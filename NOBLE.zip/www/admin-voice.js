/* NOBLE — لوحة التحكم ← «🎙 الصوت» (1.17)
 * المايك في التطبيق: تشغيل/إيقاف، مين يستخدمه، كل قسم لحاله، المدة، الزر العائم، التلميحة، شكل الموجة.
 * محفوظ في إعدادات السوق (Market.voice) — «نشر التعديلات» يوصلها لكل المستخدمين فوراً.
 */
'use strict';
async function openVoiceAdmin() {
  const box = $('#a-voice');
  if (!MK.data) box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  await loadMarket();
  MK.data.voice = { ...Voice.DEF, ...(MK.data.voice || {}), secs: { ...((MK.data.voice || {}).secs || {}) } };
  renderVoiceAdmin();
}
function renderVoiceAdmin() {
  const box = $('#a-voice'), V = MK.data.voice;
  const ch = () => { mkChanged(); renderVoiceAdmin(); };
  const AUD = [['all', '👁 الكل'], ['beta', '🧪 المختبرين'], ['pro', '💎 المشتركين'], ['off', '🚫 مقفل']];
  const seg = (cur, set, opts = AUD) => h('div', { class: 'vca-aud' }, ...opts.map(([k, l]) => h('button', { type: 'button', class: cur === k ? 'on' : '', onclick: () => { set(k); ch(); } }, l)));
  const tog = (title, sub, on, set) => { const c = h('input', { type: 'checkbox', checked: !!on }); c.addEventListener('change', () => { set(c.checked); ch(); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))); };
  const sl = (label, val, min, max, step, set, fmt) => { const r = h('input', { type: 'range', min, max, step, value: val }), o = h('em', { class: 'num', text: fmt(val) }); r.addEventListener('input', () => { o.textContent = fmt(+r.value); }); r.addEventListener('change', () => { set(+r.value); mkChanged(); }); return h('label', { class: 'uia-sl' }, h('span', { text: label }), r, o); };
  box.replaceChildren(
    mkHero('🎙 الصوت والمايك', 'المايك يحوّل كلام المستخدم لنص من الجوال نفسه (مجاني ويدعم العربي). تحكم وين يظهر ولمين — ويوصل للكل بعد النشر.'),
    h('div', { class: 'set-card vca-card' },
      tog('تشغيل الصوت في التطبيق', 'لو أطفأته يختفي المايك من كل مكان', V.on !== false, (v) => (V.on = v)),
      h('div', { class: 'vca-row' }, h('b', { text: 'مين يقدر يستخدمه' }), seg(V.aud || 'all', (k) => (V.aud = k), AUD.slice(0, 3)))),
    h('div', { class: 'set-card vca-card' },
      h('b', { class: 'vca-h', text: 'الأقسام' }), h('p', { class: 'hint', text: 'شغّل المايك في كل قسم وحدد له المستخدمين — والمستخدم يقدر يطفيه لنفسه من إعداداته.' }),
      ...Voice.SECS.map(([k, e, n]) => h('div', { class: 'vca-row' }, h('span', { text: `${e} ${n}` }), seg(V.secs[k] || 'all', (x) => { if (x === 'all') delete V.secs[k]; else V.secs[k] = x; })))),
    h('div', { class: 'set-card vca-card' },
      h('b', { class: 'vca-h', text: 'السلوك' }),
      sl('أقصى مدة', Number(V.maxSec) || 45, 10, 120, 5, (v) => (V.maxSec = v), (v) => `${UI.n(v)} ث`),
      tog('الزر العائم متاح للمستخدمين', 'زر مايك يظهر في الشاشات اللي ما فيها مايك (المستخدم يفعّله من إعداداته)', V.fab !== false, (v) => (V.fab = v)),
      tog('تلميحة «اضغط وتكلّم» للمستخدم الجديد', '', V.tip !== false, (v) => (V.tip = v)),
      h('b', { class: 'vca-h', text: 'شكل الموجة وقت الاستماع' }),
      h('div', { class: 'chips' }, ...[['orb', '🔵 كرة نابضة'], ['bars', '▮▮▮ أعمدة'], ['ring', '◯ حلقات'], ['line', '〰 موجة']].map(([k, l]) => h('button', { type: 'button', class: `chip${(V.wave || 'orb') === k ? ' on' : ''}`, onclick: () => { V.wave = k; ch(); } }, l))),
      h('button', { type: 'button', class: 'btn', onclick: async () => { const keep = Market.get().voice; Market.get().voice = V; const t = await Voice.listen({}); Market.get().voice = keep; if (t) toast('سمعتك: ' + t, { duration: 4000 }); } }, '🎙 جرّب الشكل هنا')),
    (() => { V.dest = V.dest || {}; const D = [['task', '✅ مهمة'], ['expense', '💳 مصروف'], ['income', '💰 دخل'], ['site', '🔗 موقع']];
      return h('div', { class: 'set-card vca-card' },
        h('b', { class: 'vca-h', text: '🧭 وين يروح الكلام (الإضافة السريعة)' }),
        h('p', { class: 'hint', text: 'المستخدم يختار قبل ما يتكلم: تلقائي أو مهمة أو مصروف… — و«تلقائي» يفهم من كلامه («ضيف مصروف ٥٠ بنزين» يروح للمالية). وبعد الفهم يقدر يحوّل أي بطاقة لنوع ثاني.' }),
        tog('أزرار «وين يروح؟» تظهر للمستخدم', 'لو أطفأتها يستخدم الافتراضي تحت', V.destPick !== false, (v) => (V.destPick = v)),
        h('div', { class: 'vca-row' }, h('b', { text: 'الافتراضي' }), seg(V.destDef || 'auto', (k) => (V.destDef = k), [['auto', '🪄 تلقائي'], ...D])),
        ...D.map(([k, l]) => tog(`مسموح: ${l}`, '', V.dest[k] !== false, (v) => { if (v) delete V.dest[k]; else V.dest[k] = false; })));
    })(),
    h('p', { class: 'hint', text: '💡 المايك يشتغل من خدمة التعرّف على الصوت في جوال المستخدم (Google في أندرويد) — ما يستهلك من حد Gemini.' }));
  UI.digitize(box);
}
