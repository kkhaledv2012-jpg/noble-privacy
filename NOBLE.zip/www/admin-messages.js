/* NOBLE — لوحة الإدارة: الرسائل (صندوق الرسائل / شاشة كاملة / شريط)
 * عامة أو خاصة لمستخدمين محددين، مع التحكم في الشكل واللون والحركة والأيقونة ومدة الظهور، ومعاينة مباشرة.
 */
'use strict';

const M = {
  type: 'inbox', kind: 'all', people: new Set(), q: '',
  icon: '', theme: 'flame', shape: 'card', anim: 'none', pos: 'top', close: false,
  exp: 'none', editing: null, notices: [],
};
const EXP = { none: 'بلا انتهاء', d1: 'يوم', d3: '٣ أيام', d7: 'أسبوع', custom: 'تاريخ' };
const TYPE_HINT = {
  inbox: 'تصل لصندوق رسائل المستخدم مع تنبيه، وتبقى فيه.',
  screen: 'تظهر كشاشة كاملة فوق التطبيق، ولا تختفي حتى يضغط «قرأت».',
  bar: 'تظهر كشريط أعلى أو أسفل التطبيق حتى يضغط «قرأت»، والتطبيق يعمل تحتها.',
};

/* ---------- عناصر النموذج الثابتة ---------- */
function buildMsgControls() {
  const seg = (box, name, map, cur, onPick) => {
    box.replaceChildren(...Object.entries(map).map(([k, v]) => h('label', {},
      h('input', { type: 'radio', name, value: k, checked: k === cur, onchange: () => { onPick(k); syncMsgForm(); } }), h('span', { text: v }))));
  };
  $('#m-theme').replaceChildren(...Object.entries(NoticeUI.THEMES).map(([k, v]) => h('button', {
    type: 'button', class: `m-sw nt-theme-${k}${M.theme === k ? ' on' : ''}`, title: v, 'aria-label': v,
    onclick: () => { M.theme = k; $$('#m-theme .m-sw').forEach((b) => b.classList.toggle('on', b.title === v)); syncMsgForm(); },
  }, h('i'))));
  seg($('#m-shape'), 'mshape', NoticeUI.SHAPES, M.shape, (k) => (M.shape = k));
  seg($('#m-anim'), 'manim', NoticeUI.ANIMS, M.anim, (k) => (M.anim = k));
  seg($('#m-pos'), 'mpos', NoticeUI.POS, M.pos, (k) => (M.pos = k));
  seg($('#m-exp'), 'mexp', EXP, M.exp, (k) => { M.exp = k; $('#m-exp-at').hidden = k !== 'custom'; if (k === 'custom' && !$('#m-exp-at').value) $('#m-exp-at').value = localDT(Date.now() + 3 * 864e5); });
  $('#m-icons').replaceChildren(
    h('button', { type: 'button', class: `m-ic${!M.icon ? ' on' : ''}`, dataset: { id: '' }, title: 'الافتراضية', onclick: () => pickIcon('') }, h('small', { text: 'بدون' })),
    ...AniIcon.ids.map((id) => h('button', { type: 'button', class: `m-ic${M.icon === id ? ' on' : ''}`, dataset: { id }, title: AniIcon.name(id), 'aria-label': AniIcon.name(id), onclick: () => pickIcon(id) }, AniIcon.node(id, 26))));
}
function pickIcon(id) {
  M.icon = id;
  $$('#m-icons .m-ic').forEach((b) => b.classList.toggle('on', b.dataset.id === id));
  syncMsgForm();
}
const localDT = (t) => { const d = new Date(t); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

/* ---------- المستخدمون المختارون (رسالة خاصة) ---------- */
const msgUsers = () => A.users.filter((u) => u.id !== A.me.id && u.status !== 'suspended');
function paintPeople() {
  const q = UI.normAr(M.q.trim().toLowerCase());
  const list = msgUsers().filter((u) => !q || UI.normAr(`${nameOf(u)} ${u.email}`.toLowerCase()).includes(q)).slice(0, 60);
  $('#m-people-list').replaceChildren(...(list.length ? list.map((u) => {
    const on = M.people.has(u.id);
    return h('button', { type: 'button', class: `m-person${on ? ' on' : ''}`, onclick: () => { if (on) M.people.delete(u.id); else M.people.add(u.id); paintPeople(); syncMsgForm(); } },
      h('span', { class: 'u-av sm', style: { '--h': hueOf(u.email) }, text: nameOf(u).charAt(0).toUpperCase() }),
      h('span', { class: 'm-person-t' }, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email })),
      h('span', { class: 'm-check' }, on ? icon('check', { size: 14 }) : null));
  }) : [h('p', { class: 'hint', text: 'لا يوجد مستخدمون مطابقون' })]));
  const chosen = [...M.people].map((id) => A.users.find((u) => u.id === id)).filter(Boolean);
  $('#m-chosen').replaceChildren(...(chosen.length ? chosen.map((u) => h('span', { class: 'chip on m-chip' }, nameOf(u),
    h('button', { type: 'button', 'aria-label': 'إزالة', onclick: () => { M.people.delete(u.id); paintPeople(); syncMsgForm(); } }, icon('x', { size: 12 }))))
    : [h('small', { class: 'hint', text: 'لم تختر أحداً بعد' })]));
}
/* من قائمة المستخدمين: «إرسال رسالة خاصة» */
function setMsgTarget(id) {
  resetMsgForm();
  if (id) { M.kind = 'some'; M.people = new Set([id]); }
  syncMsgForm();
  $('#m-title').focus();
}

/* ---------- الرابط والزر ---------- */
function msgLabel() {
  const v = $('input[name=mlabel]:checked')?.value;
  if (v === 'details') return 'التفاصيل';
  if (v === 'custom') return $('#m-label').value.trim();
  return 'اضغط هنا للتحديث';
}
function syncMsgLink() {
  const raw = $('#m-link').value.trim();
  const url = Links.norm(raw);
  $('#m-label-wrap').hidden = !url;
  $('#m-label').hidden = $('input[name=mlabel]:checked')?.value !== 'custom';
  const hint = $('#m-link-hint');
  hint.hidden = !raw;
  hint.className = 'hint' + (raw && !url ? ' bad' : '');
  hint.textContent = !raw ? '' : !url ? 'الرابط غير صحيح' : Links.isDrive(url)
    ? (Links.driveId(url) ? '✓ رابط Google Drive — سيُحمَّل الملف مباشرة. تأكد أن مشاركة الملف «أي شخص لديه الرابط».' : 'رابط Drive بدون ملف محدد')
    : Links.isApk(url) ? '✓ رابط ملف APK — يبدأ التحميل مباشرة.' : '✓ سيُفتح الرابط في المتصفح.';
}

/* ---------- قراءة النموذج ---------- */
function msgStyle() {
  const gif = Links.norm($('#m-gif').value.trim());
  const st = { icon: M.icon || '', gif: gif || '' };
  if (M.type === 'inbox') return st;
  st.theme = M.theme;
  if (M.type === 'bar') Object.assign(st, { shape: M.shape, anim: M.anim, pos: M.pos, close: M.close });
  return st;
}
function msgExpires() {
  if (M.type === 'inbox' || M.exp === 'none') return null;
  if (M.exp === 'custom') { const v = $('#m-exp-at').value; return v ? new Date(v).toISOString() : null; }
  const days = { d1: 1, d3: 3, d7: 7 }[M.exp] || 0;
  return new Date(Date.now() + days * 864e5).toISOString();
}
function msgDraft() {
  const rawLink = $('#m-link').value.trim(), link = Links.norm(rawLink);
  return {
    type: M.type, title: $('#m-title').value.trim(), body: $('#m-body').value.trim(),
    rawLink, link, label: link ? msgLabel() : '', image: Links.norm($('#m-image').value.trim()),
    style: msgStyle(), expires: msgExpires(), targets: M.kind === 'some' ? [...M.people] : [],
  };
}

/* ---------- المزامنة والمعاينة ---------- */
function syncMsgForm() {
  const canAll = can('messages.broadcast'), canOne = can('messages.send');
  if (!canAll) { M.type = 'inbox'; M.kind = 'some'; }
  if (M.type !== 'inbox' && !canAll) M.type = 'inbox';
  $$('input[name=mtype]').forEach((r) => { r.checked = r.value === M.type; r.disabled = !!M.editing && r.value === 'inbox'; });
  $('#m-type').hidden = !canAll;
  $$('input[name=mkind]').forEach((r) => (r.checked = r.value === M.kind));
  $$('input[name=mkind]')[0].closest('label').hidden = !canAll;
  $$('input[name=mkind]')[1].closest('label').hidden = !canOne && M.type === 'inbox';
  $('#m-type-hint').textContent = TYPE_HINT[M.type];
  $('#m-people').hidden = M.kind !== 'some';
  if (M.kind === 'some') paintPeople();
  $('#m-notice-opts').hidden = M.type === 'inbox';
  $('#m-look').hidden = M.type === 'inbox';
  $$('#m-look [data-for=bar]').forEach((el) => (el.hidden = M.type !== 'bar'));
  $('#m-close').checked = M.close;
  $$('input[name=mshape]').forEach((r) => (r.checked = r.value === M.shape));
  $$('input[name=manim]').forEach((r) => (r.checked = r.value === M.anim));
  $$('input[name=mpos]').forEach((r) => (r.checked = r.value === M.pos));
  $$('input[name=mexp]').forEach((r) => (r.checked = r.value === M.exp));
  $('#m-exp-at').hidden = M.exp !== 'custom' || M.type === 'inbox';
  $$('#m-theme .m-sw').forEach((b) => b.classList.toggle('on', b.classList.contains(`nt-theme-${M.theme}`)));
  $('#m-form-title').textContent = M.editing ? 'تعديل رسالة منشورة' : 'رسالة جديدة';
  $('#m-cancel-edit').hidden = !M.editing;
  const n = M.kind === 'some' ? M.people.size : 0;
  $('#m-send').textContent = M.editing ? 'حفظ التعديل — يصل فوراً' : M.kind === 'some' ? (n > 1 ? `إرسال لـ ${n} مستخدمين` : 'إرسال رسالة خاصة') : 'إرسال للجميع';
  syncMsgLink();
  paintPreview();
}

let previewTimer;
function paintPreview() {
  clearTimeout(previewTimer);
  previewTimer = setTimeout(() => {
    const d = msgDraft();
    const n = {
      id: 'preview', title: d.title || 'عنوان الرسالة', body: d.body || (M.type === 'bar' ? '' : 'نص الرسالة يظهر هنا…'),
      image_url: d.image, link: d.link, link_label: d.label, style: d.style, created_at: new Date().toISOString(), target: d.targets[0] || null,
    };
    const scr = $('#m-preview');
    const top = h('div', { class: 'pv-top' }, h('img', { src: (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'), alt: '' }), h('b', {}, 'NOBLE ', h('span', { text: 'WEB' })));
    const ghost = h('div', { class: 'pv-ghost' }, ...Array.from({ length: 5 }, () => h('i')));
    const tabs = h('div', { class: 'pv-tabs' }, ...['المواقع', 'المهام', 'المالية', 'الألعاب'].map((t, i) => h('span', { class: i ? '' : 'on', text: t })));
    if (M.type === 'bar') {
      const st = NoticeUI.style(n.style);
      const host = h('div', { class: `notice-host${st.pos === 'bottom' ? ' at-bottom' : ''}` }, NoticeUI.bar(n, { preview: true, onRead: () => toast('في التطبيق: تُعلَّم كمقروءة وتختفي') }));
      scr.replaceChildren(...[top, st.pos === 'bottom' ? null : host, ghost, st.pos === 'bottom' ? host : null, tabs].filter(Boolean));
    } else if (M.type === 'screen') {
      scr.replaceChildren(top, ghost, tabs, h('div', { class: 'notice-gate' }, NoticeUI.gate(n, { wait: 0, preview: true, onRead: () => toast('في التطبيق: تُغلق الشاشة ويكمل العميل') })));
    } else {
      const b = Links.body(n.body, n.link, n.link_label);
      scr.replaceChildren(top, ghost, tabs, h('div', { class: 'pv-sheet' },
        h('div', { class: 'pv-grab' }), h('h3', { text: 'الرسائل' }),
        h('article', { class: 'msg new' },
          h('div', { class: 'msg-head' }, h('span', { class: 'msg-ic' }, NoticeUI.msgIcon(n)), h('b', { text: n.title }), h('small', { class: 'n-time', text: 'الآن' })),
          b.text.length ? h('p', { class: 'msg-text' }, ...b.text) : null, b.button,
          h('small', { class: 'msg-kind', text: n.target ? 'رسالة خاصة لك' : 'إعلان للجميع' }))));
    }
  }, 60);
}

function resetMsgForm() {
  Object.assign(M, { kind: can('messages.broadcast') ? 'all' : 'some', people: new Set(), q: '', icon: '', theme: 'flame', shape: 'card', anim: 'none', pos: 'top', close: false, exp: 'none', editing: null });
  if (!can('messages.broadcast')) M.type = 'inbox';
  for (const id of ['m-title', 'm-body', 'm-link', 'm-label', 'm-gif', 'm-image', 'm-people-q', 'm-exp-at']) $('#' + id).value = '';
  $$('input[name=mlabel]')[0].checked = true;
  $('#m-error').textContent = '';
  pickIcon('');
}

/* تعديل رسالة إجبارية منشورة */
function editNotice(n) {
  resetMsgForm();
  const st = NoticeUI.style(n.style);
  Object.assign(M, { editing: n.id, type: n.level === 'bar' ? 'bar' : 'screen', kind: n.targets?.length ? 'some' : 'all', people: new Set(n.targets || []),
    icon: st.icon, theme: st.theme, shape: st.shape, anim: st.anim, pos: st.pos, close: st.close, exp: n.expires_at ? 'custom' : 'none' });
  $('#m-title').value = n.title || '';
  $('#m-body').value = n.body || '';
  $('#m-link').value = n.link || '';
  $('#m-gif').value = st.gif || '';
  $('#m-image').value = n.image_url || '';
  if (n.expires_at) $('#m-exp-at').value = localDT(new Date(n.expires_at).getTime());
  const lbl = n.link_label || '';
  const key = !lbl || lbl === 'اضغط هنا للتحديث' ? 'update' : lbl === 'التفاصيل' ? 'details' : 'custom';
  $$('input[name=mlabel]').forEach((r) => (r.checked = r.value === key));
  if (key === 'custom') $('#m-label').value = lbl;
  pickIcon(st.icon);
  syncMsgForm();
  $('#m-form').scrollIntoView({ behavior: 'smooth', block: 'start' });
}

/* ---------- الإرسال ---------- */
async function submitMsg(e) {
  e.preventDefault();
  const d = msgDraft(), err = $('#m-error');
  err.textContent = '';
  if (!d.title) return (err.textContent = 'اكتب عنواناً للرسالة');
  if (d.rawLink && !d.link) return (err.textContent = 'رابط الزر غير صحيح');
  if (d.link && $('input[name=mlabel]:checked').value === 'custom' && !d.label) return (err.textContent = 'اكتب نص الزر');
  if ($('#m-gif').value.trim() && !d.style.gif) return (err.textContent = 'رابط GIF غير صحيح');
  if (M.kind === 'some' && !d.targets.length) return (err.textContent = 'اختر مستخدماً واحداً على الأقل');
  if (d.expires && new Date(d.expires).getTime() <= Date.now()) return (err.textContent = 'تاريخ الانتهاء في الماضي');
  const btn = $('#m-send');
  btn.disabled = true;
  try {
    if (M.type === 'inbox') {
      const targets = M.kind === 'some' ? d.targets : [null];
      for (const t of targets) await Cloud.admin.sendMessage(t, d.title, d.body, d.link, d.label, d.style);
      toast(M.kind === 'some' ? (targets.length > 1 ? `أُرسلت لـ ${targets.length} مستخدمين` : 'أُرسلت الرسالة الخاصة') : 'نُشر الإعلان لكل المستخدمين', { type: 'success' });
    } else {
      const payload = { title: d.title, body: d.body, image: d.image, link: d.link, level: M.type, label: d.label, style: d.style, targets: d.targets, expires: d.expires };
      if (M.editing) {
        await Cloud.admin.updateNotice(M.editing, payload);
        toast('حُفظ التعديل — يظهر فوراً عند من لم يقرأها', { type: 'success', duration: 5000 });
      } else {
        await Cloud.admin.createNotice(payload);
        toast(M.kind === 'some' ? 'أُرسلت الرسالة الخاصة — تظهر لهم فوراً' : 'أُرسلت الرسالة — تظهر فوراً لكل المستخدمين', { type: 'success', duration: 5000 });
      }
    }
    resetMsgForm();
    syncMsgForm();
    loadMessages();
  } catch (ex) { err.textContent = Cloud.msg(ex); }
  finally { btn.disabled = false; }
}

/* ---------- القوائم ---------- */
const audience = (targets) => {
  if (!targets?.length) return 'للجميع';
  const names = targets.map((id) => A.users.find((u) => u.id === id)).filter(Boolean).map(nameOf);
  return names.length <= 2 ? `خاصة: ${names.join('، ') || targets.length + ' مستخدم'}` : `خاصة: ${names.slice(0, 2).join('، ')} +${names.length - 2}`;
};
async function loadNotices() {
  const box = $('#n-list');
  if (!can('messages.broadcast')) { box.replaceChildren(h('p', { class: 'hint', text: 'الرسائل الإجبارية تحتاج صلاحية الإعلانات.' })); return; }
  let list = [];
  try { list = (await Cloud.admin.notices()) || []; } catch { list = []; }
  M.notices = list;
  const now = Date.now();
  box.replaceChildren(...(list.length ? list.map((n) => {
    const pct = n.total ? Math.round((n.reads / n.total) * 100) : 0;
    const st = NoticeUI.style(n.style);
    const expired = n.expires_at && new Date(n.expires_at).getTime() <= now;
    const b = Links.body(n.body, n.link, n.link_label, { small: true, block: false, hint: false });
    return h('article', { class: `msg notice${n.active && !expired ? '' : ' off'}${M.editing === n.id ? ' editing' : ''}` },
      h('div', { class: 'msg-head' },
        h('span', { class: `msg-ic nt-dot nt-theme-${st.theme}` }, AniIcon.forStyle(st, 18, 'bell')),
        h('b', { text: n.title }),
        h('span', { class: `pill ${n.level === 'screen' ? 'role-admin' : 'nick'}`, text: n.level === 'screen' ? 'شاشة' : 'شريط' }),
        h('small', { class: 'n-time', text: UI.relTime(ts(n.created_at)) })),
      b.text.length ? h('p', {}, ...b.text) : null, b.button,
      h('div', { class: 'nt-meta' },
        h('span', { class: `chip sm${n.targets?.length ? ' on' : ''}` }, icon(n.targets?.length ? 'user' : 'users', { size: 13 }), audience(n.targets)),
        n.level === 'bar' ? h('span', { class: 'chip sm' }, `${NoticeUI.SHAPES[st.shape]} · ${NoticeUI.ANIMS[st.anim]} · ${NoticeUI.POS[st.pos]}`) : null,
        n.expires_at ? h('span', { class: `chip sm${expired ? ' warn' : ''}` }, icon('clock', { size: 13 }), expired ? 'انتهت' : `حتى ${new Date(n.expires_at).toLocaleDateString('ar', { day: 'numeric', month: 'short' })}`) : null),
      h('div', { class: 'nt-prog' }, h('i', { style: { width: pct + '%' } })),
      h('div', { class: 'nt-foot' },
        h('button', { type: 'button', class: 'link-btn', onclick: () => showReaders(n) }, `قرأها ${n.reads} من ${n.total} (${pct}٪)`),
        h('div', { class: 'nt-btns' },
          h('button', { type: 'button', class: 'btn sm', onclick: () => editNotice(n) }, icon('edit', { size: 14 }), 'تعديل'),
          h('button', { type: 'button', class: 'btn sm', onclick: async () => { try { await Cloud.admin.setNotice(n.id, !n.active); loadNotices(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, n.active ? 'إيقاف' : 'تفعيل'),
          h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => {
            if (await confirmSheet({ title: 'حذف الرسالة الإجبارية؟', text: 'تختفي عند من لم يقرأها بعد.', ok: 'حذف' })) {
              try { await Cloud.admin.deleteNotice(n.id); if (M.editing === n.id) { resetMsgForm(); syncMsgForm(); } loadNotices(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
            }
          } }, icon('trash', { size: 16 })))));
  }) : [h('p', { class: 'hint', text: 'لا توجد رسائل إجبارية.' })]));
}
async function showReaders(n) {
  let rows = [];
  try { rows = await Cloud.admin.noticeReaders(n.id); } catch (e) { return toast(Cloud.msg(e), { type: 'error' }); }
  const read = rows.filter((r) => r.read_at), unread = rows.filter((r) => !r.read_at);
  const row = (r) => h('div', { class: 'rd-row' }, h('span', { class: `rd-dot${r.read_at ? ' on' : ''}` }), h('div', { class: 'rd-t' }, h('b', { text: r.name || r.email.split('@')[0] }), h('small', { class: 'ltr', text: r.email })),
    h('small', { class: 'n-time', text: r.read_at ? UI.relTime(ts(r.read_at)) : 'لم يقرأ' }));
  pickSheet(n.title, `قرأها ${read.length} · لم يقرأها ${unread.length}`, [h('div', { class: 'rd-list' }, ...read.map(row), ...unread.map(row))]);
}
async function loadMessages() {
  syncMsgForm();
  loadNotices();
  try { A.msgs = (await Cloud.messages()) || []; } catch { A.msgs = []; }
  const who = (id) => { const u = A.users.find((x) => x.id === id); return u ? nameOf(u) : 'مستخدم'; };
  $('#m-list').replaceChildren(...(A.msgs.length ? A.msgs.map((m) => {
    const b = Links.body(m.body, m.link, m.link_label, { small: true, block: false, hint: false });
    return h('article', { class: 'msg' },
      h('div', { class: 'msg-head' }, h('span', { class: 'msg-ic' }, NoticeUI.msgIcon(m)), h('b', { text: m.title }),
        h('small', { class: 'n-time', text: UI.relTime(ts(m.created_at)) }),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => {
          if (await confirmSheet({ title: 'حذف الرسالة؟', text: 'تختفي من صندوق رسائل المستخدمين.', ok: 'حذف' })) { try { await Cloud.admin.deleteMessage(m.id); toast('حُذفت', { type: 'success' }); loadMessages(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }
        } }, icon('trash', { size: 16 }))),
      b.text.length ? h('p', {}, ...b.text) : null, b.button,
      h('small', { class: 'msg-kind', text: m.target ? `خاصة إلى ${who(m.target)}` : 'إعلان للجميع' }));
  }) : [h('div', { class: 'empty' }, icon('mail', { size: 34 }), h('p', { text: 'لم تُرسل رسائل بعد' }))]));
}

/* ---------- الربط ---------- */
function bindMessages() {
  buildMsgControls();
  $$('input[name=mtype]').forEach((r) => r.addEventListener('change', () => { M.type = r.value; syncMsgForm(); }));
  $$('input[name=mkind]').forEach((r) => r.addEventListener('change', () => { M.kind = r.value; syncMsgForm(); }));
  $('#m-people-q').addEventListener('input', (e) => { M.q = e.target.value; paintPeople(); });
  $('#m-close').addEventListener('change', (e) => { M.close = e.target.checked; paintPreview(); });
  $$('input[name=mlabel]').forEach((r) => r.addEventListener('change', () => { syncMsgLink(); paintPreview(); if (r.value === 'custom' && r.checked) $('#m-label').focus(); }));
  for (const id of ['m-title', 'm-body', 'm-link', 'm-label', 'm-gif', 'm-image', 'm-exp-at']) $('#' + id).addEventListener('input', () => { syncMsgLink(); paintPreview(); });
  $('#m-cancel-edit').addEventListener('click', () => { resetMsgForm(); syncMsgForm(); loadNotices(); });
  $('#m-form').addEventListener('submit', submitMsg);
}
