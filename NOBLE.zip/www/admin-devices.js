/* NOBLE — لوحة الإدارة: «📱 الأجهزة والضيوف» (1.20)
 * مين ثبّت التطبيق ودخل (حتى بدون حساب)، نوع جواله وإصدار أندرويد ولغته ومنطقته (من إعدادات الجوال)،
 * أول فتح وآخر ظهور، وإحصائيات: ضيوف/حسابات، نشطين، أكثر الأجهزة، إصدارات أندرويد ونوبل، تثبيتات كل يوم.
 */
'use strict';

/* أسماء تجارية لأشهر موديلات سامسونج (الجوال يرسل الرمز مثل SM-S911B) */
const SAMSUNG = [
  [/^SM-S931/, 'Galaxy S25'], [/^SM-S936/, 'Galaxy S25+'], [/^SM-S938/, 'Galaxy S25 Ultra'],
  [/^SM-S921/, 'Galaxy S24'], [/^SM-S926/, 'Galaxy S24+'], [/^SM-S928/, 'Galaxy S24 Ultra'], [/^SM-S721/, 'Galaxy S24 FE'],
  [/^SM-S911/, 'Galaxy S23'], [/^SM-S916/, 'Galaxy S23+'], [/^SM-S918/, 'Galaxy S23 Ultra'], [/^SM-S711/, 'Galaxy S23 FE'],
  [/^SM-S901/, 'Galaxy S22'], [/^SM-S906/, 'Galaxy S22+'], [/^SM-S908/, 'Galaxy S22 Ultra'],
  [/^SM-F95/, 'Galaxy Z Fold'], [/^SM-F94/, 'Galaxy Z Fold5'], [/^SM-F73/, 'Galaxy Z Flip'],
  [/^SM-A5[5-6]/, 'Galaxy A55/A56'], [/^SM-A5[3-4]/, 'Galaxy A53/A54'], [/^SM-A3[5-6]/, 'Galaxy A35/A36'], [/^SM-A2[5-6]/, 'Galaxy A25/A26'],
  [/^SM-A1[5-6]/, 'Galaxy A15/A16'], [/^SM-A0/, 'Galaxy A0x'], [/^SM-M/, 'Galaxy M'], [/^SM-N/, 'Galaxy Note'],
];
const CC_AR = { SA: 'السعودية', AE: 'الإمارات', KW: 'الكويت', QA: 'قطر', BH: 'البحرين', OM: 'عُمان', YE: 'اليمن', EG: 'مصر', JO: 'الأردن', IQ: 'العراق', LB: 'لبنان', SY: 'سوريا', MA: 'المغرب', DZ: 'الجزائر', TN: 'تونس', LY: 'ليبيا', SD: 'السودان', US: 'أمريكا', GB: 'بريطانيا', TR: 'تركيا' };
const flagOf = (cc) => (/^[A-Z]{2}$/.test(cc || '') ? String.fromCodePoint(...[...cc].map((c) => 0x1f1a5 + c.charCodeAt(0))) : '');
const ccName = (cc) => (cc ? `${flagOf(cc)} ${CC_AR[cc] || cc}` : '—');
const langName = (l) => { const b = String(l || '').slice(0, 2); return ({ ar: 'العربية', en: 'English', fr: 'Français', tr: 'Türkçe', ur: 'اردو', hi: 'हिन्दी' })[b] || l || '—'; };

const devOf = (u) => A.ustats?.[u.id]?.stats?.device || null;
function devModel(d) {
  if (!d) return '';
  const b = String(d.brand || ''), m = String(d.model || '');
  if (/samsung/i.test(b) || (!b && /^SM-/.test(m))) { const hit = SAMSUNG.find(([re]) => re.test(m)); if (hit) return hit[1]; }
  if (!m) return b;
  return b && m.toLowerCase().startsWith(b.toLowerCase()) ? m : [b, m].filter(Boolean).join(' ');
}
const devOs = (d) => (!d ? '' : d.os === 'android' ? `أندرويد ${d.osv || ''}`.trim() : d.os === 'ios' ? `iOS ${d.osv || ''}`.trim() : d.platform === 'web' || /windows|mac|linux/.test(d.os || '') ? 'متصفح' : '');
const devLabel = (d) => [devModel(d), devOs(d)].filter(Boolean).join(' · ');
const isGuest = (u) => !!u.guest;
/* الاسم في القائمة: الاسم اللي كتبه ← وإلا «ضيف · نوع الجوال» ← وإلا «ضيف · xxxx» */
function guestName(u) {
  if (u.display_name) return u.display_name;
  const m = devModel(devOf(u));
  return m ? `ضيف · ${m}` : u.email;
}
function guestSub(u) {
  const d = devOf(u), l = devLabel(d);
  return ['بدون حساب', l, d?.cc && flagOf(d.cc)].filter(Boolean).join(' · ');
}

/* ---------- لوحة الأجهزة ---------- */
function topOf(list, key, n = 6) {
  const m = new Map();
  for (const x of list) { const k = key(x); if (k) m.set(k, (m.get(k) || 0) + 1); }
  return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, n);
}
function barRows(rows, total) {
  if (!rows.length) return h('p', { class: 'hint', text: 'ما فيه بيانات بعد — تطلع بعد ما يفتحون التطبيق بالإصدار الجديد.' });
  const max = rows[0][1] || 1;
  return h('div', { class: 'dv-bars' }, ...rows.map(([k, v]) => h('div', { class: 'dv-bar', title: `${k}: ${v}` },
    h('span', { class: 'dv-k', text: k }),
    h('span', { class: 'dv-track' }, h('i', { style: { width: `${Math.max(4, (v / max) * 100)}%` } })),
    h('b', { class: 'num' }, String(v), total ? h('small', { text: ` ${Math.round((v / total) * 100)}٪` }) : null))));
}
function installsChart(users) {
  const days = [], now = new Date();
  for (let i = 13; i >= 0; i--) { const d = new Date(now); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); days.push({ d, n: 0, g: 0 }); }
  for (const u of users) {
    const t = new Date(u.created_at); t.setHours(0, 0, 0, 0);
    const x = days.find((y) => y.d.getTime() === t.getTime()); if (x) { x.n++; if (isGuest(u)) x.g++; }
  }
  const max = Math.max(1, ...days.map((x) => x.n));
  return h('div', { class: 'dv-cols' }, ...days.map((x, i) => h('div', { class: 'dv-col', title: `${x.d.toLocaleDateString('ar', { day: 'numeric', month: 'short' })}: ${x.n} جديد (${x.g} ضيف)` },
    h('b', { class: 'num', text: x.n || '' }),
    h('span', { class: 'dv-colbar', style: { height: `${(x.n / max) * 100}%` } }),
    h('small', { class: 'num', text: i % 2 ? '' : x.d.getDate() }))));
}
function openDevices() {
  const us = A.users || [], now = Date.now();
  const seen = (u) => ts(u.last_seen_at) || ts(A.ustats?.[u.id]?.last_sync);
  const guests = us.filter(isGuest), withDev = us.filter((u) => devOf(u));
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const tile = (v, l, fn) => h(fn ? 'button' : 'div', { class: 'ua-tile', type: fn ? 'button' : undefined, onclick: fn }, h('b', { class: 'num', text: v }), h('small', { text: l }));
  const go = (chip) => () => { closeSheet(); A.chip = chip; render(); };
  const box = h('div', { class: 'ua' },
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('users', { size: 16 }), h('b', { text: 'مين دخل' })),
      h('div', { class: 'ua-grid' },
        tile(us.length, 'الكل'), tile(guests.length, 'بدون حساب', go('guest')), tile(us.length - guests.length, 'بحساب', go('reg')),
        tile(us.filter((u) => now - seen(u) < 864e5).length, 'نشط اليوم'),
        tile(us.filter((u) => now - seen(u) < 7 * 864e5).length, 'نشط ٧ أيام'),
        tile(us.filter((u) => ts(u.created_at) >= today.getTime()).length, 'جديد اليوم'),
        tile(us.filter((u) => now - seen(u) > 30 * 864e5).length, 'ما رجع من شهر'),
        tile(guests.filter((u) => u.display_name).length, 'ضيف كتب اسمه'))),
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('plus', { size: 16 }), h('b', { text: 'التثبيتات الجديدة' }), h('small', { class: 'hint', text: 'آخر ١٤ يوم' })),
      installsChart(us)),
    h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, icon('phone', { size: 16 }), h('b', { text: 'أكثر الأجهزة' })), barRows(topOf(withDev, (u) => devModel(devOf(u))), withDev.length)),
    h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '🏷️ الشركات' })), barRows(topOf(withDev, (u) => devOf(u).brand || ''), withDev.length)),
    h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '🤖 إصدار أندرويد' })), barRows(topOf(withDev, (u) => devOs(devOf(u))), withDev.length)),
    h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '📦 إصدار NOBLE' })), barRows(topOf(us, (u) => A.ustats?.[u.id]?.version && `v${A.ustats[u.id].version}`), 0)),
    h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '🌍 المنطقة واللغة' }), h('small', { class: 'hint', text: 'من إعدادات الجوال — مو GPS' })),
      barRows(topOf(withDev, (u) => devOf(u).cc && ccName(devOf(u).cc)), withDev.length),
      barRows(topOf(withDev, (u) => langName(devOf(u).lang)), 0)),
    h('p', { class: 'hint dv-note', text: '🔒 نجمع معلومات تقنية بس: نوع الجوال وإصدار النظام واللغة والمنطقة من الإعدادات. ما نجمع رقم الجوال ولا الموقع ولا أي معرّف للجهاز. المستخدم يقدر يوقفها من «مشاركة إحصائيات الاستخدام».' }));
  pickSheet('📱 الأجهزة والضيوف', `${withDev.length} من ${us.length} وصلت معلومات جهازهم`, [box]);
  UI.digitize?.(box);
}

/* بطاقة «الجهاز» داخل تفاصيل المستخدم */
function deviceCard(u) {
  const st = A.ustats?.[u.id], d = st?.stats?.device;
  const tile = (v, l) => h('div', { class: 'ua-tile' }, h('b', { text: v || '—' }), h('small', { text: l }));
  const when = (t) => (t ? new Date(t).toLocaleString('ar', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' }) : '—');
  const APPS = { nobleweb: 'NOBLE', vault: 'الخزنة', tasks: 'المهام', finance: 'المالية', games: 'الألعاب', azkar: 'الأذكار' };
  return h('section', { class: 'ua-card' },
    h('div', { class: 'ua-h' }, icon('phone', { size: 16 }), h('b', { text: 'الجهاز' }), h('small', { class: 'hint', text: isGuest(u) ? 'دخل بدون حساب' : 'بحساب' })),
    d ? h('div', { class: 'ua-grid' },
      tile(devModel(d), 'نوع الجوال'), tile(devOs(d), 'النظام'), tile(ccName(d.cc), 'المنطقة'), tile(langName(d.lang), 'اللغة'),
      tile(APPS[d.app] || d.app, 'التطبيق'), tile(d.screen, 'الشاشة'), tile(when(u.created_at), 'أول فتح'), tile(when(u.last_seen_at || st?.last_sync), 'آخر ظهور'))
      : h('p', { class: 'hint', text: 'معلومات الجهاز تطلع بعد ما يفتح التطبيق بإصدار 1.20 أو أحدث (أو موقّف «مشاركة الإحصائيات»).' }));
}
