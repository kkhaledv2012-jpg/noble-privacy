/* NOBLE — قسم «أذكاري» (1.17): بيتك الإيماني بأربع تبويبات
 * اليوم (ذكي حسب الوقت) · المصحف (كامل بدون نت بخط مجمع الملك فهد) · الأذكار (وضع الجلسة + المسبحة) · الخدمات (المواقيت، الأذان، القبلة، التقويم الهجري، المناسبات)
 * + الذكر عند فتح التطبيق (مع «🙈 إخفاء») + «صمّمها حالة» — والإدارة تتحكم في كل جزء وأيقوناته (لوحة التحكم ← الأذكار).
 */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const AZ = { items: null, meta: {}, at: 0, cat: '', counts: {}, tab: '', m: 'reads', idx: 'surah', q: '', ss: null };
const AZ_KEY = 'nw:azkar';
const lsG = (k, d = '') => { try { return localStorage.getItem(k) ?? d; } catch { return d; } };
const lsS = (k, v) => { try { localStorage.setItem(k, v); } catch { /* لا شيء */ } };
function azCache(v) {
  if (v) { try { localStorage.setItem(AZ_KEY, JSON.stringify(v)); } catch { /* لا شيء */ } return v; }
  try { return JSON.parse(localStorage.getItem(AZ_KEY) || 'null'); } catch { return null; }
}
const azCfg = () => AzkarKit.cfg(AZ.meta || {});
const azAll = () => AzkarKit.list(AZ.items || [], AZ.meta || {});
async function loadAzkar(force) {
  if (!AZ.items) { const c = azCache(); if (c) { AZ.items = c.items || []; AZ.meta = c.meta || {}; } }
  if (!Cloud.enabled || (!force && Date.now() - AZ.at < 60e3)) return;
  AZ.at = Date.now();
  try { const r = await Cloud.azkarList(); if (r) { AZ.items = r.items || []; AZ.meta = r.meta || {}; azCache({ items: AZ.items, meta: AZ.meta }); } } catch { /* المحفوظ */ }
}
/* الظهور حسب تحكم الإدارة */
const azWho = () => ({ tester: typeof Pro !== 'undefined' && Pro.isTester(), pro: typeof Pro === 'undefined' || !Cloud.enabled || Pro.any() || Pro.inTrial() || (typeof Store !== 'undefined' && Store.noSubs()) });
const azVis = (id) => AzkarKit.visible(AZ.meta || {}, id, azWho());
const azOn = (id) => { const v = azVis(id); return v !== 'none' && v !== 'soon' && v !== 'lock'; };
const azIc = (id, o = {}) => { const s = h('span', { class: 'aik-w' }); s.innerHTML = AzkarKit.slotHTML(id, AZ.meta || {}, o); return s; };
const azItem = (id) => { const I = AzkarKit.iconCfg(AZ.meta || {}); return AzkarKit.iconItem(id, I, AzkarKit.iconSeason(I)); };
const azIcfg = () => AzkarKit.iconCfg(AZ.meta || {});
const azDay = () => { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); };
const AR = (n) => UI.n(n);

/* ================= الذكر عند فتح التطبيق ================= */
/* 1.20: ما يطلع ورا فيديو الافتتاح أو نافذة مفتوحة — ينتظر لين تفضى الشاشة (لحد ٣٠ ثانية) */
function azkarToastWhenClear(tries = 60) {
  const busy = document.getElementById('intro') || (typeof S !== 'undefined' && (!S.unlocked || (S.sheets || []).length)) || document.body.classList.contains('in-game') || document.body.classList.contains('noticed') || document.querySelector('.promo-pop, .offer-pop, .ms-pop');
  if (busy) { if (tries > 0) setTimeout(() => azkarToastWhenClear(tries - 1), 500); return; }
  azkarToast();
}
async function azkarToast(force) {
  await loadAzkar();
  const T = azCfg().toast;
  if (!force) {
    if (!T.on || !azOn('g_toast') || pref('azToastOff')) return;
    if (lsG('nw:azHideDay') === azDay()) return;
  }
  const FREQ = { open: 0, hour: 36e5, '3h': 3 * 36e5, day: 864e5 };
  const last = Number(lsG('nw:azT', 0));
  if (!force && Date.now() - last < (FREQ[T.freq] ?? 0)) return;
  const idx = Number(lsG('nw:azI', 0));
  const z = AzkarKit.pick(azAll(), T.mode, idx);
  if (!z) return;
  lsS('nw:azT', String(Date.now())); lsS('nw:azI', String(idx + 1));
  document.querySelector('.az-toast')?.remove();
  let n = 0, timer = 0;
  const prog = h('i', { class: 'az-p' });
  const cnt = h('button', { type: 'button', class: 'cnt', onclick: (e) => { n++; e.currentTarget.textContent = `قلتها ✓ ${UI.n(n)}`; e.currentTarget.classList.remove('tap'); void e.currentTarget.offsetWidth; e.currentTarget.classList.add('tap'); buzz('light'); azTasbihAdd(1); restart(); } }, 'قلتها ✓');
  const menu = h('div', { class: 'az-hm' },
    h('button', { type: 'button', onclick: () => { hide(); } }, h('span', { text: 'إخفاء الآن' }), h('small', { text: 'يرجع عند الفتح الجاي' })),
    h('button', { type: 'button', onclick: () => { lsS('nw:azHideDay', azDay()); hide(); toast('ما راح يظهر لك اليوم 🤍'); } }, h('span', { text: 'لا تظهر اليوم' }), h('small', { text: 'يرجع بكرة' })),
    h('button', { type: 'button', onclick: () => { setPref({ azToastOff: true }); hide(); toast('أوقفناه — ترجّعه من أذكاري ← ⚙️', { duration: 4000 }); } }, h('span', { text: 'إيقاف نهائي' }), h('small', { text: 'ترجّعه من إعدادات أذكاري' })));
  const box = h('div', { class: `az-toast st-${T.style} pos-${T.pos}`, role: 'status' },
    h('div', { class: 'az-h' }, h('span', { text: `${AzkarKit.catIcon(z.cat)} ${z.cat || 'ذكر'}` }), h('button', { type: 'button', class: 'x', 'aria-label': 'إغلاق', onclick: () => hide() }, '✕')),
    h('div', { class: 'az-t', text: z.text }),
    z.virtue ? h('div', { class: 'az-v', text: z.virtue }) : null,
    h('div', { class: 'az-s', text: z.source || '' }),
    h('div', { class: 'az-a' }, cnt,
      azOn('g_story') ? h('button', { type: 'button', onclick: () => { hide(); azToStory(z); } }, '🎨 حالة') : null,
      h('button', { type: 'button', class: 'az-hide', onclick: () => { menu.classList.toggle('on'); clearTimeout(timer); prog.hidden = true; } }, '🙈 إخفاء')),
    menu, prog);
  document.body.append(box);
  requestAnimationFrame(() => requestAnimationFrame(() => box.classList.add('on')));
  function restart() {
    clearTimeout(timer);
    if (!T.auto) { prog.hidden = true; return; }
    prog.style.transition = 'none'; prog.style.transform = 'scaleX(1)'; void prog.offsetWidth;
    prog.style.transition = `transform ${T.auto}s linear`; prog.style.transform = 'scaleX(0)';
    timer = setTimeout(hide, T.auto * 1000);
  }
  function hide() { clearTimeout(timer); box.classList.remove('on'); setTimeout(() => box.remove(), 600); }
  restart();
}

/* ================= صمّمها حالة ================= */
function azToStory(z) {
  if (typeof openDesign !== 'function') return toast('🎨 قسم التصاميم غير متاح هنا');
  const all = typeof dsAll === 'function' ? dsAll() : DesignKit.BUILTIN;
  const t = all.find((x) => x.id === (['دعاء', 'استغفار', 'مساء', 'نوم'].includes(z.cat) ? 'b-zk2' : 'b-zk1')) || all.find((x) => x.cat === 'azkar');
  if (!t) return;
  const long = (z.text || '').length;
  azCloseAll();
  openDesign(t, { main: z.text, sub: z.source || '', name: '' },
    { main: { anim: 'words', scale: long > 90 ? 0.72 : long > 50 ? 0.86 : 1 }, sub: { anim: 'fade' } },
    { motion: true, azkar: true, size: 'story', bgAnim: 'stars', dur: long > 90 ? 12 : 8 });
}

/* ================= المسبحة (محفوظة في الخزنة المشفّرة) ================= */
const AZ_TASBIH = [['سُبْحَانَ اللهِ', 33], ['الحَمْدُ للهِ', 33], ['اللهُ أَكْبَرُ', 34], ['لَا إِلَهَ إِلَّا اللهُ', 100], ['أَسْتَغْفِرُ اللهَ', 100], ['اللَّهُمَّ صَلِّ عَلَى مُحَمَّدٍ', 100]];
function azTasbih() { const t = S.vault?.tasbih || {}, d = azDay(); return { day: t.day || '', today: t.day === d ? t.today || 0 : 0, total: t.total || 0, sel: t.sel || 0, n: t.day === d ? t.n || 0 : 0 }; }
let azSaveT = 0, azPend = null;
function azTasbihAdd(k = 1, patch = {}) {
  const t = azTasbih();
  azPend = { ...t, day: azDay(), today: t.today + k, total: t.total + k, ...patch };
  S.vault.tasbih = azPend;
  clearTimeout(azSaveT);
  azSaveT = setTimeout(() => { const v = azPend; azPend = null; commit((x) => { x.tasbih = v; }).then(() => { if (typeof markActive === 'function') markActive('azkar'); }).catch(() => {}); }, 900);
}
/* أيام نور: ذكر أو ورد في اليوم */
function azNur() { const n = S.vault?.nur || {}; return { days: Array.isArray(n.days) ? n.days : [] }; }
function azNurMark() {
  const d = azDay(), n = azNur(); if (n.days.includes(d)) return;
  const days = [...n.days, d].slice(-60);
  S.vault.nur = { days };
  commit((x) => { x.nur = { days }; }).catch(() => {});
}
function azStreak() {
  const set = new Set(azNur().days); let s = 0; const d = new Date();
  for (let i = 0; i < 400; i++) { const k = new Date(d.getTime() - i * 864e5 - d.getTimezoneOffset() * 6e4).toISOString().slice(0, 10); if (set.has(k)) s++; else if (i > 0) break; }
  return s;
}

/* ================= المصحف: البيانات ================= */
const QR = { data: null, p: null, norm: null };
async function quran() {
  if (QR.data) return QR.data;
  if (!QR.p) QR.p = fetch('data/quran.json').then((r) => r.json()).then((j) => (QR.data = j.s)).catch((e) => { QR.p = null; throw e; });
  return QR.p;
}
const JUZ = [[1, 1], [2, 142], [2, 253], [3, 93], [4, 24], [4, 148], [5, 82], [6, 111], [7, 88], [8, 41], [9, 93], [11, 6], [12, 53], [15, 1], [17, 1], [18, 75], [21, 1], [23, 1], [25, 21], [27, 56], [29, 46], [33, 31], [36, 28], [39, 32], [41, 47], [46, 1], [51, 31], [58, 1], [67, 1], [78, 1]];
const juzOf = (s, a = 1) => { let j = 1; JUZ.forEach(([ss, aa], i) => { if (s > ss || (s === ss && a >= aa)) j = i + 1; }); return j; };
const qNorm = (s) => String(s).replace(/\u00a0/g, ' ').replace(/[ؐ-ًؚ-ٰٟۖ-ۭـ]/g, '').replace(/[ٱأإآ]/g, 'ا').replace(/ى/g, 'ي').replace(/ة/g, 'ه').replace(/ؤ/g, 'و').replace(/ئ/g, 'ي');
/* إعدادات وتقدّم القراءة (في الخزنة المشفّرة) */
const QV_DEF = { bm: [], last: [], kh: null, theme: 'dark', fs: 25, font: 'hafs' };
const qv = () => ({ ...QV_DEF, ...(S.vault?.quran || {}) });
function qSave(patch) { const v = { ...qv(), ...patch }; S.vault.quran = v; clearTimeout(qSave.t); qSave.t = setTimeout(() => commit((x) => { x.quran = S.vault.quran; }).catch(() => {}), 700); }
const QFONTS = [['hafs', 'مصحف المدينة — حفص', 'خط مجمع الملك فهد الرسمي', 'QHafs', 'm_f_hafs'], ['amiri', 'أميري', 'مفتوح المصدر', 'QAmiri', 'm_f_amiri']];
function qFont() { const ok = QFONTS.filter((f) => azOn(f[4])); const v = qv().font; return (ok.find((f) => f[0] === v) || ok[0] || QFONTS[0]); }
/* ترتيب الآية في المصحف (لحساب الختمة) */
let QIDX = null;
function qIndex(data) { if (QIDX) return QIDX; QIDX = []; let n = 0; data.forEach((s) => { QIDX.push(n); n += s[2].length; }); QIDX.total = n; return QIDX; }

/* ================= المواقيت ================= */
const CITIES = [['الرياض', 24.7136, 46.6753], ['جدة', 21.4858, 39.1925], ['مكة المكرمة', 21.4225, 39.8262], ['المدينة المنورة', 24.4686, 39.6142], ['الدمام', 26.4207, 50.0888], ['الخبر', 26.2172, 50.1971], ['الطائف', 21.2703, 40.4158], ['أبها', 18.2164, 42.5053], ['خميس مشيط', 18.3060, 42.7297], ['تبوك', 28.3835, 36.5662], ['بريدة', 26.3592, 43.9818], ['حائل', 27.5114, 41.7208], ['جازان', 16.8892, 42.5511], ['نجران', 17.4924, 44.1277], ['الأحساء', 25.3833, 49.5864], ['ينبع', 24.0895, 38.0618], ['الجبيل', 27.0046, 49.6460], ['الباحة', 20.0129, 41.4677], ['سكاكا', 29.9697, 40.2064], ['عرعر', 30.9753, 41.0381]];
const PRAY = [['الفجر', 'fajr', 'p_fajr'], ['الشروق', 'sunrise', 'p_sunrise'], ['الظهر', 'dhuhr', 'p_dhuhr'], ['العصر', 'asr', 'p_asr'], ['المغرب', 'maghrib', 'p_maghrib'], ['العشاء', 'isha', 'p_isha']];
const pv = () => ({ name: '', lat: 0, lng: 0, bells: [1, 0, 1, 1, 1, 1], pre: 0, ...(S.vault?.prayer || {}) });
function pSave(patch) { const v = { ...pv(), ...patch }; S.vault.prayer = v; commit((x) => { x.prayer = v; }).catch(() => {}); azAdhanSchedule(); }
const pLoc = () => { const p = pv(); return p.lat ? p : { name: 'مكة المكرمة', lat: 21.4225, lng: 39.8262, guess: true }; };
function pTimes(d = new Date()) {
  if (typeof adhan === 'undefined') return null;
  const L = pLoc();
  try { return new adhan.PrayerTimes(new adhan.Coordinates(L.lat, L.lng), d, adhan.CalculationMethod.UmmAlQura()); } catch { return null; }
}
function pCurNext(d = new Date()) {
  const t = pTimes(d); if (!t) return null;
  const list = PRAY.map(([n, k, id]) => [n, k, t[k], id]);
  let cur = null, nxt = null;
  for (const x of list) { if (x[2] <= d) cur = x; else if (!nxt) nxt = x; }
  if (!nxt) { const tm = pTimes(new Date(d.getTime() + 864e5)); nxt = ['الفجر', 'fajr', tm.fajr, 'p_fajr']; }
  if (!cur) { const y = pTimes(new Date(d.getTime() - 864e5)); cur = ['العشاء', 'isha', y.isha, 'p_isha']; }
  return { t, list, cur, nxt };
}
const hm = (d) => { let hh = d.getHours(); const m = d.getMinutes(), ap = hh >= 12 ? 'م' : 'ص'; hh = hh % 12 || 12; return `${String(hh).padStart(2, '0')}:${String(m).padStart(2, '0')} ${ap}`; };
const dur = (ms) => { ms = Math.max(0, ms); const H = Math.floor(ms / 36e5), M = Math.floor(ms / 6e4) % 60, s = Math.floor(ms / 1e3) % 60; return H ? `${H}:${String(M).padStart(2, '0')}:${String(s).padStart(2, '0')}` : `${String(M).padStart(2, '0')}:${String(s).padStart(2, '0')}`; };
const HM = ['محرم', 'صفر', 'ربيع الأول', 'ربيع الآخر', 'جمادى الأولى', 'جمادى الآخرة', 'رجب', 'شعبان', 'رمضان', 'شوال', 'ذو القعدة', 'ذو الحجة'];
const GM = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
const WD = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
/* تنبيهات الأذان: إشعارات محلية لسبعة أيام قدّام (تتجدد مع كل فتح) */
async function azAdhanSchedule() {
  const LN = Platform.plugin('LocalNotifications');
  if (!LN || !S.vault) return;
  const p = pv(), ids = [];
  for (let d = 0; d < 7; d++) for (let i = 0; i < 6; i++) ids.push({ id: 771000 + d * 10 + i });
  try {
    await LN.cancel({ notifications: ids }).catch(() => {});
    if (!p.lat || !azOn('s_adhan') || !p.bells.some((x, i) => x && i !== 1)) return;
    const list = [], now = Date.now();
    for (let d = 0; d < 7; d++) {
      const t = pTimes(new Date(now + d * 864e5)); if (!t) continue;
      PRAY.forEach(([n, k], i) => { if (!p.bells[i] || i === 1) return; const at = new Date(t[k].getTime() - (Number(p.pre) || 0) * 6e4); if (at.getTime() < now + 30e3) return;
        list.push({ id: 771000 + d * 10 + i, title: `🕌 ${p.pre ? `بعد ${UI.n(p.pre)} د: ` : ''}أذان ${n}`, body: p.pre ? `اقترب وقت صلاة ${n}` : `حان الآن وقت صلاة ${n}`, schedule: { at, allowWhileIdle: true }, extra: { tab: 'azkar' }, smallIcon: 'ic_stat_nobleweb' }); });
    }
    if (list.length) await LN.schedule({ notifications: list });
  } catch { /* لا شيء */ }
}

/* ================= السياق الذكي حسب الوقت ================= */
function azContext(d = new Date()) {
  const pc = pCurNext(d); const t = pc?.t;
  if (d.getDay() === 5 && (!t || d < t.maghrib)) return { k: 'kahf', em: '🕌', b: 'اليوم جمعة — اقرأ سورة الكهف', s: 'وأكثِر من الصلاة على النبي ﷺ', btn: 'ابدأ الكهف', go: () => qOpen(18) };
  if (t && d >= t.fajr && d < t.dhuhr && azOn('a_morning')) return { k: 'm', em: '☀️', b: 'وقت أذكار الصباح', s: 'دقيقتين تحصّن بها يومك', btn: 'ابدأ', go: () => azSession('صباح') };
  if (t && d >= t.asr && d < t.isha && azOn('a_evening')) return { k: 'e', em: '🌇', b: 'وقت أذكار المساء', s: 'من العصر إلى المغرب وما بعده', btn: 'ابدأ', go: () => azSession('مساء') };
  if (t && (d >= new Date(t.isha.getTime() + 60 * 6e4) || d < t.fajr) && azOn('a_sleep')) return { k: 'n', em: '🌙', b: 'أذكار النوم', s: 'قبل ما تنام، خذ دقيقة', btn: 'ابدأ', go: () => azSession('نوم') };
  return { k: 'w', em: '📖', b: 'وردك اليومي من القرآن', s: 'كمّل من حيث وقفت', btn: 'أكمل', go: () => { const l = qv().last[0]; qOpen(l ? l[0] : 1, l ? l[1] : 1); } };
}

/* ================= القسم ================= */
async function renderAzkar() {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  const root = $('#az-root');
  if (!root || !S.vault) return;
  if (!AZ.items) { const c = azCache(); if (c) { AZ.items = c.items || []; AZ.meta = c.meta || {}; } }
  paintAzkar(root);
  const before = JSON.stringify([AZ.items, AZ.meta]);
  await loadAzkar();
  if (JSON.stringify([AZ.items, AZ.meta]) !== before && S.tab === 'azkar') paintAzkar(root);
  quran().then(() => { if (S.tab === 'azkar' && (AZ.tab === 'today' || AZ.tab === 'mushaf') && !root.querySelector('.qr-ready')) paintAzkar(root); }).catch(() => {});
}
const AZ_TABS = [['today', 't_today'], ['mushaf', 't_mushaf'], ['azkar', 't_azkar'], ['services', 't_svc']];
function azTabs() { return AZ_TABS.filter(([k]) => azOn(k)); }
function paintAzkar(root = $('#az-root')) {
  if (!root) return;
  const C = AzkarKit.ctlCfg(AZ.meta || {}), I = azIcfg();
  root.classList.toggle('az-nolbl', I.labels === false);
  if (!C.on) return RC(root, azHead(), h('div', { class: 'az-maint' }, h('div', { text: '🛠️' }), h('p', { text: C.msg || 'القسم تحت التحديث' })));
  const tabs = azTabs();
  if (!tabs.length) return RC(root, azHead(), h('div', { class: 'az-maint' }, h('div', { text: '🙈' }), h('p', { text: 'ما فيه شي ظاهر هنا حالياً' })));
  if (!tabs.some(([k]) => k === AZ.tab)) { const want = lsG('nw:az-tab') || C.defTab; AZ.tab = tabs.some(([k]) => k === want) ? want : tabs.some(([k]) => k === C.defTab) ? C.defTab : tabs[0][0]; }
  const seg = h('nav', { class: `az-seg n${tabs.length}`, role: 'tablist' }, ...tabs.map(([k, id]) => { const it = azItem(id); return h('button', { type: 'button', role: 'tab', class: AZ.tab === k ? 'on' : '', onclick: () => { AZ.tab = k; lsS('nw:az-tab', k); paintAzkar(root); window.scrollTo({ top: 0 }); } }, azIc(id, { z: 30, cls: 'seg-ic' }), h('span', { text: it.n })); }));
  const body = h('div', { class: 'az-body' });
  RC(root, azHead(), seg, body);
  try {
    if (AZ.tab === 'today') paintToday(body);
    else if (AZ.tab === 'mushaf') paintMushaf(body);
    else if (AZ.tab === 'azkar') paintAzTab(body);
    else paintServices(body);
  } catch (e) { console.error(e); body.append(h('p', { class: 'note-box', text: 'تعذّر عرض هذا الجزء: ' + e.message })); }
  UI.digitize(root);
}
function azHead() {
  return h('div', { class: 'az-top' }, h('h1', { class: 'view-title', text: azCfg().title || 'أذكاري' }),
    h('div', { class: 'az-top-a' },
      azOn('m_search') && azOn('mushaf') ? h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'بحث في القرآن', onclick: () => { AZ.tab = 'mushaf'; AZ.m = 'index'; paintAzkar(); setTimeout(() => $('#qr-q')?.focus(), 80); } }, icon('search', { size: 19 })) : null,
      azOn('m_bm') && azOn('mushaf') ? h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'العلامات', onclick: () => { AZ.tab = 'mushaf'; AZ.m = 'reads'; paintAzkar(); setTimeout(() => $('#qr-bms')?.scrollIntoView({ behavior: 'smooth', block: 'center' }), 80); } }, icon('tag', { size: 19 })) : null,
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إعدادات أذكاري', onclick: azSettings }, icon('settings', { size: 19 }))));
}
const azShareBtns = (text, src) => {
  const out = [];
  if (azOn('g_story')) out.push(h('button', { type: 'button', class: 'az-mini', title: 'صمّمها حالة', onclick: () => azToStory({ text, source: src, cat: 'آية' }) }, '🎨'));
  if (azOn('g_share')) {
    out.push(h('button', { type: 'button', class: 'az-mini', title: 'نسخ', onclick: () => azCopy(`${text}\n${src || ''}`) }, '📋'));
    out.push(h('button', { type: 'button', class: 'az-mini', title: 'مشاركة', onclick: () => azShare(`${text}\n${src ? '— ' + src : ''}\n\nمن تطبيق NOBLE`) }, '↗'));
  }
  return out;
};
async function azCopy(t) { try { await navigator.clipboard.writeText(t); toast('نُسخ ✓', { type: 'success' }); } catch { toast(t); } }
async function azShare(text) {
  if (Platform.isNative) { try { await Platform.plugin('Share').share({ text, dialogTitle: 'شارك' }); } catch { /* أُلغيت */ } return; }
  if (navigator.share) { try { await navigator.share({ text }); } catch { /* أُلغيت */ } return; }
  azCopy(text);
}

/* ---------------- اليوم ---------------- */
const AYAT = [[2, 186], [2, 152], [13, 28], [94, 5], [39, 53], [65, 3], [2, 286], [3, 8], [20, 114], [40, 60], [29, 69], [93, 5], [3, 139], [12, 87], [8, 46], [28, 24]];
let azTick = 0;
function paintToday(body) {
  const d = new Date(), hj = AzkarKit.hijri(d), pc = pCurNext(d), c = azContext(d), all = azAll(), name = (S.profile?.display_name || '').split(' ')[0];
  const greet = d.getHours() < 12 ? `صباح الخير${name ? ' يا ' + name : ''} ☀️` : `مساء النور${name ? ' يا ' + name : ''} 🌙`;
  const q = QR.data;
  if (q) body.classList.add('qr-ready');
  const parts = [];
  if (azOn('t_hero')) parts.push(h('section', { class: 'az-hero2' },
    h('div', {}, h('div', { class: 'greet', text: greet }), h('div', { class: 'big', text: d.getDay() === 5 ? 'صلِّ على النبي ﷺ' : 'اذكر الله يذكرك' }),
      azOn('t_ctx') ? h('button', { type: 'button', class: 'az-cta', onclick: c.go }, `${c.em} ${c.k === 'kahf' ? 'اقرأ سورة الكهف' : c.b}`) : null,
      pc && azOn('t_pt') ? h('div', { class: 'az-nextp' }, `🕌 ${pc.nxt[0]} بعد: `, h('span', { class: 'az-pill num', id: 'az-cd', text: dur(pc.nxt[2] - d) })) : null),
    h('div', { class: 'az-day' }, h('div', { class: 'dn', text: WD[d.getDay()] }),
      h('div', { class: 'dd' }, h('div', {}, HM[hj.m - 1] || '', h('b', { class: 'num', text: AR(hj.d) })), h('div', {}, GM[d.getMonth()], h('b', { class: 'num', text: AR(d.getDate()) }))),
      h('div', { class: 'dd yy' }, h('b', { class: 'num', text: AR(hj.y) }), h('b', { class: 'num', text: AR(d.getFullYear()) })))));
  if (pc && azOn('t_pt') && azOn('services')) {
    parts.push(h('div', { class: 'az-h2' }, h('b', { text: 'مواقيت الصلاة' }), h('button', { type: 'button', class: 'link-btn', onclick: () => azCity() }, `📍 ${pLoc().name}${pLoc().guess ? ' (اختر مدينتك)' : ''}`)));
    parts.push(h('div', { class: 'az-pt' }, ...pc.list.map(([n, k, t, id]) => k === pc.cur[1]
      ? h('div', { class: 'p cur' }, h('div', {}, azIc(id, { z: 24, cls: 'bare', noBadge: true }), h('small', { text: n }), h('b', { class: 'num', text: hm(t) })), h('div', { class: 'el' }, 'مضى على الأذان', h('b', { class: 'num', id: 'az-el', text: dur(d - pc.cur[2]) })))
      : h('div', { class: `p${k === pc.nxt[1] ? ' nx' : ''}` }, azIc(id, { z: 24, cls: 'bare', noBadge: true }), h('small', { text: n }), h('b', { class: 'num', text: hm(t) })))));
  }
  if (azOn('t_ctx') && c.k !== 'kahf') parts.push(h('section', { class: 'az-ctx' }, h('div', { class: 'em', text: c.em }), h('div', {}, h('b', { text: c.b }), h('small', { text: c.s })), h('button', { type: 'button', class: 'btn btn-primary', onclick: c.go }, c.btn)));
  if (azOn('t_cont') && azOn('mushaf')) {
    const l = qv().last[0], kh = qKh();
    parts.push(h('section', { class: 'az-cont', onclick: () => qOpen(l ? l[0] : 1, l ? l[1] : 1) }, h('div', { class: 'qicon', text: 'القرآن الكريم' }),
      h('div', {}, h('b', { text: l ? 'متابعة القراءة من حيث توقفت' : 'ابدأ القراءة' }), h('small', { text: l && q ? `سورة ${q[l[0] - 1][0]} · آية ${AR(l[1])}` : 'المصحف كامل — يشتغل بدون نت' }),
        kh ? h('div', { class: 'az-bar' }, h('i', { style: { width: kh.pct + '%' } })) : null),
      h('span', { class: 'az-chev' }, icon('chevL', { size: 16 }))));
  }
  if (azOn('t_streak')) {
    const st = azStreak(), set = new Set(azNur().days), wk = [];
    for (let i = 6; i >= 0; i--) { const x = new Date(d.getTime() - i * 864e5); wk.push([['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'][x.getDay()], set.has(new Date(x.getTime() - x.getTimezoneOffset() * 6e4).toISOString().slice(0, 10))]); }
    parts.push(h('section', { class: 'az-streak' }, h('div', { class: 'fl', text: '🔥' }),
      h('div', {}, h('b', { text: st ? `${AR(st)} ${st === 1 ? 'يوم نور' : 'أيام نور متواصلة'}` : 'ابدأ أيام النور' }), h('small', { text: 'ذكر أو ورد كل يوم = يوم نور' }),
        h('div', { class: 'wk' }, ...wk.map(([l, on]) => h('span', { class: on ? 'on' : '', text: l }))))));
  }
  if (azOn('t_ayah') && q) { const [s, a] = AYAT[AzkarKit.dayNum() % AYAT.length], t = q[s - 1][2][a - 1];
    parts.push(h('div', { class: 'az-h2' }, h('b', { text: 'زادك اليوم' })));
    parts.push(h('section', { class: 'az-dly' }, h('div', { class: 'k' }, h('span', { class: 'az-tag', text: '📖 آية اليوم' }), h('div', { class: 'acts' }, ...azShareBtns(t, `﴿${q[s - 1][0]} ${a}﴾`))),
      h('p', { class: 'qt', style: { fontFamily: `${qFont()[3]}, QAmiri, serif` }, text: t, onclick: () => qOpen(s, a) }), h('small', { text: `سورة ${q[s - 1][0]} · آية ${AR(a)}` }))); }
  const z0 = AzkarKit.today(all);
  if (azOn('t_zikr') && z0) parts.push(h('section', { class: 'az-dly' }, h('div', { class: 'k' }, h('span', { class: 'az-tag g', text: `🤲 ذكر اليوم · ${z0.cat || ''}` }), h('div', { class: 'acts' }, ...azShareBtns(z0.text, z0.source))),
    h('p', { class: 't', text: z0.text }), z0.virtue ? h('small', { class: 'v', text: z0.virtue }) : null, h('small', { class: 'src', text: z0.source || '' })));
  if (azOn('t_hadith')) { const hd = azHadith(all); if (hd) parts.push(h('section', { class: 'az-dly' }, h('div', { class: 'k' }, h('span', { class: 'az-tag v', text: '📜 حديث اليوم' }), h('div', { class: 'acts' }, ...azShareBtns(hd.text, hd.source))),
    h('p', { class: 't h', text: hd.text }), h('small', { class: 'src', text: hd.source || '' }))); }
  RC(body, ...parts);
  clearInterval(azTick);
  azTick = setInterval(() => { if (S.tab !== 'azkar' || AZ.tab !== 'today') return clearInterval(azTick); const n = new Date(), p = pCurNext(n); if (!p) return; const a = $('#az-cd'), b = $('#az-el'); if (a) a.textContent = UI.n(dur(p.nxt[2] - n)); if (b) b.textContent = UI.n(dur(n - p.cur[2])); }, 1000);
}
/* حديث اليوم: من الأحاديث اللي تضيفها الإدارة (تصنيف «حديث»)، وإلا فضل ذكر صحيح */
function azHadith(all) {
  const hs = all.filter((z) => z.cat === 'حديث');
  if (hs.length) return hs[(AzkarKit.dayNum() * 3) % hs.length];
  const vs = all.filter((z) => z.virtue && /«/.test(z.virtue));
  if (!vs.length) return null;
  const z = vs[(AzkarKit.dayNum() * 5 + 1) % vs.length];
  return { text: z.virtue.replace(/^«|»$/g, ''), source: z.source };
}

/* ---------------- المصحف ---------------- */
function qKh() {
  const k = qv().kh; if (!k || !QR.data) return null;
  const I = qIndex(QR.data), total = I.total, pos = Math.min(total, k.pos || 0);
  const days = Number(k.days) || 30, day = Math.min(days, Math.floor((Date.now() - new Date(k.start).getTime()) / 864e5) + 1);
  const per = Math.ceil(total / days), today = k.dayDate === azDay() ? pos - (k.dayPos || 0) : 0;
  const leftDays = Math.max(1, days - day + 1), perNow = Math.ceil((total - (k.dayDate === azDay() ? k.dayPos || 0 : pos)) / leftDays);
  return { days, day, pos, total, pct: Math.round(pos / total * 100), per, perNow, today, done: pos >= total };
}
function qKhMark(s, a) {
  const k = qv().kh; if (!k || !QR.data) return;
  const I = qIndex(QR.data), pos = I[s - 1] + a;
  const nk = { ...k, pos: Math.max(k.pos || 0, pos) };
  if (nk.dayDate !== azDay()) { nk.dayDate = azDay(); nk.dayPos = k.pos || 0; }
  qSave({ kh: nk }); azNurMark();
}
function paintMushaf(body) {
  const q = QR.data;
  if (!q) { RC(body, h('div', { class: 'az-load' }, h('span', { class: 'spin' }), h('p', { text: 'يجهّز المصحف…' }))); quran().then(() => paintAzkar()).catch(() => RC(body, h('p', { class: 'note-box', text: 'تعذّر تحميل المصحف — حدّث الصفحة' }))); return; }
  body.classList.add('qr-ready');
  const showReads = azOn('m_reads') || azOn('m_khatma') || azOn('m_bm'), showIdx = azOn('m_index') || azOn('m_search');
  if (!showReads) AZ.m = 'index'; if (!showIdx) AZ.m = 'reads';
  const sub = showReads && showIdx ? h('div', { class: 'az-sub' }, h('button', { type: 'button', class: AZ.m === 'reads' ? 'on' : '', onclick: () => { AZ.m = 'reads'; paintAzkar(); } }, 'قراءاتي'), h('button', { type: 'button', class: AZ.m === 'index' ? 'on' : '', onclick: () => { AZ.m = 'index'; paintAzkar(); } }, 'الفهرس')) : null;
  if (AZ.m === 'reads') {
    const v = qv(), kh = qKh(), parts = [sub];
    if (azOn('m_khatma')) {
      parts.push(h('div', { class: 'az-h2' }, h('b', { text: 'ختمتي' }), h('button', { type: 'button', class: 'link-btn', onclick: qKhSheet }, kh ? 'تعديل الخطة ‹' : '')));
      parts.push(kh ? h('section', { class: 'qr-kh' }, h('div', { class: 'ring', style: { '--p': kh.pct + '%' } }, h('b', { class: 'num', text: `${AR(kh.pct)}٪` })),
        h('div', {}, h('b', { text: kh.done ? 'أتممت الختمة 🎉 تقبّل الله' : `ختمة ${AR(kh.days)} يوم 🤍` }), h('small', { text: `اليوم ${AR(kh.day)} من ${AR(kh.days)} · وردك اليوم ${AR(kh.perNow)} آية` }),
          h('div', { class: 'az-bar' }, h('i', { style: { width: Math.min(100, Math.round(kh.today / Math.max(1, kh.perNow) * 100)) + '%' } })), h('small', { text: `قرأت ${AR(Math.max(0, kh.today))} من ${AR(kh.perNow)} آية اليوم` }),
          h('div', { class: 'row' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => { const I = qIndex(q); let s = 1; while (s < 114 && I[s] < kh.pos) s++; qOpen(s, Math.max(1, kh.pos - I[s - 1])); } }, 'أكمل وردي'))))
        : h('section', { class: 'qr-kh empty' }, h('div', { text: '🎯' }), h('div', {}, h('b', { text: 'ابدأ ختمة بخطة' }), h('small', { text: 'اختر المدة ونوزّع لك الورد اليومي، ونذكّرك فيه' }), h('button', { type: 'button', class: 'btn btn-primary', onclick: qKhSheet }, 'ابدأ ختمة'))));
    }
    if (azOn('m_reads')) {
      parts.push(h('div', { class: 'az-h2' }, h('b', { text: 'آخر قراءاتي' })));
      parts.push(v.last.length ? h('div', { class: 'qr-lst' }, ...v.last.map(([s, a, t]) => h('button', { type: 'button', class: 'li', onclick: () => qOpen(s, a) }, h('span', { class: 'ci', text: '🕘' }), h('span', {}, h('b', { text: q[s - 1][0] }), h('small', { text: `${UI.relTime(t)} · آية ${AR(a)}` })), h('span', { class: 'pg', text: `الجزء ${AR(juzOf(s, a))}` }))))
        : h('p', { class: 'az-empty', text: 'افتح أي سورة من الفهرس — تظهر هنا آخر قراءاتك' }));
    }
    if (azOn('m_bm')) {
      parts.push(h('div', { class: 'az-h2', id: 'qr-bms' }, h('b', { text: 'علاماتي 🔖' })));
      parts.push(v.bm.length ? h('div', { class: 'qr-lst' }, ...v.bm.map(([s, a]) => h('button', { type: 'button', class: 'li', onclick: () => qOpen(s, a) }, h('span', { class: 'ci', text: '🔖' }), h('span', {}, h('b', { text: `${q[s - 1][0]} · ${AR(a)}` }), h('small', { class: 'qf', text: q[s - 1][2][a - 1].slice(0, 60) + '…' })), h('span', { class: 'pg' }, icon('chevL', { size: 15 })))))
        : h('p', { class: 'az-empty', text: 'اضغط على أي آية وأنت تقرأ واختر 🔖 — تظهر هنا' }));
    }
    RC(body, ...parts); return;
  }
  const qq = AZ.q || '';
  const inp = h('input', { class: 'input', id: 'qr-q', type: 'search', placeholder: 'ابحث عن سورة أو كلمة في القرآن', value: qq, autocomplete: 'off' });
  inp.addEventListener('input', () => { AZ.q = inp.value; clearTimeout(inp._t); inp._t = setTimeout(() => { paintQList(list); }, 250); });
  const list = h('div', { class: 'qr-idx' });
  const tools = h('div', { class: 'qr-tools' }, azOn('m_search') ? h('span', { class: 'qr-srch' }, inp) : h('span'),
    azOn('m_index') ? h('button', { type: 'button', class: 'qr-tgl', onclick: () => { AZ.idx = AZ.idx === 'surah' ? 'juz' : 'surah'; paintQList(list); tgl.textContent = `العرض: ${AZ.idx === 'surah' ? 'السور' : 'الأجزاء'} ⇅`; } }, `العرض: ${AZ.idx === 'surah' ? 'السور' : 'الأجزاء'} ⇅`) : null);
  const tgl = tools.querySelector('.qr-tgl');
  const bar = h('div', { class: 'qr-jzbar' }, ...JUZ.map((_, j) => h('span', { 'data-j': j + 1, text: String(j + 1) })));
  RC(body, sub, tools, h('div', { class: 'qr-wrap' }, azOn('m_index') ? bar : null, list));
  if (azOn('m_search') && typeof Voice !== 'undefined') Voice.attach(inp, 'azkar');
  paintQList(list);
  const pick = (e) => { const t = document.elementFromPoint(e.clientX, e.clientY); const j = t?.dataset?.j; if (!j) return; bar.querySelectorAll('span').forEach((x) => x.classList.toggle('on', x.dataset.j === j)); const [s] = JUZ[j - 1]; const el = AZ.idx === 'juz' ? $('#qr-jz' + j) : $('#qr-su' + s); if (el) { window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY - 140 }); } };
  bar.addEventListener('pointerdown', (e) => { bar.setPointerCapture(e.pointerId); pick(e); bar.onpointermove = pick; });
  bar.addEventListener('pointerup', () => { bar.onpointermove = null; setTimeout(() => bar.querySelectorAll('span').forEach((x) => x.classList.remove('on')), 500); });
}
function qSu(i, from = 1) {
  const s = QR.data[i];
  return h('button', { type: 'button', class: 'qr-su', id: from === 1 ? 'qr-su' + (i + 1) : null, onclick: () => qOpen(i + 1, from) },
    h('span', { class: 'n num', text: AR(i + 1) }), h('span', {}, h('span', { class: 'nm', text: `سُورَةُ ${s[0]}` }), h('small', { text: `${s[1] ? 'مكية' : 'مدنية'} · الجزء ${AR(juzOf(i + 1, from))}${from > 1 ? ` · من آية ${AR(from)}` : ''}` })),
    h('span', { class: 'ay num', text: `${AR(s[2].length)} آية` }));
}
function paintQList(list) {
  const q = QR.data, qq = (AZ.q || '').trim();
  if (qq.length >= 2) {
    const nq = qNorm(qq);
    const su = q.map((s, i) => [s, i]).filter(([s]) => qNorm(s[0]).includes(nq)).map(([, i]) => qSu(i));
    QR.norm = QR.norm || q.map((s) => s[2].map(qNorm));
    const hits = []; for (let s = 0; s < 114 && hits.length < 40; s++) for (let a = 0; a < QR.norm[s].length && hits.length < 40; a++) if (QR.norm[s][a].includes(nq)) hits.push([s + 1, a + 1]);
    RC(list, ...su, hits.length ? h('div', { class: 'qr-jh', text: `في الآيات (${AR(hits.length)}${hits.length === 40 ? '+' : ''})` }) : null,
      ...hits.map(([s, a]) => h('button', { type: 'button', class: 'qr-hit', onclick: () => qOpen(s, a) }, h('div', { class: 'qf', text: q[s - 1][2][a - 1] }), h('small', { text: `${q[s - 1][0]} · ${AR(a)}` }))),
      !su.length && !hits.length ? h('p', { class: 'az-empty', text: 'ما لقينا نتائج — جرّب كلمة ثانية (البحث بكتابة المصحف)' }) : null);
  } else if (AZ.idx === 'juz') {
    RC(list, ...JUZ.flatMap(([s, a], j) => [h('div', { class: 'qr-jh', id: 'qr-jz' + (j + 1), text: `الجزء ${AR(j + 1)} · يبدأ من ${q[s - 1][0]} ${AR(a)}` }), a > 1 ? qSu(s - 1, a) : null, ...q.map((x, i) => (juzOf(i + 1, 1) === j + 1 && !(a > 1 && i + 1 === s) ? qSu(i) : null))]));
  } else RC(list, ...q.map((_, i) => qSu(i)));
  UI.digitize(list);
  list.querySelectorAll('.qf, .nm').forEach((e) => (e.style.fontFamily = `${qFont()[3]}, QAmiri, serif`));
}
/* ---------- القارئ ---------- */
let QRD = null;
const BANNER = (n) => `<svg class="qr-banner" viewBox="0 0 360 64" aria-hidden="true"><defs><linearGradient id="qrbg" x1="0" x2="1"><stop offset="0" stop-color="#F2D184"/><stop offset=".5" stop-color="#2FD6AE"/><stop offset="1" stop-color="#F2D184"/></linearGradient></defs><g fill="none" stroke="url(#qrbg)" stroke-width="1.4"><path d="M60 8h240M60 56h240"/><path d="M60 14h240M60 50h240" stroke-opacity=".4"/><path d="M96 32c0-10 10-16 18-16h132c8 0 18 6 18 16s-10 16-18 16H114c-8 0-18-6-18-16z" fill="rgb(47 214 174 / .12)"/><path d="M60 8C40 8 28 20 28 32s12 24 32 24M300 8c20 0 32 12 32 24s-12 24-32 24"/><circle cx="18" cy="32" r="4"/><circle cx="342" cy="32" r="4"/><path d="M74 32l8-8 8 8-8 8zM270 32l8-8 8 8-8 8z"/></g></svg><div class="qr-bname">سُورَةُ ${n}</div>`;
async function qOpen(s, a = 1) {
  if (!azOn('mushaf')) return toast('المصحف غير متاح حالياً');
  const q = await quran().catch(() => null);
  if (!q) return toast('تعذّر تحميل المصحف', { type: 'error' });
  s = Math.min(114, Math.max(1, s)); a = Math.min(q[s - 1][2].length, Math.max(1, a));
  if (!QRD) {
    QRD = h('div', { class: 'qr-rd', role: 'dialog', 'aria-label': 'المصحف' });
    document.body.append(QRD);
  }
  const v = qv(), F = qFont();
  QRD.className = `qr-rd on th-${v.theme}`; QRD.style.setProperty('--fs', v.fs + 'px'); QRD.style.setProperty('--qf', F[3]);
  QRD.dataset.s = s;
  const bm = new Set(v.bm.filter((x) => x[0] === s).map((x) => x[1]));
  const txt = h('p', { class: 'qr-qt' });
  txt.innerHTML = q[s - 1][2].map((t, i) => `<span class="a${bm.has(i + 1) ? ' bm' : ''}" data-a="${i + 1}">${t.replace(/[&<>]/g, '')} ${F[0] === 'hafs' ? `<span class="anh">${UI.n(i + 1).replace(/\d/g, (x) => '٠١٢٣٤٥٦٧٨٩'[x])}</span>` : `<span class="an">${UI.n(i + 1)}</span>`}</span> `).join('');
  const head = h('div', { class: 'qr-h' }, h('button', { type: 'button', 'aria-label': 'رجوع', onclick: qClose }, icon('chevR', { size: 20 })),
    h('span', { class: 'jz num', text: `الجزء ${AR(juzOf(s, a))}` }), h('span', { class: 'sp' }), h('span', { class: 'sn', text: `سُورَةُ ${q[s - 1][0]}` }),
    h('button', { type: 'button', 'aria-label': 'إعدادات القراءة', onclick: qSettings }, icon('sliders', { size: 18 })));
  const bodyEl = h('div', { class: 'qr-b' });
  const ban = h('div', { class: 'qr-ban' }); ban.innerHTML = BANNER(q[s - 1][0]);
  bodyEl.append(ban, s !== 1 && s !== 9 ? h('div', { class: 'qr-basm', text: 'بِسۡمِ ٱللَّهِ ٱلرَّحۡمَٰنِ ٱلرَّحِيمِ' }) : null, txt,
    h('div', { class: 'qr-nav2' }, s < 114 ? h('button', { type: 'button', onclick: () => qOpen(s + 1) }, `‹ سورة ${q[s][0]}`) : h('span'), s > 1 ? h('button', { type: 'button', onclick: () => qOpen(s - 1) }, `سورة ${q[s - 2][0]} ›`) : null),
    h('p', { class: 'qr-src', text: 'النص العثماني: موسوعة القرآن الكريم · الخط: مجمع الملك فهد لطباعة المصحف الشريف' }));
  const foot = h('div', { class: 'qr-f' }, h('button', { type: 'button', onclick: qSettings }, 'Aa الخط والثيم'),
    qv().kh ? h('button', { type: 'button', onclick: () => { const cur = qCurAyah(); qKhMark(s, cur); toast(`✓ سجّلنا وردك لين آية ${UI.n(cur)} — يوم نور 🔥`, { type: 'success' }); } }, '✓ سجّل وردي') : h('button', { type: 'button', onclick: () => { azNurMark(); toast('✓ يوم نور 🔥', { type: 'success' }); } }, '✓ قرأت'));
  QRD.replaceChildren(head, bodyEl, foot);
  txt.addEventListener('click', (e) => { const el = e.target.closest('.a'); if (el) qAyahSheet(s, +el.dataset.a, el); });
  document.documentElement.classList.add('rd-open');
  requestAnimationFrame(() => { const el = txt.querySelector(`.a[data-a="${a}"]`); bodyEl.scrollTop = a > 1 && el ? el.offsetTop - 120 : 0; if (a > 1 && el) { el.classList.add('sel'); setTimeout(() => el.classList.remove('sel'), 1600); } });
  bodyEl.addEventListener('scroll', () => { clearTimeout(bodyEl._t); bodyEl._t = setTimeout(() => qSaveLast(s, qCurAyah()), 600); }, { passive: true });
  qSaveLast(s, a);
  if (Platform.isNative) { try { Platform.plugin('KeepAwake')?.keepAwake?.(); } catch { /* لا شيء */ } }
}
function qCurAyah() {
  if (!QRD) return 1; const b = QRD.querySelector('.qr-b'), top = b.getBoundingClientRect().top + 80;
  const as = [...QRD.querySelectorAll('.qr-qt .a')]; const f = as.find((x) => x.getBoundingClientRect().bottom > top);
  return f ? +f.dataset.a : 1;
}
function qSaveLast(s, a) { const last = [[s, a, Date.now()], ...qv().last.filter((x) => x[0] !== s)].slice(0, 6); qSave({ last }); }
function qClose() { if (!QRD) return; QRD.classList.remove('on'); document.documentElement.classList.remove('rd-open'); if (S.tab === 'azkar') paintAzkar(); }
function qAyahSheet(s, a, el) {
  QRD.querySelectorAll('.qr-qt .a.sel').forEach((x) => x.classList.remove('sel')); el.classList.add('sel');
  const q = QR.data, t = q[s - 1][2][a - 1], v = qv(), isBm = v.bm.some((x) => x[0] === s && x[1] === a);
  azSheet(`${q[s - 1][0]} · آية ${UI.n(a)}`, [
    h('p', { class: 'qf qr-sheet-t', style: { fontFamily: `${qFont()[3]}, QAmiri, serif` }, text: t }),
    h('div', { class: 'az-acts' },
      azOn('m_bm') ? h('button', { type: 'button', onclick: () => { const bm = isBm ? v.bm.filter((x) => !(x[0] === s && x[1] === a)) : [[s, a], ...v.bm].slice(0, 100); qSave({ bm }); el.classList.toggle('bm', !isBm); azSheetClose(); toast(isBm ? 'شلنا العلامة' : '🔖 حفظنا العلامة'); } }, h('span', { text: '🔖' }), isBm ? 'شيل العلامة' : 'علامة') : null,
      azOn('g_share') ? h('button', { type: 'button', onclick: () => { azCopy(`${t}\n﴿${q[s - 1][0]} ${a}﴾`); azSheetClose(); } }, h('span', { text: '📋' }), 'نسخ') : null,
      azOn('g_share') ? h('button', { type: 'button', onclick: () => { azShare(`${t}\n﴿${q[s - 1][0]} ${a}﴾\n\nمن تطبيق NOBLE`); azSheetClose(); } }, h('span', { text: '↗' }), 'مشاركة') : null,
      azOn('m_story') ? h('button', { type: 'button', onclick: () => { azSheetClose(); azToStory({ text: t, source: `﴿${q[s - 1][0]} ${a}﴾`, cat: 'آية' }); } }, h('span', { text: '🎨' }), 'صمّمها حالة') : null,
      qv().kh ? h('button', { type: 'button', onclick: () => { qKhMark(s, a); azSheetClose(); toast('📍 وصلت هنا في ختمتك', { type: 'success' }); } }, h('span', { text: '📍' }), 'وصلت هنا') : null)], () => el.classList.remove('sel'));
}
function qSettings() {
  const v = qv(), fonts = QFONTS.filter((f) => azOn(f[4]));
  azSheet('إعدادات القراءة', [
    fonts.length > 1 ? h('b', { class: 'az-lbl', text: 'نوع الخط' }) : null,
    fonts.length > 1 ? h('div', { class: 'qr-fopt' }, ...fonts.map(([k, n, d, fam]) => h('button', { type: 'button', class: qFont()[0] === k ? 'on' : '', onclick: () => { qSave({ font: k }); qRefresh(); qSettings(); } }, h('b', { text: n }), h('small', { text: d }), h('span', { class: 'smp', style: { fontFamily: fam }, text: 'ٱلۡحَمۡدُ لِلَّهِ رَبِّ ٱلۡعَٰلَمِينَ' })))) : null,
    h('b', { class: 'az-lbl', text: 'حجم الخط' }),
    h('div', { class: 'chips' }, ...[[21, 'صغير'], [25, 'عادي'], [29, 'كبير'], [34, 'أكبر']].map(([f, n]) => h('button', { type: 'button', class: `chip${v.fs === f ? ' on' : ''}`, onclick: () => { qSave({ fs: f }); QRD?.style.setProperty('--fs', f + 'px'); qSettings(); } }, n))),
    h('b', { class: 'az-lbl', text: 'الثيم' }),
    h('div', { class: 'chips' }, ...[['dark', '🌙 ليلي'], ['sepia', '📜 ورقي'], ['light', '☀️ فاتح']].map(([k, n]) => h('button', { type: 'button', class: `chip${v.theme === k ? ' on' : ''}`, onclick: () => { qSave({ theme: k }); if (QRD) QRD.className = `qr-rd on th-${k}`; qSettings(); } }, n)))]);
}
function qRefresh() { if (QRD?.classList.contains('on')) { const b = QRD.querySelector('.qr-b'), t = b.scrollTop; qOpen(+QRD.dataset.s, qCurAyah()).then(() => { QRD.querySelector('.qr-b').scrollTop = t; }); } }
function qKhSheet() {
  const k = qv().kh;
  azSheet('خطة الختمة', [
    h('p', { class: 'hint', text: 'أختم القرآن خلال:' }),
    h('div', { class: 'qr-fopt' }, ...[[7, 'أسبوع'], [15, '١٥ يوم'], [30, 'شهر'], [60, 'شهرين']].map(([n, t]) => h('button', { type: 'button', class: k?.days === n ? 'on' : '', onclick: () => { qSave({ kh: { days: n, start: k?.start || new Date().toISOString(), pos: k?.pos || 0, dayDate: k?.dayDate || '', dayPos: k?.dayPos || 0 } }); azSheetClose(); paintAzkar(); toast('🎯 بدأت ختمتك — بالتوفيق'); } }, h('b', { text: t }), h('small', { text: `تقريباً ${UI.n(Math.ceil(6236 / n))} آية يومياً` })))),
    h('p', { class: 'hint', text: 'لو فاتك يوم، نوزّع الباقي على الأيام الجاية تلقائياً 🤍 · سجّل وردك من زر «✓ سجّل وردي» أو «📍 وصلت هنا» على أي آية.' }),
    k ? h('button', { type: 'button', class: 'btn btn-block danger', onclick: () => { qSave({ kh: null }); azSheetClose(); paintAzkar(); } }, 'إلغاء الختمة') : null]);
}

/* ---------------- الأذكار ---------------- */
const AZ_LISTS = {
  'الأذكار': [['a_morning', '☀️', 'أذكار الصباح', 'صباح'], ['a_evening', '🌇', 'أذكار المساء', 'مساء'], ['a_prayer', '🕌', 'أذكار بعد الصلاة', 'بعد الصلاة'], ['a_sleep', '😴', 'أذكار النوم', 'نوم'], ['a_wake', '🌤️', 'أذكار الاستيقاظ', 'استيقاظ']],
  'الأدعية': [['a_dua', '🤲', 'أدعية من السنة', 'دعاء'], ['a_dua', '📖', 'أدعية من القرآن', 'آية'], ['a_dua', '💧', 'الاستغفار', 'استغفار']],
  'الفضائل': [['a_fadl', '🌿', 'الصلاة على النبي ﷺ', 'صلاة على النبي ﷺ'], ['a_fadl', '📿', 'فضل الذكر', 'ذكر'], ['a_fadl', '📜', 'أحاديث', 'حديث']],
};
const azCat = (c) => azAll().filter((z) => z.cat === c);
function paintAzTab(body) {
  const I = azIcfg(), parts = [];
  const card = (slot, ctl) => {
    const v = azVis(ctl); if (v === 'none') return null;
    const it = azItem(slot); if (it.hide) return null;
    const lock = v === 'soon' || v === 'lock';
    const go = () => {
      if (v === 'soon') return toast('قريباً — المحتوى يُضاف بعد المراجعة 🤍');
      if (v === 'lock') { if (typeof Upgrade !== 'undefined') return Upgrade.open({ app: 'azkar', why: 'هذا القسم للمشتركين 💎' }); return toast('للمشتركين 💎'); }
      if (slot === 'b_azkar') return azListSheet('الأذكار');
      if (slot === 'b_dua') return azListSheet('الأدعية');
      if (slot === 'b_fadl') return azListSheet('الفضائل');
      if (slot === 'g_tasbih') return $('#az-tb')?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const cat = { g_ruqya: 'رقية', g_ramadan: 'رمضان', g_hajj: 'حج' }[slot];
      if (cat) { if (!azCat(cat).length) return toast('قريباً — المحتوى يُضاف من الإدارة بعد المراجعة 🤍'); return azSession(cat, it.n); }
    };
    const tag = v === 'soon' ? '🔒 قريباً' : v === 'lock' ? '💎' : v === 'beta' ? '🧪' : '';
    return slot[0] === 'b'
      ? h('button', { type: 'button', class: `az-bc${lock ? ' lk' : ''}`, onclick: go }, azIc(slot), h('span', {}, h('b', { text: it.n }), I.desc !== false && it.d ? h('small', { text: it.d }) : null), tag ? h('em', { class: 'az-lk', text: tag }) : h('span', { class: 'az-chev' }, icon('chevL', { size: 16 })))
      : h('button', { type: 'button', class: `az-gc${lock ? ' lk' : ''}`, onclick: go }, tag ? h('em', { class: 'az-lk', text: tag }) : null, azIc(slot, { z: Math.round((Number(I.z) || 52) * 1.06) }), h('b', { class: 'lbl', text: it.n }), I.desc !== false && it.d ? h('small', { text: it.d }) : null);
  };
  const MAP = { b_azkar: 'a_azkar', b_dua: 'a_dua', b_fadl: 'a_fadl', g_tasbih: 'a_tasbih', g_ruqya: 'a_ruqya', g_ramadan: 'a_ramadan', g_hajj: 'a_hajj' };
  const order = I.order.filter((x) => MAP[x]);
  parts.push(h('div', { class: 'az-big' }, ...order.filter((x) => x[0] === 'b').map((x) => card(x, MAP[x]))));
  parts.push(h('div', { class: 'az-g2' }, ...order.filter((x) => x[0] === 'g').map((x) => card(x, MAP[x]))));
  if (azOn('a_tasbih')) parts.push(azTasbihCard());
  if (Platform.isNative && azCfg().remind.on && azOn('g_remind')) parts.push(h('button', { type: 'button', class: `az-remind${pref('azkarRemind') ? ' on' : ''}`, onclick: () => azSetRemind(!pref('azkarRemind')) },
    pref('azkarRemind') ? `🔔 تذكير أذكار الصباح ${UI.n(azCfg().remind.morning)}:٠٠ والمساء ${UI.n(azCfg().remind.evening > 12 ? azCfg().remind.evening - 12 : azCfg().remind.evening)}:٠٠ مفعّل` : '🔕 ذكّرني بأذكار الصباح والمساء'));
  RC(body, ...parts);
}
function azListSheet(group) {
  const L = AZ_LISTS[group].filter(([ctl, , , cat]) => azOn(ctl) && azCat(cat).length);
  azSheet(group, [h('div', { class: 'qr-lst' }, ...L.map(([, e, n, cat]) => h('button', { type: 'button', class: 'li', onclick: () => { azSheetClose(); azSession(cat, n); } }, h('span', { class: 'ci', text: e }), h('span', {}, h('b', { text: n }), h('small', { text: `${UI.n(azCat(cat).length)} ${azCat(cat).length > 2 ? 'أذكار' : 'ذكر'}${azOn('a_session') ? ' · وضع الجلسة' : ''}` })), h('span', { class: 'pg' }, icon('chevL', { size: 15 }))))),
    !L.length ? h('p', { class: 'az-empty', text: 'ما فيه محتوى ظاهر هنا حالياً' }) : null,
    azOn('a_session') ? h('p', { class: 'hint', text: '«وضع الجلسة»: ذكر واحد بالشاشة، تضغط وتعدّ، وينقلك للي بعده تلقائياً.' }) : null]);
}
function azTasbihCard() {
  const tb = azTasbih(), sel = AZ_TASBIH[tb.sel] || AZ_TASBIH[0], it = azItem('g_tasbih');
  const ring = h('i', { class: 'rg', style: { '--p': `${tb.n && tb.n % sel[1] === 0 ? 100 : (tb.n % sel[1]) / sel[1] * 100}%` } });
  const num = h('b', { class: 'num', text: UI.n(tb.n) });
  const beads = h('div', { class: 'az-beads' }, ...Array.from({ length: 11 }, (_, i) => h('i', { class: i < tb.n % 11 ? 'on' : '' })));
  const totals = h('small', { class: 'num', text: `اليوم ${UI.n(tb.today)} · المجموع ${UI.n(tb.total)}` });
  const bead = h('button', { type: 'button', class: 'az-bead', 'aria-label': 'سبّح', onclick: () => {
    const t = azTasbih(), nn = t.n + 1; azTasbihAdd(1, { n: nn, sel: t.sel }); azNurMark();
    num.textContent = UI.n(nn); ring.style.setProperty('--p', `${nn % sel[1] === 0 ? 100 : (nn % sel[1]) / sel[1] * 100}%`);
    beads.querySelectorAll('i').forEach((x, i) => x.classList.toggle('on', i < nn % 11));
    bead.classList.remove('tap'); void bead.offsetWidth; bead.classList.add('tap');
    if (nn % sel[1] === 0) { buzz('success'); toast(`أتممت ${UI.n(sel[1])} ✓ — تقبّل الله`, { type: 'success' }); } else buzz('light');
    totals.textContent = UI.n(`اليوم ${azTasbih().today} · المجموع ${azTasbih().total}`);
  } }, ring, h('span', {}, num, h('small', { text: `/ ${UI.n(sel[1])}` })));
  return h('section', { class: 'az-tb', id: 'az-tb' }, h('div', { class: 'h' }, h('b', { text: `📿 ${it.n}` }), totals),
    h('div', { class: 'chips az-tbc' }, ...AZ_TASBIH.map(([t], i) => h('button', { type: 'button', class: `chip${tb.sel === i ? ' on' : ''}`, onclick: () => { azTasbihAdd(0, { sel: i, n: 0 }); paintAzkar(); } }, t))),
    h('p', { class: 'az-tbt', text: sel[0] }), bead, beads,
    h('button', { type: 'button', class: 'link-btn', onclick: () => { azTasbihAdd(0, { n: 0 }); paintAzkar(); } }, '↺ صفّر العداد'));
}
/* وضع الجلسة */
function azSession(cat, title) {
  const L = azCat(cat);
  if (!L.length) return toast('المحتوى يُضاف من لوحة التحكم 🤍');
  title = title || { 'صباح': 'أذكار الصباح', 'مساء': 'أذكار المساء', 'نوم': 'أذكار النوم', 'بعد الصلاة': 'أذكار بعد الصلاة', 'استيقاظ': 'أذكار الاستيقاظ' }[cat] || cat;
  if (!azOn('a_session')) return azPlainList(L, title);
  if (AZ.canEdit == null) { AZ.canEdit = false; Cloud.soon(S.perms ? Promise.resolve(S.perms) : Cloud.permissions(), 5000).then((pm) => { S.perms = S.perms || pm; AZ.canEdit = (pm?.perms || []).includes('content.edit'); if (AZ.canEdit && AZ.ss) azSsPaint(); }).catch(() => { AZ.canEdit = null; }); }
  AZ.ss = { title, L, i: 0, n: 0, el: AZ.ss?.el || h('div', { class: 'az-ss', role: 'dialog', 'aria-label': title }) };
  if (!AZ.ss.el.isConnected) document.body.append(AZ.ss.el);
  AZ.ss.el.classList.add('on'); document.documentElement.classList.add('rd-open');
  azSsPaint();
}
function azPlainList(L, title) { azSheet(title, L.map((z) => h('div', { class: 'az-card' }, h('p', { class: 'az-txt', text: z.text }), z.virtue ? h('small', { class: 'az-vir', text: z.virtue }) : null, h('small', { class: 'az-src', text: `${z.source || ''}${(z.count || 1) > 1 ? ` · ×${UI.n(z.count)}` : ''}` })))); }
function azSsPaint() {
  const ss = AZ.ss; if (!ss) return; const { L, i, n } = ss, el = ss.el;
  if (i >= L.length) {
    azNurMark();
    RC(el, h('div', { class: 'ss-h' }, h('b', { text: ss.title }), h('button', { type: 'button', class: 'x', onclick: azSsClose }, '✕')),
      h('div', { class: 'ss-done' }, h('div', { class: 'em', text: '🤍' }), h('b', { text: 'تقبّل الله منك' }), h('p', { text: `أتممت ${ss.title} · يوم نور 🔥` }),
        h('div', { class: 'row' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: azSsClose }, 'تم'), azOn('g_story') ? h('button', { type: 'button', class: 'btn', onclick: () => azToStory({ text: `أتممت ${ss.title} 🤍`, source: 'NOBLE', cat: 'ذكر' }) }, '🎨 شارك إنجازك') : null)));
    buzz('success'); return;
  }
  const z = L[i], need = z.count || 1;
  const tap = h('button', { type: 'button', class: 'ss-tap', style: { '--p': `${n / need * 100}%` } }, h('i', { class: 'rg' }), h('span', {}, h('b', { class: 'num', text: UI.n(need - n) }), h('small', { text: 'اضغط' })));
  const prog = h('div', { class: 'ss-pr' }, ...L.map((_, k) => h('i', { class: k < i ? 'd' : k === i ? 'c' : '', style: { '--p': k === i ? `${n / need * 100}%` : '0%' } })));
  const press = () => {
    ss.n++; azTasbihAdd(1); buzz('light');
    if (ss.n >= need) { buzz('success'); tap.style.setProperty('--p', '100%'); tap.querySelector('b').textContent = '✓'; ss.i++; ss.n = 0; setTimeout(azSsPaint, 220); return; }
    tap.style.setProperty('--p', `${ss.n / need * 100}%`); tap.querySelector('b').textContent = UI.n(need - ss.n);
    tap.classList.remove('tap'); void tap.offsetWidth; tap.classList.add('tap'); prog.querySelector('.c')?.style.setProperty('--p', `${ss.n / need * 100}%`);
  };
  tap.onclick = press;
  const cnt = h('div', { class: 'ss-c', onclick: press }, h('div', { class: 't', text: z.text }), z.virtue ? h('div', { class: 'v', text: z.virtue }) : null, h('div', { class: 's', text: z.source || '' }));
  // 1.21.26: ✏️ تعديل الذكر من داخل التطبيق — للي عنده صلاحية المحتوى، وللأذكار اللي على السيرفر
  const ed = AZ.canEdit && z.rid ? h('button', { type: 'button', class: 'x ss-ed', 'aria-label': 'تعديل الذكر', onclick: () => azEdit(z) }, '✏️') : null;
  RC(el, h('div', { class: 'ss-h' }, h('b', { text: ss.title }), h('small', { class: 'num', text: `${UI.n(i + 1)} / ${UI.n(L.length)}` }), ed, h('button', { type: 'button', class: 'x', 'aria-label': 'إغلاق', onclick: azSsClose }, '✕')),
    prog, cnt, tap,
    h('div', { class: 'ss-n' }, h('button', { type: 'button', onclick: () => { ss.i = Math.max(0, ss.i - 1); ss.n = 0; azSsPaint(); } }, '› السابق'), h('button', { type: 'button', onclick: () => { ss.i++; ss.n = 0; azSsPaint(); } }, 'تخطَّ ‹')));
}
function azSsClose() { if (!AZ.ss) return; AZ.ss.el.classList.remove('on'); document.documentElement.classList.remove('rd-open'); AZ.ss = { ...AZ.ss, L: [] }; AZ.ss = null; if (S.tab === 'azkar') paintAzkar(); }

/* ---------------- الخدمات ---------------- */
let azCmp = null;
function paintServices(body) {
  const d = new Date(), pc = pCurNext(d), I = azIcfg(), parts = [];
  const svc = [['s_pt', 'az-s-pt'], ['s_qibla', 'az-s-qb'], ['s_cal', 'az-s-cal'], ['s_occ', 'az-s-occ']].filter(([id]) => azOn(id) && !azItem(id).hide);
  if (svc.length > 1) parts.push(h('div', { class: 'az-svc' }, ...svc.map(([id, to]) => h('button', { type: 'button', onclick: () => { const e = $('#' + to); if (e) window.scrollTo({ top: e.getBoundingClientRect().top + window.scrollY - 120, behavior: 'smooth' }); } }, azIc(id, { z: Math.round((Number(I.z) || 52) * 1.12) }), h('span', { class: 'lbl', text: azItem(id).n })))));
  if (azOn('s_pt') && pc) {
    const p = pv();
    parts.push(h('div', { class: 'az-h2', id: 'az-s-pt' }, h('b', { text: 'مواقيت الصلاة' }), h('span', { class: 'az-tag', text: 'أم القرى' })));
    parts.push(h('button', { type: 'button', class: 'az-city', onclick: azCity }, `📍 ${pLoc().name}`, h('small', { text: pLoc().guess ? ' — اضغط واختر مدينتك' : ' — تغيير' })));
    parts.push(h('div', { class: 'az-ptl' }, ...pc.list.map(([n, k, t, id], i) => h('div', { class: `r${k === pc.nxt[1] ? ' nx' : ''}` }, azIc(id, { z: 30, cls: 'bare', noBadge: true }),
      h('span', {}, n, k === pc.nxt[1] ? h('small', { text: ` · بعد ${dur(t - d).replace(/:\d\d$/, '')}` }) : null), h('b', { class: 'num', text: hm(t) }),
      azOn('s_adhan') && i !== 1 ? h('button', { type: 'button', class: `bell${p.bells[i] ? ' on' : ''}`, 'aria-label': `تنبيه ${n}`, onclick: () => { if (!p.lat) return azCity(); const b = [...p.bells]; b[i] = b[i] ? 0 : 1; pSave({ bells: b }); toast(b[i] ? `🔔 بنذكّرك بأذان ${n}` : `🔕 أوقفنا تنبيه ${n}`); paintAzkar(); } }, icon(p.bells[i] ? 'bell' : 'x', { size: 16 })) : h('span')))));
    if (azOn('s_adhan')) parts.push(h('div', { class: 'az-pre' }, h('span', { text: 'التنبيه:' }), ...[[0, 'وقت الأذان'], [10, 'قبل ١٠ د'], [15, 'قبل ١٥ د']].map(([m, l]) => h('button', { type: 'button', class: `chip${(Number(p.pre) || 0) === m ? ' on' : ''}`, onclick: () => { pSave({ pre: m }); paintAzkar(); } }, l))));
    parts.push(h('p', { class: 'hint', text: Platform.isNative ? 'تُحسب داخل الجوال بدون نت (أم القرى) · التنبيهات تتجدد كل ما فتحت التطبيق' : 'تُحسب داخل الجهاز بدون نت (أم القرى)' }));
  }
  if (azOn('s_qibla')) {
    const L = pLoc(), q = typeof adhan !== 'undefined' ? adhan.Qibla(new adhan.Coordinates(L.lat, L.lng)) : 0;
    const dial = h('div', { class: 'dial' }, ...['ش', 'شرق', 'ج', 'غرب'].map((x, i) => h('span', { style: { transform: `translate(-50%,-50%) rotate(${i * 90}deg) translateY(-92px) rotate(${-i * 90}deg)` }, text: x })));
    dial.insertAdjacentHTML('beforeend', `<svg viewBox="0 0 220 220">${Array.from({ length: 72 }, (_, i) => `<line x1="110" y1="${i % 6 ? 14 : 10}" x2="110" y2="20" stroke="currentColor" stroke-opacity="${i % 6 ? 0.15 : 0.45}" transform="rotate(${i * 5} 110 110)"/>`).join('')}</svg>`);
    const needle = h('div', { class: 'needle' }); needle.innerHTML = '<svg viewBox="0 0 220 220"><defs><linearGradient id="azng" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#F2D184"/><stop offset="1" stop-color="#2FD6AE"/></linearGradient></defs><path d="M110 40l9 70h-18z" fill="url(#azng)"/><path d="M110 180l7-70h-14z" fill="rgb(255 255 255 / .15)"/></svg><div class="kaaba">🕋</div>';
    const txt = h('small', { class: 'qb-t', text: 'وجّه أعلى الجوال نحو 🕋' });
    const set = (hd) => { dial.style.transform = `rotate(${-hd}deg)`; needle.style.transform = `rotate(${q - hd}deg)`; const df = ((q - hd) % 360 + 360) % 360; const ok = df < 6 || df > 354; txt.textContent = ok ? '✅ أنت باتجاه القبلة' : 'لفّ الجوال حتى يصير 🕋 فوق'; if (ok && !set.ok) buzz('success'); set.ok = ok; };
    parts.push(h('div', { class: 'az-h2', id: 'az-s-qb' }, h('b', { text: 'اتجاه القبلة' }), h('span', { class: 'az-tag v num', text: `${UI.n(Math.round(q))}° من الشمال` })));
    parts.push(h('section', { class: 'az-qb' }, h('div', { class: 'cmp' }, dial, needle, h('i', { class: 'hub' })), txt,
      h('button', { type: 'button', class: 'btn', onclick: () => azCompass(set) }, '🧭 فعّل البوصلة'), pLoc().guess ? h('small', { class: 'hint', text: 'اختر مدينتك فوق عشان يكون الاتجاه دقيق' }) : null));
    requestAnimationFrame(() => set(0));
  }
  if (azOn('s_cal')) { parts.push(h('div', { class: 'az-h2', id: 'az-s-cal' }, h('b', { text: 'التقويم الهجري' }), h('span', { class: 'az-tag g', text: `${HM[AzkarKit.hijri(d).m - 1] || ''} ${UI.n(AzkarKit.hijri(d).y)}` }))); parts.push(azCalendar(d)); }
  if (azOn('s_occ')) { const oc = azOccasions(d); if (oc.length) { parts.push(h('div', { class: 'az-h2', id: 'az-s-occ' }, h('b', { text: 'المناسبات القادمة' }))); parts.push(h('div', { class: 'az-occ' }, ...oc)); } }
  RC(body, ...parts);
}
function azCompass(set) {
  const on = (e) => { const hd = e.webkitCompassHeading ?? (e.absolute || e.type === 'deviceorientationabsolute' ? 360 - (e.alpha || 0) : null); if (hd != null) set(hd); };
  const start = () => { window.removeEventListener('deviceorientationabsolute', azCmp || on); window.removeEventListener('deviceorientation', azCmp || on); azCmp = on; window.addEventListener('deviceorientationabsolute', on); window.addEventListener('deviceorientation', on); toast('🧭 حرّك الجوال بشكل ∞ للمعايرة'); };
  if (typeof DeviceOrientationEvent !== 'undefined' && DeviceOrientationEvent.requestPermission) DeviceOrientationEvent.requestPermission().then((p) => p === 'granted' && start()).catch(() => {});
  else if ('ondeviceorientationabsolute' in window || 'ondeviceorientation' in window) start();
  else toast('جهازك ما فيه بوصلة', { type: 'error' });
}
function azCalendar(d) {
  const hj = AzkarKit.hijri(d); const s = new Date(d); s.setHours(12, 0, 0, 0);
  let g = 0; while (AzkarKit.hijri(s).d !== 1 && g++ < 31) s.setDate(s.getDate() - 1);
  const days = []; const x = new Date(s); g = 0; while (AzkarKit.hijri(x).m === hj.m && g++ < 31) { days.push(new Date(x)); x.setDate(x.getDate() + 1); }
  const EV = { '1-1': 'رأس السنة', '1-10': 'عاشوراء', '9-1': 'رمضان', '9-27': 'ليلة ٢٧', '10-1': 'عيد الفطر', '12-9': 'عرفة', '12-10': 'عيد الأضحى' };
  return h('section', { class: 'az-cal' },
    h('div', { class: 'grid' }, ...['ح', 'ن', 'ث', 'ر', 'خ', 'ج', 'س'].map((w) => h('div', { class: 'wd', text: w })), ...Array.from({ length: s.getDay() }, () => h('div')),
      ...days.map((gd, i) => { const n = i + 1; return h('div', { class: ['d', gd.toDateString() === d.toDateString() ? 'today' : '', [13, 14, 15].includes(n) ? 'wh' : '', EV[`${hj.m}-${n}`] ? 'ev' : '', [1, 4].includes(gd.getDay()) ? 'mt' : ''].join(' '), title: EV[`${hj.m}-${n}`] || '' }, h('span', { class: 'num', text: UI.n(n) }), h('small', { class: 'num', text: UI.n(gd.getDate()) })); })),
    h('div', { class: 'lg' }, h('span', {}, h('i', { style: { background: '#F2D184' } }), 'الأيام البيض'), h('span', {}, h('i', { style: { background: '#2FD6AE' } }), 'صيام الاثنين والخميس'), h('span', {}, h('i', { style: { background: '#C9A6FF' } }), 'مناسبة')));
}
function azOccasions(d) {
  const T = [[9, 1, '🌙', 'رمضان المبارك', 'اللهم بلّغنا رمضان'], [10, 1, '🎉', 'عيد الفطر', ''], [12, 9, '🏔️', 'يوم عرفة', 'صيامه يكفّر سنتين'], [12, 10, '🐑', 'عيد الأضحى', ''], [1, 1, '🗓️', 'رأس السنة الهجرية', ''], [1, 10, '✨', 'عاشوراء', 'صيامه يكفّر سنة']];
  const found = []; const x = new Date(d); x.setHours(12, 0, 0, 0);
  for (let i = 0; i < 400 && found.length < T.length; i++) { const hj = AzkarKit.hijri(x); T.forEach((t) => { if (t[0] === hj.m && t[1] === hj.d && !found.some((f) => f[0] === t)) found.push([t, new Date(x), i]); }); x.setDate(x.getDate() + 1); }
  return found.sort((a, b) => a[2] - b[2]).slice(0, 4).map(([t, g, n]) => h('div', { class: 'oc' }, h('span', { class: 'o', text: t[2] }), h('span', {}, h('b', { text: t[3] }), h('small', { text: `${t[4] || `${UI.n(g.getDate())} ${GM[g.getMonth()]} ${UI.n(g.getFullYear())}`} · تقريبي حسب أم القرى` })), h('span', { class: 'cd' }, h('b', { class: 'num', text: n ? UI.n(n) : 'اليوم' }), n ? h('small', { text: 'يوم' }) : null)));
}
/* اختيار المدينة */
function azCity() {
  const cur = pLoc();
  const list = h('div', { class: 'az-cities' }, ...CITIES.map(([n, lat, lng]) => h('button', { type: 'button', class: `chip${cur.name === n && !cur.guess ? ' on' : ''}`, onclick: () => { pSave({ name: n, lat, lng }); azSheetClose(); paintAzkar(); toast(`📍 ${n}`); } }, n)));
  azSheet('اختر مدينتك', [
    h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => {
      if (!navigator.geolocation) return toast('تحديد الموقع غير متاح', { type: 'error' });
      toast('📍 نحدد موقعك…');
      navigator.geolocation.getCurrentPosition((p) => { pSave({ name: 'موقعي الحالي', lat: +p.coords.latitude.toFixed(4), lng: +p.coords.longitude.toFixed(4) }); azSheetClose(); paintAzkar(); toast('✓ حدّثنا المواقيت حسب موقعك', { type: 'success' }); },
        () => toast('ما قدرنا نحدد موقعك — اسمح بالموقع أو اختر مدينة', { type: 'error' }), { enableHighAccuracy: false, timeout: 15000, maximumAge: 6e5 });
    } }, '📍 استخدم موقعي'),
    h('p', { class: 'hint', text: 'موقعك يُحفظ مشفّراً في خزنتك ويُستخدم لحساب المواقيت والقبلة داخل جوالك فقط.' }), list]);
}
/* إعدادات أذكاري */
function azSettings() {
  const tog = (title, sub, on, f) => { const i = h('input', { type: 'checkbox', checked: !!on }); i.addEventListener('change', () => f(i.checked)); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); };
  azSheet('⚙️ إعدادات أذكاري', [h('div', { class: 'set-card' },
    azCfg().toast.on && azOn('g_toast') ? tog('نافذة الذكر عند فتح التطبيق', 'ذكر لطيف ينزل لك أول ما تفتح', !pref('azToastOff'), (v) => { setPref({ azToastOff: !v }); lsS('nw:azHideDay', ''); }) : null,
    Platform.isNative && azCfg().remind.on && azOn('g_remind') ? tog('تذكير أذكار الصباح والمساء', '', !!pref('azkarRemind'), (v) => azSetRemind(v)) : null,
    azOn('services') ? h('button', { type: 'button', class: 'set-row', onclick: () => { azSheetClose(); setTimeout(azCity, 250); } }, h('span', {}, h('strong', { text: '📍 المدينة' }), h('p', { class: 'hint', text: pLoc().name })), h('b', { text: '›' })) : null,
    h('button', { type: 'button', class: 'set-row', onclick: () => { azSheetClose(); setTimeout(() => azkarToast(true), 300); } }, h('span', {}, h('strong', { text: '🔔 جرّب نافذة الذكر' })), h('b', { text: '›' })))]);
}

/* ---------- ورقة سفلية عامة للقسم ---------- */
let azSh = null, azShOnClose = null;
function azSheet(title, kids, onClose) {
  if (!azSh) { azSh = h('section', { class: 'sheet az-sheet', id: 'az-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(azSh); azSh.addEventListener('closed', () => { const f = azShOnClose; azShOnClose = null; f?.(); }); }
  azShOnClose = onClose || null;
  azSh.replaceChildren(h('div', { class: 'grab' }), h('header', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => azSheetClose() }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body az-shb' }, ...kids.filter(Boolean)));
  UI.digitize(azSh);
  if (azSh.hidden) openSheet('#az-sheet');
}
function azSheetClose() { if (azSh && !azSh.hidden) closeSheet(azSh); }
/* زر الرجوع في أندرويد */
function azBack() {
  if (AZ.ss) { azSsClose(); return true; }
  if (QRD?.classList.contains('on')) { qClose(); return true; }
  return false;
}
function azCloseAll() { if (AZ.ss) azSsClose(); if (QRD?.classList.contains('on')) qClose(); azSheetClose(); }

/* ================= تذكير الصباح والمساء ================= */
async function azSetRemind(on) {
  const LN = Platform.plugin('LocalNotifications');
  if (!LN) return;
  try {
    if (on) { const p = await LN.requestPermissions(); if (p.display !== 'granted') return toast('اسمح للتطبيق بالإشعارات من إعدادات الجوال', { type: 'error' }); }
    await LN.cancel({ notifications: [{ id: 770201 }, { id: 770202 }] }).catch(() => {});
    const r = azCfg().remind;
    if (on) await LN.schedule({ notifications: [
      { id: 770201, title: '☀️ أذكار الصباح', body: 'دقيقتين تحصّن بها يومك 🤍', schedule: { on: { hour: Number(r.morning) || 7, minute: 0 }, allowWhileIdle: true }, extra: { tab: 'azkar' }, smallIcon: 'ic_stat_nobleweb' },
      { id: 770202, title: '🌙 أذكار المساء', body: 'لا تنسَ أذكار المساء 🤍', schedule: { on: { hour: Number(r.evening) || 18, minute: 0 }, allowWhileIdle: true }, extra: { tab: 'azkar' }, smallIcon: 'ic_stat_nobleweb' }] });
    await setPref({ azkarRemind: on });
    toast(on ? 'بنذكّرك بأذكار الصباح والمساء 🤍' : 'أوقفنا التذكير', { type: 'success' });
    if (S.tab === 'azkar') renderAzkar();
  } catch (e) { toast('تعذّر ضبط التذكير: ' + (e.message || e), { type: 'error' }); }
}
/* تجديد تنبيهات الأذان عند فتح التطبيق */
setTimeout(() => { try { if (typeof S !== 'undefined' && S.vault && S.vault.prayer) azAdhanSchedule(); } catch { /* لا شيء */ } }, 8000);

/* 1.21.26 — ✏️ تعديل الذكر وأنت تقرأه (للمشرف) — نفس اللي في لوحة التحكم ← الأذكار */
function azEdit(z) {
  const ta = (v, rows, ph) => { const t = h('textarea', { class: 'input textarea', rows, placeholder: ph }); t.value = v || ''; return t; };
  const tx = ta(z.text, 6, 'نص الذكر'), src = h('input', { class: 'input', value: z.source || '', placeholder: 'المصدر — مثل «سورة البقرة: ٢٥٥» أو «رواه مسلم»' }),
    vir = ta(z.virtue, 2, 'الفضل (اختياري)'), cnt = h('input', { class: 'input num', type: 'number', min: 1, max: 1000, value: z.count || 1 });
  const save = async (e) => {
    const b = e.currentTarget; b.disabled = true;
    const data = { ...Object.fromEntries(Object.entries(z).filter(([k]) => !['id', 'rid', 'builtin'].includes(k))), text: tx.value.trim(), source: src.value.trim(), virtue: vir.value.trim(), count: Math.max(1, +cnt.value || 1) };
    if (!data.text) { b.disabled = false; return toast('النص فاضي'); }
    try {
      await Cloud.admin.azkarSave(z.rid, data);
      Object.assign(z, data);
      const it = (AZ.items || []).find((x) => x.id === z.rid); if (it) Object.assign(it, data);
      try { azCache({ items: AZ.items, meta: AZ.meta }); } catch { /* لا شيء */ }
      closeSheet(sh); toast('انحفظ ✓ ويوصل للكل', { type: 'success' }); if (AZ.ss) azSsPaint();
    } catch (er) { toast(Cloud.msg(er), { type: 'error' }); b.disabled = false; }
  };
  uiSheet('az-ed-sheet', '✏️ تعديل الذكر', [
    h('label', { class: 'field' }, h('span', { text: 'النص' }), tx),
    h('label', { class: 'field' }, h('span', { text: 'المصدر (يطلع بالأخضر تحت)' }), src),
    h('label', { class: 'field' }, h('span', { text: 'الفضل (يطلع بالرمادي)' }), vir),
    h('label', { class: 'field' }, h('span', { text: 'عدد التكرار' }), cnt),
    h('small', { class: 'hint', text: 'الآيات: حطها بين ﴿ ﴾ واكتب اسم السورة في المصدر — بدون «رواه».' })],
    [h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: save }, 'حفظ')]);
  const sh = document.getElementById('az-ed-sheet'), bd = document.getElementById('backdrop');
  if (sh) { sh.style.zIndex = '960'; if (bd) bd.style.zIndex = '950';
    const mo = new MutationObserver(() => { if (!sh.hidden) return; mo.disconnect(); sh.style.zIndex = ''; if (bd) bd.style.zIndex = ''; }); mo.observe(sh, { attributes: true, attributeFilter: ['hidden'] }); }
}
