/* NOBLE — الرسائل الإجبارية + المزامنة الفورية مع لوحة الإدارة */
'use strict';
const NT = { list: [], showing: null };

async function loadNotices() {
  if (!Cloud.enabled || !S.unlocked || !(await Cloud.user())) return;
  const now = Date.now();
  NT.list = ((await Cloud.myNotices()) || []).filter((n) => !n.expires_at || new Date(n.expires_at).getTime() > now);
  paintNoticeBar();
  nextNoticeGate();
}

/* الشريط: إعلانات «شريط» غير المقروءة (شكلها ولونها وحركتها من لوحة الإدارة) */
const closedBars = () => { try { return new Set(JSON.parse(sessionStorage.getItem('nw:bar-closed') || '[]')); } catch { return new Set(); } };
function closeBar(n) {
  const s = closedBars(); s.add(n.id);
  try { sessionStorage.setItem('nw:bar-closed', JSON.stringify([...s])); } catch { /* لا شيء */ }
  paintNoticeBar();
}
function paintNoticeBar() {
  const box = $('#notice-bar');
  const closed = closedBars();
  const bars = NT.list.filter((n) => n.level === 'bar' && !closed.has(n.id));
  box.hidden = !bars.length;
  document.body.classList.remove('nb-bottom');
  if (!bars.length) return box.replaceChildren();
  const n = bars[0];
  const el = NoticeUI.bar(n, { extra: bars.length - 1, onRead: () => readNotice(n), onClose: () => closeBar(n) });
  const bottom = NoticeUI.style(n.style).pos === 'bottom';
  box.className = `notice-host${bottom ? ' at-bottom' : ''}`;
  document.body.classList.toggle('nb-bottom', bottom);
  box.replaceChildren(el);
}

/* الشاشة الكاملة: تمنع استخدام التطبيق حتى يضغط «قرأت» */
function nextNoticeGate() {
  const n = NT.list.find((x) => x.level === 'screen');
  const gate = $('#notice-gate');
  const sig = n ? `${n.id}:${n.updated_at || ''}` : '';
  if (!n) { gate._card?._stop?.(); gate.hidden = true; gate.replaceChildren(); NT.showing = null; document.body.classList.remove('noticed'); return; }
  if (NT.showing === sig && !gate.hidden) return;
  const again = NT.showing && NT.showing.split(':')[0] === String(n.id); // تعديل لنفس الرسالة: بدون عدّاد جديد
  NT.showing = sig;
  gate._card?._stop?.();
  const count = NT.list.filter((x) => x.level === 'screen').length;
  const card = NoticeUI.gate(n, { count, wait: again ? 0 : 3, onRead: () => readNotice(n) });
  gate._card = card;
  gate.replaceChildren(card);
  gate.scrollTop = 0;
  gate.hidden = false;
  document.body.classList.add('noticed');
  if (!again) buzz('medium');
}

async function readNotice(n) {
  try { await Cloud.readNotice(n.id); } catch (e) {
    // بدون نت: نخفيها الآن ونرسل «قرأت» عند رجوع الاتصال
    if (!/اتصال|fetch|network|Load failed/i.test(e?.message || '') && Sync.online()) return toast(Cloud.msg(e), { type: 'error' });
    Sync.read(n.id);
  }
  Sync.event('notice_read', { id: n.id, level: n.level });
  NT.list = NT.list.filter((x) => x.id !== n.id);
  if (NT.showing && NT.showing.split(':')[0] === String(n.id)) NT.showing = null;
  buzz('light');
  paintNoticeBar();
  nextNoticeGate();
}

/* ---------- المزامنة الفورية ---------- */
let liveTimer = {};
const debounce = (k, fn, ms = 400) => { clearTimeout(liveTimer[k]); liveTimer[k] = setTimeout(fn, ms); };
function startLive() {
  if (!Cloud.enabled) return;
  Cloud.live((kind, row) => {
    if (kind === 'config') debounce('config', loadRemoteContent);
    else if (kind === 'notices') debounce('notices', loadNotices);
    else if (kind === 'messages') debounce('messages', loadInbox);
    else if (kind === 'entitlements') debounce('ent', async () => {
      const had = Pro.any();
      await Pro.refresh();
      if (!had && Pro.any()) { buzz('success'); toast('🎉 تم تفعيل NOBLE Pro — شكراً لدعمك!', { type: 'success', duration: 6000 }); }
      if (S.unlocked) render();
    });
    else if (kind === 'profile' && row) {
      if (row.status === 'suspended') return suspendedOut();
      S.profile = { ...(S.profile || {}), ...row };
      S.perms = null;
      renderTabbar();
      if (S.tab === 'games' && typeof renderGames === 'function') renderGames();
    }
  });
}
