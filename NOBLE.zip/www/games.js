/* NOBLE — قسم الألعاب: الأبطال، النقاط، الصدارة، إكس أو */
'use strict';

/* ================= حالة اللاعب (مشفّرة ضمن الخزنة) ================= */
const num0 = (x) => (Number.isFinite(+x) ? +x : 0);
/* يطبّع حالة اللاعب حتى لو كانت محفوظة من نسخة قديمة أو ناقصة */
function normGames(g = {}) {
  const xo = g.xo && typeof g.xo === 'object' ? g.xo : {};
  const fl = g.flame && typeof g.flame === 'object' ? g.flame : {};
  return {
    ...g,
    hero: g.hero || '', xp: num0(g.xp), points: num0(g.points),
    streak: g.streak && typeof g.streak === 'object' ? { last: g.streak.last || '', n: num0(g.streak.n) } : { last: '', n: 0 },
    xo: { w: num0(xo.w), d: num0(xo.d), l: num0(xo.l), level: ['easy', 'medium', 'hard'].includes(xo.level) ? xo.level : 'medium' },
    flame: { ...fl, best: fl.best || {}, stars: fl.stars || {} },
    badges: Array.isArray(g.badges) ? g.badges : [], orient: g.orient || '', sound: g.sound !== false,
    awarded: Array.isArray(g.awarded) ? g.awarded : [],
  };
}
function gstate() { return normGames(S.vault?.games || {}); }
/* الحفظ بالتسلسل: لا يتداخل حفظان (كان سبب أخطاء الفوز على الجوال) */
let gQueue = Promise.resolve();
function gsave(mut) {
  const run = gQueue.then(() => commit((v) => {
    v.games = normGames(v.games || {});
    return mut(v.games);
  }));
  gQueue = run.catch(() => {});
  return run;
}
const levelOf = (xp) => Math.floor(Math.sqrt(xp / 60)) + 1;
const xpFor = (lvl) => (lvl - 1) ** 2 * 60;
const todayKey = () => new Date().toISOString().slice(0, 10);

const BADGES = {
  first_win: { name: 'أول فوز', ic: '🏅' },
  xo_10: { name: '١٠ انتصارات', ic: '🎯' },
  unbeatable: { name: 'صمدت أمام المستحيل', ic: '🛡️' },
  online_win: { name: 'بطل أونلاين', ic: '🌐' },
  sanaa: { name: 'حامي صنعاء', ic: '🏰' },
  guardian: { name: 'هازم الحارس', ic: '🏮' },
  three_stars: { name: 'ثلاث نجوم', ic: '⭐' },
  beans_100: { name: '١٠٠ حبة بن', ic: '☕' },
  streak_7: { name: 'أسبوع متواصل', ic: '🔥' },
  tasks_20: { name: 'منجز', ic: '✅' },
  word_first: { name: 'أول كلمة', ic: '🔤' },
  word_7: { name: 'أسبوع كلمات', ic: '📚' },
  daily_7: { name: 'أسبوع نشاط', ic: '📅' },
  daily_30: { name: 'شهر بلا انقطاع', ic: '🏆' },
};

/* نقاط + خبرة + سلسلة أيام + أوسمة، ثم رفعها للصدارة (بشكل مجمّع) */
async function addPoints(game, pts, extra = {}) {
  pts = Math.max(0, Math.round(num0(pts) * num0(GCfg.mult(game) ?? 1))) || 0;
  let newBadges = [];
  await gsave((g) => {
    g.points = (g.points || 0) + pts;
    // نقاط كل يوم (للتقارير) — آخر ١٢٠ يوم
    g.pd = g.pd && typeof g.pd === 'object' ? g.pd : {};
    const dk = new Date(); const dks = `${dk.getFullYear()}-${String(dk.getMonth() + 1).padStart(2, '0')}-${String(dk.getDate()).padStart(2, '0')}`;
    g.pd[dks] = (g.pd[dks] || 0) + pts;
    Object.keys(g.pd).sort().slice(0, -120).forEach((k) => delete g.pd[k]);
    g.xp = (g.xp || 0) + pts;
    const t = todayKey();
    if (g.streak?.last !== t) {
      const y = new Date(Date.now() - 864e5).toISOString().slice(0, 10);
      g.streak = { last: t, n: g.streak?.last === y ? (g.streak.n || 0) + 1 : 1 };
    }
    const give = (id) => { if (id && !g.badges.includes(id)) { g.badges.push(id); newBadges.push(id); } };
    (extra.badges || []).forEach(give);
    if (g.streak.n >= 7) give('streak_7');
    if (extra.mut) extra.mut(g, give);
  });
  newBadges.filter((b) => BADGES[b]).forEach((b, i) => setTimeout(() => { buzz('success'); toast(`وسام جديد: ${BADGES[b].ic} ${BADGES[b].name}`, { type: 'success' }); }, 600 + i * 900));
  newBadges.forEach((b) => Sync.event('badge', { id: b }));
  // النقاط تُحفظ في صندوق الإرسال على الجهاز وتُرفع للصدارة عند توفر النت
  if (pts > 0 && Cloud.enabled) Sync.score(game, pts);
  if (!['tasks', 'daily', 'word'].includes(game) && typeof markActive === 'function') markActive('game');
  return pts;
}
/* نقاط إنجاز المهام (مرة واحدة لكل مهمة) */
function awardTask(id) {
  const g = gstate();
  if (g.awarded.includes(id)) return;
  addPoints('tasks', Number(GCfg.get().tasksPts) || 0, { mut: (x, give) => { x.awarded = [...(x.awarded || []), id].slice(-400); if (x.awarded.length >= 20) give('tasks_20'); } });
}

/* ================= شاشة اللعب ================= */
const GS = { screen: null, onBack: null, cleanup: null };
function openScreen(build, { onBack, cleanup, cls = '' } = {}) {
  closeScreen();
  const el = h('div', { id: 'game-screen', class: `g-screen ${cls}` });
  document.body.append(el);
  document.body.classList.add('in-game');
  GS.screen = el; GS.onBack = onBack || closeScreen; GS.cleanup = cleanup || null;
  build(el);
  return el;
}
function closeScreen() {
  if (GS.cleanup) { try { GS.cleanup(); } catch { /* لا شيء */ } }
  if (typeof ChaseMusic !== 'undefined') ChaseMusic.stop(); // لا تبقى موسيقى بعد الخروج
  GS.screen?.remove();
  GS.screen = null; GS.onBack = null; GS.cleanup = null;
  document.body.classList.remove('in-game');
  if (S.tab === 'games') renderGames();
}
function gameBack() {
  if (!GS.screen) return false;
  if (S.sheets.length) { closeSheet(); return true; }
  GS.onBack();
  return true;
}
const gHead = (title, right, onBack) => h('div', { class: 'g-head' },
  h('button', { type: 'button', class: 'icon-btn g-back', 'aria-label': 'رجوع', onclick: onBack || (() => GS.onBack()) }, icon('arrowLeft', { size: 20 })),
  h('h1', { text: title }), right || h('span', { style: { width: '42px' } }));

const myLook = () => (typeof Look !== 'undefined' ? Look.get() : null);
/* يتأكد أن اللاعب اختار بطله قبل اللعب */
const heroOn = (id) => !!id && !(GCfg.get().heroes.off || []).includes(id);
const availHeroes = () => { const l = HEROES.filter((x) => heroOn(x.id)); return l.length ? l : [HEROES[0]]; };
/* البطل الفعلي (لو أوقفت الإدارة بطل اللاعب نستخدم الافتراضي) */
function myHero() {
  const g = gstate().hero;
  if (heroOn(g)) return g;
  const d = GCfg.get().heroes.def;
  return heroOn(d) ? d : availHeroes()[0].id;
}
function withHero(then) {
  const g = gstate().hero;
  if (g && heroOn(g)) return then();
  openHeroPicker(then);
}

/* ================= الواجهة الرئيسية للألعاب ================= */
const LB = { period: '', rows: null, err: '' };
/* يعدّ الوقت المتبقي للعرض */
function leftText(until) {
  if (!until) return '';
  const ms = new Date(until).getTime() - Date.now();
  if (ms <= 0) return '';
  const d = Math.floor(ms / 864e5), hh = Math.floor((ms % 864e5) / 36e5), mm = Math.floor((ms % 36e5) / 6e4);
  return d ? `ينتهي خلال ${d} يوم و${hh} ساعة` : hh ? `ينتهي خلال ${hh} ساعة و${mm} دقيقة` : `ينتهي خلال ${mm} دقيقة`;
}
function renderGames() {
  const box = $('#g-home');
  if (!box || !S.vault) return;
  const g = gstate();
  const C = GCfg.get();
  if (!LB.period) LB.period = C.board.period || 'week';
  const ev = GCfg.event();
  const hero = g.hero ? myHero() : '';
  const cards = {
    word: () => (typeof wordCard === 'function' && typeof Words !== 'undefined' ? wordCard(C, g) : null),
    xo: () => h('button', { type: 'button', class: 'g-card gc-xo', onclick: () => withHero(openXOMenu) },
      h('span', { class: 'gc-art' }, svgNode(XO_ICON.X), svgNode(XO_ICON.O)),
      GCfg.mult('xo') > 1 ? h('span', { class: 'gc-mult num', text: `×${GCfg.mult('xo')}` }) : null,
      h('b', { text: C.xo.name }), h('small', { text: C.xo.desc }),
      h('span', { class: 'gc-meta num', text: `${g.xo.w} فوز · ${g.xo.d} تعادل` })),
    flame: () => h('button', { type: 'button', class: 'g-card gc-flame', onclick: () => withHero(() => Flame.openMap()) },
      h('span', { class: 'gc-art' }, heroNode(hero || myHero(), 44, 'run1', myLook())),
      GCfg.mult('flame') > 1 ? h('span', { class: 'gc-mult num', text: `×${GCfg.mult('flame')}` }) : null,
      h('b', { text: C.flame.name }), h('small', { text: C.flame.desc }),
      h('span', { class: 'gc-meta num', text: `⭐ ${Object.values(g.flame.stars || {}).reduce((a, b) => a + b, 0)}/9` })),
    chase: () => h('button', { type: 'button', class: 'g-card gc-chase', onclick: () => withHero(() => Chase.open()) },
      h('span', { class: 'gc-art' }, typeof ChaseArt !== 'undefined' ? svgNode(ChaseArt.carSVG('#E23B3B', { body: 'gt' })) : null),
      GCfg.mult('chase') > 1 ? h('span', { class: 'gc-mult num', text: `×${GCfg.mult('chase')}` }) : null,
      h('b', { text: C.chase.name }), h('small', { text: C.chase.desc }),
      h('span', { class: 'gc-meta num', text: `🏁 أفضل ${Math.round(g.chase?.best || 0)} كم` })),
  };
  /* الوصول لكل لعبة (مجانية / بالاشتراك / مخفية) — من لوحة التحكم */
  const P = typeof Pro !== 'undefined' ? Pro : null;
  const lockCard = (k, el) => {
    if (!P || P.has('games.' + k)) return el;
    const f = Market.feat('games.' + k);
    if (f?.limit > 0) { el.append(h('span', { class: 'gc-lock try', text: `مجاناً: ${UI.n(f.limit)} ${f.unit || ''}` })); return el; }
    el.classList.add('locked');
    el.append(h('span', { class: 'gc-lock', text: '🔒 بالاشتراك' }));
    el.onclick = () => P.gate('games.' + k);
    return el;
  };
  const order = [...new Set([...(C.order || []), 'word', 'xo', 'flame', 'chase'])].filter((k) => cards[k] && C[k]?.on !== false && (!P || P.visible('games.' + k)));
  const lvl = levelOf(g.xp);
  const from = xpFor(lvl), to = xpFor(lvl + 1);
  const pct = Math.min(100, Math.round(((g.xp - from) / (to - from)) * 100));
  const nick = S.profile?.nickname || S.profile?.display_name || 'أنت';
  const heroBtn = h('button', { type: 'button', class: 'g-avatar', 'aria-label': 'تغيير البطل', onclick: () => openHeroPicker() },
    hero ? heroNode(hero, 58, 'stand', myLook()) : h('span', { class: 'g-q', text: '؟' }), h('span', { class: 'g-edit' }, icon('edit', { size: 12 })));

  box.replaceChildren(...[
    h('div', { class: 'g-title' }, h('h1', { class: 'view-title', text: C.hubTitle }), h('span', { class: 'g-pts num' }, icon('trophy', { size: 15 }), `${g.points} نقطة`)),
    h('section', { class: 'g-player' },
      heroBtn,
      h('div', { class: 'g-pinfo' },
        h('b', { text: nick }),
        h('small', { text: hero ? heroById(hero).name : 'اختر بطلك أولاً' }),
        h('div', { class: 'g-xp' }, h('i', { style: { width: pct + '%' } })),
        h('small', { class: 'num', text: `المستوى ${lvl} · ${g.xp - from}/${to - from} خبرة` })),
      h('div', { class: 'g-streak' }, h('b', { class: 'num', text: g.streak.last === todayKey() || g.streak.last === new Date(Date.now() - 864e5).toISOString().slice(0, 10) ? g.streak.n : 0 }), h('small', { text: 'يوم 🔥' }))),
    g.badges.length ? h('div', { class: 'g-badges' }, ...g.badges.map((b) => BADGES[b] && h('span', { class: 'g-badge', title: BADGES[b].name }, BADGES[b].ic, h('small', { text: BADGES[b].name })))) : null,
    ev ? h('section', { class: 'g-event' },
      h('span', { class: 'ge-mult num', text: `×${ev.mult}` }),
      h('div', { class: 'ge-t' }, h('b', { text: ev.title }), h('small', { text: ev.text }), ev.until ? h('small', { class: 'ge-left', text: leftText(ev.until) }) : null)) : null,
    typeof AccessUI !== 'undefined' ? AccessUI.banner('games') : null,
    order.length ? h('div', { class: `g-cards${order.length === 1 ? ' one' : ''}` }, ...order.map((k) => lockCard(k, cards[k]())))
      : h('div', { class: 'empty' }, icon('gamepad', { size: 38 }), h('h3', { text: 'الألعاب متوقفة حالياً' }), h('p', { text: 'ترجع قريباً — تابع الإعلانات.' })),
    C.board.on === false ? null : h('section', { class: 'g-lb' },
      h('div', { class: 'g-lb-head' }, h('b', {}, icon('trophy', { size: 17 }), C.board.title),
        h('div', { class: 'seg seg-3 seg-mini' }, ...[['week', 'الأسبوع'], ['month', 'الشهر'], ['all', 'الكل']].map(([k, l]) =>
          h('label', {}, h('input', { type: 'radio', name: 'lbp', value: k, checked: LB.period === k, onchange: () => { LB.period = k; LB.rows = null; renderGames(); } }), h('span', { text: l }))))),
      h('div', { id: 'lb-list', class: 'lb-list' }),
      Cloud.enabled && S.profile && !S.profile.nickname ? h('button', { type: 'button', class: 'link-btn lb-nick', onclick: openProfile }, 'اختر اسمك المستعار في الصدارة ←') : null),
  ].filter(Boolean));
  renderLeaderboard();
  UI.digitize(box);
}

async function renderLeaderboard() {
  const list = $('#lb-list');
  if (!list) return;
  if (!Cloud.enabled || !(await Cloud.user())) {
    list.replaceChildren(h('p', { class: 'hint lb-empty', text: 'سجّل الدخول بحساب لتنافس الآخرين في الصدارة.' }));
    return;
  }
  if (!LB.rows) {
    list.replaceChildren(h('p', { class: 'hint lb-empty', text: 'جارٍ التحميل…' }));
    try { LB.rows = (await Cloud.leaderboard(LB.period)).slice(0, Number(GCfg.get().board.size) || 50); LB.err = ''; } catch (e) { LB.rows = Sync.online() ? [] : null; LB.err = Cloud.msg(e); if (!LB.rows) { list.replaceChildren(h('p', { class: 'hint lb-empty', text: 'بدون اتصال — الصدارة تظهر عند رجوع النت، ونقاطك محفوظة على جهازك' })); return; } }
    if (!$('#lb-list')) return;
  }
  const rows = LB.rows || [];
  if (!rows.length) {
    list.replaceChildren(h('p', { class: 'hint lb-empty', text: !Sync.online() ? 'بدون اتصال — الصدارة تظهر عند رجوع النت، ونقاطك محفوظة على جهازك' : LB.err || 'لا توجد نقاط بعد — العب أول مباراة!' }));
    return;
  }
  const medal = ['🥇', '🥈', '🥉'];
  const pend = Sync.count();
  list.replaceChildren(...[
    !Sync.online() || pend ? h('p', { class: 'hint lb-off' }, icon('wifi', { size: 13 }), !Sync.online() ? ' بدون اتصال — آخر صدارة محفوظة، ونقاطك الجديدة تُرفع عند رجوع النت' : ' نقاطك الجديدة في طريقها للصدارة…') : null,
    ...rows.map((r) => h('div', { class: `lb-row${r.is_me ? ' me' : ''}` },
    h('span', { class: 'lb-rank num', text: medal[r.rank - 1] || r.rank }),
    h('span', { class: 'lb-name', text: r.is_me ? `${r.nickname} (أنت)` : r.nickname }),
    !r.is_me && typeof reportContent === 'function' ? h('button', { type: 'button', class: 'rep-btn lb-rep', 'aria-label': 'إبلاغ عن الاسم', onclick: () => reportContent({ kind: 'nick', id: r.user_id || r.id || '', name: r.nickname }) }, '🚩') : null,
    h('span', { class: 'lb-pts num', text: r.points })))].filter(Boolean));
  UI.digitize(list);
}

/* ================= منتقي البطل ================= */
function openHeroPicker(then) {
  const H = GCfg.get().heroes;
  let pick = heroOn(gstate().hero) ? gstate().hero : myHero();
  const holder = h('div', { class: 'hp' });
  const paint = () => {
    const cur = heroById(pick);
    holder.replaceChildren(
      h('div', { class: 'hp-stage' }, heroNode(pick, 130, 'stand', myLook()), h('div', { class: 'hp-ground' })),
      h('div', { class: 'hp-info' }, h('b', {}, cur.name, H.featured === pick ? h('span', { class: 'hp-feat', text: 'مميز' }) : null), h('small', { text: cur.desc })),
      h('div', { class: 'hp-grid' }, ...availHeroes().map((x) => h('button', { type: 'button', class: `hp-opt${x.id === pick ? ' on' : ''}${H.featured === x.id ? ' feat' : ''}`, 'aria-label': heroById(x.id).name, onclick: () => { pick = x.id; buzz('select'); paint(); } }, heroNode(x.id, 46)))),
      h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
        await gsave((g) => { g.hero = pick; });
        closeSheet($('#hero-sheet'));
        buzz('success');
        if (then) setTimeout(then, 230); else renderGames();
      } }, then ? 'اختر وابدأ اللعب' : 'حفظ البطل'));
  };
  paint();
  let sheet = $('#hero-sheet');
  if (!sheet) {
    sheet = h('section', { class: 'sheet', id: 'hero-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' });
    document.body.append(sheet);
  }
  sheet.replaceChildren(h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: 'اختر بطلك' }), h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'إغلاق', onclick: () => closeSheet(sheet) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body' }, holder));
  openSheet('#hero-sheet');
}

/* ================= إكس أو ================= */
const XO_ICON = {
  X: '<svg viewBox="0 0 100 100" width="100%" height="100%"><path d="M24 24 76 76M76 24 24 76" stroke="#56C8FF" stroke-width="14" stroke-linecap="round" style="filter:drop-shadow(0 0 6px #56C8FF)"/></svg>',
  O: '<svg viewBox="0 0 100 100" width="100%" height="100%"><defs><linearGradient id="xoO" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#FFB43D"/><stop offset=".5" stop-color="#F0922F"/><stop offset="1" stop-color="#C8509C"/></linearGradient></defs><circle cx="50" cy="50" r="28" fill="none" stroke="url(#xoO)" stroke-width="14" style="filter:drop-shadow(0 0 6px #F0922F)"/></svg>',
};
const LINES = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
function winnerOf(b) {
  for (const l of LINES) if (b[l[0]] && b[l[0]] === b[l[1]] && b[l[0]] === b[l[2]]) return { p: b[l[0]], line: l };
  return b.every(Boolean) ? { p: 'draw' } : null;
}
function minimax(b, me, turn, depth = 0) {
  const w = winnerOf(b);
  if (w) return { s: w.p === 'draw' ? 0 : w.p === me ? 10 - depth : depth - 10 };
  let best = { s: turn === me ? -99 : 99, i: -1 };
  for (let i = 0; i < 9; i++) {
    if (b[i]) continue;
    b[i] = turn;
    const r = minimax(b, me, turn === 'X' ? 'O' : 'X', depth + 1);
    b[i] = null;
    if (turn === me ? r.s > best.s : r.s < best.s) best = { s: r.s, i };
  }
  return best;
}
/* ---------- ذكاء الجوال: استراتيجية «نيويل وسايمون» المعروفة لإكس أو ----------
 * الترتيب الصحيح لكل حركة: ١ فوز ← ٢ صدّ ← ٣ شوكة (تهديدين) ← ٤ منع شوكة الخصم ← ٥ الوسط ← ٦ الزاوية المقابلة ← ٧ زاوية فاضية ← ٨ جانب فاضي
 * «صعب» يلعب الاستراتيجية كاملة ويتحقق بـ minimax (ما يخسر أبداً) ويختار عشوائياً بين الحركات المثالية حتى ما تتكرر اللعبة.
 * «متوسط» ما يفوّت فوز أو صدّ أبداً، لكن يغفل عن الشوكات أحياناً — تقدر تغلبه بخطة.
 * «سهل» يغفل كثيراً لكنه يفوز إذا الفوز قدامه غالباً. */
const XO_CORNERS = [0, 2, 6, 8], XO_SIDES = [1, 3, 5, 7], XO_OPP = { 0: 8, 2: 6, 6: 2, 8: 0 };
const xoOther = (p) => (p === 'X' ? 'O' : 'X');
const xoFree = (b) => b.map((v, i) => (v ? -1 : i)).filter((i) => i >= 0);
const xoPick = (a) => a[Math.floor(Math.random() * a.length)];
/* الخانات اللي تكمّل خط لـ p (فوز فوري) */
function xoWins(b, p) {
  const out = [];
  for (const l of LINES) {
    const v = l.map((i) => b[i]);
    if (v.filter((x) => x === p).length === 2 && v.includes(null)) out.push(l[v.indexOf(null)]);
  }
  return [...new Set(out)];
}
/* الخانات اللي تصنع شوكة لـ p (تهديدين مرة وحدة) */
function xoForks(b, p) {
  return xoFree(b).filter((i) => { b[i] = p; const n = xoWins(b, p).length; b[i] = null; return n >= 2; });
}
/* منع شوكة الخصم: الأفضل نهدد تهديد يجبره يصد في خانة ما تعطيه شوكة */
function xoBlockFork(b, me) {
  const opp = xoOther(me);
  const forks = xoForks(b, opp);
  if (!forks.length) return [];
  const safe = xoFree(b).filter((i) => {
    b[i] = me;
    const threats = xoWins(b, me);
    let ok = threats.length > 0 && threats.every((t) => { b[t] = opp; const f = xoWins(b, opp).length < 2; b[t] = null; return f; });
    b[i] = null;
    return ok;
  });
  if (safe.length) return safe;
  return forks.length === 1 ? forks : [];
}
/* كل الحركات المثالية (minimax) — للتأكد إن «صعب» ما يخسر */
function xoBestMoves(b, me) {
  const scores = xoFree(b).map((i) => { b[i] = me; const s = minimax(b, me, xoOther(me), 1).s; b[i] = null; return [i, s]; });
  const top = Math.max(...scores.map((x) => x[1]));
  return scores.filter((x) => x[1] === top).map((x) => x[0]);
}
/* الاستراتيجية بالترتيب — skip: قواعد يتجاهلها المستوى */
function xoRule(b, me, skip = {}) {
  const opp = xoOther(me);
  const free = xoFree(b);
  let m;
  if ((m = xoWins(b, me)).length && !skip.win) return { i: xoPick(m), why: 'فوز' };
  if ((m = xoWins(b, opp)).length && !skip.block) return { i: xoPick(m), why: 'صدّ' };
  if (!skip.fork && (m = xoForks(b, me)).length) return { i: xoPick(m), why: 'شوكة' };
  if (!skip.blockFork && (m = xoBlockFork(b, me)).length) return { i: xoPick(m), why: 'منع شوكة' };
  if (!b[4]) return { i: 4, why: 'وسط' };
  if ((m = XO_CORNERS.filter((c) => b[c] === opp && !b[XO_OPP[c]])).length) return { i: XO_OPP[xoPick(m)], why: 'زاوية مقابلة' };
  if ((m = XO_CORNERS.filter((c) => !b[c])).length) return { i: xoPick(m), why: 'زاوية' };
  return { i: xoPick(XO_SIDES.filter((c) => !b[c]).concat(free)), why: 'جانب' };
}
function aiMove(b, me, level) {
  const board = [...b];
  const free = xoFree(board);
  if (!free.length) return -1;
  const chance = (p) => Math.random() < p;
  if (level === 'easy') {
    // سهل: يفوز غالباً لو الفوز قدامه، ويصد أحياناً، والباقي عشوائي
    const w = xoWins(board, me), bl = xoWins(board, xoOther(me));
    if (w.length && chance(0.75)) return xoPick(w);
    if (bl.length && chance(0.4)) return xoPick(bl);
    return xoPick(free);
  }
  if (level === 'medium') {
    // متوسط: فوز وصدّ دائماً — والشوكات أحياناً، فيقدر اللاعب الذكي يغلبه
    return xoRule(board, me, { fork: !chance(0.5), blockFork: !chance(0.35) }).i;
  }
  // صعب: البداية متنوعة (زاوية أو وسط)، ثم الاستراتيجية — ولو طلعت حركة غير مثالية نصححها بـ minimax
  if (free.length === 9) return chance(0.6) ? xoPick(XO_CORNERS) : 4;
  const best = xoBestMoves(board, me);
  const r = xoRule(board, me).i;
  return best.includes(r) ? r : xoPick(best);
}
const XO_LV = () => {
  const x = GCfg.get().xo;
  return { easy: { name: x.levels.easy, win: +x.pts.easy || 0 }, medium: { name: x.levels.medium, win: +x.pts.medium || 0 }, hard: { name: x.levels.hard, win: +x.pts.hard || 0, draw: +x.pts.hardDraw || 0 } };
};

function openXOMenu() {
  const g = gstate();
  let level = g.xo.level || 'medium';
  openScreen((el) => {
    const lv = h('div', { class: 'xo-levels' }, ...Object.entries(XO_LV()).map(([k, v]) =>
      h('button', { type: 'button', class: k === level ? 'on' : '', onclick: (e) => { e.stopPropagation(); level = k; $$('.xo-levels button', el).forEach((b, i) => b.classList.toggle('on', Object.keys(XO_LV())[i] === k)); gsave((x) => { x.xo = { ...x.xo, level: k }; }); } }, v.name)));
    el.append(h('div', { class: 'g-wrap' },
      gHead(GCfg.get().xo.name, h('span', { class: 'chip g-chip num' }, icon('trophy', { size: 14 }), g.points)),
      h('div', { class: 'xo-hero' }, h('span', { class: 'xo-big' }, svgNode(XO_ICON.X)), h('span', { class: 'xo-big' }, svgNode(XO_ICON.O))),
      h('div', { class: 'xo-modes' },
        h('div', { class: 'xo-mode hl', role: 'button', tabindex: 0, onclick: () => startXO({ mode: 'ai', level }) },
          h('span', { class: 'mi mi-ai' }, icon('cpu', { size: 24 })),
          h('div', { class: 'mi-t' }, h('b', { text: 'ضد الجوال' }), h('small', { text: 'اختر مستوى الذكاء ثم اضغط' }), lv),
          h('span', { class: 'mi-go' }, icon('play', { size: 18, fill: true, stroke: 0 }))),
        h('button', { type: 'button', class: 'xo-mode', onclick: () => startXO({ mode: 'local' }) },
          h('span', { class: 'mi mi-local' }, icon('users', { size: 24 })),
          h('div', { class: 'mi-t' }, h('b', { text: 'مع صديق بجانبك' }), h('small', { text: 'على نفس الجوال بالتناوب' })),
          h('span', { class: 'mi-go' }, icon('arrowLeft', { size: 18 }))),
        GCfg.get().xo.online === false ? null : h('button', { type: 'button', class: 'xo-mode', onclick: openOnlineXO },
          h('span', { class: 'mi mi-online' }, icon('wifi', { size: 24 })),
          h('div', { class: 'mi-t' }, h('b', { text: 'تحدّي صديق أونلاين' }), h('small', { text: 'كود غرفة تشاركه معه · يُحسب في الصدارة' })),
          h('span', { class: 'mi-go' }, icon('arrowLeft', { size: 18 })))),
      h('div', { class: 'xo-stats' },
        h('div', {}, h('b', { class: 'num c-win', text: g.xo.w }), h('small', { text: 'فوز' })),
        h('div', {}, h('b', { class: 'num', text: g.xo.d }), h('small', { text: 'تعادل' })),
        h('div', {}, h('b', { class: 'num c-loss', text: g.xo.l }), h('small', { text: 'خسارة' })))));
    UI.digitize(el);
  });
}

/* لعبة واحدة: mode = ai | local | online */
/* خط الفوز: من مركز الخانة الأولى إلى مركز الثالثة (يمتد قليلاً داخل الخانتين فقط — لا يخرج منها)
 * يُحسب من مكان الخانات الفعلي على الشاشة، فيصلح مع الاتجاه العربي ومع تدوير الجوال */
function xoLinePoints(board, lineIdx) {
  const svg = board.querySelector('.xo-line');
  const box = svg.getBoundingClientRect();
  const cells = board.querySelectorAll('.xo-cell');
  const rect = (i) => cells[i].getBoundingClientRect();
  const mid = (r) => [r.left + r.width / 2 - box.left, r.top + r.height / 2 - box.top];
  const [a, , z] = lineIdx;
  const ra = rect(a), rz = rect(z);
  const [x1, y1] = mid(ra), [x2, y2] = mid(rz);
  const len = Math.hypot(x2 - x1, y2 - y1) || 1;
  const ux = (x2 - x1) / len, uy = (y2 - y1) / len;
  const ext = Math.min(ra.width, ra.height) * 0.3; // يبقى داخل الخانة (نصفها = 0.5)
  return { box, p1: [x1 - ux * ext, y1 - uy * ext], p2: [x2 + ux * ext, y2 + uy * ext] };
}
function startXO(opt) {
  const g = gstate();
  const me = S.profile?.nickname || S.profile?.display_name || 'أنت';
  const X = { mode: opt.mode, level: opt.level, board: Array(9).fill(null), turn: 'X', starter: 'X', over: false, round: 1, score: { X: 0, O: 0 },
    mine: opt.mine || 'X', net: opt.net || null, names: { X: me, O: opt.mode === 'ai' ? 'الجوال' : opt.mode === 'local' ? 'صديقك' : (opt.oppName || 'صديقك') }, heroes: { X: myHero(), O: opt.oppHero || '' } };
  if (opt.mode === 'online' && X.mine === 'O') X.names = { X: opt.oppName || 'صديقك', O: me }, X.heroes = { X: opt.oppHero || '', O: myHero() };
  if (opt.mode === 'local') X.names = { X: 'اللاعب ١', O: 'اللاعب ٢' };

  let els = {};
  let lastWin = null;
  function drawWinLine(lineIdx, animate) {
    if (!els.line || !els.line.isConnected) return;
    lastWin = lineIdx;
    const { box, p1, p2 } = xoLinePoints(els.line.parentNode, lineIdx);
    if (!box.width) return;
    const line = els.line.querySelector('line');
    els.line.setAttribute('viewBox', `0 0 ${box.width} ${box.height}`);
    line.setAttribute('x1', p1[0]); line.setAttribute('y1', p1[1]); line.setAttribute('x2', p2[0]); line.setAttribute('y2', p2[1]);
    const g = els.line.querySelector('linearGradient'); g?.setAttribute('x1', p1[0]); g?.setAttribute('y1', p1[1]); g?.setAttribute('x2', p2[0]); g?.setAttribute('y2', p2[1]);
    const L = String(Math.ceil(Math.hypot(p2[0] - p1[0], p2[1] - p1[1])) + 4);
    line.style.strokeDasharray = L;
    if (animate) { line.style.strokeDashoffset = L; els.line.classList.remove('show'); void els.line.getBoundingClientRect(); els.line.classList.add('show'); }
    else line.style.strokeDashoffset = '0';
  }
  const onXoResize = () => { if (lastWin && X.over) drawWinLine(lastWin, false); };
  window.addEventListener('resize', onXoResize);
  const quit = () => {
    if (X.net) { X.net.send({ t: 'bye' }).catch(() => {}); X.net.leave(); }
    openXOMenu();
  };
  openScreen((el) => {
    const pl = (p) => h('div', { class: 'xo-pl', dataset: { p } },
      h('span', { class: 'xo-pic' }, X.heroes[p] ? heroNode(X.heroes[p], 30, 'stand', p === X.mine ? myLook() : null) : svgNode(p === 'X' ? XO_ICON.X : XO_ICON.O)),
      h('span', { class: 'xo-sym' }, svgNode(XO_ICON[p])),
      h('span', { class: 'nm', text: X.names[p] }),
      h('small', { text: X.mode === 'ai' && p === 'O' ? XO_LV()[X.level].name : X.mode === 'online' && p === X.mine ? 'أنت' : '' }),
      h('b', { class: 'sc num', text: '0' }));
    els.board = h('div', { class: 'xo-board' }, ...Array.from({ length: 9 }, (_, i) => h('button', { type: 'button', class: 'xo-cell', dataset: { i }, 'aria-label': `خانة ${i + 1}` })),
      els.line = svgNode('<svg class="xo-line" viewBox="0 0 300 300" preserveAspectRatio="none"><defs><linearGradient id="xoL" gradientUnits="userSpaceOnUse" x1="0" y1="0" x2="300" y2="300"><stop offset="0" stop-color="#FFB43D"/><stop offset=".5" stop-color="#F0922F"/><stop offset="1" stop-color="#C8509C"/></linearGradient></defs><line x1="0" y1="0" x2="0" y2="0" stroke="url(#xoL)" stroke-width="12" stroke-linecap="round"/></svg>'));
    els.status = h('div', { class: 'xo-status' });
    els.actions = h('div', { class: 'xo-actions' },
      h('button', { type: 'button', class: 'btn', onclick: quit }, 'القائمة'),
      els.again = h('button', { type: 'button', class: 'btn btn-primary', hidden: true, onclick: () => { if (X.net) X.net.send({ t: 'again' }); newRound(); } }, 'جولة جديدة'));
    el.append(h('div', { class: 'g-wrap' },
      gHead(GCfg.get().xo.name, els.roundChip = h('span', { class: 'chip g-chip num' })),
      h('div', { class: 'xo-players' }, els.px = pl('X'), h('span', { class: 'xo-vs', text: 'VS' }), els.po = pl('O')),
      els.status, els.board, els.actions));
    els.board.addEventListener('click', (e) => {
      const c = e.target.closest('.xo-cell');
      if (c) tap(Number(c.dataset.i));
    });
  }, { onBack: quit, cleanup: () => { window.removeEventListener('resize', onXoResize); if (X.net) X.net.leave(); } });

  function paint(win) {
    $$('.xo-cell', els.board).forEach((c, i) => {
      const v = X.board[i];
      if (v && !c.firstChild) c.append(svgNode(XO_ICON[v]));
      if (!v) c.replaceChildren();
      c.disabled = !!v || X.over;
      c.classList.toggle('win', !!win?.line?.includes(i));
    });
    els.px.classList.toggle('turn', !X.over && X.turn === 'X');
    els.po.classList.toggle('turn', !X.over && X.turn === 'O');
    $('.sc', els.px).textContent = UI.n(X.score.X);
    $('.sc', els.po).textContent = UI.n(X.score.O);
    els.roundChip.textContent = UI.n(`الجولة ${X.round}`);
    const line = $('line', els.line);
    els.line.classList.toggle('show', !!win?.line);
    if (!win?.line) lastWin = null;
    if (win?.line) requestAnimationFrame(() => drawWinLine(win.line, true));
    els.again.hidden = !X.over;
    if (!X.over) {
      const yours = X.mode === 'local' ? `دور ${X.names[X.turn]}` : X.turn === X.mine ? 'دورك' : X.mode === 'ai' ? 'الجوال يفكّر…' : `دور ${X.names[X.turn]}`;
      els.status.replaceChildren(h('span', { text: yours }));
    }
  }

  function tap(i) {
    if (X.over || X.board[i]) return;
    if (X.mode !== 'local' && X.turn !== X.mine) return;
    play(i, true);
  }
  function play(i, local) {
    X.board[i] = X.turn;
    buzz('light');
    if (X.mode === 'online' && local) X.net.send({ t: 'move', i, r: X.round });
    const w = winnerOf(X.board);
    if (w) return finish(w);
    X.turn = X.turn === 'X' ? 'O' : 'X';
    paint();
    if (X.mode === 'ai' && X.turn !== X.mine) setTimeout(() => { if (!X.over && GS.screen) play(aiMove(X.board, X.turn, X.level), false); }, 420 + Math.random() * 300);
  }
  /* نهاية الجولة: النتيجة تظهر فوراً، والنقاط تُحفظ في الخلفية بأمان */
  function finish(w) {
    X.over = true;
    if (w.p !== 'draw') X.score[w.p]++;
    const round = X.round;
    const won = w.p === X.mine, draw = w.p === 'draw';
    let msg;
    if (X.mode === 'local') msg = draw ? 'تعادل!' : `فاز ${X.names[w.p]} 🎉`;
    else msg = draw ? 'تعادل 🤝' : won ? 'فزت بالجولة! 🎉' : X.mode === 'ai' ? 'فاز الجوال هذه المرة' : `فاز ${X.names[w.p]}`;
    const title = h('b', { class: won || (X.mode === 'local' && !draw) ? 'c-win' : '', text: msg });
    const sub = h('small', { class: 'xo-pts', hidden: true });
    try { paint(w); } catch (e) { console.warn('xo paint', e); }
    els.status.replaceChildren(title, sub);
    els.status.classList.remove('pop'); void els.status.offsetWidth; els.status.classList.add('pop');
    buzz(won || (X.mode === 'local' && !draw) ? 'success' : draw ? 'medium' : 'warning');
    if (X.mode === 'local') return;
    let pts = 0;
    try {
      const L = XO_LV()[X.level] || {};
      const XP = GCfg.get().xo?.pts || {};
      pts = X.mode === 'ai' ? (won ? num0(L.win) : draw ? (num0(L.draw) || 1) : 0) : won ? num0(XP.onlineWin) : draw ? num0(XP.onlineDraw) : 0;
    } catch { pts = 0; }
    const mode = X.mode, level = X.level;
    Sync.event('xo_game', { mode, level: mode === 'ai' ? level : undefined, result: won ? 'win' : draw ? 'draw' : 'loss' });
    addPoints('xo', pts, { mut: (g, give) => {
      g.xo = { ...g.xo, w: g.xo.w + (won ? 1 : 0), d: g.xo.d + (draw ? 1 : 0), l: g.xo.l + (!won && !draw ? 1 : 0) };
      if (won) give('first_win');
      if (g.xo.w >= 10) give('xo_10');
      if (draw && level === 'hard') give('unbeatable');
      if (won && mode === 'online') give('online_win');
    } }).then((got) => {
      if (!got || !GS.screen || X.round !== round || !sub.isConnected) return;
      sub.textContent = UI.n(`+${got} نقطة`);
      sub.hidden = false;
    }).catch((e) => console.warn('xo points', e));
  }
  function newRound() {
    X.board = Array(9).fill(null);
    X.over = false;
    X.round++;
    X.starter = X.starter === 'X' ? 'O' : 'X';
    X.turn = X.starter;
    paint();
    if (X.mode === 'ai' && X.turn !== X.mine) setTimeout(() => { if (!X.over && GS.screen) play(aiMove(X.board, X.turn, X.level), false); }, 500);
  }

  if (X.net) {
    X.net.onMsg = (m) => {
      if (m.t === 'move' && !X.over && X.turn !== X.mine && !X.board[m.i]) play(m.i, false);
      else if (m.t === 'again' && X.over) newRound();
      else if (m.t === 'bye') { X.over = true; paint(); els.status.replaceChildren(h('b', { text: 'غادر صديقك الغرفة' })); els.again.hidden = true; }
    };
  }
  paint();
}

/* ---------- أونلاين ---------- */
function openOnlineXO() {
  if (!Cloud.enabled) return toast('اللعب أونلاين يحتاج حساباً سحابياً');
  if (!Sync.online()) return toast('تحدّي الأونلاين يحتاج اتصالاً بالإنترنت — العب ضد الجوال أو مع صديق بجانبك', { duration: 5000 });
  let net = null;
  const leave = () => { if (net) { net.leave(); net = null; } };
  openScreen((el) => {
    const codeIn = h('input', { class: 'input xo-code-in ltr', maxlength: 4, placeholder: 'ABCD', autocomplete: 'off', inputmode: 'text' });
    const status = h('div', { class: 'xo-wait', hidden: true });
    el.append(h('div', { class: 'g-wrap' },
      gHead('تحدّي أونلاين', null, () => { leave(); openXOMenu(); }),
      h('div', { class: 'set-card' },
        h('b', { text: 'أنشئ غرفة' }), h('p', { class: 'hint', text: 'تحصل على كود من ٤ أحرف، أرسله لصديقك ليدخل.' }),
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => host() }, 'إنشاء غرفة')),
      h('div', { class: 'set-card' },
        h('b', { text: 'ادخل غرفة صديقك' }),
        h('div', { class: 'xo-join' }, codeIn, h('button', { type: 'button', class: 'btn', onclick: () => join(codeIn.value) }, 'دخول'))),
      status));

    function waiting(code, text) {
      status.hidden = false;
      status.replaceChildren(h('span', { class: 'xo-spin' }), h('b', { text }),
        ...(code ? [h('div', { class: 'xo-code ltr', text: code }), h('button', { type: 'button', class: 'btn sm', onclick: () => shareCode(code) }, icon('share', { size: 16 }), 'مشاركة الكود')] : []));
    }
    async function connect(code, role) {
      leave();
      const g = gstate();
      const me = S.profile?.nickname || S.profile?.display_name || 'صديقك';
      let started = false;
      const handlers = { onMsg: () => {} };
      net = Cloud.channel('nw-xo-' + code, (m) => {
        if (m.t === 'hi' && !started) {
          started = true;
          const n = net;
          if (role === 'X') n.send({ t: 'hi', name: me, hero: myHero() });
          startXO({ mode: 'online', mine: role, oppName: String(m.name || 'صديقك').slice(0, 20), oppHero: HEROES.some((x) => x.id === m.hero) ? m.hero : '', net: n });
          n.onMsgProxy = true;
        } else handlers.onMsg(m);
      }, (count) => {
        if (count >= 2 && role === 'O' && !started) net?.send({ t: 'hi', name: me, hero: myHero() });
      });
      const n = net;
      Object.defineProperty(n, 'onMsg', { set: (f) => { handlers.onMsg = f; }, get: () => handlers.onMsg });
      try { await n.join(); } catch (e) { toast(e.message, { type: 'error' }); leave(); status.hidden = true; }
    }
    function host() {
      const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
      const code = Array.from({ length: 4 }, () => A[Math.floor(Math.random() * A.length)]).join('');
      waiting(code, 'بانتظار صديقك…');
      connect(code, 'X');
    }
    function join(v) {
      const code = String(v || '').trim().toUpperCase();
      if (!/^[A-Z0-9]{4}$/.test(code)) return toast('الكود ٤ أحرف أو أرقام');
      waiting('', 'جارٍ الاتصال بالغرفة…');
      connect(code, 'O');
    }
  }, { onBack: () => { leave(); openXOMenu(); }, cleanup: () => {} });
}
async function shareCode(code) {
  const text = `تعال نلعب إكس أو في NOBLE 🔥\nكود الغرفة: ${code}`;
  if (Platform.isNative) { try { await Platform.plugin('Share').share({ text, dialogTitle: 'مشاركة الكود' }); return; } catch { return; } }
  try { await navigator.clipboard.writeText(text); toast('تم نسخ الكود', { type: 'success' }); } catch { toast(code); }
}
