/* NOBLE — لوحة الإدارة: «التطبيقات» (الأقسام، روابط التحديث، الإعلانات) و«الاشتراكات» (الأسعار، العروض، الأكواد، طلبات الدفع) */
'use strict';

const MK = { data: null, dirty: false, updated: null, noColumn: false, sub: 'access', stats: null, subs: [], codes: [], discounts: [], pays: [], adStats: {}, payFilter: 'pending', newCodes: [] };
const APP_IDS = ['nobleweb', 'vault', 'tasks', 'finance', 'games', 'azkar'];
const APP_META = {
  nobleweb: { name: 'NOBLE', desc: 'التطبيق الشامل', color: '#8B45F0', pro: 'all', sections: ['sites', 'tasks', 'today', 'news', 'finance', 'games', 'designs', 'azkar', 'discover'] },
  vault: { name: 'خزنة NOBLE', desc: 'المواقع المحفوظة', color: '#2E5BFF', pro: 'vault', sections: ['sites'] },
  tasks: { name: 'مهام NOBLE', desc: 'المهام والتذكيرات', color: '#1FC7A0', pro: 'tasks', sections: ['tasks'] },
  finance: { name: 'مالية NOBLE', desc: 'الحركات والفواتير', color: '#F0922F', pro: 'finance', sections: ['finance'] },
  games: { name: 'ألعاب NOBLE', desc: 'إكس أو ومغامرة اللهب', color: '#C8509C', pro: 'games', sections: ['games'] },
  azkar: { name: 'أذكار NOBLE', desc: 'أذكار وأدعية ومسبحة — مجاني', color: '#0b5c44', pro: 'azkar', sections: ['azkar', 'designs'] },
};
const SEC_NAMES = { sites: 'المواقع', tasks: 'المهام', today: 'يومي', news: 'الأخبار', finance: 'المالية', games: 'الألعاب', designs: 'التصاميم', azkar: 'أذكاري', discover: 'اكتشف' };
/* الأقسام اللي كانت معروفة قبل إضافة «يومي» و«الأخبار» — الحفظ القديم بدونها ما يعني إخفاءها */
const SEC_OLD = ['sites', 'tasks', 'finance', 'games'];
const PLACES = { banner: 'شريط سفلي', card: 'بطاقة في القوائم', inter: 'بين المراحل', reward: 'بمكافأة (اختياري)' };
const PLANS3 = [['m', 'شهري'], ['y', 'سنوي'], ['l', 'مدى الحياة']];
const PRO_APPS = [['vault', 'خزنة'], ['tasks', 'مهام'], ['today', 'يومي'], ['news', 'أخبار'], ['finance', 'مالية'], ['games', 'ألعاب'], ['designs', 'تصاميم'], ['azkar', 'أذكار'], ['all', 'الباقة الكاملة']];
const mkClone = (x) => JSON.parse(JSON.stringify(x));
const sar = (n) => `${UI.n(Math.round((+n || 0) * 100) / 100)} ${MK.data?.currency || 'ر.س'}`;
const dShort = (d) => (d ? new Date(d).toLocaleDateString('ar', { day: 'numeric', month: 'short', year: 'numeric' }) : '—');

async function loadMarket(force) {
  if (MK.data && !force) return;
  try {
    const conf = await Cloud.getConfig();
    MK.noColumn = conf && !('_market' in conf);
    MK.data = Market.merge(mkClone(Market.DEFAULTS), conf?._market || {});
    MK.updated = conf?._updated;
  } catch (e) {
    MK.data = mkClone(Market.DEFAULTS);
    toast('تعذّر التحميل: ' + Cloud.msg(e), { type: 'error' });
  }
}
function mkChanged() {
  MK.dirty = true;
  $$('.mk-status').forEach((s) => (s.textContent = 'تعديلات غير منشورة'));
  $$('.mk-save').forEach((b) => b.classList.add('pulse'));
}
async function saveMarket() {
  try {
    await Cloud.admin.setMarket(MK.data);
    MK.dirty = false; MK.updated = new Date().toISOString();
    $$('.mk-status').forEach((s) => (s.textContent = 'تم النشر ✓'));
    $$('.mk-save').forEach((b) => b.classList.remove('pulse'));
    toast('تم النشر — يصل للتطبيقات فوراً', { type: 'success' });
  } catch (e) { toast(/function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.8.sql أولاً' : Cloud.msg(e), { type: 'error' }); }
}
const mkHero = (title, lead, extra) => h('section', { class: 'a-hero' },
  h('div', {}, h('h1', {}, h('span', { class: 'title-pill', text: title })), h('p', { class: 'lead', text: lead })),
  h('div', { class: 'a-save' }, h('span', { class: 'hint mk-status', text: MK.dirty ? 'تعديلات غير منشورة' : MK.updated ? `آخر نشر ${UI.relTime(new Date(MK.updated).getTime())}` : '' }),
    extra || null, h('button', { type: 'button', class: `btn btn-primary mk-save${MK.dirty ? ' pulse' : ''}`, onclick: saveMarket }, 'نشر التعديلات')));

/* عناصر إدخال مرتبطة بكائن */
function mkInput(obj, key, { type = 'text', ph = '', ltr = false, max = 120, min, cls = '', onChange } = {}) {
  const i = h('input', { class: `input ${ltr ? 'ltr' : ''} ${cls}`, type, placeholder: ph, maxlength: max, min, step: type === 'number' ? 'any' : undefined });
  i.value = obj[key] ?? '';
  i.addEventListener('input', () => { obj[key] = type === 'number' ? (i.value === '' ? '' : Number(i.value)) : i.value; mkChanged(); onChange?.(); });
  return i;
}
const mkField = (label, input, hint) => h('label', { class: 'field' }, h('span', { text: label }), input, hint ? h('small', { class: 'hint', text: hint }) : null);
function mkSwitch(obj, key, label, sub, onChange, { def = true } = {}) {
  const sw = h('input', { type: 'checkbox', checked: def ? obj[key] !== false : !!obj[key] });
  sw.addEventListener('change', () => { obj[key] = sw.checked; mkChanged(); onChange?.(sw.checked); });
  if (!label) return h('label', { class: 'switch' }, sw, h('span', { class: 'track' }));
  return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, sw, h('span', { class: 'track' })));
}
function mkChecks(list, opts, onChange) {
  const cur = new Set(list || []);
  return h('div', { class: 'ga-checks' }, ...opts.map(([v, l]) => {
    const c = h('input', { type: 'checkbox', checked: cur.has(v) });
    c.addEventListener('change', () => { if (c.checked) cur.add(v); else cur.delete(v); onChange([...cur]); });
    return h('label', { class: 'ga-check' }, c, h('span', { text: l }));
  }));
}
const mkCard = (title, ...kids) => h('div', { class: 'set-card mk-card' }, title ? h('div', { class: 'mk-ct' }, ...(Array.isArray(title) ? title : [h('strong', { text: title })])) : null, ...kids.filter(Boolean));
const pill = (t, c) => h('span', { class: `pill mk-pill ${c}`, text: t });

/* ورقة عامة */
let mkSheetEl = null;
function mkSheet(title, kids, foot) {
  if (!mkSheetEl) { mkSheetEl = h('section', { class: 'sheet', id: 'mk-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(mkSheetEl); }
  mkSheetEl.replaceChildren(...[h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(mkSheetEl) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body mk-sheet-body' }, ...kids.filter(Boolean)),
    foot ? h('footer', { class: 'sheet-foot' }, ...foot.filter(Boolean)) : null].filter(Boolean));
  if (!A.sheets.includes(mkSheetEl)) openSheet('#mk-sheet');
  mkSheetEl.scrollTop = 0;
  UI.digitize(mkSheetEl);
}
function toLocalDT(iso) {
  if (!iso) return '';
  const d = new Date(iso); const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(d.getMinutes())}`;
}
function dtInput(obj, key) {
  const i = h('input', { class: 'input ltr', type: 'datetime-local', value: toLocalDT(obj[key]) });
  i.addEventListener('change', () => { obj[key] = i.value ? new Date(i.value).toISOString() : ''; });
  return i;
}

/* أزرار التنقل (1.15): زر الرجوع قريب من الإبهام — الشكل والمكان والأزرار */
/* الأيقونات (1.15): النمط والألوان، أيقونة واسم كل قسم، أيقونات أعلى التطبيق، ومكتبتك */
function iconPicker(title, cur, onPick) {
  let tab = 'lib';
  const body = h('div', { class: 'ik-pick' });
  const paint = () => {
    const C = IconKit.cfg();
    const items = tab === 'lib' ? IconKit.NAMES : tab === 'emoji' ? IconKit.EMOJI : C.lib.map((x) => x.id);
    body.replaceChildren(
      mkSeg([['lib', 'أيقونات NOBLE'], ['emoji', 'إيموجي'], ['mine', `مكتبتك (${UI.n(C.lib.length)})`]], tab, (v) => { tab = v; paint(); }),
      items.length ? h('div', { class: 'ik-grid' }, ...items.map((ic) => h('button', { type: 'button', class: `ik-cell${cur === ic ? ' on' : ''}`, title: ic, onclick: () => { onPick(ic); closeSheet($('#mk-sheet')); } }, IconKit.render(ic, { size: 24 })))) : h('p', { class: 'hint', text: 'مكتبتك فاضية — أضف أيقوناتك من بطاقة «الأيقونات».' }),
      h('button', { type: 'button', class: 'link-btn', onclick: () => { onPick(''); closeSheet($('#mk-sheet')); } }, '↺ رجّع الافتراضي'));
  };
  paint();
  mkSheet(title, [body]);
}
function iconsCard(d) {
  d.icons = { ...IconKit.DEF, ...(d.icons || {}) };
  const I = d.icons;
  I.tabs = I.tabs || {}; I.slots = I.slots || {}; I.lib = Array.isArray(I.lib) ? I.lib : [];
  if (typeof Market !== 'undefined') Market.get().icons = I; // معاينة حيّة بنفس الإعداد
  const box = h('div', { class: 'mk-ik' });
  const ch = () => { mkChanged(); paint(); };
  const color = (val, on) => { const c = h('input', { type: 'color', class: 'mk-color', value: val || '#56C8FF' }); c.addEventListener('input', () => on(c.value)); c.addEventListener('change', ch); return c; };
  const range = (k, min, max, step) => { const r = h('input', { type: 'range', min, max, step, value: I[k] }); r.addEventListener('input', () => { I[k] = Number(r.value); mkChanged(); prev(); }); return r; };
  const pv = h('div', { class: 'ik-prev' });
  const prev = () => {
    const ids = Object.keys(SEC_NAMES).slice(0, 5);
    pv.replaceChildren(h('div', { class: 'ik-top' }, ...['lock', 'settings'].map((k) => h('span', { class: 'ik-tb' }, IconKit.render((I.slots[k] || {}).ic || k, { size: 18, color: (I.slots[k] || {}).color || '' })))),
      h('nav', { class: 'ik-bar' }, ...ids.map((id, i) => {
        const o = I.tabs[id] || {}, on = i === 2;
        const col = !on ? (I.idle || '') : I.color === 'one' ? I.active : I.color === 'each' ? (o.color || IconKit.TAB_COLORS[id]) : '';
        const icEl = IconKit.render(o.ic || (typeof TABS_IC !== 'undefined' ? TABS_IC[id] : SEC_ICN[id]), { size: Number(I.size) || 22, color: col });
        if (on && I.glow) icEl.style.filter = 'drop-shadow(0 0 7px currentColor)';
        return h('span', { class: `ik-bt${on ? ' on' : ''}` }, icEl, h('small', { text: o.label || SEC_NAMES[id] }));
      })));
  };
  const paint = () => {
    const tabRow = (id) => {
      const o = I.tabs[id] = I.tabs[id] || {};
      const lab = h('input', { class: 'input', value: o.label || '', placeholder: SEC_NAMES[id], maxlength: 12 });
      lab.addEventListener('input', () => { o.label = lab.value.trim(); mkChanged(); prev(); });
      return h('div', { class: 'ik-row' },
        h('button', { type: 'button', class: 'ik-cell', title: 'غيّر الأيقونة', onclick: () => iconPicker(`أيقونة ${SEC_NAMES[id]}`, o.ic, (ic) => { o.ic = ic; ch(); }) }, IconKit.render(o.ic || SEC_ICN[id], { size: 22 })),
        lab,
        I.color === 'each' ? color(o.color || IconKit.TAB_COLORS[id], (v) => { o.color = v; prev(); }) : null,
        o.ic || o.label || o.color ? h('button', { type: 'button', class: 'link-btn', onclick: () => { I.tabs[id] = {}; ch(); } }, '↺') : null);
    };
    const slotRow = (k, name) => {
      const o = I.slots[k] = I.slots[k] || {};
      return h('div', { class: 'ik-row' },
        h('button', { type: 'button', class: 'ik-cell', onclick: () => iconPicker(`أيقونة ${name}`, o.ic, (ic) => { o.ic = ic; ch(); }) }, IconKit.render(o.ic || k, { size: 20, color: o.color || '' })),
        h('span', { text: name }), color(o.color || '#ffffff', (v) => { o.color = v; prev(); }),
        o.ic || o.color ? h('button', { type: 'button', class: 'link-btn', onclick: () => { I.slots[k] = {}; ch(); } }, '↺') : null);
    };
    const nm = h('input', { class: 'input', placeholder: 'اسم الأيقونة (مثلاً: شعاري)', maxlength: 30 });
    const src = h('textarea', { class: 'input textarea ltr', rows: 3, placeholder: 'الصق كود SVG هنا، أو رابط صورة https://… (PNG / SVG)' });
    const up = h('input', { type: 'file', accept: 'image/png,image/svg+xml,image/webp', hidden: true });
    up.addEventListener('change', async () => { const f = up.files[0]; if (!f) return; try { if (f.type === 'image/svg+xml' && f.size < 20000) src.value = await f.text(); else { toast('يرفع…'); src.value = await Cloud.admin.designUpload(f, 'icons'); } } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
    box.replaceChildren(
      h('div', { class: 'nk-adm' },
        h('div', { class: 'nk-adm-f' },
          divField('نمط الأيقونات', mkSeg([['line', 'خطي'], ['bold', 'سميك'], ['duo', 'ثنائي اللون']], I.style, (v) => { I.style = v; ch(); })),
          h('div', { class: 'row-2' }, divField(`سُمك الخط (${UI.n(I.stroke)})`, range('stroke', 1.2, 2.6, 0.1)), divField(`حجم أيقونات الشريط (${UI.n(I.size)})`, range('size', 18, 30, 1))),
          divField('الألوان', mkSeg([['theme', 'حسب الثيم'], ['one', 'لون واحد'], ['each', 'لون لكل قسم']], I.color, (v) => { I.color = v; ch(); })),
          h('div', { class: 'row-2' },
            I.color === 'one' ? divField('لون الأيقونة النشطة', color(I.active, (v) => { I.active = v; prev(); })) : null,
            divField('لون غير النشطة', h('div', { class: 'ik-row' }, color(I.idle || '#7d86a5', (v) => { I.idle = v; prev(); }), I.idle ? h('button', { type: 'button', class: 'link-btn', onclick: () => { I.idle = ''; ch(); } }, 'حسب الشكل') : null))),
          mkSwitch(I, 'glow', 'توهّج الأيقونة النشطة', null, () => prev(), { def: false }),
          h('div', { class: 'mk-lbl', text: 'الشريط السفلي — اضغط الأيقونة لتغييرها، وعدّل الاسم' }),
          h('div', { class: 'ik-rows' }, ...Object.keys(SEC_NAMES).map(tabRow)),
          h('div', { class: 'mk-lbl', text: 'أعلى التطبيق' }),
          slotRow('lock', 'زر القفل'), slotRow('settings', 'الإعدادات'),
          h('div', { class: 'mk-lbl', text: `مكتبتك (${UI.n(I.lib.length)})` }),
          I.lib.length ? h('div', { class: 'ik-grid' }, ...I.lib.map((x, i) => h('span', { class: 'ik-cell lib', title: x.name }, IconKit.render(x.id, { size: 24 }), h('button', { type: 'button', class: 'ik-del', 'aria-label': 'حذف', onclick: () => { I.lib.splice(i, 1); ch(); } }, '✕')))) : null,
          h('div', { class: 'ik-add' }, nm, src, h('div', { class: 'ik-row' }, h('button', { type: 'button', class: 'btn sm', onclick: () => up.click() }, '📁 ارفع ملف'), h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => {
            const v = src.value.trim();
            let val = '';
            if (/^https?:\/\//.test(v)) val = v; else val = IconKit.cleanSvg(v);
            if (!val) return toast('الصق كود SVG صحيح أو رابط صورة');
            I.lib.push({ id: 'my-' + Date.now().toString(36), name: nm.value.trim() || 'أيقونتي', src: val }); ch(); toast('انضافت للمكتبة ✓', { type: 'success' });
          } }, '＋ أضف للمكتبة'), up)),
          h('button', { type: 'button', class: 'btn', onclick: async () => { if (!(await confirmSheet({ title: 'رجوع للافتراضي؟', text: 'ترجع كل الأيقونات والأسماء والألوان للأصل (مكتبتك تبقى).', ok: 'رجّع' }))) return; Object.assign(I, { ...IconKit.DEF, lib: I.lib, tabs: {}, slots: {} }); ch(); } }, '↺ الافتراضي')),
        pv));
    prev();
    UI.digitize(box);
  };
  paint();
  return mkCard('🎨 الأيقونات', box);
}
const SEC_ICN = { sites: 'link', tasks: 'checkSquare', today: 'sun', news: 'bolt', finance: 'wallet', games: 'gamepad', designs: 'image', azkar: 'moon', discover: 'play' };
/* المواقع المميزة (1.15): تظهر أعلى قسم المواقع — المستخدم يفتحها أو يحفظها بخزنته */
function featCard(d) {
  d.featured = { on: true, title: '⭐ مواقع مميزة', style: 'row', hideable: true, list: [], ...(d.featured || {}) };
  const F = d.featured;
  const box = h('div', { class: 'mk-feat' });
  const BADGES = [['', 'بدون'], ['new', 'جديد'], ['free', 'مجاني'], ['hot', 'رائج 🔥'], ['pick', 'اختيارنا']];
  const edit = (f) => {
    const o = f ? { ...f } : { id: 'f' + Date.now().toString(36), name: '', url: '', desc: '', ic: '', badge: '', on: true };
    const inp = (k, ph, max = 120, ltr) => { const i = h('input', { class: `input${ltr ? ' ltr' : ''}`, value: o[k] || '', placeholder: ph, maxlength: max }); i.addEventListener('input', () => { o[k] = i.value.trim(); }); return i; };
    const up = h('input', { type: 'file', accept: 'image/*', hidden: true });
    const icPrev = h('span', { class: 'mk-feat-ic' });
    const paintIc = () => icPrev.replaceChildren(o.ic ? (/^https?:/.test(o.ic) ? h('img', { src: o.ic, alt: '' }) : h('b', { text: o.ic })) : h('small', { text: 'تلقائي' }));
    paintIc();
    up.addEventListener('change', async () => { const fl = up.files[0]; if (!fl) return; try { toast('يرفع الأيقونة…'); o.ic = await Cloud.admin.designUpload(fl, 'sites'); paintIc(); toast('انرفعت ✓', { type: 'success' }); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
    const emo = h('input', { class: 'input', placeholder: 'إيموجي 🎨', maxlength: 4, style: { width: '90px' }, value: /^https?:/.test(o.ic || '') ? '' : o.ic || '' });
    emo.addEventListener('input', () => { o.ic = emo.value.trim(); paintIc(); });
    const bd = h('select', { class: 'input' }, ...BADGES.map(([v, l]) => h('option', { value: v, text: l })));
    bd.value = o.badge || ''; bd.addEventListener('change', () => { o.badge = bd.value; });
    mkSheet(f ? 'تعديل موقع مميز' : '⭐ موقع مميز جديد', [
      divField('الاسم', inp('name', 'مثلاً: Behance', 40)),
      divField('الرابط', inp('url', 'https://…', 400, true)),
      divField('وصف قصير', inp('desc', 'ليش هذا الموقع مفيد؟', 120)),
      divField('الأيقونة', h('div', { class: 'mk-feat-icrow' }, icPrev, emo, h('button', { type: 'button', class: 'btn sm', onclick: () => up.click() }, '🖼️ ارفع صورة'), h('button', { type: 'button', class: 'link-btn', onclick: () => { o.ic = ''; emo.value = ''; paintIc(); } }, 'تلقائي'), up), 'تلقائي = أيقونة الموقع نفسه'),
      divField('شارة', bd)],
    [h('button', { type: 'button', class: 'btn btn-primary', onclick: () => {
      const url = Core.normalizeUrl(o.url);
      if (!url) return toast('اكتب رابط صحيح');
      o.url = url; if (!o.name) o.name = Core.domainOf(url);
      const i = F.list.findIndex((x) => x.id === o.id);
      if (i >= 0) F.list[i] = o; else F.list.push(o);
      mkChanged(); closeSheet($('#mk-sheet')); paint(); toast('أُضيف — اضغط «نشر» فوق عشان يوصل للكل', { type: 'success' });
    } }, 'حفظ')]);
  };
  const paint = () => {
    box.replaceChildren(
      h('div', { class: 'row-2' }, mkField('العنوان', mkInput(F, 'title', { max: 40, ph: '⭐ مواقع مميزة' })), divField('الشكل', mkSeg([['row', 'شريط أفقي'], ['grid', 'شبكة']], F.style, (v) => { F.style = v; mkChanged(); }))),
      mkSwitch(F, 'on', 'إظهار المواقع المميزة', 'أعلى قسم المواقع — تختفي وقت البحث'),
      mkSwitch(F, 'hideable', 'المستخدم يقدر يطويها', 'زر «إخفاء» صغير جنب العنوان'),
      h('div', { class: 'mk-feat-list' }, ...(F.list.length ? F.list.map((f, i) => h('div', { class: `mk-ord-row${f.on === false ? ' off' : ''}` },
        h('span', { class: 'mk-ord-n bar', text: UI.n(i + 1) }),
        h('span', { class: 'mk-feat-ic sm' }, f.ic ? (/^https?:/.test(f.ic) ? h('img', { src: f.ic, alt: '' }) : h('b', { text: f.ic })) : h('b', { text: (f.name || '?')[0] })),
        h('span', { class: 'mk-ord-t' }, h('b', { text: f.name }), h('small', { text: f.url.replace(/^https?:\/\//, '') })),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'لأعلى', disabled: i === 0, onclick: () => { [F.list[i - 1], F.list[i]] = [F.list[i], F.list[i - 1]]; mkChanged(); paint(); } }, '▲'),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'تعديل', onclick: () => edit(f) }, icon('edit', { size: 15 })),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { F.list.splice(i, 1); mkChanged(); paint(); } }, icon('trash', { size: 15 })),
        mkSwitch(f, 'on', null, null, () => paint()))) : [h('p', { class: 'hint', text: 'ما فيه مواقع للحين — أضف أول موقع 👇' })])),
      h('button', { type: 'button', class: 'btn', onclick: () => edit(null) }, icon('plus', { size: 15 }), 'أضف موقع مميز'));
    UI.digitize(box);
  };
  paint();
  return mkCard('⭐ المواقع المميزة', box);
}
const divField = (label, el, hint) => h('div', { class: 'field' }, h('span', { text: label }), el, hint ? h('small', { class: 'hint', text: hint }) : null);
function navCard(d) {
  if (typeof NavKit === 'undefined') return null;
  d.nav = { ...NavKit.DEF, ...(d.nav || {}) };
  const N = d.nav;
  const box = h('div', { class: 'mk-nav' });
  const sw = (k, label, sub) => mkSwitch(N, k, label, sub, () => paint());
  const seg = (k, opts) => mkSeg(opts, String(N[k]), (v) => { N[k] = /^\d+$/.test(v) ? Number(v) : v; mkChanged(); paint(); });
  const prev = () => {
    const sd = N.side === 'left' ? 'left' : 'right', sz = Number(N.size) || 54;
    const b = h('span', { class: `nk-prev-b lk-${N.look} ${N.label ? 'pill' : 'circle'}`, style: { '--sz': `${Math.round(sz * 0.8)}px`, '--bc': N.color, [sd]: '10px' } }, h('span', { class: 'bi' }, NavKit.svg(N.icon, Math.round(sz * 0.32))), N.label ? h('span', { text: N.text || 'رجوع' }) : null);
    const tabs = h('span', { class: 'nk-prev-tabs' }, ...[0, 1, 2, 3, 4].map((i) => h('i', { class: N.style === 'tab' && i === (sd === 'right' ? 0 : 4) ? 'bk' : '', style: N.style === 'tab' && i === (sd === 'right' ? 0 : 4) ? { background: N.color } : null })));
    return h('div', { class: 'nk-prev' }, h('span', { class: 'nk-prev-scr' }, h('i'), h('i'), h('i')),
      N.style === 'float' ? b : null,
      N.style === 'bar' ? h('span', { class: `nk-prev-bar${sd === 'left' ? ' rev' : ''}` }, h('b', { style: { background: N.color }, text: N.text || 'رجوع' }), N.forward ? h('i', { text: 'تقدّم' }) : null, N.home ? h('i', { text: '🏠' }) : null) : tabs,
      N.style === 'off' ? h('span', { class: 'nk-prev-off', text: 'الزر القديم فوق فقط' }) : null);
  };
  const paint = () => {
    const icons = h('div', { class: 'nk-icons' }, ...Object.entries(NavKit.ICONS).map(([k, [nm]]) => h('button', { type: 'button', class: N.icon === k ? 'on' : '', title: nm, onclick: () => { N.icon = k; mkChanged(); paint(); } }, NavKit.svg(k, 20))));
    const col = h('input', { type: 'color', class: 'mk-color', value: N.color });
    col.addEventListener('input', () => { N.color = col.value; mkChanged(); box.querySelector('.nk-prev').replaceWith(prev()); });
    box.replaceChildren(
      h('div', { class: 'nk-adm' },
        h('div', { class: 'nk-adm-f' },
          // 1.21.1: زر الرجوع اللي فوق جنب الشعار — أول شي وبشكل واضح
          h('div', { class: 'nk-top-ctl' },
            h('div', {}, h('b', { text: '⬆️ زر الرجوع اللي فوق جنب الشعار' }), h('small', { text: 'لو تبي تشيله من كل الصفحات — زر رجوع الجوال يشتغل عادي' })),
            mkSeg([['show', 'يظهر'], ['hide', 'مخفي']], (N.style === 'off' ? !N.topHide : !!N.top) ? 'show' : 'hide', (v) => { N.top = v === 'show'; N.topHide = v === 'hide'; mkChanged(); paint(); })),
          h('div', { class: 'mk-lbl', text: 'شكل التنقل' }),
          seg('style', NavKit.STYLES.map(([k, t]) => [k, t])),
          h('p', { class: 'hint', text: (NavKit.STYLES.find((x) => x[0] === N.style) || [])[2] || '' }),
          N.style !== 'off' ? h('div', { class: 'nk-adm-g' },
            divField('الكلام', mkInput(N, 'text', { max: 12, ph: 'رجوع', onChange: () => box.querySelector('.nk-prev').replaceWith(prev()) })),
            divField('الأيقونة', icons),
            divField('الشكل', seg('look', Object.entries(NavKit.LOOKS))),
            divField('اللون', col),
            divField('الجهة', seg('side', [['right', 'يمين'], ['left', 'يسار'], ['user', 'حسب يد المستخدم']])),
            divField('الحجم', seg('size', [['44', 'صغير'], ['54', 'متوسط'], ['64', 'كبير']])),
            sw('label', 'نص «رجوع» مع السهم'),
            sw('autohide', 'يختفي وقت النزول ويرجع وقت الصعود', 'عشان ما يغطي المحتوى'),
            sw('forward', '⬅️ زر تقدّم', 'بعد ما يرجع يقدر يتقدّم لنفس الصفحة'),
            sw('home', '🏠 زر الرئيسية', 'يرجع لقسم البداية مباشرة'),
            sw('haptic', 'اهتزاز خفيف مع الرجوع'),
            sw('userCtl', 'المستخدم يغيّر الجهة والحجم', 'من الإعدادات ← المظهر')) : null,
          h('p', { class: 'hint', text: 'زر رجوع الجوال (أندرويد) يشتغل دائماً بنفس الترتيب، وضغطتين للخروج. الألعاب ومحرّر التصاميم لها زر رجوع فوق عشان ما نغطي أزرار اللعب.' })),
        prev()));
  };
  paint();
  return mkCard('🧭 أزرار التنقل', box);
}
/* ترتيب الأقسام لكل تطبيق: أسهم + إظهار/إخفاء + قسم البداية + تطبيق على الكل (1.14.1) */
const SEC_IC = { sites: '🔗', tasks: '✅', today: '☀️', news: '📰', finance: '💰', games: '🎮', designs: '🎨', azkar: '🤍', discover: '▶️' };
function secOrder(id, c, secs) {
  const box = h('div', { class: 'mk-ord' });
  const all = Object.keys(SEC_NAMES);
  const norm = () => {
    const base = Array.isArray(c.order) ? c.order.filter((x) => all.includes(x)) : [...(c.sections || APP_META[id].sections)];
    c.order = [...base, ...all.filter((x) => !base.includes(x))];
    c.sections = c.order.filter((x) => secs.has(x));
    if (!c.sections.includes(c.start)) c.start = c.sections[0] || '';
  };
  const paint = () => {
    norm();
    const BM = Math.min(7, Math.max(4, Number(c.barMax) || 5)), vis = c.sections, many = vis.length > BM;
    let n = 0;
    const rows = [];
    c.order.forEach((k, i) => {
      const on = secs.has(k);
      if (on) n++;
      if (on && many && n === BM) rows.push(h('div', { class: 'mk-ord-div', text: 'داخل «المزيد» ⋯' }));
      const inBar = on && n <= (many ? BM - 1 : BM);
      const mv = (d) => { const j = i + d; if (j < 0 || j >= c.order.length) return; [c.order[i], c.order[j]] = [c.order[j], c.order[i]]; mkChanged(); paint(); };
      const beta = on && (c.beta || []).includes(k);
      const mode = !on ? 'off' : beta ? 'beta' : 'all';
      // الجمهور: الكل · 🧪 المختبرين فقط · مخفي
      const setMode = (m) => {
        if (m === mode) return;
        if (m === 'off' && secs.size === 1) return toast('لازم قسم واحد على الأقل');
        if (m === 'off') secs.delete(k); else secs.add(k);
        c.beta = (c.beta || []).filter((x) => x !== k); c.proSecs = (c.proSecs || []).filter((x) => x !== k); c.custom = (c.custom || []).filter((x) => x !== k);
        if (m === 'beta') { if (k === 'sites') return toast('المواقع قسم أساسي — ما يصير تجريبي'); c.beta.push(k); }
        mkChanged(); paint();
      };
      const aud = h('div', { class: 'mk-aud' }, ...[['all', '👥', 'الكل'], ['beta', '🧪', 'مختبرين'], ['off', '🚫', 'مخفي']].map(([m, ic, l]) =>
        h('button', { type: 'button', class: `mk-aud-b ${m}${mode === m ? ' on' : ''}`, title: l, onclick: () => setMode(m) }, h('i', { text: ic }), h('span', { text: l }))));
      rows.push(h('div', { class: `mk-ord-row${on ? '' : ' off'}${beta ? ' beta' : ''}` },
        h('span', { class: `mk-ord-n${inBar ? ' bar' : ''}`, text: on ? UI.n(n) : '—' }),
        h('span', { class: 'mk-ord-ic', text: SEC_IC[k] || '•' }),
        h('span', { class: 'mk-ord-t' }, h('b', { text: SEC_NAMES[k] }, beta ? h('em', { class: 'mk-beta', text: '🧪 تجريبي' }) : null), h('small', { text: !on ? 'مخفي في هذا التطبيق' : (beta ? 'يظهر للمختبرين فقط · ' : '') + (inBar ? 'في الشريط' : 'في «المزيد»') + (c.start === k ? ' · 🏁 البداية' : '') })),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'لأعلى', disabled: i === 0, onclick: () => mv(-1) }, '▲'),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'لأسفل', disabled: i === c.order.length - 1, onclick: () => mv(1) }, '▼'),
        aud));
    });
    c.beta = (c.beta || []).filter((x) => secs.has(x));
    const st = h('select', { class: 'input' }, ...vis.filter((k) => !c.beta.includes(k)).map((k) => h('option', { value: k, text: `${SEC_IC[k] || ''} ${SEC_NAMES[k]}` })));
    st.value = c.start;
    st.addEventListener('change', () => { c.start = st.value; mkChanged(); paint(); });
    box.replaceChildren(...rows,
      mkField('🏁 قسم البداية — يفتح عليه التطبيق أول ما يشتغل', st),
      h('p', { class: 'hint', text: 'الترتيب يوصل مباشرة للمستخدمين الجدد واللي ما رتّبوا أقسامهم بأنفسهم. اللي رتّب لنفسه يبقى ترتيبه — إلا لو ضغطت «طبّقه على الكل».' }),
      h('button', { type: 'button', class: 'btn sm mk-ord-force', onclick: async () => {
        if (!(await confirmSheet({ title: 'تطبيق الترتيب على الكل؟', text: `كل مستخدمي «${c.name || APP_META[id].name}» يرجع ترتيبهم لهذا الترتيب (مرة وحدة)، وبعدها كل واحد يقدر يرتّب لنفسه.`, ok: 'طبّقه على الكل' }))) return;
        c.orderVer = (Number(c.orderVer) || 0) + 1; mkChanged(); toast('بيتطبّق على الكل بعد الحفظ ✓', { type: 'success' });
      } }, `🔁 طبّقه على الكل${c.orderVer ? ` (آخر مرة: ${UI.n(c.orderVer)})` : ''}`));
  };
  paint();
  return box;
}
/* ================= تبويب التطبيقات ================= */
async function openAppsAdmin() {
  const box = $('#a-apps');
  if (!MK.data) box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  await loadMarket();
  try { MK.subs = can('billing.manage') ? await Cloud.admin.subscribers() : MK.subs; } catch { /* قبل 1.8 */ }
  try { MK.adStats = Object.fromEntries((await Cloud.admin.adStats(30)).map((r) => [r.ad_id, r])); } catch { MK.adStats = {}; }
  renderApps();
}
function appUsage(id) {
  const rows = Object.values(A.ustats || {});
  const mine = rows.filter((r) => (r.stats?.device?.app || 'nobleweb') === id);
  const vers = mine.map((r) => r.version).filter(Boolean).sort((a, b) => (Content.older(a, b) ? 1 : -1));
  const now = Date.now();
  const pro = new Set((MK.subs || []).filter((e) => !e.revoked && (!e.until || new Date(e.until).getTime() > now) && (e.app === 'all' || e.app === APP_META[id].pro)).map((e) => e.user_id)).size;
  return { users: mine.length, version: vers[0] || '—', pro };
}
function renderApps() {
  const d = MK.data;
  d.apps = d.apps || {};
  const box = $('#a-apps');
  const appCard = (id) => {
    const m = APP_META[id];
    const c = d.apps[id] = Market.merge({ name: m.name, sections: m.sections, ads: { house: true, admob: false }, updateUrl: '', minVersion: '', on: true }, d.apps[id] || {});
    const u = appUsage(id);
    // إصلاح الحفظ القديم: الأقسام الجديدة اللي ما كانت موجودة وقتها تُضاف ظاهرة
    // أي قسم جديد ما كانت اللوحة تعرفه وقت آخر حفظ (مثل التصاميم والأذكار في 1.14) يُضاف ظاهر — ما يختفي بالغلط عند أول حفظ
    if (Array.isArray(c.sections) && id === 'nobleweb') {
      const known = Array.isArray(c.sectionsKnown) ? c.sectionsKnown : SEC_OLD;
      c.sections = Object.keys(SEC_NAMES).filter((x) => c.sections.includes(x) || !known.includes(x));
    }
    c.sectionsKnown = Object.keys(SEC_NAMES);
    const secs = new Set(c.sections || m.sections);
    return h('div', { class: 'mk-app' },
      h('div', { class: 'mk-ah' },
        h('span', { class: 'mk-aic', style: { background: `linear-gradient(145deg, ${m.color}, #0B1638)` } }, h('img', { src: (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'), alt: '' })),
        h('div', {}, h('b', { text: c.name || m.name }), h('small', { class: 'ltr', text: `com.nobledesigner.${id}` }))),
      h('div', { class: 'mk-kp' }, h('div', {}, h('b', { class: 'num', text: u.users }), h('small', { text: 'مستخدم' })),
        h('div', {}, h('b', { class: 'num', text: u.pro }), h('small', { text: 'مشترك Pro' })),
        h('div', {}, h('b', { class: 'num', text: u.version }), h('small', { text: 'آخر إصدار' }))),
      mkField('الاسم الظاهر', mkInput(c, 'name', { max: 30 })),
      h('div', { class: 'mk-lbl', text: 'الأقسام: الترتيب والظهور' }),
      secOrder(id, c, secs),
      mkSwitch(c.ads, 'house', 'إعلاناتك الخاصة', 'تختفي تلقائياً لمشتركي Pro'),
      mkSwitch(c.ads, 'admob', 'إعلانات قوقل AdMob', 'تحتاج إصدار أندرويد فيه AdMob — انظر الدليل', null, { def: false }),
      mkField('رابط التحديث (Drive أو مباشر)', mkInput(c, 'updateUrl', { ltr: true, ph: 'https://drive.google.com/…', max: 400 })),
      mkField('أقل إصدار مسموح (تحديث إجباري)', mkInput(c, 'minVersion', { ltr: true, ph: 'مثال 1.8.0', max: 12 })));
  };
  const H = d.ads.house;
  const adRow = (a, i) => {
    const st = MK.adStats[a.id] || {};
    return h('div', { class: 'mk-row' },
      h('span', { class: 'mk-ad-art', style: { background: a.img ? `center/cover url("${a.img}")` : `linear-gradient(145deg, ${APP_META[a.promoteApp]?.color || '#2E5BFF'}, #0B1638)` } }, a.img ? null : h('img', { src: (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'), alt: '' })),
      h('div', { class: 'mk-rt' }, h('b', { text: a.title || '(بدون عنوان)' }), h('small', { text: [(a.placements?.length ? a.placements : Object.keys(PLACES)).map((p) => PLACES[p]).join('، '), a.apps?.length ? a.apps.map((x) => APP_META[x]?.name || x).join('، ') : 'كل التطبيقات'].join(' · ') })),
      h('div', { class: 'mk-rn' }, h('b', { class: 'num', text: `${UI.n(st.clicks || 0)} / ${UI.n(st.views || 0)}` }), h('small', { text: 'نقرات / مشاهدات' })),
      mkSwitch(a, 'on', null, null, null),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'تعديل', onclick: () => adSheet(a) }, icon('edit', { size: 16 })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => { if (await confirmSheet({ title: 'حذف الإعلان؟', text: a.title, ok: 'حذف' })) { H.list.splice(i, 1); mkChanged(); renderApps(); } } }, icon('trash', { size: 16 })));
  };
  const M = d.ads.admob;
  box.replaceChildren(...[
    mkHero('التطبيقات', 'كل تطبيق بأقسامه وإعلاناته ورابط تحديثه — نفس الحساب ونفس الكود. التعديلات تصل للتطبيقات فوراً.'),
    MK.noColumn ? h('p', { class: 'note-box', text: 'شغّل ملف supabase/update-1.8.sql في Supabase أولاً حتى يمكن الحفظ.' }) : null,
    h('div', { class: 'mk-apps' }, ...APP_IDS.map(appCard)),
    testersCard(d),
    navCard(d),
    featCard(d),
    iconsCard(d),
    h('div', { class: 'mk-2col' },
      mkCard([h('strong', { text: 'إعلاناتك الخاصة' }), h('span', { class: 'spacer' }), h('button', { type: 'button', class: 'btn sm', onclick: () => adSheet(null) }, icon('plus', { size: 15 }), 'إعلان جديد')],
        mkSwitch(H, 'on', 'تشغيل إعلاناتك', 'المشترك Pro لا يرى أي إعلان · كل إعلان عليه كلمة «إعلان»'),
        h('div', { class: 'row-2' },
          mkField('بين المراحل: مرة كل … مراحل', mkInput(H, 'freq', { type: 'number', min: 3 }), 'الحد الأدنى ٣ — حتى لا يُزعج اللاعب'),
          mkField('زر التخطّي بعد … ثوانٍ', mkInput(H, 'skip', { type: 'number', min: 3 }), 'من ٣ إلى ١٠')),
        H.list.length ? h('div', { class: 'mk-rows' }, ...H.list.map(adRow)) : h('p', { class: 'hint', text: 'لا توجد إعلانات بعد — أضف إعلاناً لتطبيقاتك أو لخدماتك.' })),
      mkCard([h('strong', { text: 'إعلانات قوقل (AdMob)' }), h('span', { class: 'spacer' }), pill('G — لكل الأعمار', 'g')],
        mkSwitch(M, 'on', 'تشغيل AdMob', 'متوقف افتراضياً — شغّله بعد ضبط الحظر في حساب AdMob', null, { def: false }),
        mkField('معرّف إعلان البانر', mkInput(M, 'banner', { ltr: true, ph: 'ca-app-pub-xxx/yyy', max: 80 })),
        mkField('معرّف الإعلان بين المراحل', mkInput(M, 'inter', { ltr: true, ph: 'ca-app-pub-xxx/yyy', max: 80 })),
        mkField('معرّف إعلان المكافأة', mkInput(M, 'reward', { ltr: true, ph: 'ca-app-pub-xxx/yyy', max: 80 })),
        h('div', { class: 'mk-guide' },
          h('b', { text: 'حتى لا يظهر إعلان غير أخلاقي:' }),
          h('ol', {},
            h('li', { text: 'AdMob ← الإعدادات ← حظر المحتوى ← «تصنيف المحتوى الأعلى» = G (لكل الأعمار).' }),
            h('li', { text: 'حظر الفئات الحساسة: القمار، المواعدة، الكحول، السياسة، الأديان، المحتوى الجنسي، السجائر.' }),
            h('li', { text: 'مركز مراجعة الإعلانات (Ad Review Center): راجع الإعلانات واحظر أي إعلان أو معلن بضغطة.' }),
            h('li', { text: 'الدليل المصوّر الكامل موجود في ملف AdMob-guide ضمن المشروع.' })),
          h('small', { class: 'hint', text: 'ملاحظة: تشغيل AdMob يحتاج إصدار أندرويد مبني بمكتبة AdMob — المفاتيح هنا جاهزة لذلك الإصدار، وحتى ذلك الحين تعمل إعلاناتك الخاصة فقط.' })))),
  ].filter(Boolean));
  UI.digitize(box);
}
function adSheet(src) {
  const H = MK.data.ads.house;
  const a = mkClone(src || { id: 'ad' + Date.now().toString(36), title: '', text: '', img: '', link: '', cta: '', promoteApp: '', placements: ['banner', 'card', 'inter'], apps: [], until: '', on: true });
  const inp = (k, o = {}) => { const i = h('input', { class: `input ${o.ltr ? 'ltr' : ''}`, placeholder: o.ph || '', maxlength: o.max || 120, value: a[k] || '' }); i.addEventListener('input', () => (a[k] = i.value)); return i; };
  const promo = h('select', { class: 'input select' }, h('option', { value: '', text: 'لا — رابط خارجي' }), ...APP_IDS.filter((x) => x !== 'nobleweb').map((x) => h('option', { value: x, text: APP_META[x].name, selected: a.promoteApp === x })));
  promo.addEventListener('change', () => (a.promoteApp = promo.value));
  mkSheet(src ? 'تعديل الإعلان' : 'إعلان جديد', [
    mkField('العنوان', inp('title', { max: 60, ph: 'مثال: جرّب NOBLE مهام' })),
    mkField('النص', inp('text', { max: 120, ph: 'سطر قصير' })),
    mkField('رابط صورة (اختياري)', inp('img', { ltr: true, max: 400, ph: 'https://…/banner.jpg' }), 'بدون صورة يظهر شعار NOBLE بلون التطبيق'),
    mkField('يروّج لتطبيق من تطبيقاتك؟', promo, 'لا يظهر داخل التطبيق نفسه، ويستخدم رابط تحديثه تلقائياً'),
    mkField('الرابط عند الضغط', inp('link', { ltr: true, max: 400, ph: 'https://…' })),
    mkField('نص الزر', inp('cta', { max: 14, ph: 'تحميل / اطلب الآن' })),
    h('div', { class: 'field' }, h('span', { text: 'مكان الظهور' }), mkChecks(a.placements, Object.entries(PLACES), (v) => (a.placements = v))),
    h('div', { class: 'field' }, h('span', { text: 'يظهر في (بدون اختيار = كل التطبيقات)' }), mkChecks(a.apps, APP_IDS.map((x) => [x, APP_META[x].name]), (v) => (a.apps = v))),
    mkField('ينتهي في (اختياري)', dtInput(a, 'until')),
    h('p', { class: 'hint', text: 'لا إعلانات في شاشات الدفع أو الأمان، ولا تظهر لمشتركي Pro.' }),
  ], [h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => {
    if (!a.title.trim()) return toast('اكتب عنوان الإعلان', { type: 'error' });
    const i = H.list.findIndex((x) => x.id === a.id);
    if (i >= 0) H.list[i] = a; else H.list.push(a);
    mkChanged(); closeSheet(mkSheetEl); renderApps(); toast('اضغط «نشر التعديلات» لإرساله للتطبيقات');
  } }, 'حفظ الإعلان')]);
}

/* ================= تبويب الاشتراكات ================= */
const BILL_SECS = [['access', 'الأقسام والتجربة', 'grid'], ['features', 'مزايا كل قسم', 'layers'], ['prices', 'الأسعار', 'tag'], ['offers', 'العروض', 'bolt'], ['discounts', 'أكواد الخصم', 'target'], ['codes', 'أكواد التفعيل', 'lock'], ['payments', 'طلبات الدفع', 'wallet'], ['subs', 'المشتركون', 'users'], ['pay', 'بيانات الدفع', 'receipt']];
async function openBillingAdmin() {
  const box = $('#a-billing');
  if (!MK.data) box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  await loadMarket();
  await loadBilling();
  renderBilling();
}
async function loadBilling() {
  try {
    [MK.stats, MK.subs, MK.codes, MK.discounts, MK.pays] = await Promise.all([Cloud.admin.billingStats(), Cloud.admin.subscribers(), Cloud.admin.codes(), Cloud.admin.discounts(), Cloud.admin.payments(null)]);
    MK.receipts = await Cloud.admin.paymentReceipts();
    MK.missing = false;
  } catch (e) { MK.missing = /function|schema/i.test(e.message || ''); if (!MK.missing) toast(Cloud.msg(e), { type: 'error' }); }
}
function renderBilling() {
  const box = $('#a-billing');
  const s = MK.stats || {};
  const pend = (MK.pays || []).filter((p) => p.status === 'pending').length;
  const kpi = (label, v, cls = '', go) => h('button', { type: 'button', class: `mk-kpi ${cls}`, onclick: go ? () => { MK.sub = go; renderBilling(); } : null }, h('small', { text: label }), h('b', { class: 'num', text: v }));
  box.replaceChildren(...[
    mkHero('الاشتراكات', 'الأسعار والعروض وأكواد الخصم والتفعيل — كلها تتحدّث في التطبيقات فوراً.'),
    MK.missing || MK.noColumn ? h('p', { class: 'note-box', text: 'شغّل ملف supabase/update-1.8.sql في Supabase أولاً لتفعيل الاشتراكات.' }) : null,
    h('div', { class: 'mk-kpis' },
      kpi('إيراد هذا الشهر', sar(s.revenue_month), 'hi'),
      kpi('مشتركون نشطون', UI.n(s.active || 0), '', 'subs'),
      kpi('ينتهي خلال ٧ أيام', UI.n(s.expiring || 0), '', 'subs'),
      kpi('طلبات دفع بانتظارك', UI.n(pend), pend ? 'warn' : '', 'payments')),
    h('nav', { class: 'chips ga-nav' }, ...BILL_SECS.map(([id, l, ic]) => h('button', { type: 'button', class: `chip${MK.sub === id ? ' on' : ''}`, onclick: () => { MK.sub = id; renderBilling(); } }, icon(ic, { size: 15 }), l, id === 'payments' && pend ? h('b', { class: 'mini-badge num', text: pend }) : null))),
    h('div', { class: 'ga-body mk-body', id: 'mk-body' }),
  ].filter(Boolean));
  const body = $('#mk-body');
  ({ access: bAccess, prices: bPrices, offers: bOffers, discounts: bDiscounts, codes: bCodes, payments: bPayments, subs: bSubs, features: bFeatures, pay: bPay })[MK.sub](body);
  UI.digitize(box);
}

function bPrices(body) {
  const d = MK.data;
  const row = ([id, label]) => {
    const p = d.plans[id] = d.plans[id] || { m: 0, y: 0, l: 0, on: true };
    return h('div', { class: 'mk-prow' }, h('b', { text: id === 'all' ? '★ ' + label : Market.APPS[id]?.name || label }),
      ...PLANS3.map(([k]) => mkInput(p, k, { type: 'number', min: 0, cls: 'mk-num' })), mkSwitch(p, 'on', null));
  };
  body.append(
    mkCard(`الأسعار (${d.currency})`,
      h('div', { class: 'mk-prow mk-phead' }, h('span', { text: 'الخطة' }), ...PLANS3.map(([, l]) => h('span', { text: l })), h('span', { text: 'متاحة' })),
      ...PRO_APPS.map(row),
      h('p', { class: 'hint', text: 'الباقة الكاملة تفتح مزايا كل التطبيقات. المشترك يجدد متى شاء، والمدة الجديدة تُضاف على المتبقي.' })),
    mkCard('الخطط المعروضة',
      mkSwitch(d.planOn, 'm', 'الشهري'), mkSwitch(d.planOn, 'y', 'السنوي'), mkSwitch(d.planOn, 'l', 'مدى الحياة'),
      mkField('العملة', mkInput(d, 'currency', { max: 8 }))));
}
function bOffers(body) {
  const d = MK.data;
  const now = Date.now();
  const row = (o, i) => {
    const live = o.on !== false && (!o.until || new Date(o.until).getTime() > now);
    return h('div', { class: 'mk-row' },
      h('span', { class: 'mk-big', text: `−${UI.n(o.pct)}٪` }),
      h('div', { class: 'mk-rt' }, h('b', { text: o.title || 'عرض' }), h('small', { text: [o.plans?.length ? o.plans.map((p) => Market.PLAN_NAME[p]).join(' + ') : 'كل الخطط', o.apps?.length ? o.apps.map((a) => Market.APP_NAME(a)).join('، ') : 'كل التطبيقات'].join(' · ') })),
      h('div', { class: 'mk-rn' }, pill(live ? 'فعّال' : o.on === false ? 'متوقف' : 'انتهى', live ? 'g' : 'r'), h('small', { text: o.until ? `حتى ${dShort(o.until)}` : 'دائم' })),
      mkSwitch(o, 'on', null, null, () => renderBilling()),
      h('button', { type: 'button', class: 'icon-btn sm-ic', onclick: () => offerSheet(o) }, icon('edit', { size: 16 })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', onclick: () => { d.offers.splice(i, 1); mkChanged(); renderBilling(); } }, icon('trash', { size: 16 })));
  };
  body.append(mkCard([h('strong', { text: 'العروض' }), h('span', { class: 'spacer' }), h('button', { type: 'button', class: 'btn sm', onclick: () => offerSheet(null) }, icon('plus', { size: 15 }), 'عرض جديد')],
    d.offers.length ? h('div', { class: 'mk-rows' }, ...d.offers.map(row)) : h('p', { class: 'hint', text: 'لا توجد عروض. العرض يظهر في شاشة الترقية بعدّاد تنازلي وسعر مشطوب.' }),
    h('p', { class: 'hint', text: 'إذا انطبق أكثر من عرض يُطبَّق الأعلى خصماً. كود الخصم يُضاف فوق العرض.' })));
}
function offerSheet(src) {
  const d = MK.data;
  const o = mkClone(src || { id: 'of' + Date.now().toString(36), title: '', text: '', pct: 20, plans: ['y'], apps: [], until: new Date(Date.now() + 3 * 864e5).toISOString(), on: true });
  const t = h('input', { class: 'input', maxlength: 40, value: o.title, placeholder: 'مثال: عرض اليوم الوطني' }); t.addEventListener('input', () => (o.title = t.value));
  const x = h('input', { class: 'input', maxlength: 80, value: o.text, placeholder: 'سطر قصير تحت العنوان' }); x.addEventListener('input', () => (o.text = x.value));
  const pct = h('input', { class: 'input', type: 'number', min: 1, max: 90, value: o.pct }); pct.addEventListener('input', () => (o.pct = Math.max(1, Math.min(90, Number(pct.value) || 0))));
  const until = dtInput(o, 'until');
  const quick = (l, hrs) => h('button', { type: 'button', class: 'chip', onclick: () => { o.until = hrs ? new Date(Date.now() + hrs * 36e5).toISOString() : ''; until.value = toLocalDT(o.until); } }, l);
  mkSheet(src ? 'تعديل العرض' : 'عرض جديد', [
    mkField('عنوان العرض', t), mkField('النص', x), mkField('نسبة الخصم ٪', pct),
    h('div', { class: 'field' }, h('span', { text: 'على الخطط (بدون اختيار = كلها)' }), mkChecks(o.plans, PLANS3, (v) => (o.plans = v))),
    h('div', { class: 'field' }, h('span', { text: 'على (بدون اختيار = كل التطبيقات)' }), mkChecks(o.apps, PRO_APPS, (v) => (o.apps = v))),
    h('div', { class: 'field' }, h('span', { text: 'ينتهي في' }), until, h('div', { class: 'chips ga-quick' }, quick('يوم', 24), quick('٣ أيام', 72), quick('أسبوع', 168), quick('شهر', 720), quick('دائم', 0))),
  ], [h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => {
    const i = d.offers.findIndex((z) => z.id === o.id);
    if (i >= 0) d.offers[i] = o; else d.offers.push(o);
    mkChanged(); closeSheet(mkSheetEl); renderBilling(); toast('اضغط «نشر التعديلات» لتفعيله');
  } }, 'حفظ العرض')]);
}
function bDiscounts(body) {
  const row = (c) => {
    const exp = c.until && new Date(c.until) < new Date();
    return h('div', { class: 'mk-row' },
      h('bdi', { class: 'mk-code', text: c.code }), pill(`−${UI.n(c.pct)}٪`, 'g'),
      h('div', { class: 'mk-rt' }, h('small', { text: [c.plans?.length ? c.plans.map((p) => Market.PLAN_NAME[p]).join('، ') : 'كل الخطط', c.apps?.length ? c.apps.map((a) => Market.APP_NAME(a)).join('، ') : 'كل التطبيقات'].join(' · ') })),
      h('div', { class: 'mk-rn' }, h('b', { class: 'num', text: `${UI.n(c.used)}${c.max_uses ? ' / ' + UI.n(c.max_uses) : ''}` }), h('small', { text: c.until ? (exp ? 'انتهى ' : 'ينتهي ') + dShort(c.until) : 'بدون نهاية' })),
      !c.active ? pill('متوقف', 'r') : exp ? pill('منتهي', 'r') : null,
      h('button', { type: 'button', class: 'icon-btn sm-ic', onclick: () => discSheet(c) }, icon('edit', { size: 16 })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', onclick: async () => { if (await confirmSheet({ title: `حذف ${c.code}؟`, text: 'لن يعمل الكود بعد الآن.', ok: 'حذف' })) { await mkRun(() => Cloud.admin.deleteDiscount(c.code), 'تم الحذف'); } } }, icon('trash', { size: 16 })));
  };
  body.append(mkCard([h('strong', { text: 'أكواد الخصم' }), h('span', { class: 'spacer' }), h('button', { type: 'button', class: 'btn sm', onclick: () => discSheet(null) }, icon('plus', { size: 15 }), 'كود خصم')],
    MK.discounts.length ? h('div', { class: 'mk-rows' }, ...MK.discounts.map(row)) : h('p', { class: 'hint', text: 'لا توجد أكواد خصم. أنشئ كوداً للمؤثرين أو العملاء (مثل NOBLE10).' }),
    h('p', { class: 'hint', text: 'يُحسب الاستخدام عند موافقتك على طلب الدفع.' })));
}
function discSheet(src) {
  const c = src ? { ...src, max: src.max_uses } : { code: '', pct: 10, apps: [], plans: [], max: '', until: '', active: true };
  const code = h('input', { class: 'input ltr', maxlength: 30, value: c.code, placeholder: 'NOBLE10', disabled: !!src }); code.addEventListener('input', () => (c.code = code.value.toUpperCase().replace(/\s/g, '')));
  const pct = h('input', { class: 'input', type: 'number', min: 1, max: 100, value: c.pct }); pct.addEventListener('input', () => (c.pct = Number(pct.value) || 0));
  const max = h('input', { class: 'input', type: 'number', min: 1, value: c.max || '', placeholder: 'بلا حد' }); max.addEventListener('input', () => (c.max = Number(max.value) || null));
  const act = h('input', { type: 'checkbox', checked: c.active !== false }); act.addEventListener('change', () => (c.active = act.checked));
  mkSheet(src ? `تعديل ${src.code}` : 'كود خصم جديد', [
    mkField('الكود', code), mkField('الخصم ٪', pct, '١٠٠٪ = الاشتراك يتفعّل مباشرة بدون دفع (مرة وحدة لكل شخص، ويُحسب من «أقصى عدد استخدام»)'), mkField('أقصى عدد استخدام', max),
    h('div', { class: 'field' }, h('span', { text: 'على الخطط (بدون اختيار = كلها)' }), mkChecks(c.plans, PLANS3, (v) => (c.plans = v))),
    h('div', { class: 'field' }, h('span', { text: 'على (بدون اختيار = الكل)' }), mkChecks(c.apps, PRO_APPS, (v) => (c.apps = v))),
    mkField('ينتهي في (اختياري)', dtInput(c, 'until')),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'فعّال' })), h('span', { class: 'switch' }, act, h('span', { class: 'track' }))),
  ], [h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
    if (!/^[A-Z0-9_-]{3,30}$/.test(c.code || '')) return toast('الكود ٣ أحرف على الأقل (إنجليزي وأرقام)', { type: 'error' });
    if (!(c.pct >= 1 && c.pct <= 100)) return toast('الخصم من ١ إلى ١٠٠', { type: 'error' });
    closeSheet(mkSheetEl);
    await mkRun(() => Cloud.admin.setDiscount(c), 'تم حفظ الكود');
  } }, 'حفظ')]);
}
async function mkRun(fn, done) {
  try { await fn(); toast(done, { type: 'success' }); await loadBilling(); renderBilling(); }
  catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
function bCodes(body) {
  const g = MK.gen = MK.gen || { n: 5, app: 'finance', plan: 'y', price: '', note: '' };
  const sel = (key, opts) => { const s = h('select', { class: 'input select' }, ...opts.map(([v, l]) => h('option', { value: v, text: l, selected: g[key] === v }))); s.addEventListener('change', () => { g[key] = s.value; if (key !== 'n') { g.price = MK.data.plans?.[g.app]?.[g.plan] ?? ''; price.value = g.price; } }); return s; };
  const n = h('input', { class: 'input mk-num', type: 'number', min: 1, max: 100, value: g.n }); n.addEventListener('input', () => (g.n = Number(n.value) || 1));
  if (g.price === '') g.price = MK.data.plans?.[g.app]?.[g.plan] ?? 0;
  const price = h('input', { class: 'input mk-num', type: 'number', min: 0, value: g.price }); price.addEventListener('input', () => (g.price = Number(price.value) || 0));
  const note = h('input', { class: 'input', maxlength: 60, value: g.note, placeholder: 'ملاحظة (اسم العميل / رقم التحويل)' }); note.addEventListener('input', () => (g.note = note.value));
  const ST = { new: ['غير مستخدم', 'b'], used: ['مُفعّل', 'g'], revoked: ['ملغي', 'r'] };
  const q = h('input', { class: 'input mk-search', placeholder: 'بحث بالكود أو الإيميل' });
  const list = h('div', { class: 'mk-rows' });
  const paint = () => {
    const k = q.value.trim().toUpperCase();
    const rows = MK.codes.filter((c) => !k || c.code.includes(k) || (c.used_email || '').toUpperCase().includes(k) || (c.note || '').toUpperCase().includes(k)).slice(0, 200);
    list.replaceChildren(...(rows.length ? rows.map((c) => h('div', { class: 'mk-row' },
      h('bdi', { class: 'mk-code', text: c.code }),
      h('div', { class: 'mk-rt' }, h('b', { text: `${Market.APP_NAME(c.app)} · ${Market.PLAN_NAME[c.plan] || c.plan}` }), h('small', { text: [c.price ? sar(c.price) : '', c.note, dShort(c.created_at)].filter(Boolean).join(' · ') })),
      h('div', { class: 'mk-rn' }, pill(ST[c.status][0], ST[c.status][1]), c.used_email ? h('small', { class: 'ltr', text: c.used_email }) : null),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'نسخ', onclick: () => copyTxt(c.code) }, icon('copy', { size: 16 })),
      c.status === 'new' ? h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'إلغاء', onclick: async () => { if (await confirmSheet({ title: `إلغاء ${c.code}؟`, text: 'لن يمكن استخدامه.', ok: 'إلغاء الكود' })) mkRun(() => Cloud.admin.revokeCode(c.code), 'تم إلغاء الكود'); } }, icon('x', { size: 16 })) : null))
      : [h('p', { class: 'hint', text: 'لا توجد أكواد.' })]));
    UI.digitize(list);
  };
  q.addEventListener('input', paint);
  body.append(
    mkCard('أكواد التفعيل — بعد التحويل البنكي / STC Pay',
      h('div', { class: 'mk-gen' }, h('span', { text: 'أنشئ' }), n, h('span', { text: 'أكواد لـ' }), sel('app', PRO_APPS.map(([v]) => [v, Market.APP_NAME(v)])), sel('plan', PLANS3), h('span', { text: 'بسعر' }), price,
        h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
          try {
            MK.newCodes = await Cloud.admin.genCodes(Math.max(1, Math.min(100, g.n)), g.app, g.plan, g.price, g.note);
            await copyTxt(MK.newCodes.join('\n'), false);
            toast(`تم توليد ${UI.n(MK.newCodes.length)} كود ونسخها ✓`, { type: 'success' });
            await loadBilling(); renderBilling();
          } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
        } }, 'توليد ونسخ')),
      note,
      MK.newCodes.length ? h('div', { class: 'mk-new' }, h('b', { text: 'الأكواد الجديدة:' }), h('pre', { class: 'ltr', text: MK.newCodes.join('\n') }),
        h('button', { type: 'button', class: 'btn sm', onclick: () => copyTxt(MK.newCodes.join('\n')) }, icon('copy', { size: 15 }), 'نسخ الكل')) : null,
      h('p', { class: 'hint', text: 'أرسل الكود للعميل — يدخله من «الترقية ← عندك كود تفعيل؟». كل كود يُستخدم مرة واحدة.' }),
      h('button', { type: 'button', class: 'btn', onclick: () => grantProSheet(null) }, icon('bolt', { size: 16 }), 'أو امنح أقساماً لمستخدم مباشرة')),
    mkCard([h('strong', { text: `كل الأكواد (${UI.n(MK.codes.length)})` }), h('span', { class: 'spacer' }), q], list));
  paint();
}
async function copyTxt(t, say = true) {
  try { await navigator.clipboard.writeText(t); if (say) toast('تم النسخ', { type: 'success', duration: 1500 }); } catch { /* لا شيء */ }
}
/* عرض إيصال التحويل (رابط مؤقت من المخزن الخاص) */
async function receiptView(p, path) {
  mkSheet(`🧾 إيصال ${p.name || p.email || ''}`, [h('p', { class: 'hint', text: 'جارٍ التحميل…' })]);
  try {
    const url = await Cloud.admin.receiptURL(path);
    const pdf = /\.pdf$/i.test(path);
    mkSheet(`🧾 إيصال ${p.name || p.email || ''}`, [
      h('div', { class: 'mk-rc-sum' }, h('b', { class: 'num', text: sar(p.amount) }), h('small', { text: `${Market.APP_NAME(p.app)} · ${Market.PLAN_NAME[p.plan] || p.plan}${p.ref ? ' · رقم العملية ' + p.ref : ''}` })),
      pdf ? h('a', { class: 'btn', href: url, target: '_blank', rel: 'noopener' }, '📄 افتح الإيصال (PDF)') : h('a', { href: url, target: '_blank', rel: 'noopener' }, h('img', { class: 'mk-rc-img', src: url, alt: 'الإيصال' })),
    ], p.status === 'pending' ? [h('button', { type: 'button', class: 'btn btn-primary', onclick: () => { closeSheet($('#mk-sheet')); mkRun(() => Cloud.admin.decidePayment(p.id, true), `تم تفعيل Pro لـ ${p.name || p.email} ✓`); } }, '✓ وصل المبلغ — فعّل')] : null);
  } catch (e) { mkSheet('🧾 الإيصال', [h('p', { class: 'note-box', text: 'تعذّر فتح الإيصال: ' + Cloud.msg(e) })]); }
}
function bPayments(body) {
  const f = MK.payFilter;
  const list = (MK.pays || []).filter((p) => f === 'all' || p.status === f);
  const ST = { pending: ['بانتظار المراجعة', 'o'], approved: ['تمت الموافقة', 'g'], rejected: ['مرفوض', 'r'] };
  const row = (p) => h('div', { class: `mk-pay st-${p.status}` },
    h('div', { class: 'mk-pay-h' }, h('b', { text: p.name || p.email || '—' }), h('small', { class: 'ltr', text: p.email || '' }), h('span', { class: 'spacer' }), pill(ST[p.status][0], ST[p.status][1])),
    h('div', { class: 'mk-pay-g' },
      h('div', {}, h('small', { text: 'الاشتراك' }), h('b', { text: `${Market.APP_NAME(p.app)} · ${Market.PLAN_NAME[p.plan] || p.plan}` })),
      h('div', {}, h('small', { text: 'المبلغ' }), h('b', { class: 'num', text: sar(p.amount) })),
      h('div', {}, h('small', { text: 'الطريقة' }), h('b', { text: p.method === 'stc' ? 'STC Pay' : 'تحويل بنكي' })),
      h('div', {}, h('small', { text: 'رقم العملية' }), h('bdi', { text: p.ref || '—' }))),
    (MK.receipts || {})[p.id] ? h('button', { type: 'button', class: 'btn sm mk-rc', onclick: () => receiptView(p, MK.receipts[p.id]) }, '🧾 عرض الإيصال') : p.status === 'pending' ? h('small', { class: 'hint', text: '🧾 بدون إيصال' }) : null,
    p.discount ? h('small', { class: 'hint', text: `كود خصم: ${p.discount}` }) : null,
    p.note ? h('p', { class: 'mk-note', text: p.note }) : null,
    h('div', { class: 'mk-pay-f' }, h('small', { class: 'hint', text: `${dShort(p.created_at)}${p.decided_at ? ' · قُرّر ' + dShort(p.decided_at) : ''}` }), h('span', { class: 'spacer' }),
      p.status === 'pending' ? h('button', { type: 'button', class: 'btn sm btn-danger-ghost', onclick: async () => { if (await confirmSheet({ title: 'رفض الطلب؟', text: 'تأكد أن التحويل لم يصل.', ok: 'رفض' })) mkRun(() => Cloud.admin.decidePayment(p.id, false), 'تم الرفض'); } }, 'رفض') : null,
      p.status === 'pending' ? h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => mkRun(() => Cloud.admin.decidePayment(p.id, true), `تم تفعيل Pro لـ ${p.name || p.email} ✓`) }, icon('check', { size: 15 }), 'وصل المبلغ — فعّل') : null));
  body.append(mkCard([h('strong', { text: 'طلبات الدفع' }), h('span', { class: 'spacer' }),
    h('div', { class: 'seg seg-3 seg-mini' }, ...[['pending', 'بانتظارك'], ['approved', 'مقبولة'], ['all', 'الكل']].map(([v, l]) => h('label', {}, h('input', { type: 'radio', name: 'mk-pf', checked: f === v, onchange: () => { MK.payFilter = v; renderBilling(); } }), h('span', { text: l }))))],
    list.length ? h('div', { class: 'mk-pays' }, ...list.map(row)) : h('p', { class: 'hint', text: f === 'pending' ? 'لا توجد طلبات بانتظارك 👌' : 'لا توجد طلبات.' }),
    h('p', { class: 'hint', text: 'عند الموافقة يتفعّل Pro عند المستخدم فوراً على كل أجهزته — بدون كود.' })));
}
function bSubs(body) {
  const now = Date.now();
  const q = h('input', { class: 'input mk-search', placeholder: 'بحث بالإيميل' });
  const list = h('div', { class: 'mk-rows' });
  const SRC = { code: 'كود', payment: 'تحويل', admin: 'يدوي', gateway: 'بوابة', discount: 'خصم 100٪' };
  const paint = () => {
    const k = q.value.trim().toLowerCase();
    const rows = (MK.subs || []).filter((e) => !k || (e.email || '').toLowerCase().includes(k) || (e.name || '').toLowerCase().includes(k));
    list.replaceChildren(...(rows.length ? rows.map((e) => {
      const live = !e.revoked && (!e.until || new Date(e.until).getTime() > now);
      const soon = live && e.until && new Date(e.until).getTime() - now < 7 * 864e5;
      return h('div', { class: 'mk-row' },
        h('div', { class: 'mk-rt' }, h('b', { text: e.name || e.email || '—' }), h('small', { class: 'ltr', text: e.email || '' })),
        h('div', { class: 'mk-rt' }, h('b', { text: `${Market.APP_NAME(e.app)} · ${Market.PLAN_NAME[e.plan] || e.plan}` }), h('small', { text: `${SRC[e.source] || e.source}${e.amount ? ' · ' + sar(e.amount) : ''} · ${dShort(e.created_at)}` })),
        h('div', { class: 'mk-rn' }, pill(e.revoked ? 'ملغي' : !live ? 'منتهي' : soon ? 'ينتهي قريباً' : 'نشط', e.revoked || !live ? 'r' : soon ? 'o' : 'g'), h('small', { text: e.until ? 'حتى ' + dShort(e.until) : 'مدى الحياة' })),
        live ? h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'إلغاء', onclick: async () => { if (await confirmSheet({ title: 'إلغاء الاشتراك؟', text: `${e.email} — ${Market.APP_NAME(e.app)}`, ok: 'إلغاء الاشتراك' })) mkRun(() => Cloud.admin.revokeEnt(e.id), 'تم الإلغاء'); } }, icon('x', { size: 16 })) : null);
    }) : [h('p', { class: 'hint', text: 'لا يوجد مشتركون بعد.' })]));
    UI.digitize(list);
  };
  q.addEventListener('input', paint);
  const by = MK.stats?.by_app || {};
  body.append(
    h('div', { class: 'mk-byapp' }, ...PRO_APPS.map(([k]) => h('div', {}, h('b', { class: 'num', text: UI.n(by[k] || 0) }), h('small', { text: Market.APP_NAME(k) })))),
    mkCard([h('strong', { text: 'المشتركون' }), h('span', { class: 'spacer' }), q, h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => grantProSheet(null) }, icon('plus', { size: 15 }), 'منح أقسام لمستخدم')], list));
  paint();
}
/* عنصر اختيار (أزرار متجاورة) مرتبط بقيمة */
function mkSeg(opts, cur, onPick) {
  const box = h('div', { class: 'seg3 mk-seg' });
  const paint = (v) => box.replaceChildren(...opts.map(([val, l]) => h('button', { type: 'button', class: v === val ? 'on' : '', onclick: () => { onPick(val); paint(val); } }, l)));
  paint(cur);
  return box;
}
const SEC_ROWS = [['vault', '🔗 المواقع'], ['tasks', '✅ المهام'], ['today', '☀️ يومي'], ['news', '⚡ الأخبار'], ['finance', '💰 المالية'], ['games', '🎮 الألعاب'], ['designs', '🎨 التصاميم'], ['azkar', '🤍 أذكاري']];
function bAccess(body) {
  const d = MK.data;
  d.access = Market.merge(mkClone(Market.DEFAULTS.access), d.access || {});
  const A2 = d.access;
  const priceIn = (app, k) => { d.plans[app] = d.plans[app] || { m: 0, y: 0, l: 0 }; return mkInput(d.plans[app], k, { type: 'number', min: 0, cls: 'mk-num' }); };
  const secRow = ([app, label]) => {
    A2.sections[app] = A2.sections[app] || { mode: 'paid' };
    const paid = A2.sections[app].mode !== 'free';
    const row = h('div', { class: 'mk-arow' }, h('b', { text: label }),
      mkSeg([['free', 'مجاني'], ['paid', 'مدفوع']], A2.sections[app].mode, (v) => { A2.sections[app].mode = v; d.plans[app] = { ...(d.plans[app] || {}), on: v === 'paid' }; mkChanged(); renderBilling(); }),
      paid ? priceIn(app, 'm') : h('span', { class: 'mk-dash', text: '—' }), paid ? priceIn(app, 'y') : h('span', { class: 'mk-dash', text: '—' }));
    return row;
  };
  const T = A2.trial;
  const mode = T.until ? 'date' : String(T.days);
  const until = dtInput(T, 'until');
  until.addEventListener('change', mkChanged);
  const days = mkInput(T, 'days', { type: 'number', min: 1, cls: 'mk-num' });
  body.append(
    mkCard('الأقسام',
      h('div', { class: 'mk-arow mk-ahead' }, h('span', { text: 'القسم' }), h('span', { text: 'النوع' }), h('span', { text: 'شهري' }), h('span', { text: 'سنوي' })),
      ...SEC_ROWS.map(secRow),
      h('div', { class: 'mk-arow' }, h('b', { text: '★ الكل' }), h('small', { class: 'hint', text: 'كل الأقسام المدفوعة' }), priceIn('all', 'm'), priceIn('all', 'y')),
      h('p', { class: 'hint', text: 'المدفوع: يقفل بعد فترة التجربة (والبيانات تبقى). داخل كل قسم تقدر تخلي مزايا معيّنة مجانية من «مزايا كل قسم». السعر الثالث (مدى الحياة) والعروض من تبويب «الأسعار».' })),
    mkCard([h('strong', { text: '⏳ فترة التجربة المجانية' }), h('span', { class: 'spacer' }), mkSwitch(T, 'on', null, null, () => renderBilling())],
      mkSeg([['7', 'أسبوع'], ['14', 'أسبوعين'], ['30', 'شهر'], ['custom', 'مخصص'], ['date', 'حتى تاريخ']], ['7', '14', '30'].includes(mode) ? mode : mode === 'date' ? 'date' : 'custom', (v) => {
        if (v === 'date') { T.until = T.until || new Date(Date.now() + 14 * 864e5).toISOString(); } else { T.until = ''; if (v !== 'custom') T.days = Number(v); }
        mkChanged(); renderBilling();
      }),
      T.until ? mkField('تنتهي التجربة للجميع في', until) : mkField('عدد الأيام', days),
      h('p', { class: 'hint', text: 'تبدأ التجربة لكل مستخدم من أول فتح للتحديث (والجدد من التسجيل)، ولا تتصفّر بحذف التطبيق. تقدر تمدّد أو تنهي تجربة أي شخص من «المشتركون» أو من بطاقة المستخدم.' })),
    promosCard(d),
    proBtnCard(d),
    renewCard(d),
    offlineCard(A2));
}
/* العمل بدون نت: المشترك دائماً، وغير المشترك حسب اختيارك لكل قسم */
function offlineCard(A2) {
  A2.offline = A2.offline && typeof A2.offline === 'object' ? A2.offline : {};
  const F = A2.offline.free = A2.offline.free && typeof A2.offline.free === 'object' ? A2.offline.free : {};
  const secs = SEC_ROWS.map(([app, label]) => [Market.SEC_OF[app] || app, label]);
  const on = (sec) => F[sec] !== false;
  const all = (v) => { secs.forEach(([sec]) => (F[sec] = v)); mkChanged(); renderBilling(); };
  return mkCard('📴 العمل بدون نت',
    h('div', { class: 'mk-off-sub' }, h('b', { text: '★ المشترك وفترة التجربة' }), h('span', { text: 'كل الأقسام تشتغل بدون نت دائماً، وتتزامن أول ما يرجع الاتصال.' })),
    h('div', { class: 'mk-lbl', text: 'غير المشترك — الأقسام اللي تشتغل له بدون نت' }),
    h('div', { class: 'mk-chips' }, ...secs.map(([sec, label]) => h('button', { type: 'button', class: `mk-chip ${on(sec) ? 'on' : ''}`, onclick: () => { F[sec] = !on(sec); mkChanged(); renderBilling(); } }, (on(sec) ? '✓ ' : '📴 ') + label))),
    h('div', { class: 'mk-chips', style: { marginTop: '8px' } },
      h('button', { type: 'button', class: 'btn sm', onclick: () => all(true) }, 'كلها تشتغل بدون نت'),
      h('button', { type: 'button', class: 'btn sm', onclick: () => all(false) }, 'ولا قسم — للمشتركين فقط')),
    h('p', { class: 'hint', text: 'القسم الموقوف: لما ينقطع النت عن غير المشترك تطلع له رسالة «يحتاج اتصال — أو اشترك ويشتغل بدون نت»، وبياناته تبقى محفوظة على جواله ويرجع لها أول ما يتصل. فتح التطبيق بكلمة المرور يشتغل دائماً.' }));
}
function bFeatures(body) {
  const d = MK.data;
  d.access = Market.merge(mkClone(Market.DEFAULTS.access), d.access || {});
  const F = d.access.features;
  const byApp = {};
  Object.entries(Market.FEATURES).forEach(([k, f]) => (byApp[f.app] = byApp[f.app] || []).push([k, f]));
  const row = ([k, f]) => {
    const cur = { mode: F[k]?.mode || f.mode, limit: F[k]?.limit ?? f.limit };
    const lim = h('input', { class: 'input mk-num', type: 'number', min: 0, value: cur.limit || '', placeholder: '∞' });
    lim.addEventListener('input', () => { F[k] = { ...cur, ...(F[k] || {}), limit: Number(lim.value) || 0 }; mkChanged(); });
    return h('div', { class: 'mk-frow' }, h('div', { class: 'mk-rt' }, h('b', { text: f.label }), f.core ? h('small', { text: 'أساسية' }) : null),
      mkSeg([['free', 'مجاني'], ['paid', 'مدفوع'], ['hidden', 'مخفي']], cur.mode, (v) => { F[k] = { ...cur, ...(F[k] || {}), mode: v }; mkChanged(); }),
      f.unit ? h('label', { class: 'mk-lim' }, lim, h('small', { text: f.unit })) : h('span', { class: 'mk-dash', text: '—' }));
  };
  body.append(
    h('p', { class: 'note-box', text: '«مجاني» للكل · «مدفوع» يحتاج اشتراك القسم (أو الكل) · «مخفي» لا يظهر. الحد = كم يستخدم مجاناً قبل ما يطلب الاشتراك (فارغ = بلا حد للمجاني، وصفر للمدفوع). خلال فترة التجربة كل المزايا مفتوحة. أي ميزة جديدة نضيفها في التحديثات تظهر هنا تلقائياً.' }),
    h('div', { class: 'mk-2col' }, ...SEC_ROWS.map(([app, label]) => byApp[app] ? mkCard(label, ...byApp[app].map(row)) : null).filter(Boolean)));
}
function bPay(body) {
  const p = MK.data.pay;
  body.append(mkCard('بيانات الدفع — تظهر للمستخدم عند الاشتراك',
    h('div', { class: 'row-2' }, mkField('اسم البنك', mkInput(p, 'bank', { max: 40, ph: 'مصرف الراجحي' })), mkField('اسم المستفيد', mkInput(p, 'holder', { max: 60 }))),
    mkField('رقم الآيبان', mkInput(p, 'iban', { ltr: true, max: 34, ph: 'SA00 0000 0000 0000 0000 0000' })),
    mkField('رقم STC Pay', mkInput(p, 'stc', { ltr: true, max: 20, ph: '05xxxxxxxx' })),
    mkField('واتساب للاستفسار ومتابعة الطلبات', mkInput(p, 'whatsapp', { ltr: true, max: 20, ph: '9665xxxxxxxx' }), 'بالصيغة الدولية بدون + (مثال 966550000000) — يظهر زر «استفسار» في صفحة الدفع'),
    divField('🧾 إيصال التحويل', mkSeg([['required', 'إجباري قبل التأكيد'], ['optional', 'اختياري']], p.receipt || 'required', (v) => { p.receipt = v; mkChanged(); })),
    mkField('ملاحظة تحت بيانات الدفع', mkInput(p, 'note', { max: 160 }))),
  mkCard('بوابة الدفع (مدى / Apple Pay)',
    h('p', { class: 'hint', text: 'تُفعَّل عند جاهزية السجل التجاري والربط مع Moyasar أو Tap — حالياً تظهر للمستخدم «قريباً».' })));
}

/* وصول مستخدم: التجربة + منح/قفل الأقسام لتاريخ معيّن */
function pickUserThen(fn) {
  const email = h('input', { class: 'input ltr', placeholder: 'email@example.com', list: 'mk-emails' });
  const dl = h('datalist', { id: 'mk-emails' }, ...(A.users || []).slice(0, 800).map((x) => h('option', { value: x.email })));
  mkSheet('اختر المستخدم', [mkField('الإيميل', email), dl], [h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => {
    const u = (A.users || []).find((x) => (x.email || '').toLowerCase() === email.value.trim().toLowerCase());
    if (!u) return toast('ما لقينا مستخدماً بهذا الإيميل', { type: 'error' });
    closeSheet(mkSheetEl); setTimeout(() => fn(u), 230);
  } }, 'متابعة')]);
}
const grantProSheet = (u) => (u ? userAccessSheet(u) : pickUserThen(userAccessSheet));
async function userAccessSheet(u) {
  await loadMarket();
  let info = {};
  try { info = await Cloud.admin.userAccess(u.id); } catch (e) { return toast(/function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.9.sql أولاً' : Cloud.msg(e), { type: 'error' }); }
  const T = MK.data.access?.trial || Market.DEFAULTS.access.trial;
  const acc = info.access || {};
  const trialEnd = acc.trial_until ? new Date(acc.trial_until) : T.on === false ? null : T.until ? new Date(T.until) : new Date(new Date(acc.trial_from || Date.now()).getTime() + (Number(T.days) || 14) * 864e5);
  const now = Date.now();
  const ents = (info.ents || []).filter((e) => !e.until || new Date(e.until).getTime() > now);
  const entOf = (app) => ents.filter((e) => e.app === app);
  const tEnd = { until: trialEnd ? trialEnd.toISOString() : '' };
  const tIn = dtInput(tEnd, 'until');
  const reload = () => { closeSheet(mkSheetEl); setTimeout(() => userAccessSheet(u), 240); };
  const act = async (fn, msg) => { try { await fn(); toast(msg, { type: 'success' }); if (A.tab === 'billing') { loadBilling().then(renderBilling); } reload(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  const secRow = ([app, label]) => {
    const mode = Market.get().access?.sections?.[app]?.mode || MK.data.access?.sections?.[app]?.mode || 'paid';
    const own = entOf(app), viaAll = entOf('all');
    const forever = [...own, ...viaAll].some((e) => !e.until);
    const last = [...own, ...viaAll].map((e) => e.until).filter(Boolean).sort().pop();
    const state = mode === 'free' ? 'free' : own.length || viaAll.length ? 'on' : trialEnd && trialEnd.getTime() > now ? 'trial' : 'locked';
    const d = { until: own.find((e) => e.source === 'admin')?.until || '' };
    const din = dtInput(d, 'until');
    return h('div', { class: 'mk-urow' },
      h('div', { class: 'mk-rt' }, h('b', { text: label }), h('small', { text: { free: 'مجاني للجميع', on: forever ? 'مفعّل بدون نهاية' : `مفعّل حتى ${dShort(last)}`, trial: `تجربة حتى ${dShort(trialEnd)}`, locked: 'مقفل' }[state] + (viaAll.length && !own.length ? ' (عبر «الكل»)' : '') })),
      mode === 'free' ? h('span', { class: 'mk-dash', text: '—' }) : h('div', { class: 'mk-uact' }, din,
        h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => act(() => Cloud.admin.grantSection(u.id, app, d.until || null, 'منح من الإدارة'), `تم منح ${label} ${d.until ? 'حتى ' + dShort(d.until) : 'بدون نهاية'} ✓`) }, 'امنح'),
        own.length ? h('button', { type: 'button', class: 'btn sm btn-danger-ghost', onclick: () => act(() => Cloud.admin.lockSection(u.id, app), `تم قفل ${label}`) }, 'اقفل') : null));
  };
  mkSheet(`أقسام ${nameOf(u)}`, [
    h('p', { class: 'hint', text: `${u.email} · بدأ التجربة ${dShort(acc.trial_from)}` }),
    mkCard('⏳ فترة التجربة',
      h('p', { class: 'hint', text: trialEnd ? (trialEnd.getTime() > now ? `تنتهي ${dShort(trialEnd)}` : `انتهت ${dShort(trialEnd)}`) : 'التجربة متوقفة' }),
      mkField('نهاية التجربة لهذا المستخدم', tIn),
      h('div', { class: 'mk-uact' },
        h('button', { type: 'button', class: 'btn sm', onclick: () => act(() => Cloud.admin.setTrial(u.id, new Date(Math.max(now, trialEnd?.getTime() || now) + 7 * 864e5).toISOString()), 'تم تمديد التجربة ٧ أيام') }, '+٧ أيام'),
        h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => act(() => Cloud.admin.setTrial(u.id, tEnd.until || null), 'تم حفظ نهاية التجربة') }, 'حفظ التاريخ'),
        h('button', { type: 'button', class: 'btn sm btn-danger-ghost', onclick: () => act(() => Cloud.admin.setTrial(u.id, new Date().toISOString()), 'تم إنهاء التجربة') }, 'إنهاء التجربة'),
        acc.trial_until ? h('button', { type: 'button', class: 'btn sm', onclick: () => act(() => Cloud.admin.setTrial(u.id, null), 'رجعت للإعداد العام') }, 'حسب الإعداد العام') : null)),
    mkCard('الأقسام — امنح حتى تاريخ (فارغ = بدون نهاية)', ...[...SEC_ROWS, ['all', '★ الكل']].map(secRow)),
  ]);
}


/* ================= مجاني في تواريخ معينة (رمضان، العيد، اليوم الوطني…) ================= */
function promosCard(d) {
  d.promos = Array.isArray(d.promos) ? d.promos : [];
  const now = Date.now();
  const iso = (days, h0 = 0) => { const x = new Date(); x.setHours(h0, 0, 0, 0); x.setDate(x.getDate() + days); return x.toISOString(); };
  const QUICK = [
    ['🌙 عرض رمضان (٣٠ يوم)', { icon: '🌙', title: 'رمضان كريم 🌙 — كل شي مجاني', text: 'بمناسبة الشهر الفضيل: كل مميزات NOBLE مفتوحة لك مجاناً — صمّم تهانيك واستمتع.', from: iso(0), to: iso(30) }],
    ['🎉 عرض العيد (٤ أيام)', { icon: '🎉', title: 'عيدكم مبارك 🎉 — هدية لك', text: 'كل التصاميم والمميزات مجاناً أيام العيد — شارك فرحتك.', from: iso(0), to: iso(4), apps: ['designs'] }],
    ['🇸🇦 اليوم الوطني (٣ أيام)', { icon: '💚', title: 'يوم وطني سعيد 💚', text: 'بمناسبة اليوم الوطني: المميزات مفتوحة مجاناً.', from: iso(0), to: iso(3) }],
    ['⏳ نهاية الأسبوع', { icon: '⏳', title: 'نهاية أسبوع مجانية ⏳', text: 'جرّب كل المميزات مجاناً لين نهاية الأسبوع.', from: iso(0), to: iso((7 - new Date().getDay()) % 7 || 2) }],
  ];
  const SECS = [['all', '★ كل الأقسام'], ...SEC_ROWS];
  const list = h('div', { class: 'mk-promos' });
  const paint = () => {
    list.replaceChildren(...d.promos.map((p, i) => {
      const live = p.on !== false && now >= Date.parse(p.from) && now < Date.parse(p.to);
      const ended = now >= Date.parse(p.to);
      const apps = p.apps && p.apps.length ? p.apps : ['all'];
      return h('div', { class: `mk-promo${live ? ' live' : ''}${ended ? ' ended' : ''}` },
        h('div', { class: 'mk-promo-h' },
          h('span', { class: 'mk-pill', text: live ? '🟢 شغّال الحين' : ended ? 'انتهى' : p.on === false ? 'متوقف' : '🕒 مجدول' }),
          mkInput(p, 'title', { ph: 'عنوان العرض', max: 60 }),
          mkSwitch(p, 'on', null, null, () => { mkChanged(); paint(); }),
          h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { if (!confirm('حذف العرض؟')) return; d.promos.splice(i, 1); mkChanged(); paint(); } }, icon('trash', { size: 15 }))),
        mkField('الرسالة في النافذة', mkInput(p, 'text', { ph: 'كل المميزات مفتوحة لك مجاناً…', max: 160 })),
        h('div', { class: 'row-2' }, mkField('من', (() => { const x = dtInput(p, 'from'); x.addEventListener('change', () => { mkChanged(); paint(); }); return x; })()), mkField('إلى', (() => { const x = dtInput(p, 'to'); x.addEventListener('change', () => { mkChanged(); paint(); }); return x; })())),
        mkField('يشمل', h('div', { class: 'chips' }, ...SECS.map(([k, l]) => h('button', { type: 'button', class: `chip${apps.includes(k) ? ' on' : ''}`, onclick: () => {
          let a = (p.apps && p.apps.length ? p.apps : ['all']).filter((x) => x !== 'all');
          if (k === 'all') a = ['all']; else a = a.includes(k) ? a.filter((x) => x !== k) : [...a, k];
          p.apps = a.length ? a : ['all']; mkChanged(); paint();
        } }, l)))),
        mkSwitch(p, 'popup', 'نافذة منبثقة للمستخدمين', 'تطلع مرة وحدة لكل مستخدم أول ما يفتح التطبيق خلال العرض', () => mkChanged()));
    }));
  };
  paint();
  return mkCard('🎁 مجاني في تواريخ معينة',
    h('p', { class: 'hint', text: 'خلال الفترة تنفتح الأقسام اللي تختارها للجميع (كأنهم مشتركين) وتنقفل تلقائياً بعدها — بدون تحديث للتطبيق. تقدر تجدول عروض قدام.' }),
    h('div', { class: 'chips' }, ...QUICK.map(([l, tpl]) => h('button', { type: 'button', class: 'chip', onclick: () => { d.promos.unshift({ id: 'p' + Date.now().toString(36), on: true, popup: true, apps: ['all'], ...tpl }); mkChanged(); paint(); } }, l)),
      h('button', { type: 'button', class: 'chip', onclick: () => { d.promos.unshift({ id: 'p' + Date.now().toString(36), on: true, popup: true, apps: ['all'], title: 'عرض جديد', text: '', from: iso(0), to: iso(7) }); mkChanged(); paint(); } }, '+ عرض مخصص')),
    list);
}

/* ================= شكل شريط التنقل: مين مجاني / تجربة / مشتركين + الافتراضي ================= */
/* «اشتراكي» ورسائل التجديد (1.15) */
function renewCard(d) {
  const DEF = typeof RENEW_DEF !== 'undefined' ? RENEW_DEF : {};
  d.renew = { ...DEF, ...(d.renew || {}) };
  const R = d.renew;
  const box = h('div', { class: 'mk-renew' });
  const txt = (k, rows = 2, max = 300) => { const t = h('textarea', { class: 'input textarea', rows, maxlength: max }); t.value = R[k] || ''; t.addEventListener('input', () => { R[k] = t.value; mkChanged(); prev(); }); return t; };
  const pv = h('div', { class: 'mk-renew-pv' });
  const prev = () => {
    const fill = (t) => String(t || '').replace(/\{الاسم\}/g, 'خالد').replace(/\{الأيام\}/g, '٣ أيام').replace(/\{التاريخ\}/g, '١٢ أكتوبر').replace(/\{الخطة\}/g, 'الباقة الكاملة · سنوي').replace(/\{السعر\}/g, '129 ر.س');
    pv.replaceChildren(h('small', { text: 'معاينة' }), h('b', { text: R.title }), h('p', { text: fill(R.text) }), R.withCode && R.code ? h('span', { class: 'mk-renew-code', text: '🎁 ' + String(R.code).toUpperCase() }) : null);
  };
  const paint = () => {
    const days = h('div', { class: 'mk-chips' }, ...[14, 7, 5, 3, 2, 1].map((n) => h('button', { type: 'button', class: `mk-chip${(R.days || []).map(Number).includes(n) ? ' on' : ''}`, onclick: () => { const s2 = new Set((R.days || []).map(Number)); if (s2.has(n)) s2.delete(n); else s2.add(n); R.days = [...s2].sort((a, b) => b - a); mkChanged(); paint(); } }, `${UI.n(n)} ${n === 1 ? 'يوم' : n <= 10 ? 'أيام' : 'يوم'}`)));
    const hour = h('select', { class: 'input' }, ...[[10, '١٠ الصبح'], [13, '١ الظهر'], [17, '٥ العصر'], [19, '٧ المساء'], [21, '٩ الليل']].map(([v, l]) => h('option', { value: String(v), text: l })));
    hour.value = String(R.notifHour || 19); hour.addEventListener('change', () => { R.notifHour = Number(hour.value); mkChanged(); });
    box.replaceChildren(
      h('p', { class: 'hint', text: 'المشترك يشوف كل تفاصيل اشتراكه في صفحة «اشتراكي» (من زر ★ Pro أو الإعدادات). وقبل النهاية تطلع له رسالة لطيفة مرة باليوم كحد أقصى، وإشعار جوال حتى لو التطبيق مقفل.' }),
      mkSwitch(R, 'onTrial', 'قبل نهاية التجربة المجانية', null, () => paint()),
      mkSwitch(R, 'onSub', 'قبل نهاية الاشتراك', null, () => paint()),
      divField('متى تطلع؟ (قبل النهاية بكم يوم)', days),
      divField('شكلها', mkSeg([['sheet', 'نافذة من تحت'], ['center', 'بطاقة بالوسط'], ['bar', 'شريط أعلى']], R.style, (v) => { R.style = v; mkChanged(); })),
      h('div', { class: 'row-2' }, mkSwitch(R, 'notif', 'إشعار على الجوال', 'حتى لو التطبيق مقفل'), mkField('الساعة', hour)),
      mkField('العنوان', mkInput(R, 'title', { max: 60, onChange: prev })),
      divField('نص الاشتراك', txt('text'), 'متغيرات: {الاسم} {الأيام} {التاريخ} {الخطة} {السعر}'),
      mkField('عنوان التجربة', mkInput(R, 'trialTitle', { max: 60 })),
      divField('نص التجربة', txt('trialText')),
      h('div', { class: 'row-2' }, mkSwitch(R, 'withCode', '🎁 هدية التجديد', 'كود خصم يطلع داخل الرسالة ويتطبّق تلقائياً', () => prev()), mkField('الكود', mkInput(R, 'code', { max: 24, ltr: true, ph: 'RENEW20', onChange: prev }), 'أنشئه من «أكواد الخصم»')),
      mkSwitch(R, 'endOn', 'رسالة وداع بعد ما ينتهي'),
      divField('نصها', txt('endText')),
      h('div', { class: 'mk-lbl', text: 'صفحة «اشتراكي» — وش تعرض' }),
      mkSwitch(R, 'showInv', 'الفواتير والمدفوعات', 'مع مشاركة الفاتورة كصورة'),
      mkSwitch(R, 'showTl', 'تاريخ الاشتراك', 'متى اشترك، جدّد، استخدم كود…'),
      mkSwitch(R, 'showWa', 'زر «تواصل معنا» على واتساب', 'رقم الواتساب من المحتوى'),
      mkSwitch(R, 'showUp', 'اقتراح الترقية للباقة الكاملة'),
      pv);
    prev();
    UI.digitize(box);
  };
  paint();
  return mkCard('💎 اشتراكي ورسائل التجديد', box);
}
/* زر «Pro ★» أعلى التطبيق (1.14.2): إظهار/إخفاء ونصّه — الاشتراكات تبقى شغّالة */
function proBtnCard(d) {
  d.proBtn = { who: 'all', label: '', labelPro: '', ...(d.proBtn || {}) };
  const P = d.proBtn;
  return mkCard('★ زر Pro أعلى التطبيق',
    h('p', { class: 'hint', text: 'تقدر تخفي كلمة Pro من أعلى التطبيق وتبقى الاشتراكات شغّالة كالعادة: الأقسام المدفوعة تقفل وتطلب الاشتراك، وأكواد التفعيل وبطاقة «أقسامك» في الإعدادات تشتغل.' }),
    mkSeg([['all', 'للكل'], ['free', 'لغير المشتركين'], ['pro', 'للمشتركين فقط'], ['none', 'مخفي']], P.who, (v) => { P.who = v; mkChanged(); renderBilling(); }),
    P.who !== 'none' ? h('div', { class: 'row-2' },
      mkField('النص لغير المشترك', mkInput(P, 'label', { max: 14, ph: 'Pro ★' })),
      mkField('النص للمشترك', mkInput(P, 'labelPro', { max: 14, ph: '★ Pro' }))) : null);
}
function tabbarCard(d) {
  if (typeof TabStyles === 'undefined') return null;
  d.tabbar = { ...TabStyles.DEF, ...(d.tabbar || {}), access: { ...((d.tabbar || {}).access || {}) } };
  const T = d.tabbar;
  const ACC = [['free', 'مجاني'], ['trial', 'تجربة ثم اشتراك'], ['pro', '★ مشتركين'], ['off', 'مخفي']];
  const sel = (val, opts, on) => { const x = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: String(v), text: l }))); x.value = String(val); x.addEventListener('change', () => { on(x.value); mkChanged(); }); return x; };
  const rows = TabStyles.STYLES.map(([id, name, desc, defAcc]) => h('div', { class: 'mk-tbrow' },
    h('label', { class: 'mk-tbdef' }, (() => { const r = h('input', { type: 'radio', name: 'tb-def' }); r.checked = T.def === id; r.addEventListener('change', () => { T.def = id; mkChanged(); }); return r; })(), h('span', {}, h('b', { text: name }), h('small', { text: desc }))),
    sel(T.access[id] || defAcc, ACC, (v) => { T.access[id] = v; })));
  const days = mkInput(T, 'trialDays', { type: 'number', min: 1, cls: 'mk-num' });
  return mkCard('🧭 شريط التنقل المتحرك',
    h('p', { class: 'hint', text: 'اختر الشكل الافتراضي للجميع (الدائرة)، وحدد لكل شكل: مجاني، أو تجربة مجانية بعدد أيام ثم اشتراك، أو للمشتركين، أو مخفي. المستخدم يغيّر شكله من الإعدادات ← المظهر.' }),
    h('div', { class: 'mk-tbgrid' }, ...rows),
    h('div', { class: 'row-2' },
      mkField('أيام التجربة لكل شكل', days),
      mkField('حركة الأيقونة', sel(T.motion || '', [['', 'حسب الشكل'], ...Object.entries(TabStyles.MOTIONS)], (v) => { T.motion = v; }))),
    h('div', { class: 'row-2' },
      mkField('نَفَس الحركة', sel(T.ease, Object.entries(TabStyles.EASES).map(([k, v]) => [k, v[0]]), (v) => { T.ease = v; })),
      mkField('أسماء الأزرار', sel(T.labels === false ? '0' : '1', [['1', 'ظاهرة'], ['0', 'أيقونات فقط']], (v) => { T.labels = v === '1'; }))),
    mkField('لون الشريط', sel(T.color || '', Object.entries(TabStyles.COLORS || {}).map(([k, v]) => [k, v[0]]), (v) => { T.color = v; }), 'المستخدم يقدر يغيّره لنفسه لو «المستخدم يختار شكله» شغّال'),
    mkSwitch(T, 'allowPick', 'المستخدم يختار شكله', 'عند الإيقاف يشوف الجميع الشكل الافتراضي فقط'));
}

/* ---------- 🧪 المختبرون (1.16): يشوفون الأقسام التجريبية ويفتحونها كاملة ---------- */
function testersCard(d) {
  d.testers = Array.isArray(d.testers) ? d.testers : [];
  const betaAll = APP_IDS.flatMap((id) => ((d.apps?.[id]?.beta) || []).map((k) => `${SEC_IC[k] || ''} ${SEC_NAMES[k] || k}${APP_IDS.length > 1 ? ` (${APP_META[id].name})` : ''}`));
  const list = h('div', { class: 'mk-testers' }, ...(d.testers.length ? d.testers.map((t, i) => h('span', { class: 'mk-tester' }, h('b', { text: t.name || t.email || 'مستخدم' }), h('small', { class: 'ltr', text: t.email || '' }),
    h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'شيله', onclick: () => { d.testers.splice(i, 1); mkChanged(); renderApps(); } }, '✕'))) : [h('p', { class: 'hint', text: 'ما فيه مختبرين للحين — أضف نفسك أو أي مستخدم تثق فيه.' })]));
  return mkCard([h('strong', { text: '🧪 المختبرون' }), h('span', { class: 'spacer' }), h('button', { type: 'button', class: 'btn sm', onclick: () => testerPick(d) }, '＋ أضف مختبر')],
    h('p', { class: 'hint', text: 'أي قسم تخليه «🧪 مختبرين» في «الأقسام: الترتيب والظهور» يظهر لهؤلاء بس — ويفتح لهم كامل حتى لو مدفوع. الباقين ما يشوفونه.' }),
    list,
    h('p', { class: 'hint mk-beta-now', text: betaAll.length ? `الأقسام التجريبية الحين: ${betaAll.join('، ')}` : 'ولا قسم تجريبي الحين.' }));
}
async function testerPick(d) {
  try { if (!A.users?.length && typeof loadUsers === 'function') await loadUsers(); } catch { /* لا شيء */ }
  const q = h('input', { class: 'input', placeholder: 'ابحث بالاسم أو الإيميل…' });
  const out = h('div', { class: 'supa-pick' });
  const have = new Set(d.testers.map((t) => t.id));
  const paint = () => {
    const s = q.value.trim().toLowerCase();
    const rows = (A.users || []).filter((u) => !have.has(u.id) && (!s || nameOf(u).toLowerCase().includes(s) || (u.email || '').toLowerCase().includes(s))).slice(0, 30);
    out.replaceChildren(...(rows.length ? rows.map((u) => h('button', { type: 'button', class: 'supa-pr', onclick: () => { d.testers.push({ id: u.id, name: nameOf(u), email: u.email || '' }); mkChanged(); closeSheet($('#mk-sheet')); renderApps(); toast(`صار ${nameOf(u)} مختبر 🧪 — اضغط «نشر» للحفظ`, { type: 'success' }); } }, h('b', { text: nameOf(u) + (u.id === A.me?.id ? ' (أنت)' : '') }), h('small', { class: 'ltr', text: u.email || '' }))) : [h('p', { class: 'hint', text: 'ما لقيت أحد' })]));
  };
  q.addEventListener('input', paint);
  mkSheet('🧪 أضف مختبر', [q, out]);
  paint();
}
/* من بطاقة المستخدم: تبديل «مختبر» مباشرة مع الحفظ */
async function toggleTester(u) {
  await loadMarket();
  const d = MK.data; d.testers = Array.isArray(d.testers) ? d.testers : [];
  const i = d.testers.findIndex((t) => t.id === u.id);
  if (i >= 0) d.testers.splice(i, 1); else d.testers.push({ id: u.id, name: nameOf(u), email: u.email || '' });
  await saveMarket();
  toast(i >= 0 ? `${nameOf(u)} ما عاد مختبر` : `${nameOf(u)} صار مختبر 🧪`, { type: 'success' });
  if (A.tab === 'apps') renderApps();
}
