/* NOBLE — الستوري وقسم «اكتشف» (1.15)
 * الإدارة ترفع ستوري (صورة/فيديو) بمدة: ٢٤ ساعة، ٣ أيام، أسبوع، أو تاريخ — وبعدها تختفي وتنحذف من السيرفر.
 * «المميزة» دائمة. المنشورات: صور كاروسيل، فيديو، استفتاء، نص — إعجاب وحفظ ومشاركة وتعليقات بمراجعة الإدارة.
 * الستوري تتحمّل على الجوال في الخلفية أول ما يفتح التطبيق، فيشوفها حتى بدون نت لين تنتهي مدتها.
 */
'use strict';
const DSC = { items: [], meta: {}, loaded: 0, loading: null };
/* 📴 1.21.14: آخر «اكتشف» محفوظ على الجوال — يشتغل بدون نت (الصور محفوظة بالـ Cache) */
const DSC_KEY = 'nw:feed:last';
(() => { try { const c = JSON.parse(localStorage.getItem(DSC_KEY) || 'null'); if (c?.items) { DSC.items = c.items; DSC.meta = c.meta || {}; } } catch { /* لا شيء */ } })();
const DSC_SEEN = 'nw:feed:seen', DSC_SAVED = 'nw:feed:saved';
const dscGet = (k) => { try { return JSON.parse(localStorage.getItem(k) || '[]') || []; } catch { return []; } };
const dscSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v.slice(-400))); } catch { /* لا شيء */ } };
/* ورقة عامة من تحت (للتطبيق) */
function uiSheet(id, title, kids, foot) {
  let el = document.getElementById(id);
  if (!el) { el = h('section', { class: 'sheet', id, hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  el.replaceChildren(...[h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body' }, ...kids.filter(Boolean)),
    foot?.length ? h('footer', { class: 'sheet-foot' }, ...foot.filter(Boolean)) : null].filter(Boolean));
  if (el.hidden) openSheet('#' + id);
  UI.digitize?.(el);
  return el;
}
const dscLive = (it) => !it.expires_at || new Date(it.expires_at).getTime() > Date.now();
const dscStories = () => DSC.items.filter((x) => x.kind === 'story' && dscLive(x));
const dscPosts = () => DSC.items.filter((x) => x.kind === 'post' && dscLive(x));
const dscMeta = () => ({ title: 'اكتشف', sub: 'جديد NOBLE وأفكار تهمك', comments: true, storiesOn: true, storiesToday: true, ...(DSC.meta || {}) });

async function loadFeed(force) {
  if (!Cloud.enabled) return;
  if (!force && Date.now() - DSC.loaded < 60000) return;
  if (DSC.loading) return DSC.loading;
  DSC.loading = (async () => {
    try { const r = await Cloud.soon(Cloud.feedList(), 12000); DSC.items = r?.items || []; DSC.meta = r?.meta || {}; DSC.loaded = Date.now(); try { localStorage.setItem(DSC_KEY, JSON.stringify({ items: DSC.items.slice(0, 60), meta: DSC.meta })); } catch { /* لا شيء */ } dscPrefetch(); }
    catch { /* نعرض المحفوظ */ }
    DSC.loading = null;
    if (S.tab === 'discover') renderDiscover();
    if (S.tab === 'news' && typeof NEWS !== 'undefined') { if (NEWS.view === 'discover') renderNews(); else if (typeof newsHubPaintRings === 'function') newsHubPaintRings(); }
    if (S.tab === 'today') dscPaintRing();
  })();
  return DSC.loading;
}

/* ---------- حفظ الستوري على الجوال (Cache API) ---------- */
const DSC_CACHE = 'noble-feed-v1';
async function dscPrefetch() {
  if (!('caches' in window) || navigator.onLine === false) return;
  try {
    const c = await caches.open(DSC_CACHE);
    const want = new Set();
    for (const it of dscStories()) for (const m of it.data?.media || []) if (m.url) want.add(m.url);
    for (const u of want) { if (!(await c.match(u))) { try { const r = await fetch(u, { mode: 'cors' }); if (r.ok) await c.put(u, r); } catch { /* لا شيء */ } } }
    // نشيل المنتهي من الجوال
    for (const req of await c.keys()) if (!want.has(req.url)) await c.delete(req);
  } catch { /* لا شيء */ }
}
const dscBlobs = new Map();
async function dscSrc(url) {
  if (!url) return '';
  if (dscBlobs.has(url)) return dscBlobs.get(url);
  try {
    if ('caches' in window) {
      const r = await (await caches.open(DSC_CACHE)).match(url);
      if (r) { const b = URL.createObjectURL(await r.blob()); dscBlobs.set(url, b); return b; }
    }
  } catch { /* لا شيء */ }
  return url;
}

/* ---------- حلقات الستوري ---------- */
function dscGroups() {
  const seen = new Set(dscGet(DSC_SEEN));
  const st = dscStories();
  const daily = st.filter((x) => !x.highlight).sort((a, b) => new Date(a.created_at) - new Date(b.created_at));
  const groups = [];
  if (daily.length) groups.push({ id: 'daily', title: dscMeta().storiesTitle || 'NOBLE', cover: daily[daily.length - 1], items: daily, unseen: daily.some((x) => !seen.has(x.id)), main: true });
  st.filter((x) => x.highlight).forEach((x) => groups.push({ id: 'h' + x.id, title: x.data?.ring || x.data?.caption?.slice(0, 14) || 'مميزة', cover: x, items: [x], unseen: !seen.has(x.id) }));
  return groups;
}
function dscRings(cls = '') {
  const gs = dscGroups();
  if (!gs.length || dscMeta().storiesOn === false) return null;
  return h('div', { class: `dsc-rings ${cls}` }, ...gs.map((g, i) => {
    const m = g.cover.data?.media?.[0];
    const thumb = m?.thumb || (m?.kind === 'image' ? m.url : '');
    const bg = g.cover.data?.type === 'text' ? g.cover.data?.bg : '';
    const face = h('span', { class: 'dsc-face', style: bg ? { background: bg } : null }, thumb ? h('img', { src: thumb, alt: '', loading: 'lazy' }) : h('b', { text: g.main ? 'N' : '✨' }));
    return h('button', { type: 'button', class: `dsc-ring${g.unseen ? ' new' : ''}${g.main ? ' main' : ''}`, onclick: () => dscOpenStories(gs, i) },
      h('span', { class: 'dsc-halo' }, face), h('small', { text: g.title }));
  }));
}
function dscPaintRing() {
  const root = $('#td-root');
  if (!root || dscMeta().storiesToday === false) return;
  root.querySelector(':scope > .dsc-rings')?.remove();
  const r = dscRings('in-today');
  if (r) root.prepend(r);
}

/* ---------- عارض الستوري ---------- */
function dscOpenStories(groups, gi) {
  let g = gi, i = Math.max(0, groups[gi].items.findIndex((x) => !new Set(dscGet(DSC_SEEN)).has(x.id)));
  let timer = 0, t0 = 0, dur = 5000, paused = false, elapsed = 0, media = null;
  const el = h('div', { class: 'dsc-viewer', role: 'dialog', 'aria-modal': 'true' });
  document.body.append(el);
  document.body.classList.add('dsc-open');
  const close = () => { cancelAnimationFrame(timer); media?.pause?.(); el.classList.add('out'); setTimeout(() => { el.remove(); document.body.classList.remove('dsc-open'); if (S.tab === 'today') dscPaintRing(); if (S.tab === 'discover') renderDiscover(); if (S.tab === 'news' && typeof newsHubPaintRings === 'function') { if (NEWS.view === 'discover') renderNews(); else newsHubPaintRings(); } }, 200); };
  const go = (d) => {
    i += d;
    if (i >= groups[g].items.length) { g++; i = 0; if (g >= groups.length) return close(); }
    if (i < 0) { g--; if (g < 0) { g = 0; i = 0; } else i = groups[g].items.length - 1; }
    show();
  };
  const markSeen = (it) => { const s = dscGet(DSC_SEEN); if (!s.includes(it.id)) { s.push(it.id); dscSet(DSC_SEEN, s); Cloud.feedSeen(it.id); } };
  async function show() {
    cancelAnimationFrame(timer); media?.pause?.();
    const grp = groups[g], it = grp.items[i], d = it.data || {}, m = (d.media || [])[0] || {};
    markSeen(it);
    const bars = h('div', { class: 'dsc-bars' }, ...grp.items.map((_, k) => h('i', {}, h('b', { style: { width: k < i ? '100%' : '0%' } }))));
    const src = await dscSrc(m.url);
    media = m.kind === 'video' ? h('video', { src, playsinline: true, autoplay: true, class: 'dsc-media' }) : m.url ? h('img', { src, alt: '', class: 'dsc-media' }) : h('div', { class: 'dsc-media dsc-txt', style: { background: d.bg || 'linear-gradient(160deg,#0E1B55,#8B45F0)' } }, h('p', { text: d.caption || '' }));
    if (m.kind === 'video') { media.muted = false; media.addEventListener('loadedmetadata', () => { dur = Math.min(60, media.duration || 15) * 1000; }); media.addEventListener('ended', () => go(1)); media.play().catch(() => { media.muted = true; media.play().catch(() => {}); }); }
    const liked = !!it.liked;
    const like = h('button', { type: 'button', class: `dsc-like${liked ? ' on' : ''}`, 'aria-label': 'إعجاب', onclick: async (e) => { e.stopPropagation(); buzz('light'); try { const r = await Cloud.feedLike(it.id); it.liked = r.liked; it.likes = r.likes; like.classList.toggle('on', r.liked); } catch (er) { toast(Cloud.msg(er), { type: 'error' }); } } }, '♥');
    el.replaceChildren(...[
      bars,
      h('div', { class: 'dsc-vh' }, h('span', { class: 'dsc-vav', text: 'N' }), h('b', { text: grp.title }), h('small', { text: UI.relTime(new Date(it.created_at).getTime()) }), h('span', { class: 'spacer' }),
        h('button', { type: 'button', class: 'dsc-x', 'aria-label': 'إغلاق', onclick: (e) => { e.stopPropagation(); close(); } }, '✕')),
      media,
      d.caption && (m.url || m.kind) ? h('p', { class: 'dsc-cap', text: d.caption }) : null,
      h('div', { class: 'dsc-vf' }, d.link?.url ? h('button', { type: 'button', class: 'dsc-cta', onclick: (e) => { e.stopPropagation(); dscLink(d.link.url); } }, d.link.label || 'اعرف أكثر ↗') : h('span'), like)].filter(Boolean));
    dur = m.kind === 'video' ? 15000 : 5000; elapsed = 0; t0 = performance.now(); paused = false;
    const fill = bars.children[i]?.firstChild;
    const tick = (now) => {
      if (!paused) { elapsed += now - t0; }
      t0 = now;
      const p = m.kind === 'video' && media.duration ? media.currentTime / media.duration : elapsed / dur;
      if (fill) fill.style.width = Math.min(100, p * 100) + '%';
      if (p >= 1 && m.kind !== 'video') return go(1);
      timer = requestAnimationFrame(tick);
    };
    timer = requestAnimationFrame(tick);
  }
  // اللمس: يسار = التالي، يمين = السابق (عربي)، ضغط مطوّل = إيقاف، سحب لتحت = إغلاق
  let down = 0, sy = 0, sx = 0;
  el.addEventListener('pointerdown', (e) => { if (e.target.closest('button')) return; down = Date.now(); sy = e.clientY; sx = e.clientX; paused = true; media?.pause?.(); });
  el.addEventListener('pointerup', (e) => {
    if (!down || e.target.closest('button')) return;
    const held = Date.now() - down; down = 0; paused = false; if (media?.tagName === 'VIDEO') media.play().catch(() => {});
    if (e.clientY - sy > 90) return close();
    if (held > 350 || Math.abs(e.clientX - sx) > 40) return;
    go(e.clientX < innerWidth / 2 ? 1 : -1);
  });
  el.tabIndex = -1; el.focus();
  dscOpenStories.close = close;
  show();
}
function dscLink(url) {
  if (/^noble:/i.test(url) && typeof Links !== 'undefined') return Links.open(url);
  if (typeof Links !== 'undefined') Links.open(url); else window.open(url, '_blank', 'noopener');
}

/* ---------- قسم «اكتشف» ---------- */
function renderDiscover({ root = $('#dsc-root'), embedded = false } = {}) {
  if (!root) return;
  const again = () => (embedded && typeof renderNews === 'function' ? renderNews() : renderDiscover());
  const M = dscMeta();
  const posts = dscPosts();
  const saved = new Set(dscGet(DSC_SAVED));
  const showSaved = root.dataset.saved === '1';
  const list = showSaved ? posts.filter((p) => saved.has(p.id)) : posts;
  root.replaceChildren(...[
    h('div', { class: `dsc-head${embedded ? ' in-news' : ''}` }, embedded ? h('small', { text: M.sub || 'جديد NOBLE وأفكار تهمك' }) : h('div', {}, h('h1', { class: 'view-title', text: M.title || 'اكتشف' }), M.sub ? h('small', { text: M.sub }) : null),
      h('button', { type: 'button', class: `chip${showSaved ? ' on' : ''}`, onclick: () => { root.dataset.saved = showSaved ? '' : '1'; again(); } }, showSaved ? '✕ الكل' : '🔖 محفوظاتي')),
    showSaved || embedded ? null : dscRings('in-dsc'),
    ...(list.length ? list.map(dscPost) : [h('div', { class: 'empty' }, h('b', { text: showSaved ? 'ما حفظت شي للحين' : 'قريباً منشورات جديدة 👀' }), h('small', { text: showSaved ? 'اضغط 🔖 على أي منشور يعجبك.' : 'تابعنا، نضيف محتوى أول بأول.' }))])].filter(Boolean));
  UI.digitize?.(root);
}
function dscPost(it) {
  const d = it.data || {}, media = d.media || [];
  const saved = new Set(dscGet(DSC_SAVED));
  let body = null;
  if (d.type === 'poll' && d.poll?.options?.length) body = dscPoll(it);
  else if (media.length > 1) {
    const dots = h('div', { class: 'dsc-dots' }, ...media.map((_, k) => h('i', { class: k ? '' : 'on' })));
    const track = h('div', { class: 'dsc-car' }, ...media.map((m) => m.kind === 'video' ? h('video', { src: m.url, controls: true, playsinline: true, preload: 'metadata', poster: m.thumb || null }) : h('img', { src: m.url, alt: '', loading: 'lazy' })));
    track.addEventListener('scroll', () => { const k = Math.round(Math.abs(track.scrollLeft) / Math.max(1, track.clientWidth)); [...dots.children].forEach((x, j) => x.classList.toggle('on', j === k)); }, { passive: true });
    body = h('div', { class: 'dsc-carw' }, track, dots);
  } else if (media[0]) body = media[0].kind === 'video' ? h('video', { class: 'dsc-pm', src: media[0].url, controls: true, playsinline: true, preload: 'metadata', poster: media[0].thumb || null }) : h('img', { class: 'dsc-pm', src: media[0].url, alt: '', loading: 'lazy' });
  else if (d.type === 'text') body = h('div', { class: 'dsc-ptxt', style: { background: d.bg || 'linear-gradient(160deg,#0E1B55,#2E5BFF 60%,#8B45F0)' } }, h('p', { text: d.caption || '' }));
  const likeB = h('button', { type: 'button', class: `dsc-act${it.liked ? ' on' : ''}`, 'aria-label': 'إعجاب', onclick: async () => {
    buzz('light');
    try { const r = await Cloud.feedLike(it.id); it.liked = r.liked; it.likes = r.likes; likeB.classList.toggle('on', r.liked); likeB.lastChild.textContent = UI.n(r.likes); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  } }, h('span', { text: '♥' }), h('small', { text: UI.n(it.likes || 0) }));
  const saveB = h('button', { type: 'button', class: `dsc-act${saved.has(it.id) ? ' on' : ''}`, 'aria-label': 'حفظ', onclick: () => {
    const s = dscGet(DSC_SAVED); const on = s.includes(it.id);
    dscSet(DSC_SAVED, on ? s.filter((x) => x !== it.id) : [...s, it.id]); saveB.classList.toggle('on', !on); toast(on ? 'شلناه من محفوظاتك' : 'انحفظ في محفوظاتك 🔖');
  } }, h('span', { text: '🔖' }));
  return h('article', { class: 'dsc-post' },
    h('div', { class: 'dsc-ph' }, h('span', { class: 'dsc-vav', text: 'N' }), h('div', {}, h('b', { text: dscMeta().author || 'NOBLE' }), h('small', { text: UI.relTime(new Date(it.created_at).getTime()) }))),
    body,
    d.type !== 'text' && d.caption ? h('p', { class: 'dsc-pc', text: d.caption }) : null,
    d.link?.url ? h('button', { type: 'button', class: 'btn sm dsc-plink', onclick: () => dscLink(d.link.url) }, d.link.label || 'اعرف أكثر ↗') : null,
    d.type === 'ai_issue' && d.issue && typeof ainOpenId === 'function' ? h('button', { type: 'button', class: 'btn btn-primary btn-block dsc-ai', onclick: () => ainOpenId(d.issue) }, '⚡ شوف العدد بالفيديو') : null,
    h('div', { class: 'dsc-acts' }, likeB,
      dscMeta().comments !== false ? h('button', { type: 'button', class: 'dsc-act', 'aria-label': 'تعليقات', onclick: () => dscComments(it) }, h('span', { text: '💬' }), h('small', { text: UI.n(it.comments || 0) })) : null,
      h('button', { type: 'button', class: 'dsc-act', 'aria-label': 'مشاركة', onclick: () => dscShare(it) }, h('span', { text: '↗' })),
      h('span', { class: 'spacer' }), saveB));
}
function dscPoll(it) {
  const d = it.data, opts = d.poll.options;
  const box = h('div', { class: 'dsc-poll' });
  const paint = () => {
    const tally = it.tally || {}, total = Object.values(tally).reduce((a, b) => a + Number(b), 0);
    const voted = it.voted != null;
    box.replaceChildren(h('b', { class: 'dsc-pq', text: d.poll.q || d.caption || '' }),
      ...opts.map((o, k) => {
        const n = Number(tally[k] || 0), pct = total ? Math.round((n / total) * 100) : 0;
        return h('button', { type: 'button', class: `dsc-opt${voted ? ' done' : ''}${it.voted === k ? ' mine' : ''}`, onclick: async () => {
          buzz('select');
          try { it.tally = await Cloud.feedVote(it.id, k); it.voted = k; paint(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
        } }, h('i', { style: { width: voted ? pct + '%' : '0%' } }), h('span', { text: o }), voted ? h('em', { class: 'num', text: UI.n(pct) + '٪' }) : null);
      }),
      voted ? h('small', { class: 'dsc-pt', text: `${UI.n(total)} صوت` }) : h('small', { class: 'dsc-pt', text: 'اختر عشان تشوف النتيجة' }));
  };
  paint();
  return box;
}
async function dscShare(it) {
  const d = it.data || {};
  const text = [d.caption || d.poll?.q || '', d.link?.url && /^https?:/.test(d.link.url) ? d.link.url : '', '— من تطبيق NOBLE'].filter(Boolean).join('\n');
  try {
    const Sh = Platform.plugin?.('Share');
    if (Sh) return await Sh.share({ text, dialogTitle: 'مشاركة' });
    if (navigator.share) return await navigator.share({ text });
    await navigator.clipboard.writeText(text); toast('انسخ النص ✓');
  } catch { /* ألغى */ }
}
// opts (1.21.26 — من عارض «عاجل»): { pick: ['عنوان الخبر ١', …] ← «📌 أي خبر تقصد؟»، title, placeholder, onCount(n) }
async function dscComments(it, opts = {}) {
  const list = h('div', { class: 'dsc-cl' }, h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  const inp = h('textarea', { class: 'input textarea', rows: 2, maxlength: 500, placeholder: opts.placeholder || 'اكتب تعليقك…' });
  let pk = 0; // رقم الخبر المختار (0 = عام)
  const pickRow = opts.pick?.length ? h('div', { class: 'dsc-pick' }, h('small', { text: '📌 تعلّق على أي خبر؟ (اختياري)' }),
    h('div', { class: 'chips' }, ...opts.pick.map((t, k) => h('button', { type: 'button', class: 'chip', title: t, onclick: (e) => { pk = pk === k + 1 ? 0 : k + 1; [...e.currentTarget.parentNode.children].forEach((b, j) => b.classList.toggle('on', j + 1 === pk)); } },
      `${UI.n(k + 1)} · ${String(t).slice(0, 22)}${String(t).length > 22 ? '…' : ''}`)))) : null;
  const tagOf = (b) => { const m = /^📌 الخبر (\d+): ?/.exec(b || ''); return m ? { n: +m[1], body: b.slice(m[0].length) } : null; };
  const paint = (rows) => list.replaceChildren(...(rows.length ? rows.map((c) => h('div', { class: `dsc-c${c.status === 'pending' ? ' wait' : ''}` },
    h('div', { class: 'dsc-ch' }, h('b', { text: c.mine ? 'أنت' : c.name }), !c.mine && typeof reportContent === 'function' ? h('button', { type: 'button', class: 'rep-btn', 'aria-label': 'إبلاغ', onclick: () => reportContent({ kind: 'comment', id: c.id, name: c.name, text: c.body }) }, '🚩') : null), (() => { const tg = tagOf(c.body); return tg ? h('p', {}, h('span', { class: 'dsc-tag', text: `📌 ${opts.pick?.[tg.n - 1] ? String(opts.pick[tg.n - 1]).slice(0, 28) : 'الخبر ' + UI.n(tg.n)}` }), ' ', tg.body) : h('p', { text: c.body }); })(),
    h('small', { text: c.status === 'pending' ? '⏳ بانتظار المراجعة — يظهر للكل بعد الموافقة' : UI.relTime(new Date(c.created_at).getTime()) }))) : [h('p', { class: 'hint', text: 'كن أول من يعلّق 💬' })]));
  const send = async (e) => {
    const b = e.currentTarget, v = inp.value.trim();
    if (!v) return;
    b.disabled = true;
    try { await Cloud.feedComment(it.id, pk ? `📌 الخبر ${pk}: ${v}` : v); inp.value = ''; toast('وصل تعليقك ✓ ويظهر بعد المراجعة', { type: 'success' }); paint(await Cloud.feedComments(it.id)); }
    catch (er) { toast(/limit/.test(er.message) ? 'وصلت حد التعليقات اليوم' : /comments off/.test(er.message) ? 'التعليقات موقوفة حالياً' : Cloud.msg(er), { type: 'error' }); }
    b.disabled = false;
  };
  uiSheet('dsc-sheet', opts.title || '💬 التعليقات', [list, pickRow, h('div', { class: 'dsc-cin' }, inp, h('button', { type: 'button', class: 'btn btn-primary', onclick: send }, 'إرسال'))]);
  try { const rows = await Cloud.feedComments(it.id); paint(rows); opts.onCount?.(rows.filter((c) => c.status === 'approved').length); } catch (e) { list.replaceChildren(h('p', { class: 'hint', text: Cloud.msg(e) })); }
}
