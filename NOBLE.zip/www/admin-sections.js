/* NOBLE — لوحة التحكم ← «الأقسام والصلاحيات» (1.17)
 * الترتيب بالسحب + مين يشوف كل قسم (للكل / 🧪 المختبرين / 💎 المشتركين / 👥 محددين / 🚫 موقوف)
 * المحددين: بالاسم أو الإيميل أو نطاق الإيميل أو المجموعات، مع مدة — محفوظة في السيرفر (ما تنكشف للمستخدمين).
 * + استثناء لمستخدم محدد + معاينة «كذا يشوفه فلان».
 * الترتيب والجمهور في إعدادات السوق (نشر التعديلات) — والمحددين/المجموعات/الاستثناءات تنحفظ فوراً.
 */
'use strict';
const SEC = { app: 'nobleweb', data: null, pv: '', uq: '', uSel: '' };
const SEC_NORM = new WeakSet();
const SEC_AUD = [['all', '👁', 'للكل'], ['beta', '🧪', 'المختبرين'], ['pro', '💎', 'المشتركين'], ['custom', '👥', 'محددين'], ['off', '🚫', 'موقوف']];
async function renderSections() {
  const box = $('#a-sections');
  if (!box) return;
  if (!MK.data || !SEC.data) RC(box, h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  await loadMarket();
  if (!MK.subs && can('billing.manage')) { try { MK.subs = await Cloud.admin.subscribers(); } catch { MK.subs = []; } }
  if (!SEC.data) { try { SEC.data = await Cloud.admin.sectionsGet(); } catch (e) { SEC.data = { perms: [], groups: [], overrides: [], err: Cloud.msg(e) }; } }
  paintSections();
}
function secApp() {
  const d = MK.data; d.apps = d.apps || {};
  const m = APP_META[SEC.app];
  let c = d.apps[SEC.app];
  if (!c || !SEC_NORM.has(c)) { c = d.apps[SEC.app] = Market.merge({ name: m.name, sections: m.sections, ads: { house: true, admob: false }, updateUrl: '', minVersion: '', on: true }, c || {}); SEC_NORM.add(c); }
  const all = Object.keys(SEC_NAMES).filter((x) => SEC.app === 'nobleweb' || m.sections.includes(x) || (c.sections || []).includes(x));
  const base = Array.isArray(c.order) ? c.order.filter((x) => all.includes(x)) : [...(c.sections || m.sections)];
  c.order = [...base, ...all.filter((x) => !base.includes(x))];
  c.sections = Array.isArray(c.sections) ? c.sections : [...m.sections];
  ['beta', 'proSecs', 'custom'].forEach((k) => { c[k] = Array.isArray(c[k]) ? c[k] : []; });
  c.sectionsKnown = Object.keys(SEC_NAMES);
  return c;
}
const secAudOf = (c, k) => (!c.sections.includes(k) ? 'off' : c.beta.includes(k) ? 'beta' : c.proSecs.includes(k) ? 'pro' : c.custom.includes(k) ? 'custom' : 'all');
function secSetAud(c, k, a) {
  if (k === 'sites' && a !== 'all') return toast('المواقع قسم أساسي — يظهر للكل دائماً');
  if (a === 'off' && c.sections.filter((x) => x !== k).length === 0) return toast('لازم قسم واحد على الأقل');
  c.sections = c.sections.filter((x) => x !== k); if (a !== 'off') c.sections = c.order.filter((x) => x === k || c.sections.includes(x));
  c.beta = c.beta.filter((x) => x !== k); c.proSecs = c.proSecs.filter((x) => x !== k); c.custom = c.custom.filter((x) => x !== k);
  if (a === 'beta') c.beta.push(k); if (a === 'pro') c.proSecs.push(k); if (a === 'custom') c.custom.push(k);
  if (!c.sections.includes(c.start)) c.start = c.sections[0] || '';
  mkChanged(); paintSections();
  if (a === 'custom') secPerm(k);
}
const secPermOf = (k) => (SEC.data.perms || []).find((p) => p.sec === k);
const secGroups = () => SEC.data.groups || [];
const secUser = (id) => (A.users || []).find((u) => u.id === id);
const secIsSub = (u) => { const now = Date.now(); return (MK.subs || []).some((e) => e.user_id === u.id && !e.revoked && (!e.until || new Date(e.until).getTime() > now)); };
const secIsTester = (u) => (MK.data.testers || []).some((t) => (t?.id || t) === u.id);
/* هل يشوف المستخدم القسم؟ (نفس منطق التطبيق والسيرفر) */
function secAccessFor(u, k, c) {
  if (k === 'sites') return [true, 'قسم أساسي'];
  const o = (SEC.data.overrides || []).find((x) => x.user_id === u.id && x.sec === k);
  if (o?.mode === 'show') return [true, 'استثناء خاص له ✋'];
  if (o?.mode === 'hide') return [false, 'مخفي عنه بالذات ✋'];
  if ((u.disabled_sections || []).includes(k)) return [false, 'موقوف له من إجراءات المستخدم'];
  if (['owner', 'admin'].includes(u.role)) return [true, 'الإدارة تشوف كل شي'];
  const a = secAudOf(c, k);
  if (a === 'off') return [false, 'القسم موقوف'];
  if (a === 'beta') return secIsTester(u) ? [true, '🧪 لأنه مختبر'] : [false, 'للمختبرين فقط'];
  if (a === 'pro') return secIsSub(u) || secIsTester(u) ? [true, '💎 مشترك'] : [c.lockShow === false ? false : 'lock', 'للمشتركين فقط'];
  if (a === 'custom') {
    const p = secPermOf(k); if (!p) return [true, 'ما حددت أحد بعد — ظاهر للكل'];
    const dom = String(u.email || '').toLowerCase().split('@')[1] || '';
    const g = secGroups().find((x) => (p.groups || []).includes(x.id) && (x.users || []).includes(u.id));
    const hit = (p.users || []).includes(u.id) ? 'بالاسم' : g ? `مجموعة «${g.name}»` : dom && (p.domains || []).includes(dom) ? `نطاق @${dom}` : '';
    const ex = (p.until || {})[u.id], exp = ex && new Date(ex + 'T23:59:59') < new Date();
    if (p.mode === 'deny') return hit ? [false, `مستثنى (${hit})`] : [true, 'للكل إلا المستثنين'];
    return hit && !exp ? [true, `مسموح له (${hit})${ex ? ` حتى ${ex}` : ''}`] : [false, exp ? 'انتهت مدة صلاحيته' : 'مو ضمن المسموح لهم'];
  }
  return [true, 'متاح للكل'];
}

function paintSections() {
  const box = $('#a-sections'), c = secApp();
  const off = Content.get('sectionsOff') || [];
  let n = 0;
  const rows = c.order.map((k, i) => {
    const a = secAudOf(c, k), on = a !== 'off'; if (on) n++;
    const BM = secBarMax(c), many = c.sections.length > BM;
    const inBar = on && n <= (many ? BM - 1 : BM), p = secPermOf(k);
    const cnt = p ? (p.users || []).length + (p.groups || []).length + (p.domains || []).length : 0;
    const mv = (d) => { const j = i + d; if (j < 0 || j >= c.order.length) return; [c.order[i], c.order[j]] = [c.order[j], c.order[i]]; c.sections = c.order.filter((x) => c.sections.includes(x)); mkChanged(); paintSections(); };
    const div = on && many && n === BM ? h('div', { class: 'sec2-div', text: 'داخل «المزيد ⋯»' }) : null;
    return [div, h('div', { class: `sec2-row${on ? '' : ' off'}`, 'data-k': k },
      h('span', { class: 'sec2-hdl', 'data-h': '1', title: 'اسحب للترتيب', text: '⠿' }),
      h('span', { class: 'sec2-n num', text: on ? UI.n(n) : '–' }),
      h('span', { class: 'sec2-ic', text: SEC_IC[k] || '•' }),
      h('div', { class: 'sec2-t' }, h('b', { text: SEC_NAMES[k] }),
        h('div', { class: 'sec2-pills' },
          on ? h('span', { class: `pill ${inBar ? 'bar' : ''}`, text: inBar ? 'في الشريط' : 'في المزيد' }) : null,
          a === 'beta' ? h('span', { class: 'pill beta', text: '🧪 مختبرين' }) : null,
          a === 'pro' ? h('span', { class: 'pill pro', text: `💎 مشتركين${c.lockShow === false ? '' : ' · يظهر مقفل'}` }) : null,
          a === 'custom' ? h('span', { class: 'pill cus', text: `👥 ${p?.mode === 'deny' ? 'الكل إلا' : 'محددين'} · ${UI.n(cnt)}` }) : null,
          a === 'off' ? h('span', { class: 'pill off', text: '🚫 موقوف' }) : null,
          k === 'sites' ? h('span', { class: 'pill lk', text: 'أساسي 🔒' }) : null,
          c.start === k ? h('span', { class: 'pill lk', text: '🏁 يفتح عليه' }) : null,
          off.includes(k) ? h('span', { class: 'pill off', text: 'موقوف لكل التطبيقات (إعداد قديم)' }) : null)),
      h('div', { class: 'sec2-acts' },
        h('button', { type: 'button', class: `btn sm${a === 'custom' ? ' sec2-cus' : ''}`, disabled: k === 'sites', onclick: () => secPerm(k) }, '👥', h('span', { class: 'w', text: ' مين يشوفه' })),
        h('div', { class: 'sec2-mv' }, h('button', { type: 'button', disabled: i === 0, onclick: () => mv(-1) }, '▲'), h('button', { type: 'button', disabled: i === c.order.length - 1, onclick: () => mv(1) }, '▼'))))];
  }).flat().filter(Boolean);
  const list = h('div', { class: 'sec2-list' }, ...rows);
  const tog = (title, sub, k, def = true) => { const i = h('input', { type: 'checkbox', checked: c[k] === undefined ? def : !!c[k] }); i.addEventListener('change', () => { c[k] = i.checked; mkChanged(); paintSections(); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); };
  const start = h('select', { class: 'input' }, ...c.sections.filter((k) => secAudOf(c, k) === 'all').map((k) => h('option', { value: k, text: `${SEC_IC[k] || ''} ${SEC_NAMES[k]}` })));
  start.value = c.start; start.addEventListener('change', () => { c.start = start.value; mkChanged(); paintSections(); });
  const users = (A.users || []).slice().sort((a, b) => nameOf(a).localeCompare(nameOf(b), 'ar'));
  if (!SEC.pv && users.length) SEC.pv = (users.find((u) => u.role === 'user') || users[0]).id;
  const pvSel = h('select', { class: 'input' }, ...users.map((u) => h('option', { value: u.id, text: `${nameOf(u)}${secIsSub(u) ? ' 💎' : ''}${secIsTester(u) ? ' 🧪' : ''}` })));
  pvSel.value = SEC.pv; pvSel.addEventListener('change', () => { SEC.pv = pvSel.value; paintSections(); });
  const pvU = secUser(SEC.pv);
  const pv = pvU ? (() => { const vis = c.order.map((k) => [k, ...secAccessFor(pvU, k, c)]).filter(([, ok]) => ok); const bar = vis.filter(([, ok]) => ok === true).slice(0, vis.length > secBarMax(c) ? secBarMax(c) - 1 : secBarMax(c));
    return h('div', { class: 'sec2-phone' }, h('b', { class: 'sec2-ph-h', text: 'أقسامك' }),
      ...vis.map(([k, ok]) => h('div', { class: 'sec2-ph-it' }, h('span', { class: 'ic', text: SEC_IC[k] || '•' }), h('span', { text: SEC_NAMES[k] }), h('small', { class: ok === 'lock' ? 'p' : secAudOf(c, k) === 'beta' ? 'b' : secAudOf(c, k) === 'custom' ? 'c' : '', text: ok === 'lock' ? '🔒 اشترك' : secAudOf(c, k) === 'beta' ? '🧪 تجريبي' : secAudOf(c, k) === 'custom' ? '👥 خاص' : secAudOf(c, k) === 'pro' ? '💎' : 'متاح' }))),
      h('div', { class: 'sec2-dock' }, ...bar.map(([k]) => h('div', { class: k === c.start ? 'on' : '' }, h('i', { text: SEC_IC[k] }), SEC_NAMES[k])), vis.length > secBarMax(c) ? h('div', { class: 'more' }, h('i', { text: '⋯' }), `المزيد +${UI.n(vis.length - secBarMax(c) + 1)}`) : null)); })() : h('p', { class: 'hint', text: 'ما فيه مستخدمين للمعاينة' });
  RC(box,
    mkHero('الأقسام والصلاحيات', 'رتّب الأقسام اللي تظهر للمستخدمين، وحدد مين يشوف كل قسم: للكل، المختبرين، المشتركين، أو ناس محددين بالإيميل والاسم والمجموعات. المواقع قسم أساسي.'),
    SEC.data.err ? h('p', { class: 'note-box', text: 'صلاحيات «👥 محددين» تحتاج تحديث قاعدة البيانات: شغّل ملف supabase/update-all.sql في Supabase ← SQL Editor. (' + SEC.data.err + ')' }) : null,
    h('div', { class: 'chips sec2-apps' }, ...Object.entries(APP_META).map(([id, m]) => h('button', { type: 'button', class: `chip${SEC.app === id ? ' on' : ''}`, onclick: () => { SEC.app = id; paintSections(); } }, m.name))),
    h('div', { class: 'sec2-wrap' },
      h('div', { class: 'sec2-col' },
        h('section', { class: 'set-card sec2-card' }, h('b', { class: 'sec2-h', text: '↕️ الترتيب والظهور' }), h('p', { class: 'hint', text: 'اسحب من ⠿ أو استخدم الأسهم — عدد الأقسام في الشريط تحدده من «⚙️ قواعد الترتيب»، والباقي داخل «المزيد»، ونفس الترتيب في الإعدادات ← «أقسامك». الترتيب والجمهور يوصل بعد «نشر التعديلات».' }), list),
        h('section', { class: 'set-card sec2-card' }, h('b', { class: 'sec2-h', text: '⚙️ قواعد الترتيب' }),
          mkField('🏁 يفتح التطبيق على', start),
          secFld('📱 كم قسم في الشريط السفلي', h('div', { class: 'chips sec2-bm' }, ...[4, 5, 6, 7].map((n) => h('button', { type: 'button', class: `chip${secBarMax(c) === n ? ' on' : ''}`, onclick: () => { c.barMax = n; mkChanged(); paintSections(); } }, UI.n(n))),
            h('small', { class: 'hint', text: c.sections.length > secBarMax(c) ? `يظهر ${UI.n(secBarMax(c) - 1)} + زر «المزيد» (فيه ${UI.n(c.sections.length - secBarMax(c) + 1)})` : 'كل الأقسام تظهر في الشريط' }))),
          secFld('⋯ شكل زر «المزيد»', h('div', { class: 'chips' }, ...[['count', '⋯ المزيد +٣ (دائماً)'], ['smart', 'اسم القسم المفتوح + ⋯']].map(([k, l]) => h('button', { type: 'button', class: `chip${(c.moreLook || 'count') === k ? ' on' : ''}`, onclick: () => { c.moreLook = k; mkChanged(); paintSections(); } }, l)))),
          tog('نبّه المستخدم على «المزيد» أول مرة', 'نبضة خفيفة حول الزر لين يفتحه أول مرة', 'moreHint'),
          tog('اسمح للمستخدم يرتّب لنفسه', 'لو قفلتها، الكل يشوف ترتيبك أنت', 'userOrder'),
          tog('اسمح للمستخدم يخفي أقسام لنفسه', 'من الإعدادات ← الأقسام', 'userHide'),
          tog('القسم «💎 للمشتركين» يظهر مقفل مع زر الاشتراك', 'لو أطفأته يختفي عن غير المشتركين تماماً', 'lockShow'),
          h('button', { type: 'button', class: 'btn sm', onclick: async () => { if (!(await confirmSheet({ title: 'تطبيق الترتيب على الكل؟', text: 'كل المستخدمين يرجع ترتيبهم لهذا الترتيب (مرة وحدة)، وبعدها كل واحد يقدر يرتّب لنفسه لو مسموح.', ok: 'طبّقه على الكل' }))) return; c.orderVer = (Number(c.orderVer) || 0) + 1; mkChanged(); toast('بيتطبّق على الكل بعد النشر ✓', { type: 'success' }); } }, `🔁 طبّق ترتيبي على الكل${c.orderVer ? ` (آخر مرة: ${UI.n(c.orderVer)})` : ''}`)),
        h('section', { class: 'set-card sec2-card' }, h('b', { class: 'sec2-h', text: '👥 المجموعات' }), h('p', { class: 'hint', text: 'جمّع الناس مرة وحدة واستخدم المجموعة في أي قسم — مثل «العائلة» أو «عملاء» أو «فريق التصميم». تنحفظ فوراً.' }),
          h('div', { class: 'sec2-groups' }, ...secGroups().map((g) => h('button', { type: 'button', class: 'sec2-grp', onclick: () => secGroup(g) }, h('i', { style: { background: g.color } }), g.name, h('small', { text: `${UI.n((g.users || []).length)} شخص` }))),
            h('button', { type: 'button', class: 'sec2-grp add', onclick: () => secGroup({ name: '', color: ['#56C8FF', '#E5487A', '#F5C451', '#1FC7A0', '#8B45F0'][secGroups().length % 5], users: [] }) }, '+ مجموعة جديدة'))),
        h('section', { class: 'set-card sec2-card' }, h('b', { class: 'sec2-h', text: '🔎 صلاحيات مستخدم محدد' }), h('p', { class: 'hint', text: 'ابحث بالإيميل أو الاسم — تشوف كل الأقسام عنده وليش ظاهرة أو مخفية، وتقدر تستثنيه' }), secUserBox(c))),
      h('aside', { class: 'sec2-pv' }, h('label', { class: 'field' }, h('span', { text: 'عاين كـ' }), pvSel), pv)));
  secDrag(list, c);
  UI.digitize(box);
}
const secFld = (label, ...k) => h('div', { class: 'field' }, h('span', { text: label }), ...k);
const secBarMax = (c) => Math.min(7, Math.max(4, Number(c.barMax) || 5));
function secDrag(list, c) {
  list.querySelectorAll('[data-h]').forEach((hd) => hd.addEventListener('pointerdown', (e) => {
    const row = hd.closest('.sec2-row'); row.classList.add('drag'); hd.setPointerCapture(e.pointerId); const y0 = e.clientY;
    const move = (ev) => { row.style.transform = `translateY(${ev.clientY - y0}px)`; };
    const up = (ev) => { hd.removeEventListener('pointermove', move); hd.removeEventListener('pointerup', up);
      const items = [...list.querySelectorAll('.sec2-row')].filter((x) => x !== row); let idx = items.findIndex((x) => { const r = x.getBoundingClientRect(); return ev.clientY < r.top + r.height / 2; }); if (idx < 0) idx = items.length;
      const ord = items.map((x) => x.dataset.k); ord.splice(idx, 0, row.dataset.k); c.order = ord; c.sections = c.order.filter((x) => c.sections.includes(x)); mkChanged(); paintSections(); };
    hd.addEventListener('pointermove', move); hd.addEventListener('pointerup', up);
  }));
}
/* ---------- مين يشوف القسم ---------- */
function secPerm(k) {
  const C = () => secApp();
  let el = document.getElementById('sec2-sheet');
  if (!el) { el = h('section', { class: 'sheet', id: 'sec2-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  let q = '';
  const save = async (p) => { try { await Cloud.admin.sectionPermSave(p); const i = (SEC.data.perms || []).findIndex((x) => x.sec === p.sec); if (i >= 0) SEC.data.perms[i] = p; else (SEC.data.perms = SEC.data.perms || []).push(p); paint(); paintSections(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  const paint = () => {
    const c = C(), a = secAudOf(c, k), p = secPermOf(k) || { sec: k, mode: 'allow', users: [], groups: [], domains: [], until: {} };
    const sugg = q.trim() ? (A.users || []).filter((u) => !(p.users || []).includes(u.id) && (nameOf(u).includes(q.trim()) || String(u.email || '').toLowerCase().includes(q.trim().toLowerCase()))).slice(0, 6) : [];
    const dom = q.includes('@') && (q.split('@')[1] || '').includes('.') ? q.split('@')[1].trim().toLowerCase() : '';
    const inp = h('input', { class: 'input', placeholder: 'اكتب اسم أو إيميل أو @نطاق.com', value: q, autocomplete: 'off' });
    inp.addEventListener('input', () => { q = inp.value; paint(); const n = el.querySelector('.sec2-q'); n?.focus(); n?.setSelectionRange(n.value.length, n.value.length); });
    inp.classList.add('sec2-q');
    const total = (p.users || []).length + (p.groups || []).length + (p.domains || []).length;
    el.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('div', {}, h('h2', { text: `${SEC_IC[k] || ''} ${SEC_NAMES[k]}` }), h('small', { class: 'hint', text: 'مين يشوف هذا القسم؟' })), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
      h('div', { class: 'sheet-body sec2-eb' },
        h('b', { class: 'sec2-sh', text: 'الجمهور' }),
        h('div', { class: 'chips' }, ...SEC_AUD.map(([v, e, l]) => h('button', { type: 'button', class: `chip${a === v ? ' on' : ''}`, onclick: () => { secSetAud(c, k, v); paint(); } }, `${e} ${l}`))),
        a === 'custom' ? [
          h('b', { class: 'sec2-sh', text: 'الطريقة' }),
          h('div', { class: 'sec2-modes' }, ...[['allow', '✅ فقط هؤلاء', 'القسم مخفي عن الكل إلا اللي تختارهم'], ['deny', '⛔ الكل إلا هؤلاء', 'ظاهر للكل وتستثني ناس']].map(([m, t, d]) => h('button', { type: 'button', class: (p.mode || 'allow') === m ? 'on' : '', onclick: () => save({ ...p, mode: m }) }, h('b', { text: t }), h('small', { text: d })))),
          h('b', { class: 'sec2-sh', text: 'أضف بالاسم أو الإيميل أو نطاق الإيميل' }), inp,
          sugg.length || dom ? h('div', { class: 'sec2-sugg' }, ...sugg.map((u) => h('button', { type: 'button', onclick: () => { q = ''; save({ ...p, users: [...(p.users || []), u.id] }); } }, h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: nameOf(u).charAt(0).toUpperCase() }), h('span', {}, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email })), '+')),
            dom && !(p.domains || []).includes(dom) ? h('button', { type: 'button', onclick: () => { q = ''; save({ ...p, domains: [...(p.domains || []), dom] }); } }, h('span', { text: '🌐' }), h('span', {}, h('b', { text: 'كل إيميلات النطاق' }), h('small', { class: 'ltr', text: '@' + dom })), '+') : null) : null,
          secGroups().length ? h('b', { class: 'sec2-sh', text: 'أو اختر مجموعة' }) : null,
          h('div', { class: 'chips' }, ...secGroups().map((g) => h('button', { type: 'button', class: `chip${(p.groups || []).includes(g.id) ? ' on' : ''}`, onclick: () => save({ ...p, groups: (p.groups || []).includes(g.id) ? p.groups.filter((x) => x !== g.id) : [...(p.groups || []), g.id] }) }, h('i', { class: 'sec2-dot', style: { background: g.color } }), ` ${g.name} (${UI.n((g.users || []).length)})`))),
          h('b', { class: 'sec2-sh', text: `${(p.mode || 'allow') === 'allow' ? 'المسموح لهم' : 'المستثنين'} (${UI.n(total)})` }),
          h('div', { class: 'sec2-tags' },
            ...(p.users || []).map((id) => { const u = secUser(id); const ex = (p.until || {})[id];
              const d = h('input', { type: 'date', class: 'sec2-date', value: ex || '', title: 'صلاحية حتى تاريخ (اختياري)' });
              d.addEventListener('change', () => { const until = { ...(p.until || {}) }; if (d.value) until[id] = d.value; else delete until[id]; save({ ...p, until }); });
              return h('span', { class: 'sec2-tag' }, u ? nameOf(u) : id.slice(0, 8), ex ? h('em', { text: ` حتى ${ex}` }) : null, h('label', { class: 'sec2-tbtn', title: 'مدة' }, '⏳', d), h('button', { type: 'button', onclick: () => { const until = { ...(p.until || {}) }; delete until[id]; save({ ...p, users: p.users.filter((x) => x !== id), until }); } }, '✕')); }),
            ...(p.groups || []).map((gid) => { const g = secGroups().find((x) => x.id === gid); return g ? h('span', { class: 'sec2-tag g' }, `👥 ${g.name}`, h('button', { type: 'button', onclick: () => save({ ...p, groups: p.groups.filter((x) => x !== gid) }) }, '✕')) : null; }),
            ...(p.domains || []).map((dm) => h('span', { class: 'sec2-tag d ltr' }, '@' + dm, h('button', { type: 'button', onclick: () => save({ ...p, domains: p.domains.filter((x) => x !== dm) }) }, '✕')))),
          !total ? h('p', { class: 'hint', text: (p.mode || 'allow') === 'allow' ? '⚠️ ما فيه أحد — القسم مخفي عن الكل (إلا الإدارة)' : 'ما فيه مستثنين — ظاهر للكل' }) : null,
          h('p', { class: 'hint', text: '⏳ اضغط الساعة جنب أي اسم وحدد تاريخ — صلاحيته تنتهي وحدها. القائمة تنحفظ فوراً.' })] : null,
        a === 'pro' ? h('p', { class: 'hint', text: '💎 يظهر للمشتركين (وفترة التجربة والمختبرين) — وغير المشترك يشوفه 🔒 مع زر الاشتراك (أو يختفي حسب «قواعد الترتيب»). احفظ بـ«نشر التعديلات».' }) : null,
        a === 'beta' ? h('p', { class: 'hint', text: '🧪 المختبرين تحددهم من «المستخدمون» ← إجراءات المستخدم ← «اجعله مختبر».' }) : null,
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => closeSheet(el) }, 'تم')));
    UI.digitize(el);
  };
  paint(); openSheet('#sec2-sheet');
}
/* ---------- المجموعات ---------- */
function secGroup(g0) {
  let el = document.getElementById('sec2-gsheet');
  if (!el) { el = h('section', { class: 'sheet', id: 'sec2-gsheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  const g = { ...g0, users: [...(g0.users || [])] }; let q = '';
  const save = async () => { if (!g.name.trim()) return toast('اكتب اسم المجموعة'); try { const id = await Cloud.admin.sectionGroupSave(g); g.id = id || g.id; const L = SEC.data.groups = SEC.data.groups || []; const i = L.findIndex((x) => x.id === g.id); if (i >= 0) L[i] = { ...g }; else L.push({ ...g }); toast('حُفظت المجموعة ✓', { type: 'success' }); closeSheet(el); paintSections(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  const paint = () => {
    const name = h('input', { class: 'input', value: g.name, maxlength: 40, placeholder: 'مثل: العائلة' }); name.addEventListener('input', () => (g.name = name.value));
    const search = h('input', { class: 'input', placeholder: '🔎 ابحث بالاسم أو الإيميل', value: q }); search.addEventListener('input', () => { q = search.value; paintList(); });
    const listBox = h('div', { class: 'sec2-ulist' });
    const paintList = () => RC(listBox, ...(A.users || []).filter((u) => !q || nameOf(u).includes(q) || String(u.email || '').toLowerCase().includes(q.toLowerCase())).slice(0, 60).map((u) => h('button', { type: 'button', class: `sec2-u${g.users.includes(u.id) ? ' on' : ''}`, onclick: () => { g.users = g.users.includes(u.id) ? g.users.filter((x) => x !== u.id) : [...g.users, u.id]; paintList(); cnt.textContent = `${UI.n(g.users.length)} عضو`; } },
      h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: nameOf(u).charAt(0).toUpperCase() }), h('span', {}, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email })), h('i', { text: g.users.includes(u.id) ? '✅' : '⬜' }))));
    const cnt = h('small', { class: 'hint', text: `${UI.n(g.users.length)} عضو` });
    paintList();
    const used = (SEC.data.perms || []).filter((p) => (p.groups || []).includes(g.id)).map((p) => `${SEC_IC[p.sec] || ''} ${SEC_NAMES[p.sec] || p.sec}`);
    el.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('h2', { text: g.id ? 'تعديل المجموعة' : 'مجموعة جديدة' }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
      h('div', { class: 'sheet-body sec2-eb' },
        mkField('اسم المجموعة', name),
        h('div', { class: 'uia-sws' }, ...['#56C8FF', '#E5487A', '#F5C451', '#1FC7A0', '#8B45F0', '#FF9E7A'].map((col) => h('button', { type: 'button', class: `uia-sw${g.color === col ? ' on' : ''}`, style: { background: col }, onclick: () => { g.color = col; paint(); } }))),
        h('div', { class: 'sec2-gh' }, h('b', { text: 'الأعضاء' }), cnt), search, listBox,
        used.length ? h('p', { class: 'hint', text: 'مستخدمة في: ' + used.join('، ') }) : null,
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: save }, 'حفظ المجموعة'),
        g.id ? h('button', { type: 'button', class: 'btn btn-block danger', onclick: async () => { if (!(await confirmSheet({ title: 'حذف المجموعة؟', text: 'تنشال من كل الأقسام اللي مستخدمتها.', ok: 'حذف' }))) return; try { await Cloud.admin.sectionGroupDelete(g.id); SEC.data.groups = secGroups().filter((x) => x.id !== g.id); (SEC.data.perms || []).forEach((p) => { p.groups = (p.groups || []).filter((x) => x !== g.id); }); closeSheet(el); paintSections(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, 'حذف المجموعة') : null));
    UI.digitize(el);
  };
  paint(); openSheet('#sec2-gsheet');
}
/* ---------- مستخدم محدد ---------- */
function secUserBox(c) {
  const box = h('div', { class: 'sec2-ubox' });
  const inp = h('input', { class: 'input', placeholder: 'اكتب إيميل أو اسم…', value: SEC.uq, autocomplete: 'off' });
  const res = h('div', {});
  const paint = () => {
    const u = SEC.uSel ? secUser(SEC.uSel) : null;
    if (u) {
      RC(res, h('div', { class: 'sec2-urow' }, h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: nameOf(u).charAt(0).toUpperCase() }), h('span', { class: 'grow' }, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email })),
        h('button', { type: 'button', class: 'btn sm', onclick: () => { SEC.pv = u.id; paintSections(); } }, '👁 عاين كأنه هو'), h('button', { type: 'button', class: 'btn sm', onclick: () => { SEC.uSel = ''; paint(); } }, '✕')),
        h('div', { class: 'sec2-mx' }, ...c.order.map((k) => { const [ok, why] = secAccessFor(u, k, c); const o = (SEC.data.overrides || []).find((x) => x.user_id === u.id && x.sec === k)?.mode || '';
          return h('div', { class: 'sec2-mxr' }, h('span', { text: SEC_IC[k] || '•' }), h('span', { class: 'grow' }, h('b', { text: SEC_NAMES[k] }), h('small', { text: why })),
            h('span', { class: ok === true ? 'ok' : 'no', text: ok === true ? 'يشوفه' : ok === 'lock' ? '🔒 مقفل' : 'مخفي' }),
            k === 'sites' ? h('span') : h('div', { class: 'sec2-ovr' }, ...[['', 'تلقائي'], ['show', 'أظهر'], ['hide', 'أخفِ']].map(([m, l]) => h('button', { type: 'button', class: o === m ? 'on' : '', onclick: async () => {
              try { await Cloud.admin.sectionOverride(u.id, k, m); SEC.data.overrides = (SEC.data.overrides || []).filter((x) => !(x.user_id === u.id && x.sec === k)); if (m) SEC.data.overrides.push({ user_id: u.id, sec: k, mode: m }); toast('حُفظ ✓ — يوصله أول ما يفتح التطبيق', { type: 'success' }); paint(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, l)))); })));
    } else {
      const q = SEC.uq.trim().toLowerCase();
      RC(res, ...(q ? (A.users || []).filter((x) => nameOf(x).toLowerCase().includes(q) || String(x.email || '').toLowerCase().includes(q)).slice(0, 8).map((x) => h('button', { type: 'button', class: 'sec2-urow btn-like', onclick: () => { SEC.uSel = x.id; SEC.uq = ''; inp.value = ''; paint(); } },
        h('span', { class: 'u-av', style: { '--h': hueOf(x.email) }, text: nameOf(x).charAt(0).toUpperCase() }), h('span', { class: 'grow' }, h('b', { text: nameOf(x) }), h('small', { class: 'ltr', text: x.email })), secIsSub(x) ? h('span', { class: 'pill pro', text: '💎' }) : null, secIsTester(x) ? h('span', { class: 'pill beta', text: '🧪' }) : null)) : []));
    }
    UI.digitize(res);
  };
  inp.addEventListener('input', () => { SEC.uq = inp.value; SEC.uSel = ''; paint(); });
  paint();
  box.append(inp, res);
  return box;
}
