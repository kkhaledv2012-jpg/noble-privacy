/* NOBLE — المهام والتنبيهات */
'use strict';

const TSTATUS = { todo: 'للتنفيذ', doing: 'قيد العمل', done: 'منجزة' };
const REPEAT_LABEL = { daily: 'يومياً', weekdays: 'أيام العمل', weekly: 'أسبوعياً', monthly: 'شهرياً' };
const T = { mode: 'list', q: '', project: '', showDone: false, subs: [], editingId: null };

/* ---------- التواريخ ---------- */
const pad = (n) => String(n).padStart(2, '0');
const ymd = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const addDays = (d, n) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const todayStr = () => ymd(new Date());
const parseYmd = (s) => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
const dayDiff = (s) => Math.round((parseYmd(s) - parseYmd(todayStr())) / 86400000);
const LOC_ = () => UI.loc();

function dueAt(t) {
  if (!t.due) return null;
  const d = parseYmd(t.due);
  const [hh, mm] = (t.time || '09:00').split(':').map(Number);
  d.setHours(hh, mm, 0, 0);
  return d.getTime();
}
function remindAt(t) {
  if (t.remind === '' || t.remind == null || !t.due) return null;
  return dueAt(t) - Number(t.remind) * 60000;
}
function fmtTime(s) {
  const [h, m] = s.split(':').map(Number);
  const d = new Date(); d.setHours(h, m);
  return d.toLocaleTimeString(LOC_(), { hour: 'numeric', minute: '2-digit' });
}
function fmtDue(t) {
  if (!t.due) return '';
  const diff = dayDiff(t.due);
  let label;
  if (diff === 0) label = 'اليوم';
  else if (diff === 1) label = 'غداً';
  else if (diff === -1) label = 'أمس';
  else if (diff > 1 && diff < 7) label = parseYmd(t.due).toLocaleDateString(LOC_(), { weekday: 'long' });
  else label = parseYmd(t.due).toLocaleDateString(LOC_(), { day: 'numeric', month: 'short' });
  return t.time ? `${label} · ${fmtTime(t.time)}` : label;
}
function isOverdue(t) {
  if (t.status === 'done' || !t.due) return false;
  if (t.time) return dueAt(t) < Date.now();
  return dayDiff(t.due) < 0;
}
function nextDue(t) {
  const d = parseYmd(t.due);
  switch (t.repeat) {
    case 'daily': return ymd(addDays(d, 1));
    case 'weekly': return ymd(addDays(d, 7));
    case 'monthly': { const x = new Date(d); x.setMonth(x.getMonth() + 1); return ymd(x); }
    case 'weekdays': { let x = addDays(d, 1); while (x.getDay() === 5 || x.getDay() === 6) x = addDays(x, 1); return ymd(x); }
    default: return '';
  }
}

/* ---------- التنبيهات ---------- */
const Notify = {
  webTimers: new Map(),
  plugin() { return Platform.plugin('LocalNotifications'); },
  idFor(t) { let x = 0; for (const c of t.id) x = (x * 31 + c.charCodeAt(0)) | 0; return Math.abs(x) % 2000000000 || 1; },
  async allowed() {
    if (!Platform.isNative) return true;
    try {
      const p = this.plugin();
      let st = await p.checkPermissions();
      if (st.display !== 'granted') st = await p.requestPermissions();
      return st.display === 'granted';
    } catch { return false; }
  },
  async cancel(t) {
    const id = this.idFor(t);
    clearTimeout(this.webTimers.get(id));
    this.webTimers.delete(id);
    if (Platform.isNative) { try { await this.plugin().cancel({ notifications: [{ id }] }); } catch {} }
  },
  async schedule(t) {
    await this.cancel(t);
    const at = remindAt(t);
    if (!at || t.status === 'done' || at < Date.now() - 1000) return false;
    const id = this.idFor(t);
    const body = [t.time ? `الموعد ${fmtTime(t.time)}` : 'مستحقة اليوم', t.project].filter(Boolean).join(' · ');
    if (Platform.isNative) {
      if (!(await this.allowed())) return false;
      await this.plugin().schedule({
        notifications: [{ id, title: t.title, body, largeBody: t.desc || body, schedule: { at: new Date(Math.max(at, Date.now() + 2000)), allowWhileIdle: true }, extra: { taskId: t.id } }],
      });
    } else if (at - Date.now() < 86400000) {
      this.webTimers.set(id, setTimeout(() => toast(`⏰ ${t.title} — ${body}`, { duration: 8000, action: { label: 'فتح', run: () => openTaskById(t.id) } }), at - Date.now()));
    }
    return true;
  },
};

/* يعيد جدولة كل التنبيهات (عند فتح الخزنة أو بعد المزامنة) */
async function syncReminders() {
  if (!S.vault) return;
  for (const t of S.vault.tasks || []) await Notify.schedule(t);
}

/* ---------- العرض ---------- */
function taskList() {
  const q = UI.normAr(T.q.trim());
  return (S.vault.tasks || []).filter((t) => {
    if (T.project === '__high' && t.priority !== 'high') return false;
    if (T.project && T.project !== '__high' && t.project !== T.project) return false;
    if (q && !UI.normAr(`${t.title} ${t.desc} ${t.project} ${(t.subtasks || []).map((s) => s.text).join(' ')}`).includes(q)) return false;
    return true;
  });
}
const PRI_W = { high: 3, medium: 2, low: 1, none: 0 };
const byDue = (a, b) => (dueAt(a) ?? 9e15) - (dueAt(b) ?? 9e15) || PRI_W[b.priority] - PRI_W[a.priority] || a.createdAt - b.createdAt;

function renderTasks() {
  if (!S.vault) return;
  S.vault.tasks = S.vault.tasks || [];
  const all = S.vault.tasks;
  const open = all.filter((t) => t.status !== 'done');
  const overdue = open.filter(isOverdue);
  const today = all.filter((t) => t.due === todayStr());
  const todayDone = today.filter((t) => t.status === 'done').length;
  const upcoming = open.filter((t) => t.due && dayDiff(t.due) > 0 && dayDiff(t.due) <= 7);

  // شارة التبويب
  const badge = overdue.length + today.filter((t) => t.status !== 'done' && !isOverdue(t)).length;
  $('#tasks-badge').hidden = !badge;
  $('#tasks-badge').textContent = badge > 9 ? '9+' : badge;

  // البطاقة العلوية
  const pct = today.length ? todayDone / today.length : 0;
  const R = 34, C = 2 * Math.PI * R;
  const ring = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  ring.setAttribute('viewBox', '0 0 84 84');
  ring.setAttribute('class', 't-ring');
  const mk = (cls, extra) => { const c = document.createElementNS('http://www.w3.org/2000/svg', 'circle'); c.setAttribute('cx', 42); c.setAttribute('cy', 42); c.setAttribute('r', R); c.setAttribute('class', cls); Object.entries(extra || {}).forEach(([k, v]) => c.setAttribute(k, v)); return c; };
  ring.append(mk('ring-bg'), mk('ring-fg', { 'stroke-dasharray': C, 'stroke-dashoffset': C * (1 - pct) }));
  const stat = (n, label, cls, filterFn) => h('button', { type: 'button', class: `t-stat ${cls}`, onclick: filterFn }, h('b', { class: 'num', text: n }), h('span', { text: label }));
  $('#t-hero').replaceChildren(
    h('div', { class: 't-hero-top' },
      h('div', {},
        h('div', { class: 't-date', text: new Date().toLocaleDateString(LOC_(), { weekday: 'long', day: 'numeric', month: 'long' }) }),
        h('h1', { class: 'view-title', text: today.length ? (todayDone === today.length ? 'أنجزت مهام اليوم 👏' : 'مهام اليوم') : 'المهام' })),
      h('div', { class: 't-ring-wrap' }, ring, h('div', { class: 't-ring-num' }, h('b', { class: 'num', text: `${todayDone}/${today.length}` }), h('small', { text: 'اليوم' })))),
    h('div', { class: 't-stats' },
      stat(overdue.length, 'متأخرة', 'st-over', () => document.querySelector('[data-group="overdue"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })),
      stat(today.length - todayDone, 'متبقية اليوم', 'st-today', () => document.querySelector('[data-group="today"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })),
      stat(upcoming.length, 'هذا الأسبوع', 'st-week', () => document.querySelector('[data-group="week"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' })),
      stat(open.filter((t) => t.status === 'doing').length, 'قيد العمل', 'st-doing', () => { T.mode = 'board'; syncMode(); renderTasks(); })));

  // المشاريع
  const projects = new Map();
  open.forEach((t) => t.project && projects.set(t.project, (projects.get(t.project) || 0) + 1));
  const chip = (id, label, n) => h('button', { type: 'button', class: `chip${T.project === id ? ' on' : ''}`, onclick: () => { T.project = T.project === id ? '' : id; renderTasks(); } }, label, n != null ? h('span', { class: 'count num', text: n }) : null);
  $('#t-chips').replaceChildren(chip('', 'الكل', open.length), chip('__high', 'عالية الأولوية', open.filter((t) => t.priority === 'high').length),
    ...[...projects.entries()].sort((a, b) => b[1] - a[1]).map(([p, n]) => chip(p, p, n)));
  $('#project-list').replaceChildren(...[...new Set(all.map((t) => t.project).filter(Boolean))].map((p) => h('option', { value: p })));

  const list = taskList();
  $('#t-list').hidden = T.mode !== 'list';
  $('#t-board').hidden = T.mode !== 'board';
  if (T.mode === 'list') renderTaskGroups(list); else renderBoard(list);

  const empty = $('#t-empty');
  empty.hidden = list.length > 0;
  if (!list.length) empty.replaceChildren(icon('checkSquare', { size: 40 }), h('h3', { text: all.length ? 'لا نتائج' : Content.get('emptyTasksTitle') }),
    h('p', { text: all.length ? 'غيّر البحث أو المشروع.' : Content.get('emptyTasksText') }));
  $('#t-hero .t-stats').hidden = !!S.settings.hideStats;
  UI.digitize($('#view-tasks'));
  UI.digitize($('#tasks-badge').parentNode);
}

function renderTaskGroups(list) {
  const open = list.filter((t) => t.status !== 'done');
  const done = list.filter((t) => t.status === 'done').sort((a, b) => (b.doneAt || 0) - (a.doneAt || 0));
  const groups = [
    ['overdue', 'متأخرة', open.filter(isOverdue)],
    ['today', 'اليوم', open.filter((t) => t.due && dayDiff(t.due) === 0 && !isOverdue(t))],
    ['tomorrow', 'غداً', open.filter((t) => t.due && dayDiff(t.due) === 1)],
    ['week', 'هذا الأسبوع', open.filter((t) => t.due && dayDiff(t.due) > 1 && dayDiff(t.due) <= 7)],
    ['later', 'لاحقاً', open.filter((t) => t.due && dayDiff(t.due) > 7)],
    ['nodate', 'بدون موعد', open.filter((t) => !t.due)],
  ];
  const out = [];
  for (const [key, label, items] of groups) {
    if (!items.length) continue;
    out.push(h('section', { class: `t-group g-${key}`, dataset: { group: key } },
      h('div', { class: 't-group-head' }, h('span', { text: label }), h('b', { class: 'num', text: items.length })),
      h('div', { class: 't-items' }, ...items.sort(byDue).map(taskRow))));
  }
  if (done.length) {
    out.push(h('section', { class: 't-group g-done', dataset: { group: 'done' } },
      h('button', { type: 'button', class: 't-group-head t-toggle', onclick: () => { T.showDone = !T.showDone; renderTasks(); } },
        h('span', { text: `المنجزة` }), h('b', { class: 'num', text: done.length }), icon(T.showDone ? 'arrowUp' : 'arrowDown', { size: 16 })),
      T.showDone ? h('div', { class: 't-items' }, ...done.slice(0, 30).map(taskRow)) : null));
  }
  $('#t-list').replaceChildren(...out);
  if (typeof Ads !== 'undefined') Ads.inject($('#t-list .t-items'));
}

function taskMeta(t) {
  const meta = h('div', { class: 't-meta' });
  if (t.due) meta.append(h('span', { class: `t-due${isOverdue(t) ? ' over' : dayDiff(t.due) === 0 ? ' today' : ''}` }, icon('calendar', { size: 13 }), fmtDue(t)));
  if (t.remind !== '' && t.remind != null && t.due) meta.append(h('span', { class: 't-ic', title: 'تنبيه' }, icon('bell', { size: 13 })));
  if (t.repeat) meta.append(h('span', { class: 't-ic', title: REPEAT_LABEL[t.repeat] }, icon('repeat', { size: 13 }), REPEAT_LABEL[t.repeat]));
  const subs = t.subtasks || [];
  if (subs.length) meta.append(h('span', { class: 't-ic' }, icon('listCheck', { size: 13 }), `${subs.filter((s) => s.done).length}/${subs.length}`));
  if (t.project) meta.append(h('span', { class: 't-proj', text: t.project }));
  if (t.status === 'doing') meta.append(h('span', { class: 't-doing', text: 'قيد العمل' }));
  const site = t.siteId && S.vault.items.find((i) => i.id === t.siteId);
  if (site) meta.append(h('a', { class: 't-site', href: site.url, target: '_blank', rel: 'noopener noreferrer', onclick: (e) => e.stopPropagation() }, icon('link', { size: 13 }), site.name));
  return meta;
}

function taskRow(t) {
  const done = t.status === 'done';
  return h('article', { class: `t-row tp-${t.priority}${done ? ' is-done' : ''}`, dataset: { id: t.id }, onclick: (e) => { if (!e.target.closest('.t-check')) openTaskSheet(t); } },
    h('button', { type: 'button', class: 't-check', 'aria-label': done ? 'إلغاء الإنجاز' : 'إنجاز', onclick: (e) => { e.stopPropagation(); toggleDone(t.id, e.currentTarget); } }, icon('check', { size: 15, stroke: 3 })),
    h('div', { class: 't-body' }, h('div', { class: 't-title', text: t.title }), t.desc ? h('div', { class: 't-desc', text: t.desc }) : null, taskMeta(t)));
}

function renderBoard(list) {
  const cols = ['todo', 'doing', 'done'];
  const order = { todo: 0, doing: 1, done: 2 };
  $('#t-board').replaceChildren(...cols.map((st) => {
    const items = list.filter((t) => t.status === st).sort(st === 'done' ? (a, b) => (b.doneAt || 0) - (a.doneAt || 0) : byDue);
    return h('section', { class: `b-col col-${st}` },
      h('div', { class: 'b-head' }, h('i'), h('span', { text: TSTATUS[st] }), h('b', { class: 'num', text: items.length })),
      h('div', { class: 'b-items' }, ...items.slice(0, st === 'done' ? 20 : 200).map((t) =>
        h('article', { class: `b-card tp-${t.priority}`, onclick: () => openTaskSheet(t) },
          h('div', { class: 't-title', text: t.title }),
          taskMeta(t),
          h('div', { class: 'b-move' },
            order[st] > 0 ? h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'رجوع خطوة', onclick: (e) => { e.stopPropagation(); moveTask(t.id, cols[order[st] - 1]); } }, icon('arrowLeft', { size: 16 })) : h('span'),
            order[st] < 2 ? h('button', { type: 'button', class: 'b-next', onclick: (e) => { e.stopPropagation(); moveTask(t.id, cols[order[st] + 1]); } }, cols[order[st] + 1] === 'done' ? 'إنجاز' : 'ابدأ', icon('arrowLeft', { size: 14 })) : null)))),
      st !== 'done' ? h('button', { type: 'button', class: 'b-add', onclick: () => openTaskSheet(null, { status: st }) }, icon('plus', { size: 16 }), 'إضافة') : null);
  }));
}

function syncMode() { $$('#t-mode input').forEach((r) => (r.checked = r.value === T.mode)); }

/* ---------- الإجراءات ---------- */
async function toggleDone(id, btn) {
  const before = JSON.parse(JSON.stringify(S.vault.tasks));
  const row = btn?.closest('.t-row, .b-card');
  if (row) row.classList.add('completing');
  await new Promise((r) => setTimeout(r, 260));
  let created = null, nowDone = false;
  await commit((v) => {
    const t = v.tasks.find((x) => x.id === id);
    if (!t) return;
    nowDone = t.status !== 'done';
    t.status = nowDone ? 'done' : 'todo';
    t.doneAt = nowDone ? Date.now() : 0;
    t.updatedAt = Date.now();
    if (nowDone && t.repeat && t.due) {
      created = { ...JSON.parse(JSON.stringify(t)), id: crypto.randomUUID(), due: nextDue(t), status: 'todo', doneAt: 0, createdAt: Date.now(),
        subtasks: (t.subtasks || []).map((s) => ({ ...s, id: crypto.randomUUID(), done: false })) };
      t.repeat = '';
      v.tasks.push(created);
    }
  });
  const t = S.vault.tasks.find((x) => x.id === id);
  if (t) await Notify.schedule(t);
  if (created) await Notify.schedule(created);
  if (nowDone) { buzz('success'); if (typeof awardTask === 'function') awardTask(id); if (typeof markActive === 'function') markActive('task'); }
  if (nowDone) toast(created ? `أُنجزت ✓ — التكرار التالي ${fmtDue(created)}` : 'أُنجزت المهمة ✓', { type: 'success', action: { label: 'تراجع', run: () => restoreTasks(before, created) } });
}
async function restoreTasks(before, created) {
  if (created) await Notify.cancel(created);
  await commit((v) => { v.tasks = before; });
  syncReminders();
}
async function moveTask(id, status) {
  if (status === 'done') return toggleDone(id);
  await commit((v) => { const t = v.tasks.find((x) => x.id === id); t.status = status; t.doneAt = 0; t.updatedAt = Date.now(); });
  const t = S.vault.tasks.find((x) => x.id === id);
  if (t) Notify.schedule(t);
}
function openTaskById(id) {
  const t = S.vault?.tasks.find((x) => x.id === id);
  setTab('tasks');
  if (t) openTaskSheet(t);
}

/* ---------- نموذج المهمة ---------- */
function renderSubs() {
  const box = $('#subtasks');
  box.replaceChildren(...T.subs.map((s, i) => h('div', { class: `sub${s.done ? ' done' : ''}` },
    h('button', { type: 'button', class: 'sub-check', 'aria-label': 'إنجاز', onclick: () => { s.done = !s.done; renderSubs(); } }, icon('check', { size: 12, stroke: 3 })),
    h('input', { class: 'sub-text', value: s.text, oninput: (e) => (s.text = e.target.value) }),
    h('button', { type: 'button', class: 'icon-btn sub-del', 'aria-label': 'حذف', onclick: () => { T.subs.splice(i, 1); renderSubs(); } }, icon('x', { size: 14 })))));
  $('#sub-count').textContent = T.subs.length ? `${T.subs.filter((s) => s.done).length}/${T.subs.length}` : '';
}

function openTaskSheet(task = null, draft = {}) {
  const f = $('#task-form');
  f.reset();
  T.editingId = task?.id || null;
  const src = task || { status: 'todo', priority: 'none', remind: '', repeat: '', ...draft };
  $('#task-title-h').textContent = task ? 'تعديل المهمة' : 'مهمة جديدة';
  f.elements.title.value = src.title || '';
  f.elements.desc.value = src.desc || '';
  f.elements.date.value = src.due || '';
  f.elements.time.value = src.time || '';
  f.elements.remind.value = src.remind ?? '';
  f.elements.repeat.value = src.repeat || '';
  f.elements.repeat.onchange = () => { // التكرار من مزايا Pro (المهام المتكررة الموجودة تبقى تعمل)
    if (f.elements.repeat.value && !src.repeat && typeof Pro !== 'undefined' && !Pro.has('tasks.repeat')) { f.elements.repeat.value = ''; Pro.gate('tasks.repeat'); }
  };
  f.elements.project.value = src.project || '';
  f.elements.status.value = src.status || 'todo';
  $$('input[name=tpriority]', f).forEach((r) => (r.checked = r.value === (src.priority || 'none')));
  const sel = $('#task-site');
  sel.replaceChildren(h('option', { value: '', text: 'بدون' }), ...[...S.vault.items].sort((a, b) => a.name.localeCompare(b.name, 'ar')).map((i) => h('option', { value: i.id, text: `${i.name} — ${Core.domainOf(i.url)}` })));
  sel.value = src.siteId || '';
  T.subs = JSON.parse(JSON.stringify(src.subtasks || []));
  renderSubs();
  $('#task-delete').hidden = !task;
  $('#task-error').textContent = '';
  $('#task-meta').textContent = task ? `أُنشئت ${UI.relTime(task.createdAt)}${task.doneAt ? ' · أُنجزت ' + UI.relTime(task.doneAt) : ''}` : '';
  openSheet('#task-sheet');
  $('#task-sheet').scrollTop = 0;
  if (!task) setTimeout(() => f.elements.title.focus(), 280);
}

async function saveTask(e) {
  e.preventDefault();
  const f = e.target.elements;
  const title = f.title.value.trim();
  if (!title) { $('#task-error').textContent = 'اكتب عنوان المهمة'; return f.title.focus(); }
  if (f.remind.value !== '' && !f.date.value) { $('#task-error').textContent = 'حدد تاريخاً حتى يعمل التنبيه'; return f.date.focus(); }
  if (f.repeat.value && !f.date.value) { $('#task-error').textContent = 'التكرار يحتاج تاريخاً للبداية'; return f.date.focus(); }
  const data = {
    title: title.slice(0, 200), desc: f.desc.value.trim().slice(0, 5000), due: f.date.value, time: f.time.value,
    remind: f.remind.value, repeat: f.repeat.value, project: f.project.value.trim().slice(0, 60), status: f.status.value,
    priority: $('input[name=tpriority]:checked', e.target)?.value || 'none', siteId: f.siteId.value,
    subtasks: T.subs.filter((s) => s.text.trim()).map((s) => ({ id: s.id || crypto.randomUUID(), text: s.text.trim().slice(0, 200), done: !!s.done })),
  };
  const id = T.editingId;
  let saved;
  const ok = await commit((v) => {
    v.tasks = v.tasks || [];
    if (id) {
      saved = v.tasks.find((t) => t.id === id);
      const wasDone = saved.status === 'done';
      Object.assign(saved, data, { updatedAt: Date.now() });
      if (!wasDone && data.status === 'done') saved.doneAt = Date.now();
      if (data.status !== 'done') saved.doneAt = 0;
    } else {
      saved = { id: crypto.randomUUID(), ...data, createdAt: Date.now(), updatedAt: Date.now(), doneAt: data.status === 'done' ? Date.now() : 0 };
      v.tasks.push(saved);
    }
  });
  if (!ok) return;
  closeSheet($('#task-sheet'));
  const scheduled = await Notify.schedule(S.vault.tasks.find((t) => t.id === saved.id));
  if (data.remind !== '' && data.due && !scheduled && remindAt(data) > Date.now()) toast('لم يُسمح بالإشعارات — فعّلها من إعدادات الجوال', { type: 'error', duration: 6000 });
  else toast(id ? 'تم حفظ المهمة' : scheduled ? `أُضيفت — سننبّهك ${fmtDue(data)}` : 'أُضيفت المهمة', { type: 'success' });
}

function bindTasks() {
  $('#sub-add-btn').append(icon('plus', { size: 18 }));
  $('#task-delete').append(icon('trash', { size: 18 }), 'حذف');
  $('#task-form').addEventListener('submit', saveTask);
  const addSub = () => {
    const inp = $('#sub-new');
    if (!inp.value.trim()) return;
    T.subs.push({ id: crypto.randomUUID(), text: inp.value.trim(), done: false });
    inp.value = '';
    renderSubs();
    inp.focus();
  };
  $('#sub-add-btn').addEventListener('click', addSub);
  $('#sub-new').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); addSub(); } });
  $('#quick-dates').addEventListener('click', (e) => {
    const q = e.target.closest('[data-q]')?.dataset.q;
    if (!q) return;
    const f = $('#task-form').elements;
    f.date.value = q === 'none' ? '' : ymd(addDays(new Date(), { today: 0, tomorrow: 1, week: 7 }[q]));
    if (q === 'none') { f.time.value = ''; f.remind.value = ''; f.repeat.value = ''; }
    else if (!f.time.value) f.time.value = '09:00';
  });
  $('#task-delete').addEventListener('click', async () => {
    const t = S.vault.tasks.find((x) => x.id === T.editingId);
    if (!t) return;
    closeSheet($('#task-sheet'));
    const copy = { ...t };
    await Notify.cancel(t);
    await commit((v) => { if (typeof Trash !== 'undefined') Trash.put(v, 'task', copy); v.tasks = v.tasks.filter((x) => x.id !== t.id); });
    toast(`🗑️ «${t.title}» انتقلت لسلة المحذوفات`, { action: { label: 'تراجع', run: () => Trash.undo('task', copy.id) }, duration: 6000 });
  });
  $('#t-mode').addEventListener('change', (e) => { T.mode = e.target.value; renderTasks(); });
  let tm;
  $('#t-search').addEventListener('input', (e) => { clearTimeout(tm); tm = setTimeout(() => { T.q = e.target.value; renderTasks(); }, 120); });

  // الضغط على الإشعار يفتح المهمة
  if (Platform.isNative) {
    Platform.plugin('LocalNotifications').addListener('localNotificationActionPerformed', (ev) => {
      if (ev?.notification?.extra?.tab === 'news') { if (S.unlocked) setTab('news'); return; }
      if (ev?.notification?.extra?.action === 'mysub') { if (S.unlocked && typeof openMySub === 'function') openMySub(); return; }
      const id = ev?.notification?.extra?.taskId;
      if (!id) return;
      if (S.unlocked) openTaskById(id);
      else S.pendingTask = id;
    });
  }
  // مراجعة المتأخر كل دقيقة لتحديث الألوان
  setInterval(() => { if (S.unlocked && S.tab === 'tasks' && !S.sheets.length) renderTasks(); }, 60000);
}

document.addEventListener('DOMContentLoaded', bindTasks);
