/* NOBLE — لوحة التحكم ← الرسائل ← «🔔 الإشعارات» (1.19)
 * إشعار يطلع على جوال المستخدم (نفس إشعار الأذان): للجميع أو لأشخاص محددين، الآن أو بوقت محدد،
 * ولما يضغطه يفتح القسم اللي تختاره. المرحلة ١ بدون Firebase: يوصل لما يفتح المستخدم التطبيق،
 * والمجدول يطلع في وقته بالضبط على كل جوال فتح التطبيق بعد ما جدولته.
 */
'use strict';
const PU = { view: 'msg', kind: 'all', people: new Set(), q: '', when: 'now', editing: null, list: [], icon: 'noble', fcm: true, img: 'def', imgSt: '' };
// 1.21.22: fcm = يوصل فوراً حتى لو التطبيق مسكّر (Firebase) · img = 'def' الافتراضية من إعدادات الإشعارات / رابط صورتك / '' بدون
const PU_TABS = [['', 'بدون (يفتح التطبيق بس)'], ['today', '☀️ يومي'], ['tasks', '✅ المهام'], ['news', '📰 الأخبار'], ['sites', '🔗 المواقع'], ['finance', '💰 المالية'], ['games', '🎮 الألعاب'], ['designs', '🎨 التصاميم'], ['azkar', '🤍 أذكاري'], ['discover', '▶️ اكتشف']];
const puName = (k) => (PU_TABS.find((t) => t[0] === k) || [, ''])[1];

/* التبديل بين «الرسائل» و«الإشعارات» داخل نفس التبويب */
function puMountSwitch() {
  const host = $('#a-messages');
  if (!host || host.querySelector('.pu-switch')) return;
  const nav = h('nav', { class: 'pu-switch', role: 'tablist' },
    h('button', { type: 'button', 'data-v': 'msg', class: 'on', onclick: () => puShow('msg') }, '✉️ الرسائل'),
    h('button', { type: 'button', 'data-v': 'push', onclick: () => puShow('push') }, '🔔 الإشعارات'));
  host.querySelector('.a-hero').after(nav);
  host.append(h('div', { id: 'a-push', hidden: true }));
}
function puShow(v) {
  PU.view = v;
  const host = $('#a-messages');
  host.querySelectorAll('.pu-switch button').forEach((b) => b.classList.toggle('on', b.dataset.v === v));
  [...host.children].forEach((el) => { if (el.matches('.a-hero, .pu-switch')) return; el.hidden = el.id === 'a-push' ? v !== 'push' : v === 'push'; });
  if (v === 'push') openPushAdmin();
}

async function openPushAdmin() {
  puPaint();
  try { PU.list = (await Cloud.admin.pushList()) || []; } catch (e) { PU.list = []; PU.err = /function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.19.sql في Supabase أول' : Cloud.msg(e); }
  puPaintList();
}
const puLocal = (t) => { const d = new Date(t); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); return d.toISOString().slice(0, 16); };

function puPaint() {
  const box = $('#a-push'); if (!box) return;
  const canAll = can('messages.broadcast');
  if (!canAll) PU.kind = 'some';
  const title = h('input', { class: 'input', id: 'pu-title', maxlength: 80, placeholder: 'مثال: 🔥 عدد جديد من NOBLE عاجل' });
  const body = h('textarea', { class: 'input textarea', id: 'pu-body', rows: 3, maxlength: 240, placeholder: 'سطر أو سطرين يظهرون تحت العنوان' });
  const tab = h('select', { class: 'input select', id: 'pu-tab' }, ...PU_TABS.map(([k, l]) => h('option', { value: k, text: l })));
  const link = h('input', { class: 'input ltr', id: 'pu-link', inputmode: 'url', placeholder: 'https://… (اختياري)' });
  const at = h('input', { class: 'input ltr', id: 'pu-at', type: 'datetime-local', hidden: PU.when !== 'at', value: puLocal(Date.now() + 3600e3) });
  const seg = (name, map, cur, on) => h('div', { class: `seg seg-${Object.keys(map).length}` }, ...Object.entries(map).map(([k, l]) => h('label', {}, h('input', { type: 'radio', name, value: k, checked: k === cur, onchange: () => on(k) }), h('span', { text: l }))));
  const people = h('div', { class: 'm-people', id: 'pu-people', hidden: PU.kind !== 'some' });
  const err = h('p', { class: 'form-error', id: 'pu-err' });
  const send = h('button', { type: 'submit', class: 'btn btn-primary btn-block', id: 'pu-send' }, '🔔 إرسال الإشعار');
  const form = h('form', { class: 'set-card m-form pu-form', novalidate: true },
    h('div', { class: 'm-form-head' }, h('strong', { id: 'pu-ftitle', text: 'إشعار جديد' }), h('button', { type: 'button', class: 'btn sm', id: 'pu-cancel', hidden: true, onclick: () => { PU.editing = null; puPaint(); puPaintList(); } }, 'إلغاء التعديل')),
    h('p', { class: 'hint', text: 'يطلع على جوال المستخدم مثل إشعار الأذان، ولما يضغطه يفتح القسم اللي تختاره.' }),
    h('div', { class: 'm-sec' }, h('span', { class: 'm-sec-t', text: 'لمن؟' }),
      canAll ? seg('pukind', { all: 'للجميع', some: 'أشخاص محددين' }, PU.kind, (k) => { PU.kind = k; people.hidden = k !== 'some'; if (k === 'some') puPeople(); puSyncBtn(); }) : null, people),
    h('div', { class: 'm-sec' }, h('span', { class: 'm-sec-t', text: 'الأيقونة' }),
      h('div', { class: 'pu-icons', id: 'pu-icons' }, ...NotIcons.LIST.map(([k, l]) => h('button', { type: 'button', class: `pu-ic${PU.icon === k ? ' on' : ''}`, title: l, 'aria-label': l, 'data-k': k, onclick: () => { PU.icon = k; $$('#pu-icons .pu-ic').forEach((b) => b.classList.toggle('on', b.dataset.k === k)); puPreview(); } }, h('img', { src: NotIcons.src(k), alt: '' }), h('small', { text: l })))),
      h('p', { class: 'hint', text: 'تطلع كصورة جنب الإشعار. الدائرة الصغيرة على اليسار هي أيقونة التطبيق نفسه — أندرويد ما يسمح بتغييرها لكل إشعار.' })),
    mkFieldP('العنوان', title), mkFieldP('النص', body),
    // 🖼️📲 1.21.22: صورة كبيرة + يوصل حتى لو التطبيق مسكّر
    h('div', { class: 'm-sec' }, h('span', { class: 'm-sec-t', text: '🖼️ صورة كبيرة (مثل الجزيرة)' }),
      seg('puimg', { def: 'الافتراضية', up: '⬆️ صورتي', none: 'بدون' }, PU.img === 'def' ? 'def' : PU.img ? 'up' : 'none', (k) => {
        if (k === 'up') { const i = h('input', { type: 'file', accept: 'image/*' }); i.addEventListener('change', async () => { if (!i.files[0] || typeof PushImg === 'undefined') return; const st = $('#pu-imgst'); if (st) st.textContent = '⏳ رفع…'; try { PU.img = await PushImg.upload(await PushImg.fromFile(i.files[0])); if (st) st.textContent = '✓ انرفعت'; } catch (x) { if (st) st.textContent = Cloud.msg(x); } puPreview(); }); i.click(); return; }
        PU.img = k === 'def' ? 'def' : ''; puPreview(); }),
      h('small', { class: 'hint', id: 'pu-imgst', text: 'المقاس 1440×720 — نقصّها ونصغّرها لحالها. «الافتراضية» تتغير من: الأخبار ← الإعدادات ← 🖼️ صور الإشعارات.' })),
    h('label', { class: 'switch-row', id: 'pu-fcm-row', hidden: PU.when !== 'now' }, h('span', {}, h('b', { text: '📲 يوصل فوراً حتى لو التطبيق مسكّر' }), h('small', { text: 'عن طريق Firebase — والصورة الكبيرة ما تطلع إلا بهذي الطريقة' })),
      h('span', { class: 'switch' }, h('input', { type: 'checkbox', id: 'pu-fcm', checked: PU.fcm, onchange: (e) => { PU.fcm = e.target.checked; } }), h('span', { class: 'track' }))),
    h('div', { class: 'm-sec' }, h('span', { class: 'm-sec-t', text: 'متى؟' }),
      seg('puwhen', { now: '⚡ الآن', at: '🕒 وقت محدد' }, PU.when, (k) => { PU.when = k; at.hidden = k !== 'at'; const r = $('#pu-fcm-row'); if (r) r.hidden = k !== 'now'; puSyncBtn(); }), at),
    mkFieldP('لما يضغطه يفتح', tab), mkFieldP('رابط (اختياري — يفتح بعد القسم)', link),
    h('details', { class: 'pu-how' }, h('summary', { text: 'ℹ️ كيف يوصل الإشعار؟' }),
      h('p', { class: 'hint', text: '• «الآن»: يطلع لكل مستخدم أول ما يفتح التطبيق أو يرجع له (خلال يوم).' }),
      h('p', { class: 'hint', text: '• «وقت محدد»: يتجدول على الجوال ويطلع في وقته بالضبط حتى لو التطبيق مسكّر — لكل اللي فتحوا التطبيق بعد ما جدولته. عشان كذا جدوله قبلها بيوم أو أكثر.' }),
      h('p', { class: 'hint', text: '• «الآن» + «📲 يوصل فوراً»: يوصل خلال ثواني لكل الجوالات حتى المسكّرة، وبالصورة الكبيرة (1.21.22).' })),
    err, send);
  form.addEventListener('submit', puSubmit);
  [title, body].forEach((i) => i.addEventListener('input', puPreview));
  tab.addEventListener('change', puPreview);
  box.replaceChildren(
    h('div', { class: 'm-layout' }, form,
      h('section', { class: 'm-side pu-side' }, h('strong', { text: 'المعاينة على الجوال' }), h('div', { class: 'pu-phone', id: 'pu-pv' }))),
    h('h3', { class: 'set-title', text: 'الإشعارات المرسلة والمجدولة' }),
    h('section', { class: 'pu-list', id: 'pu-list' }, h('p', { class: 'hint', text: 'جارٍ التحميل…' })));
  if (PU.kind === 'some') puPeople();
  if (PU.editing) {
    const n = PU.list.find((x) => x.id === PU.editing);
    if (n) { title.value = n.title; body.value = n.body || ''; tab.value = n.tab || ''; link.value = n.link || ''; at.value = puLocal(new Date(n.send_at).getTime()); $('#pu-ftitle').textContent = 'تعديل إشعار'; $('#pu-cancel').hidden = false; }
  }
  puSyncBtn(); puPreview();
}
function mkFieldP(label, el) { return h('label', { class: 'field' }, h('span', { text: label }), el); }
function puSyncBtn() {
  const b = $('#pu-send'); if (!b) return;
  const n = PU.people.size;
  b.textContent = PU.editing ? '💾 حفظ التعديل' : `🔔 ${PU.when === 'at' ? 'جدولة' : 'إرسال'} ${PU.kind === 'some' ? (n ? `لـ ${UI.n(n)} شخص` : '') : 'للجميع'}`;
}
function puPeople() {
  const box = $('#pu-people'); if (!box) return;
  const q = UI.normAr(PU.q.trim().toLowerCase());
  const users = (A.users || []).filter((u) => u.id !== A.me?.id && u.status !== 'suspended');
  const list = users.filter((u) => !q || UI.normAr(`${nameOf(u)} ${u.email || ''}`.toLowerCase()).includes(q)).slice(0, 40);
  const inp = h('input', { class: 'input', placeholder: 'ابحث بالاسم أو الإيميل…', value: PU.q });
  inp.addEventListener('input', () => { PU.q = inp.value; puPeople(); const i = $('#pu-people input'); i?.focus(); i?.setSelectionRange(i.value.length, i.value.length); });
  box.replaceChildren(
    h('div', { class: 'm-chosen' }, ...(PU.people.size ? [...PU.people].map((id) => { const u = users.find((x) => x.id === id); return h('span', { class: 'chip on m-chip' }, u ? nameOf(u) : 'مستخدم', h('button', { type: 'button', 'aria-label': 'إزالة', onclick: () => { PU.people.delete(id); puPeople(); puSyncBtn(); } }, '✕')); }) : [h('small', { class: 'hint', text: 'ما اخترت أحد للحين' })])),
    inp,
    h('div', { class: 'm-people-list' }, ...list.map((u) => { const on = PU.people.has(u.id); return h('button', { type: 'button', class: `m-person${on ? ' on' : ''}`, onclick: () => { on ? PU.people.delete(u.id) : PU.people.add(u.id); puPeople(); puSyncBtn(); } }, h('span', { class: 'u-av sm', style: { '--h': hueOf(u.email || u.id) }, text: nameOf(u).charAt(0).toUpperCase() }), h('span', { class: 'm-person-t' }, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email || '' })), h('span', { class: 'm-check', text: on ? '✓' : '' })); })));
}
function puPreview() {
  const pv = $('#pu-pv'); if (!pv) return;
  const t = $('#pu-title')?.value.trim() || 'عنوان الإشعار', b = $('#pu-body')?.value.trim() || 'نص الإشعار يظهر هنا', tab = $('#pu-tab')?.value;
  pv.replaceChildren(
    h('div', { class: 'pu-status' }, h('b', { text: '5:58' }), h('span', { text: '📶 🔋' })),
    h('div', { class: 'pu-note' },
      h('span', { class: 'pu-appic' }, h('img', { src: typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png', alt: '' })),
      h('div', { class: 'pu-nt' }, h('div', { class: 'pu-app' }, h('b', { text: 'NOBLE' }), h('small', { text: 'الآن' })), h('strong', { text: t }), h('p', { text: b })),
      h('img', { class: 'pu-large', src: NotIcons.src(PU.icon), alt: '' })),
    PU.img && PU.img !== 'def' ? h('img', { class: 'pu-bigimg', src: PU.img, alt: '' }) : PU.img === 'def' ? h('small', { class: 'pu-goes', text: '🖼️ + الصورة الافتراضية لإشعاراتك' }) : null,
    tab ? h('small', { class: 'pu-goes', text: `لما يضغطه ← ${puName(tab)}` }) : null);
}
async function puSubmit(e) {
  e.preventDefault();
  const err = $('#pu-err'); err.textContent = '';
  const title = $('#pu-title').value.trim(), body = $('#pu-body').value.trim();
  if (!title) return (err.textContent = 'اكتب عنوان للإشعار');
  if (PU.kind === 'some' && !PU.people.size) return (err.textContent = 'اختر شخص واحد على الأقل');
  let sendAt = new Date();
  if (PU.when === 'at') { const v = $('#pu-at').value; if (!v) return (err.textContent = 'حدد الوقت'); sendAt = new Date(v); if (sendAt.getTime() < Date.now() - 60000) return (err.textContent = 'الوقت اللي اخترته راح'); }
  const rawLink = $('#pu-link').value.trim(), link = rawLink ? Links.norm(rawLink) : '';
  if (rawLink && !link) return (err.textContent = 'الرابط مو صحيح');
  const btn = $('#pu-send'); btn.disabled = true;
  try {
    const viaFcm = PU.fcm && PU.when === 'now' && !PU.editing;
    const id = await Cloud.admin.pushSave({ id: PU.editing || undefined, icon: PU.icon, title, body, tab: $('#pu-tab').value, link, send_at: sendAt.toISOString(), targets: PU.kind === 'some' ? [...PU.people] : [], fcm: viaFcm, image: PU.img === 'def' ? 'def' : PU.img || '' });
    let sent = null;
    if (viaFcm) {
      try { const r = await Cloud.admin.pushSend({ kind: 'custom', id }); sent = r?.sent ?? 0; }
      catch (x) { toast('انحفظ، بس Firebase ما أرسله: ' + Cloud.msg(x) + ' — بيطلع لهم لما يفتحون التطبيق', { type: 'error', duration: 8000 }); try { await Cloud.admin.pushSave({ id, icon: PU.icon, title, body, tab: $('#pu-tab').value, link, send_at: sendAt.toISOString(), targets: PU.kind === 'some' ? [...PU.people] : [], fcm: false, image: '' }); } catch { /* لا شيء */ } }
    }
    toast(PU.editing ? 'انحفظ التعديل ✓' : PU.when === 'at' ? `🕒 انجدول — يطلع ${sendAt.toLocaleString('ar', { weekday: 'long', hour: 'numeric', minute: '2-digit' })}` : sent != null ? `📲 وصل لـ ${UI.n(sent)} جهاز — حتى المسكّرة` : '🔔 انرسل — يطلع للمستخدمين أول ما يفتحون التطبيق', { type: 'success', duration: 4500 });
    PU.editing = null; PU.people = new Set(); PU.when = 'now'; PU.icon = 'noble'; PU.img = 'def';
    openPushAdmin();
  } catch (ex) { err.textContent = Cloud.msg(ex); btn.disabled = false; }
}
function puPaintList() {
  const box = $('#pu-list'); if (!box) return;
  if (PU.err) { box.replaceChildren(h('p', { class: 'note-box', text: PU.err })); PU.err = ''; return; }
  if (!PU.list.length) return box.replaceChildren(h('div', { class: 'empty' }, h('p', { text: '🔔 ما أرسلت إشعارات للحين' })));
  const now = Date.now();
  box.replaceChildren(...PU.list.map((n) => {
    const t = new Date(n.send_at).getTime(), future = t > now;
    const pctG = n.audience ? Math.min(100, Math.round((n.got / n.audience) * 100)) : 0, pctO = n.got ? Math.round((n.opened / n.got) * 100) : 0;
    const who = n.targets?.length ? (n.targets.length === 1 ? nameOf((A.users || []).find((u) => u.id === n.targets[0]) || { email: 'مستخدم' }) : `${UI.n(n.targets.length)} أشخاص`) : 'للجميع';
    return h('article', { class: `pu-item${n.active ? '' : ' off'}` },
      h('div', { class: 'pu-ih' }, h('img', { class: 'pu-li', src: NotIcons.src(n.icon), alt: '' }), h('b', { text: n.title }), h('span', { class: `pill ${future ? 'nick' : 'role-admin'}`, text: !n.active ? 'موقوف' : future ? '🕒 مجدول' : '✓ انرسل' })),
      n.body ? h('p', { class: 'hint', text: n.body }) : null,
      h('div', { class: 'nt-meta' },
        h('span', { class: 'chip sm', text: `👥 ${who}` }),
        h('span', { class: 'chip sm', text: `🕒 ${new Date(t).toLocaleString('ar', { day: 'numeric', month: 'short', hour: 'numeric', minute: '2-digit' })}` }),
        n.tab ? h('span', { class: 'chip sm', text: `↪ ${puName(n.tab)}` }) : null),
      h('div', { class: 'pu-stats' },
        h('div', {}, h('small', { text: `وصل لـ ${UI.n(n.got)} من ${UI.n(n.audience)}` }), h('div', { class: 'nt-prog' }, h('i', { style: { width: pctG + '%' } }))),
        h('div', {}, h('small', { text: `ضغطه ${UI.n(n.opened)} (${UI.n(pctO)}٪)` }), h('div', { class: 'nt-prog o' }, h('i', { style: { width: pctO + '%' } })))),
      h('div', { class: 'nt-btns' },
        future ? h('button', { type: 'button', class: 'btn sm', onclick: () => { PU.editing = n.id; PU.icon = NotIcons.pick(n.icon); PU.kind = n.targets?.length ? 'some' : 'all'; PU.people = new Set(n.targets || []); PU.when = 'at'; puPaint(); $('#a-push').scrollIntoView({ behavior: 'smooth' }); } }, '✏️ تعديل') : null,
        h('button', { type: 'button', class: 'btn sm', onclick: () => { PU.editing = null; PU.icon = NotIcons.pick(n.icon); PU.kind = n.targets?.length ? 'some' : 'all'; PU.people = new Set(n.targets || []); PU.when = 'now'; puPaint(); $('#pu-title').value = n.title; $('#pu-body').value = n.body || ''; $('#pu-tab').value = n.tab || ''; $('#pu-link').value = n.link || ''; puPreview(); toast('نسخته — عدّل واضغط إرسال'); } }, '📋 نسخ'),
        h('button', { type: 'button', class: 'btn sm', onclick: async () => { try { await Cloud.admin.pushSet(n.id, !n.active); openPushAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, n.active ? 'إيقاف' : 'تفعيل'),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => { if (await confirmSheet({ title: 'حذف الإشعار؟', text: future ? 'ينلغي من الجوالات اللي جدولته لما تفتح التطبيق.' : 'ينحذف من القائمة والإحصائيات.', ok: 'حذف' })) { try { await Cloud.admin.pushDelete(n.id); openPushAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } } }, '🗑')));
  }));
}
document.addEventListener('DOMContentLoaded', () => { try { puMountSwitch(); } catch { /* لا شيء */ } });
