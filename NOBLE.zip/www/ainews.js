/* NOBLE — «⚡ NOBLE عاجل» داخل قسم الأخبار (1.18) — أيقونة واضحة فوق في الأخبار تفتحه
 * ملخص أخبار الذكاء الاصطناعي (يومي/أسبوعي/شهري حسب اختيار الإدارة) كسلايدات متحركة بالفيديو. العدد الأحدث كبير فوق، وأخباره تحته، والأعداد السابقة.
 * العارض مثل الستوري (سحب، ضغط يمين/يسار، شرائط تقدم)، والمستخدم ينزّله كاروسيل ٤:٥ أو ستوري ٩:١٦ ويشاركه.
 * العدد المثبّت يطلع كبطاقة مهمة في «يومي»، وكل عدد ينزل منشور في «اكتشف».
 */
'use strict';
const AIN = { items: [], kit: null, loaded: 0, loading: null, raf: 0, vw: null };
const AIN_KEY = 'nw:ainews', AIN_SEEN = 'nw:ainews:seen';
const ainN = (x) => UI.n(x);
(() => { try { const c = JSON.parse(localStorage.getItem(AIN_KEY) || 'null'); if (c?.items) { AIN.items = c.items; AIN.kit = c.kit || null; } } catch { /* لا شيء */ } })();
const ainKit = () => AISlides.kitOf(AIN.kit);
const ainPinned = () => AIN.items.find((x) => x.pinned_until && new Date(x.pinned_until) > new Date());

async function loadAiNews(force) {
  if (!Cloud.enabled) return;
  if (!force && Date.now() - AIN.loaded < 120000) return;
  if (AIN.loading) return AIN.loading;
  AIN.loading = (async () => {
    const before = JSON.stringify(AIN.items.map((x) => [x.id, x.updated_at || x.published_at, x.pinned_until]));
    AIN.loaded = Date.now(); // حتى لو فشل: ما نعيد المحاولة فوراً (بدون حلقة)
    try {
      const r = await Cloud.soon(Cloud.aiFeed(20), 12000); // 📴 1.21.14: بدون نت نعرض المحفوظ فوراً
      AIN.items = r?.items || []; AIN.kit = r?.kit || null;
      try { localStorage.setItem(AIN_KEY, JSON.stringify({ items: AIN.items.slice(0, 12), kit: AIN.kit })); } catch { /* لا شيء */ }
    } catch { /* نعرض المحفوظ */ }
    AIN.loading = null;
    const changed = before !== JSON.stringify(AIN.items.map((x) => [x.id, x.updated_at || x.published_at, x.pinned_until]));
    if (S.tab === 'news' && NEWS.view === 'ai' && !AIN.vw) renderNews();
    else if (changed && S.tab === 'news') ainPaintBtn();
    if (changed && S.tab === 'today' && typeof renderToday === 'function') renderToday();
    ainPaintBell();
  })();
  return AIN.loading;
}

/* أيقونة «عاجل» فوق في الأخبار (عليها نقطة لو فيه عدد جديد ما شافه) */
const ainHasNew = () => !!AIN.items[0] && !ainSeen().includes(AIN.items[0].id);
function ainNewsBtn() {
  return h('button', { type: 'button', class: `n-ai-btn${ainHasNew() ? ' new' : ''}`, 'aria-label': 'NOBLE عاجل', onclick: () => { NEWS.view = 'ai'; renderNews(); window.scrollTo({ top: 0 }); } },
    icon('spark', { size: 16 }), h('span', { text: 'عاجل' }));
}
/* ===== 🔔 جرس «عاجل» فوق جنب رسائل الدعم (1.21.2) — يتحكم فيه المالك من لوحة «الواجهة» ===== */
const AIN_BELL_DEF = { on: true, mode: 'new', open: 'hub', pulse: true, kinds: { urgent: true, daily: true, weekly: true, monthly: true } };
const ainBellCfg = () => { const m = (typeof Market !== 'undefined' && Market.get().ainBell) || {}; return { ...AIN_BELL_DEF, ...m, kinds: { ...AIN_BELL_DEF.kinds, ...(m.kinds || {}) } }; };
const ainBellItems = () => { const c = ainBellCfg(); return AIN.items.filter((x) => c.kinds[x.kind] !== false); };
const ainBellNew = () => { const seen = ainSeen(); return ainBellItems().filter((x) => !seen.includes(x.id)); };
function ainPaintBell() {
  const b = document.getElementById('ain-bell'); if (!b) return;
  const c = ainBellCfg(), fresh = ainBellNew(), pn = typeof FCM !== 'undefined' && FCM.pending ? FCM.pending() : 0, n = fresh.length + pn; // 1.21.10: + الأخبار اللي وصل إشعارها والتطبيق مفتوح
  const off = !c.on || (typeof secOff === 'function' && secOff('news')) || (!AIN.items.length && !pn);
  b.hidden = off || (c.mode === 'new' && !n);
  b.classList.toggle('pulse', !!n && c.pulse !== false);
  const d = document.getElementById('ain-bell-n');
  if (d) { d.hidden = !n; d.textContent = n > 9 ? '9+' : String(n); }
  b.setAttribute('aria-label', n ? `${n} جديد` : 'عاجل');
}
function ainBellTap() {
  const c = ainBellCfg(), fresh = ainBellNew(), top = fresh[0] || ainBellItems()[0];
  // أخبار جديدة وصل إشعارها (وما فيه عدد عاجل جديد) → نفتح الأخبار على طول
  if (typeof FCM !== 'undefined' && FCM.pending?.() && !fresh.length) { FCM.clear(); if (typeof NEWS !== 'undefined') NEWS.view = 'feed'; if (S.tab !== 'news') setTab('news'); else if (typeof loadNews === 'function') loadNews({ force: true }); window.scrollTo({ top: 0 }); return; }
  if (typeof FCM !== 'undefined') FCM.clear?.();
  if (c.open === 'issue' && top) { ainOpen(top, 0); setTimeout(ainPaintBell, 50); return; }
  fresh.forEach((x) => ainMarkSeen(x.id));
  if (typeof NEWS !== 'undefined') NEWS.view = 'ai';
  if (S.tab !== 'news') setTab('news'); else renderNews();
  window.scrollTo({ top: 0 });
  ainPaintBell();
}
function ainBellInit() {
  const b = document.getElementById('ain-bell'); if (!b || b.dataset.ok) return;
  b.dataset.ok = '1';
  b.prepend(icon('bell', { size: 20 }));
  b.addEventListener('click', ainBellTap);
  ainPaintBell();
  setTimeout(() => loadAiNews(), 2500);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) loadAiNews(); });
  setInterval(() => { if (!document.hidden) loadAiNews(); }, 5 * 60000);
}
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ainBellInit); else setTimeout(ainBellInit, 0);

function ainPaintBtn() { document.querySelectorAll('#n-root .n-ai-btn, #n-root .n-hub-t[data-v=ai]').forEach((b) => b.classList.toggle('new', ainHasNew())); }
const AIN_KIND = { daily: 'ملخص اليوم', weekly: 'ملخص الأسبوع', monthly: 'ملخص الشهر', urgent: 'عاجل' };
const ainLabel = (it) => it.kind === 'urgent' ? `⚡ ${it.title}` : it.kind === 'weekly' ? `ملخص الأسبوع ${ainN(it.week)}` : `${AIN_KIND[it.kind] || 'ملخص'} · ${it.date_label || ''}`;
function renderAiNews(root = $('#n-root')) {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  if (!root) return;
  cancelAnimationFrame(AIN.raf);
  const [cur, ...old] = AIN.items;
  const kit = ainKit();
  const head = h('div', { class: 'ain-head' },
    h('div', { class: 'ain-ht' }, h('h1', { class: 'view-title', text: '⚡ NOBLE عاجل' }), h('small', { text: 'أهم أخبار الذكاء الاصطناعي — بالفيديو وبدقيقة' })),
    h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'تحديث', onclick: () => loadAiNews(true) }, icon('repeat', { size: 18 })));
  if (!cur) {
    root.replaceChildren(head, AIN.loading || (!AIN.loaded && Cloud.enabled)
      ? h('div', { class: 'ain-skel' })
      : h('div', { class: 'empty' }, h('b', { text: 'قريباً أول عدد ⚡' }), h('small', { text: 'ملخص أسبوعي لأهم أخبار الذكاء الاصطناعي من مصادرها الرسمية.' })));
    if (!AIN.loaded) loadAiNews();
    return;
  }
  const isNew = !ainSeen().includes(cur.id);
  const hero = h('canvas', { class: 'ain-hero-cv', width: 540, height: 675 });
  const thumb = (issue, i) => { const c = h('canvas', { width: 236, height: 295 }); requestAnimationFrame(() => AISlides.draw(c.getContext('2d'), issue, i, 3, { kit })); return c; };
  root.replaceChildren(...[head,
    h('button', { type: 'button', class: 'ain-hero', onclick: () => ainOpen(cur, 0) }, hero,
      h('div', { class: 'ain-ov' }, isNew ? h('span', { class: 'ain-live', text: 'جديد' }) : null, h('span', { class: 'spacer' }), h('span', { class: 'ain-play', 'aria-label': 'تشغيل', text: '▶' }))),
    (cur.slides || []).length ? h('div', { class: 'ain-sec' }, h('b', { text: 'أخبار هذا العدد' }), h('small', { text: 'اسحب ←' })) : null,
    h('div', { class: 'ain-hs' }, ...(cur.slides || []).map((s, k) => h('button', { type: 'button', onclick: () => ainOpen(cur, k + 1) }, thumb(cur, k + 1), h('span', { text: s.head || s.company })))),
    old.length ? h('div', { class: 'ain-sec' }, h('b', { text: 'أعداد سابقة' })) : null,
    old.length ? h('div', { class: 'ain-old' }, ...old.map((it) => h('button', { type: 'button', onclick: () => ainOpen(it, 0) }, thumb(it, 0),
      h('span', { text: ainLabel(it) }), it.kind === 'weekly' || it.kind === 'urgent' ? h('small', { text: it.date_label || '' }) : null))) : null].filter(Boolean));
  UI.digitize(root);
  AISlides.fonts().then(() => {
    const t0 = performance.now(), c = hero.getContext('2d');
    const loop = (now) => { if (S.tab !== 'news' || NEWS.view !== 'ai' || !document.body.contains(hero) || AIN.vw) return; AISlides.draw(c, cur, 0, (now - t0) / 1000, { kit }); AIN.raf = requestAnimationFrame(loop); };
    AIN.raf = requestAnimationFrame(loop);
  });
  if (Date.now() - AIN.loaded > 120000) loadAiNews();
}
const ainSeen = () => { try { return JSON.parse(localStorage.getItem(AIN_SEEN) || '[]'); } catch { return []; } };
const ainMarkSeen = (id) => { try { const s = ainSeen(); if (!s.includes(id)) localStorage.setItem(AIN_SEEN, JSON.stringify([...s, id].slice(-60))); } catch { /* لا شيء */ } };

/* بطاقة «يومي» للعدد المثبّت */
function ainTodayCard() {
  const it = ainPinned();
  if (!it) return null;
  const c = h('canvas', { width: 160, height: 200 });
  requestAnimationFrame(() => AISlides.fonts().then(() => AISlides.draw(c.getContext('2d'), it, 0, 3, { kit: ainKit() })));
  return h('button', { type: 'button', class: `ain-today${ainSeen().includes(it.id) ? '' : ' new'}`, onclick: () => ainOpen(it, 0) }, c,
    h('div', {}, h('small', { text: '⚡ NOBLE عاجل · مهم' }), h('b', { text: it.title }), h('span', { text: `${ainN((it.slides || []).length)} أخبار بالفيديو — شوفها بدقيقة ←` })));
}
/* من «اكتشف» أو رابط: افتح عدد برقمه */
async function ainOpenId(id) {
  let it = AIN.items.find((x) => x.id === Number(id));
  if (!it) { await loadAiNews(true); it = AIN.items.find((x) => x.id === Number(id)); }
  if (it) ainOpen(it, 0); else toast('العدد ما عاد متاح');
}

/* ---------- العارض ---------- */
function ainOpen(issue, i = 0) {
  ainClose(true);
  ainMarkSeen(issue.id); ainPaintBell(); if (typeof Insights !== 'undefined') Insights.inc('aiOpen');
  Cloud.aiHit?.(issue.id);
  const kit = ainKit(), total = AISlides.total(issue, kit, 'app');
  const cv = h('canvas', { class: 'ain-cv', width: 1080, height: 1350 });
  const bars = h('div', { class: 'ain-bars' }, ...Array.from({ length: total }, () => h('i', {}, h('u'))));
  const snd = h('button', { type: 'button', class: 'ain-ic', 'aria-label': 'الصوت', onclick: () => { V.muted = !V.muted; snd.textContent = V.muted ? '🔇' : '🔊'; ainSound(); } }, '🔇');
  const src = h('button', { type: 'button', class: 'btn sm ain-src', onclick: () => { const s = issue.slides[V.i - 1]; if (s?.url) (typeof dscLink === 'function' ? dscLink(s.url) : window.open(s.url, '_blank', 'noopener')); } }, '🔗 المصدر');
  // 1.21.26: 💬 التعليقات — زر تحت (مع العدد) + «اكتب رأيك» فوق الصفحة الأخيرة
  const cmt = h('button', { type: 'button', class: 'btn sm ain-cmt', hidden: true, onclick: () => ainComments() }, '💬');
  const big = h('button', { type: 'button', class: 'ain-cmt-big', hidden: true, onclick: (e) => { e.stopPropagation(); ainComments(); } }, String(kit.outro?.cmtText || '').trim() || '💬 اكتب رأيك');
  ['pointerdown', 'pointerup'].forEach((ev) => big.addEventListener(ev, (e) => e.stopPropagation()));
  const el = h('div', { class: 'ain-viewer', role: 'dialog', 'aria-modal': 'true' },
    bars,
    h('div', { class: 'ain-vh' }, h('span', { class: 'ain-av', text: 'N' }), h('div', {}, h('b', { text: 'NOBLE عاجل' }), h('small', { text: issue.kind === 'weekly' ? `الأسبوع ${ainN(issue.week)}` : AIN_KIND[issue.kind] || 'عاجل' })),
      h('span', { class: 'spacer' }), snd, h('button', { type: 'button', class: 'ain-ic', 'aria-label': 'إغلاق', onclick: () => ainClose() }, '✕')),
    h('div', { class: 'ain-stage' }, cv, h('div', { class: 'ain-tap' }, h('div', { onclick: () => ainGo(-1) }), h('div', { onclick: () => ainGo(1) })), big),
    h('div', { class: 'ain-acts' }, src, cmt,
      h('button', { type: 'button', class: 'btn sm', onclick: () => ainSave(issue, 1350, 'carousel') }, '⬇️ كاروسيل'),
      h('button', { type: 'button', class: 'btn sm', onclick: () => ainSave(issue, 1920, 'story') }, '⬇️ ستوري'),
      h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => ainShareOne(issue) }, '↗ شارك')));
  const V = AIN.vw = { el, issue, i, t0: performance.now(), muted: true, paused: false, kit, cv, bars, src, cmt, big };
  if (issue.look?.cmt !== false && typeof Cloud.aiThread === 'function' && typeof dscComments === 'function')
    Cloud.soon(Cloud.aiThread(issue.id), 7000).then((r) => { if (AIN.vw !== V || !r || r.off || !r.id) return; V.th = r; ainCmtPaint(); }).catch(() => {});
  // 1.21.9: 🎵 موسيقى العدد (من لوحة التحكم) — تشتغل لما يفتح العدد، وتوطى لما فيديو الخبر يتكلم
  const MU = issue.look?.music;
  if (MU?.url && MU.app !== false && !/^blob:/.test(MU.url)) {
    const a = V.mu = new Audio(MU.url); a.loop = MU.loop !== false; a.preload = 'auto'; a.volume = 0;
    a.addEventListener('loadedmetadata', () => { try { a.currentTime = Math.min(+MU.start || 0, Math.max(0, (a.duration || 1) - 1)); } catch { /* لا شيء */ } }, { once: true });
    if (MU.auto !== false) { V.muted = false; snd.textContent = '🔊'; }
  }
  // سحب يمين/يسار + ضغط مطوّل = إيقاف مؤقت
  let sx = null, hold = 0;
  el.querySelector('.ain-stage').addEventListener('pointerdown', (e) => { sx = e.clientX; hold = setTimeout(() => { V.paused = true; V.pAt = performance.now(); }, 260); });
  el.querySelector('.ain-stage').addEventListener('pointerup', (e) => { clearTimeout(hold); if (V.paused) { V.t0 += performance.now() - V.pAt; V.paused = false; sx = null; e.stopPropagation(); return; } if (sx != null && Math.abs(e.clientX - sx) > 40) ainGo(e.clientX - sx > 0 ? 1 : -1); sx = null; });
  document.body.append(el);
  document.documentElement.classList.add('ain-open');
  ainSet(i);
  AISlides.fonts().then(() => { const loop = (now) => { if (AIN.vw !== V) return; ainTick(now); AIN.raf = requestAnimationFrame(loop); }; AIN.raf = requestAnimationFrame(loop); });
}
function ainSet(i) {
  const V = AIN.vw; if (!V) return;
  V.i = i; V.t0 = performance.now();
  AISlides.rewind(V.issue, i);
  V.src.hidden = !(i > 0 && V.issue.slides[i - 1]?.url);
  ainCmtPaint();
  ainSound();
}
function ainSound() { const V = AIN.vw; if (!V) return; const s = V.issue.slides[V.i - 1]; for (const x of (V.issue.slides || [])) if (x.media?.kind === 'video') AISlides.vidOf(x.media.url).muted = true; if (s?.media?.kind === 'video') AISlides.vidOf(s.media.url).muted = V.muted; ainMusic(); }
/* 🎵 الموسيقى: ظهور ناعم، وتوطى ٧٠٪ لو فيديو الخبر شغّال بصوته */
function ainMusic() {
  const V = AIN.vw, a = V?.mu; if (!a) return;
  const MU = V.issue.look?.music || {}, s = V.issue.slides[V.i - 1], talk = s?.media?.kind === 'video' && !V.muted;
  const target = V.muted ? 0 : Math.max(0, Math.min(1, (+MU.vol || 80) / 100)) * (talk ? .3 : 1);
  if (!V.muted && a.paused) a.play().catch(() => { V.muted = true; const b = V.el.querySelector('.ain-ic'); if (b) b.textContent = '🔇'; });
  clearInterval(V.muT); const step = MU.fade === false ? 1 : .06;
  V.muT = setInterval(() => { const d = target - a.volume; if (Math.abs(d) <= step) { a.volume = target; clearInterval(V.muT); if (!target) a.pause(); } else a.volume = Math.max(0, Math.min(1, a.volume + Math.sign(d) * step)); }, 40);
}
function ainGo(d) { const V = AIN.vw; if (!V) return; const n = V.i + d; if (n < 0) return ainSet(0); if (n >= AISlides.total(V.issue, ainKit(), 'app')) return ainClose(); buzz?.('light'); ainSet(n); }
function ainTick(now) {
  const V = AIN.vw, t = V.paused ? (V.pAt - V.t0) / 1000 : (now - V.t0) / 1000, dur = AISlides.duration(V.issue, V.i, ainKit());
  AISlides.sync(V.issue, [V.i], !V.paused);
  AISlides.draw(V.cv.getContext('2d'), V.issue, V.i, t, { kit: V.kit });
  [...V.bars.children].forEach((b, k) => { b.firstChild.style.width = (k < V.i ? 100 : k > V.i ? 0 : Math.min(100, (t / dur) * 100)) + '%'; });
  if (!V.paused && t > dur + .4) ainGo(1);
}
function ainClose(silent) {
  const V = AIN.vw; if (!V) return false;
  AIN.vw = null; cancelAnimationFrame(AIN.raf);
  AISlides.sync(V.issue, [], false);
  if (V.mu) { clearInterval(V.muT); try { V.mu.pause(); V.mu.src = ''; } catch { /* لا شيء */ } }
  V.el.remove(); document.documentElement.classList.remove('ain-open');
  if (!silent && S.tab === 'news' && NEWS.view === 'ai') renderNews();
  return true;
}

/* ---------- التنزيل والمشاركة ---------- */
const ainB64 = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.readAsDataURL(blob); });
async function ainFiles(issue, h0, label, only = null) {
  await AISlides.fonts();
  const out = [], base = `NOBLE-${issue.kind === 'urgent' ? 'urgent' : 'week-' + issue.week}-${label}`;
  const idx = only != null ? [only] : Array.from({ length: AISlides.total(issue, ainKit()) }, (_, i) => i);
  for (const i of idx) {
    const b = await AISlides.still(issue, i, h0, { kit: ainKit() }, 'image/jpeg', 3);
    out.push(new File([b], `${base}-${String(i + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }));
  }
  return out;
}
async function ainDeliver(files, title, how = 'share') {
  if (Platform.isNative) {
    const FS = Platform.plugin('Filesystem'), Sh = Platform.plugin('Share');
    if (how === 'save') {
      for (const f of files) await FS.writeFile({ path: `NOBLE/${f.name}`, data: await ainB64(f), directory: 'DOCUMENTS', recursive: true });
      return toast(`انحفظت ${ainN(files.length)} صور في المستندات ← NOBLE ✓`, { type: 'success' });
    }
    const uris = [];
    for (const f of files) uris.push((await FS.writeFile({ path: f.name, data: await ainB64(f), directory: 'CACHE' })).uri);
    return Sh.share({ title, files: uris, dialogTitle: 'شارك' });
  }
  if (how === 'share' && navigator.canShare?.({ files })) { try { await navigator.share({ files, title }); return; } catch (e) { if (e?.name === 'AbortError') return; } }
  files.forEach((f, k) => setTimeout(() => { const u = URL.createObjectURL(f), a = h('a', { href: u, download: f.name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 30000); }, k * 250));
  toast(`⬇️ نزلت ${ainN(files.length)} صور`, { type: 'success' });
}
async function ainSave(issue, h0, label) {
  if (typeof Insights !== 'undefined') Insights.inc('downloads');
  const V = AIN.vw; if (V) V.paused = true, V.pAt = performance.now();
  toast('⏳ نجهّز الصور…');
  try { await ainDeliver(await ainFiles(issue, h0, label), issue.title, Platform.isNative ? 'share' : 'save'); }
  catch (e) { if (e?.name !== 'AbortError') toast('ما قدرنا نجهّزها: ' + (e?.message || e), { type: 'error' }); }
  if (AIN.vw === V && V) { V.t0 += performance.now() - V.pAt; V.paused = false; }
}
async function ainShareOne(issue) {
  if (typeof Insights !== 'undefined') Insights.inc('shares');
  const V = AIN.vw;
  try { await ainDeliver(await ainFiles(issue, 1350, 'post', V?.i ?? 0), issue.title, 'share'); } catch { /* ألغى */ }
}

/* 1.21.3 — «🔒 سياسة الخصوصية» تنفتح فوق التطبيق (بدون ما نطلع منه ويقفل) */
document.addEventListener('click', (e) => {
  const a = e.target.closest?.('a.about-pp'); if (!a) return;
  e.preventDefault();
  const ov = h('div', { class: 'pp-ov', role: 'dialog', 'aria-modal': 'true' },
    h('button', { type: 'button', class: 'pp-x', 'aria-label': 'إغلاق', onclick: () => ov.remove() }, '✕'),
    h('iframe', { src: 'privacy.html', title: 'سياسة الخصوصية' }));
  document.body.append(ov);
});

/* 1.21.26 — 💬 تعليقات العدد (نفس محادثة منشوره في «اكتشف») */
function ainCmtPaint() {
  const V = AIN.vw; if (!V?.cmt) return;
  V.cmt.hidden = !V.th;
  if (V.th) V.cmt.textContent = V.th.n ? `💬 ${ainN(V.th.n)}` : '💬';
  V.big.hidden = !(V.th && V.kit.outro?.cmtOn !== false && V.i > (V.issue.slides || []).length);
}
function ainComments() {
  const V = AIN.vw; if (!V?.th) return;
  if (!V.paused) { V.paused = true; V.pAt = performance.now(); }
  dscComments({ id: V.th.id }, { title: '💬 وش رأيك؟', placeholder: 'أي خبر شدّك أكثر؟ اكتب رأيك…', pick: (V.issue.slides || []).map((s) => s.head || s.company || ''),
    onCount: (n) => { if (V.th) { V.th.n = n; ainCmtPaint(); } } });
  const sh = document.getElementById('dsc-sheet'), bd = document.getElementById('backdrop');
  if (!sh) return;
  sh.style.zIndex = '96'; if (bd) bd.style.zIndex = '94'; // فوق العارض
  const mo = new MutationObserver(() => { if (!sh.hidden) return; mo.disconnect(); sh.style.zIndex = ''; if (bd) bd.style.zIndex = '';
    if (AIN.vw === V && V.paused) { V.t0 += performance.now() - V.pAt; V.paused = false; } });
  mo.observe(sh, { attributes: true, attributeFilter: ['hidden'] });
}
