/* NOBLE — التفاعل اليومي (1.14): سلسلة نشاط موحّدة + تحدي اليوم + الموجز الصباحي والمسائي
 * كل شي على الجهاز وداخل الخزنة المشفّرة؛ الإعدادات (المكافآت، التحديات، نصوص الموجز) من لوحة التحكم ← الألعاب ← التفاعل اليومي.
 */
'use strict';
const DCFG = () => GCfg.merge(GCfg.DEFAULTS.daily, GCfg.get().daily || {});
const dYmd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const dYesterday = () => { const d = new Date(); d.setDate(d.getDate() - 1); return dYmd(d); };
const D_KINDS = { azkar: 'azkar', task: 'tasks', tx: 'finance', news: 'news', game: 'games', word: 'games', design: 'designs', quick: 'today', site: 'sites' };

function dState(v = S.vault) {
  const x = v?.daily && typeof v.daily === 'object' ? v.daily : {};
  return { last: x.last || '', n: Number(x.n) || 0, best: Number(x.best) || 0, day: x.day || '', k: x.k && typeof x.k === 'object' ? x.k : {}, ch: x.ch || '', got: Array.isArray(x.got) ? x.got : [] };
}
/* السلسلة الحالية (تنكسر لو فات يوم كامل بدون نشاط) */
function dStreak(st = dState()) { return st.last === dYmd() || st.last === dYesterday() ? st.n : 0; }

/* تحدي اليوم: من القائمة المفعّلة وحسب الأقسام الظاهرة للمستخدم */
function dChallenge() {
  const C = DCFG();
  if (!C.on || !C.challenge?.on) return null;
  const tabs = typeof visibleTabs === 'function' ? new Set(visibleTabs()) : null;
  const list = (C.challenge.list || []).filter((c) => c && c.on !== false && c.kind && (!tabs || tabs.has(D_KINDS[c.kind] || c.tab || 'today')));
  if (!list.length) return null;
  const n = typeof Words !== 'undefined' ? Words.dayNum() : Math.floor(Date.now() / 864e5);
  return list[(n * 5 + 3) % list.length];
}

/* يُستدعى من كل الأقسام عند أي نشاط حقيقي */
let dQueue = Promise.resolve();
function markActive(kind) {
  if (!S.vault || !kind) return Promise.resolve();
  const run = dQueue.then(() => dMark(kind));
  dQueue = run.catch(() => {});
  return run;
}
async function dMark(kind) {
  const C = DCFG();
  if (!C.on) return;
  const today = dYmd();
  const st0 = dState();
  const ch = dChallenge();
  const count = (st0.day === today ? st0.k[kind] || 0 : 0);
  const need = ch && ch.kind === kind ? Number(ch.n) || 1 : 0;
  // ما فيه شي جديد: اليوم محسوب والعدّاد ما يفرق للتحدي
  if (st0.last === today && (count >= Math.max(need, 1)) && (st0.ch === today || !need)) return;
  let newDay = false, reward = null, chDone = false;
  await commit((v) => {
    const st = dState(v);
    if (st.day !== today) { st.day = today; st.k = {}; }
    st.k[kind] = Math.min(20, (st.k[kind] || 0) + 1);
    if (st.last !== today) {
      newDay = true;
      st.n = st.last === dYesterday() ? st.n + 1 : 1;
      if (st.n === 1) st.got = [];
      st.last = today; st.best = Math.max(st.best, st.n);
      if (C.streak?.on !== false) {
        const r = (C.streak.rewards || []).map(([d, p]) => [Number(d), Number(p)]).filter(([d]) => d === st.n && !st.got.includes(d))[0];
        if (r) { reward = r; st.got = [...st.got, r[0]]; }
      }
    }
    if (ch && ch.kind === kind && st.ch !== today && st.k[kind] >= (Number(ch.n) || 1)) { st.ch = today; chDone = true; }
    v.daily = st;
  });
  if (typeof addPoints === 'function') {
    if (reward && reward[1] > 0) {
      const got = await addPoints('daily', reward[1], { badges: reward[0] >= 30 ? ['daily_30'] : reward[0] >= 7 ? ['daily_7'] : [] }).catch(() => 0);
      setTimeout(() => { buzz('success'); toast(`🔥 ${UI.n(reward[0])} أيام متواصلة! +${UI.n(got)} نقطة`, { type: 'success', duration: 4500 }); }, 900);
    }
    if (chDone) {
      const got = await addPoints('daily', Number(C.challenge.pts) || 0).catch(() => 0);
      setTimeout(() => { buzz('success'); toast(`🎯 أنجزت تحدي اليوم! +${UI.n(got)} نقطة`, { type: 'success', duration: 4500 }); }, reward ? 2600 : 700);
    }
  }
  if (newDay || chDone) { if (S.tab === 'today' && typeof renderToday === 'function') renderToday(); dBriefSchedule(); }
}

/* أمثلة النشاط من الأقسام الظاهرة بس (1.19.2) */
function dActs() {
  const L = [['tasks', 'مهمة'], ['finance', 'مصروف'], ['news', 'خبر'], ['games', 'لعبة'], ['azkar', 'ذكر'], ['designs', 'تصميم'], ['sites', 'موقع']];
  const on = L.filter(([k]) => !(typeof secOff === 'function' && secOff(k))).map(([, l]) => l).slice(0, 4);
  return on.join('، ') || 'مهمة';
}
/* بطاقة «يومي»: السلسلة + تحدي اليوم + زر الموجز */
function tdDailyCard() {
  const C = DCFG();
  if (!C.on || !S.vault) return null;
  const st = dState(), n = dStreak(st), today = dYmd();
  const activeToday = st.last === today;
  const rewards = (C.streak?.rewards || []).map(([d, p]) => [Number(d), Number(p)]).sort((a, b) => a[0] - b[0]);
  const next = rewards.find(([d]) => d > n);
  const ch = dChallenge();
  const chCount = ch ? Math.min(Number(ch.n) || 1, st.day === today ? st.k[ch.kind] || 0 : 0) : 0;
  const chDone = ch && st.ch === today;
  const goCh = () => {
    if (!ch) return;
    if (ch.kind === 'word' && typeof openWord === 'function') { setTab('games'); setTimeout(() => openWord(wLangs()[0]), 50); return; }
    if (ch.kind === 'quick' && typeof openQuickAdd === 'function') return openQuickAdd();
    setTab(D_KINDS[ch.kind] || 'today');
  };
  const days = Array.from({ length: 7 }, (_, i) => { const d = new Date(); d.setDate(d.getDate() - 6 + i); return d; });
  const lit = (d) => { const k = dYmd(d); if (!st.last || k > st.last) return false; const diff = Math.round((new Date(st.last + 'T12:00') - new Date(k + 'T12:00')) / 864e5); return n > 0 && diff < n; };
  return h('section', { class: 'td-card td-daily' },
    h('div', { class: 'td-streak' },
      h('span', { class: `td-fire${activeToday ? ' on' : ''}`, text: '🔥' }),
      h('div', {}, h('b', { class: 'num', text: n ? `${UI.n(n)} ${n === 1 ? 'يوم' : n <= 10 ? 'أيام' : 'يوم'} متواصلة` : 'ابدأ سلسلتك اليوم' }),
        h('small', { text: activeToday ? (next ? `باقي ${UI.n(next[0] - n)} ${next[0] - n === 1 ? 'يوم' : 'أيام'} على مكافأة +${UI.n(next[1])} 🎁` : `أفضل سلسلة: ${UI.n(Math.max(st.best, n))}`) : `أي نشاط اليوم (${dActs()}…) يكمّل السلسلة` })),
      h('div', { class: 'td-week' }, ...days.map((d) => h('i', { class: lit(d) ? 'on' : '', title: dYmd(d), text: d.toLocaleDateString(UI.loc(), { weekday: 'narrow' }) })))),
    ch ? h('button', { type: 'button', class: `td-ch${chDone ? ' done' : ''}`, onclick: goCh },
      h('span', { class: 'td-ch-ic', text: chDone ? '✅' : '🎯' }),
      h('span', {}, h('small', { text: 'تحدي اليوم' }), h('b', { text: ch.text })),
      h('em', { class: 'num', text: chDone ? `+${UI.n(C.challenge.pts)}` : (Number(ch.n) || 1) > 1 ? `${UI.n(chCount)}/${UI.n(ch.n)}` : `+${UI.n(C.challenge.pts)}` })) : null,
    Platform.isNative && C.brief?.on ? h('button', { type: 'button', class: `link-btn td-brief${pref('brief') ? ' on' : ''}`, onclick: () => setBrief(!pref('brief')) },
      pref('brief') ? `🔔 الموجز ${UI.n(C.brief.morning)}:٠٠ ص و ${UI.n(C.brief.evening > 12 ? C.brief.evening - 12 : C.brief.evening)}:٠٠ م مفعّل` : '🔕 فعّل موجز الصباح والمساء') : null);
}

/* ================= الموجز الصباحي والمسائي (إشعارات محلية — بدون نت) ================= */
const BRIEF_IDS = [770101, 770102, 770103, 770104, 770105, 770106];
function dFill(tpl, vars) { return String(tpl || '').replace(/\{(\w+)\}/g, (_, k) => (vars[k] ?? '')).replace(/\s+·\s+$/, '').trim(); }
async function setBrief(on) {
  const LN = Platform.plugin('LocalNotifications');
  if (!LN) return;
  try {
    if (on) { const p = await LN.requestPermissions(); if (p.display !== 'granted') return toast('اسمح للتطبيق بالإشعارات من إعدادات الجوال', { type: 'error' }); }
    await setPref({ brief: on });
    await dBriefSchedule();
    toast(on ? 'بنرسل لك موجز الصباح والمساء ☀️🌙' : 'أوقفنا الموجز', { type: 'success' });
    if (S.tab === 'today') renderToday();
  } catch (e) { toast('تعذّر ضبط الإشعار: ' + (e.message || e), { type: 'error' }); }
}
/* نجدول ٣ أيام قدّام بنصوص محسوبة لكل يوم، ونعيد الجدولة كل ما فُتح التطبيق */
async function dBriefSchedule() {
  if (!Platform.isNative || !S.vault) return;
  const LN = Platform.plugin('LocalNotifications');
  if (!LN) return;
  try {
    await LN.cancel({ notifications: BRIEF_IDS.map((id) => ({ id })) }).catch(() => {});
    const C = DCFG();
    if (!C.on || !C.brief?.on || !pref('brief')) return;
    const name = (S.profile?.display_name || '').split(/\s+/)[0] || '';
    const tasks = S.vault.tasks || [];
    const st = dState(), n = dStreak(st);
    const ch = dChallenge();
    const list = [];
    for (let i = 0; i < 3; i++) {
      const d = new Date(); d.setDate(d.getDate() + i);
      const k = dYmd(d);
      const due = tasks.filter((t) => t.status !== 'done' && t.due && t.due <= k).length;
      const vars = { name, tasks: UI.n(due), streak: UI.n(i === 0 ? n : n + i), challenge: ch?.text || '', done: UI.n(tasks.filter((t) => t.status === 'done' && t.doneAt && dYmd(new Date(t.doneAt)) === k).length) };
      const m = new Date(d); m.setHours(Number(C.brief.morning) || 8, 0, 0, 0);
      const e = new Date(d); e.setHours(Number(C.brief.evening) || 21, 0, 0, 0);
      if (m > new Date()) list.push({ id: BRIEF_IDS[i * 2], title: dFill(C.brief.mTitle, vars), body: dFill(due ? C.brief.mBody : C.brief.mBodyFree, vars), schedule: { at: m, allowWhileIdle: true }, extra: { tab: 'today' }, smallIcon: 'ic_stat_nobleweb' });
      // المساء: لو ما سوّى نشاط اليوم نذكّره يحافظ على السلسلة
      const safe = i === 0 && st.last === dYmd();
      if (e > new Date()) list.push({ id: BRIEF_IDS[i * 2 + 1], title: dFill(safe ? C.brief.eTitle : C.brief.eTitleRisk, vars), body: dFill(safe ? C.brief.eBody : C.brief.eBodyRisk, vars), schedule: { at: e, allowWhileIdle: true }, extra: { tab: 'today' }, smallIcon: 'ic_stat_nobleweb' });
    }
    if (list.length) await LN.schedule({ notifications: list });
  } catch (e) { console.warn('brief', e); }
}
