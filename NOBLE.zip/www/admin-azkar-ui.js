/* NOBLE — لوحة التحكم ← الأذكار ← «🎨 الأيقونات» و«🎛️ التحكم» (1.17)
 * الأيقونات: باقات، النمط، الإطار (أشكال إسلامية)، التعبئة، الألوان، الحركة، المواسم، كل أيقونة لحالها، الترتيب، مكتبتي.
 * التحكم: كل عنصر في القسم (للكل/مختبرين/مشتركين/مخفي) + الجدولة بالتاريخ أو بالموسم الهجري + شكل الإخفاء + أوضاع جاهزة.
 * كلها في إعدادات الأذكار (meta.icons / meta.ctl) — «احفظ الإعدادات» يوصلها للكل فوراً.
 */
'use strict';
const AZI = { hist: [], seas: undefined, pv: 'azkar', q: '', filter: '', open: new Set(['azkar']) };
const AZI_N = new WeakSet();
const aziI = () => { const m = AZA.meta.icons; if (m && AZI_N.has(m)) return m; const n = AzkarKit.iconCfg(AZA.meta); AZI_N.add(n); return (AZA.meta.icons = n); };
const aziC = () => { const m = AZA.meta.ctl; if (m && AZI_N.has(m)) return m; const n = AzkarKit.ctlCfg(AZA.meta); AZI_N.add(n); return (AZA.meta.ctl = n); };
const aziSnap = () => { AZI.hist.push(JSON.stringify({ icons: AZA.meta.icons, ctl: AZA.meta.ctl })); if (AZI.hist.length > 50) AZI.hist.shift(); };
function aziUndo(re) { const s = AZI.hist.pop(); if (!s) return toast('ما فيه شي نتراجع عنه'); const o = JSON.parse(s); AZA.meta.icons = o.icons; AZA.meta.ctl = o.ctl; azaChanged(); re(); }
const aziIc = (ic, col, z, badge = '') => { const s = h('span', { class: 'aik-w' }); s.innerHTML = AzkarKit.iconHTML(ic, col, AzkarKit.iconCfg(AZA.meta), { z, badge }); return s; };
const aziSlot = (id, z, seas) => { const s = h('span', { class: 'aik-w' }); s.innerHTML = AzkarKit.slotHTML(id, AZA.meta, { z, season: seas === undefined ? AZI.seas : seas }); return s; };
const aziItem = (id) => { const I = aziI(); return AzkarKit.iconItem(id, I, AzkarKit.iconSeason(I, AZI.seas)); };

/* ================= الأيقونات ================= */
const AZI_OPT = {
  style: [['line', 'خطّي'], ['bold', 'عريض'], ['duo', 'ثنائي اللون'], ['solid', 'ممتلئ'], ['grad', 'متدرّج NOBLE'], ['neon', 'نيون']],
  shape: [['circle', '● دائرة'], ['squircle', '▢ مربع ناعم'], ['square', '◼ مربع'], ['oct', '⯃ مثمّن'], ['star', '✸ نجمة إسلامية'], ['arch', '⌂ محراب'], ['leaf', '❦ ورقة'], ['none', 'بدون']],
  fill: [['tint', 'لون خفيف'], ['glass', 'زجاجي'], ['solid', 'لون كامل'], ['grad', 'متدرّج'], ['ring', 'إطار فقط'], ['dark', 'داكن'], ['none', 'شفاف']],
  theme: [['multi', '🌈 لون لكل أيقونة'], ['mono', '● لون واحد']],
  anim: [['none', 'بدون'], ['pulse', 'نبض'], ['glow', 'توهّج'], ['float', 'طفو'], ['swing', 'تمايل (فانوس)'], ['shine', 'لمعة']],
  tap: [['bounce', 'ارتداد'], ['ripple', 'تموّج'], ['spin', 'لفّة'], ['none', 'بدون']],
};
const AZI_SW = ['#2FD6AE', '#F2D184', '#56C8FF', '#C9A6FF', '#FF9E7A', '#FF7AC8', '#BFEFDF', '#FFFFFF'];
function renderAzIcons(box) {
  const I = aziI(), re = () => renderAzIcons(box);
  const set = (k, v) => { aziSnap(); I[k] = v; azaChanged(); re(); };
  const chips = (k) => h('div', { class: 'chips azi-chips' }, ...AZI_OPT[k].map(([v, l]) => h('button', { type: 'button', class: `chip${I[k] === v ? ' on' : ''}`, onclick: () => set(k, v) }, l)));
  const rng = (label, k, min, max, step, fmt) => { const r = h('input', { type: 'range', min, max, step, value: I[k] }), o = h('em', { class: 'num', text: fmt(I[k]) }); r.addEventListener('pointerdown', aziSnap); r.addEventListener('input', () => { I[k] = +r.value; o.textContent = fmt(+r.value); azaChanged(); paintPv(); paintSlots(); }); return h('label', { class: 'uia-sl' }, h('span', { text: label }), r, o); };
  const tog = (title, sub, k) => { const c = h('input', { type: 'checkbox', checked: !!I[k] }); c.addEventListener('change', () => set(k, c.checked)); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))); };
  const card = (title, sub, ...kids) => h('section', { class: 'set-card azi-card' }, h('b', { class: 'azi-h', text: title }), sub ? h('p', { class: 'hint', text: sub }) : null, ...kids.filter(Boolean));
  const presets = h('div', { class: 'azi-pre' }, ...AzkarKit.ICON_PRESETS.map(([k, n, p]) => {
    const on = Object.entries(p).every(([a, b]) => I[a] === b), tmp = { ...I, ...p };
    const row = h('div', { class: 'row' }); row.innerHTML = ['beads', 'hands', 'mosque', 'lantern'].map((ic, i) => AzkarKit.iconHTML(ic, tmp.theme === 'multi' ? ['#2FD6AE', '#56C8FF', '#C9A6FF', '#F2D184'][i] : tmp.color, tmp, { z: 32 })).join('');
    return h('button', { type: 'button', class: `azi-p${on ? ' on' : ''}`, onclick: () => { aziSnap(); Object.assign(I, p); azaChanged(); re(); toast('✓ طبّقنا الباقة — عدّل عليها براحتك'); } }, h('b', { text: n }), row);
  }));
  const colors = h('div', { class: 'uia-sws' }, ...AZI_SW.map((c) => h('button', { type: 'button', class: `uia-sw${I.color === c && I.theme === 'mono' ? ' on' : ''}`, style: { background: c }, 'aria-label': c, onclick: () => { aziSnap(); I.color = c; I.theme = 'mono'; azaChanged(); re(); } })),
    h('label', { class: 'uia-sw pick' }, (() => { const i = h('input', { type: 'color', value: I.color }); i.addEventListener('change', () => { aziSnap(); I.color = i.value; I.theme = 'mono'; azaChanged(); re(); }); return i; })()));
  const slots = h('div', {});
  const paintSlots = () => RC(slots, ...AzkarKit.SLOTS.map(([g, L]) => h('div', { class: 'azi-grp' }, h('b', { text: g }), h('div', { class: 'azi-slots' }, ...L.map(([id]) => { const it = aziItem(id); return h('button', { type: 'button', class: `azi-slot${it.hide ? ' off' : ''}`, onclick: () => aziEdit(id, re) }, h('span', { class: 'ed', text: '✎' }), aziSlot(id, 44), h('span', { text: it.n })); })))));
  paintSlots();
  const ordNames = { b_azkar: 1, b_dua: 1, b_fadl: 1, g_tasbih: 1, g_ruqya: 1, g_ramadan: 1, g_hajj: 1 };
  const ord = h('div', { class: 'azi-ord' }, ...I.order.filter((x) => ordNames[x]).map((id, i, arr) => h('div', {}, aziSlot(id, 34), h('span', { text: aziItem(id).n }),
    h('button', { type: 'button', disabled: !i, onclick: () => { aziSnap(); const o = I.order; const a = o.indexOf(id), b = o.indexOf(arr[i - 1]); [o[a], o[b]] = [o[b], o[a]]; azaChanged(); re(); } }, '▲'),
    h('button', { type: 'button', disabled: i === arr.length - 1, onclick: () => { aziSnap(); const o = I.order; const a = o.indexOf(id), b = o.indexOf(arr[i + 1]); [o[a], o[b]] = [o[b], o[a]]; azaChanged(); re(); } }, '▼'))));
  const lib = h('div', { class: 'azi-slots' }, ...(I.lib.length ? I.lib.map((l) => h('div', { class: 'azi-slot' }, aziIc(l.id, I.color, 44), h('span', { text: l.n }), h('button', { type: 'button', class: 'btn sm', onclick: () => { aziSnap(); I.lib = I.lib.filter((x) => x.id !== l.id); Object.values(I.items).forEach((o) => { if (o.ic === l.id) delete o.ic; }); azaChanged(); re(); } }, 'حذف'))) : [h('small', { class: 'hint', text: 'ما رفعت شي للحين' })]));
  const pv = h('div', { class: 'azi-phone' });
  const paintPv = () => aziPreview(pv, re);
  const pvCol = h('div', { class: 'azi-pvcol', onclick: (e) => { if (e.target === e.currentTarget) e.currentTarget.classList.remove('show'); } }, h('div', { class: 'azi-pvbar' }, ...[['azkar', 'قسم الأذكار'], ['services', 'الخدمات'], ['lib', 'المكتبة']].map(([k, l]) => h('button', { type: 'button', class: AZI.pv === k ? 'on' : '', onclick: () => { AZI.pv = k; re(); } }, l)), AZI.seas ? h('button', { type: 'button', class: 'on', onclick: () => { AZI.seas = undefined; re(); } }, `معاينة ${({ ramadan: 'رمضان', hajj: 'الحج', eid: 'العيد' })[AZI.seas]} ✕`) : null), pv);
  RC(box, h('div', { class: 'azi-wrap' }, h('div', { class: 'azi-col' },
    h('div', { class: 'azi-top' }, h('button', { type: 'button', class: 'btn', onclick: () => aziUndo(re) }, '↶ تراجع'), h('button', { type: 'button', class: 'btn azi-pvbtn', onclick: () => document.querySelector('.azi-pvcol')?.classList.toggle('show') }, '👁 المعاينة')),
    card('⚡ باقات جاهزة', 'ضغطة وحدة — وبعدها عدّل براحتك', presets),
    card('✏️ نمط الأيقونة', 'شكل الرسم نفسه', chips('style'), rng('سُمك الخط', 'sw', 1.2, 2.6, 0.1, (v) => UI.n(v)), rng('حجمها داخل الإطار', 'k', 0.34, 0.7, 0.02, (v) => UI.n(Math.round(v * 100)) + '٪')),
    card('⬡ شكل الإطار', 'منها أشكال إسلامية: المثمّن، النجمة، المحراب', chips('shape'), h('b', { class: 'azi-sh', text: 'التعبئة' }), chips('fill'), rng('حجم الإطار', 'z', 38, 70, 2, (v) => UI.n(v) + 'px')),
    card('🎨 الألوان', 'لون لكل أيقونة (مثل «آمين») أو لون واحد للكل', chips('theme'), colors),
    card('✨ الحركة والتفاعل', 'حركة خفيفة تجذب العين بدون إزعاج', chips('anim'), h('b', { class: 'azi-sh', text: 'مؤثر الضغط' }), chips('tap'), tog('إظهار الأسماء تحت الأيقونات', '', 'labels'), tog('إظهار الوصف في البطاقات', '', 'desc')),
    card('🌙 باقات المواسم', 'تتبدّل الأيقونات والألوان وحدها حسب التاريخ الهجري وترجع بعد الموسم',
      tog('🌙 رمضان', 'فوانيس وهلال وذهبي · من ١ رمضان إلى ٣ شوال', 's_ramadan'), tog('🕋 الحج', 'الكعبة والخيام · من ١ إلى ١٣ ذو الحجة', 's_hajj'), tog('🎉 العيد', 'ألوان احتفالية · أيام العيدين', 's_eid'),
      h('div', { class: 'chips' }, ...[['ramadan', '👁 عاين رمضان'], ['hajj', '👁 عاين الحج'], ['eid', '👁 عاين العيد']].map(([k, l]) => h('button', { type: 'button', class: `chip${AZI.seas === k ? ' on' : ''}`, onclick: () => { AZI.seas = AZI.seas === k ? undefined : k; re(); } }, l)))),
    card('🧩 كل أيقونة لحالها', 'اضغط أي أيقونة: تغيّرها، لونها، اسمها، شارة «جديد»، أو تخفيها', slots),
    card('↕️ ترتيب البطاقات', 'ترتيب البطاقات في تبويب «الأذكار»', ord),
    card('📁 مكتبتي', 'ارفع أيقوناتك (SVG أو PNG شفاف) — ننظّف ملفات SVG تلقائياً للأمان',
      h('label', { class: 'azi-up' }, (() => { const f = h('input', { type: 'file', accept: '.svg,image/svg+xml,image/png,image/webp', hidden: true }); f.addEventListener('change', () => aziUpload(f, re)); return f; })(), h('span', { text: '⬆️ ارفع أيقونة' }), h('small', { text: 'SVG أفضل · حد أقصى ٢٠٠KB' })), lib),
    h('button', { type: 'button', class: 'btn btn-block', onclick: () => { if (!confirm('ترجع الأيقونات للتصميم الافتراضي؟')) return; aziSnap(); const l = I.lib; AZA.meta.icons = { ...AzkarKit.ICON_DEF, lib: l }; azaChanged(); re(); } }, '↺ رجوع للتصميم الافتراضي')),
  pvCol));
  paintPv();
  UI.digitize(box);
}
function aziPreview(pv, re) {
  const I = aziI(), seas = AZI.seas;
  const tabs = h('div', { class: 'azi-seg' }, ...['t_today', 't_mushaf', 't_azkar', 't_svc'].map((id, i) => h('button', { type: 'button', class: i === (AZI.pv === 'services' ? 3 : 2) ? 'on' : '', onclick: () => aziEdit(id, re) }, aziSlot(id, 30), h('span', { text: aziItem(id).n }))));
  if (AZI.pv === 'lib') return RC(pv, h('div', { class: 'azi-libg' }, ...Object.keys(AzkarKit.IC).map((k, i) => h('div', {}, aziIc(k, I.theme === 'multi' ? AZI_SW[i % 6] : I.color, 46), h('small', { text: AzkarKit.IC[k][0] })))));
  if (AZI.pv === 'services') return RC(pv, tabs, h('div', { class: 'azi-svc' }, ...['s_pt', 's_qibla', 's_cal', 's_occ'].filter((id) => !aziItem(id).hide).map((id) => h('button', { type: 'button', onclick: () => aziEdit(id, re) }, aziSlot(id, Math.round(I.z * 1.12)), I.labels !== false ? h('span', { text: aziItem(id).n }) : null))),
    h('div', { class: 'azi-pt' }, ...['p_fajr', 'p_sunrise', 'p_dhuhr', 'p_asr', 'p_maghrib', 'p_isha'].map((id, i) => h('button', { type: 'button', onclick: () => aziEdit(id, re) }, aziSlot(id, 26), h('small', { text: aziItem(id).n }), h('b', { text: ['4:59', '6:15', '12:08', '3:29', '6:01', '7:31'][i] })))));
  const card = (id) => { const it = aziItem(id); if (it.hide) return null; return id[0] === 'b'
    ? h('button', { type: 'button', class: 'azi-big', onclick: () => aziEdit(id, re) }, aziSlot(id), h('span', {}, h('b', { text: it.n }), I.desc !== false && it.d ? h('small', { text: it.d }) : null))
    : h('button', { type: 'button', class: 'azi-gc', onclick: () => aziEdit(id, re) }, aziSlot(id, Math.round(I.z * 1.06)), I.labels !== false ? h('b', { text: it.n }) : null, I.desc !== false && it.d ? h('small', { text: it.d }) : null); };
  RC(pv, tabs, ...I.order.filter((x) => x[0] === 'b').map(card), h('div', { class: 'azi-g2' }, ...I.order.filter((x) => x[0] === 'g').map(card)));
  void seas;
}
/* تعديل أيقونة واحدة */
let AZI_TAB = 'noble';
function aziEdit(id, re) {
  let el = document.getElementById('azi-sheet');
  if (!el) { el = h('section', { class: 'sheet', id: 'azi-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  const paint = () => {
    const I = aziI(), it = aziItem(id), o = I.items[id] || {};
    const setIt = (k, v) => { aziSnap(); const x = I.items[id] = I.items[id] || {}; if (v === '' || v === false || v == null) delete x[k]; else x[k] = v; azaChanged(); re(); paint(); };
    const pick = AZI_TAB === 'noble' ? Object.entries(AzkarKit.IC).map(([k, [n]]) => h('button', { type: 'button', class: it.ic === k ? 'on' : '', onclick: () => setIt('ic', k) }, aziIc(k, it.col, 32), h('small', { text: n })))
      : AZI_TAB === 'emoji' ? AzkarKit.EMO.map((e) => h('button', { type: 'button', class: it.ic === e ? 'on' : '', onclick: () => setIt('ic', e) }, h('span', { class: 'emo2', text: e })))
        : [...I.lib.map((l) => h('button', { type: 'button', class: it.ic === l.id ? 'on' : '', onclick: () => setIt('ic', l.id) }, aziIc(l.id, it.col, 32), h('small', { text: l.n }))),
          h('label', { class: 'azi-up', style: { gridColumn: '1 / -1' } }, (() => { const f = h('input', { type: 'file', accept: '.svg,image/svg+xml,image/png,image/webp', hidden: true }); f.addEventListener('change', () => aziUpload(f, () => { re(); paint(); }, (lid) => setIt('ic', lid))); return f; })(), h('span', { text: '⬆️ ارفع أيقونة جديدة' }))];
    const inp = (k, ph, val) => { const i = h('input', { class: 'input', value: val || '', placeholder: ph, maxlength: 40 }); i.addEventListener('change', () => setIt(k, i.value.trim())); return i; };
    const grpName = (AzkarKit.SLOTS.find(([, L]) => L.some((x) => x[0] === id)) || [''])[0];
    el.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('div', { class: 'azi-eh' }, aziSlot(id, 56), h('div', {}, h('h2', { text: it.n }), h('small', { class: 'hint', text: `${AzkarKit.SLOT[id].n} · ${grpName}` }))), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
      h('div', { class: 'sheet-body azi-eb' },
        h('div', { class: 'azi-tabs' }, ...[['noble', 'أيقونات NOBLE'], ['emoji', 'إيموجي'], ['lib', 'مكتبتي']].map(([k, l]) => h('button', { type: 'button', class: AZI_TAB === k ? 'on' : '', onclick: () => { AZI_TAB = k; paint(); } }, l))),
        h('div', { class: 'azi-pick' }, ...pick),
        h('b', { class: 'azi-sh', text: 'اللون' }),
        h('div', { class: 'uia-sws' }, ...AZI_SW.map((c) => h('button', { type: 'button', class: `uia-sw${it.col === c ? ' on' : ''}`, style: { background: c }, onclick: () => setIt('col', c) })),
          h('label', { class: 'uia-sw pick' }, (() => { const i = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(it.col) ? it.col : '#2FD6AE' }); i.addEventListener('change', () => setIt('col', i.value)); return i; })()),
          o.col ? h('button', { type: 'button', class: 'btn sm', onclick: () => setIt('col', '') }, 'حسب النمط العام') : null),
        h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'الاسم' }), inp('n', AzkarKit.SLOT[id].n, o.n)), h('label', { class: 'field' }, h('span', { text: 'شارة' }), inp('badge', 'مثال: جديد', o.badge))),
        AzkarKit.SLOT[id].d ? h('label', { class: 'field' }, h('span', { text: 'الوصف' }), (() => { const i = h('input', { class: 'input', value: o.d ?? AzkarKit.SLOT[id].d, maxlength: 60 }); i.addEventListener('change', () => setIt('d', i.value.trim())); return i; })()) : null,
        h('div', { class: 'chips' }, ...['جديد', 'مراجعة', 'قريباً', '🔥'].map((b) => h('button', { type: 'button', class: 'chip', onclick: () => setIt('badge', b) }, b)), h('button', { type: 'button', class: 'chip', onclick: () => setIt('badge', '') }, 'بدون شارة')),
        (() => { const c = h('input', { type: 'checkbox', checked: !!o.hide }); c.addEventListener('change', () => setIt('hide', c.checked)); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'إخفاء الأيقونة' }), h('small', { text: 'تختفي البطاقة أو الأيقونة — للتحكم الكامل بالظهور استخدم «🎛️ التحكم»' })), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))); })(),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => { aziSnap(); delete aziI().items[id]; azaChanged(); re(); paint(); } }, '↺ رجّعها للأصل')));
    UI.digitize(el);
  };
  paint(); openSheet('#azi-sheet');
}
function aziClean(src) {
  if (typeof IconKit !== 'undefined' && IconKit.cleanSvg) return IconKit.cleanSvg(src);
  return '';
}
async function aziUpload(input, re, then) {
  const f = input.files && input.files[0]; input.value = '';
  if (!f) return;
  if (f.size > 200e3) return toast('الملف كبير — الحد ٢٠٠KB', { type: 'error' });
  const I = aziI(), id = 'L' + Date.now().toString(36), n = f.name.replace(/\.\w+$/, '').slice(0, 14);
  try {
    if (/svg/.test(f.type) || /\.svg$/i.test(f.name)) { const s = aziClean(await f.text()); if (!s) return toast('ملف SVG غير صالح', { type: 'error' }); aziSnap(); I.lib.push({ id, n, svg: s }); }
    else { const url = await Cloud.admin.designUpload(f, 'icons'); aziSnap(); I.lib.push({ id, n, src: url }); }
    azaChanged(); toast('✓ انضافت لمكتبتك'); re(); then?.(id);
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

/* ================= التحكم ================= */
const AZC_AUD = [['all', '👁', 'للكل'], ['beta', '🧪', 'مختبرين'], ['pro', '💎', 'مشتركين'], ['off', '🚫', 'مخفي']];
function renderAzCtl(box) {
  const C = aziC(), re = () => renderAzCtl(box);
  const audOf = (k) => C.a[k] || 'all';
  const inhOff = (id) => { let p = AzkarKit.PARENT[id]; while (p) { if (audOf(p) === 'off') return AzkarKit.NODE[p].n; p = AzkarKit.PARENT[p]; } return C.on ? '' : 'القسم كامل'; };
  const setA = (id, k) => { aziSnap(); if (k === 'all') delete C.a[id]; else C.a[id] = k; azaChanged(); re(); };
  const schTxt = (s) => s.type === 'season' ? AzkarKit.SEAS_NAME[s.v] : s.type === 'dates' ? `${s.from || '…'} ← ${s.to || '…'}` : '';
  const aud = (id, short) => h('div', { class: `azc-aud${inhOff(id) ? ' dis' : ''}` }, ...AZC_AUD.map(([k, e, l]) => h('button', { type: 'button', class: `a-${k}${audOf(id) === k ? ' on' : ''}`, title: l, onclick: (ev) => { ev.stopPropagation(); setA(id, k); } }, e, short ? null : h('span', { class: 'w', text: ' ' + l }))));
  const q = AZI.q.trim();
  const match = (id) => { const n = AzkarKit.NODE[id]; const okF = !AZI.filter || (AZI.filter === 'sch' ? !!C.sch[id] : audOf(id) === AZI.filter); return okF && (!q || n.n.includes(q)); };
  const deep = (id) => match(id) || (AzkarKit.NODE[id].kids || []).some(([k]) => deep(k));
  const row = (id, sub) => { const n = AzkarKit.NODE[id], inh = inhOff(id), s = C.sch[id];
    return [h('div', { class: `azc-it${sub ? ' sub' : ''}` },
      h('div', {}, h('div', { class: 'n' }, n.n, n.review ? h('span', { class: 'azc-tag rv', text: 'يحتاج مراجعة' }) : null),
        h('div', { class: 'meta' }, inh ? h('span', { class: 'azc-tag inh', text: `مخفي لأن «${inh}» مخفي` }) : null,
          s ? h('button', { type: 'button', class: 'azc-tag sch', onclick: () => azcOpts(id, re) }, `📅 ${schTxt(s)} · ${AzkarKit.inSeason(s) ? 'ظاهر الآن' : 'مخفي حتى موسمه'}`) : null,
          C.look[id] === 'soon' && (audOf(id) === 'off' || s) ? h('span', { class: 'azc-tag', text: 'يظهر «قريباً»' }) : null)),
      h('div', { class: 'azc-r' }, aud(id), h('button', { type: 'button', class: 'azc-more', 'aria-label': 'خيارات', onclick: () => azcOpts(id, re) }, '⋯'))),
    ...(n.kids ? n.kids.filter(([k]) => deep(k)).flatMap(([k]) => row(k, true)) : [])]; };
  const search = h('input', { class: 'input', placeholder: '🔍 دوّر: الحج، المصحف، القبلة…', value: AZI.q });
  search.addEventListener('input', () => { AZI.q = search.value; clearTimeout(search._t); search._t = setTimeout(() => { re(); const s2 = box.querySelector('.azc-tools .input'); s2?.focus(); s2?.setSelectionRange(s2.value.length, s2.value.length); }, 300); });
  const MODES = [['full', 'كامل', 'كل شي ظاهر للكل'], ['basic', 'الأساسي فقط', 'المصحف + الأذكار + المواقيت'], ['beta', '🧪 الجديد للمختبرين', 'الجاهز للكل والجديد للمختبرين'], ['ramadan', '🌙 وضع رمضان', 'يبرز رمضان والمصحف'], ['hajj', '🕋 وضع الحج', 'يظهر الحج والعمرة']];
  const mode = (k) => {
    aziSnap(); C.on = true; C.a = {}; C.sch = {}; C.look = {};
    if (k === 'basic') ['t_streak', 't_hadith', 'm_story', 'a_fadl', 'a_ruqya', 'a_ramadan', 'a_hajj', 's_cal', 's_occ', 's_qibla', 'g_story'].forEach((x) => (C.a[x] = 'off'));
    if (k === 'beta') Object.assign(C.a, { a_ruqya: 'beta', a_ramadan: 'beta', a_hajj: 'beta', s_occ: 'beta' });
    if (k === 'ramadan') { Object.assign(C.a, { a_hajj: 'off' }); C.defTab = 'mushaf'; }
    if (k === 'hajj') { Object.assign(C.a, { a_ramadan: 'off' }); C.defTab = 'azkar'; }
    if (k === 'full') C.defTab = 'today';
    azaChanged(); re(); toast('✓ طبّقنا الوضع — راجعه قبل الحفظ');
  };
  const hidden = Object.values(C.a).filter((x) => x === 'off').length;
  RC(box,
    h('div', { class: 'azi-top' }, h('button', { type: 'button', class: 'btn', onclick: () => aziUndo(re) }, '↶ تراجع')),
    h('section', { class: 'set-card azi-card' },
      (() => { const c = h('input', { type: 'checkbox', checked: C.on }); c.addEventListener('change', () => { aziSnap(); C.on = c.checked; azaChanged(); re(); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'قسم «أذكاري» كامل' }), h('small', { text: C.on ? `شغّال · ${UI.n(hidden)} عنصر مخفي` : 'موقوف — المستخدمين يشوفون رسالة الصيانة' })), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))); })(),
      C.on ? h('div', { class: 'chips' }, h('span', { class: 'hint', text: 'يفتح على:' }), ...AzkarKit.TREE.slice(0, 4).map(([id, n]) => h('button', { type: 'button', class: `chip${C.defTab === id ? ' on' : ''}`, onclick: () => { aziSnap(); C.defTab = id; azaChanged(); re(); } }, n.replace(/تبويب |«|»/g, ''))))
        : (() => { const i = h('input', { class: 'input', value: C.msg || '', maxlength: 120 }); i.addEventListener('change', () => { aziSnap(); C.msg = i.value; azaChanged(); }); return h('label', { class: 'field' }, h('span', { text: 'رسالة الصيانة' }), i); })()),
    h('section', { class: 'set-card azi-card' }, h('b', { class: 'azi-h', text: '⚡ أوضاع جاهزة' }), h('p', { class: 'hint', text: 'ضغطة وحدة تضبط كل الأقسام — وتعدّل بعدها براحتك' }),
      h('div', { class: 'azi-pre' }, ...MODES.map(([k, n, d]) => h('button', { type: 'button', class: 'azi-p', onclick: () => mode(k) }, h('b', { text: n }), h('small', { text: d }))))),
    h('section', { class: 'set-card azi-card' }, h('b', { class: 'azi-h', text: '🌳 كل شي في القسم' }),
      h('p', { class: 'hint', text: 'لكل عنصر: 👁 للكل · 🧪 المختبرين · 💎 المشتركين · 🚫 مخفي — و«⋯» للجدولة والمواسم وشكل الإخفاء' }),
      h('div', { class: 'azc-tools' }, search, ...[['', 'الكل'], ['off', 'المخفي'], ['beta', '🧪'], ['pro', '💎'], ['sch', '📅 مجدول']].map(([k, l]) => h('button', { type: 'button', class: `chip${AZI.filter === k ? ' on' : ''}`, onclick: () => { AZI.filter = k; re(); } }, l))),
      ...AzkarKit.TREE.filter(([id]) => deep(id)).map(([id, n, em, kids]) => {
        const open = AZI.open.has(id) || !!q || !!AZI.filter, cnt = kids.filter(([k]) => audOf(k) === 'off').length;
        return h('div', { class: `azc-grp${open ? ' open' : ''}${audOf(id) === 'off' || !C.on ? ' off' : ''}` },
          h('div', { class: 'azc-gh', onclick: (e) => { if (e.target.closest('.azc-aud,.azc-more')) return; if (AZI.open.has(id)) AZI.open.delete(id); else AZI.open.add(id); re(); } },
            h('span', { class: 'em', text: em }), h('div', { class: 't' }, h('b', { text: n }), h('small', { text: `${UI.n(kids.length)} عنصر${cnt ? ` · ${UI.n(cnt)} مخفي` : ''}${C.sch[id] ? ' · 📅 مجدول' : ''}` })),
            id === 'general' ? null : aud(id, true), id === 'general' ? null : h('button', { type: 'button', class: 'azc-more', onclick: (e) => { e.stopPropagation(); azcOpts(id, re); } }, '⋯'), h('span', { class: 'ar', text: '◀' })),
          open ? h('div', { class: 'azc-items' }, ...kids.filter(([k]) => deep(k)).flatMap(([k]) => row(k))) : null);
      }),
      h('div', { class: 'chips' }, h('button', { type: 'button', class: 'btn sm', onclick: () => { AZI.open = new Set(AzkarKit.TREE.map((x) => x[0])); re(); } }, 'فتح الكل'), h('button', { type: 'button', class: 'btn sm', onclick: () => { AZI.open = new Set(); re(); } }, 'طي الكل'),
        h('button', { type: 'button', class: 'btn sm', onclick: () => { aziSnap(); Object.values(AzkarKit.NODE).forEach((n) => { if (n.review) { C.a[n.id] = 'off'; C.look[n.id] = 'soon'; } }); azaChanged(); re(); toast('أخفيناها وتظهر «قريباً» 🔒'); } }, '🙈 أخفِ كل محتوى «يحتاج مراجعة»'))),
    h('p', { class: 'hint', text: '💡 التغييرات توصل للمستخدمين بعد «احفظ الإعدادات» — أول ما يفتحون القسم.' }));
  UI.digitize(box);
}
function azcOpts(id, re) {
  let el = document.getElementById('azc-sheet');
  if (!el) { el = h('section', { class: 'sheet', id: 'azc-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  const paint = () => {
    const C = aziC(), n = AzkarKit.NODE[id], s = C.sch[id] || { type: 'always' }, a = C.a[id] || 'all';
    const setS = (v) => { aziSnap(); if (v.type === 'always') delete C.sch[id]; else C.sch[id] = v; azaChanged(); re(); paint(); };
    const date = (k) => { const i = h('input', { class: 'input', type: 'date', value: s[k] || '' }); i.addEventListener('change', () => setS({ ...s, type: 'dates', [k]: i.value })); return i; };
    el.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('div', {}, h('h2', { text: n.n }), h('small', { class: 'hint', text: AzkarKit.PARENT[id] ? 'داخل ' + AzkarKit.NODE[AzkarKit.PARENT[id]].n : 'تبويب رئيسي' })), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
      h('div', { class: 'sheet-body azi-eb' },
        h('b', { class: 'azi-sh', text: 'مين يشوفه' }),
        h('div', { class: 'chips' }, ...AZC_AUD.map(([k, e, l]) => h('button', { type: 'button', class: `chip${a === k ? ' on' : ''}`, onclick: () => { aziSnap(); if (k === 'all') delete C.a[id]; else C.a[id] = k; azaChanged(); re(); paint(); } }, `${e} ${l}`))),
        h('b', { class: 'azi-sh', text: 'متى يظهر 📅' }),
        h('div', { class: 'chips' }, ...[['always', 'دائماً'], ['dates', 'من تاريخ إلى تاريخ'], ['season', 'موسم هجري (تلقائي)']].map(([k, l]) => h('button', { type: 'button', class: `chip${s.type === k ? ' on' : ''}`, onclick: () => setS({ type: k, v: k === 'season' ? s.v || 'ramadan' : undefined }) }, l))),
        s.type === 'dates' ? h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'من' }), date('from')), h('label', { class: 'field' }, h('span', { text: 'إلى' }), date('to'))) : null,
        s.type === 'season' ? h('div', { class: 'chips' }, ...Object.entries(AzkarKit.SEAS_NAME).map(([k, l]) => h('button', { type: 'button', class: `chip${s.v === k ? ' on' : ''}`, onclick: () => setS({ type: 'season', v: k }) }, l))) : null,
        s.type === 'season' ? h('p', { class: 'hint', text: 'يظهر وحده في موسمه ويختفي بعده — حسب تقويم أم القرى' }) : null,
        h('b', { class: 'azi-sh', text: 'لما يكون مخفي، يظهر للمستخدم كـ' }),
        h('div', { class: 'chips' }, ...[['gone', 'يختفي تماماً'], ['soon', '🔒 «قريباً» مقفل']].map(([k, l]) => h('button', { type: 'button', class: `chip${(C.look[id] || 'gone') === k ? ' on' : ''}`, onclick: () => { aziSnap(); if (k === 'gone') delete C.look[id]; else C.look[id] = k; azaChanged(); re(); paint(); } }, l))),
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => closeSheet(el) }, 'تم')));
  };
  paint(); openSheet('#azc-sheet');
}
