/* NOBLE — لوحة التحكم ← التصاميم (1.14)
 * القوالب (صورة + أماكن النصوص بالضغط على المعاينة)، المناسبات ومواسمها، النصوص المقترحة، القوالب الجاهزة، المقترح اليوم، إحصائية.
 */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const AD = { sub: 'list', items: null, meta: null, stats: null, dirty: false };
const AD_SUBS = [['list', '🖼 القوالب'], ['bgs', '🌄 الخلفيات'], ['callig', '✒️ المخطوطات'], ['fonts', '🔤 الخطوط'], ['sounds', '🎵 الأصوات والأناشيد'], ['motion', '🎬 الحركة والفيديو'], ['sign', '✍️ التوقيع والشعار'], ['occ', '🎉 المناسبات والنصوص'], ['builtin', '✨ القوالب الجاهزة'], ['settings', '⚙️ الإعدادات']];
const AD_WEEK = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
const adClone = (x) => JSON.parse(JSON.stringify(x));
const adIsTpl = (x) => !x.data?.kind || x.data.kind === 'tpl';
const adKind = (k) => (AD.items || []).filter((x) => x.data?.kind === k);
const adCfg = () => DesignKit.cfg(AD.meta || {});
const adSwitch = (checked, onChange, label, sub) => {
  const sw = h('input', { type: 'checkbox', checked: !!checked });
  sw.addEventListener('change', () => onChange(sw.checked));
  const s = h('span', { class: 'switch' }, sw, h('span', { class: 'track' }));
  return label ? h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), s) : h('label', { class: 'switch' }, sw, h('span', { class: 'track' }));
};
const adField = (label, input, hint) => h('label', { class: 'field' }, h('span', { text: label }), input, hint ? h('small', { class: 'hint', text: hint }) : null);
const adInput = (val, on, opt = {}) => {
  const i = h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, type: opt.type || 'text', maxlength: opt.max || 200, placeholder: opt.ph || '', ...(opt.min != null ? { min: opt.min } : {}), ...(opt.maxv != null ? { max: opt.maxv } : {}), ...(opt.step ? { step: opt.step } : {}) });
  i.value = val ?? '';
  i.addEventListener('input', () => on(opt.type === 'number' ? Number(i.value) : i.value));
  return i;
};
const adSelect = (val, opts, on) => {
  const s = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: v, text: l })));
  s.value = val ?? '';
  s.addEventListener('change', () => on(s.value));
  return s;
};

async function openDesignsAdmin(force) {
  const box = $('#a-designs');
  if (!AD.meta || force) {
    RC(box, h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      const [items, stats, pub] = await Promise.all([Cloud.admin.designs(), Cloud.admin.designStats(), Cloud.designsList()]);
      AD.items = items || []; AD.stats = stats; AD.meta = (pub && pub.meta) || {};
    } catch (e) {
      const msg = Cloud.msg(e);
      RC(box, h('p', { class: 'note-box', text: /function|schema|relation/i.test(msg) ? 'شغّل ملف supabase/update-all.sql (كامل) في Supabase ← SQL Editor أولاً حتى يشتغل قسم التصاميم.' : 'تعذّر التحميل: ' + msg }));
      return;
    }
  }
  renderDesignsAdmin();
}

function renderDesignsAdmin() {
  const s = AD.stats || {};
  $('#a-designs').replaceChildren(
    h('section', { class: 'a-hero' },
      h('div', {}, h('h1', {}, h('span', { class: 'title-pill', text: 'التصاميم' })),
        h('p', { class: 'lead', text: 'ارفع صورة التصميم وحدّد مكان النص بالضغط على المعاينة — والمستخدم يكتب اسمه وعبارته ويحفظ أو يشارك. المناسبات تطلع تلقائياً في موسمها (رمضان، العيد، اليوم الوطني لدولة المستخدم…).' })),
      h('div', { class: 'a-save' },
        h('button', { type: 'button', class: 'btn', onclick: () => editDesign({}) }, icon('plus', { size: 16 }), 'قالب جديد'),
        h('button', { type: 'button', class: 'btn btn-primary', id: 'ad-save', disabled: !AD.dirty, onclick: saveDesignMeta }, icon('check', { size: 16 }), 'احفظ الإعدادات'))),
    h('div', { class: 'an-stats' }, ...[[(AD.items || []).filter(adIsTpl).length, 'قالب'], [adKind('bg').length, 'خلفية'], [adKind('callig').length, 'مخطوطة'], [adKind('font').length, 'خط'], [adKind('sound').length, 'صوت'], [s.uses, 'مرة حُفظ/شورك']].map(([n, l]) =>
      h('div', {}, h('b', { class: 'num', text: UI.n(n || 0) }), h('small', { text: l })))),
    h('nav', { class: 'chips an-nav' }, ...AD_SUBS.map(([id, l]) => h('button', { type: 'button', class: `chip${AD.sub === id ? ' on' : ''}`, onclick: () => { AD.sub = id; renderDesignsAdmin(); } }, l))),
    h('div', { id: 'ad-body', class: 'an-body' }));
  const body = $('#ad-body');
  if (AD.sub === 'list') paintAdList(body);
  else if (AD.sub === 'callig') paintAdCallig(body);
  else if (AD.sub === 'bgs') paintAdMedia(body, 'bg');
  else if (AD.sub === 'fonts') paintAdMedia(body, 'font');
  else if (AD.sub === 'sounds') paintAdMedia(body, 'sound');
  else if (AD.sub === 'motion') paintAdMotion(body);
  else if (AD.sub === 'sign') paintAdSign(body);
  else if (AD.sub === 'occ') paintAdOcc(body);
  else if (AD.sub === 'builtin') paintAdBuiltin(body);
  else paintAdSettings(body);
  UI.digitize($('#a-designs'));
}
function adChanged() { AD.dirty = true; const b = $('#ad-save'); if (b) b.disabled = false; }
async function saveDesignMeta() {
  try { await Cloud.admin.designMeta(AD.meta); AD.dirty = false; toast('حُفظت إعدادات التصاميم ✓', { type: 'success' }); renderDesignsAdmin(); }
  catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

/* مصغّرة معاينة */
function adThumb(t, w = 120) {
  const cv = h('canvas', { class: 'ad-th' });
  DesignKit.render(t, {}, { width: w * 2, canvas: cv }).catch(() => {});
  return cv;
}
const adOccName = (id) => { const o = adCfg().occasions.find((x) => x.id === id) || DesignKit.OCCASIONS.find((x) => x.id === id); return o ? `${o.ic} ${o.name}` : id || '—'; };

/* ---------- القوالب المرفوعة ---------- */
function paintAdList(body) {
  const list = (AD.items || []).filter(adIsTpl);
  if (!list.length) {
    RC(body, h('div', { class: 'empty' }, h('b', { text: 'ما رفعت قوالب بعد' }), h('small', { text: 'المستخدمين يشوفون القوالب الجاهزة الحين. اضغط «قالب جديد» وارفع صورتك.' })));
    return;
  }
  const move = async (i, d) => {
    const a = list[i], b = list[i + d];
    if (!b) return;
    try { await Promise.all([Cloud.admin.designSave(a.id, null, b.sort), Cloud.admin.designSave(b.id, null, a.sort)]); [a.sort, b.sort] = [b.sort, a.sort]; list.sort((x, y) => x.sort - y.sort || x.id - y.id); paintAdList(body); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  RC(body, ...list.map((it, i) => {
    const t = { ...it.data, id: 'r' + it.id };
    return h('div', { class: `an-row ad-row${it.active ? '' : ' off'}` }, adThumb(t, 60),
      h('div', { class: 'an-c' },
        h('b', { text: (t.premium ? '★ ' : '') + (t.title || 'بدون عنوان') + (String(AD.meta?.featured) === String(it.id) ? ' · 📌 مقترح اليوم' : '') }),
        h('small', { text: `${adOccName(t.cat)} · ${DesignKit.SIZES[t.size]?.[2] || 'منشور'} · ${UI.n((t.slots || []).length)} نص · استُخدم ${UI.n(it.uses || 0)} مرة${it.active ? '' : ' · مخفي'}` })),
      h('div', { class: 'an-a' },
        adSwitch(it.active, async (v) => { try { await Cloud.admin.designSave(it.id, null, null, v); it.active = v; toast(v ? 'ظاهر للمستخدمين ✓' : 'أُخفي', { type: 'success' }); paintAdList(body); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }),
        h('button', { type: 'button', class: 'icon-btn', title: 'لفوق', disabled: !i, onclick: () => move(i, -1) }, '↑'),
        h('button', { type: 'button', class: 'icon-btn', title: 'لتحت', disabled: i === list.length - 1, onclick: () => move(i, 1) }, '↓'),
        h('button', { type: 'button', class: 'btn', onclick: () => editDesign(it) }, icon('edit', { size: 15 }), 'تعديل'),
        h('button', { type: 'button', class: 'icon-btn danger', title: 'حذف', onclick: async () => {
          if (!confirm(`حذف «${t.title || 'القالب'}» نهائياً؟`)) return;
          try { await Cloud.admin.designDelete(it.id); AD.items = AD.items.filter((x) => x.id !== it.id); toast('حُذف', { type: 'success' }); renderDesignsAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
        } }, icon('trash', { size: 16 }))));
  }));
}

/* ---------- محرّر القالب: صورة + نصوص بالضغط على المعاينة ---------- */
const AD_SLOT = (k, label, def, y, size, extra = {}) => ({ k, label, def, x: 0.5, y, size, weight: 700, color: '#FFFFFF', align: 'center', maxW: 0.84, lines: 2, ...extra });
function editDesign(it) {
  const isNew = !it.id;
  const t = adClone(it.data || { title: '', cat: adCfg().occasions[0]?.id || 'general', size: 'post', image: '', dim: 0, premium: false, mark: true,
    slots: [AD_SLOT('main', 'العبارة', 'عيد مبارك', 0.45, 110), AD_SLOT('name', 'الاسم', '', 0.8, 44, { weight: 400 })] });
  t.slots = Array.isArray(t.slots) ? t.slots : [];
  let sel = 0;
  const cv = h('canvas', { class: 'ad-prev', title: 'اضغط لتحديد مكان النص المختار' });
  let pending = 0;
  const paint = () => { const n = ++pending; requestAnimationFrame(() => { if (n === pending) DesignKit.render({ ...t, id: 'edit' }, {}, { width: 540, canvas: cv }).then(() => mark()).catch(() => {}); }); };
  const mark = () => {
    const s = t.slots[sel]; if (!s) return;
    const c = cv.getContext('2d');
    c.save(); c.strokeStyle = '#FFB43D'; c.setLineDash([8, 6]); c.lineWidth = 2;
    const w = (s.maxW || 0.84) * cv.width, hh = (s.size || 60) * (cv.width / 1080) * 1.5 * (s.lines || 1);
    const x = s.align === 'right' ? (s.x + (s.maxW || 0.84) / 2) * cv.width - w : s.align === 'left' ? (s.x - (s.maxW || 0.84) / 2) * cv.width : s.x * cv.width - w / 2;
    c.strokeRect(x, s.y * cv.height - hh / 2, w, hh);
    c.fillStyle = '#FFB43D'; c.beginPath(); c.arc(s.x * cv.width, s.y * cv.height, 5, 0, 7); c.fill(); c.restore();
  };
  // سحب أو ضغط على المعاينة ينقل النص المختار
  let drag = false;
  const at = (e) => {
    const r = cv.getBoundingClientRect(), s = t.slots[sel]; if (!s) return;
    s.x = Math.round(Math.min(0.98, Math.max(0.02, (e.clientX - r.left) / r.width)) * 100) / 100;
    s.y = Math.round(Math.min(0.98, Math.max(0.02, (e.clientY - r.top) / r.height)) * 100) / 100;
    paint(); paintSlots();
  };
  cv.addEventListener('pointerdown', (e) => { drag = true; cv.setPointerCapture?.(e.pointerId); at(e); });
  cv.addEventListener('pointermove', (e) => drag && at(e));
  cv.addEventListener('pointerup', () => (drag = false));

  const imgBox = h('div', { class: 'ad-img' });
  const paintImg = () => {
    const url = adInput(t.image, (v) => { t.image = v.trim(); paint(); }, { ltr: true, max: 600, ph: 'https://… أو ارفع صورة' });
    const file = h('input', { type: 'file', accept: 'image/png,image/jpeg,image/webp', hidden: true });
    file.addEventListener('change', async () => {
      const f = file.files[0]; if (!f) return;
      if (f.size > 4 * 1024 * 1024) return toast('الصورة أكبر من 4MB — صغّرها شوي', { type: 'error' });
      up.disabled = true; up.lastChild.textContent = 'جارٍ الرفع…';
      try { t.image = await Cloud.admin.designUpload(f); toast('رُفعت الصورة ✓', { type: 'success' }); paintImg(); paint(); }
      catch (e) { toast(Cloud.msg(e), { type: 'error' }); up.disabled = false; up.lastChild.textContent = 'ارفع صورة'; }
    });
    const up = h('button', { type: 'button', class: 'btn', onclick: () => file.click() }, icon('download', { size: 15 }), 'ارفع صورة');
    RC(imgBox, adField('صورة الخلفية', h('div', { class: 'ad-imgrow' }, url, up, file), 'مقاس مقترح: منشور 1080×1350، مربع 1080×1080، ستوري 1080×1920. بدون صورة يُرسم خلفية NOBLE.'),
      adField(`تعتيم الصورة (يوضّح النص) — ${Math.round((t.dim || 0) * 100)}٪`, (() => { const r = h('input', { type: 'range', min: 0, max: 0.7, step: 0.05 }); r.value = t.dim || 0; r.addEventListener('input', () => { t.dim = Number(r.value); r.parentElement.firstChild.textContent = `تعتيم الصورة (يوضّح النص) — ${Math.round(t.dim * 100)}٪`; paint(); }); return r; })()));
  };

  const slotBox = h('div', { class: 'ad-slots' });
  const paintSlots = () => {
    const s = t.slots[sel];
    RC(slotBox, 
      h('div', { class: 'chips' }, ...t.slots.map((x, i) => h('button', { type: 'button', class: `chip${i === sel ? ' on' : ''}`, onclick: () => { sel = i; paintSlots(); paint(); } }, x.label || x.k)),
        t.slots.length < 5 ? h('button', { type: 'button', class: 'chip', onclick: () => { t.slots.push(AD_SLOT('t' + Date.now().toString(36).slice(-4), 'نص جديد', 'اكتب هنا', 0.6, 60)); sel = t.slots.length - 1; paintSlots(); paint(); } }, '＋ نص') : null),
      s ? h('div', { class: 'ad-slot' },
        h('p', { class: 'hint', text: `📍 اضغط أو اسحب على المعاينة لتحريك «${s.label || s.k}» — المكان الحالي ${Math.round(s.x * 100)}٪ أفقي، ${Math.round(s.y * 100)}٪ رأسي` }),
        h('div', { class: 'row-2' },
          adField('اسم الحقل (يظهر للمستخدم)', adInput(s.label, (v) => { s.label = v; paintSlotChips(); }, { max: 30 })),
          adField('النص الافتراضي', adInput(s.def, (v) => { s.def = v; paint(); }, { max: 120, ph: 'فاضي = يكتبه المستخدم' }))),
        h('div', { class: 'row-3' },
          adField('حجم الخط', adInput(s.size, (v) => { s.size = Math.max(16, Math.min(260, v || 60)); paint(); }, { type: 'number', min: 16, maxv: 260 })),
          adField('السماكة', adSelect(String(s.weight || 700), [['700', 'عريض'], ['400', 'عادي'], ['300', 'خفيف']], (v) => { s.weight = Number(v); paint(); })),
          adField('المحاذاة', adSelect(s.align || 'center', [['center', 'وسط'], ['right', 'يمين'], ['left', 'يسار']], (v) => { s.align = v; paint(); }))),
        adField('الخط', adSelect(s.font || 'noor', [['noor', 'خط التطبيق (الافتراضي)'], ['plex', 'Plex'], ...(typeof FontKit !== 'undefined' ? FontKit.LIST.map((f) => ['k-' + f.id, f.name]) : []), ...adKind('font').map((f) => ['f' + f.id, '🔤 ' + (f.data.title || 'خط')])], async (v) => { s.font = v; DesignKit.registerFonts(adKind('font').map((f) => ({ id: f.id, url: f.data.url, title: f.data.title }))); await DesignKit.ensureFont(v); paint(); })),
        h('div', { class: 'row-3' },
          adField('اللون', (() => { const c = h('input', { type: 'color', class: 'input ad-color' }); c.value = /^#[0-9a-f]{6}$/i.test(s.color) ? s.color : '#ffffff'; c.addEventListener('input', () => { s.color = c.value; paint(); }); return c; })()),
          adField('أقصى أسطر', adSelect(String(s.lines || 2), [['1', '1'], ['2', '2'], ['3', '3'], ['4', '4']], (v) => { s.lines = Number(v); paint(); })),
          adField('عرض النص ٪', adInput(Math.round((s.maxW || 0.84) * 100), (v) => { s.maxW = Math.max(0.2, Math.min(0.96, (v || 84) / 100)); paint(); }, { type: 'number', min: 20, maxv: 96 }))),
        h('div', { class: 'ad-slot-a' },
          adSwitch(s.shadow !== false, (v) => { s.shadow = v; paint(); }, 'ظل خفيف للنص'),
          t.slots.length > 1 ? h('button', { type: 'button', class: 'btn danger', onclick: () => { t.slots.splice(sel, 1); sel = 0; paintSlots(); paint(); } }, icon('trash', { size: 15 }), 'احذف هذا النص') : null)) : null);
  };
  const paintSlotChips = () => slotBox.querySelectorAll('.chips .chip').forEach((b, i) => { if (t.slots[i]) b.textContent = t.slots[i].label || t.slots[i].k; });

  const occ = adCfg().occasions;
  const form = h('div', { class: 'ad-edit' },
    h('div', { class: 'ad-prev-wrap' }, cv),
    h('div', { class: 'ad-form' },
      h('div', { class: 'row-2' },
        adField('اسم القالب', adInput(t.title, (v) => (t.title = v), { max: 60, ph: 'مثال: عيد ذهبي' })),
        adField('المناسبة', adSelect(t.cat, occ.map((o) => [o.id, `${o.ic} ${o.name}`]), (v) => (t.cat = v)))),
      adField('المقاس', adSelect(t.size || 'post', Object.entries(DesignKit.SIZES).map(([k, v]) => [k, `${v[2]} (${v[0]}×${v[1]})`]), (v) => { t.size = v; paint(); })),
      imgBox,
      h('h3', { class: 'ad-h', text: 'النصوص على التصميم' }),
      slotBox,
      adSwitch(!!t.premium, (v) => (t.premium = v), '★ للمشتركين فقط', 'يظهر للكل مع نجمة، والاستخدام للمشترك'),
      adSwitch(t.mark !== false, (v) => { t.mark = v; paint(); }, 'توقيع NOBLE صغير بالزاوية')));
  paintImg(); paintSlots(); paint();

  const save = async () => {
    if (!t.title.trim()) return toast('اكتب اسم القالب');
    if (t.image && !/^https:\/\//.test(t.image) && !/^data:image\//.test(t.image)) return toast('رابط الصورة لازم يبدأ بـ https');
    try {
      const id = await Cloud.admin.designSave(it.id || null, t);
      toast(isNew ? 'أُضيف القالب ✓ يظهر للمستخدمين الحين' : 'حُفظ التعديل ✓', { type: 'success' });
      closeSheet($('#mk-sheet'));
      AD.items = await Cloud.admin.designs(); AD.stats = await Cloud.admin.designStats();
      if (!id) return;
      AD.sub = 'list'; renderDesignsAdmin();
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  mkSheet(isNew ? 'قالب جديد' : 'تعديل القالب', [form], [
    h('button', { type: 'button', class: 'btn', onclick: () => closeSheet($('#mk-sheet')) }, 'إلغاء'),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: save }, isNew ? 'أضف القالب' : 'احفظ')]);
}

/* ---------- المناسبات ومواسمها + النصوص المقترحة ---------- */
function adOccList() {
  if (!Array.isArray(AD.meta.occasions) || !AD.meta.occasions.length) AD.meta.occasions = adClone(DesignKit.OCCASIONS);
  return AD.meta.occasions;
}
const adSeasonKind = (s) => (!s ? '' : s.hijri ? 'hijri' : s.greg ? 'greg' : s.weekly ? 'weekly' : s.national ? 'national' : '');
function paintAdOcc(body) {
  const list = adOccList();
  AD.meta.texts = AD.meta.texts || {};
  const texts = (id) => AD.meta.texts[id] || DesignKit.TEXTS[id] || [];
  const card = (o, i) => {
    const kind = adSeasonKind(o.season);
    const seasonBox = h('div', { class: 'ad-season' });
    const paintSeason = () => {
      const k = adSeasonKind(o.season);
      let ed = null;
      if (k === 'hijri') {
        ed = adField('الفترة بالهجري (شهر:من-إلى) — مثال 9:1-30، 10:1-3', adInput((o.season.hijri || []).map(([m, a, b]) => `${m}:${a}-${b}`).join('، '), (v) => {
          o.season.hijri = String(v).split(/[،,]/).map((x) => x.trim().match(/^(\d{1,2}):(\d{1,2})-(\d{1,2})$/)).filter(Boolean).map((m) => [+m[1], +m[2], +m[3]]); adChanged();
        }, { ltr: true, max: 80 }));
      } else if (k === 'greg') {
        ed = h('div', { class: 'row-2' },
          adField('من (شهر-يوم)', adInput(o.season.greg.from, (v) => { o.season.greg.from = v; adChanged(); }, { ltr: true, max: 5, ph: '02-14' })),
          adField('إلى (شهر-يوم)', adInput(o.season.greg.to, (v) => { o.season.greg.to = v; adChanged(); }, { ltr: true, max: 5, ph: '02-16' })));
      } else if (k === 'weekly') {
        ed = h('div', { class: 'chips' }, ...AD_WEEK.map((d, n) => h('button', { type: 'button', class: `chip${o.season.weekly.includes(n) ? ' on' : ''}`, onclick: (e) => {
          o.season.weekly = o.season.weekly.includes(n) ? o.season.weekly.filter((x) => x !== n) : [...o.season.weekly, n]; e.currentTarget.classList.toggle('on'); adChanged();
        } }, d)));
      } else if (k === 'national') ed = h('p', { class: 'hint', text: 'يطلع قبل اليوم الوطني لدولة المستخدم بأسبوع (اليمن 22 مايو، السعودية 23 سبتمبر…) ويتغيّر العلم حسب دولته.' });
      RC(seasonBox, adField('متى يطلع «الحين»؟', adSelect(k, [['', 'طول السنة (بدون موسم)'], ['hijri', 'تاريخ هجري'], ['greg', 'تاريخ ميلادي'], ['weekly', 'أيام الأسبوع'], ['national', 'اليوم الوطني للمستخدم']], (v) => {
        o.season = v === 'hijri' ? { hijri: [[9, 1, 30]] } : v === 'greg' ? { greg: { from: '01-01', to: '01-03' } } : v === 'weekly' ? { weekly: [5] } : v === 'national' ? { national: true } : undefined;
        if (!o.season) delete o.season; adChanged(); paintSeason();
      })), ed);
    };
    paintSeason();
    const ta = h('textarea', { class: 'input textarea', rows: 3, maxlength: 1500 });
    ta.value = texts(o.id).join('\n');
    ta.addEventListener('input', () => { AD.meta.texts[o.id] = ta.value.split('\n').map((x) => x.trim()).filter(Boolean).slice(0, 20); adChanged(); });
    return h('div', { class: `ad-occ${o.on === false ? ' off' : ''}` },
      h('div', { class: 'ad-occ-h' },
        adInput(o.ic, (v) => { o.ic = v; adChanged(); }, { max: 4 }),
        adInput(o.name, (v) => { o.name = v; adChanged(); }, { max: 30 }),
        h('small', { class: 'hint', text: kind ? '🗓 موسمي' : '' }),
        adSwitch(o.on !== false, (v) => { o.on = v; adChanged(); }),
        h('button', { type: 'button', class: 'icon-btn', disabled: !i, onclick: () => { [list[i - 1], list[i]] = [list[i], list[i - 1]]; adChanged(); paintAdOcc(body); } }, '↑'),
        h('button', { type: 'button', class: 'icon-btn danger', title: 'حذف', onclick: () => { if (!confirm(`حذف مناسبة «${o.name}»؟`)) return; list.splice(i, 1); adChanged(); paintAdOcc(body); } }, icon('trash', { size: 15 }))),
      seasonBox,
      adField('نصوص مقترحة (كل سطر عبارة) — تطلع للمستخدم كأزرار سريعة', ta));
  };
  RC(body, 
    h('p', { class: 'hint', text: 'رتّب المناسبات وحدّد موسم كل وحدة — اللي في موسمها تطلع أول مع شارة «الحين» وتصير «مقترح اليوم».' }),
    ...list.map(card),
    h('div', { class: 'ad-row-a' },
      h('button', { type: 'button', class: 'btn', onclick: () => { list.push({ id: 'o' + Date.now().toString(36).slice(-5), name: 'مناسبة جديدة', ic: '🎈' }); adChanged(); paintAdOcc(body); } }, icon('plus', { size: 15 }), 'أضف مناسبة'),
      h('button', { type: 'button', class: 'btn', onclick: () => { if (!confirm('ترجيع المناسبات والنصوص للافتراضي؟')) return; delete AD.meta.occasions; delete AD.meta.texts; adChanged(); paintAdOcc(body); } }, '↺ الافتراضي')));
}

/* ---------- القوالب الجاهزة (مرسومة بالكود — تشتغل بدون نت) ---------- */
function paintAdBuiltin(body) {
  const hidden = new Set(AD.meta.hiddenBuiltin || []);
  const set = () => { AD.meta.hiddenBuiltin = [...hidden]; adChanged(); };
  RC(body, 
    adSwitch(AD.meta.builtinOff !== true, (v) => { AD.meta.builtinOff = !v; adChanged(); paintAdBuiltin(body); }, 'إظهار القوالب الجاهزة', 'قوالب NOBLE المرسومة — خفيفة وتشتغل بدون نت. تقدر تخفي اللي ما يعجبك.'),
    AD.meta.builtinOff === true ? null : h('div', { class: 'ad-grid' }, ...DesignKit.BUILTIN.map((t) => h('div', { class: `ad-bi${hidden.has(t.id) ? ' off' : ''}` }, adThumb(t, 90),
      h('b', { text: t.title }), h('small', { text: adOccName(t.cat) }),
      adSwitch(!hidden.has(t.id), (v) => { v ? hidden.delete(t.id) : hidden.add(t.id); set(); paintAdBuiltin(body); })))));
}

/* ---------- الإعدادات: العنوان والمقترح ---------- */
function paintAdSettings(body) {
  const m = AD.meta;
  const opts = [['', '🗓 تلقائي — حسب الموسم (مستحسن)'],
    ...(AD.items || []).filter((x) => x.active && adIsTpl(x)).map((x) => [String(x.id), '🖼 ' + (x.data?.title || x.id)]),
    ...(m.builtinOff === true ? [] : DesignKit.BUILTIN.filter((b) => !(m.hiddenBuiltin || []).includes(b.id)).map((b) => [b.id, '✨ ' + b.title + ' · ' + adOccName(b.cat)]))];
  RC(body, h('div', { class: 'ad-form' },
    adField('عنوان القسم', adInput(m.title || '', (v) => { m.title = v; adChanged(); }, { max: 30, ph: 'التصاميم' })),
    adField('السطر التعريفي', adInput(m.sub || '', (v) => { m.sub = v; adChanged(); }, { max: 90, ph: 'تهاني ومناسبات بتصاميم NOBLE — اكتب اسمك وشاركها' })),
    adSwitch(m.greet !== false, (v) => { m.greet = v; adChanged(); }, '💌 «بطاقة تهنئة بخطوات» للمستخدمين', 'معالج سريع: المناسبة ← المخطوطة ← الخلفية ← الزخرفة ← الكتابة ← الألوان — يستخدم مخطوطاتك وخلفياتك المرفوعة'),
    adSwitch(m.studio !== false, (v) => { m.studio = v; adChanged(); }, '🎬 «استوديو NOBLE» للمستخدمين', 'محرر حر: مقاسات مخصصة، صور بإطارات، تحريك، صوت، وتصدير فيديو — التوقيع من «✍️ التوقيع والشعار» والأصوات من «🎵 الأصوات»'),
    adField('📌 «مقترح اليوم» في أعلى القسم', adSelect(m.featured || '', opts, (v) => { m.featured = v; adChanged(); }), 'تلقائي = يختار قالب من المناسبة اللي في موسمها الحين، ويتغيّر يومياً.'),
    h('p', { class: 'note-box', text: 'الوصول للقسم (مجاني/مشترك) والعمل بدون نت تتحكم فيه من «التطبيقات ← الأقسام والاشتراكات». القوالب المعلّمة ★ تحتاج ميزة «القوالب المميّزة»، وأدوات الصورة الاحترافية ميزة «أدوات الصورة»، وإخفاء التوقيع ميزة «إخفاء توقيع NOBLE» — كلها تتحكم فيها هناك.' })));
}

/* ---------- المخطوطات: صور شفافة (PNG) يضيفها المستخدم فوق أي تصميم أو صورته ---------- */
function paintAdCallig(body) {
  const list = (AD.items || []).filter((x) => x.data?.kind === 'callig');
  RC(body, 
    h('p', { class: 'hint', text: 'ارفع مخطوطة بخلفية شفافة (PNG) — مثل «رمضان كريم» أو «عيد مبارك». تظهر للمستخدمين فوراً، ويضيفونها فوق أي قالب أو صورتهم، ويحرّكونها ويكبّرونها. المخطوطة البيضاء أو السوداء يقدر المستخدم يلوّنها.' }),
    adSwitch(AD.meta.callig !== false, (v) => { AD.meta.callig = v; adChanged(); }, 'إظهار المخطوطات للمستخدمين', 'احفظ الإعدادات بعد التغيير'),
    h('div', { class: 'ad-row-a' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => editCallig({}) }, icon('plus', { size: 15 }), 'أضف مخطوطة')),
    list.length ? h('div', { class: 'ad-grid' }, ...list.map((it) => h('div', { class: `ad-bi ad-cal${it.active ? '' : ' off'}` },
      h('div', { class: 'ad-cal-img' }, h('img', { src: it.data.image, alt: '', loading: 'lazy' })),
      h('b', { text: (it.data.premium ? '★ ' : '') + (it.data.title || 'مخطوطة') }), h('small', { text: `${adOccName(it.data.cat)} · استُخدمت ${UI.n(it.uses || 0)}` }),
      h('div', { class: 'ad-cal-a' },
        adSwitch(it.active, async (v) => { try { await Cloud.admin.designSave(it.id, null, null, v); it.active = v; paintAdCallig(body); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }),
        h('button', { type: 'button', class: 'icon-btn', title: 'تعديل', onclick: () => editCallig(it) }, icon('edit', { size: 15 })),
        h('button', { type: 'button', class: 'icon-btn danger', title: 'حذف', onclick: async () => { if (!confirm('حذف المخطوطة نهائياً؟')) return; try { await Cloud.admin.designDelete(it.id); AD.items = AD.items.filter((x) => x.id !== it.id); renderDesignsAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, icon('trash', { size: 15 })))))) 
      : h('div', { class: 'empty' }, h('b', { text: 'ما فيه مخطوطات بعد' }), h('small', { text: 'ارفع أول مخطوطة PNG شفافة.' })));
}
function editCallig(it) {
  const d = adClone(it.data || { kind: 'callig', title: '', cat: adCfg().occasions[0]?.id || 'general', image: '', premium: false, tint: true, color: '', w: 0.6 });
  const prev = h('canvas', { class: 'ad-prev' });
  const paint = () => DesignKit.render({ id: 'cal', size: 'post', bg: 'flame', pal: ['#070b22', '#22145a', '#F0922F'], slots: [], mark: false }, {},
    { width: 540, canvas: prev, layers: d.image ? [{ url: d.image, x: 0.5, y: 0.4, w: d.w || 0.6, ...(d.color ? { tint: d.color } : {}) }] : [] }).catch(() => {});
  const file = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml', hidden: true });
  const up = h('button', { type: 'button', class: 'btn', onclick: () => file.click() }, icon('download', { size: 15 }), 'ارفع PNG');
  file.addEventListener('change', async () => {
    const f = file.files[0]; if (!f) return;
    if (f.size > 3 * 1024 * 1024) return toast('الملف أكبر من 3MB', { type: 'error' });
    up.disabled = true;
    try { d.image = await Cloud.admin.designUpload(f); url.value = d.image; paint(); toast('رُفعت ✓', { type: 'success' }); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    up.disabled = false;
  });
  const url = adInput(d.image, (v) => { d.image = v.trim(); paint(); }, { ltr: true, max: 600, ph: 'https://… أو ارفع' });
  const col = h('input', { type: 'color', class: 'input ad-color' }); col.value = /^#[0-9a-f]{6}$/i.test(d.color) ? d.color : '#ffffff';
  col.addEventListener('input', () => { d.color = col.value; paint(); });
  const w = h('input', { type: 'range', min: 0.2, max: 1.1, step: 0.05, value: d.w || 0.6 }); w.addEventListener('input', () => { d.w = Number(w.value); paint(); });
  const form = h('div', { class: 'ad-edit' }, h('div', { class: 'ad-prev-wrap' }, prev),
    h('div', { class: 'ad-form' },
      h('div', { class: 'row-2' }, adField('الاسم', adInput(d.title, (v) => (d.title = v), { max: 40, ph: 'رمضان كريم — ذهبي' })),
        adField('المناسبة', adSelect(d.cat, adCfg().occasions.map((o) => [o.id, `${o.ic} ${o.name}`]), (v) => (d.cat = v)))),
      adField('الصورة (PNG شفاف)', h('div', { class: 'ad-imgrow' }, url, up, file), 'الأفضل عرض 1000px أو أكثر بخلفية شفافة.'),
      adField('الحجم الافتراضي على التصميم', w),
      h('div', { class: 'row-2' }, adField('لون افتراضي (اختياري)', col), h('div', { class: 'field' }, h('span', { text: ' ' }), h('button', { type: 'button', class: 'btn', onclick: () => { d.color = ''; paint(); } }, '↺ لونها الأصلي'))),
      adSwitch(d.tint !== false, (v) => (d.tint = v), 'المستخدم يقدر يلوّنها', 'للمخطوطات بلون واحد (أبيض/أسود/ذهبي)'),
      adSwitch(!!d.premium, (v) => (d.premium = v), '★ للمشتركين فقط')));
  paint();
  mkSheet(it.id ? 'تعديل المخطوطة' : 'مخطوطة جديدة', [form], [
    h('button', { type: 'button', class: 'btn', onclick: () => closeSheet($('#mk-sheet')) }, 'إلغاء'),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      if (!d.image) return toast('ارفع صورة المخطوطة');
      if (!/^https:\/\//.test(d.image) && !/^data:image\//.test(d.image)) return toast('رابط الصورة لازم يبدأ بـ https');
      d.kind = 'callig';
      try { await Cloud.admin.designSave(it.id || null, d); toast('حُفظت ✓ — ظاهرة للمستخدمين الحين', { type: 'success' }); closeSheet($('#mk-sheet')); AD.items = await Cloud.admin.designs(); AD.sub = 'callig'; renderDesignsAdmin(); }
      catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    } }, 'احفظ')]);
}

/* ---------- توقيع NOBLE والشعار تحت كل صورة ---------- */
function paintAdSign(body) {
  const sg = (AD.meta.sign = { ...DesignKit.SIGN, ...(AD.meta.sign || {}) });
  const prev = h('canvas', { class: 'ad-prev' });
  let tpl = 0;
  const samples = DesignKit.BUILTIN.filter((b) => ['b-ram1', 'b-wed', 'b-eid2', 'b-gen'].includes(b.id));
  const logoSrc = () => (sg.logo === false ? '' : sg.logoUrl || (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'));
  const paint = () => DesignKit.render(samples[tpl] || DesignKit.BUILTIN[0], {}, { width: 540, canvas: prev, sign: sg.on ? { ...sg, logoSrc: logoSrc() } : null }).catch(() => {});
  const ch = () => { adChanged(); paint(); };
  const file = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml', hidden: true });
  file.addEventListener('change', async () => {
    const f = file.files[0]; if (!f) return;
    try { sg.logoUrl = await Cloud.admin.designUpload(f); toast('رُفع الشعار ✓', { type: 'success' }); ch(); paintAdSign(body); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  });
  const col = h('input', { type: 'color', class: 'input ad-color' }); col.value = /^#[0-9a-f]{6}$/i.test(sg.color) ? sg.color : '#ffffff';
  col.addEventListener('input', () => { sg.color = col.value; ch(); });
  const rng = (key, min, max, step, label, fmt) => { const r = h('input', { type: 'range', min, max, step, value: sg[key] }); const lb = h('span', { text: `${label} — ${fmt(sg[key])}` }); r.addEventListener('input', () => { sg[key] = Number(r.value); lb.textContent = `${label} — ${fmt(sg[key])}`; ch(); }); return h('label', { class: 'field' }, lb, r); };
  RC(body, h('div', { class: 'ad-edit' },
    h('div', { class: 'ad-prev-wrap' }, prev, h('div', { class: 'chips ad-samples' }, ...samples.map((b, i) => h('button', { type: 'button', class: `chip${i === tpl ? ' on' : ''}`, onclick: (e) => { tpl = i; e.currentTarget.parentElement.querySelectorAll('.chip').forEach((x, j) => x.classList.toggle('on', j === i)); paint(); } }, b.title)))),
    h('div', { class: 'ad-form' },
      h('p', { class: 'hint', text: 'يطلع التوقيع والشعار تحت كل تصميم يحفظه أو يشاركه المستخدم — دعاية مجانية للتطبيق مع كل مشاركة. التغيير يوصل للمستخدمين فوراً بعد «احفظ الإعدادات».' }),
      adSwitch(sg.on, (v) => { sg.on = v; ch(); }, 'إظهار التوقيع', 'عند الإيقاف تطلع الصور بدون أي توقيع'),
      adField('نص التوقيع', adInput(sg.text, (v) => { sg.text = v; ch(); }, { max: 40, ph: 'NOBLE' }), 'مثال: NOBLE أو @noble.app أو صُمّم في NOBLE — فاضي = الشعار فقط'),
      adSwitch(sg.logo !== false, (v) => { sg.logo = v; ch(); }, 'إظهار الشعار'),
      h('div', { class: 'ad-imgrow' }, h('button', { type: 'button', class: 'btn', onclick: () => file.click() }, icon('download', { size: 15 }), sg.logoUrl ? 'غيّر الشعار' : 'ارفع شعار مخصص'), file,
        sg.logoUrl ? h('button', { type: 'button', class: 'btn', onclick: () => { sg.logoUrl = ''; ch(); paintAdSign(body); } }, '↺ شعار التطبيق') : h('small', { class: 'hint', text: 'الافتراضي: شعار التطبيق من «الهوية»' })),
      h('div', { class: 'row-2' }, adField('المكان', adSelect(sg.pos, [['bottom', 'تحت بالوسط'], ['br', 'تحت يمين'], ['bl', 'تحت يسار'], ['top', 'فوق بالوسط']], (v) => { sg.pos = v; ch(); })), adField('لون النص', col)),
      rng('size', 0.015, 0.05, 0.001, 'الحجم', (v) => `${Math.round(v * 1000) / 10}٪`),
      rng('op', 0.2, 1, 0.05, 'الوضوح', (v) => `${Math.round(v * 100)}٪`),
      adSwitch(!!sg.bar, (v) => { sg.bar = v; ch(); }, 'شريط خلف التوقيع', 'يوضّح التوقيع على الصور الفاتحة'),
      adSwitch(!!sg.paidHide, (v) => { sg.paidHide = v; ch(); }, 'السماح بإخفائه ★', 'لمن عنده ميزة «إخفاء توقيع NOBLE» — تحددها في التطبيقات ← الأقسام والاشتراكات (مجاني/اشتراك)'))));
  body.append(adWmCard(), adNewsCard());
  paint();
}

/* ================= مكتبة الوسائط: خلفيات (صور/فيديو) · خطوط · أصوات وأناشيد =================
 * كل شي يوصل للمستخدمين فوراً بعد الحفظ (بدون تحديث للتطبيق)، ويتحفظ على أجهزتهم بعد أول استخدام. */
const AD_MEDIA = {
  bg: { title: '🌄 الخلفيات', one: 'خلفية', accept: 'image/png,image/jpeg,image/webp,video/mp4,video/webm', max: 25, folder: 'b',
    hint: 'صور أو فيديوهات قصيرة (حتى 25MB) — تظهر للمستخدم في تبويب «الخلفية» داخل التصميم. تقدر تربط كل خلفية بصوت طبيعي يشتغل معها تلقائياً.' },
  font: { title: '🔤 الخطوط', one: 'خط', accept: '.woff2,.woff,.ttf,.otf', max: 6, folder: 'f',
    hint: 'ارفع ملف خط (woff2 أفضل وأخف، أو ttf / otf) — يظهر للمستخدم في اختيار خط كل نص. تأكد إن رخصة الخط تسمح بالاستخدام في التطبيقات.' },
  sound: { title: '🎵 الأصوات والأناشيد', one: 'صوت', accept: 'audio/mpeg,audio/mp4,audio/aac,audio/ogg,audio/wav,.mp3,.m4a,.aac,.ogg,.wav', max: 12, folder: 's',
    hint: 'أصوات طبيعية (مطر، بحر، طيور…) وأناشيد (حتى 12MB، mp3 أو m4a أفضل). تطلع للمستخدم في تبويب «الصوت» وتنضاف للفيديو، والحركة تتفاعل معها. ارفع فقط ما عندك حق استخدامه.' },
};
const SOUND_TYPES = [['nature', '🌿 طبيعي'], ['nasheed', '🎶 نشيد (بدون موسيقى)'], ['ambient', '✨ أجواء'], ['effect', '🔔 مؤثر']];
const adFmtSize = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)}MB` : `${Math.round(b / 1024)}KB`);
function paintAdMedia(body, kind) {
  const M = AD_MEDIA[kind];
  const list = adKind(kind);
  const card = (it) => {
    const d = it.data;
    let pv;
    if (kind === 'bg') pv = d.video ? h('video', { src: d.url, muted: '', loop: '', playsinline: '', autoplay: '', preload: 'metadata' }) : h('img', { src: d.url, alt: '', loading: 'lazy' });
    else if (kind === 'font') { pv = h('div', { class: 'ad-fontpv', text: d.sample || 'رمضان كريم Abc' }); DesignKit.registerFonts([{ id: it.id, url: d.url, title: d.title }]); DesignKit.ensureFont('f' + it.id).then(() => { pv.style.fontFamily = DesignKit.family('f' + it.id); }); }
    else { const a = h('audio', { src: d.url, preload: 'none' }); pv = h('button', { type: 'button', class: 'ad-play', onclick: (e) => { const b = e.currentTarget; document.querySelectorAll('.ad-play.on').forEach((x) => { if (x !== b) { x.classList.remove('on'); x._a?.pause(); } }); b._a = a; if (a.paused) { a.play(); b.classList.add('on'); } else { a.pause(); b.classList.remove('on'); } } }, '▶'); a.onended = () => pv.classList.remove('on'); }
    const meta = [kind === 'bg' ? (d.video ? '🎬 فيديو' : '🖼 صورة') : kind === 'sound' ? (SOUND_TYPES.find((x) => x[0] === d.type)?.[1] || '') : '',
      d.cat && d.cat !== 'all' ? adOccName(d.cat) : 'كل المناسبات', d.size ? adFmtSize(d.size) : '', kind === 'bg' && d.sound ? '🎵 ' + (adKind('sound').find((x) => String(x.id) === String(d.sound))?.data.title || 'صوت') : '', `استُخدم ${UI.n(it.uses || 0)}`].filter(Boolean).join(' · ');
    return h('div', { class: `ad-bi ad-media ad-m-${kind}${it.active ? '' : ' off'}` },
      h('div', { class: 'ad-media-pv' }, pv),
      h('b', { text: (d.premium ? '★ ' : '') + (d.title || M.one) }), h('small', { text: meta }),
      h('div', { class: 'ad-cal-a' },
        adSwitch(it.active, async (v) => { try { await Cloud.admin.designSave(it.id, null, null, v); it.active = v; paintAdMedia(body, kind); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }),
        h('button', { type: 'button', class: 'icon-btn', title: 'تعديل', onclick: () => editMedia(kind, it) }, icon('edit', { size: 15 })),
        h('button', { type: 'button', class: 'icon-btn danger', title: 'حذف', onclick: async () => { if (!confirm(`حذف «${d.title || M.one}» نهائياً؟`)) return; try { await Cloud.admin.designDelete(it.id); AD.items = AD.items.filter((x) => x.id !== it.id); renderDesignsAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, icon('trash', { size: 15 }))));
  };
  RC(body,
    h('p', { class: 'hint', text: M.hint }),
    h('div', { class: 'ad-row-a' }, h('button', { type: 'button', class: 'btn btn-primary', onclick: () => editMedia(kind, {}) }, icon('plus', { size: 15 }), `أضف ${M.one}`)),
    list.length ? h('div', { class: `ad-grid ad-grid-${kind}` }, ...list.map(card)) : h('div', { class: 'empty' }, h('b', { text: `ما فيه ${M.title.slice(2)} بعد` }), h('small', { text: `اضغط «أضف ${M.one}».` })));
}
function editMedia(kind, it) {
  const M = AD_MEDIA[kind];
  const d = adClone(it.data || { kind, title: '', cat: 'all', url: '', premium: false, ...(kind === 'sound' ? { type: 'nature', vol: 0.8 } : {}), ...(kind === 'bg' ? { video: false, dim: 0.15, sound: '', anim: '' } : {}), ...(kind === 'font' ? { sample: 'رمضان كريم' } : {}) });
  const pv = h('div', { class: 'ad-media-big' });
  const paintPv = () => {
    if (!d.url) return RC(pv, h('small', { class: 'hint', text: 'ارفع الملف لتشوف المعاينة' }));
    if (kind === 'bg') RC(pv, d.video ? h('video', { src: d.url, muted: '', loop: '', autoplay: '', playsinline: '', controls: '' }) : h('img', { src: d.url, alt: '' }));
    else if (kind === 'font') { const t = h('div', { class: 'ad-fontpv big', text: d.sample || 'رمضان كريم' }); RC(pv, t); const id = it.id || 'tmp' + Date.now(); DesignKit.registerFonts([{ id, url: d.url, title: d.title }]); DesignKit.ensureFont('f' + id).then((ok) => { if (ok) t.style.fontFamily = DesignKit.family('f' + id); else RC(pv, h('p', { class: 'note-box', text: 'تعذّر قراءة الخط — جرّب ملف woff2 أو ttf ثاني' })); }); }
    else RC(pv, h('audio', { src: d.url, controls: '', preload: 'metadata' }));
  };
  const file = h('input', { type: 'file', accept: M.accept, hidden: true });
  const up = h('button', { type: 'button', class: 'btn', onclick: () => file.click() }, icon('download', { size: 15 }), 'ارفع الملف');
  const url = adInput(d.url, (v) => { d.url = v.trim(); if (kind === 'bg') d.video = /\.(mp4|webm|mov)(\?|$)/i.test(d.url); paintPv(); }, { ltr: true, max: 600, ph: 'https://… أو ارفع' });
  file.addEventListener('change', async () => {
    const f = file.files[0]; if (!f) return;
    if (f.size > M.max * 1048576) return toast(`الملف أكبر من ${M.max}MB`, { type: 'error' });
    up.disabled = true; up.lastChild.textContent = 'جارٍ الرفع…';
    try {
      d.url = await Cloud.admin.designUpload(f, M.folder); d.size = f.size; url.value = d.url;
      if (kind === 'bg') d.video = /^video\//.test(f.type) || /\.(mp4|webm|mov)$/i.test(f.name);
      if (!d.title) { d.title = f.name.replace(/\.[^.]+$/, '').slice(0, 40); title.value = d.title; }
      if (kind === 'sound') { const a = new Audio(); a.preload = 'metadata'; a.src = d.url; a.onloadedmetadata = () => { d.dur = Math.round(a.duration || 0); }; }
      toast('رُفع ✓', { type: 'success' }); paintPv();
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    up.disabled = false; up.lastChild.textContent = 'ارفع الملف';
  });
  const title = adInput(d.title, (v) => (d.title = v), { max: 40 });
  const occ = [['all', '✨ كل المناسبات'], ...adCfg().occasions.map((o) => [o.id, `${o.ic} ${o.name}`])];
  const sounds = [['', 'بدون صوت'], ...adKind('sound').map((x) => [String(x.id), '🎵 ' + (x.data.title || 'صوت')])];
  const announce = { on: !it.id };
  const form = h('div', { class: 'ad-form' },
    pv,
    h('div', { class: 'row-2' }, adField('الاسم', title), adField('المناسبة', adSelect(d.cat || 'all', occ, (v) => (d.cat = v)))),
    adField('الملف', h('div', { class: 'ad-imgrow' }, url, up, file), `الحد ${M.max}MB`),
    kind === 'sound' ? h('div', { class: 'row-2' }, adField('النوع', adSelect(d.type || 'nature', SOUND_TYPES, (v) => (d.type = v))),
      adField(`مستوى الصوت الافتراضي — ${Math.round((d.vol ?? 0.8) * 100)}٪`, (() => { const r = h('input', { type: 'range', min: 0.1, max: 1, step: 0.05, value: d.vol ?? 0.8 }); r.addEventListener('input', () => { d.vol = Number(r.value); r.previousSibling.textContent = `مستوى الصوت الافتراضي — ${Math.round(d.vol * 100)}٪`; }); return r; })())) : null,
    kind === 'bg' ? h('div', { class: 'row-2' }, adField('صوت يشتغل معها تلقائياً', adSelect(d.sound || '', sounds, (v) => (d.sound = v)), 'المستخدم يقدر يغيّره أو يوقفه'),
      adField('حركة مقترحة للخلفية', adSelect(d.anim || '', [['', 'بدون'], ...Object.entries(MotionKit.BG).filter(([k]) => k !== 'none').map(([k, v]) => [k, v.name])], (v) => (d.anim = v)))) : null,
    kind === 'font' ? adField('نص المعاينة', adInput(d.sample, (v) => { d.sample = v; paintPv(); }, { max: 40 })) : null,
    adSwitch(!!d.premium, (v) => (d.premium = v), '★ للمشتركين', 'غير المشترك يجربه في التصميم، ولما يحفظ يطلع له الاشتراك'),
    !it.id ? adSwitch(true, (v) => (announce.on = v), '📣 أعلن عنه للمستخدمين', 'نافذة «جديد» تطلع لهم مرة وحدة عند فتح التطبيق') : null);
  paintPv();
  mkSheet(it.id ? `تعديل ${M.one}` : `${M.one} جديد`, [form], [
    h('button', { type: 'button', class: 'btn', onclick: () => closeSheet($('#mk-sheet')) }, 'إلغاء'),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      if (!d.url) return toast('ارفع الملف أول');
      if (!/^https:\/\//.test(d.url) && !/^data:/.test(d.url)) return toast('الرابط لازم يبدأ بـ https');
      d.kind = kind;
      try {
        const id = await Cloud.admin.designSave(it.id || null, d);
        if (announce.on && !it.id) {
          AD.meta.news = { id: 'n' + Date.now().toString(36), kind, ref: id, title: `جديد في التصاميم: ${d.title || M.one}`, text: kind === 'bg' ? 'خلفية جديدة جاهزة لتصاميمك ✨' : kind === 'font' ? 'خط جديد تقدر تكتب فيه تصاميمك ✍️' : 'صوت جديد تضيفه لتصاميمك المتحركة 🎵', image: kind === 'bg' && !d.video ? d.url : '', mode: 'popup', at: Date.now() };
          await Cloud.admin.designMeta(AD.meta);
        }
        toast('حُفظ ✓ — وصل للمستخدمين الحين', { type: 'success' }); closeSheet($('#mk-sheet'));
        AD.items = await Cloud.admin.designs(); renderDesignsAdmin();
      } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    } }, 'احفظ')]);
}

/* ================= الحركة والفيديو: مين مجاني ومين مدفوع + سياسة «جرّب ثم اشترك» ================= */
const MOTION_DEF = { on: true, video: 'free', freeMax: 8, hq: 'pro', policy: 'try', freeCopy: true, sound: 'free', access: {} };
function adMotion() { AD.meta.motion = { ...MOTION_DEF, ...(AD.meta.motion || {}), access: { ...((AD.meta.motion || {}).access || {}) } }; return AD.meta.motion; }
function paintAdMotion(body) {
  const m = adMotion();
  const def = (prefix, k, v) => m.access[prefix + k] || (v.pro ? 'pro' : 'free');
  const ACC = [['free', 'مجاني'], ['pro', '★ مدفوع'], ['off', 'مخفي']];
  const table = (title, map, prefix) => h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: title }),
    h('div', { class: 'ad-acc' }, ...Object.entries(map).filter(([k]) => k !== 'none').map(([k, v]) => h('label', { class: 'ad-acc-r' }, h('span', { text: v.name }),
      adSelect(def(prefix, k, v), ACC, (val) => { m.access[prefix + k] = val; adChanged(); })))));
  RC(body,
    h('p', { class: 'hint', text: 'المستخدم يختار «صورة ثابتة» أو «متحرك — فيديو». المدفوع يجربه عادي في المعاينة، ولما يحفظ أو يشارك يطلع له «اشترك» مع خيار «احفظ نسخة مجانية». احفظ الإعدادات بعد التعديل.' }),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '⚙️ عام' }),
      adSwitch(m.on, (v) => { m.on = v; adChanged(); }, 'التصاميم المتحركة', 'عند الإيقاف يختفي خيار «متحرك»'),
      h('div', { class: 'row-2' },
        adField('حفظ الفيديو', adSelect(m.video, [['free', 'مجاني للكل'], ['pro', '★ للمشتركين']], (v) => { m.video = v; adChanged(); })),
        adField('الصوت داخل الفيديو', adSelect(m.sound, [['free', 'مجاني'], ['pro', '★ للمشتركين']], (v) => { m.sound = v; adChanged(); }))),
      h('div', { class: 'row-2' },
        adField('أقصى مدة مجانية', adSelect(String(m.freeMax), [['5', '٥ ثواني'], ['8', '٨ ثواني'], ['12', '١٢ ثانية'], ['15', '١٥ ثانية']], (v) => { m.freeMax = Number(v); adChanged(); })),
        adField('جودة 1080p', adSelect(m.hq, [['free', 'مجانية'], ['pro', '★ للمشتركين']], (v) => { m.hq = v; adChanged(); }))),
      adField('المميزات المدفوعة عند غير المشترك', adSelect(m.policy, [['try', 'يجرّبها — والاشتراك عند الحفظ (مستحسن)'], ['lock', 'مقفلة — ما يقدر يجربها']], (v) => { m.policy = v; adChanged(); }), 'تنطبق على كل مميزات التصاميم: القوالب ★، الخلفيات والخطوط والأصوات ★، الفلاتر والإطارات، إخفاء التوقيع.'),
      adSwitch(m.freeCopy !== false, (v) => { m.freeCopy = v; adChanged(); }, 'زر «احفظ نسخة مجانية»', 'نبدّل المميزات المدفوعة بأقرب بديل مجاني')),
    table('✍️ حركات النص', MotionKit.TEXT, 't:'), table('🌌 حركات الخلفية', MotionKit.BG, 'b:'), table('✒️ حركات المخطوطة', MotionKit.LAYER, 'l:'));
}

/* ================= الشعار المائي + نافذة «جديد» (تُضاف لتبويب التوقيع) ================= */
function adWmCard() {
  const wm = (AD.meta.wm = { ...DesignKit.WM, ...(AD.meta.wm || {}) });
  const prev = h('canvas', { class: 'ad-prev ad-prev-sm' });
  const logoSrc = () => wm.logoUrl || (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png');
  const paint = () => DesignKit.render(DesignKit.BUILTIN.find((b) => b.id === 'b-fri') || DesignKit.BUILTIN[0], {}, { width: 360, canvas: prev, sign: null, wm: wm.on ? { ...wm, logoSrc: logoSrc() } : null }).catch(() => {});
  const ch = () => { adChanged(); paint(); };
  const file = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml', hidden: true });
  file.addEventListener('change', async () => { const f = file.files[0]; if (!f) return; try { wm.logoUrl = await Cloud.admin.designUpload(f, 'w'); toast('رُفع ✓', { type: 'success' }); ch(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
  const rng = (key, min, max, step, label, fmt) => { const r = h('input', { type: 'range', min, max, step, value: wm[key] }); const lb = h('span', { text: `${label} — ${fmt(wm[key])}` }); r.addEventListener('input', () => { wm[key] = Number(r.value); lb.textContent = `${label} — ${fmt(wm[key])}`; ch(); }); return h('label', { class: 'field' }, lb, r); };
  setTimeout(paint, 30);
  return h('div', { class: 'set-card ga-card ad-wm' }, h('strong', { class: 'ga-ct', text: '💧 الشعار المائي الشفاف (حقوق العمل)' }),
    h('div', { class: 'ad-wm-g' }, prev, h('div', { class: 'ad-form' },
      adSwitch(wm.on, (v) => { wm.on = v; ch(); }, 'إظهار الشعار المائي'),
      adField('يظهر على', adSelect(wm.scope, [['azkar', 'تصاميم الأذكار فقط'], ['all', 'كل التصاميم']], (v) => { wm.scope = v; ch(); })),
      adField('المكان', adSelect(wm.pos, [['center', 'بالوسط'], ['tr', 'فوق يمين'], ['tl', 'فوق يسار'], ['br', 'تحت يمين'], ['bl', 'تحت يسار']], (v) => { wm.pos = v; ch(); })),
      rng('size', 0.08, 0.9, 0.01, 'الحجم', (v) => `${Math.round(v * 100)}٪`),
      rng('op', 0.03, 0.6, 0.01, 'الشفافية', (v) => `${Math.round(v * 100)}٪`),
      h('div', { class: 'ad-imgrow' }, h('button', { type: 'button', class: 'btn', onclick: () => file.click() }, icon('download', { size: 15 }), wm.logoUrl ? 'غيّر الشعار' : 'ارفع شعار (PNG شفاف)'), file,
        wm.logoUrl ? h('button', { type: 'button', class: 'btn', onclick: () => { wm.logoUrl = ''; ch(); } }, '↺ شعار التطبيق') : null),
      adSwitch(!!wm.paidHide, (v) => { wm.paidHide = v; ch(); }, 'المشترك يقدر يخفيه ★'))));
}
function adNewsCard() {
  const n = AD.meta.news;
  return h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '📣 نافذة «جديد» للمستخدمين' }),
    h('p', { class: 'hint', text: 'تطلع مرة وحدة لكل مستخدم عند فتح التطبيق — تنضاف تلقائياً لما ترفع خلفية أو خط أو صوت مع «أعلن عنه»، وتقدر تعدّلها أو توقفها هنا.' }),
    n ? h('div', { class: 'ad-form' },
      adField('العنوان', adInput(n.title, (v) => { n.title = v; adChanged(); }, { max: 60 })),
      adField('النص', adInput(n.text, (v) => { n.text = v; adChanged(); }, { max: 140 })),
      adField('طريقة الظهور', adSelect(n.mode || 'popup', [['popup', 'نافذة منبثقة'], ['banner', 'شريط أعلى قسم التصاميم'], ['off', 'متوقفة']], (v) => { n.mode = v; adChanged(); })),
      h('button', { type: 'button', class: 'btn', onclick: () => { n.id = 'n' + Date.now().toString(36); adChanged(); toast('بتطلع للجميع مرة ثانية بعد الحفظ', { type: 'success' }); } }, '🔁 اعرضها للجميع من جديد'))
      : h('div', { class: 'ad-row-a' }, h('small', { class: 'hint', text: 'ما فيه إعلان حالياً.' }), h('button', { type: 'button', class: 'btn', onclick: () => { AD.meta.news = { id: 'n' + Date.now().toString(36), title: 'جديد في التصاميم ✨', text: 'أضفنا تصاميم جديدة — جرّبها الحين', mode: 'popup', at: Date.now() }; adChanged(); renderDesignsAdmin(); } }, '+ إعلان جديد')));
}
