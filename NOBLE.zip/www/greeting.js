/* NOBLE — «💌 بطاقة تهنئة بخطوات» (1.17)
 * معالج سريع داخل قسم التصاميم: المناسبة ← المخطوطة ← الخلفية ← الزخرفة ← الكتابة ← الألوان ← جاهزة
 * المخطوطات والخلفيات من مكتبة الإدارة (PNG شفاف / صور)، ولو ما فيه شي نرسم مخطوطة بخط المصحف وخلفيات NOBLE.
 */
'use strict';
const GR = { s: null, imgs: new Map(), logo: null, logoSrc: '' };

/* عبارات المخطوطة الافتراضية لكل مناسبة (بالتشكيل) */
const GR_CAL = {
  ramadan: [['رَمَضَانُ', 'كَرِيمٌ'], ['مُبَارَكٌ', 'عَلَيْكُمُ الشَّهْرُ'], ['أَهْلًا', 'رَمَضَان']],
  eidf: [['عِيدٌ', 'سَعِيدٌ'], ['عِيدُكُمْ', 'مُبَارَكٌ'], ['تَقَبَّلَ اللهُ', 'مِنَّا وَمِنْكُمْ']],
  eida: [['عِيدُ أَضْحَى', 'مُبَارَكٌ'], ['عِيدٌ', 'سَعِيدٌ'], ['تَقَبَّلَ اللهُ', 'طَاعَاتِكُمْ']],
  hijri: [['عَامٌ', 'هِجْرِيٌّ سَعِيدٌ'], ['كُلُّ عَامٍ', 'وَأَنْتُمْ بِخَيْرٍ']],
  national: [['يَوْمٌ', 'وَطَنِيٌّ سَعِيدٌ'], ['دَامَ عِزُّكَ', 'يَا وَطَن']],
  friday: [['جُمُعَةٌ', 'مُبَارَكَةٌ'], ['اللَّهُمَّ صَلِّ', 'عَلَى مُحَمَّدٍ']],
  hajj: [['حَجٌّ مَبْرُورٌ', 'وَذَنْبٌ مَغْفُورٌ'], ['لَبَّيْكَ', 'اللَّهُمَّ لَبَّيْكَ']],
  wedding: [['بَارَكَ اللهُ', 'لَكُمَا'], ['أَلْفُ', 'مَبْرُوكٍ']],
  grad: [['أَلْفُ', 'مَبْرُوكٍ'], ['تَخَرُّجٌ', 'مُبَارَكٌ']],
  baby: [['مَا شَاءَ اللهُ', 'تَبَارَكَ اللهُ'], ['بُورِكَ لَكُمْ', 'فِي الْمَوْهُوبِ']],
  getwell: [['سَلَامَتَكَ', 'مَا تَشُوفُ شَرًّا'], ['طَهُورٌ', 'إِنْ شَاءَ اللهُ']],
  thanks: [['شُكْرًا', 'مِنَ الْقَلْبِ'], ['جَزَاكَ اللهُ', 'خَيْرًا']],
  general: [['أَلْفُ', 'مَبْرُوكٍ'], ['كُلُّ عَامٍ', 'وَأَنْتُمْ بِخَيْرٍ']],
};
const GR_BGS = [['night', 'ليل وهلال'], ['emerald', 'زمرّدي'], ['gold', 'ذهبي'], ['dusk', 'غروب'], ['marble', 'رخامي'], ['brand', 'NOBLE'], ['arches', 'أقواس'], ['lantern', 'فوانيس']];
const GR_FRM = [['none', 'بدون'], ['mihrab', 'محراب'], ['onion', 'قبة'], ['lobed', 'مفصّص'], ['round', 'قوس'], ['lamp', 'فانوس'], ['star', 'نجمة'], ['double', 'مزدوج']];
const GR_COL = [['white', '#FFFFFF', 'أبيض'], ['gold', 'grad:#FFF2C2,#E6B450,#9C6B1E', 'ذهبي'], ['mint', '#BFF5E2', 'نعناعي'], ['brand', 'grad:#FFB43D,#FF4D9D,#8B45F0', 'NOBLE'], ['rose', '#FFD1DC', 'وردي'], ['ink', '#1A1F33', 'داكن']];
const GR_FONTS = [['QHafs', 'مصحفي'], ['QAmiri', 'أميري'], ['NobleUI', 'عصري']];
const GR_SIZES = { post: [1080, 1350, '٤:٥'], story: [1080, 1920, 'ستوري'], sq: [1080, 1080, 'مربع'] };
const GR_STEPS = [['occ', 'المناسبة', 'وش المناسبة؟', 'نقترح لك المخطوطات والعبارات المناسبة'], ['cal', 'المخطوطة', 'اختر شكل المخطوطة', 'من مكتبة مخطوطات NOBLE'], ['bg', 'الخلفية', 'اختر الخلفية', 'أو ارفع صورتك أنت'], ['frm', 'الزخرفة', 'اختر شكل أو زخرفة', 'إطار يحتضن المخطوطة'], ['txt', 'الكتابة', 'أضف كلمتك', 'نص خاص + اسمك'], ['col', 'الألوان', 'خيارات التلوين', 'لون المخطوطة والإطار والإضاءة'], ['done', 'جاهزة', 'بطاقتك جاهزة 🎉', 'شاركها أو احفظها']];

const grOccs = () => dsCfg().occasions.filter((o) => o.id !== 'azkar');
const grTexts = (occ) => { const t = dsCfg().texts; return (t[occ] && t[occ].length ? t[occ] : t.general || ['كل عام وأنتم بخير']).slice(0, 5); };
/* المخطوطات: المرفوعة من الإدارة لهالمناسبة أولاً، بعدها المكتوبة */
function grCals(occ) {
  const up = dsCallig().filter((c) => !c.cat || c.cat === occ).map((c) => ({ img: c.image, premium: !!c.premium, title: c.title || '', id: c.id || c.image }));
  const o = dsOcc(occ);
  const txt = (GR_CAL[occ] || (o ? [[o.name, '']] : GR_CAL.general)).map((l) => ({ lines: l }));
  return up.concat(txt);
}
const grBgImgs = () => dsBgs().filter((b) => !DesignKit.isVideo(b)).map((b) => ({ id: 'lib:' + (b.id || b.url), url: b.url, premium: !!b.premium, title: b.title || '' }));
const grColSpec = (k) => (GR_COL.find((x) => x[0] === k) || GR_COL[0])[1];
function grFill(c, spec, x, y, w, hh) { if (!spec.startsWith('grad:')) return spec; const cs = spec.slice(5).split(','); const g = c.createLinearGradient(x, y, x, y + hh); cs.forEach((k, i) => g.addColorStop(i / (cs.length - 1), k)); return g; }
function grRnd(seed) { let s = seed; return () => (s = (s * 9301 + 49297) % 233280) / 233280; }

/* الصور: تحميل مرة وحدة ثم رسم من الذاكرة */
function grImg(url) {
  if (!url) return null;
  const e = GR.imgs.get(url);
  if (e) return e.im || null;
  const rec = { im: null }; GR.imgs.set(url, rec);
  DesignKit.loadImg(url).then((im) => { rec.im = im; grRedraw(); }).catch(() => { rec.err = true; });
  return null;
}
async function grImgWait(url) { if (!url) return null; try { const im = await DesignKit.loadImg(url); GR.imgs.set(url, { im }); return im; } catch { return null; } }

/* ---------- الرسم ---------- */
function grPattern(c, W, H, col, s) { c.strokeStyle = col; c.lineWidth = 2; for (let y = -s; y < H + s; y += s) for (let x = -s; x < W + s; x += s) { const cx = x + ((y / s) % 2 ? s / 2 : 0); c.save(); c.translate(cx, y); for (let k = 0; k < 2; k++) { c.rotate(Math.PI / 4 * k); c.strokeRect(-s * 0.3, -s * 0.3, s * 0.6, s * 0.6); } c.restore(); } }
function grSkyline(c, W, H) {
  c.beginPath(); c.moveTo(0, H); c.lineTo(0, H * 0.8);
  const dome = (x, w, hh) => { c.lineTo(x - w, H * 0.8); c.quadraticCurveTo(x - w, H * 0.8 - hh, x, H * 0.8 - hh * 1.25); c.quadraticCurveTo(x + w, H * 0.8 - hh, x + w, H * 0.8); };
  c.lineTo(W * 0.12, H * 0.8); c.lineTo(W * 0.12, H * 0.62); c.lineTo(W * 0.14, H * 0.58); c.lineTo(W * 0.16, H * 0.62); c.lineTo(W * 0.16, H * 0.8);
  dome(W * 0.38, W * 0.14, H * 0.1); dome(W * 0.62, W * 0.09, H * 0.07);
  c.lineTo(W * 0.84, H * 0.8); c.lineTo(W * 0.84, H * 0.6); c.lineTo(W * 0.86, H * 0.56); c.lineTo(W * 0.88, H * 0.6); c.lineTo(W * 0.88, H * 0.8); c.lineTo(W, H * 0.8); c.lineTo(W, H); c.fill();
}
function grLantern(c, x, y, r) { c.save(); c.fillStyle = 'rgba(255,200,110,.9)'; c.shadowColor = '#FFC870'; c.shadowBlur = 30; c.beginPath(); c.moveTo(x - r * 0.6, y); c.lineTo(x + r * 0.6, y); c.lineTo(x + r, y + r * 1.2); c.lineTo(x + r * 0.7, y + r * 2.6); c.lineTo(x - r * 0.7, y + r * 2.6); c.lineTo(x - r, y + r * 1.2); c.closePath(); c.fill(); c.restore(); }
function grArch(c, x, y, w, hh, k) {
  const cx = x + w / 2, sh = hh * 0.38; c.beginPath();
  if (k === 'mihrab') { c.moveTo(x, y + hh); c.lineTo(x, y + sh); c.quadraticCurveTo(x, y + sh * 0.25, cx, y); c.quadraticCurveTo(x + w, y + sh * 0.25, x + w, y + sh); c.lineTo(x + w, y + hh); }
  else if (k === 'onion') { c.moveTo(x, y + hh); c.lineTo(x, y + sh * 1.1); c.bezierCurveTo(x, y + sh * 0.55, cx - w * 0.42, y + sh * 0.5, cx - w * 0.1, y + sh * 0.2); c.quadraticCurveTo(cx, y + sh * 0.05, cx, y - hh * 0.03); c.quadraticCurveTo(cx, y + sh * 0.05, cx + w * 0.1, y + sh * 0.2); c.bezierCurveTo(cx + w * 0.42, y + sh * 0.5, x + w, y + sh * 0.55, x + w, y + sh * 1.1); c.lineTo(x + w, y + hh); }
  else if (k === 'lobed') { c.moveTo(x, y + hh); c.lineTo(x, y + sh); const n = 5, r = w / (n * 2) * 1.05; for (let i = 0; i < n; i++) { const t = i / (n - 1), px = x + w * (i + 0.5) / n, py = y + sh * (1 - Math.sin(t * Math.PI) * 0.9); c.arc(px, py, r, Math.PI, 0, false); } c.lineTo(x + w, y + hh); }
  else if (k === 'round') { c.moveTo(x, y + hh); c.lineTo(x, y + w / 2); c.arc(cx, y + w / 2, w / 2, Math.PI, 0); c.lineTo(x + w, y + hh); }
  else if (k === 'lamp') { const nk = w * 0.18; c.moveTo(x + w * 0.15, y + hh); c.lineTo(x, y + hh * 0.78); c.lineTo(x, y + sh * 1.1); c.lineTo(cx - nk, y + sh * 0.45); c.lineTo(cx - nk, y + sh * 0.2); c.quadraticCurveTo(cx, y - hh * 0.04, cx + nk, y + sh * 0.2); c.lineTo(cx + nk, y + sh * 0.45); c.lineTo(x + w, y + sh * 1.1); c.lineTo(x + w, y + hh * 0.78); c.lineTo(x + w * 0.85, y + hh); }
  else if (k === 'star') { const R = Math.min(w, hh) / 2, cy = y + hh / 2; for (let i = 0; i < 16; i++) { const a = -Math.PI / 2 + i * Math.PI / 8, rr = i % 2 ? R * 0.86 : R; c.lineTo(cx + Math.cos(a) * rr, cy + Math.sin(a) * rr); } }
  c.closePath();
}
function grCover(c, im, W, H) { const r = Math.max(W / im.width, H / im.height); c.drawImage(im, (W - im.width * r) / 2, (H - im.height * r) / 2, im.width * r, im.height * r); }
function grBg(c, W, H, o) {
  const k = o.bg;
  const g = (a, d = 'v') => { const gr = d === 'v' ? c.createLinearGradient(0, 0, 0, H) : c.createRadialGradient(W / 2, H * 0.35, 0, W / 2, H * 0.35, H * 0.8); a.forEach((col, i) => gr.addColorStop(i / (a.length - 1), col)); c.fillStyle = gr; c.fillRect(0, 0, W, H); };
  const R = grRnd(7);
  if (k === 'photo' || k.startsWith('lib:')) {
    const im = k === 'photo' ? o.photo : grImg((grBgImgs().find((b) => b.id === k) || {}).url);
    if (im) { grCover(c, im, W, H); return; }
    g(['#0B1030', '#1B2350']); return;
  }
  if (k === 'night') { g(['#030A2A', '#0B1F5C', '#1C2F7A']); for (let i = 0; i < 160; i++) { c.fillStyle = `rgba(255,255,255,${R() * 0.8})`; c.beginPath(); c.arc(R() * W, R() * H * 0.8, R() * 2.4, 0, 7); c.fill(); }
    c.fillStyle = '#FFF4C8'; c.shadowColor = '#FFE9A0'; c.shadowBlur = 60; c.beginPath(); c.arc(W * 0.78, H * 0.14, W * 0.08, 0, 7); c.fill(); c.shadowBlur = 0; c.fillStyle = '#0B1F5C'; c.beginPath(); c.arc(W * 0.81, H * 0.125, W * 0.072, 0, 7); c.fill(); }
  if (k === 'emerald') { g(['#03251C', '#065A43', '#0B8A66'], 'r'); grPattern(c, W, H, 'rgba(255,255,255,.07)', 120); }
  if (k === 'gold') { g(['#120A02', '#2A1A06', '#0A0602']); for (let i = 0; i < 70; i++) { const x = R() * W, y = R() * H, r = 10 + R() * 70; const gr = c.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, `rgba(255,205,110,${0.15 + R() * 0.35})`); gr.addColorStop(1, 'rgba(255,205,110,0)'); c.fillStyle = gr; c.fillRect(x - r, y - r, r * 2, r * 2); } }
  if (k === 'dusk') { g(['#2B1055', '#7A2A6E', '#E36A4A', '#F5B067']); c.fillStyle = 'rgba(20,6,30,.92)'; grSkyline(c, W, H); }
  if (k === 'marble') { g(['#F7F1E6', '#EADFC9']); grPattern(c, W, H, 'rgba(150,110,50,.13)', 140); }
  if (k === 'brand') { c.fillStyle = '#0A0820'; c.fillRect(0, 0, W, H); [['#FF4D9D', 0.2, 0.2], ['#8B45F0', 0.85, 0.35], ['#56C8FF', 0.3, 0.85], ['#FFB43D', 0.8, 0.9]].forEach(([col, x, y]) => { const gr = c.createRadialGradient(W * x, H * y, 0, W * x, H * y, W * 0.7); gr.addColorStop(0, col + 'AA'); gr.addColorStop(1, col + '00'); c.fillStyle = gr; c.fillRect(0, 0, W, H); }); }
  if (k === 'arches') { g(['#14203D', '#0A1226']); c.strokeStyle = 'rgba(255,255,255,.08)'; c.lineWidth = 3; for (let i = -1; i < 6; i++) { const w = W / 4; grArch(c, i * w + w * 0.1, H * 0.45, w * 0.8, H * 0.6, 'mihrab'); c.stroke(); } }
  if (k === 'lantern') { g(['#1A0B2E', '#3B1650', '#5A1F55']); for (let i = 0; i < 7; i++) { const x = W * (0.08 + i * 0.14), len = H * (0.08 + R() * 0.18); c.strokeStyle = 'rgba(255,215,140,.5)'; c.lineWidth = 2; c.beginPath(); c.moveTo(x, 0); c.lineTo(x, len); c.stroke(); grLantern(c, x, len, W * 0.035); } }
}
const grLight = (o) => o.bg === 'marble';
function grStar4(c, x, y, r) { c.beginPath(); c.moveTo(x, y - r); c.quadraticCurveTo(x, y, x + r, y); c.quadraticCurveTo(x, y, x, y + r); c.quadraticCurveTo(x, y, x - r, y); c.quadraticCurveTo(x, y, x, y - r); c.fill(); }
function grWrap(c, t, x, y, mw, lh) { const words = String(t).split(' '); let line = '', yy = y; words.forEach((w) => { const tl = line ? line + ' ' + w : w; if (c.measureText(tl).width > mw && line) { c.fillText(line, x, yy); line = w; yy += lh; } else line = tl; }); c.fillText(line, x, yy); }
/* مخطوطة مرفوعة (PNG) ملوّنة باللون المختار */
function grTint(im, fill, w, hh) {
  const t = document.createElement('canvas'); t.width = Math.max(1, Math.round(w)); t.height = Math.max(1, Math.round(hh));
  const c = t.getContext('2d'); c.drawImage(im, 0, 0, t.width, t.height);
  c.globalCompositeOperation = 'source-in'; c.fillStyle = typeof fill === 'string' ? fill : fill; c.fillRect(0, 0, t.width, t.height);
  return t;
}
function grDraw(cv, o, opt = {}) {
  const [W, H] = GR_SIZES[opt.size || o.size] || GR_SIZES.post;
  if (cv.width !== W || cv.height !== H) { cv.width = W; cv.height = H; }
  const c = cv.getContext('2d'); c.clearRect(0, 0, W, H); c.save();
  grBg(c, W, H, o); c.shadowBlur = 0;
  if (!grLight(o) && o.dim) { c.fillStyle = `rgba(0,0,0,${o.dim / 100})`; c.fillRect(0, 0, W, H); }
  // الإطار
  const fw = W * 0.52, fh = Math.min(H * 0.58, fw * 1.55), fx = (W - fw) / 2, fy = H * 0.5 - fh * 0.52;
  if (o.frm !== 'none') {
    const fc = grFill(c, grColSpec(o.frmCol), fx, fy, fw, fh); c.save(); c.strokeStyle = fc; c.lineWidth = W * 0.005;
    if (o.glow) { c.shadowColor = 'rgba(255,230,170,.6)'; c.shadowBlur = 20; }
    grArch(c, fx, fy, fw, fh, o.frm === 'double' ? 'mihrab' : o.frm); c.stroke();
    if (o.frm === 'double') { grArch(c, fx + W * 0.022, fy + W * 0.03, fw - W * 0.044, fh - W * 0.044, 'mihrab'); c.lineWidth = W * 0.0025; c.stroke(); }
    c.restore();
  }
  // المخطوطة
  const cals = grCals(o.occ), cal = cals[o.cal % cals.length] || cals[0];
  const fs = W * 0.13 * o.ttlSize, cy = H * 0.5 - fs * 0.3;
  const cf = grFill(c, grColSpec(o.col), 0, cy - fs, W, fs * 2.4);
  c.save();
  if (o.glow) { c.shadowColor = o.col === 'ink' ? 'rgba(255,255,255,.5)' : 'rgba(255,240,200,.55)'; c.shadowBlur = 28; }
  if (cal?.img) {
    const im = opt.imgs?.get(cal.img) || grImg(cal.img);
    if (im) { const mw = W * 0.62 * o.ttlSize, mh = H * 0.32 * o.ttlSize, r = Math.min(mw / im.width, mh / im.height), w = im.width * r, hh = im.height * r;
      const tg = c.createLinearGradient(0, 0, 0, hh); if (typeof cf !== 'string') { grColSpec(o.col).slice(5).split(',').forEach((k, i, a) => tg.addColorStop(i / (a.length - 1), k)); }
      c.drawImage(o.tint === false ? im : grTint(im, typeof cf === 'string' ? cf : tg, w, hh), (W - w) / 2, cy + fs * 0.35 - hh / 2, w, hh); }
  } else if (cal?.lines) {
    c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'rtl'; c.fillStyle = cf;
    c.font = `${fs}px QHafs, QAmiri, serif`; c.fillText(cal.lines[0], W / 2, cy);
    if (cal.lines[1]) { c.font = `${fs * 0.62}px QHafs, QAmiri, serif`; c.fillText(cal.lines[1], W / 2 + fs * 0.2, cy + fs * 1.05); }
  }
  c.restore();
  if (o.stars) { c.save(); c.fillStyle = typeof cf === 'string' ? cf : '#F2D184'; [[0.3, -0.9, 1], [0.72, -0.55, 0.7], [0.25, 0.9, 0.6], [0.68, 1.25, 1.1], [0.5, -1.6, 0.8]].forEach(([px, py, s]) => grStar4(c, W * px, cy + fs * py, fs * 0.09 * s)); c.restore(); }
  // النص الخاص + «من»
  if (o.txt && !opt.thumb) { c.save(); c.textAlign = 'center'; c.direction = 'rtl'; c.fillStyle = o.col === 'ink' || grLight(o) ? '#1A1F33' : '#fff'; c.font = `700 ${W * 0.042}px ${o.font}, NobleUI, sans-serif`; if (!grLight(o)) { c.shadowColor = 'rgba(0,0,0,.5)'; c.shadowBlur = 12; }
    grWrap(c, o.txt, W / 2, Math.min(fy + fh + W * 0.07, H - W * 0.2), W * 0.8, W * 0.056); c.restore(); }
  if (o.from && !opt.thumb) { c.save(); c.textAlign = 'center'; c.direction = 'rtl'; c.fillStyle = grLight(o) ? 'rgba(30,25,15,.7)' : 'rgba(255,255,255,.85)'; c.font = `${W * 0.032}px NobleUI, sans-serif`; c.fillText('— ' + o.from, W / 2, H - W * 0.12); c.restore(); }
  // التوقيع (الإدارة تتحكم فيه)
  const sg = opt.thumb ? null : dsSign(false);
  if (sg) {
    let logo = null;
    if (sg.logo !== false && sg.logoSrc) { logo = opt.logo !== undefined ? opt.logo : grImg(sg.logoSrc); }
    DesignKit.drawSign(c, W, H, grLight(o) ? { ...sg, color: '#3a2a10' } : sg, logo);
  }
  c.restore();
}

/* ---------- الواجهة ---------- */
function grDefaults(occ) {
  return { i: 0, occ, cal: 0, bg: occ === 'ramadan' || occ === 'friday' ? 'night' : occ === 'eidf' || occ === 'eida' ? 'gold' : 'emerald', frm: 'mihrab', col: 'gold', frmCol: 'gold', txt: '', from: '', font: 'NobleUI', glow: true, stars: true, dim: 20, ttlSize: 1, size: 'post', photo: null };
}
function openGreeting(occ0) {
  const seas = typeof dsSeasonal === 'function' ? dsSeasonal() : [];
  const occs = grOccs();
  const occ = occ0 || seas.find((s) => occs.some((o) => o.id === s)) || (occs[0] || {}).id || 'general';
  GR.s = grDefaults(occ);
  if (document.fonts?.load) Promise.all(['QHafs', 'QAmiri', 'NobleUI'].map((f) => document.fonts.load(`40px ${f}`, 'رمضان').catch(() => null))).then(grRedraw);
  openScreen((el) => {
    el.classList.add('gr-scr');
    el.append(h('div', { class: 'gr-wiz' },
      h('div', { class: 'gr-hd' },
        h('button', { type: 'button', class: 'gr-bk', 'aria-label': 'رجوع', onclick: () => grBack() }, '›'),
        h('h1', { text: 'بطاقة التهنئة' }),
        h('button', { type: 'button', class: 'gr-rnd', onclick: grSurprise }, '🎲 فاجئني')),
      h('div', { class: 'gr-steps' }), h('div', { class: 'gr-q' }),
      h('div', { class: 'gr-pv' }, h('canvas', { class: 'gr-cv' }), h('div', { class: 'gr-sz' })),
      h('div', { class: 'gr-body' }),
      h('div', { class: 'gr-foot' },
        h('button', { type: 'button', class: 'gr-prev', onclick: () => grStep(GR.s.i - 1) }, '›'),
        h('button', { type: 'button', class: 'gr-go', onclick: () => grStep(GR.s.i + 1) }))));
    grRender();
  }, { onBack: () => grBack(), cleanup: () => { window.removeEventListener('resize', grFit); GR.s = null; } });
  window.addEventListener('resize', grFit);
  Sync?.event?.('greeting', { step: 'open', occ });
}
const grQ = (s) => GR_ROOT()?.querySelector(s);
const GR_ROOT = () => document.querySelector('.gr-wiz');
function grBack() { if (!GR.s) return closeScreen(); if (GR.s.i > 0) return grStep(GR.s.i - 1); closeScreen(); if (S.tab === 'designs') renderDesigns(); }
function grStep(i) { if (!GR.s) return; if (i >= GR_STEPS.length) { toast('تم 🤍', { type: 'success' }); closeScreen(); if (S.tab === 'designs') renderDesigns(); return; } GR.s.i = Math.max(0, i); grRender(); grQ('.gr-body')?.scrollTo?.({ top: 0 }); }
function grRedraw() { const cv = grQ('.gr-cv'); if (cv && GR.s) grDraw(cv, GR.s); }
function grFit() {
  const pv = grQ('.gr-pv'), root = GR_ROOT(); if (!pv || !root || !GR.s) return;
  const [W, H] = GR_SIZES[GR.s.size];
  const avail = root.clientHeight * 0.44;
  let hh = Math.max(200, avail), w = hh * W / H; const mw = root.clientWidth - 32;
  if (w > mw) { w = mw; hh = w * H / W; }
  pv.style.width = w + 'px'; pv.style.height = hh + 'px';
}
function grThumb(o, lbl, on, click, premium) {
  const cv = h('canvas', { width: 220, height: 220 });
  const b = h('button', { type: 'button', class: 'gr-th' + (on ? ' on' : ''), onclick: click }, cv, lbl ? h('span', { class: 'lb', text: lbl }) : null, premium ? h('i', { class: 'pr', text: '★' }) : null);
  requestAnimationFrame(() => { const big = document.createElement('canvas'); grDraw(big, o, { size: 'sq', thumb: true }); cv.getContext('2d').drawImage(big, 0, 0, 220, 220); });
  return b;
}
const grSet = (patch, redrawOnly) => { Object.assign(GR.s, patch); if (redrawOnly) grRedraw(); else grRender(); };
function grRender() {
  const s = GR.s, root = GR_ROOT(); if (!s || !root) return;
  const [k, , q, sub] = GR_STEPS[s.i];
  RC(grQ('.gr-steps'), ...GR_STEPS.map(([, nn], i) => h('button', { type: 'button', class: i === s.i ? 'on' : i < s.i ? 'done' : '', onclick: () => grStep(i) }, h('i'), nn)));
  RC(grQ('.gr-q'), q, h('small', { text: sub }));
  RC(grQ('.gr-sz'), ...Object.entries(GR_SIZES).map(([k2, v]) => h('button', { type: 'button', class: s.size === k2 ? 'on' : '', onclick: () => grSet({ size: k2 }) }, v[2])));
  grFit(); grRedraw();
  const body = grQ('.gr-body'); RC(body);
  const strip = () => h('div', { class: 'gr-strip' });
  const lbl = (t) => h('div', { class: 'gr-lbl', text: t });
  const range = (min, max, step, val, on) => h('div', { class: 'gr-rng' }, h('input', { type: 'range', min, max, step, value: val, oninput: (e) => on(+e.target.value) }));
  const note = (t) => h('p', { class: 'gr-note', text: t });
  if (k === 'occ') {
    body.append(h('div', { class: 'gr-occ' }, ...grOccs().map((o) => h('button', { type: 'button', class: s.occ === o.id ? 'on' : '', onclick: () => grSet({ occ: o.id, cal: 0, txt: '' }) },
      h('span', { text: o.id === 'national' ? (DesignKit.NATIONAL?.[typeof dsCountry === 'function' ? dsCountry() : 'SA']?.[1] || o.ic) : o.ic || '🎁' }), o.name))));
  }
  if (k === 'cal') {
    const st = strip();
    grCals(s.occ).forEach((cal, i) => st.append(grThumb({ ...s, cal: i, bg: 'marble', frm: 'none', col: 'ink', stars: false, glow: false, dim: 0, ttlSize: 1 }, cal.title || '', s.cal % grCals(s.occ).length === i, () => grSet({ cal: i }), cal.premium && !dsPremium())));
    body.append(st, lbl('حجم المخطوطة'), range(0.6, 1.35, 0.05, s.ttlSize, (v) => grSet({ ttlSize: v }, true)));
  }
  if (k === 'bg') {
    const st = strip();
    const up = h('label', { class: 'gr-th gr-up' }, '📷', h('small', { text: 'صورتك' }), h('input', { type: 'file', accept: 'image/*', hidden: true, onchange: (e) => {
      const f = e.target.files[0]; if (!f) return; const im = new Image(); im.onload = () => grSet({ photo: im, bg: 'photo' }); im.src = URL.createObjectURL(f); } }));
    st.append(up);
    if (s.photo) st.append(grThumb({ ...s, bg: 'photo' }, 'صورتك', s.bg === 'photo', () => grSet({ bg: 'photo' })));
    grBgImgs().forEach((b) => { grImg(b.url); st.append(grThumb({ ...s, bg: b.id }, b.title, s.bg === b.id, () => grSet({ bg: b.id }), b.premium && !dsPremium())); });
    GR_BGS.forEach(([id, n2]) => st.append(grThumb({ ...s, bg: id }, n2, s.bg === id, () => grSet({ bg: id }))));
    body.append(st, lbl('تعتيم الخلفية'), range(0, 70, 1, s.dim, (v) => grSet({ dim: v }, true)));
  }
  if (k === 'frm') {
    const st = strip();
    GR_FRM.forEach(([id, n2]) => st.append(id === 'none'
      ? h('button', { type: 'button', class: 'gr-th gr-none' + (s.frm === 'none' ? ' on' : ''), onclick: () => grSet({ frm: 'none' }) }, '✕', h('span', { class: 'lb', text: n2 }))
      : grThumb({ ...s, frm: id }, n2, s.frm === id, () => grSet({ frm: id }))));
    body.append(st);
  }
  if (k === 'txt') {
    const sugg = grTexts(s.occ);
    const t1 = h('input', { class: 'gr-inp', maxlength: 80, placeholder: 'مثلاً: ' + (sugg[0] || ''), value: s.txt, oninput: (e) => grSet({ txt: e.target.value }, true) });
    const t2 = h('input', { class: 'gr-inp', maxlength: 30, placeholder: 'اسمك أو اسم العائلة', value: s.from, oninput: (e) => grSet({ from: e.target.value }, true) });
    body.append(h('div', { class: 'gr-ti' }, t1), h('div', { class: 'gr-chips' }, ...sugg.map((t) => h('button', { type: 'button', class: 'gr-chip' + (s.txt === t ? ' on' : ''), onclick: () => grSet({ txt: t }) }, t))),
      lbl('الخط'), h('div', { class: 'gr-chips' }, ...GR_FONTS.map(([f, n2]) => h('button', { type: 'button', class: 'gr-chip' + (s.font === f ? ' on' : ''), style: `font-family:${f}`, onclick: () => grSet({ font: f }) }, n2))),
      lbl('من (اختياري)'), h('div', { class: 'gr-ti' }, t2));
    if (typeof Voice !== 'undefined') { try { Voice.attach(t1, 'designs', { replace: true, onText: (v) => grSet({ txt: v }, true) }); } catch { /* لا شيء */ } }
  }
  if (k === 'col') {
    const sw = (key) => h('div', { class: 'gr-sw' }, ...GR_COL.map(([id, v, n2]) => h('button', { type: 'button', title: n2, 'aria-label': n2, class: s[key] === id ? 'on' : '', style: `background:${v.startsWith('grad:') ? `linear-gradient(${v.slice(5)})` : v}`, onclick: () => grSet({ [key]: id }) })));
    body.append(lbl('لون المخطوطة'), sw('col'), lbl('لون الإطار'), sw('frmCol'),
      h('div', { class: 'gr-chips', style: 'margin-top:12px' },
        h('button', { type: 'button', class: 'gr-chip' + (s.glow ? ' on' : ''), onclick: () => grSet({ glow: !s.glow }) }, '✨ توهّج'),
        h('button', { type: 'button', class: 'gr-chip' + (s.stars ? ' on' : ''), onclick: () => grSet({ stars: !s.stars }) }, '✦ نجوم')));
  }
  if (k === 'done') {
    body.append(h('div', { class: 'gr-share' },
      h('button', { type: 'button', class: 'big', onclick: () => grExport('share') }, h('span', { text: '↗' }), 'شارك البطاقة'),
      h('button', { type: 'button', onclick: () => grExport('save') }, h('span', { text: '⬇️' }), 'حفظ صورة'),
      h('button', { type: 'button', onclick: () => { const n = grCals(s.occ).length; grSet({ i: 1, cal: (s.cal + 1) % n }); } }, h('span', { text: '🔁' }), 'نسخة ثانية'),
      h('button', { type: 'button', onclick: () => { GR.s = { ...grDefaults(s.occ), size: s.size }; grRender(); } }, h('span', { text: '✨' }), 'بطاقة جديدة')));
    if (dsSign(false) && dsCanHideSign()) body.append(note('التوقيع يظهر أسفل البطاقة — تقدر تشيله من المحرّر لأنك مشترك'));
  }
  const prev = grQ('.gr-prev'); prev.style.visibility = s.i ? 'visible' : 'hidden';
  grQ('.gr-go').textContent = s.i < GR_STEPS.length - 1 ? `التالي: ${GR_STEPS[s.i + 1][1]} ←` : '✓ انتهيت';
  UI.digitize?.(body);
}
function grSurprise() {
  const s = GR.s; if (!s) return;
  const p = (a) => a[Math.floor(Math.random() * a.length)];
  const bgs = GR_BGS.map((b) => b[0]).concat(grBgImgs().filter((b) => !b.premium || dsPremium()).map((b) => b.id));
  const cals = grCals(s.occ).map((c, i) => [c, i]).filter(([c]) => !c.premium || dsPremium());
  grSet({ bg: p(bgs), frm: p(GR_FRM.slice(1))[0], cal: (p(cals) || [null, 0])[1], col: p(['white', 'gold', 'mint', 'brand']), frmCol: p(['gold', 'white', 'mint']), txt: p(grTexts(s.occ)) });
  toast('🎲 تشكيلة جديدة — عدّل براحتك');
}
async function grExport(how) {
  const s = GR.s; if (!s) return;
  if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
  const cal = grCals(s.occ)[s.cal % grCals(s.occ).length];
  const bgLib = s.bg.startsWith('lib:') ? grBgImgs().find((b) => b.id === s.bg) : null;
  if (((cal && cal.premium) || (bgLib && bgLib.premium)) && !dsPremium()) { if (typeof Pro !== 'undefined') Pro.gate('designs.premium', 'هذي المخطوطة/الخلفية للمشتركين ★ — اختر وحدة ثانية أو اشترك'); return; }
  if (s.bg === 'photo' && !dsPhotoPro()) { if (typeof Pro !== 'undefined') Pro.gate('designs.photo', 'صورتك كخلفية للمشتركين ★'); return; }
  try {
    const imgs = new Map();
    if (cal?.img) imgs.set(cal.img, await grImgWait(cal.img));
    if (bgLib) await grImgWait(bgLib.url);
    const sg = dsSign(false);
    const logo = sg && sg.logo !== false && sg.logoSrc ? await grImgWait(sg.logoSrc) : null;
    if (document.fonts?.load) await Promise.all([`40px ${s.font}`, '40px QHafs'].map((f) => document.fonts.load(f, 'رمضان').catch(() => null)));
    const cv = document.createElement('canvas');
    grDraw(cv, s, { imgs, logo });
    const blob = await new Promise((r) => cv.toBlob(r, 'image/png'));
    if (!blob) return toast('تعذّر تجهيز الصورة', { type: 'error' });
    await dsDeliver(blob, `noble-card-${s.occ}-${Date.now().toString(36)}.png`, how, dsOcc(s.occ)?.name || 'بطاقة تهنئة');
    Sync?.event?.('design', { tpl: 'greeting', cat: s.occ, how });
    if (typeof markActive === 'function') markActive('design');
    buzz?.('success');
  } catch { /* أُلغيت المشاركة */ }
}
