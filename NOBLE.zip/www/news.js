/* NOBLE — قسم الأخبار: مجالات واهتمامات ودول حسب اختيار المستخدم، موجز يومي، حفظ ومشاركة
 * الأخبار تُسحب وتُلخَّص في السيرفر، وتنزل هنا بعد موافقة الإدارة.
 * اختيارات المستخدم (دولته، مفضلاته، ترتيبها) تُحفظ مشفّرة ضمن الخزنة وتشتغل بدون نت.
 */
'use strict';
const NEWS = { items: [], cat: '', more: true, loading: false, loaded: false, err: '', meta: null, view: 'feed', seen: new Set(), at: 0, sig: '' };
const NEWS_KEY = 'nw:news';
const NEWS_META_KEY = 'nw:news-meta';
// للتوافق مع الأقسام اللي تستخدم الأسماء القديمة
const NEWS_GRAD = NewsCfg.GRAD;

/* ---------- الإعداد واختيارات المستخدم ---------- */
function newsMetaCached() {
  if (NEWS.meta) return NEWS.meta;
  try { return JSON.parse(localStorage.getItem(NEWS_META_KEY) || 'null'); } catch { return null; }
}
const newsCfg = () => NewsCfg.from(newsMetaCached() || {});
const newsDomain = (id) => newsCfg().domains.find((d) => d.id === id);
const newsCountry = (id) => newsCfg().countries.find((c) => c.id === id);
const newsTopicName = (d, t) => (d?.subs || []).find((s) => s[0] === t)?.[1] || '';
/* مزايا المشتركين (زيادة المفضلات والدول + الترتيب والاهتمامات الدقيقة) — تجي مع الاشتراك اللي تحدده الإدارة */
function newsPremium() {
  if (!Cloud.enabled || typeof Pro === 'undefined') return true;
  if (Pro.inTrial()) return true;
  const p = newsCfg().premium;
  return Pro.active().some((e) => (p.apps || []).includes(e.app) && (!['m', 'y', 'l'].includes(e.plan) || (p.plans || []).includes(e.plan)));
}
const newsLimit = (k) => { const l = newsCfg().limits[k]; return newsPremium() ? Math.max(l.paid, l.free) : l.free; };
const newsPrefsRaw = () => (S.vault?.newsPrefs && typeof S.vault.newsPrefs === 'object' ? S.vault.newsPrefs : {});
/* الاختيارات الفعّالة بعد تطبيق الحدود والمجالات المفعّلة */
function newsPrefs() {
  const cfg = newsCfg(), raw = newsPrefsRaw(), prem = newsPremium();
  const domOn = new Set(cfg.domains.filter((d) => d.on).map((d) => d.id));
  const ctyOn = new Set(cfg.countries.filter((c) => c.on).map((c) => c.id));
  const home = ctyOn.has(raw.home) ? raw.home : (!raw.done ? NewsCfg.detectCountry(cfg.countries) : '');
  const countries = [home, ...(raw.more || [])].filter((c, i, a) => c && ctyOn.has(c) && a.indexOf(c) === i).slice(0, newsLimit('countries'));
  let favs = (raw.favs || []).filter((d) => domOn.has(d));
  if (!raw.done && !favs.length) favs = cfg.domains.filter((d) => d.on).slice(0, 3).map((d) => d.id);
  favs = favs.slice(0, newsLimit('favs'));
  const subs = {};
  if (prem) Object.entries(raw.subs || {}).forEach(([d, l]) => { if (favs.includes(d) && Array.isArray(l) && l.length) subs[d] = l; });
  return { home, countries, favs, subs, done: !!raw.done, prem };
}
const newsNeedsSetup = () => !newsPrefsRaw().done && newsCfg().ask && !!S.vault;
async function saveNewsPrefs(p) {
  await commit((v) => { v.newsPrefs = { home: p.home || '', more: (p.more || []).filter(Boolean), favs: p.favs || [], subs: p.subs || {}, done: true, at: Date.now() }; });
  NEWS.items = []; NEWS.cat = ''; NEWS.sig = ''; NEWS.loaded = false;
}
const newsSig = (p) => JSON.stringify([p.favs, p.countries, p.subs]);

const newsSaved = () => (Array.isArray(S.vault?.newsSaved) ? S.vault.newsSaved : []);
const isSaved = (id) => newsSaved().some((x) => x.id === id);
const newsAgo = (iso) => {
  const t = new Date(iso).getTime();
  if (!t) return '';
  const m = Math.max(1, Math.round((Date.now() - t) / 6e4));
  return m < 60 ? `قبل ${UI.n(m)} د` : m < 1440 ? `قبل ${UI.n(Math.round(m / 60))} س` : m < 2880 ? 'أمس' : `قبل ${UI.n(Math.round(m / 1440))} يوم`;
};
/* آخر خلاصة «مفضلاتي» محفوظة على الجهاز — للعرض بدون نت */
function newsCache(items) {
  const sig = newsSig(newsPrefs());
  if (items) { try { localStorage.setItem(NEWS_KEY, JSON.stringify({ sig, items: items.slice(0, 40) })); } catch { /* لا شيء */ } return items; }
  try {
    const c = JSON.parse(localStorage.getItem(NEWS_KEY) || 'null');
    if (Array.isArray(c)) return c; // نسخة قديمة
    return c && Array.isArray(c.items) ? c.items : [];
  } catch { return []; }
}

/* خلط «مفضلاتي»: بالتناوب حسب ترتيب المفضلات — الأول ياخذ نصيب أكبر، والمثبّت أولاً، وأخبار دولته قبل الدول الثانية */
function newsMix(list, p) {
  const pinned = list.filter((x) => x.pinned);
  const rest = list.filter((x) => !x.pinned);
  const homeFirst = (a, b) => ((b.country === p.home) - (a.country === p.home)) || (new Date(b.at) - new Date(a.at));
  const q = p.favs.map((d) => rest.filter((x) => x.cat === d).sort(homeFirst));
  const other = rest.filter((x) => !p.favs.includes(x.cat));
  const out = [...pinned];
  for (let round = 0; q.some((a) => a.length); round++) q.forEach((a, i) => out.push(...a.splice(0, i === 0 ? 2 : 1)));
  return [...out, ...other];
}

async function loadNews({ more = false, force = false } = {}) {
  if (typeof loadAiNews === 'function') loadAiNews(force);
  if (NEWS.loading) return;
  if (!Cloud.enabled) { NEWS.err = 'الأخبار تحتاج حساب سحابي'; NEWS.loaded = true; return renderNews(); }
  // الإعداد أولاً (المجالات والدول) — حتى لو بدون اختيار بعد
  // 📴 1.21.14: الإعداد المحفوظ أولاً (يرسم فوراً)، والجديد من السيرفر بحد أقصى — بدون نت ما ننتظر
  if (!NEWS.meta) NEWS.meta = newsMetaCached();
  if (!NEWS.metaAt || force) {
    if (!NEWS.meta) { NEWS.loading = true; renderNews(); }
    const m = await Cloud.soon(Cloud.newsMeta(), 7000).catch(() => null);
    NEWS.loading = false;
    if (m) { NEWS.meta = m; NEWS.metaAt = Date.now(); try { localStorage.setItem(NEWS_META_KEY, JSON.stringify(m)); } catch { /* لا شيء */ } }
  }
  if (navigator.onLine === false) {
    const c = newsCache();
    if (!more) NEWS.items = NEWS.cat && !['all', 'star'].includes(NEWS.cat) ? c.filter((x) => x.cat === NEWS.cat) : NEWS.cat === 'star' ? c.filter((x) => x.featured) : c;
    NEWS.more = false; NEWS.loaded = true; NEWS.sig = '';
    NEWS.err = NEWS.items.length ? '📴 بدون نت — هذي آخر أخبار محفوظة على جوالك' : '📴 بدون نت — أول ما يرجع النت تنزل الأخبار هنا';
    return renderNews();
  }
  if (newsNeedsSetup()) { NEWS.loaded = true; return renderNews(); }
  const p = newsPrefs();
  const sig = newsSig(p) + NEWS.cat;
  if (!more && !force && NEWS.loaded && NEWS.sig === sig && Date.now() - NEWS.at < 5 * 6e4) return renderNews();
  NEWS.loading = true; NEWS.err = '';
  if (!more && (!NEWS.items.length || NEWS.sig !== sig)) { NEWS.items = NEWS.cat ? [] : newsCache(); renderNews(); }
  try {
    const before = more ? NEWS.items.filter((x) => !x.pinned).slice(-1)[0]?.at : null;
    const star = NEWS.cat === 'star'; // ⭐ المميزة (1.19)
    const all = NEWS.cat === 'all' || star; // «الكل»: كل المجالات المفعّلة بدون تخصيص الاهتمامات
    const exploring = all || (NEWS.cat && !p.favs.includes(NEWS.cat));
    const cats = all ? newsCfg().domains.filter((d) => d.on).map((d) => d.id) : NEWS.cat ? [NEWS.cat] : p.favs;
    const topics = exploring ? [] : Object.entries(p.subs).filter(([d]) => cats.includes(d)).flatMap(([d, l]) => l.map((t) => `${d}/${t}`));
    let list = await Cloud.soon(Cloud.newsFeed2({ cats, countries: p.countries, topics, before, limit: 40 }), 12000);
    const got = list ? list.length : 0;
    if (list && star) list = list.filter((x) => x.featured);
    if (list === null) { NEWS.err = 'قسم الأخبار يحتاج تحديث قاعدة البيانات'; NEWS.items = []; }
    else {
      const merged = more ? [...NEWS.items, ...list.filter((x) => !NEWS.items.some((y) => y.id === x.id))] : list;
      NEWS.items = NEWS.cat ? merged : (more ? merged : newsMix(merged, p));
      NEWS.more = got >= 40;
      if (!NEWS.cat && !more) newsCache(NEWS.items);
    }
    NEWS.at = Date.now(); NEWS.sig = sig;
  } catch (e) {
    const net = navigator.onLine === false || /offline|timeout|fetch|network/i.test(e?.message || '');
    if (net && !more && !NEWS.items.length && !NEWS.cat) NEWS.items = newsCache();
    NEWS.err = net ? (NEWS.items.length ? '📶 النت ضعيف — هذي آخر أخبار محفوظة' : '📶 النت ضعيف — اسحب للتحديث بعد شوي') : 'تعذّر تحميل الأخبار: ' + Cloud.msg(e);
  }
  NEWS.loading = false; NEWS.loaded = true;
  renderNews();
}

function newsImg(it, cls) {
  const d = newsDomain(it.cat);
  const box = h('div', { class: cls, style: { background: NewsCfg.GRAD[it.cat] || NewsCfg.GRAD_DEF } });
  if (it.image && /^https:\/\//.test(it.image)) {
    const img = h('img', { src: it.image, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' });
    img.addEventListener('error', () => img.remove());
    box.append(img);
  } else box.append(h('span', { class: 'n-ph', text: d?.ic || '📰' }));
  return box;
}
function newsTagText(it) {
  const d = newsDomain(it.cat), c = it.country ? newsCountry(it.country) : null;
  return `${d?.ic || '📰'} ${newsTopicName(d, it.topic) || d?.name || 'عام'}${c ? ' ' + c.flag : ''}`;
}
const catTag = (it) => h('span', { class: 'n-tag', text: newsTagText(it) });

/* ---------- الصفحة ---------- */
/* ===== «الأخبار» كمركز (1.18): تبويبات فوق — الأخبار · ⚡ عاجل · 🧭 اكتشف (لو الإدارة دمجت اكتشف) + دوائر الستوري ===== */
const newsHasDiscover = () => Content.get('discoverInNews') === true && !(Content.get('sectionsOff') || []).includes('discover') && typeof renderDiscover === 'function';
function newsHubTop() {
  const tab = (v, ic, l, extra) => h('button', { type: 'button', class: `n-hub-t${NEWS.view === v || (v === 'feed' && !['ai', 'discover'].includes(NEWS.view)) ? ' on' : ''}${extra || ''}`, dataset: { v },
    onclick: () => { if (NEWS.view === v) return; NEWS.view = v; const r = $('#n-root'); if (r) r.dataset.saved = ''; renderNews(); window.scrollTo({ top: 0 }); if (v === 'discover' && typeof loadFeed === 'function') loadFeed(); } }, ic, h('span', { text: l }));
  const rings = newsHasDiscover() && typeof dscRings === 'function' ? dscRings('in-news') : null;
  return [rings ? h('div', { class: 'n-hub-rings' }, rings) : null,
    h('nav', { class: 'n-hub', role: 'tablist' },
      tab('feed', icon('bolt', { size: 15 }), NEWS.view === 'saved' ? 'المحفوظة' : 'الأخبار'),
      typeof renderAiNews === 'function' ? tab('ai', icon('spark', { size: 15 }), 'عاجل', typeof ainHasNew === 'function' && ainHasNew() ? ' new' : '') : null,
      newsHasDiscover() ? tab('discover', icon('play', { size: 14 }), 'اكتشف') : null)].filter(Boolean);
}
function newsHubPaintRings() {
  const box = document.querySelector('#n-root .n-hub-rings'); if (!box || typeof dscRings !== 'function') return;
  const r = dscRings('in-news'); if (r) box.replaceChildren(r); else box.remove();
}
function renderNews() {
  if (typeof FCM !== 'undefined' && FCM.pending?.() && S.tab === 'news') FCM.clear(); // 1.21.10: شاف الأخبار → نشيل رقم الجرس
  const root = $('#n-root');
  if (!root || !S.vault) return;
  if (NEWS.view === 'discover' && !newsHasDiscover()) NEWS.view = 'feed';
  if (NEWS.view === 'discover') renderDiscover({ root, embedded: true });
  else if (NEWS.view === 'ai' && typeof renderAiNews === 'function') renderAiNews(root);
  else renderNewsFeed();
  root.prepend(...newsHubTop());
  UI.digitize?.(root);
}
function renderNewsFeed() {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  const root = $('#n-root');
  if (!root || !S.vault) return;
  if (newsNeedsSetup()) {
    paintNewsSetup(root, { first: true });
    // «عاجل» متاح حتى قبل ما يختار اهتماماته
    return;
  }
  const meta = NEWS.meta || newsMetaCached() || { title: 'الأخبار', sub: '' };
  const saved = NEWS.view === 'saved';
  const p = newsPrefs();
  const today = new Date().toDateString();
  const todays = NEWS.items.filter((x) => new Date(x.at).toDateString() === today);
  const head = h('div', { class: 'n-top' },
    h('div', { class: 'n-tw' }, h('div', { class: 'n-tline' }, h('h1', { class: 'view-title', text: saved ? 'المحفوظة' : meta.title || 'الأخبار' })),
      h('small', { text: saved ? `${UI.n(newsSaved().length)} خبر` : `${new Intl.DateTimeFormat('ar-SA-u-ca-gregory-nu-latn', { weekday: 'long', day: 'numeric', month: 'long' }).format(new Date())}${todays.length ? ` · ${UI.n(todays.length)} خبر اليوم` : ''}` })),
    h('div', { class: 'n-tools' },
      saved ? null : h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'تحديث', onclick: () => loadNews({ force: true }) }, icon('repeat', { size: 18 })),
      saved ? null : h('button', { type: 'button', class: 'n-pill', onclick: () => openNewsPrefs() }, '✏️ اهتماماتي'),
      h('button', { type: 'button', class: `n-pill${saved ? ' on' : ''}`, onclick: () => { NEWS.view = saved ? 'feed' : 'saved'; renderNews(); window.scrollTo({ top: 0 }); } }, saved ? '← كل الأخبار' : '🔖')));

  if (saved) {
    const list = newsSaved();
    root.replaceChildren(head, list.length
      ? h('div', { class: 'n-list' }, ...list.map((it) => newsRow(it)))
      : h('div', { class: 'empty n-empty' }, h('b', { text: 'ما حفظت أي خبر بعد' }), h('small', { text: 'اضغط 🔖 على أي خبر يعجبك ويوصل هنا — حتى بدون نت.' })));
    UI.digitize(root);
    return;
  }
  const items = NEWS.items;
  const parts = [head];
  if (meta.sub) parts.push(h('p', { class: 'hint n-sub', text: meta.sub }));
  // الموجز
  if (!NEWS.cat && items.length && meta.digest !== false) {
    const pool = (todays.length >= 2 ? todays : items).slice(0, 3);
    parts.push(h('section', { class: 'n-digest' },
      h('div', { class: 'n-dh' }, h('b', { text: todays.length >= 2 ? '☀️ موجز اليوم من مفضلاتك' : '⚡ آخر أخبار مفضلاتك' }), h('span', { text: `${UI.n(Math.max(1, Math.round(pool.reduce((s, x) => s + (x.summary || '').split(/\s+/).length, 0) / 120 + 1)))} دقائق قراءة` })),
      h('div', { class: 'n-dl' }, ...pool.map((x, i) => h('button', { type: 'button', onclick: () => openNews(x) }, h('span', { class: 'num', text: i + 1 }), h('b', { text: x.title }), h('em', { class: 'n-dt', text: newsTagText(x) })))),
      notifyBtn()));
  }
  const go = (k) => { if (NEWS.cat === k) return; NEWS.cat = k; NEWS.items = []; NEWS.more = true; if (k === 'explore') { renderNews(); return; } loadNews({ force: true }); window.scrollTo({ top: 0 }); };
  const chip = (k, ic, l) => h('button', { type: 'button', class: `chip${NEWS.cat === k ? ' on' : ''}`, onclick: () => go(k) }, `${ic} ${l}`);
  const browsing = NEWS.cat && NEWS.cat !== 'explore' && NEWS.cat !== 'star' && !p.favs.includes(NEWS.cat) ? newsDomain(NEWS.cat) : null;
  parts.push(h('nav', { class: 'chips n-chips' }, chip('', '✨', 'مفضلاتي'), chip('all', '📰', 'الكل'), chip('star', '⭐', 'المميزة'),
    ...p.favs.map((k) => { const d = newsDomain(k); return d ? chip(k, d.ic, d.name) : null; }).filter(Boolean),
    browsing ? chip(browsing.id, browsing.ic, browsing.name) : null,
    chip('explore', '🧭', 'استكشف')));
  if (NEWS.cat === 'explore') { parts.push(...newsExplore(p)); root.replaceChildren(...parts); UI.digitize(root); return; }
  if (browsing) parts.push(h('div', { class: 'n-browse' }, h('span', { text: `تتصفح ${browsing.ic} ${browsing.name} — مو من مفضلاتك` }), h('button', { type: 'button', class: 'n-pill', onclick: () => newsAddFav(browsing.id) }, '＋ أضف للمفضلة')));
  if (NEWS.err) parts.push(h('p', { class: 'note-box n-err', text: NEWS.err }));
  if (!items.length) {
    parts.push(NEWS.loading || !NEWS.loaded
      ? h('div', { class: 'n-list' }, ...[0, 1, 2].map(() => h('div', { class: 'n-skel' })))
      : h('div', { class: 'empty n-empty' }, h('b', { text: 'لا توجد أخبار هنا بعد' }), h('small', { text: p.subs[NEWS.cat] || Object.keys(p.subs).length ? 'جرّب توسّع اهتماماتك من ✏️ اهتماماتي، أو ارجع بعد شوي.' : 'ارجع بعد شوي — الأخبار تنزل على مدار اليوم.' })));
  } else {
    const [first, ...rest] = items;
    parts.push(newsCard(first), h('div', { class: 'n-list' }, ...rest.map((it, i) => (i % 5 === 3 ? newsCard(it) : newsRow(it)))));
    if (NEWS.more) parts.push(h('button', { type: 'button', class: 'btn btn-block n-more', disabled: NEWS.loading, onclick: () => loadNews({ more: true }) }, NEWS.loading ? 'جارٍ التحميل…' : 'أخبار أقدم'));
  }
  root.replaceChildren(...parts);
  UI.digitize(root);
}
/* استكشف: المجالات اللي مو ضمن مفضلاته */
function newsExplore(p) {
  const others = newsCfg().domains.filter((d) => d.on && !p.favs.includes(d.id));
  if (!others.length) return [h('div', { class: 'empty n-empty' }, h('b', { text: 'كل المجالات ضمن مفضلاتك 👌' }))];
  return [h('p', { class: 'hint', text: 'مجالات مو ضمن مفضلاتك — افتح أي مجال تتصفحه، أو أضفه للمفضلة.' }),
    h('div', { class: 'n-xgrid' }, ...others.map((d) => h('div', { class: 'n-x', style: { background: NewsCfg.GRAD[d.id] || NewsCfg.GRAD_DEF } },
      h('button', { type: 'button', class: 'n-x-open', onclick: () => { NEWS.cat = d.id; NEWS.items = []; loadNews({ force: true }); window.scrollTo({ top: 0 }); } }, h('span', { class: 'n-x-ic', text: d.ic }), h('b', { text: d.name }), h('small', { text: d.subs.slice(0, 3).map((s) => s[1]).join(' · ') })),
      h('button', { type: 'button', class: 'n-x-add', 'aria-label': 'أضف للمفضلة', onclick: () => newsAddFav(d.id) }, '＋'))))];
}
async function newsAddFav(id) {
  const raw = newsPrefsRaw(), p = newsPrefs();
  if (p.favs.includes(id)) return;
  if (p.favs.length >= newsLimit('favs')) return newsUpsell(`مفضلاتك مكتملة (${UI.n(p.favs.length)})`);
  await saveNewsPrefs({ ...raw, home: p.home, more: p.countries.slice(1), favs: [...p.favs, id], subs: raw.subs || {} });
  NEWS.cat = id;
  toast(`انضاف ${newsDomain(id)?.name || ''} لمفضلاتك ✓`, { type: 'success' });
  loadNews({ force: true });
}
/* شاشة الترقية للاشتراك اللي حددته الإدارة */
function newsUpsell(why) {
  const l = newsCfg().limits;
  const more = l.favs.paid > l.favs.free || l.countries.paid > l.countries.free;
  if (newsPremium() || !more) return toast(why + ' — شيل واحد وأضف غيره');
  buzz('warning');
  const apps = newsCfg().premium.apps || [];
  if (typeof Upgrade !== 'undefined') Upgrade.open({ app: apps.includes('news') ? 'news' : apps.find((a) => a !== 'all') || 'all', why: `${why} — اشترك وتابع حتى ${UI.n(l.favs.paid)} مجالات و${UI.n(l.countries.paid)} دول، ورتّبها واختر اهتماماتك بالتحديد ★` });
  else toast(why);
}

function newsCard(it) {
  return h('article', { class: 'n-card', onclick: () => openNews(it) },
    h('div', { class: 'n-imgwrap' }, newsImg(it, 'n-img'), catTag(it), it.pinned ? h('span', { class: 'n-pin', text: '📌' }) : null, it.featured ? h('span', { class: 'n-star', text: '⭐ مميز' }) : null),
    h('div', { class: 'n-b' },
      h('div', { class: 'n-src' }, h('b', { text: it.src || 'NOBLE' }), h('span', { text: newsAgo(it.at) })),
      h('h3', { text: it.title }), it.summary ? h('p', { text: it.summary }) : null,
      newsActs(it)));
}
function newsRow(it) {
  return h('article', { class: 'n-row', onclick: () => openNews(it) }, newsImg(it, 'n-th'),
    h('div', {}, h('b', { text: (it.featured ? '⭐ ' : '') + it.title }), h('small', { text: `${newsTagText(it)} · ${it.src || ''} · ${newsAgo(it.at)}` })),
    h('button', { type: 'button', class: `n-save-ic${isSaved(it.id) ? ' on' : ''}`, 'aria-label': 'حفظ', onclick: (e) => { e.stopPropagation(); toggleSave(it); } }, '🔖'));
}
function newsActs(it) {
  const stop = (fn) => (e) => { e.stopPropagation(); fn(); };
  return h('div', { class: 'n-acts' },
    h('button', { type: 'button', class: isSaved(it.id) ? 'on' : '', onclick: stop(() => toggleSave(it)) }, isSaved(it.id) ? '🔖 محفوظ' : '🔖 حفظ'),
    h('button', { type: 'button', onclick: stop(() => shareNews(it)) }, '↗ مشاركة'),
    it.url ? h('a', { href: it.url, target: '_blank', rel: 'noopener noreferrer', onclick: (e) => e.stopPropagation() }, '🔗 المصدر') : null);
}

/* ---------- الاختيار: دولته ثم اهتماماته (أول مرة) / تعديلها من «اهتماماتي» ---------- */
function newsDraft() {
  const p = newsPrefs(), raw = newsPrefsRaw();
  const home = p.home || (raw.done ? '' : NewsCfg.detectCountry(newsCfg().countries));
  return { step: 1, home, homeSet: !!raw.done, more: p.countries.filter((c) => c !== home), favs: raw.done ? [...p.favs] : [], subs: JSON.parse(JSON.stringify(p.subs)), ctyOpen: false, detected: NewsCfg.detectCountry(newsCfg().countries) };
}
function paintNewsSetup(root, { first = false, st = null } = {}) {
  const D = st || (root._nd ||= newsDraft());
  const cfg = newsCfg(), prem = newsPremium();
  const doms = cfg.domains.filter((d) => d.on), ctys = cfg.countries.filter((c) => c.on);
  const favMax = newsLimit('favs'), ctyMax = newsLimit('countries');
  const again = () => paintNewsSetup(root, { first, st: D });
  const lockMsg = () => newsUpsell('ترتيب المفضلات والاهتمامات الدقيقة للمشتركين');
  const flag = (id) => newsCountry(id) || { flag: '🌐', name: 'بدون — أخبار عامة' };

  // ١) الدولة
  const ctyGrid = () => h('div', { class: 'ns-ctys' },
    ...ctys.map((c) => h('button', { type: 'button', class: `ns-cty${D.home === c.id ? ' on' : ''}`, onclick: () => { D.home = c.id; D.homeSet = true; D.more = D.more.filter((x) => x !== c.id); if (!first) D.ctyOpen = false; again(); } },
      h('span', { class: 'ns-fl', text: c.flag }), h('b', { text: c.name }), D.detected === c.id ? h('small', { text: '📍 موقعك' }) : null)),
    h('button', { type: 'button', class: `ns-cty ns-none${D.homeSet && !D.home ? ' on' : ''}`, onclick: () => { D.home = ''; D.homeSet = true; D.more = []; again(); } }, h('span', { class: 'ns-fl', text: '🌐' }), h('b', { text: 'بدون — أخبار عامة' })));

  if (first && D.step === 1) {
    root.replaceChildren(h('section', { class: 'ns' },
      h('div', { class: 'ns-steps' }, h('i', { class: 'on' }), h('i')),
      h('h1', { class: 'view-title', text: 'وين موقعك؟ 📍' }),
      h('p', { class: 'lead', text: D.detected ? `حسب جوالك أنت في ${flag(D.detected).name} — أكّدها أو اختر دولتك، وأخبارها المحلية (السوق، الدوري، الفعاليات…) تجيك أول.` : 'اختر دولتك عشان تجيك أخبارها المحلية (السوق، الدوري، الفعاليات…).' }),
      ctyGrid(),
      h('div', { class: 'ns-bar' }, h('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: !D.homeSet && !D.home, onclick: () => { D.homeSet = true; D.step = 2; again(); window.scrollTo({ top: 0 }); } }, D.home || D.homeSet ? `التالي — ${flag(D.home).flag} ${flag(D.home).name}` : 'اختر دولتك'))));
    UI.digitize(root);
    return;
  }

  // ٢) المجالات المفضلة
  const full = D.favs.length >= favMax;
  const domGrid = h('div', { class: 'ns-doms' }, ...doms.map((d) => {
    const i = D.favs.indexOf(d.id);
    return h('button', { type: 'button', class: `ns-dom${i >= 0 ? ' on' : full ? ' dim' : ''}`, onclick: () => {
      if (i >= 0) { D.favs.splice(i, 1); delete D.subs[d.id]; }
      else if (D.favs.length >= favMax) return newsUpsell(`وصلت ${UI.n(favMax)} مجالات`);
      else D.favs.push(d.id);
      again();
    } }, i >= 0 ? h('span', { class: 'ns-ord num', text: i + 1 }) : null, h('span', { class: 'ns-ic', text: d.ic }), h('b', { text: d.name }), h('small', { text: `${UI.n(d.subs.length)} اهتمامات` }));
  }));
  const meter = h('div', { class: 'ns-meter' }, h('div', { class: 'ns-dots' }, ...Array.from({ length: favMax }, (_, i) => h('i', { class: i < D.favs.length ? 'f' : '' }))),
    h('span', { text: `اخترت ${UI.n(D.favs.length)} من ${UI.n(favMax)}` }),
    !prem && cfg.limits.favs.paid > cfg.limits.favs.free ? h('button', { type: 'button', class: 'ns-up', onclick: () => newsUpsell('زِد مفضلاتك') }, `★ حتى ${UI.n(cfg.limits.favs.paid)}`) : null);

  // ترتيب المفضلات والاهتمامات الدقيقة (للمشتركين)
  const mv = (i, dlt) => { const j = i + dlt; [D.favs[i], D.favs[j]] = [D.favs[j], D.favs[i]]; again(); };
  const order = D.favs.length ? [h('div', { class: 'ns-st' }, h('b', { text: 'ترتيب مفضلاتك واهتماماتك' }), prem ? h('small', { text: 'الأعلى يطلع أكثر' }) : h('button', { type: 'button', class: 'ns-lock', onclick: lockMsg }, '🔒 للمشتركين ★')),
    !prem ? h('p', { class: 'hint', text: 'مجالاتك تطلع بترتيب اختيارك وبكل اهتماماتها. التحكم بالترتيب والاهتمامات الدقيقة للمشتركين.' }) : null,
    ...D.favs.map((id, i) => {
      const d = doms.find((x) => x.id === id); if (!d) return null;
      const sel = D.subs[id] || [];
      return h('div', { class: 'ns-fav' },
        h('div', { class: 'ns-fh' }, h('span', { class: 'ns-n num', text: i + 1 }), h('b', { text: `${d.ic} ${d.name}` }),
          prem ? h('button', { type: 'button', class: 'ns-mv', disabled: i === 0, 'aria-label': 'فوق', onclick: () => mv(i, -1) }, '▲') : h('button', { type: 'button', class: 'ns-mv', 'aria-label': 'مقفل', onclick: lockMsg }, '🔒'),
          prem ? h('button', { type: 'button', class: 'ns-mv', disabled: i === D.favs.length - 1, 'aria-label': 'تحت', onclick: () => mv(i, 1) }, '▼') : null),
        h('div', { class: `ns-subs${prem ? '' : ' locked'}` },
          h('button', { type: 'button', class: `chip${sel.length && prem ? '' : ' on'}`, onclick: () => { if (!prem) return lockMsg(); delete D.subs[id]; again(); } }, `كل ${d.name}`),
          ...d.subs.map(([k, l]) => h('button', { type: 'button', class: `chip${prem && sel.includes(k) ? ' on' : ''}`, onclick: () => {
            if (!prem) return lockMsg();
            const a = D.subs[id] = D.subs[id] || []; const j = a.indexOf(k); j >= 0 ? a.splice(j, 1) : a.push(k); if (!a.length) delete D.subs[id]; again();
          } }, l))));
    })] : [];

  // الدول (في التعديل): دولته + دول إضافية للمشتركين
  const ctyCard = first ? null : h('section', { class: 'ns-card' },
    h('button', { type: 'button', class: 'ns-ch', onclick: () => { D.ctyOpen = !D.ctyOpen; again(); } },
      h('span', { class: 'ns-fl', text: [D.home, ...D.more].filter(Boolean).map((c) => flag(c).flag).join(' ') || '🌐' }),
      h('div', {}, h('b', { text: D.home ? `دولتك: ${flag(D.home).name}` : 'بدون دولة — أخبار عامة' }), h('small', { text: D.more.length ? `+ تتابع ${D.more.map((c) => flag(c).name).join(' و')}` : 'الأخبار المحلية تجيك منها أول' })),
      h('span', { class: 'ns-chg', text: D.ctyOpen ? 'تم' : 'تغيير' })),
    D.ctyOpen ? h('div', {}, h('small', { class: 'ns-lbl', text: '🏠 دولتك' }), ctyGrid(),
      D.home ? h('div', { class: 'ns-more' },
        h('div', { class: 'ns-st' }, h('b', { text: `دول تتابعها أيضاً (${UI.n(D.more.length)} من ${UI.n(Math.max(0, ctyMax - 1))})` }),
          !prem && cfg.limits.countries.paid > cfg.limits.countries.free ? h('button', { type: 'button', class: 'ns-lock', onclick: () => newsUpsell('تابع أكثر من دولة') }, `🔒 حتى ${UI.n(cfg.limits.countries.paid)} ★`) : null),
        h('div', { class: 'chips ns-wrap' }, ...ctys.filter((c) => c.id !== D.home).map((c) => h('button', { type: 'button', class: `chip${D.more.includes(c.id) ? ' on' : ''}`, onclick: () => {
          const j = D.more.indexOf(c.id);
          if (j >= 0) D.more.splice(j, 1);
          else if (1 + D.more.length >= ctyMax) return newsUpsell(ctyMax <= 1 ? 'متابعة أكثر من دولة' : `وصلت ${UI.n(ctyMax)} دول`);
          else D.more.push(c.id);
          again();
        } }, `${c.flag} ${c.name}`)))) : null) : null);

  const save = async () => {
    if (!D.favs.length) return toast('اختر مجال واحد على الأقل');
    await saveNewsPrefs({ home: D.home, more: D.more, favs: D.favs, subs: prem ? D.subs : {} });
    root._nd = null;
    toast(first ? 'جاهز ✓ — هذي أخبارك' : 'انحفظت اهتماماتك ✓', { type: 'success' });
    if (!first) closeScreen();
    loadNews({ force: true });
  };
  root.replaceChildren(h('section', { class: 'ns' },
    first ? h('div', { class: 'ns-steps' }, h('i', { class: 'on' }), h('i', { class: 'on' })) : null,
    !first ? h('div', { class: 'ns-top' }, h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'رجوع', onclick: () => closeScreen() }, icon('arrowLeft', { size: 20 }))) : null,
    first ? h('button', { type: 'button', class: 'ns-backs', onclick: () => { D.step = 1; again(); } }, `← ${flag(D.home).flag} ${flag(D.home).name}`) : null,
    h('h1', { class: 'view-title', text: first ? 'وش يهمّك تتابع؟ 🧭' : 'اهتماماتي' }),
    h('p', { class: 'lead', text: 'اختر مجالاتك المفضلة بالترتيب — الأول يطلع لك أكثر.' }),
    ctyCard, meter, domGrid, ...order.filter(Boolean),
    h('div', { class: 'ns-bar' }, h('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: !D.favs.length, onclick: save }, D.favs.length ? (first ? `ابدأ (${UI.n(D.favs.length)})` : `احفظ (${UI.n(D.favs.length)})`) : 'اختر مجال واحد على الأقل'))));
  UI.digitize(root);
}
function openNewsPrefs() {
  openScreen((el) => { el._nd = newsDraft(); el.classList.add('ns-screen'); paintNewsSetup(el, { first: false }); }, { cls: 'ns-screen', onBack: () => closeScreen() });
}

async function toggleSave(it) {
  const was = isSaved(it.id);
  if (!was && typeof Pro !== 'undefined' && !Pro.gate('news.saved')) return;
  const snap = { id: it.id, title: it.title, summary: it.summary, body: it.body, why: it.why, image: it.image, url: it.url, src: it.src, cat: it.cat, topic: it.topic, country: it.country, at: it.at };
  await commit((v) => {
    const list = Array.isArray(v.newsSaved) ? v.newsSaved : [];
    v.newsSaved = was ? list.filter((x) => x.id !== it.id) : [snap, ...list.filter((x) => x.id !== it.id)].slice(0, 200);
  });
  Cloud.newsHit(it.id, was ? 'unsave' : 'save'); if (!was && typeof Insights !== 'undefined') Insights.inc('saves');
  buzz('light');
  toast(was ? 'أُزيل من المحفوظة' : 'حُفظ — تلقاه في 🔖 المحفوظة', { type: was ? '' : 'success' });
  if (GS.screen?.classList.contains('n-screen')) paintNews(GS.screen, it); else renderNews();
}
async function shareNews(it) {
  if (typeof Insights !== 'undefined') Insights.inc('shares');
  const text = `${it.title}\n\n${it.summary || ''}${it.url ? '\n' + it.url : ''}\n\n— من ${NEWS.meta?.title || 'الأخبار'} في NOBLE`;
  try {
    if (Platform.isNative) await Platform.plugin('Share').share({ title: it.title, text, dialogTitle: 'مشاركة الخبر' });
    else if (navigator.share) await navigator.share({ title: it.title, text });
    else { await navigator.clipboard.writeText(text); toast('نُسخ الخبر ✓', { type: 'success' }); }
  } catch { /* أُلغيت */ }
}

/* ---------- صفحة الخبر ---------- */
function openNews(it) {
  if (!NEWS.seen.has(it.id)) { NEWS.seen.add(it.id); Cloud.newsHit(it.id, 'view'); if (typeof Insights !== 'undefined') Insights.inc('newsRead'); if (typeof markActive === 'function') markActive('news'); }
  openScreen((el) => paintNews(el, it), { cls: 'n-screen', onBack: () => { closeScreen(); renderNews(); } });
}
function paintNews(el, it) {
  const paras = String(it.body || it.summary || '').split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  el.replaceChildren(
    h('div', { class: 'n-hero' }, newsImg(it, 'n-himg'),
      h('button', { type: 'button', class: 'n-back', 'aria-label': 'رجوع', onclick: () => { closeScreen(); renderNews(); } }, icon('arrowLeft', { size: 20 }))),
    h('div', { class: 'n-art' },
      h('div', { class: 'n-meta' }, catTag(it), it.src ? h('span', { class: 'n-tag', text: it.src }) : null, h('span', { class: 'n-tag', text: newsAgo(it.at) })),
      h('h2', { text: it.title }),
      ...paras.map((p) => h('p', { text: p })),
      it.why ? h('div', { class: 'n-why' }, h('b', { text: '💡 ليش يهمك؟' }), h('span', { text: it.why })) : null,
      h('div', { class: 'n-btns' },
        it.url ? h('a', { class: 'btn btn-primary', href: it.url, target: '_blank', rel: 'noopener noreferrer' }, '🔗 اقرأ المصدر') : null,
        h('button', { type: 'button', class: `btn${isSaved(it.id) ? ' on' : ''}`, onclick: () => toggleSave(it) }, isSaved(it.id) ? '🔖 محفوظ' : '🔖 حفظ'),
        h('button', { type: 'button', class: 'btn', 'aria-label': 'مشاركة', onclick: () => shareNews(it) }, '↗')),
      it.ai ? h('p', { class: 'n-ai', text: 'ملخّص بالذكاء الاصطناعي من المصدر وراجعته الإدارة ✓' }) : null));
  UI.digitize(el);
}

/* ---------- إشعار الموجز اليومي ---------- */
function notifyBtn() {
  if (!Platform.isNative) return null;
  const on = !!pref('newsNotify');
  return h('button', { type: 'button', class: `n-notify${on ? ' on' : ''}`, onclick: () => setNewsNotify(!on) }, on ? `🔔 إشعار الموجز ${UI.n(NEWS.meta?.hour ?? 8)}:٠٠ مفعّل` : '🔕 نبّهني بالموجز كل صباح');
}
async function setNewsNotify(on) {
  const LN = Platform.plugin('LocalNotifications');
  try {
    if (on) {
      const p = await LN.requestPermissions();
      if (p.display !== 'granted') return toast('اسمح للتطبيق بالإشعارات من إعدادات الجوال', { type: 'error' });
    }
    await LN.cancel({ notifications: [{ id: 770001 }] }).catch(() => {});
    if (on) {
      await LN.schedule({ notifications: [{ id: 770001, title: `☀️ ${NEWS.meta?.title || 'الأخبار'} — موجز اليوم`, body: 'أهم أخبار مفضلاتك جاهزة', schedule: { on: { hour: Number(NEWS.meta?.hour ?? 8), minute: 0 }, allowWhileIdle: true }, extra: { tab: 'news' }, smallIcon: 'ic_stat_nobleweb' }] });
    }
    await setPref({ newsNotify: on });
    toast(on ? 'بنرسل لك الموجز كل صباح ☀️' : 'أوقفنا إشعار الموجز', { type: 'success' });
  } catch (e) { toast('تعذّر ضبط الإشعار: ' + (e.message || e), { type: 'error' }); }
}
