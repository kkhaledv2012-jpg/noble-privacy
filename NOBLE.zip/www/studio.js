/* NOBLE — «🎬 استوديو NOBLE» (1.16)
 * محرر حر داخل قسم التصاميم: مقاسات جاهزة ومخصصة، نصوص، صور بإطارات، أشكال، ملصقات، فلاتر وتعديلات،
 * طبقات، تحريك لكل عنصر، صوت (مكتبة الإدارة أو من الجهاز) وتصدير صورة أو فيديو — كل شي على الجهاز.
 * توقيع NOBLE من نفس إعداد لوحة التحكم ← التصاميم ← «التوقيع».
 */
'use strict';
var Studio = (() => {
const mk = (html) => { const d = document.createElement('div'); d.className = 'st-root'; d.innerHTML = html; return d; };
const ED = mk('<section class="scr ed" id="st-ed">\n    <div class="ed-top">\n      <button type="button" class="ibtn" id="st-back" aria-label="رجوع">✕</button>\n      <button type="button" class="ibtn" id="st-undo" aria-label="تراجع"></button>\n      <button type="button" class="ibtn" id="st-redo" aria-label="إعادة"></button>\n      <span class="sp" id="st-ed-name"></span>\n      <button type="button" class="export" id="st-export">تصدير</button>\n    </div>\n    <div class="stage-wrap" id="st-sw">\n      <div class="stage" id="st-stage">\n        <canvas id="st-cv"></canvas>\n        <i class="tline" id="st-tline" hidden><i></i></i>\n        <i class="guide v" id="st-gv"></i><i class="guide h" id="st-gh"></i>\n        <div class="sel" id="st-sel" hidden>\n          <span class="hd del" data-h="del"></span><span class="hd dup" data-h="dup"></span>\n          <span class="hd rot" data-h="rot"></span><span class="hd scl" data-h="scl"></span><span class="hd edt" data-h="edt" hidden></span>\n        </div>\n      </div>\n      <button type="button" class="playbtn" id="st-play" hidden>▶ معاينة الحركة</button>\n    </div>\n    <div class="ctx" id="st-ctx" hidden></div>\n    <nav class="bar" id="st-bar"></nav>\n    <div class="panel" id="st-panel"><div class="p-h"><b id="st-p-t"></b><button type="button" class="ok" id="st-p-ok">✓</button></div><div class="p-b" id="st-p-b"></div></div>\n    <div class="exp" id="st-exp" hidden><div class="exp-c"><div class="pv"><img id="st-exp-img" alt=""><i id="st-exp-mask"></i></div><b id="st-exp-n">0%</b><p id="st-exp-p">يجهّز التصميم… لا تقفل الشاشة</p></div></div>\n  </section>\n  ');
const HOME = mk('<section class="scr home" id="st-home">\n    <div class="h-top"><h1>استوديو NOBLE<small>حرّر صورك وصمّم بحرية كاملة</small></h1></div>\n        <button type="button" class="newp" id="st-newp"><b>＋</b>مشروع جديد</button>\n    <div class="tools" id="st-tools"></div>\n    <div class="sec-h"><h2>ابدأ من فكرة ✨</h2><small>تفتح جاهزة للتعديل</small></div>\n    <div class="tpls" id="st-tpls"></div>\n    <div class="sec-h"><h2>مشاريعي</h2><small id="st-pcount"></small></div>\n    <div class="projs" id="st-projs"></div>\n  </section>\n  ');
const SH = mk('<div class="sheet-bg" id="st-sheet" hidden><div class="sheet" id="st-sheet-c"></div></div>\n');
ED.classList.add('st-ed-root');
ED.append(Object.assign(document.createElement('input'), { type: 'file', id: 'st-file', accept: 'image/*', hidden: true }), Object.assign(document.createElement('input'), { type: 'file', id: 'st-afile', accept: 'audio/*', hidden: true }));

const $ = (s) => ED.querySelector(s) || HOME.querySelector(s) || SH.querySelector(s) || document.querySelector(s);
const el = (tag, attrs = {}, ...kids) => { const e = document.createElement(tag); for (const [k, v] of Object.entries(attrs)) { if (v == null || v === false) continue; if (k === 'class') e.className = v; else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v); else if (k.startsWith('on')) e.addEventListener(k.slice(2), v); else if (k === 'text') e.textContent = v; else if (k === 'html') e.innerHTML = v; else e.setAttribute(k, v === true ? '' : v); } kids.flat().forEach((c) => c != null && c !== false && e.append(c.nodeType ? c : document.createTextNode(c))); return e; };
const N = (n) => String(n).replace(/\d/g, (d) => '٠١٢٣٤٥٦٧٨٩'[d]);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const uid = () => Math.random().toString(36).slice(2, 9);
const toast = (m, o) => (typeof window.toast === 'function' ? window.toast(m, o) : console.log(m));
const LS = { get(k, d) { try { return JSON.parse(localStorage.getItem(k)) ?? d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch { return false; } } };

/* ---------- أيقونات ---------- */
const P = {
  size: '<rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 3v3M16 3v3M4 9h16"/>',
  bg: '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M3 15l5-5 4 4 3-3 6 6"/><circle cx="16" cy="8" r="1.6"/>',
  text: '<path d="M5 6V4h14v2M12 4v16M9 20h6"/>',
  photo: '<rect x="3" y="5" width="18" height="15" rx="2"/><circle cx="9" cy="11" r="2"/><path d="M21 17l-5-5-9 8"/><path d="M17 2v6M14 5h6"/>',
  shape: '<circle cx="8" cy="8" r="5"/><rect x="11" y="11" width="10" height="10" rx="1.5"/>',
  sticker: '<path d="M20 12a8 8 0 1 1-8-8h3l5 5z"/><path d="M15 4v3a2 2 0 0 0 2 2h3"/><path d="M9 14c1 1.3 3 1.6 4.5.6M9.5 10h.01M14 10h.01"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  undo: '<path d="M9 14L4 9l5-5"/><path d="M4 9h10a6 6 0 0 1 0 12h-3"/>',
  redo: '<path d="M15 14l5-5-5-5"/><path d="M20 9H10a6 6 0 0 0 0 12h3"/>',
  trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  rot: '<path d="M20 12a8 8 0 1 1-2.3-5.6"/><path d="M20 4v5h-5"/>',
  scl: '<path d="M14 4h6v6M10 20H4v-6M20 4l-7 7M4 20l7-7"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="M14 6l4 4"/>',
  wand: '<path d="M4 20L16 8M14 4l1 3 3 1-3 1-1 3-1-3-3-1 3-1z"/>',
  collage: '<rect x="3" y="3" width="8" height="18" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="13" width="8" height="8" rx="1.5"/>',
  motion: '<path d="M5 3l14 9-14 9z"/><path d="M2 8h2M1 12h3M2 16h2"/>',
  music: '<path d="M9 18V5l11-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="17" cy="16" r="3"/>',
  video: '<rect x="3" y="6" width="13" height="12" rx="2"/><path d="M16 10l5-3v10l-5-3"/>',
};
const svg = (k, sw = 1.8) => `<svg class="ic" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="${sw}" stroke-linecap="round" stroke-linejoin="round">${P[k] || ''}</svg>`;

/* ---------- البيانات ---------- */
const SIZES = { post: ['كاروسيل انستقرام', 1080, 1350], story: ['ستوري', 1080, 1920], square: ['مربع', 1080, 1080], wide: ['يوتيوب', 1920, 1080], a4: ['A4 طباعة', 1240, 1754], cover: ['غلاف', 1500, 500] };
/* مقاساتي (المستخدم يضيف براحته) */
const mySizes = () => LS.get('noble-studio-sizes', []);
const sizeOf_ = (k) => SIZES[k] || (mySizes().find((x) => 'c:' + x.id === k) ? (() => { const c = mySizes().find((x) => 'c:' + x.id === k); return [c.name, c.w, c.h]; })() : null);
const COLORS = ['#FFFFFF', '#111111', '#F6D68E', '#FFB43D', '#FF4D9D', '#C8509C', '#8B45F0', '#2E5BFF', '#56C8FF', '#1FC7A0', '#16A34A', '#E5484D'];
const GRADS = [['#0B1030', '#22145A', '#4B1D7A'], ['#2B1055', '#D35D6E', '#F9A26C'], ['#0F2A4A', '#1C6E8C', '#5FD3C6'], ['#1A1206', '#5C4318', '#D9A441'], ['#00261A', '#006C35', '#2FA36B'], ['#3A0F2E', '#B83B7E', '#F7B2D9'], ['#0A0F3C', '#2E5BFF', '#8B45F0'], ['#F7F3EC', '#E9DFD0', '#CDBBA0'], ['#050505', '#1C1F26', '#3A3F4B'], ['#FF7EB3', '#FF758C', '#7AFCFF']];
const ADJ = [['b', 'سطوع', '☀️'], ['c', 'تباين', '◐'], ['s', 'تشبّع', '🎨'], ['warm', 'دفء', '🌡'], ['hue', 'صبغة', '🌈'], ['blur', 'ضبابية', '💧'], ['vig', 'أطراف', '◎'], ['fade', 'بهتان', '🌫']];
const FILTERS = [['none', 'أصلي', {}], ['vivid', 'حيوي', { s: 40, c: 15 }], ['warm', 'دافي', { warm: 55, s: 10 }], ['cool', 'بارد', { warm: -55 }], ['film', 'فيلم', { c: -12, s: -18, fade: 35, warm: 15 }], ['bw', 'أبيض وأسود', { s: -100, c: 15 }], ['noir', 'نوار', { s: -100, c: 45, b: -12, vig: 50 }], ['gold', 'ذهبي', { warm: 80, s: 20, b: 6 }], ['dream', 'حالم', { b: 12, s: -10, blur: 8, fade: 25 }], ['drama', 'درامي', { c: 40, s: -12, vig: 60, b: -8 }], ['night', 'ليلي', { b: -25, warm: -45, c: 20 }], ['retro', 'قديم', { warm: 45, s: -30, fade: 40 }]];
const SHAPES = { rect: 'مستطيل', round: 'ناعم', circle: 'دائرة', heart: 'قلب', star: 'نجمة', hex: 'سداسي', arch: 'قوس', line: 'خط', tri: 'مثلث', badge: 'ختم' };
const MASKS = { none: 'بدون', round: 'ناعم', circle: 'دائرة', arch: 'قوس', heart: 'قلب', hex: 'سداسي', star: 'نجمة' };
const STK = { 'مناسبات': ['🎉', '🎊', '🎈', '🎁', '🎂', '🥳', '🌙', '⭐', '✨', '🕌', '🏮', '🌟', '💐', '🌹', '🤍', '❤️'], 'تعبير': ['😍', '😂', '🥹', '😎', '🤩', '🙏', '👏', '💪', '🔥', '💯', '👀', '🤝'], 'أشكال': ['⚡', '💫', '🌈', '☁️', '🌸', '🍃', '💎', '👑', '🏆', '📍', '✅', '🎯'] };
const TPRE = [
  { n: 'عنوان ذهبي', t: 'عيد مبارك', font: 'amiri', size: 150, color: '#F6D68E', fx: 'gold' },
  { n: 'نيون', t: 'NOBLE', font: 'kufi', size: 120, color: '#56C8FF', fx: 'glow' },
  { n: 'شريط', t: 'عرض خاص', font: 'tajawal', size: 70, color: '#FFFFFF', fx: 'box', fxc: '#E5484D' },
  { n: 'بحدّ', t: 'جمعة مباركة', font: 'reem', size: 110, color: '#FFFFFF', fx: 'outline', fxc: '#111111' },
  { n: 'رقعة', t: 'ألف مبروك', font: 'ruqaa', size: 130, color: '#FFFFFF', fx: 'shadow' },
  { n: 'عادي', t: 'اكتب هنا', font: 'noor', size: 80, color: '#FFFFFF', fx: 'shadow' },
];

let S = null; // المشروع الحالي
const IMG = new Map(); // src → Image
const loadImg = (src) => { if (!src) return Promise.resolve(null); if (IMG.has(src)) return Promise.resolve(IMG.get(src)); return new Promise((res) => { const im = new Image(); im.onload = () => { IMG.set(src, im); res(im); }; im.onerror = () => res(null); im.src = src; }); };

/* صورة تجريبية (مرسومة بالكود) */
function samplePhoto(seed = 0) {
  const c = document.createElement('canvas'); c.width = 1080; c.height = 1350; const x = c.getContext('2d');
  const sets = [['#ffb26b', '#ff7b54', '#4a2c5a'], ['#9be7ff', '#4a90d9', '#1b2a4a'], ['#ffd6e7', '#c98bd8', '#2b1b48']][seed % 3];
  const g = x.createLinearGradient(0, 0, 0, 1350); g.addColorStop(0, sets[0]); g.addColorStop(0.55, sets[1]); g.addColorStop(1, sets[2]); x.fillStyle = g; x.fillRect(0, 0, 1080, 1350);
  const sun = x.createRadialGradient(700, 560, 10, 700, 560, 260); sun.addColorStop(0, 'rgba(255,250,220,1)'); sun.addColorStop(0.3, 'rgba(255,230,160,.8)'); sun.addColorStop(1, 'rgba(255,200,120,0)'); x.fillStyle = sun; x.fillRect(0, 0, 1080, 1350);
  const mt = (base, amp, col, k) => { x.fillStyle = col; x.beginPath(); x.moveTo(0, 1350); for (let i = 0; i <= 1080; i += 20) x.lineTo(i, base - Math.abs(Math.sin(i / k + seed)) * amp - Math.sin(i / 37) * 12); x.lineTo(1080, 1350); x.fill(); };
  mt(900, 220, 'rgba(60,30,80,.45)', 160); mt(1000, 160, 'rgba(40,20,60,.65)', 110);
  x.fillStyle = 'rgba(15,8,30,.92)'; x.beginPath(); x.moveTo(0, 1350); x.lineTo(0, 1120);
  for (let i = 0; i <= 1080; i += 135) { x.lineTo(i, 1110); x.arc(i + 67, 1100, 50, Math.PI, 0); }
  x.lineTo(1080, 1350); x.fill(); x.fillRect(470, 880, 26, 240); x.beginPath(); x.arc(483, 875, 20, 0, 7); x.fill();
  for (let i = 0; i < 60; i++) { x.fillStyle = `rgba(255,255,255,${Math.random() * 0.5})`; x.beginPath(); x.arc(Math.random() * 1080, Math.random() * 500, Math.random() * 2, 0, 7); x.fill(); }
  return c.toDataURL('image/jpeg', 0.86);
}

/* ---------- توقيع NOBLE: نفس إعداد لوحة التحكم ← التصاميم ← «التوقيع» ---------- */
let LOGO = null;
async function loadLogo() { const sg = typeof dsSign === 'function' ? dsSign(false) : null; LOGO = sg?.logoSrc ? await DesignKit.loadImg(sg.logoSrc) : null; }
const canHideSign = () => typeof dsCanHideSign === 'function' && dsCanHideSign();
/* ---------- رسم ---------- */
function shapePath(c, k, x, y, w, h) {
  c.beginPath();
  if (k === 'circle') { c.ellipse(x + w / 2, y + h / 2, w / 2, h / 2, 0, 0, Math.PI * 2); return; }
  if (k === 'round') { const r = Math.min(w, h) * 0.14; c.roundRect ? c.roundRect(x, y, w, h, r) : c.rect(x, y, w, h); return; }
  if (k === 'arch') { const r = w / 2; c.moveTo(x, y + h); c.lineTo(x, y + r); c.arc(x + r, y + r, r, Math.PI, 0); c.lineTo(x + w, y + h); c.closePath(); return; }
  if (k === 'hex') { for (let i = 0; i < 6; i++) { const a = Math.PI / 6 + i * Math.PI / 3, px = x + w / 2 + w / 2 * Math.cos(a), py = y + h / 2 + h / 2 * Math.sin(a); i ? c.lineTo(px, py) : c.moveTo(px, py); } c.closePath(); return; }
  if (k === 'tri') { c.moveTo(x + w / 2, y); c.lineTo(x + w, y + h); c.lineTo(x, y + h); c.closePath(); return; }
  if (k === 'star' || k === 'badge') { const n = k === 'star' ? 5 : 16, ri = k === 'star' ? 0.42 : 0.86; for (let i = 0; i < n * 2; i++) { const r = i % 2 ? ri : 1, a = -Math.PI / 2 + i * Math.PI / n; const px = x + w / 2 + Math.cos(a) * w / 2 * r, py = y + h / 2 + Math.sin(a) * h / 2 * r; i ? c.lineTo(px, py) : c.moveTo(px, py); } c.closePath(); return; }
  if (k === 'heart') { const cx = x + w / 2; c.moveTo(cx, y + h); c.bezierCurveTo(x - w * 0.05, y + h * 0.6, x - w * 0.02, y + h * 0.05, x + w * 0.27, y + h * 0.02); c.bezierCurveTo(x + w * 0.42, y, cx, y + h * 0.12, cx, y + h * 0.24); c.bezierCurveTo(cx, y + h * 0.12, x + w * 0.58, y, x + w * 0.73, y + h * 0.02); c.bezierCurveTo(x + w * 1.02, y + h * 0.05, x + w * 1.05, y + h * 0.6, cx, y + h); c.closePath(); return; }
  if (k === 'line') { c.rect(x, y + h / 2 - Math.max(2, h * 0.5) / 2, w, Math.max(2, h * 0.5)); return; }
  c.rect(x, y, w, h);
}
function filterOf(f = {}, U = 1080) {
  const o = [];
  if (f.b) o.push(`brightness(${1 + f.b / 100})`);
  if (f.c) o.push(`contrast(${1 + f.c / 100})`);
  if (f.s) o.push(`saturate(${Math.max(0, 1 + f.s / 100)})`);
  if (f.warm > 0) o.push(`sepia(${(f.warm / 100 * 0.4).toFixed(2)})`, `saturate(${1 + f.warm / 400})`);
  if (f.warm < 0) o.push(`hue-rotate(${Math.round(-f.warm / 100 * 20)}deg)`, `saturate(${1 + -f.warm / 1000})`);
  if (f.hue) o.push(`hue-rotate(${Math.round(f.hue * 1.8)}deg)`);
  if (f.blur > 0) o.push(`blur(${(f.blur / 100 * U * 0.02).toFixed(1)}px)`);
  return o.join(' ') || 'none';
}
const mergeF = (a = {}, b = {}) => { const o = { ...a }; for (const k in b) o[k] = (o[k] || 0) + b[k]; return o; };
const effF = (e) => mergeF(FILTERS.find((x) => x[0] === (e.flt || 'none'))[2], e.f || {});
function postFx(c, x, y, w, h, f) {
  if (f.fade > 0) { c.fillStyle = `rgba(235,225,215,${(f.fade / 100 * 0.35).toFixed(3)})`; c.fillRect(x, y, w, h); }
  if (f.vig > 0) { const g = c.createRadialGradient(x + w / 2, y + h / 2, Math.min(w, h) * 0.3, x + w / 2, y + h / 2, Math.hypot(w, h) / 2); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, `rgba(0,0,0,${(f.vig / 100 * 0.85).toFixed(2)})`); c.fillStyle = g; c.fillRect(x, y, w, h); }
}
function coverDraw(c, im, x, y, w, h, zoom = 1, px = 0, py = 0) {
  const iw = im.naturalWidth || im.width, ih = im.naturalHeight || im.height;
  const sc = Math.max(w / iw, h / ih) * zoom, dw = iw * sc, dh = ih * sc;
  c.drawImage(im, x + (w - dw) / 2 - px * (dw - w) / 2, y + (h - dh) / 2 - py * (dh - h) / 2, dw, dh);
}
const fam = (k) => DesignKit.family(k);
function textLines(c, e) {
  c.font = `${e.weight || 700} ${e.size}px ${fam(e.font)}, NobleUI, sans-serif`;
  const lines = String(e.text || ' ').split('\n');
  const lh = e.size * (e.lh || 1.35);
  const ws = lines.map((l) => c.measureText(l || ' ').width + (e.ls || 0) * l.length);
  return { lines, lh, ws, w: Math.max(...ws, e.size * 0.6), h: lines.length * lh };
}
const MC = document.createElement('canvas').getContext('2d');
function sizeOf(e) {
  if (e.type === 'text') { const m = textLines(MC, e); const pad = e.fx === 'box' ? e.size * 0.5 : e.size * 0.15; return [m.w + pad * 2, m.h + pad]; }
  if (e.type === 'sticker') return [e.size * 1.25, e.size * 1.25];
  return [e.w, e.h];
}
/* ---------- الحركة: دخول · مستمرة · خروج ---------- */
const EZ = (p) => 1 - Math.pow(1 - p, 3), BK = (p) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); };
const AN_IN = { none: ['بدون', '⛔'], fade: ['ظهور', '🌫'], rise: ['صعود', '⬆️'], drop: ['نزول', '⬇️'], zoom: ['تكبير', '🔍'], pop: ['قفزة', '💥'], slideR: ['من اليمين', '⬅️'], slideL: ['من اليسار', '➡️'], blur: ['ضبابي', '💧'], spin: ['دوران', '🌀'], type: ['كتابة', '⌨️'] };
const AN_LOOP = { none: ['بدون', '⛔'], float: ['طفو', '🎈'], pulse: ['نبض', '💓'], swing: ['تمايل', '🔔'], spin: ['لفّ', '🔄'], shake: ['اهتزاز', '📳'] };
const AN_OUT = { none: ['بدون', '⛔'], fade: ['اختفاء', '🌫'], zoom: ['تكبير', '🔍'], drop: ['سقوط', '⬇️'], slide: ['لليسار', '⬅️'] };
function animAt(e, t) {
  const a = e.anim || {}, o = { a: 1, dx: 0, dy: 0, s: 1, dr: 0, blur: 0, chars: 1 };
  const d = a.delay || 0, du = a.dur || 0.9, p = clamp((t - d) / du, 0, 1), E = EZ(p);
  switch (a.in) {
    case 'fade': o.a = E; break; case 'rise': o.a = E; o.dy = (1 - E) * 110; break; case 'drop': o.a = E; o.dy = -(1 - E) * 110; break;
    case 'zoom': o.a = E; o.s = 0.4 + 0.6 * E; break; case 'pop': o.a = clamp(p * 3, 0, 1); o.s = p > 0 ? 0.3 + 0.7 * BK(p) : 0.3; break;
    case 'slideR': o.a = E; o.dx = (1 - E) * S.W * 0.4; break; case 'slideL': o.a = E; o.dx = -(1 - E) * S.W * 0.4; break;
    case 'blur': o.a = E; o.blur = (1 - E) * 28; break; case 'spin': o.a = E; o.dr = -(1 - E) * 1.6; o.s = 0.5 + 0.5 * E; break;
    case 'type': o.chars = clamp((t - d) / Math.max(0.5, du * 2), 0, 1); o.a = t >= d ? 1 : 0; break;
  }
  const lt = Math.max(0, t - d - (a.in && a.in !== 'none' ? du : 0));
  switch (a.loop) { case 'float': o.dy += Math.sin(lt * 2) * 14; break; case 'pulse': o.s *= 1 + Math.sin(lt * 3.2) * 0.045; break; case 'swing': o.dr += Math.sin(lt * 2.4) * 0.07; break; case 'spin': o.dr += lt * 0.9; break; case 'shake': o.dx += Math.sin(lt * 28) * 4 * (Math.sin(lt * 1.3) > 0.6 ? 1 : 0); break; }
  if (S.audio?.react !== false && AUD.lvl > 0.02 && (a.in || a.loop)) o.s *= 1 + AUD.lvl * 0.07;
  if (a.out && a.out !== 'none') { const q = EZ(clamp((t - ((S.dur || 6) - 0.8)) / 0.7, 0, 1)); if (q > 0) { o.a *= 1 - q; if (a.out === 'zoom') o.s *= 1 + q * 0.5; if (a.out === 'drop') o.dy += q * 160; if (a.out === 'slide') o.dx -= q * S.W * 0.4; } }
  return o;
}
const hasAnim = () => S && S.els.some((e) => e.anim && ((e.anim.in && e.anim.in !== 'none') || (e.anim.loop && e.anim.loop !== 'none') || (e.anim.out && e.anim.out !== 'none')));
function drawEl(c, e, t) {
  if (e.hidden) return;
  const A = t != null && e.anim ? animAt(e, t) : null;
  if (A && A.a <= 0.001) return;
  c.save();
  c.translate(e.x + (A ? A.dx : 0), e.y + (A ? A.dy : 0)); c.rotate((e.rot || 0) + (A ? A.dr : 0)); c.scale((e.flip ? -1 : 1) * (e.scale || 1) * (A ? A.s : 1), (e.scale || 1) * (A ? A.s : 1));
  c.globalAlpha = (e.op ?? 1) * (A ? A.a : 1);
  const AB = A && A.blur > 0.3 ? ` blur(${A.blur.toFixed(1)}px)` : '';
  if (AB && e.type !== 'image') c.filter = AB.trim();
  if (e.shadow && e.type !== 'text') { c.shadowColor = 'rgba(0,0,0,.45)'; c.shadowBlur = 30; c.shadowOffsetY = 12; }
  if (e.type === 'image') {
    const im = IMG.get(e.src); const w = e.w, h = e.h;
    if (im) {
      const m = e.mask || 'none';
      if (m !== 'none' && e.shadow) { shapePath(c, m, -w / 2, -h / 2, w, h); c.fillStyle = '#000'; c.fill(); }
      c.shadowColor = 'transparent';
      c.save(); if (m !== 'none') { shapePath(c, m, -w / 2, -h / 2, w, h); c.clip(); }
      const f = effF(e); c.filter = (filterOf(f).replace('none', '') + AB).trim() || 'none';
      coverDraw(c, im, -w / 2, -h / 2, w, h, e.zoom || 1, e.px || 0, e.py || 0);
      c.filter = 'none'; postFx(c, -w / 2, -h / 2, w, h, f);
      c.restore();
      if (e.bw > 0) { c.lineWidth = e.bw; c.strokeStyle = e.bc || '#fff'; shapePath(c, m === 'none' ? 'rect' : m, -w / 2, -h / 2, w, h); c.stroke(); }
    }
  } else if (e.type === 'shape') {
    const w = e.w, h = e.h;
    shapePath(c, e.kind, -w / 2, -h / 2, w, h);
    if (e.grad) { const g = c.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2); g.addColorStop(0, e.fill); g.addColorStop(1, e.grad); c.fillStyle = g; } else c.fillStyle = e.fill;
    if (e.noFill) { c.lineWidth = e.sw || 8; c.strokeStyle = e.fill; c.stroke(); } else c.fill();
  } else if (e.type === 'sticker') {
    c.font = `${e.size}px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText(e.emoji, 0, e.size * 0.06);
  } else if (e.type === 'text') {
    const m = textLines(c, e);
    if (A && A.chars < 1) { let left = Math.ceil([...m.lines.join('')].length * A.chars); m.lines = m.lines.map((l) => { const ch = [...l], take = ch.slice(0, Math.max(0, left)); left -= ch.length; return take.join(''); }); }
    c.direction = 'rtl'; c.textBaseline = 'middle';
    const al = e.align || 'center';
    c.textAlign = al === 'center' ? 'center' : al === 'right' ? 'right' : 'left';
    const ax = al === 'center' ? 0 : al === 'right' ? m.w / 2 : -m.w / 2;
    let y = -m.h / 2 + m.lh / 2;
    if (e.fx === 'box') { c.fillStyle = e.fxc || '#E5484D'; m.lines.forEach((l, i) => { const w = m.ws[i], pad = e.size * 0.4, bx = al === 'center' ? -w / 2 : al === 'right' ? ax - w : ax; c.beginPath(); c.roundRect ? c.roundRect(bx - pad, y + i * m.lh - m.lh * 0.46, w + pad * 2, m.lh * 0.92, e.size * 0.22) : c.rect(bx - pad, y + i * m.lh - m.lh * 0.46, w + pad * 2, m.lh * 0.92); c.fill(); }); }
    if (e.fx === 'gold') { const g = c.createLinearGradient(0, -m.h / 2, 0, m.h / 2); g.addColorStop(0, '#FFF6CF'); g.addColorStop(0.45, '#F6D68E'); g.addColorStop(0.55, '#D9A441'); g.addColorStop(1, '#9C6B1E'); c.fillStyle = g; } else c.fillStyle = e.color;
    if (e.fx === 'glow') { c.shadowColor = e.color; c.shadowBlur = e.size * 0.6; }
    else if (e.fx === 'shadow' || e.fx === 'gold') { c.shadowColor = 'rgba(0,0,0,.45)'; c.shadowBlur = e.size * 0.15; c.shadowOffsetY = e.size * 0.05; }
    if (e.ls) c.letterSpacing = e.ls + 'px';
    m.lines.forEach((l, i) => {
      const yy = y + i * m.lh;
      if (e.fx === 'outline') { c.save(); c.shadowColor = 'transparent'; c.lineJoin = 'round'; c.lineWidth = e.size * 0.12; c.strokeStyle = e.fxc || '#111'; c.strokeText(l, ax, yy); c.restore(); }
      c.fillText(l, ax, yy); if (e.fx === 'glow') c.fillText(l, ax, yy);
    });
  }
  c.restore();
}
function drawBg(c, W, H, bg) {
  if (bg.type === 'grad') { const g = c.createLinearGradient(0, 0, W * 0.35, H); bg.c.forEach((col, i) => g.addColorStop(i / (bg.c.length - 1), col)); c.fillStyle = g; c.fillRect(0, 0, W, H); }
  else if (bg.type === 'image' && IMG.get(bg.src)) { const f = bg.f || {}; c.save(); c.filter = filterOf(f); coverDraw(c, IMG.get(bg.src), 0, 0, W, H); c.filter = 'none'; postFx(c, 0, 0, W, H, f); if (bg.dim) { c.fillStyle = `rgba(0,0,0,${bg.dim})`; c.fillRect(0, 0, W, H); } c.restore(); }
  else { c.fillStyle = bg.color || '#0B1030'; c.fillRect(0, 0, W, H); }
}
let NOSIGN = false; // المعاينات المصغرة بدون توقيع
function render(c, k = 1, t) {
  const { W, H } = S;
  c.save(); c.setTransform(k, 0, 0, k, 0, 0);
  drawBg(c, W, H, S.bg);
  S.els.forEach((e) => drawEl(c, e, t));
  const sg = typeof dsSign === 'function' ? dsSign(!!S.noSign) : null;
  if (sg && !NOSIGN) { c.save(); if (t != null) c.globalAlpha = clamp((t - 0.5) / 0.8, 0, 1); DesignKit.drawSign(c, W, H, sg, LOGO); c.restore(); }
  c.restore();
}

/* ---------- المحرر ---------- */
const cv = $('#st-cv'), cx = cv.getContext('2d');
let sel = null, K = 1, hist = [], hi = -1, panelKind = '';
const selEl = () => S.els.find((e) => e.id === sel);
function fit() {
  if (!S) return;
  const sw = $('#st-sw'), cs = getComputedStyle(sw);
  const aw = sw.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), ah = sw.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
  K = Math.max(0.05, Math.min(aw / S.W, ah / S.H));
  const w = Math.round(S.W * K), h = Math.round(S.H * K), dpr = Math.min(2, devicePixelRatio || 1);
  Object.assign($('#st-stage').style, { width: w + 'px', height: h + 'px' });
  cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
  draw();
}
let rq = 0;
function draw() { if (PLAY.on) return; cancelAnimationFrame(rq); rq = requestAnimationFrame(() => { if (!S) return; render(cx, cv.width / S.W); paintSel(); }); paintPlay(); }
/* معاينة الحركة */
const PLAY = { on: false, t0: 0, raf: 0, once: false };
function paintPlay() { const b = $('#st-play'); const on = !!S && hasAnim(); b.hidden = !on; b.textContent = PLAY.on ? '⏸ إيقاف' : '▶ معاينة الحركة'; $('#st-tline').hidden = !PLAY.on; }
function play(once) {
  if (!S) return;
  PLAY.on = true; PLAY.once = !!once; PLAY.t0 = performance.now(); $('#st-sel').hidden = true; paintPlay();
  const D = (S.dur || 6) + 0.6;
  const startA = () => { PLAY.aud?.stop(); PLAY.aud = null; if (S.audio && !once) getBuf(S.audio.id).then((b) => { if (PLAY.on && b) PLAY.aud = startAudio(b, S.audio, null, S.dur || 6); }); };
  startA();
  const step = (now) => {
    if (!PLAY.on) return;
    let t = (now - PLAY.t0) / 1000;
    if (t > D) { if (PLAY.once) { stopPlay(); return; } PLAY.t0 = now; t = 0; startA(); }
    if (PLAY.aud) level(); else AUD.lvl = 0;
    render(cx, cv.width / S.W, t); $('#st-tline i').style.width = (t / D * 100) + '%';
    PLAY.raf = requestAnimationFrame(step);
  };
  PLAY.raf = requestAnimationFrame(step);
}
function stopPlay() { PLAY.aud?.stop(); PLAY.aud = null; AUD.lvl = 0; PLAY.on = false; cancelAnimationFrame(PLAY.raf); paintPlay(); draw(); }
$('#st-play').onclick = () => (PLAY.on ? stopPlay() : play());
function paintSel() {
  const s = $('#st-sel'), e = selEl();
  if (!e || e.hidden) { s.hidden = true; return; }
  const [w, h] = sizeOf(e);
  s.hidden = false;
  Object.assign(s.style, { left: e.x * K + 'px', top: e.y * K + 'px', width: Math.max(24, w * (e.scale || 1) * K) + 'px', height: Math.max(24, h * (e.scale || 1) * K) + 'px', transform: `translate(-50%,-50%) rotate(${e.rot || 0}rad)` });
  s.querySelector('.edt').hidden = e.type !== 'text';
}
function snap() { const j = JSON.stringify({ W: S.W, H: S.H, size: S.size, dur: S.dur, bg: S.bg, els: S.els, audio: S.audio || null, noSign: !!S.noSign }); if (hist[hi] === j) return; hist = hist.slice(0, hi + 1); hist.push(j); if (hist.length > 60) hist.shift(); hi = hist.length - 1; paintHist(); autosave(); }
function restore(j) { const o = JSON.parse(j); Object.assign(S, o); if (sel && !selEl()) sel = null; fit(); paintCtx(); if (panelKind) openPanel(panelKind, true); }
function paintHist() { $('#st-undo').disabled = hi <= 0; $('#st-redo').disabled = hi >= hist.length - 1; }
$('#st-undo').innerHTML = svg('undo'); $('#st-redo').innerHTML = svg('redo');
$('#st-undo').onclick = () => { if (hi > 0) { hi--; restore(hist[hi]); paintHist(); autosave(); } };
$('#st-redo').onclick = () => { if (hi < hist.length - 1) { hi++; restore(hist[hi]); paintHist(); autosave(); } };
ED.querySelectorAll('.hd').forEach((h) => { h.innerHTML = svg({ del: 'trash', dup: 'copy', rot: 'rot', scl: 'scl', edt: 'edit' }[h.dataset.h], 2.2); });

/* اللمس: سحب، تدوير، تكبير، وإصبعين */
const ptrs = new Map(); let act = null;
const toStage = (ev) => { const r = $('#st-stage').getBoundingClientRect(); return { x: (ev.clientX - r.left) / K, y: (ev.clientY - r.top) / K }; };
function hit(p) {
  for (let i = S.els.length - 1; i >= 0; i--) {
    const e = S.els[i]; if (e.hidden || e.lock) continue;
    const [w, h] = sizeOf(e), sc = e.scale || 1, a = -(e.rot || 0);
    const dx = p.x - e.x, dy = p.y - e.y, lx = (dx * Math.cos(a) - dy * Math.sin(a)) / sc, ly = (dx * Math.sin(a) + dy * Math.cos(a)) / sc;
    const pad = 14 / K / sc;
    if (Math.abs(lx) <= w / 2 + pad && Math.abs(ly) <= h / 2 + pad) return e;
  }
  return null;
}
const guides = (v, hz) => { $('#st-gv').classList.toggle('on', v); $('#st-gh').classList.toggle('on', hz); };
$('#st-sw').addEventListener('pointerdown', (ev) => {
  if (!S || ev.target.closest('#st-play')) return;
  if (PLAY.on) stopPlay();
  const hd = ev.target.closest('.hd');
  ptrs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
  $('#st-sw').setPointerCapture?.(ev.pointerId);
  const e = selEl();
  if (hd && e) {
    const k = hd.dataset.h;
    if (k === 'del') { delSel(); return; }
    if (k === 'dup') { dupSel(); return; }
    if (k === 'edt') { openPanel('textedit'); return; }
    const p = toStage(ev);
    act = { k, e, ang0: Math.atan2(p.y - e.y, p.x - e.x), rot0: e.rot || 0, d0: Math.hypot(p.x - e.x, p.y - e.y), sc0: e.scale || 1 };
    return;
  }
  if (ptrs.size === 2 && e) { const [a, b] = [...ptrs.values()]; act = { k: 'pinch', e, d0: Math.hypot(a.x - b.x, a.y - b.y), a0: Math.atan2(b.y - a.y, b.x - a.x), sc0: e.scale || 1, rot0: e.rot || 0 }; return; }
  const p = toStage(ev), t = hit(p);
  if (t) { if (sel !== t.id) { sel = t.id; paintCtx(); if (panelKind && !['layers', 'bg', 'size'].includes(panelKind)) closePanel(); } act = { k: 'move', e: t, dx: t.x - p.x, dy: t.y - p.y, moved: false, t0: Date.now() }; }
  else { if (ev.target.closest('.stage') || ev.target === $('#st-sw')) { sel = null; paintCtx(); if (panelKind && !['layers', 'bg', 'size'].includes(panelKind)) closePanel(); } act = null; }
  draw();
});
$('#st-sw').addEventListener('pointermove', (ev) => {
  if (!ptrs.has(ev.pointerId)) return;
  ptrs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
  if (!act) return;
  const e = act.e;
  if (act.k === 'pinch' && ptrs.size >= 2) { const [a, b] = [...ptrs.values()]; e.scale = clamp(act.sc0 * Math.hypot(a.x - b.x, a.y - b.y) / act.d0, 0.08, 12); e.rot = act.rot0 + Math.atan2(b.y - a.y, b.x - a.x) - act.a0; draw(); return; }
  const p = toStage(ev);
  if (act.k === 'move') {
    let x = p.x + act.dx, y = p.y + act.dy; const th = 10 / K;
    const v = Math.abs(x - S.W / 2) < th, hz = Math.abs(y - S.H / 2) < th;
    if (v) x = S.W / 2; if (hz) y = S.H / 2; guides(v, hz);
    e.x = x; e.y = y; act.moved = true;
  } else if (act.k === 'rot') { let r = act.rot0 + Math.atan2(p.y - e.y, p.x - e.x) - act.ang0; const deg = r * 180 / Math.PI, near = Math.round(deg / 45) * 45; if (Math.abs(deg - near) < 4) r = near * Math.PI / 180; e.rot = r; }
  else if (act.k === 'scl') { e.scale = clamp(act.sc0 * Math.hypot(p.x - e.x, p.y - e.y) / act.d0, 0.08, 12); }
  draw();
});
const endPtr = (ev) => {
  ptrs.delete(ev.pointerId);
  if (act && ptrs.size === 0) {
    const tap = act.k === 'move' && !act.moved;
    if (tap && act.e.type === 'text' && lastTap.id === act.e.id && Date.now() - lastTap.t < 380) openPanel('textedit');
    if (!tap) snap();
    lastTap = tap ? { id: act.e.id, t: Date.now() } : {};
    act = null; guides(false, false);
  }
};
let lastTap = {};
$('#st-sw').addEventListener('dblclick', () => { const e = selEl(); if (e?.type === 'text') openPanel('textedit'); });
$('#st-sw').addEventListener('pointerup', endPtr); $('#st-sw').addEventListener('pointercancel', endPtr);
addEventListener('resize', fit);
if (typeof ResizeObserver !== 'undefined') new ResizeObserver(() => S && fit()).observe($('#st-sw'));

/* ---------- إضافة وحذف ---------- */
function add(e) { e.id = uid(); e.x = e.x ?? S.W / 2; e.y = e.y ?? S.H / 2; e.scale = e.scale ?? 1; e.rot = e.rot || 0; S.els.push(e); sel = e.id; snap(); paintCtx(); draw(); return e; }
function delSel() { const e = selEl(); if (!e) return; S.els = S.els.filter((x) => x !== e); sel = null; closePanel(); snap(); paintCtx(); draw(); toast('انحذف — تقدر ترجعه من ↶'); }
function dupSel() { const e = selEl(); if (!e) return; const c = { ...JSON.parse(JSON.stringify(e)), id: uid(), x: e.x + 40, y: e.y + 40 }; S.els.splice(S.els.indexOf(e) + 1, 0, c); sel = c.id; snap(); paintCtx(); draw(); }
async function addImage(src, asBg) {
  const im = await loadImg(src); if (!im) return toast('تعذّر فتح الصورة');
  if (asBg) { S.bg = { type: 'image', src, f: {}, dim: 0 }; snap(); draw(); return; }
  const ar = im.height / im.width, w = Math.min(S.W * 0.62, S.H * 0.62 / ar);
  add({ type: 'image', src, w, h: w * ar, f: {}, flt: 'none', mask: 'none', bw: 0, bc: '#FFFFFF' });
}
let fileFor = null;
$('#st-file').addEventListener('change', async () => {
  const f = $('#st-file').files[0]; $('#st-file').value = ''; if (!f) return;
  const src = await shrink(f, 2000); const want = fileFor; fileFor = null;
  if (want === 'replace') { const e = selEl(); if (e) { await loadImg(src); const im = IMG.get(src); e.src = src; e.h = e.w * im.height / im.width; e.zoom = 1; e.px = 0; e.py = 0; snap(); draw(); } return; }
  addImage(src, want === 'bg');
});
const pickFile = (k) => { fileFor = k; $('#st-file').click(); };
function shrink(file, max) { return new Promise((res) => { const u = URL.createObjectURL(file), im = new Image(); im.onload = () => { const s = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas'); c.width = Math.round(im.width * s); c.height = Math.round(im.height * s); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL(/png/.test(file.type) ? 'image/png' : 'image/jpeg', 0.9)); }; im.src = u; }); }

/* ---------- شريط الأدوات السفلي ---------- */
const MAIN = [['size', 'المقاس', 'size'], ['bg', 'الخلفية', 'bg'], ['text', 'نص', 'text'], ['photo', 'صورة', 'photo'], ['shape', 'أشكال', 'shape'], ['sticker', 'ملصقات', 'sticker'], ['motion', 'تحريك', 'motion'], ['audio', 'صوت', 'music'], ['layers', 'الطبقات', 'layers']];
function paintBar() { const b = $('#st-bar'); b.replaceChildren(...MAIN.map(([k, l, ic]) => el('button', { type: 'button', class: panelKind === k ? 'on' : '', onclick: () => (panelKind === k ? closePanel() : openPanel(k)) }, el('span', { html: svg(ic) }), l))); }
/* شريط السياق: يتغير حسب العنصر المختار */
function paintCtx() {
  const c = $('#st-ctx'), e = selEl();
  if (!e) { c.hidden = true; paintBar(); return; }
  c.hidden = false;
  const B = (l, fn, cls) => el('button', { type: 'button', class: cls || '', onclick: fn }, l);
  const common = [B('🔲 الشفافية', () => openPanel('opacity')), B('⇋ قلب', () => { e.flip = !e.flip; snap(); draw(); }), B('⬆ للأمام', () => order(1)), B('⬇ للخلف', () => order(-1)), B(e.lock ? '🔓 فك القفل' : '🔒 قفل', () => { e.lock = !e.lock; if (e.lock) sel = null; snap(); paintCtx(); draw(); toast(e.lock ? 'انقفل — ما يتحرك بالغلط (فكه من الطبقات)' : 'انفك القفل'); }), B('⧉ نسخ', dupSel), B('🗑 حذف', delSel, 'dang')];
  const kinds = {
    text: [B('🎬 حركة', () => openPanel('motion')), B('✏️ تعديل', () => openPanel('textedit')), B('🔤 الخط', () => openPanel('font')), B('🎨 اللون', () => openPanel('tcolor')), B('✨ تأثير', () => openPanel('tfx')), B('↔ تنسيق', () => openPanel('tfmt'))],
    image: [B('🎬 حركة', () => openPanel('motion')), B('🎚 تعديل', () => openPanel('adjust')), B('🎞 فلاتر', () => openPanel('filters')), B('✂️ قص وإطار', () => openPanel('mask')), B('🔁 استبدال', () => pickFile('replace')), B('🌅 اجعلها خلفية', () => { S.bg = { type: 'image', src: e.src, f: e.f || {}, dim: 0 }; S.els = S.els.filter((x) => x !== e); sel = null; snap(); paintCtx(); draw(); toast('صارت خلفية التصميم ✓'); })],
    shape: [B('🎬 حركة', () => openPanel('motion')), B('🎨 اللون', () => openPanel('scolor'))],
    sticker: [B('🎬 حركة', () => openPanel('motion'))],
  };
  c.replaceChildren(...kinds[e.type], ...common);
  paintBar();
}
function order(d) { const e = selEl(), i = S.els.indexOf(e), j = clamp(i + d, 0, S.els.length - 1); if (i === j) return toast(d > 0 ? 'هو بالفعل في الأمام' : 'هو بالفعل في الخلف'); S.els.splice(i, 1); S.els.splice(j, 0, e); snap(); draw(); }

/* ---------- اللوحات ---------- */
const TITLES = { audio: '🎵 الصوت', motion: '🎬 التحريك', size: '📐 المقاس', bg: '🖼 الخلفية', text: '✍️ أضف نص', photo: '📷 أضف صورة', shape: '⬟ أشكال', sticker: '😀 ملصقات', layers: '🗂 الطبقات', textedit: '✏️ النص', font: '🔤 الخط', tcolor: '🎨 لون النص', tfx: '✨ تأثير الكتابة', tfmt: '↔ التنسيق', adjust: '🎚 تعديل الصورة', filters: '🎞 فلاتر', mask: '✂️ قص وإطار', opacity: '🔲 الشفافية', scolor: '🎨 لون الشكل' };
let adjKey = 'b';
function openPanel(k, keep) {
  panelKind = k; $('#st-p-t').textContent = TITLES[k] || '';
  const b = $('#st-p-b'), e = selEl();
  const kids = (PANELS[k] || (() => []))(e) || [];
  b.replaceChildren(...kids.filter(Boolean));
  $('#st-panel').classList.add('on'); paintBar();
  if (!keep) b.scrollTop = 0;
  // التصميم يطلع فوق اللوحة — تشوف التعديل مباشرة
  const ph = $('#st-panel').offsetHeight, under = $('#st-bar').offsetHeight + ($('#st-ctx').hidden ? 0 : $('#st-ctx').offsetHeight);
  $('#st-sw').style.paddingBottom = Math.max(10, ph - under + 10) + 'px'; fit();
}
function closePanel() { stopPrev(); panelKind = ''; $('#st-panel').classList.remove('on'); $('#st-sw').style.paddingBottom = ''; paintBar(); if (S) fit(); }
$('#st-p-ok').onclick = () => { snap(); closePanel(); };
const colorRow = (cur, set) => el('div', { class: 'row' }, ...COLORS.map((col) => el('button', { type: 'button', class: 'sw' + (String(cur).toLowerCase() === col.toLowerCase() ? ' on' : ''), style: { background: col }, onclick: () => { set(col); snap(); draw(); openPanel(panelKind, true); } })),
  el('label', { class: 'sw pick', title: 'لون مخصص' }, (() => { const i = el('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(cur) ? cur : '#ffffff' }); i.addEventListener('input', () => { set(i.value); draw(); }); i.addEventListener('change', () => snap()); return i; })()));
const slider = (val, min, max, step, on, fmt = (v) => N(Math.round(v))) => { const r = el('input', { type: 'range', min, max, step, value: val }), o = el('em', { text: fmt(+val) }); r.addEventListener('input', () => { on(+r.value); o.textContent = fmt(+r.value); draw(); }); r.addEventListener('change', () => snap()); return el('div', { class: 'slider' }, r, o); };
const thumb = (fn, w = 66, h = 66) => { const c = el('canvas', { width: w * 2, height: h * 2, style: { width: w + 'px', height: h + 'px', maxWidth: '100%' } }); const x = c.getContext('2d'); x.scale(2, 2); fn(x, w, h); return c; };
const PANELS = {
  audio: () => {
    const A = S.audio;
    const list = sndList().map((it) => { const id = String(it.id), [ic, tl] = SND_TYPES[it.type || 'nature'] || SND_TYPES.nature;
      return el('div', { class: 'snd' + (String(A?.id) === id ? ' on' : ''), onclick: async () => {
        if (it.premium && !(typeof dsPremium === 'function' && dsPremium()) && !(typeof dsTry === 'function' && dsTry())) { if (typeof Pro !== 'undefined') Pro.gate('designs.premium', 'هذا الصوت للمشتركين ★'); return; }
        stopPrev(); try { await getBuf(id); } catch { return toast('تعذّر تحميل الصوت — تأكد من النت', { type: 'error' }); }
        S.audio = { id, name: it.title || 'صوت', vol: A?.vol ?? it.vol ?? 0.8, from: 0, fade: A?.fade ?? true, react: A?.react ?? true, premium: !!it.premium }; snap(); openPanel('audio', true); if (hasAnim()) play(); } },
      el('i', { text: ic }), el('div', {}, el('b', { text: (it.title || 'صوت') + (it.premium ? ' ★' : '') }), el('small', { text: tl + (it.dur ? ' · ' + mmss(it.dur) : '') })), el('button', { type: 'button', onclick: (ev) => { ev.stopPropagation(); prevSound(id, ev.currentTarget); } }, '▶')); });
    if (!list.length) list.push(el('div', { class: 'empty', text: '🎵 مكتبة الأصوات فاضية حالياً — الإدارة تضيف أصوات وأناشيد قريب. تقدر تضيف صوتك من جهازك.' }));
    const kids = [el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn', onclick: () => $('#st-afile').click() }, '📁 صوت من جهازي'), A ? el('button', { type: 'button', class: 'btn', onclick: () => { S.audio = null; stopPlay(); snap(); openPanel('audio', true); } }, '🔇 بدون صوت') : el('div')),
      el('div', { class: 'lbl', text: 'مكتبة NOBLE (الإدارة تضيف أصوات وأناشيد)' }), ...list];
    if (A) {
      const buf = AUD.bufs.get(A.id);
      if (A.mine) kids.splice(1, 0, el('div', { class: 'snd on' }, el('i', { text: '🎧' }), el('div', {}, el('b', { text: A.name }), el('small', { text: 'من جهازك' })), el('span')));
      const total = buf ? buf.duration : 30, D = S.dur || 6;
      const wc = el('canvas'), win = el('i', { class: 'win' }), r = el('input', { type: 'range', min: 0, max: Math.max(0, total - 1), step: 0.1, value: A.from || 0, 'data-keep': '1' }), hb = el('b', { text: mmss(A.from || 0) });
      const paintWin = () => { const f = (A.from || 0) / total; win.style.left = f * 100 + '%'; win.style.width = Math.min(1 - f, D / total) * 100 + '%'; };
      requestAnimationFrame(() => { const w = wc.clientWidth || 300, h = 64; wc.width = w * 2; wc.height = h * 2; const x = wc.getContext('2d'); if (!buf) return; const d = buf.getChannelData(0), n = w / 1.5, step = Math.floor(d.length / n); x.fillStyle = 'rgba(255,255,255,.45)'; for (let i = 0; i < n; i++) { let m = 0; for (let j = 0; j < step; j += 8) m = Math.max(m, Math.abs(d[i * step + j] || 0)); const bh = Math.max(2, m * h * 1.7); x.fillRect(i * 3, h - bh, 2, bh * 2); } });
      r.oninput = () => { A.from = +r.value; hb.textContent = mmss(A.from); paintWin(); };
      r.onchange = () => { snap(); if (hasAnim()) { stopPlay(); play(); } else { stopPrev(); getBuf(A.id).then((b) => { AUD.prev = startAudio(b, A, null, D); AUD.prev.id = A.id; setTimeout(stopPrev, D * 1000); }); } };
      paintWin();
      kids.push(el('div', { class: 'wave-h' }, el('span', { text: '⏱ يبدأ من' }), hb, el('span', { text: `المظلّل = ${N(D)} ثواني الفيديو` })), el('div', { class: 'wave' }, wc, win, r),
        el('div', { class: 'lbl', text: 'مستوى الصوت' }), slider(Math.round((A.vol ?? 0.8) * 100), 0, 100, 1, (v) => (A.vol = v / 100), (v) => N(v) + '٪'),
        el('label', { class: 'tog' }, el('span', {}, '🌊 دخول وخروج ناعم (Fade)'), (() => { const c = el('input', { type: 'checkbox' }); c.checked = A.fade !== false; c.onchange = () => { A.fade = c.checked; snap(); }; return c; })()),
        el('label', { class: 'tog' }, el('span', {}, '💓 الحركة تنبض مع الإيقاع', el('small', { text: 'العناصر المتحركة تتفاعل مع الصوت' })), (() => { const c = el('input', { type: 'checkbox' }); c.checked = A.react !== false; c.onchange = () => { A.react = c.checked; snap(); }; return c; })()),
        el('p', { class: 'note', text: hasAnim() ? '▶ اضغط «معاينة الحركة» تسمع الصوت مع التصميم — ويدخل في الفيديو عند التصدير.' : '💡 الصوت يدخل في الفيديو — حرّك عناصرك من «🎬 تحريك» عشان يصير فيديو.' }));
    }
    return kids;
  },
  motion: (e) => {
    const chips = (map, cur, set, filter) => el('div', { class: 'an-grid' }, ...Object.entries(map).filter(([k]) => !filter || filter(k)).map(([k, [l, ic]]) => el('button', { type: 'button', class: 'an' + ((cur || 'none') === k ? ' on' : ''), onclick: () => { set(k); snap(); openPanel('motion', true); play(true); } }, el('i', { text: ic }), l)));
    const glob = [el('div', { class: 'an-sec' }, el('h4', {}, '⏱ مدة الفيديو'), el('div', { class: 'row' }, ...[4, 6, 8, 10, 15].map((d) => el('button', { type: 'button', class: 'chip' + ((S.dur || 6) === d ? ' on' : ''), onclick: () => { S.dur = d; snap(); openPanel('motion', true); } }, N(d) + ' ثواني')))),
      el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn pri', onclick: () => { autoAnim(); snap(); openPanel('motion', true); play(true); toast('حرّكت كل العناصر بالترتيب ✨'); } }, '✨ حرّك الكل تلقائياً'), el('button', { type: 'button', class: 'btn', onclick: () => { S.els.forEach((x) => delete x.anim); snap(); stopPlay(); openPanel('motion', true); } }, 'شيل الحركة'))];
    if (!e) return [el('p', { class: 'note', text: 'اختر عنصر من التصميم عشان تحدد حركته — أو خلّها علينا: «حرّك الكل تلقائياً». التصميم المتحرك ينحفظ فيديو.' }), ...glob];
    const a = e.anim = e.anim || {};
    return [
      el('div', { class: 'an-sec' }, el('h4', {}, '⤵ الدخول', el('small', { text: 'كيف يظهر العنصر' })), chips(AN_IN, a.in, (k) => (a.in = k), (k) => k !== 'type' || e.type === 'text')),
      el('div', { class: 'an-sec' }, el('h4', {}, '🔁 مستمرة', el('small', { text: 'بعد ما يظهر' })), chips(AN_LOOP, a.loop, (k) => (a.loop = k))),
      el('div', { class: 'an-sec' }, el('h4', {}, '⤴ الخروج', el('small', { text: 'آخر الفيديو' })), chips(AN_OUT, a.out, (k) => (a.out = k))),
      el('div', { class: 'lbl', text: 'يبدأ بعد (ثواني)' }), slider(Math.round((a.delay || 0) * 10), 0, 60, 1, (v) => (a.delay = v / 10), (v) => N((v / 10).toFixed(1))),
      el('div', { class: 'lbl', text: 'سرعة الدخول' }), slider(Math.round((a.dur || 0.9) * 10), 3, 25, 1, (v) => (a.dur = v / 10), (v) => N((v / 10).toFixed(1)) + 'ث'),
      ...glob];
  },
  size: () => [sizeGrid(S.size, (k) => resize(k), () => openPanel('size', true)),
    el('p', { class: 'note', text: 'تغيير المقاس يحافظ على أماكن العناصر بالنسبة للتصميم. «＋ مقاس مخصص» يضيف أي مقاس تبيه ويحفظه في «مقاساتي».' })],
  bg: () => {
    const B = S.bg;
    return [
      el('div', { class: 'lbl', text: 'لون سادة' }), colorRow(B.type === 'color' ? B.color : '', (c) => { S.bg = { type: 'color', color: c }; }),
      el('div', { class: 'lbl', text: 'تدرّجات' }),
      el('div', { class: 'row' }, ...GRADS.map((g) => el('button', { type: 'button', class: 'sw' + (B.type === 'grad' && B.c.join() === g.join() ? ' on' : ''), style: { background: `linear-gradient(160deg, ${g.join(',')})`, width: '46px', height: '46px', borderRadius: '14px' }, onclick: () => { S.bg = { type: 'grad', c: g }; snap(); draw(); openPanel('bg', true); } }))),
      (() => { const lib = (typeof dsBgs === 'function' ? dsBgs() : []).filter((x) => !x.video); return lib.length ? el('div', { class: 'lbl', text: '✨ خلفيات NOBLE' }) : null; })(),
      (() => { const lib = (typeof dsBgs === 'function' ? dsBgs() : []).filter((x) => !x.video); return lib.length ? el('div', { class: 'row' }, ...lib.map((it) => el('button', { type: 'button', class: 'sw' + (B.src === it.url ? ' on' : ''), style: { width: '56px', height: '72px', borderRadius: '12px', background: `center/cover url("${it.url}")` }, onclick: async () => { if (it.premium && !(typeof dsPremium === 'function' && dsPremium()) && !(typeof dsTry === 'function' && dsTry())) { if (typeof Pro !== 'undefined') Pro.gate('designs.premium', 'هذي الخلفية للمشتركين ★'); return; } toast('يحمّل الخلفية…'); const src = await DesignKit.cachedURL(it.url); await addImage(src, true); S.bg.lib = it.id; openPanel('bg', true); } }, it.premium ? '★' : ''))) : null; })(),
      el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn', onclick: () => pickFile('bg') }, '📷 صورة من جهازي'), el('button', { type: 'button', class: 'btn', onclick: () => addImage(samplePhoto(Math.floor(Math.random() * 3)), true).then(() => openPanel('bg', true)) }, '🌄 صورة مثال')),
      B.type === 'image' ? el('div', { class: 'lbl', text: 'تعتيم الخلفية (يوضّح الكلام)' }) : null,
      B.type === 'image' ? slider(Math.round((B.dim || 0) * 100), 0, 80, 1, (v) => (B.dim = v / 100)) : null,
      B.type === 'image' ? el('div', { class: 'lbl', text: 'ضبابية الخلفية' }) : null,
      B.type === 'image' ? slider(B.f?.blur || 0, 0, 100, 1, (v) => { B.f = { ...(B.f || {}), blur: v }; }) : null,
    ];
  },
  text: () => [el('div', { class: 'tpres' }, ...TPRE.map((t) => el('button', { type: 'button', class: 'tpre', onclick: () => { add({ type: 'text', text: t.t, font: t.font, size: t.size, color: t.color, fx: t.fx, fxc: t.fxc, align: 'center' }); openPanel('textedit'); } },
    thumb((x, w, h) => { const e = { type: 'text', text: t.t, font: t.font, size: 26, color: t.color, fx: t.fx, fxc: t.fxc, x: w / 2, y: h / 2 }; drawEl(x, e); }, 150, 56)))),
    el('p', { class: 'note', text: 'اختر ستايل وبعدها اكتب كلامك — الخط واللون والتأثير تقدر تغيّرها كلها.' })],
  photo: () => [el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn pri', onclick: () => pickFile('add') }, '📷 من جهازي'), el('button', { type: 'button', class: 'btn', onclick: () => { addImage(samplePhoto(Math.floor(Math.random() * 3))); closePanel(); } }, '🌄 صورة مثال')),
    el('p', { class: 'note', text: 'الصورة تنضاف كطبقة فوق التصميم: تحركها، تكبّرها، تقصها بإطار، وتعدّل ألوانها. صورك تبقى على جهازك.' })],
  shape: () => [el('div', { class: 'grid5' }, ...Object.entries(SHAPES).map(([k, l]) => el('button', { type: 'button', class: 'tile', onclick: () => { add({ type: 'shape', kind: k, w: k === 'line' ? 600 : 360, h: k === 'line' ? 14 : k === 'rect' || k === 'round' ? 240 : 360, fill: k === 'line' ? '#F6D68E' : '#56C8FF' }); closePanel(); } },
    thumb((x, w, h) => { x.fillStyle = '#56C8FF'; shapePath(x, k, 8, k === 'line' ? h / 2 - 3 : 8, w - 16, k === 'line' ? 6 : h - 16); x.fill(); }, 40, 40), l)))],
  sticker: () => Object.entries(STK).flatMap(([cat, list]) => [el('div', { class: 'lbl', text: cat }), el('div', { class: 'grid5' }, ...list.map((s) => el('button', { type: 'button', class: 'stk', onclick: () => { add({ type: 'sticker', emoji: s, size: 220 }); closePanel(); } }, s)))]),
  layers: () => S.els.length ? [...S.els].reverse().map((e) => el('div', { class: 'layer' + (e.id === sel ? ' on' : '') },
    thumb((x, w, h) => { const [ew, eh] = sizeOf(e); const k = Math.min(w / ew, h / eh) * 0.9; x.translate(w / 2, h / 2); x.scale(k, k); drawEl(x, { ...e, x: 0, y: 0, rot: 0, scale: 1, hidden: false, op: 1 }); }, 44, 44),
    el('b', { text: e.type === 'text' ? e.text.split('\n')[0] : e.type === 'image' ? 'صورة' : e.type === 'sticker' ? 'ملصق ' + e.emoji : 'شكل: ' + SHAPES[e.kind], onclick: () => { if (e.lock) return toast('مقفول — فكّه أول 🔒'); sel = e.id; paintCtx(); draw(); openPanel('layers', true); } }),
    el('button', { type: 'button', title: 'إظهار/إخفاء', onclick: () => { e.hidden = !e.hidden; snap(); draw(); openPanel('layers', true); } }, e.hidden ? '🙈' : '👁'),
    el('button', { type: 'button', title: 'قفل', onclick: () => { e.lock = !e.lock; if (e.lock && sel === e.id) sel = null; snap(); paintCtx(); draw(); openPanel('layers', true); } }, e.lock ? '🔒' : '🔓'),
    el('button', { type: 'button', title: 'للأمام', onclick: () => { const i = S.els.indexOf(e); if (i < S.els.length - 1) { S.els.splice(i, 1); S.els.splice(i + 1, 0, e); snap(); draw(); openPanel('layers', true); } } }, '⬆'))) : [el('div', { class: 'empty', text: 'التصميم فاضي — أضف نص أو صورة أو شكل من الشريط تحت.' })],
  textedit: (e) => { if (!e) return []; const ta = el('textarea', { class: 'ta', placeholder: 'اكتب هنا…' }); ta.value = e.text; ta.addEventListener('input', () => { e.text = ta.value || ' '; draw(); }); ta.addEventListener('change', () => snap()); setTimeout(() => { ta.focus(); ta.select(); }, 280); return [ta, el('p', { class: 'note', text: 'Enter = سطر جديد. اسحب النص على التصميم، والمقبض الأيسر تحت يكبّره، واللي فوق يدوّره.' })]; },
  font: (e) => [el('div', { class: 'row' }, ...Object.entries(DesignKit.FONTS).map(([k, F]) => { const b = el('button', { type: 'button', class: 'fontb' + ((e.font || 'noor') === k ? ' on' : ''), onclick: async () => { if (F.premium && !(typeof dsPremium === 'function' && dsPremium()) && !(typeof dsTry === 'function' && dsTry())) { if (typeof Pro !== 'undefined') Pro.gate('designs.premium', 'هذا الخط للمشتركين ★'); return; } await DesignKit.ensureFont(k); e.font = k; e.weight = null; snap(); draw(); openPanel('font', true); } }, el('b', { text: 'أبجد', style: { fontFamily: F.fam, fontWeight: 700 } }), el('small', { text: (F.name || k) + (F.premium ? ' ★' : '') })); if (F.url) DesignKit.ensureFont(k); return b; })),
    Object.keys(DesignKit.FONTS).length < 4 ? el('p', { class: 'note', text: 'الخطوط تزيد كل ما أضافت الإدارة خطوط في مكتبة التصاميم.' }) : null,
    el('div', { class: 'lbl', text: 'الحجم' }), slider(e.size, 24, 300, 1, (v) => (e.size = v))],
  tcolor: (e) => [colorRow(e.color, (c) => (e.color = c))],
  tfx: (e) => [el('div', { class: 'row' }, ...[['shadow', 'ظل'], ['none', 'بدون'], ['outline', 'حدّ'], ['box', 'شريط'], ['gold', 'ذهبي'], ['glow', 'توهّج']].map(([k, l]) => el('button', { type: 'button', class: 'chip' + ((e.fx || 'none') === k ? ' on' : ''), onclick: () => { e.fx = k; snap(); draw(); openPanel('tfx', true); } }, l))),
    ['outline', 'box'].includes(e.fx) ? el('div', { class: 'lbl', text: e.fx === 'box' ? 'لون الشريط' : 'لون الحدّ' }) : null,
    ['outline', 'box'].includes(e.fx) ? colorRow(e.fxc || '#111111', (c) => (e.fxc = c)) : null],
  tfmt: (e) => [el('div', { class: 'row' }, ...[['right', 'يمين'], ['center', 'وسط'], ['left', 'يسار']].map(([k, l]) => el('button', { type: 'button', class: 'chip' + ((e.align || 'center') === k ? ' on' : ''), onclick: () => { e.align = k; snap(); draw(); openPanel('tfmt', true); } }, l))),
    el('div', { class: 'lbl', text: 'تباعد الأسطر' }), slider(Math.round((e.lh || 1.35) * 100), 90, 220, 1, (v) => (e.lh = v / 100), (v) => N((v / 100).toFixed(2))),
    el('div', { class: 'lbl', text: 'تباعد الحروف (للإنجليزي)' }), slider(e.ls || 0, 0, 40, 1, (v) => (e.ls = v))],
  adjust: (e) => { const f = e.f = e.f || {}; const ics = el('div', { class: 'adj-ics' }, ...ADJ.map(([k, l, ic]) => el('button', { type: 'button', class: 'adj-ic' + (adjKey === k ? ' on' : '') + (f[k] ? ' ch' : ''), onclick: () => { adjKey = k; openPanel('adjust', true); } }, el('i', { text: ic }), l)));
    const [mn] = ['blur', 'vig', 'fade'].includes(adjKey) ? [0] : [-100];
    return [ics, slider(f[adjKey] || 0, mn, 100, 1, (v) => { f[adjKey] = v; }), el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn', onclick: () => { e.f = {}; snap(); draw(); openPanel('adjust', true); } }, '↺ رجّع الأصل'), el('button', { type: 'button', class: 'btn', onmousedown: () => {}, onclick: () => { const keep = e.f; e.f = {}; draw(); setTimeout(() => { e.f = keep; draw(); }, 700); } }, '👁 قارن'))]; },
  filters: (e) => { const im = IMG.get(e.src); return [el('div', { class: 'row' }, ...FILTERS.map(([k, l, f]) => el('button', { type: 'button', class: 'flt' + ((e.flt || 'none') === k ? ' on' : ''), onclick: () => { e.flt = k; snap(); draw(); openPanel('filters', true); } },
    thumb((x, w, h) => { if (!im) return; x.filter = filterOf(f, 66); coverDraw(x, im, 0, 0, w, h); x.filter = 'none'; postFx(x, 0, 0, w, h, f); }), l))), el('p', { class: 'note', text: 'بعد الفلتر تقدر تضبط أكثر من «🎚 تعديل».' })]; },
  mask: (e) => [el('div', { class: 'lbl', text: 'شكل القص' }), el('div', { class: 'grid4' }, ...Object.entries(MASKS).map(([k, l]) => el('button', { type: 'button', class: 'tile' + ((e.mask || 'none') === k ? ' on' : ''), onclick: () => { e.mask = k; if (['circle', 'heart', 'hex', 'star'].includes(k) && Math.abs(e.w - e.h) > 2) { const s = Math.min(e.w, e.h); e.w = s; e.h = k === 'heart' ? s * 0.92 : s; } snap(); draw(); openPanel('mask', true); } }, thumb((x, w, h) => { x.fillStyle = '#56C8FF'; shapePath(x, k === 'none' ? 'rect' : k, 6, 6, w - 12, h - 12); x.fill(); }, 36, 36), l))),
    el('div', { class: 'lbl', text: 'تكبير الصورة داخل الإطار' }), slider(Math.round((e.zoom || 1) * 100), 100, 300, 1, (v) => (e.zoom = v / 100), (v) => N((v / 100).toFixed(1)) + '×'),
    el('div', { class: 'lbl', text: 'تحريك داخل الإطار ↔' }), slider(Math.round((e.px || 0) * 100), -100, 100, 1, (v) => (e.px = v / 100)),
    el('div', { class: 'lbl', text: 'تحريك داخل الإطار ↕' }), slider(Math.round((e.py || 0) * 100), -100, 100, 1, (v) => (e.py = v / 100)),
    el('div', { class: 'lbl', text: 'حدّ الإطار' }), slider(e.bw || 0, 0, 40, 1, (v) => (e.bw = v)), colorRow(e.bc || '#FFFFFF', (c) => (e.bc = c)),
    el('label', { class: 'chip', style: { display: 'inline-flex', alignItems: 'center', gap: '8px', width: 'max-content' } }, (() => { const c = el('input', { type: 'checkbox' }); c.checked = !!e.shadow; c.onchange = () => { e.shadow = c.checked; snap(); draw(); }; return c; })(), 'ظل خلف الصورة')],
  opacity: (e) => [slider(Math.round((e.op ?? 1) * 100), 5, 100, 1, (v) => (e.op = v / 100), (v) => N(v) + '٪')],
  scolor: (e) => [colorRow(e.fill, (c) => (e.fill = c)), el('div', { class: 'lbl', text: 'تدرّج للون ثاني (اختياري)' }), colorRow(e.grad || '', (c) => (e.grad = c)), el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn', onclick: () => { e.grad = null; snap(); draw(); openPanel('scolor', true); } }, 'بدون تدرّج'), el('button', { type: 'button', class: 'btn', onclick: () => { e.noFill = !e.noFill; snap(); draw(); openPanel('scolor', true); } }, e.noFill ? '⬛ معبّى' : '⬜ حدّ فقط'))],
};
/* ---------- الصوت ---------- */
const AUD = { ctx: null, bufs: new Map(), raw: new Map(), src: null, gain: null, an: null, data: null, lvl: 0, prev: null };
const actx = () => (AUD.ctx = AUD.ctx || new (window.AudioContext || window.webkitAudioContext)());
function wav(sec, sr, fn) { const n = Math.floor(sr * sec), b = new ArrayBuffer(44 + n * 2), v = new DataView(b), w = (o, t) => [...t].forEach((ch, i) => v.setUint8(o + i, ch.charCodeAt(0)));
  w(0, 'RIFF'); v.setUint32(4, 36 + n * 2, true); w(8, 'WAVEfmt '); v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true); v.setUint32(24, sr, true); v.setUint32(28, sr * 2, true); v.setUint16(32, 2, true); v.setUint16(34, 16, true); w(36, 'data'); v.setUint32(40, n * 2, true);
  for (let i = 0; i < n; i++) v.setInt16(44 + i * 2, clamp(fn(i / sr, i), -1, 1) * 22000, true); return b; }
const SND_TYPES = { nature: ['🌿', 'طبيعي'], nasheed: ['🎶', 'نشيد'], ambient: ['✨', 'أجواء'], effect: ['🔔', 'مؤثر'] };
const sndList = () => (typeof dsSounds === 'function' ? dsSounds() : []);
const mmss = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
async function getBuf(id) {
  if (AUD.bufs.has(id)) return AUD.bufs.get(id);
  let raw = AUD.raw.get(id);
  if (!raw) { const s = sndList().find((x) => String(x.id) === String(id)); if (!s) return null; const src = await DesignKit.cachedURL(s.url); raw = await (await fetch(src)).arrayBuffer(); AUD.raw.set(id, raw); }
  const buf = await actx().decodeAudioData(raw.slice(0)); AUD.bufs.set(id, buf); return buf;
}
/* تشغيل الصوت (معاينة أو تصدير) مع بداية ودخول/خروج ناعم */
function startAudio(buf, a, dest, len) {
  const c = actx(); c.resume();
  const src = c.createBufferSource(); src.buffer = buf; src.loop = true; src.loopStart = 0; src.loopEnd = buf.duration;
  const g = c.createGain(), an = c.createAnalyser(); an.fftSize = 256;
  const v = a.vol ?? 0.8, now = c.currentTime, fi = a.fade !== false ? 1.2 : 0.05, fo = a.fade !== false ? 1.6 : 0.1;
  g.gain.setValueAtTime(0, now); g.gain.linearRampToValueAtTime(v, now + fi);
  if (len) { g.gain.setValueAtTime(v, now + Math.max(fi, len - fo)); g.gain.linearRampToValueAtTime(0, now + len); }
  src.connect(g); g.connect(an); an.connect(dest || c.destination);
  src.start(0, Math.min(a.from || 0, buf.duration - 0.1));
  AUD.an = an; AUD.data = new Uint8Array(an.frequencyBinCount);
  return { stop() { try { src.stop(); } catch { /* لا شيء */ } src.disconnect(); g.disconnect(); } };
}
const level = () => { if (!AUD.an) return 0; AUD.an.getByteFrequencyData(AUD.data); let s = 0; for (let i = 2; i < 30; i++) s += AUD.data[i]; AUD.lvl = AUD.lvl * 0.6 + Math.min(1, s / (28 * 170)) * 0.4; return AUD.lvl; };
$('#st-afile').addEventListener('change', async () => {
  const f = $('#st-afile').files[0]; $('#st-afile').value = ''; if (!f) return;
  if (f.size > 25e6) return toast('الملف كبير — أقصى شي ٢٥ ميجا');
  try { const raw = await f.arrayBuffer(); const id = 'up:' + uid(); AUD.raw.set(id, raw); await getBuf(id); S.audio = { id, name: f.name.replace(/\.[^.]+$/, '').slice(0, 30), vol: 0.8, from: 0, fade: true, react: true, mine: true }; snap(); openPanel('audio', true); toast('انضاف صوتك ✓'); }
  catch { toast('ما قدرت أقرأ هالملف — جرّب MP3'); }
});
function stopPrev() { AUD.prev?.stop(); AUD.prev = null; ED.querySelectorAll('.snd button').forEach((b) => (b.textContent = '▶')); }
async function prevSound(id, btn) { const was = AUD.prev?.id === id; stopPrev(); if (was) return; btn.textContent = '…'; let buf; try { buf = await getBuf(id); } catch { btn.textContent = '▶'; return toast('تعذّر تحميل الصوت', { type: 'error' }); } AUD.prev = startAudio(buf, { vol: 0.8, from: 0, fade: false }, null, 0); AUD.prev.id = id; btn.textContent = '⏸'; }
/* حركة تلقائية مرتبة حسب نوع كل عنصر */
function autoAnim() {
  const order = [...S.els].sort((a, b) => (a.type === 'image' ? 0 : a.type === 'shape' ? 1 : a.type === 'text' ? 2 : 3) - (b.type === 'image' ? 0 : b.type === 'shape' ? 1 : b.type === 'text' ? 2 : 3) || a.y - b.y);
  order.forEach((e, i) => { e.anim = { in: e.type === 'image' ? 'zoom' : e.type === 'text' ? (i % 2 ? 'rise' : 'blur') : e.type === 'sticker' ? 'pop' : 'fade', loop: e.type === 'sticker' ? 'float' : e.type === 'image' ? 'none' : 'none', out: 'none', delay: +(0.2 + i * 0.45).toFixed(2), dur: e.type === 'text' ? 1 : 0.8 }; });
}
function resize(k) {
  const [, w, h] = sizeOf_(k) || [0, S.W, S.H], fx = w / S.W, fy = h / S.H, f = Math.min(fx, fy);
  S.els.forEach((e) => { e.x *= fx; e.y *= fy; e.scale = (e.scale || 1) * f; });
  S.size = k; S.W = w; S.H = h; snap(); fit(); openPanel('size', true);
}

/* ---------- التصدير ---------- */
$('#st-export').onclick = () => {
  const sgc = typeof dsCfg === 'function' ? dsCfg().sign : null;
  const signRow = sgc?.on ? el('div', { class: 'signrow' }, el('div', {}, el('b', { text: '✍️ توقيع NOBLE' }), el('small', { text: sgc.paidHide ? (canHideSign() ? 'أنت مشترك — تقدر تخفيه' : 'يظهر على التصميم — إخفاؤه للمشتركين ★') : 'يظهر على كل تصميم' })),
    sgc.paidHide ? (canHideSign() ? (() => { const c = el('input', { type: 'checkbox' }); c.checked = !S.noSign; c.style.cssText = 'width:44px;height:24px;accent-color:#56C8FF'; c.onchange = () => { S.noSign = !c.checked; snap(); draw(); }; return c; })()
      : el('button', { type: 'button', class: 'chip', onclick: () => { closeSheet(); if (typeof Pro !== 'undefined') Pro.gate('designs.nosign', 'إخفاء التوقيع للمشتركين ★'); } }, '★ إخفاء')) : null) : null;
  const fmt = { v: 'png' };
  const fmts = el('div', { class: 'row' }, ...[['png', 'PNG أعلى جودة'], ['jpg', 'JPG حجم أصغر']].map(([k, l]) => el('button', { type: 'button', class: 'chip' + (k === 'png' ? ' on' : ''), onclick: (ev) => { fmt.v = k; fmts.querySelectorAll('.chip').forEach((b) => b.classList.toggle('on', b === ev.currentTarget)); } }, l)));
  const vid = hasAnim() || S.audio;
  sheet([el('h3', { text: 'تصدير التصميم' }), signRow,
    el('div', { class: 'lbl', text: '🖼 صورة' }), fmts,
    el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn pri', onclick: () => doExport(fmt.v, 'share') }, '↗ مشاركة'), el('button', { type: 'button', class: 'btn', onclick: () => doExport(fmt.v, 'save') }, '⬇️ حفظ في الجهاز')),
    vid ? el('div', { class: 'lbl', text: `🎬 فيديو ${S.audio ? 'مع الصوت 🎵' : 'متحرك'} — ${N(S.dur || 6)} ثواني` }) : el('p', { class: 'note', text: '💡 حرّك العناصر من «🎬 تحريك» أو أضف صوت وتقدر تصدّره فيديو.' }),
    vid ? el('div', { class: 'two' }, el('button', { type: 'button', class: 'btn pri', style: { background: 'linear-gradient(135deg,#E5487A,#8B45F0)' }, onclick: () => exportVideo('share') }, '↗ مشاركة الفيديو'), el('button', { type: 'button', class: 'btn', onclick: () => exportVideo('save') }, '⬇️ حفظ الفيديو')) : null,
    el('button', { type: 'button', class: 'btn', onclick: () => { saveProject(true); closeSheet(); } }, '💾 احفظ في مشاريعي فقط')]);
};
const deliver = async (blob, ext, how) => {
  const name = `noble-studio-${Date.now().toString(36)}.${ext}`;
  if (typeof dsDeliver === 'function') return dsDeliver(blob, name, how, 'تصميم NOBLE');
  const u = URL.createObjectURL(blob), a = el('a', { href: u, download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(u), 60000);
};
const usedMark = (how, video) => {
  try { if (S.audio?.id && !String(S.audio.id).startsWith('up:') && typeof Cloud !== 'undefined') Cloud.designUsed(S.audio.id); } catch { /* لا شيء */ }
  try { Sync?.event?.('studio', { how, video: !!video, size: S.size }); } catch { /* لا شيء */ }
  if (typeof markActive === 'function') markActive('design');
  if (typeof buzz === 'function') buzz('success');
};
async function doExport(fmt, how) {
  if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
  closeSheet();
  const c = document.createElement('canvas'); c.width = S.W; c.height = S.H; render(c.getContext('2d'), 1);
  $('#st-exp-img').src = c.toDataURL('image/jpeg', 0.5); $('#st-exp').hidden = false; $('#st-exp-p').textContent = 'يجهّز التصميم…';
  const t0 = performance.now(), D = 700;
  const blobP = new Promise((r) => c.toBlob(r, fmt === 'png' ? 'image/png' : 'image/jpeg', 0.92));
  await new Promise((res) => { const step = (now) => { const p = Math.min(1, (now - t0) / D); $('#st-exp-n').textContent = N(Math.round(p * 100)) + '٪'; $('#st-exp-mask').style.clipPath = `inset(0 0 0 ${p * 100}%)`; p < 1 ? requestAnimationFrame(step) : res(); }; requestAnimationFrame(step); });
  const blob = await blobP;
  $('#st-exp').hidden = true;
  if (!blob) return toast('تعذّر تجهيز الصورة', { type: 'error' });
  try { await deliver(blob, fmt, how); usedMark(how); saveProject(false, true); } catch { /* أُلغيت */ }
}
/* تصدير فيديو: نسجّل التصميم المتحرك بالوقت الحقيقي (مع الصوت) */
async function exportVideo(how) {
  if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
  closeSheet(); stopPlay();
  const withA = !!S.audio;
  const type = typeof MotionKit !== 'undefined' && MotionKit.bestType ? MotionKit.bestType(withA) : (['video/mp4', 'video/webm'].find((x) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(x)));
  if (!type) return toast('جهازك ما يدعم حفظ الفيديو — احفظه صورة', { type: 'error' });
  const k = Math.min(1, 1080 / Math.max(S.W, S.H)), c = document.createElement('canvas'); c.width = Math.round(S.W * k / 2) * 2; c.height = Math.round(S.H * k / 2) * 2;
  // أندرويد يوقف إطارات اللوحة المخفية — نثبّتها في الصفحة ونرسل كل إطار يدوياً
  Object.assign(c.style, { position: 'fixed', left: 0, top: 0, width: '2px', height: '2px', opacity: 0.01, pointerEvents: 'none', zIndex: -1 }); document.body.append(c);
  const x = c.getContext('2d'); const D = (S.dur || 6) + 0.3;
  render(x, c.width / S.W, D * 0.6); $('#st-exp-img').src = c.toDataURL('image/jpeg', 0.6);
  render(x, c.width / S.W, 0);
  $('#st-exp').hidden = false; $('#st-exp-p').textContent = 'يسجّل الفيديو… لا تقفل الشاشة';
  const manual = typeof CanvasCaptureMediaStreamTrack !== 'undefined' && 'requestFrame' in CanvasCaptureMediaStreamTrack.prototype;
  const stream = c.captureStream(manual ? 0 : 30), vt = stream.getVideoTracks()[0];
  let wake = null; try { navigator.wakeLock?.request('screen').then((w) => { wake = w; }).catch(() => {}); } catch { /* لا شيء */ }
  let aud = null;
  if (withA) { try { const b = await getBuf(S.audio.id), dst = actx().createMediaStreamDestination(); dst.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr)); aud = { b, dst }; } catch { toast('الصوت ما اشتغل — بيتصدّر بدونه'); } }
  const rec = new MediaRecorder(stream, { mimeType: type, videoBitsPerSecond: 5e6, ...(aud ? { audioBitsPerSecond: 128000 } : {}) }), chunks = [];
  rec.ondataavailable = (ev) => ev.data && ev.data.size && chunks.push(ev.data);
  const done = new Promise((res) => (rec.onstop = res));
  rec.start(250); const t0 = performance.now();
  const player = aud ? startAudio(aud.b, S.audio, aud.dst, D) : null;
  await new Promise((res) => {
    let fin = false, last = -1;
    const tick = () => { if (fin) return; const now = performance.now(); if (last >= 0 && now - last < 20) return; last = now; const t = (now - t0) / 1000; if (player) level(); render(x, c.width / S.W, Math.min(t, D)); if (manual) try { vt.requestFrame(); } catch { /* لا شيء */ } const p = Math.min(1, t / D); $('#st-exp-n').textContent = N(Math.round(p * 100)) + '٪'; $('#st-exp-mask').style.clipPath = `inset(0 0 0 ${p * 100}%)`; if (t >= D) { fin = true; clearInterval(iv); res(); } };
    const iv = setInterval(tick, 1000 / 30); const raf = () => { if (!fin) { tick(); requestAnimationFrame(raf); } }; requestAnimationFrame(raf);
  });
  player?.stop(); AUD.lvl = 0; rec.stop(); await done; c.remove(); try { wake?.release(); } catch { /* لا شيء */ }
  stream.getTracks().forEach((tr) => tr.stop());
  $('#st-exp').hidden = true;
  const blob = new Blob(chunks, { type: type.split(';')[0] });
  try { await deliver(blob, /mp4/.test(type) ? 'mp4' : 'webm', how); usedMark(how, true); saveProject(false, true); } catch { /* أُلغيت */ }
}
/* ---------- المشاريع ---------- */
function thumbURL() { const c = document.createElement('canvas'); const k = 240 / Math.max(S.W, S.H); c.width = Math.round(S.W * k); c.height = Math.round(S.H * k); NOSIGN = true; render(c.getContext('2d'), k); NOSIGN = false; return c.toDataURL('image/jpeg', 0.7); }
let saveT;
function autosave() { clearTimeout(saveT); saveT = setTimeout(() => saveProject(false, true), 900); }
let PROJ = null;
const projList = async () => (PROJ = PROJ || (typeof DSDB !== 'undefined' ? (await DSDB.get('studio:projects')) || [] : LS.get('noble-studio', [])));
const projSave = async (list) => { PROJ = list; if (typeof DSDB !== 'undefined') { await DSDB.put('studio:projects', list); return true; } return LS.set('noble-studio', list); };
async function saveProject(msg, quiet) {
  if (!S) return;
  const list = await projList();
  const item = { id: S.id, name: S.name, at: Date.now(), thumb: thumbURL(), data: { W: S.W, H: S.H, size: S.size, dur: S.dur, bg: S.bg, els: S.els, audio: S.audio && !S.audio.mine ? S.audio : null, noSign: !!S.noSign } };
  const next = [item, ...list.filter((x) => x.id !== S.id)].slice(0, 20);
  if (!(await projSave(next))) { if (!quiet) toast('ما قدرت أحفظ — المساحة ممتلئة', { type: 'error' }); return; }
  if (msg) toast('انحفظ في «مشاريعي» ✓', { type: 'success' });
}
async function paintHome() {
  const list = await projList();
  $('#st-pcount').textContent = list.length ? N(list.length) + ' مشروع' : '';
  $('#st-projs').replaceChildren(...(list.length ? list.map((p) => el('div', { class: 'proj', role: 'button', onclick: () => p.data ? openEditor(p.data, p.id, p.name) : toast('هذا المشروع انحفظ مصغّر فقط') },
    el('img', { src: p.thumb, alt: '' }), el('div', {}, el('b', { text: p.name }), el('small', { text: new Date(p.at).toLocaleString('ar-SA', { dateStyle: 'medium', timeStyle: 'short' }) })),
    el('button', { type: 'button', class: 'del', html: svg('trash'), onclick: (ev) => { ev.stopPropagation(); if (!confirm('حذف المشروع؟')) return; projSave(list.filter((x) => x.id !== p.id)).then(paintHome); } }))) : [el('div', { class: 'empty', html: 'ما عندك مشاريع للحين<br>اضغط «مشروع جديد» وابدأ 🎨' })]));
}
const TOOLS = [['motion', 'تصميم متحرك', 'motion', () => newProject('story', 'idea', IDEAS[0][2]).then(() => { autoAnim(); snap(); play(); openPanel('motion'); })],['photo', 'محرر صور', 'photo', () => newProject('post', 'photo')], ['text', 'نص على صورة', 'text', () => newProject('story', 'text')], ['collage', 'كولاج', 'collage', () => newProject('square', 'collage')], ['wand', 'إزالة الخلفية', 'wand', () => toast('المرحلة ٣ — بالذكاء الاصطناعي'), 'قريباً'], ['video', 'محرر فيديو', 'video', () => (typeof VEdit !== 'undefined' ? VEdit.open() : toast('قريباً'))], ['size', 'مقاس مخصص', 'size', () => customSize((k) => newProject(k, 'blank'))]];
$('#st-tools').replaceChildren(...TOOLS.map(([k, l, ic, fn, soon]) => el('button', { type: 'button', class: 'tool' + (soon ? ' soon' : ''), onclick: fn }, el('i', { html: svg(ic) }), l, soon ? el('em', { text: soon }) : null)));
const newSheet = () => sheet([el('h3', { text: 'مقاس المشروع' }), sizeGrid('', (k) => { closeSheet(); newProject(k, 'blank'); }, newSheet)]);
$('#st-newp').onclick = newSheet;
/* شبكة المقاسات: الجاهزة + مقاساتي + «＋ مقاس مخصص» */
function sizeGrid(cur, pick, repaint) {
  const ico = (w, h) => { const r = h / w; return { height: (r * 30 > 48 ? 48 : Math.max(8, Math.round(30 * r))) + 'px', width: (r * 30 > 48 ? Math.round(48 / r) : 30) + 'px' }; };
  const box = el('div', { class: 'sizes' },
    ...Object.entries(SIZES).map(([k, [l, w, h]]) => el('button', { type: 'button', class: 'sz' + (cur === k ? ' on' : ''), onclick: () => pick(k) }, el('i', { style: ico(w, h) }), l, el('small', { text: `${w}×${h}` }))),
    ...mySizes().map((c) => el('button', { type: 'button', class: 'sz' + (cur === 'c:' + c.id ? ' on' : ''), onclick: () => pick('c:' + c.id) }, el('i', { style: ico(c.w, c.h) }), c.name, el('small', { text: `${c.w}×${c.h}` }),
      el('span', { class: 'x', role: 'button', 'aria-label': 'حذف', onclick: (ev) => { ev.stopPropagation(); LS.set('noble-studio-sizes', mySizes().filter((x) => x.id !== c.id)); repaint(); } }, '✕'))),
    el('button', { type: 'button', class: 'sz add', onclick: () => customSize((k) => pick(k)) }, el('i', { text: '＋' }), 'مقاس مخصص', el('small', { text: 'أي مقاس تبيه' })));
  return box;
}
/* إضافة مقاس مخصص: بكسل أو سم أو إنش (للطباعة ٣٠٠ نقطة/إنش) */
function customSize(done) {
  const U = { px: ['بكسل', 1], cm: ['سم', 300 / 2.54], in: ['إنش', 300] };
  const st = { unit: 'px', w: 1080, h: 1080, lock: false, save: true, name: '' };
  const wI = el('input', { type: 'number', inputmode: 'decimal', min: 1, value: 1080 }), hI = el('input', { type: 'number', inputmode: 'decimal', min: 1, value: 1080 });
  const nI = el('input', { class: 'cs-name', placeholder: 'اسم المقاس (مثلاً: بنر المحل)', maxlength: 24 });
  const pv = el('i'), info = el('div', { class: 'cs-info' });
  const lockB = el('button', { type: 'button', class: 'lock', title: 'تثبيت النسبة' }, '🔓');
  const px = (v) => Math.round(v * U[st.unit][1]);
  const paint = () => {
    const W = px(+wI.value || 0), H = px(+hI.value || 0), r = H / W || 1, big = 92;
    Object.assign(pv.style, r > 1 ? { height: big + 'px', width: Math.max(6, big / r) + 'px' } : { width: big * 1.6 + 'px', height: Math.max(6, big * 1.6 * r) + 'px' });
    const ok = W >= 100 && H >= 100 && W <= 4096 && H <= 4096;
    info.textContent = ok ? `${N(W)} × ${N(H)} بكسل · النسبة ${N((W / H).toFixed(2))}${st.unit !== 'px' ? ' · جودة طباعة ٣٠٠ نقطة' : ''}` : 'المقاس لازم يكون بين ١٠٠ و ٤٠٩٦ بكسل لكل جهة';
    info.style.color = ok ? '' : '#FF9A9E';
    return ok ? [W, H] : null;
  };
  let ratio = 1;
  wI.addEventListener('input', () => { if (st.lock) hI.value = +(+wI.value / ratio).toFixed(2); paint(); });
  hI.addEventListener('input', () => { if (st.lock) wI.value = +(+hI.value * ratio).toFixed(2); paint(); });
  lockB.onclick = () => { st.lock = !st.lock; ratio = (+wI.value || 1) / (+hI.value || 1); lockB.classList.toggle('on', st.lock); lockB.textContent = st.lock ? '🔒' : '🔓'; };
  const units = el('div', { class: 'row' }, ...Object.entries(U).map(([k, [l]]) => el('button', { type: 'button', class: 'chip' + (k === 'px' ? ' on' : ''), onclick: (ev) => {
    const f = U[st.unit][1] / U[k][1]; wI.value = +(+wI.value * f).toFixed(2); hI.value = +(+hI.value * f).toFixed(2); st.unit = k;
    units.querySelectorAll('.chip').forEach((c) => c.classList.toggle('on', c === ev.currentTarget)); paint();
  } }, l)));
  const quick = el('div', { class: 'row' }, ...[['كاروسيل ٤:٥', 1080, 1350], ['كاروسيل ٣:٤', 1080, 1440], ['تيك توك', 1080, 1920], ['تويتر', 1600, 900], ['لينكدإن', 1200, 627], ['بطاقة عمل', 1050, 600], ['رول أب', 2400, 6000], ['شعار', 1000, 1000]].map(([l, w, h]) => el('button', { type: 'button', class: 'chip', onclick: () => { st.unit = 'px'; units.querySelectorAll('.chip').forEach((c, i) => c.classList.toggle('on', i === 0)); wI.value = Math.min(4096, w); hI.value = Math.min(4096, h); if (!nI.value) nI.value = l; paint(); } }, l)));
  const save = el('label', { class: 'check' }, (() => { const c = el('input', { type: 'checkbox' }); c.checked = true; c.onchange = () => (st.save = c.checked); return c; })(), 'احفظه في «مقاساتي» عشان ترجع له');
  sheet([el('h3', { text: '＋ مقاس مخصص' }), units,
    el('div', { class: 'cs-row' }, el('label', {}, 'العرض', wI), lockB, el('label', {}, 'الارتفاع', hI)),
    el('div', { class: 'cs-pv' }, pv), info, el('div', { class: 'lbl', text: 'مقاسات منتشرة' }), quick, nI, save,
    el('button', { type: 'button', class: 'btn pri', onclick: () => {
      const r = paint(); if (!r) return toast('عدّل المقاس أول');
      const [W, H] = r, name = nI.value.trim() || `${W}×${H}`;
      let key;
      if (st.save) { const c = { id: uid(), name, w: W, h: H }; LS.set('noble-studio-sizes', [...mySizes(), c].slice(-12)); key = 'c:' + c.id; }
      else { const c = { id: 'tmp', name, w: W, h: H }; LS.set('noble-studio-sizes', [...mySizes().filter((x) => x.id !== 'tmp'), c]); key = 'c:tmp'; }
      closeSheet(); done(key);
    } }, 'اعتمد المقاس')]);
  paint();
}
function sheet(kids) { if (!SH.isConnected) document.body.append(SH); $('#st-sheet-c').replaceChildren(...kids); $('#st-sheet').hidden = false; if (typeof UI !== 'undefined') UI.digitize?.(SH); }
function closeSheet() { $('#st-sheet').hidden = true; }
$('#st-sheet').addEventListener('click', (e) => { if (e.target.id === 'st-sheet') closeSheet(); });

/* أفكار جاهزة (تفتح للتعديل) */
const IDEAS = [
  ['عيد مبارك', 'story', () => ({ bg: { type: 'grad', c: ['#2B1055', '#D35D6E', '#F9A26C'] }, els: [{ type: 'sticker', emoji: '🌙', size: 260, x: 540, y: 520 }, { type: 'text', text: 'عيد مبارك', font: 'amiri', size: 190, color: '#F6D68E', fx: 'gold', x: 540, y: 900 }, { type: 'text', text: 'كل عام وأنتم بخير', font: 'noor', size: 70, color: '#FFFFFF', fx: 'shadow', x: 540, y: 1080 }, { type: 'shape', kind: 'line', w: 520, h: 10, fill: '#F6D68E', x: 540, y: 1180 }] })],
  ['عرض خاص', 'post', () => ({ bg: { type: 'grad', c: ['#050505', '#1C1F26', '#3A3F4B'] }, els: [{ type: 'shape', kind: 'badge', w: 380, h: 380, fill: '#E5484D', x: 760, y: 330, rot: 0.2 }, { type: 'text', text: '٥٠٪\nخصم', font: 'lalezar', size: 110, color: '#FFFFFF', fx: 'none', x: 760, y: 330, rot: 0.2, lh: 1 }, { type: 'text', text: 'عرض خاص', font: 'kufi', size: 130, color: '#FFFFFF', fx: 'shadow', x: 540, y: 820 }, { type: 'text', text: 'لفترة محدودة', font: 'tajawal', size: 64, color: '#111111', fx: 'box', fxc: '#F6D68E', x: 540, y: 990 }] })],
  ['تهنئة بصورة', 'post', () => ({ bg: { type: 'grad', c: ['#0A0F3C', '#2E5BFF', '#8B45F0'] }, photo: true, els: [{ type: 'text', text: 'ألف مبروك', font: 'ruqaa', size: 140, color: '#FFFFFF', fx: 'shadow', x: 540, y: 1040 }, { type: 'text', text: 'التخرّج', font: 'kufi', size: 70, color: '#56C8FF', fx: 'glow', x: 540, y: 1190 }] })],
  ['جمعة مباركة', 'square', () => ({ bg: { type: 'grad', c: ['#00261A', '#006C35', '#2FA36B'] }, els: [{ type: 'shape', kind: 'arch', w: 640, h: 760, fill: '#FFFFFF', noFill: true, sw: 10, x: 540, y: 560 }, { type: 'text', text: 'جمعة\nمباركة', font: 'reem', size: 150, color: '#FFFFFF', fx: 'outline', fxc: '#00261A', x: 540, y: 600, lh: 1.15 }] })],
];
$('#st-tpls').replaceChildren(...IDEAS.map(([n, size, fn]) => el('button', { type: 'button', class: 'tpl', onclick: () => newProject(size, 'idea', fn) },
  (() => { const [, w, h] = SIZES[size]; const c = el('canvas', { width: 232, height: Math.round(232 * h / w) }); const d = fn(); const keep = S; S = { W: w, H: h, bg: d.bg, els: d.els.map((e) => ({ scale: 1, rot: 0, ...e })) }; document.fonts.ready.then(() => { const k = 232 / w; const t = S; S = { W: w, H: h, bg: d.bg, els: d.els.map((e) => ({ scale: 1, rot: 0, ...e })) }; NOSIGN = true; render(c.getContext('2d'), k); NOSIGN = false; S = t; }); S = keep; return c; })(), n)));

async function newProject(size, kind, ideaFn) {
  const [, W, H] = sizeOf_(size) || SIZES.post;
  const data = { dur: 6, W, H, size, bg: { type: 'grad', c: GRADS[0] }, els: [] };
  if (ideaFn) { const d = ideaFn(); data.bg = d.bg; data.els = d.els.map((e) => ({ id: uid(), scale: 1, rot: 0, ...e })); if (d.photo) { const src = samplePhoto(2); await loadImg(src); const im = IMG.get(src); data.els.unshift({ id: uid(), type: 'image', src, w: 560, h: 560, x: 540, y: 520, scale: 1, rot: 0, mask: 'circle', bw: 14, bc: '#FFFFFF', shadow: true, f: {}, flt: 'none' }); } }
  await openEditor(data, uid(), 'مشروع ' + N(new Date().getDate()) + '/' + N(new Date().getMonth() + 1));
  if (kind === 'photo') { addImage(samplePhoto(0), true); toast('هذي صورة مثال — بدّلها من «الخلفية» ← صورة من جهازي'); }
  if (kind === 'text') { await addImage(samplePhoto(1), true); add({ type: 'text', text: 'اكتب كلامك', font: 'kufi', size: 110, color: '#FFFFFF', fx: 'shadow', align: 'center' }); openPanel('textedit'); }
  if (kind === 'collage') { const s1 = samplePhoto(0), s2 = samplePhoto(1), s3 = samplePhoto(2); for (const [src, x, y, w, h] of [[s1, 270, 540, 520, 1060], [s2, 810, 270, 520, 520], [s3, 810, 810, 520, 520]]) { await loadImg(src); S.els.push({ id: uid(), type: 'image', src, x, y, w, h, scale: 1, rot: 0, mask: 'round', f: {}, flt: 'none', bw: 0 }); } S.bg = { type: 'color', color: '#FFFFFF' }; snap(); draw(); toast('بدّل أي صورة: اخترها ← «🔁 استبدال»'); }
  if (kind === 'sticker') openPanel('sticker');
}
async function openEditor(data, id, name) {
  S = { id, name, ...JSON.parse(JSON.stringify(data)) };
  if (typeof DesignKit !== 'undefined' && typeof dsFontsList === 'function') DesignKit.registerFonts(dsFontsList().map((f) => ({ id: f.id, url: f.url, title: f.title, premium: f.premium })));
  const srcs = [S.bg.src, ...S.els.map((e) => e.src)].filter(Boolean);
  await Promise.all([...srcs.map(loadImg), loadLogo(), DesignKit.ensureFonts(S.els.map((e) => e.font))]);
  sel = null; hist = []; hi = -1; panelKind = '';
  openScreen((scr) => { scr.append(ED); }, { cls: 'st-screen', onBack: goBack, cleanup: () => { stopPrev(); stopPlay(); ED.remove(); } });
  $('#st-ed-name').textContent = name;
  closePanel(); paintCtx();
  fit(); snap();
  document.fonts.ready.then(() => draw());
}
/* الرجوع (زر ✕ أو زر الجوال): يقفل الورقة أو اللوحة أول، وبعدين يطلع ويحفظ */
function goBack() {
  if (!SH.querySelector('#st-sheet').hidden) return closeSheet();
  if (!$('#st-exp').hidden) return;
  if (panelKind) return closePanel();
  stopPrev(); stopPlay(); const keep = S; saveProject(false, true).then(() => { if (S === keep) S = null; paintHome(); });
  closeScreen();
}
$('#st-back').onclick = goBack;
document.fonts.ready.then(() => S && draw());
paintBar();

/* الرئيسية داخل قسم التصاميم */
function renderHome(root) { root.append(HOME); paintHome(); if (typeof UI !== 'undefined') UI.digitize?.(HOME); }
return { renderHome, open: openEditor, isOpen: () => !!S };
})();
