/* NOBLE — «راسل الإدارة» (1.16)
 * زر عائم في الرسائل + صف في الإعدادات ← شاشة يكتب فيها المستخدم مشكلته ويرفق صور/فيديو.
 * المرفقات تنرفع لمخزن خاص (support) ما يشوفه إلا المالك وفريقه.
 */
'use strict';
const SUP = { st: null, at: 0, files: [], cat: 'issue', body: '', info: true, busy: false };
const SUP_CATS = [['issue', '🛠', 'مشكلة'], ['idea', '💡', 'اقتراح'], ['billing', '💳', 'الاشتراك'], ['question', '❓', 'سؤال'], ['other', '💬', 'غيره']];
const SUP_ST = { new: ['وصلت ✓', 'new'], open: ['نشتغل عليها 🔧', 'open'], done: ['انحلّت ✅', 'done'] };
const SUP_MAX_VID = 30 * 1024 * 1024;

async function supLoad(force) {
  if (!Cloud.enabled || !(await Cloud.user())) { SUP.st = null; supPaint(); return null; }
  if (!force && SUP.st && Date.now() - SUP.at < 5 * 60e3) { supPaint(); return SUP.st; }
  SUP.st = await Cloud.supportStatus(); SUP.at = Date.now();
  supPaint();
  return SUP.st;
}
const supOn = () => !!SUP.st?.on;
/* يظهر/يختفي الزر العائم وصف الإعدادات حسب إعداد المالك */
function supPaint() {
  const on = supOn();
  const sheet = document.getElementById('inbox-sheet');
  if (sheet) {
    let fab = sheet.querySelector('.sup-fab');
    if (on && !fab) {
      fab = h('button', { type: 'button', class: 'sup-fab', onclick: () => openSupport() }, h('span', { class: 'sup-fab-ic' }, supIcon()), h('b', { text: 'راسل الإدارة' }));
      sheet.append(fab);
    }
    if (fab) fab.hidden = !on;
    const dot = SUP.st?.unread > 0;
    fab?.classList.toggle('dot', dot);
  }
  const row = document.getElementById('sup-row');
  if (row) row.hidden = !on;
  // زر الرسائل يظهر حتى لو ما فيه رسائل — عشان يوصل للمراسلة
  const ib = document.getElementById('inbox-btn');
  if (ib && on) ib.hidden = false;
  if (SUP.st?.unread > 0) { const d = document.getElementById('inbox-dot'); if (d) d.hidden = false; }
}
function supIcon() {
  const ns = 'http://www.w3.org/2000/svg', s = document.createElementNS(ns, 'svg');
  s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('width', 22); s.setAttribute('height', 22);
  s.innerHTML = '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H11l-4.2 3.6c-.5.4-1.3.1-1.3-.6V16A2.5 2.5 0 0 1 4 13.5z" fill="currentColor" opacity=".25"/><path d="M4 5.5A2.5 2.5 0 0 1 6.5 3h11A2.5 2.5 0 0 1 20 5.5v8a2.5 2.5 0 0 1-2.5 2.5H11l-4.2 3.6c-.5.4-1.3.1-1.3-.6V16A2.5 2.5 0 0 1 4 13.5z" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linejoin="round"/><path d="M8.5 8.5h7M8.5 11.5h4.5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>';
  return s;
}
/* معلومات الجهاز (تساعد المالك يفهم المشكلة) */
function supMeta() {
  const ua = navigator.userAgent || '';
  const dev = (ua.match(/Android [\d.]+;[^;)]*?([^;)]+)\)/) || [])[1] || (/iPhone|iPad/.test(ua) ? (ua.match(/(iPhone|iPad)[^;)]*/) || [''])[0] : '') || '';
  return {
    app: typeof APP !== 'undefined' ? APP.id : 'nobleweb', version: Cloud.VERSION || '', platform: typeof Platform !== 'undefined' && Platform.isNative ? 'android' : 'web',
    os: (ua.match(/Android [\d.]+|iPhone OS [\d_]+|Windows NT [\d.]+|Mac OS X [\d_]+/) || [''])[0].replace(/_/g, '.'), device: dev.trim().slice(0, 60),
    screen: `${screen.width}×${screen.height}`, tab: (typeof S !== 'undefined' && S.tab) || '', online: navigator.onLine, at: new Date().toISOString(),
  };
}
/* صورة: نصغرها على الجهاز قبل الرفع */
function supShrink(file, max = 1600) {
  return new Promise((res) => {
    const url = URL.createObjectURL(file), im = new Image();
    im.onload = () => {
      const sc = Math.min(1, max / Math.max(im.width, im.height)), c = document.createElement('canvas');
      c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height);
      URL.revokeObjectURL(url);
      c.toBlob((b) => res(b ? new File([b], 'photo.jpg', { type: 'image/jpeg' }) : file), 'image/jpeg', 0.85);
    };
    im.onerror = () => { URL.revokeObjectURL(url); res(file); };
    im.src = url;
  });
}

function openSupport() {
  if (typeof closeAllSheets === 'function') closeAllSheets();
  if (!supOn()) { toast('المراسلة متوقفة حالياً'); return; }
  openScreen((el) => supScreen(el), { cls: 'sub-screen sup-screen', onBack: () => { supClear(); closeScreen(); }, cleanup: supClear });
}
function supClear() { SUP.files.forEach((f) => f.url && URL.revokeObjectURL(f.url)); SUP.files = []; }

function supScreen(el) {
  const left = Math.max(0, (SUP.st?.max_day || 5) - (SUP.st?.used || 0));
  const fileIn = h('input', { type: 'file', accept: 'image/*,video/*', multiple: true, hidden: true });
  const grid = h('div', { class: 'sup-files' });
  const ta = h('textarea', { class: 'input textarea sup-ta', rows: 5, maxlength: 2000, placeholder: 'اكتب لنا وش صار معك… كل ما وضّحت أكثر، حلّيناها أسرع 🤍' });
  ta.value = SUP.body;
  const taBox = h('span', { class: 'vc-wrap ta' }, ta);
  if (typeof Voice !== 'undefined') Voice.attach(ta, 'support', { replace: false });
  const cnt = h('small', { class: 'sup-cnt num' });
  const send = h('button', { type: 'button', class: 'btn btn-primary sup-send' }, 'أرسل للإدارة ✈️');
  const paintCnt = () => { cnt.textContent = `${UI.n(ta.value.length)}/${UI.n(2000)}`; send.disabled = SUP.busy || ta.value.trim().length < 3 || !left; };
  ta.addEventListener('input', () => { SUP.body = ta.value; paintCnt(); });
  const paintFiles = () => {
    RC(grid, ...SUP.files.map((f, i) => h('div', { class: `sup-file${f.kind === 'video' ? ' vid' : ''}` },
      f.kind === 'video' ? h('video', { src: f.url, muted: '', playsinline: '', preload: 'metadata' }) : h('img', { src: f.url, alt: '' }),
      f.kind === 'video' ? h('i', { class: 'sup-vi', text: '▶' }) : null,
      h('small', { class: 'num', text: f.size > 1048576 ? `${(f.size / 1048576).toFixed(1)}MB` : `${Math.round(f.size / 1024)}KB` }),
      h('button', { type: 'button', class: 'sup-x', 'aria-label': 'شيل', onclick: () => { URL.revokeObjectURL(f.url); SUP.files.splice(i, 1); paintFiles(); } }, '✕'))),
      SUP.files.length < 4 ? h('button', { type: 'button', class: 'sup-add', onclick: () => fileIn.click() }, h('b', { text: '＋' }), h('small', { text: SUP.files.length ? 'ملف ثاني' : 'صورة أو فيديو' })) : null);
    UI.digitize(grid);
  };
  fileIn.addEventListener('change', async () => {
    const list = [...fileIn.files]; fileIn.value = '';
    for (const f of list) {
      if (SUP.files.length >= 4) { toast('أقصى شي ٤ مرفقات'); break; }
      const vid = /^video\//.test(f.type);
      if (!vid && !/^image\//.test(f.type)) { toast('صور أو فيديو بس'); continue; }
      if (vid && f.size > SUP_MAX_VID) { toast('الفيديو كبير — أقصى حجم ٣٠ ميجا (صوّر مقطع أقصر)', { type: 'error' }); continue; }
      const file = vid ? f : await supShrink(f);
      SUP.files.push({ file, kind: vid ? 'video' : 'image', url: URL.createObjectURL(file), size: file.size, name: f.name });
    }
    paintFiles();
  });
  const cats = h('div', { class: 'sup-cats' });
  const paintCats = () => RC(cats, ...SUP_CATS.map(([k, ic, l]) => h('button', { type: 'button', class: `sup-cat${SUP.cat === k ? ' on' : ''}`, onclick: () => { SUP.cat = k; paintCats(); } }, h('i', { text: ic }), h('span', { text: l }))));
  paintCats();
  const info = h('label', { class: 'sup-info' }, (() => { const c = h('input', { type: 'checkbox', checked: SUP.info }); c.addEventListener('change', () => { SUP.info = c.checked; }); return c; })(),
    h('span', {}, h('b', { text: 'أرفق معلومات الجهاز' }), h('small', { text: 'نسخة التطبيق ونوع الجوال — تساعدنا نلقى المشكلة أسرع' })));
  const mine = h('div', { class: 'sup-mine' });
  send.addEventListener('click', async () => {
    if (SUP.busy) return;
    SUP.busy = true; paintCnt();
    const folder = Date.now().toString(36) + Math.random().toString(36).slice(2, 5);
    const files = [];
    try {
      for (let i = 0; i < SUP.files.length; i++) {
        const f = SUP.files[i];
        send.textContent = `يرفع المرفقات… ${UI.n(i + 1)}/${UI.n(SUP.files.length)}`;
        const path = await Cloud.supportUpload(f.file, folder, i + 1);
        files.push({ path, kind: f.kind, size: f.size, name: String(f.name || '').slice(0, 60) });
      }
      send.textContent = 'يرسل…';
      await Cloud.supportSend({ cat: SUP.cat, body: ta.value.trim(), files, meta: SUP.info ? supMeta() : { app: typeof APP !== 'undefined' ? APP.id : '', version: Cloud.VERSION || '' } });
      if (typeof buzz === 'function') buzz('success');
      supClear(); SUP.body = ''; SUP.busy = false;
      await supLoad(true);
      supDone(el);
    } catch (e) {
      SUP.busy = false; send.textContent = 'أرسل للإدارة ✈️'; paintCnt();
      const m = String(e?.message || e);
      toast(/daily limit/.test(m) ? 'وصلت حد الرسائل اليوم — نرد عليك قريب 🤍' : /closed/.test(m) ? 'المراسلة متوقفة حالياً' : /short/.test(m) ? 'اكتب رسالة أوضح شوي' : Cloud.msg(e), { type: 'error' });
    }
  });
  el.replaceChildren(h('div', { class: 'g-wrap sup-wrap' },
    gHead('📩 راسل الإدارة'),
    h('div', { class: 'sup-hero' }, h('span', { class: 'sup-hero-ic' }, supIcon()), h('div', {}, h('b', { text: 'نقرأ كل رسالة بنفسنا 🤍' }), h('small', { text: 'مشكلة، فكرة، أو سؤال — اكتب لنا وارفق صورة أو فيديو يوضّح.' }))),
    h('div', { class: 'sup-card' },
      h('small', { class: 'sup-lbl', text: 'وش نوع رسالتك؟' }), cats,
      h('div', { class: 'sup-tawrap' }, taBox, cnt),
      h('small', { class: 'sup-lbl', text: '📎 المرفقات (اختياري — حتى ٤)' }), grid, fileIn,
      info,
      left ? null : h('p', { class: 'sup-warn', text: 'وصلت حد الرسائل اليوم — تقدر ترسل بكرة، ورسائلك السابقة وصلت ✓' }),
      send),
    mine));
  paintFiles(); paintCnt();
  supMine(mine);
  UI.digitize(el);
}
function supDone(el) {
  el.replaceChildren(h('div', { class: 'g-wrap sup-wrap' }, gHead('📩 راسل الإدارة'),
    h('div', { class: 'sup-ok' }, h('div', { class: 'sup-ok-ic', text: '✅' }), h('h2', { text: 'وصلت رسالتك' }), h('p', { text: 'شكراً إنك كتبت لنا 🤍 بنشوفها ونرد عليك هنا وفي الرسائل.' }),
      h('button', { type: 'button', class: 'btn', onclick: () => supScreen(el) }, 'رسالة ثانية'),
      h('button', { type: 'button', class: 'btn ghost', onclick: () => closeScreen() }, 'تم')),
    (() => { const m = h('div', { class: 'sup-mine' }); supMine(m); return m; })()));
  UI.digitize(el);
}
async function supMine(box) {
  let list = [];
  try { list = await Cloud.supportMine(); } catch { return RC(box); }
  if (!list.length) return RC(box);
  RC(box, h('h3', { class: 'set-title', text: 'رسائلي السابقة' }), ...list.map((t) => {
    const [st, cls] = SUP_ST[t.status] || SUP_ST.new, cat = SUP_CATS.find((c) => c[0] === t.cat) || SUP_CATS[4];
    return h('article', { class: `sup-t st-${cls}` },
      h('div', { class: 'sup-t-h' }, h('span', { text: `${cat[1]} ${cat[2]}` }), h('em', { class: `sup-st ${cls}`, text: st }), h('small', { text: UI.relTime(new Date(t.created_at).getTime()) })),
      h('p', { text: t.body }),
      t.nfiles ? h('small', { class: 'sup-t-f', text: `📎 ${UI.n(t.nfiles)} مرفق` }) : null,
      t.reply ? h('div', { class: 'sup-reply' }, h('b', { text: '💬 رد الإدارة' }), h('p', { text: t.reply })) : null);
  }));
  UI.digitize(box);
  if (list.some((t) => t.reply)) { Cloud.supportSeen(); if (SUP.st) SUP.st.unread = 0; supPaint(); }
}

/* 🚩 1.21.15: الإبلاغ عن محتوى مسيء (تعليق / اسم في الصدارة) — شرط Google Play للمحتوى اللي يكتبه المستخدمين.
   البلاغ يوصل للإدارة كرسالة دعم (الرسائل ← الدعم) فيها نوع المحتوى ومعرّفه */
async function reportContent({ kind, id, name, text }) {
  if (!Cloud.enabled) return;
  const ok = await confirmSheet({ title: '🚩 إبلاغ عن محتوى', text: `${name ? `«${name}»: ` : ''}${text ? String(text).slice(0, 120) : ''}\n\nبنراجعه ونحذفه لو مخالف. شكراً لك 🤍`, ok: 'إرسال البلاغ' });
  if (!ok) return;
  try {
    await Cloud.soon(Cloud.supportSend({ cat: 'other', body: `🚩 بلاغ عن ${kind === 'comment' ? 'تعليق' : kind === 'nick' ? 'اسم في الصدارة' : 'محتوى'}${name ? ` — ${name}` : ''}${text ? `\n«${String(text).slice(0, 300)}»` : ''}`, meta: { report: { kind, id: String(id || ''), name: name || '' } } }), 12000);
    toast('وصل بلاغك ✓ بنراجعه بأسرع وقت', { type: 'success' });
  } catch (e) { toast(navigator.onLine === false ? 'بدون نت — جرّب بعد ما يرجع النت' : Cloud.msg(e), { type: 'error' }); }
}
