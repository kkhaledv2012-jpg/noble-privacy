/* NOBLE — تفضيلات العرض، الأقسام، البصمة، الملف الشخصي، الرسائل */
'use strict';

const TABS = [
  { id: 'sites', label: 'المواقع', ic: 'link' },
  { id: 'tasks', label: 'المهام', ic: 'checkSquare' },
  { id: 'today', label: 'يومي', ic: 'sun' },
  { id: 'finance', label: 'المالية', ic: 'wallet' },
  { id: 'news', label: 'الأخبار', ic: 'bolt' },
  { id: 'games', label: 'الألعاب', ic: 'gamepad' },
  { id: 'designs', label: 'تصاميم', ic: 'image' },
  { id: 'azkar', label: 'أذكاري', ic: 'moon' },
  { id: 'discover', label: 'اكتشف', ic: 'play' },
];
const ROLE_LABEL = { owner: 'المالك', admin: 'أدمن', moderator: 'مشرف', editor: 'محرر', support: 'دعم', user: 'مستخدم' };
const PREF = {
  mode: 'dark', fontScale: 1, density: 'comfy', hideStats: false, motion: true, haptics: true,
  calendar: 'gregory', digits: 'latn', privacy: false, biometric: false, usage: true,
  tabOrder: TABS.map((t) => t.id), hiddenTabs: [], startTab: '', voice: {},
};
const pref = (k) => (S.settings && S.settings[k] !== undefined ? S.settings[k] : PREF[k]);
async function setPref(patch) {
  S.settings = await Core.setSettings(patch);
  applyPrefs();
  if (S.unlocked) render();
}

/* ================= تطبيق التفضيلات ================= */
function applyPrefs() {
  const root = document.documentElement;
  Themes.apply(themeSettings());
  const z = Number(pref('fontScale')) || 1;
  root.style.setProperty('--z', z);
  document.body.style.zoom = z === 1 ? '' : z;
  root.classList.toggle('dense', pref('density') === 'compact');
  root.classList.toggle('no-motion', !pref('motion'));
  UI.setFormat({ cal: pref('calendar'), nu: typeof FontKit !== 'undefined' ? FontKit.digits(pref('digits')) : pref('digits') }); // 1.21.24: الإدارة تحدد الافتراضي/القفل
  renderTabbar();
  if (typeof Voice !== 'undefined') { try { Voice.refresh(); } catch { /* لا شيء */ } }
  if (Platform.isNative) {
    const ps = Platform.plugin('PrivacyScreen');
    (pref('privacy') ? ps.enable({ android: { dimBackground: true } }) : ps.disable()).catch(() => {});
  }
}
matchMedia('(prefers-color-scheme: light)').addEventListener?.('change', () => { if (pref('mode') === 'system') Themes.apply(themeSettings()); });

/* اهتزاز خفيف */
function buzz(kind = 'light') {
  if (!Platform.isNative || !pref('haptics')) return;
  const H = Platform.plugin('Haptics');
  if (!H) return;
  try {
    const r = kind === 'select' ? H.selectionChanged?.()
      : kind === 'success' || kind === 'error' || kind === 'warning' ? H.notification({ type: kind.toUpperCase() })
        : H.impact({ style: kind === 'heavy' ? 'HEAVY' : kind === 'medium' ? 'MEDIUM' : 'LIGHT' });
    r?.catch?.(() => {});
  } catch { /* لا شيء */ }
}

/* ================= الأقسام ================= */
/* أقسام هذا التطبيق (كل تطبيق منفصل له أقسامه — من ملف التطبيق أو من لوحة التحكم) */
function appSections() {
  // 🏪 وضع المتجر: أقسام الإدارة (في التطبيقات المنفصلة: بس اللي داخل التطبيق نفسه)
  if (typeof Store !== 'undefined' && Store.sections()) {
    const base = Array.isArray(APP.sections) ? APP.sections : null;
    const l = Store.sections().filter((id) => TABS.some((t) => t.id === id) && (!base || base.includes(id)));
    if (l.length) return l;
  }
  const cfg = typeof Market !== 'undefined' ? Market.get().apps?.[APP.id] : null;
  const fromPanel = cfg?.sections;
  let list = Array.isArray(fromPanel) && fromPanel.length ? fromPanel : APP.sections;
  // قسم جديد ما كانت لوحة التحكم تعرفه وقت الحفظ = يظهر (ما نخفيه بالغلط)
  if (Array.isArray(fromPanel) && fromPanel.length && APP.id === 'nobleweb') {
    const known = Array.isArray(cfg.sectionsKnown) ? cfg.sectionsKnown : ['sites', 'tasks', 'finance', 'games'];
    list = [...list, ...TABS.map((t) => t.id).filter((id) => !known.includes(id) && !list.includes(id))];
  }
  return Array.isArray(list) && list.length ? list : null;
}
/* 1.17: إعدادات الأقسام من الإدارة (لوحة التحكم ← الأقسام) + صلاحياتي من السيرفر */
const appSecCfg = () => ((typeof Market !== 'undefined' ? Market.get().apps?.[APP.id] : null) || {});
/* 1.17.1: كم قسم في الشريط (٤–٧) — الإدارة تحدده لكل تطبيق، والباقي داخل «المزيد» */
const barMaxOf = (c = appSecCfg()) => Math.min(7, Math.max(4, Number(c.barMax) || 5));
const barSplit = (vis, c = appSecCfg()) => { const M = barMaxOf(c); return vis.length > M ? [vis.slice(0, M - 1), vis.slice(M - 1)] : [vis, []]; };
const isStaff = () => ['owner', 'admin'].includes(S.profile?.role);
const isSubscriber = () => typeof Pro === 'undefined' || !Cloud.enabled || Pro.any() || Pro.inTrial() || Pro.isTester();
function secAccess() {
  if (S.secAcc) return S.secAcc;
  try { const id = S.profile?.id; const c = id ? JSON.parse(localStorage.getItem('nw:secacc:' + id) || 'null') : null; if (c) S.secAcc = c; return c; } catch { return null; }
}
let secAccAt = 0;
async function loadSectionAccess(force) {
  if (!Cloud.enabled || !S.profile?.id || (!force && Date.now() - secAccAt < 60e3)) return;
  secAccAt = Date.now();
  const r = await Cloud.mySectionAccess();
  if (!r) return;
  const before = JSON.stringify(S.secAcc || null);
  S.secAcc = r;
  try { localStorage.setItem('nw:secacc:' + S.profile.id, JSON.stringify(r)); } catch { /* لا شيء */ }
  if (before !== JSON.stringify(r) && S.unlocked) { renderTabbar(); if (typeof AccessUI !== 'undefined') AccessUI.apply(); }
}
function blockedTabs() {
  const off = Content.get('sectionsOff');
  const global = Array.isArray(off) ? off : [];
  const mine = S.profile?.disabled_sections || [];
  const set = new Set([...global, ...mine].filter((x) => x !== 'sites'));
  const own = appSections();
  if (own) TABS.forEach((t) => { if (!own.includes(t.id)) set.add(t.id); });
  // الأقسام التجريبية 🧪 تظهر للمختبرين فقط
  // 🧭 «اكتشف» داخل الأخبار: ما يطلع كقسم لحاله
  if (Content.get('discoverInNews') === true && !set.has('news') && (!own || own.includes('news'))) set.add('discover');
  if (typeof Pro !== 'undefined' && Pro.betaSecs && !Pro.isTester()) Pro.betaSecs().forEach((x) => { if (x !== 'sites') set.add(x); });
  // 1.17: 👥 محددين (من السيرفر) · 💎 للمشتركين · استثناءات لكل مستخدم
  if (!isStaff()) {
    const ac = appSecCfg(), acc = secAccess();
    if (acc) (Array.isArray(ac.custom) ? ac.custom : []).forEach((x) => { if ((acc.no || []).includes(x) && x !== 'sites') set.add(x); });
    if (ac.lockShow === false && !isSubscriber()) (Array.isArray(ac.proSecs) ? ac.proSecs : []).forEach((x) => { if (x !== 'sites') set.add(x); });
    if (acc) { (acc.hide || []).forEach((x) => { if (x !== 'sites') set.add(x); }); (acc.show || []).forEach((x) => { if (!own || own.includes(x)) set.delete(x); }); }
  }
  return set;
}
/* ترتيب الإدارة لهذا التطبيق (لوحة التحكم ← التطبيقات) — للجدد واللي ما رتّبوا لأنفسهم */
function tabCfg() {
  const c = (typeof Market !== 'undefined' ? Market.get().apps?.[APP.id] : null) || {};
  const order = Array.isArray(c.order) && c.order.length ? c.order : Array.isArray(c.sections) && c.sections.length ? c.sections : null;
  return { order, start: c.start || '', ver: Number(c.orderVer) || 0 };
}
/* ترتيب المستخدم يُعتمد لو رتّب بنفسه ولم تطبّق الإدارة ترتيباً على الكل بعده */
function userTabs() { if (appSecCfg().userOrder === false) return false; return (Number(S.settings?.tabOrderVer) || 0) >= tabCfg().ver; }
function myHidden() { if (appSecCfg().userHide === false) return []; return (Number(S.settings?.tabOrderVer) || 0) >= tabCfg().ver ? pref('hiddenTabs') : []; }
function orderedTabs() {
  const ss = typeof Store !== 'undefined' ? Store.sections() : null; // 🏪 وضع المتجر: ترتيب الإدارة
  if (ss) return [...ss.filter((id) => TABS.some((t) => t.id === id)), ...TABS.map((t) => t.id).filter((id) => !ss.includes(id))];
  const mine = userTabs() && Array.isArray(S.settings?.tabOrder) ? S.settings.tabOrder : null;
  const base = mine || tabCfg().order || PREF.tabOrder;
  const order = base.filter((id, i) => TABS.some((t) => t.id === id) && base.indexOf(id) === i);
  TABS.forEach((t, i) => { if (!order.includes(t.id)) order.splice(Math.min(i, order.length), 0, t.id); });
  return order;
}
/* أي تعديل من المستخدم يحفظ الحالة الكاملة (عشان ما يرجع ترتيب قديم بعد «طبّقه على الكل») */
function saveTabs(patch) {
  return setPref({ tabOrder: orderedTabs(), hiddenTabs: myHidden(), startTab: startTab(), tabOrderVer: tabCfg().ver, ...patch });
}
/* 1.19.2: القسم مخفي من الإدارة (وضع المتجر / الأقسام / الصلاحيات) — ما نذكره بأي مكان */
function secOff(id) { try { return typeof blockedTabs === 'function' && blockedTabs().has(id); } catch { return false; } }
/* أي عنصر عليه data-sec="finance games" يختفي لو أي قسم منها مخفي */
function secGate(root = document) { try { root.querySelectorAll('[data-sec]').forEach((el) => { el.hidden = String(el.dataset.sec).split(/\s+/).some(secOff); }); } catch { /* لا شيء */ } }
function visibleTabs() {
  const blocked = blockedTabs();
  const hidden = new Set(myHidden());
  const list = orderedTabs().filter((id) => !blocked.has(id) && !hidden.has(id));
  return list.length ? list : [appSections()?.[0] || 'sites'];
}
function startTab() {
  const v = visibleTabs();
  const mine = userTabs() ? pref('startTab') : '';
  const want = mine || tabCfg().start;
  return v.includes(want) ? want : v[0];
}
/* ورقة «المزيد» للأقسام الزائدة */
function openMoreTabs(list) {
  let el = $('#more-sheet');
  if (!el) { el = h('section', { class: 'sheet more-sheet', id: 'more-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(el); }
  el.replaceChildren(h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: 'المزيد' }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(el) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body more-grid' }, ...list.map((id) => { const t = TABS.find((x) => x.id === id); const ik = typeof IconKit !== 'undefined' ? IconKit.tab(id, t) : null; return h('button', { type: 'button', class: `more-item${S.tab === id ? ' on' : ''}`, onclick: () => { closeSheet(el); setTab(id); } }, ik ? IconKit.render((IconKit.cfg().tabs[id] || {}).ic || t.ic, { size: 26 }) : icon(t.ic, { size: 26 }), h('b', { text: ik ? ik.label : t.label })); }),
      h('p', { class: 'hint more-hint', text: 'رتّب الأقسام واختر اللي يظهر في الشريط من: الإعدادات ← الأقسام' })));
  openSheet('#more-sheet');
}
function renderTabbar() {
  const bar = $('#tabbar');
  if (!bar) return;
  secGate();
  const badge = $('#tasks-badge');
  const vis = visibleTabs();
  // أكثر من العدد المحدد (الإدارة: ٤–٧): الأوائل في الشريط والباقي في «المزيد»
  const ac = appSecCfg();
  const [shown, extra] = barSplit(vis, ac);
  const cols = shown.length + (extra.length ? 1 : 0);
  ['n6', 'n7', 'n8'].forEach((k) => bar.classList.toggle(k, cols >= +k.slice(1)));
  bar.style.gridTemplateColumns = `repeat(${shown.length + (extra.length ? 1 : 0)}, 1fr)`;
  bar.hidden = vis.length < 2;
  const moreBtn = extra.length ? (() => {
    const cur = extra.includes(S.tab) ? TABS.find((x) => x.id === S.tab) : null;
    const ck = cur && typeof IconKit !== 'undefined' ? IconKit.tab(cur.id, cur) : null;
    // «المزيد» واضح دائماً: أيقونة ⋯ + عدد الأقسام المخفية، وحتى لو المستخدم داخل قسم منها يبقى يبين إنه «المزيد»
    const smart = ac.moreLook === 'smart' && cur;
    const seen = (() => { try { return localStorage.getItem('nw:moreSeen') === '1'; } catch { return true; } })();
    const b = h('button', { type: 'button', class: `tab-more${cur ? ' on' : ''}${ac.moreHint !== false && !seen ? ' hint' : ''}`, 'aria-label': `المزيد — ${UI.n(extra.length)} أقسام`,
      onclick: (e) => { e.stopPropagation(); try { localStorage.setItem('nw:moreSeen', '1'); } catch { /* لا شيء */ } b.classList.remove('hint'); openMoreTabs(extra); } },
      smart ? (ck ? ck.ic : icon(cur.ic, { size: 22 })) : h('span', { class: 'tm-ic' }, (() => { const sv = icon('more', { size: 20 }); sv.style.transform = 'rotate(90deg)'; return sv; })()),
      h('span', { class: 'tm-lbl', text: smart ? (ck ? ck.label : cur.label) : 'المزيد' }),
      h('em', { class: 'tm-n', text: smart ? '⋯' : '+' + UI.n(extra.length) }));
    if (extra.some((id) => typeof AccessUI !== 'undefined' && AccessUI.locked(id))) b.append(h('span', { class: 'tab-lock', text: '🔒' }));
    return b;
  })() : null;
  bar.replaceChildren(...[...shown.map((id) => {
    const t = TABS.find((x) => x.id === id);
    const ik = typeof IconKit !== 'undefined' ? IconKit.tab(id, t) : null;
    const b = h('button', { type: 'button', dataset: { tab: id }, class: S.tab === id ? 'on' : '' }, ik ? ik.ic : icon(t.ic, { size: 22 }), h('span', { text: ik ? ik.label : t.label }));
    if (id === 'tasks') b.append(badge);
    if (typeof AccessUI !== 'undefined' && AccessUI.locked(id)) b.append(h('span', { class: 'tab-lock', text: '🔒' }));
    return b;
  }), moreBtn].filter(Boolean));
  if (!vis.includes('tasks')) $('#app').append(badge);
  if (S.unlocked && !vis.includes(S.tab)) setTab(vis[0]);
  if (typeof IconKit !== 'undefined') { IconKit.paintBar(bar); IconKit.paintSlots(); }
  if (typeof TabStyles !== 'undefined') TabStyles.mount(bar);
}

/* ================= واجهة الإعدادات ================= */
function setSeg(name, value) {
  $$(`input[name="${name}"]`).forEach((r) => (r.checked = r.value === String(value)));
}
function renderPrefs() {
  { const vr = $('#voice-row'); if (vr && !vr.dataset.bound) { vr.dataset.bound = '1'; vr.addEventListener('click', () => Voice.openPrefs()); } }
  { const sr = $('#sup-row'); if (sr && !sr.dataset.bound) { sr.dataset.bound = '1'; sr.addEventListener('click', () => openSupport()); } if (typeof supPaint === 'function') supPaint(); }
  if (typeof renderTrashRow === 'function') { renderTrashRow(); const tb = $('#trash-btn'); if (tb && !tb.dataset.bound) { tb.dataset.bound = '1'; tb.addEventListener('click', () => { if (typeof closeAllSheets === 'function') closeAllSheets(); Trash.open(); }); } }
  if (typeof NavKit !== 'undefined' && $('#nk-pref-row')) {
    const c = NavKit.cfg();
    $('#nk-pref-row').hidden = c.style === 'off' || !(c.userCtl || c.side === 'user');
    const seg = (box, opts, cur, key) => $(box).replaceChildren(...opts.map(([v, l]) => h('button', { type: 'button', class: String(cur) === String(v) ? 'on' : '', onclick: () => setPref({ [key]: v }).then(() => { renderPrefs(); NavKit.sync(true); }) }, l)));
    seg('#nk-side', [['right', 'يمين'], ['left', 'يسار']], NavKit.side(c), 'navSide');
    seg('#nk-size', [[44, 'صغير'], [54, 'وسط'], [64, 'كبير']], NavKit.size(c), 'navSize');
  }
  if (typeof TabStyles !== 'undefined' && $('#tb-pick-row')) {
    const c = TabStyles.cfg();
    $('#tb-pick-row').hidden = !c.allowPick;
    const cur = TabStyles.STYLES.find((x) => x[0] === TabStyles.current());
    $('#tb-pick-name').textContent = cur ? `الحالي: ${cur[1]}` : 'اختر شكل الشريط السفلي وحركته';
    if (!$('#tb-pick').dataset.bound) { $('#tb-pick').dataset.bound = '1'; $('#tb-pick').addEventListener('click', () => TabStyles.openPicker()); }
  }
  setSeg('p-mode', pref('mode'));
  setSeg('p-font', pref('fontScale'));
  setSeg('p-density', pref('density'));
  setSeg('p-cal', pref('calendar'));
  setSeg('p-digits', pref('digits'));
  $('#p-hidestats').checked = !!pref('hideStats');
  $('#p-motion').checked = !!pref('motion');
  $('#p-haptics').checked = !!pref('haptics');
  $('#p-privacy').checked = !!pref('privacy');
  if ($('#p-usage')) $('#p-usage').checked = pref('usage') !== false;
  $('#p-bio').checked = !!pref('biometric');
  $$('.native-only').forEach((el) => (el.hidden = !Platform.isNative));
  $('#set-nav [data-go="set-account"]').hidden = !Cloud.enabled;
  $('#date-sample').textContent = new Date().toLocaleDateString(UI.loc(), { day: 'numeric', month: 'long', year: 'numeric' });
  renderBioPrefs();
  if (typeof renderRecoveryPrefs === 'function') renderRecoveryPrefs();
  renderTabOrder();
}

function renderTabOrder() {
  const blocked = blockedTabs();
  const hidden = new Set(myHidden());
  const own = appSections();
  const order = orderedTabs().filter((id) => !own || own.includes(id));
  const move = (i, d) => {
    const o = [...order];
    const j = i + d;
    if (j < 0 || j >= o.length) return;
    [o[i], o[j]] = [o[j], o[i]];
    saveTabs({ tabOrder: o }).then(renderTabOrder);
  };
  const ac = appSecCfg(), lockOrd = ac.userOrder === false, lockHide = ac.userHide === false;
  $('#tab-order').replaceChildren(...(lockOrd || lockHide ? [h('p', { class: 'hint', text: lockOrd && lockHide ? '🔒 ترتيب الأقسام وإظهارها تتحكم فيه الإدارة' : lockOrd ? '🔒 الترتيب تتحكم فيه الإدارة' : '🔒 إخفاء الأقسام تتحكم فيه الإدارة' })] : []), ...order.map((id, i) => {
    const t = TABS.find((x) => x.id === id);
    const isBlocked = blocked.has(id);
    const shown = !hidden.has(id) && !isBlocked;
    const sw = h('input', { type: 'checkbox', checked: shown, disabled: isBlocked || lockHide });
    sw.addEventListener('change', () => {
      const hs = new Set(myHidden());
      if (sw.checked) hs.delete(id); else hs.add(id);
      const remaining = orderedTabs().filter((x) => !hs.has(x) && !blocked.has(x));
      if (!remaining.length) { sw.checked = true; return toast('يجب أن يبقى قسم واحد على الأقل'); }
      saveTabs({ hiddenTabs: [...hs] }).then(renderTabOrder);
    });
    return h('div', { class: `to-row${shown ? '' : ' off'}` },
      h('span', { class: 'to-ic' }, icon(t.ic, { size: 18 })),
      h('span', { class: 'to-name' }, t.label, isBlocked ? h('small', { text: 'موقوف من الإدارة' }) : null),
      lockOrd ? null : h('button', { type: 'button', class: 'icon-btn to-mv', 'aria-label': 'لأعلى', disabled: i === 0, onclick: () => move(i, -1) }, icon('arrowUp', { size: 16 })),
      lockOrd ? null : h('button', { type: 'button', class: 'icon-btn to-mv', 'aria-label': 'لأسفل', disabled: i === order.length - 1, onclick: () => move(i, 1) }, icon('arrowDown', { size: 16 })),
      h('span', { class: 'switch' }, sw, h('span', { class: 'track' })));
  }));
  const vis = visibleTabs();
  $('#p-start').replaceChildren(...vis.map((id) => h('option', { value: id, text: TABS.find((t) => t.id === id).label, selected: id === startTab() })));
}

function bindPrefs() {
  const onSeg = (name, key, conv = (v) => v) => $$(`input[name="${name}"]`).forEach((r) => r.addEventListener('change', () => setPref({ [key]: conv(r.value) }).then(renderPrefs)));
  onSeg('p-mode', 'mode');
  onSeg('p-font', 'fontScale', Number);
  onSeg('p-density', 'density');
  onSeg('p-cal', 'calendar');
  onSeg('p-digits', 'digits');
  const onSw = (id, key) => $(id).addEventListener('change', (e) => setPref({ [key]: e.target.checked }));
  onSw('#p-hidestats', 'hideStats');
  onSw('#p-motion', 'motion');
  onSw('#p-haptics', 'haptics');
  onSw('#p-privacy', 'privacy');
  if ($('#p-usage')) onSw('#p-usage', 'usage');
  $('#p-start').addEventListener('change', (e) => saveTabs({ startTab: e.target.value }));
  $('#p-bio').addEventListener('change', async (e) => {
    const on = e.target.checked;
    e.target.checked = !on;
    if (on) await Bio.enableFlow(); else await Bio.disableFlow();
    $('#p-bio').checked = !!pref('biometric');
    renderBioPrefs();
  });
  $('#set-nav').addEventListener('click', (e) => {
    const b = e.target.closest('[data-go]');
    if (b) $('#' + b.dataset.go)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  });

  $('#profile-btn').addEventListener('click', openProfile);
  $('#profile-form').addEventListener('submit', saveProfile);
  $('#inbox-btn').addEventListener('click', openInbox);
  $('#inbox-open').addEventListener('click', () => { closeSheet(); openInbox(); });
  $('#bio-btn').addEventListener('click', () => Bio.login());
}
document.addEventListener('DOMContentLoaded', bindPrefs);

/* ================= طلب كلمة المرور ================= */
function askPassword({ title, text, verifyWith }) {
  $('#pwask-title').textContent = title;
  $('#pwask-text').textContent = text || '';
  $('#pwask-error').textContent = '';
  const input = $('#pwask-pw');
  input.value = '';
  openSheet('#pwask-sheet');
  setTimeout(() => input.focus(), 250);
  return new Promise((resolve) => {
    const sheet = $('#pwask-sheet');
    let result = null;
    $('#pwask-form').onsubmit = async (e) => {
      e.preventDefault();
      if (!input.value) return;
      if (!(await (verifyWith ? verifyWith(input.value) : Core.verify(input.value)))) { $('#pwask-error').textContent = 'كلمة المرور غير صحيحة'; return; }
      result = input.value;
      closeSheet(sheet);
    };
    $('#pwask-cancel').onclick = () => closeSheet(sheet);
    sheet.addEventListener('closed', () => { input.value = ''; resolve(result); }, { once: true });
  });
}

/* ================= البصمة (الإصبع + الوجه) =================
 * بصمة الإصبع: كلمة المرور في مخزن الجوال الآمن مربوطة ببصمة «قوية» (أعلى حماية).
 * بصمة الوجه (أو رمز قفل الجوال): أندرويد يصنّف وجه أغلب الجوالات «ضعيفاً» ولا يقبله لفتح المخزن المربوط،
 * لذلك نتحقق من الهوية أولاً (وجه أو إصبع أو رمز) ثم نقرأ كلمة المرور من المخزن الآمن (مشفّرة بمفتاح الجهاز). */
const BIO_T = { FACE_ID: 2, FINGERPRINT: 3, FACE: 4, MULTIPLE: 6, DEVICE: 7 };
const Bio = {
  SERVER: 'com.nobledesigner.nobleweb',
  p: () => Platform.plugin('NativeBiometric'),
  info: null,
  async available() {
    if (!Platform.isNative) return false;
    try { const r = await this.p().isAvailable({ useFallback: false, preferMultipleBiometryType: true }); this.info = r; return !!r.isAvailable; } catch { return false; }
  },
  /* هل في الجوال بصمة وجه؟ */
  hasFace() { const t = this.info?.biometryType; return t === BIO_T.FACE || t === BIO_T.FACE_ID || t === BIO_T.MULTIPLE; },
  mode() { return { finger: pref('bioFinger') !== false, face: !!pref('bioFace'), pin: !!pref('bioPin') }; },
  weak() { const m = this.mode(); return m.face || m.pin; },
  types() {
    const m = this.mode(); const t = [];
    if (m.finger) t.push(BIO_T.FINGERPRINT);
    if (m.face) t.push(BIO_T.FACE, BIO_T.FACE_ID);
    if (m.pin) t.push(BIO_T.DEVICE);
    return t.length ? t : [BIO_T.FINGERPRINT];
  },
  /* حفظ كلمة المرور بالطريقة المناسبة للاختيار الحالي */
  async put(server, user, pw) {
    const P = this.p();
    if (this.weak()) {
      await this.check('تأكيد تفعيل الدخول بالبصمة');
      await P.setCredentials({ username: user, password: pw, server: server + '.w' });
      try { await P.deleteCredentials({ server }); } catch { /* لا شيء */ }
    } else {
      await P.setCredentials({ username: user, password: pw, server, accessControl: 2, title: 'تفعيل الدخول بالبصمة', negativeButtonText: 'إلغاء' });
      try { await P.deleteCredentials({ server: server + '.w' }); } catch { /* لا شيء */ }
    }
  },
  async del(server) {
    if (!Platform.isNative) return;
    for (const s of [server, server + '.w']) { try { await this.p().deleteCredentials({ server: s }); } catch { /* لا شيء */ } }
  },
  /* التحقق من الهوية (وجه/إصبع/رمز) */
  async check(subtitle) {
    await this.p().verifyIdentity({ reason: 'افتح خزنتك', title: 'NOBLE', subtitle: subtitle || '', description: '', negativeButtonText: this.mode().pin ? undefined : 'كلمة المرور', maxAttempts: 5, allowedBiometryTypes: this.types() });
  },
  /* قراءة كلمة المرور بعد التحقق */
  async take(server, subtitle) {
    const P = this.p();
    if (this.weak()) {
      let saved = false;
      try { saved = (await P.isCredentialsSaved({ server: server + '.w' })).isSaved; } catch { saved = false; }
      if (saved) { await this.check(subtitle); return (await P.getCredentials({ server: server + '.w' })).password; }
    }
    return (await P.getSecureCredentials({ server, title: 'NOBLE', subtitle: subtitle || 'افتح خزنتك بالبصمة', reason: 'افتح خزنتك', negativeButtonText: 'كلمة المرور' })).password;
  },
  async store(pw) { await this.put(this.SERVER, 'vault', pw); },
  async enableFlow() {
    if (!(await this.available())) return toast('البصمة غير متاحة — فعّلها من إعدادات الجوال أولاً', { type: 'error' });
    const pw = await askPassword({ title: 'تفعيل البصمة', text: 'أدخل كلمة المرور مرة واحدة ليحفظها الجوال في مخزنه الآمن، ثم تفتح بالبصمة.' });
    if (!pw) return;
    try {
      await this.store(pw);
      await setPref({ biometric: true });
      await syncAccountBio(pw, true);
      buzz('success');
      toast('تم تفعيل الدخول بالبصمة', { type: 'success' });
    } catch (e) {
      toast('لم يتم التفعيل', { type: 'error' });
    }
  },
  /* تغيير طريقة الدخول (إصبع / وجه / رمز) — نعيد حفظ كلمة المرور بالطريقة الجديدة */
  async setMode(patch) {
    const before = this.mode();
    const next = { ...before, ...patch };
    if (!next.finger && !next.face) return toast('اختر بصمة الإصبع أو الوجه — واحدة على الأقل', { type: 'error' });
    if (!pref('biometric')) { await setPref({ bioFinger: next.finger, bioFace: next.face, bioPin: next.pin }); return true; }
    const pw = await askPassword({ title: 'تحديث طريقة الدخول', text: 'أدخل كلمة المرور لحفظها بالطريقة الجديدة.' });
    if (!pw) return false;
    await setPref({ bioFinger: next.finger, bioFace: next.face, bioPin: next.pin });
    try {
      await this.store(pw);
      await syncAccountBio(pw, true);
      buzz('success');
      toast(next.face && next.finger ? 'تم — تقدر تفتح بالوجه أو بالإصبع' : next.face ? 'تم — الدخول ببصمة الوجه' : 'تم — الدخول ببصمة الإصبع', { type: 'success' });
      return true;
    } catch {
      await setPref({ bioFinger: before.finger, bioFace: before.face, bioPin: before.pin });
      toast('لم يتم التحديث — حاول مرة ثانية', { type: 'error' });
      return false;
    }
  },
  async disableFlow() {
    await this.off();
    await syncAccountBio(null, false);
    toast('تم إيقاف الدخول بالبصمة');
  },
  async off() {
    await this.del(this.SERVER);
    if (pref('biometric')) S.settings = await Core.setSettings({ biometric: false });
  },
  /* بعد تغيير كلمة المرور */
  async refresh(pw) {
    try { await this.store(pw); await syncAccountBio(pw, true); } catch { await this.off(); await syncAccountBio(null, false); toast('أعد تفعيل البصمة من الإعدادات'); }
  },
  busy: false,
  async login() {
    if (this.busy) return;
    this.busy = true;
    try {
      const pw = await this.take(this.SERVER, 'افتح خزنتك');
      const res = await Core.unlock(pw);
      if (res.ok) { buzz('success'); Resume.pw = pw; return enterApp(); }
      if (res.wait) return checkLockout();
      await this.off();
      $('#bio-btn').hidden = true;
      $('#login-error').textContent = 'تغيّرت كلمة المرور — أدخلها ثم أعد تفعيل البصمة من الإعدادات.';
    } catch (e) {
      if (String(e?.code) === '21' || /No protected credentials|not found|No credentials/i.test(e?.message || '')) {
        await this.off();
        $('#bio-btn').hidden = true;
        $('#login-error').textContent = 'تغيّرت بصمات الجهاز — ادخل بكلمة المرور ثم فعّل البصمة من جديد.';
      }
    } finally {
      this.busy = false;
    }
  },
};

/* واجهة خيارات البصمة في الإعدادات */
async function renderBioPrefs() {
  const box = $('#bio-opts');
  if (!box) return;
  const ok = await Bio.available();
  $('#bio-row').hidden = !ok;
  box.hidden = !ok || !pref('biometric');
  if (box.hidden) return;
  const m = Bio.mode();
  const sw = (label, sub, on, ic, patch) => {
    const inp = h('input', { type: 'checkbox', checked: on });
    inp.addEventListener('change', async () => { inp.checked = !inp.checked; await Bio.setMode(patch(!on)); renderBioPrefs(); });
    return h('label', { class: 'switch-row bio-opt' }, h('span', { class: 'bopt-ic', text: ic }), h('span', {}, h('b', { text: label }), h('small', { text: sub })), h('span', { class: 'switch' }, inp, h('span', { class: 'track' })));
  };
  box.replaceChildren(
    sw('بصمة الإصبع', 'أعلى حماية', m.finger, '☝️', (v) => ({ finger: v })),
    sw('بصمة الوجه', Bio.hasFace() ? 'أسرع — حمايتها أقل قليلاً من الإصبع في أغلب الجوالات' : 'لم نجد بصمة وجه مسجّلة — سجّلها من إعدادات الجوال أولاً', m.face, '🙂', (v) => ({ face: v })),
    sw('رمز قفل الجوال كبديل', 'إذا ما تعرّف على البصمة', m.pin, '🔢', (v) => ({ pin: v })),
    h('p', { class: 'hint', text: m.finger && m.face ? 'تقدر تفتح بالوجه أو بالإصبع — اللي يجي أول.' : '' }));
}

function setupBioLogin() {
  const on = !!pref('biometric') && Platform.isNative;
  $('#bio-btn').hidden = !on;
  if (on && !document.hidden) setTimeout(() => { if (!S.unlocked && !$('#login-form').hidden) Bio.login(); }, 450);
}

/* ================= الملف الشخصي ================= */
async function openProfile() {
  const u = await Cloud.user();
  if (!u) return;
  if (!u.email && typeof GuestName !== 'undefined') { closeSheet(); return GuestName.open(true); } // ضيف: الاسم بس
  const p = S.profile || (await Cloud.profile()) || {};
  const f = $('#profile-form').elements;
  f.name.value = p.display_name || '';
  f.email.value = u.email;
  f.nickname.value = p.nickname || '';
  f.show.checked = p.show_on_board !== false;
  $('#profile-error').textContent = '';
  openSheet('#profile-sheet');
}

async function saveProfile(e) {
  e.preventDefault();
  const f = $('#profile-form').elements;
  const err = $('#profile-error');
  const name = f.name.value.trim(), nick = f.nickname.value.trim(), email = f.email.value.trim();
  if (!name) return (err.textContent = 'اكتب اسمك');
  if (nick && !/^[\p{L}\p{N}_ .-]{2,20}$/u.test(nick)) return (err.textContent = 'الاسم المستعار من ٢ إلى ٢٠ حرفاً (حروف وأرقام و _ فقط)');
  if (!/^\S+@\S+\.\S+$/.test(email)) return (err.textContent = 'بريد غير صحيح');
  const btn = $('#profile-form [type=submit]');
  btn.disabled = true;
  try {
    S.profile = (await Cloud.updateMyProfile(name, nick, f.show.checked)) || (await Cloud.profile());
    const u = await Cloud.user();
    let msg = 'تم حفظ الملف';
    if (email.toLowerCase() !== u.email.toLowerCase()) {
      await Cloud.updateEmail(email);
      msg = 'أرسلنا رابط تأكيد إلى البريد الجديد — لن يتغيّر حتى تؤكّده';
    }
    closeSheet($('#profile-sheet'));
    renderAccount();
    toast(msg, { type: 'success', duration: 5000 });
  } catch (ex) {
    err.textContent = Cloud.msg(ex);
  } finally {
    btn.disabled = false;
  }
}

/* ================= الرسائل ================= */
const INBOX = { list: [] };
const seenIds = () => { try { return new Set(JSON.parse(localStorage.getItem('nw:msg-seen') || '[]')); } catch { return new Set(); } };
function markSeen(ids) {
  const s = seenIds();
  ids.forEach((i) => s.add(i));
  try { localStorage.setItem('nw:msg-seen', JSON.stringify([...s].slice(-300))); } catch { /* لا شيء */ }
}
async function loadInbox() {
  if (!Cloud.enabled || !(await Cloud.user())) return;
  try { INBOX.list = (await Cloud.messages()) || []; } catch { return; }
  const seen = seenIds();
  const unread = INBOX.list.filter((m) => !seen.has(m.id));
  $('#inbox-btn').hidden = !INBOX.list.length;
  $('#inbox-dot').hidden = !unread.length;
  $('#inbox-count').hidden = !unread.length;
  $('#inbox-count').textContent = UI.n(unread.length);
  if (typeof supLoad === 'function') supLoad();
  const fresh = unread.find((m) => !INBOX.notified?.has(m.id));
  if (fresh) {
    INBOX.notified = INBOX.notified || new Set();
    unread.forEach((m) => INBOX.notified.add(m.id));
    toast(`رسالة من الإدارة: ${fresh.title}`, { action: { label: 'عرض', run: openInbox }, duration: 7000 });
  }
}
/* نص الرسالة مع روابط قابلة للضغط + زر (مثل «اضغط هنا للتحديث») */
function msgBody(m) {
  const b = Links.body(m.body, m.link, m.link_label, { small: false });
  return [b.text.length ? h('p', { class: 'msg-text' }, ...b.text) : null, b.button];
}
function openInbox() {
  const seen = seenIds();
  const box = $('#inbox-list');
  box.replaceChildren(...(INBOX.list.length ? INBOX.list.map((m) => h('article', { class: `msg${seen.has(m.id) ? '' : ' new'}` },
    h('div', { class: 'msg-head' }, h('span', { class: 'msg-ic' }, NoticeUI.msgIcon(m)),
      h('b', { text: m.title }), h('small', { class: 'n-time', text: UI.relTime(new Date(m.created_at).getTime()) })),
    ...msgBody(m),
    h('small', { class: 'msg-kind', text: m.target ? 'رسالة خاصة لك' : 'إعلان للجميع' })))
    : [h('div', { class: 'empty' }, icon('inbox', { size: 36 }), h('p', { text: 'لا توجد رسائل' }))]));
  UI.digitize(box);
  openSheet('#inbox-sheet');
  markSeen(INBOX.list.map((m) => m.id));
  $('#inbox-dot').hidden = true;
  $('#inbox-count').hidden = true;
}
