/* NOBLE — لعبة المطاردة: الرسومات (سيارات، لوحات يمنية، مباني، أشجار، إشارات) — تصميم أصلي */
'use strict';
var ChaseArt = (() => {
  const shade = (hex, f = 0.55) => { const n = parseInt(hex.slice(1), 16); const c = (v) => Math.max(0, Math.min(255, Math.round(v * f))); return '#' + [c(n >> 16), c((n >> 8) & 255), c(n & 255)].map((x) => x.toString(16).padStart(2, '0')).join(''); };
  const GOVS = {
    'صنعاء': '#C8102E', 'عدن': '#1F6FEB', 'تعز': '#0F8A5F', 'حضرموت': '#B8661E', 'سقطرى': '#0FA3A3', 'مأرب': '#6B3FA0',
    'إب': '#2E8B3D', 'الحديدة': '#E08A00', 'المكلا': '#9C2A6E', 'ذمار': '#3C5A99', 'شبوة': '#8A6A1F', 'صعدة': '#5B3A29',
  };
  /* لوحة بطابع يمني: رقم مميز + المحافظة + NOBLE */
  function plate(p, police) {
    const band = police ? '#1537D1' : GOVS[p.gov] || '#C8102E';
    return `<g><rect x="78" y="92" width="64" height="24" rx="3" fill="#F7F7F2" stroke="#0B1638" stroke-width="1.2"/>
    <rect x="78" y="92" width="64" height="7" rx="2" fill="${band}"/>
    <text x="81" y="97.8" font-size="5" font-weight="900" fill="#fff" font-family="NobleUI, sans-serif">${police ? 'شرطة' : 'اليمن'}</text>
    <text x="139" y="97.8" text-anchor="end" font-size="4.6" font-weight="900" fill="#fff" font-family="Plex Latin, sans-serif">YEMEN</text>
    <text x="84" y="112.5" font-size="12" font-weight="900" fill="#0B1638" font-family="Plex Latin, sans-serif">${p.n}</text>
    <line x1="109" y1="101" x2="109" y2="114" stroke="#0B1638" stroke-width=".6"/>
    <text x="126" y="106.5" text-anchor="middle" font-size="6.2" font-weight="900" fill="#0B1638" font-family="NobleUI, sans-serif">${police ? 'نجدة' : p.gov}</text>
    <text x="126" y="113.5" text-anchor="middle" font-size="4.4" font-weight="900" fill="${band}" font-family="Plex Latin, sans-serif" letter-spacing=".6">NOBLE</text></g>`;
  }
  /* أشكال السيارات (منظر خلفي) */
  const BODIES = {
    gt: { roof: 'M70 32 Q74 27 84 27 L136 27 Q146 27 150 32 L168 56 L52 56 Z', body: 'M20 96 Q18 66 40 58 L64 30 Q70 22 82 22 L138 22 Q150 22 156 30 L180 58 Q202 66 200 96 L200 112 Q200 120 190 120 L30 120 Q20 120 20 112 Z', spoiler: true },
    muscle: { roof: 'M66 30 Q70 24 82 24 L138 24 Q150 24 154 30 L170 56 L50 56 Z', body: 'M16 100 Q14 66 36 58 L60 28 Q66 20 80 20 L140 20 Q154 20 160 28 L184 58 Q206 66 204 100 L204 114 Q204 122 194 122 L26 122 Q16 122 16 114 Z', spoiler: false, stripes: true },
    super: { roof: 'M78 40 Q84 34 92 34 L128 34 Q136 34 142 40 L162 60 L58 60 Z', body: 'M14 104 Q12 74 34 64 L72 36 Q80 30 92 30 L128 30 Q140 30 148 36 L186 64 Q208 74 206 104 L206 114 Q206 122 196 122 L24 122 Q14 122 14 114 Z', spoiler: true, wing: true },
    suv: { roof: 'M56 22 Q60 14 72 14 L148 14 Q160 14 164 22 L176 54 L44 54 Z', body: 'M18 104 L18 60 Q18 54 30 52 L52 16 Q58 8 72 8 L148 8 Q162 8 168 16 L190 52 Q202 54 202 60 L202 116 Q202 124 192 124 L28 124 Q18 124 18 116 Z', spoiler: false, rack: true },
  };
  function carSVG(color = '#E5484D', opts = {}) {
    const police = !!opts.police;
    const b = BODIES[opts.body || 'gt'] || BODIES.gt;
    const body = police ? '#F3F6FF' : color;
    const id = 'c' + Math.random().toString(36).slice(2, 7);
    return `<svg xmlns="http://www.w3.org/2000/svg" width="220" height="140" viewBox="0 0 220 140" style="direction:ltr"><defs>
    <linearGradient id="${id}b" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${body}"/><stop offset="1" stop-color="${police ? '#9AA6C8' : shade(color)}"/></linearGradient>
    <linearGradient id="${id}g" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#22305a"/><stop offset="1" stop-color="#05070f"/></linearGradient>
    <radialGradient id="${id}l"><stop offset="0" stop-color="#FF3B4E"/><stop offset="1" stop-color="#FF3B4E" stop-opacity="0"/></radialGradient></defs>
    <ellipse cx="110" cy="128" rx="104" ry="9" fill="#000" opacity=".5"/>
    <rect x="14" y="94" width="34" height="34" rx="7" fill="#0a0c14"/><rect x="172" y="94" width="34" height="34" rx="7" fill="#0a0c14"/>
    <path d="${b.body}" fill="url(#${id}b)"/>
    <path d="${b.roof}" fill="url(#${id}g)"/>
    <path d="M84 30 L100 30 L78 54 L62 54 Z" fill="#fff" opacity=".07"/>
    ${b.stripes && !police ? `<rect x="96" y="20" width="10" height="100" fill="#fff" opacity=".85"/><rect x="114" y="20" width="10" height="100" fill="#fff" opacity=".85"/>` : ''}
    ${police ? `<rect x="22" y="70" width="176" height="12" fill="#0B1638"/><text x="110" y="80" text-anchor="middle" font-size="10" font-weight="900" fill="#fff" font-family="NobleUI, sans-serif">شرطة</text>` : `<path d="M34 62 L186 62 L182 68 L38 68 Z" fill="#000" opacity=".22"/>`}
    <rect x="26" y="84" width="46" height="10" rx="5" fill="#FF2E44"/><rect x="148" y="84" width="46" height="10" rx="5" fill="#FF2E44"/>
    <ellipse cx="49" cy="89" rx="34" ry="14" fill="url(#${id}l)" opacity=".75"/><ellipse cx="171" cy="89" rx="34" ry="14" fill="url(#${id}l)" opacity=".75"/>
    ${plate(opts.plate || { n: '777', gov: 'صنعاء' }, police)}
    <rect x="30" y="114" width="160" height="5" rx="2.5" fill="#000" opacity=".35"/>
    <circle cx="78" cy="118" r="4" fill="#333"/><circle cx="142" cy="118" r="4" fill="#333"/>
    ${b.spoiler && !police ? `<rect x="28" y="${b.wing ? 42 : 50}" width="164" height="6" rx="3" fill="${shade(color, 0.4)}"/><rect x="44" y="${b.wing ? 42 : 50}" width="6" height="${b.wing ? 20 : 12}" fill="#111"/><rect x="170" y="${b.wing ? 42 : 50}" width="6" height="${b.wing ? 20 : 12}" fill="#111"/>` : ''}
    ${b.rack && !police ? `<rect x="60" y="2" width="100" height="6" rx="2" fill="#222"/>` : ''}
    ${police ? `<rect x="80" y="12" width="28" height="11" rx="4" fill="#FF2E44"/><rect x="112" y="12" width="28" height="11" rx="4" fill="#2E7BFF"/>` : ''}
    </svg>`;
  }
  /* بيت صنعاني برجي بنوافذ قمرية */
  function sanaaHouse(seed = 1, night = true) {
    const r = (k) => { const x = Math.sin(seed * 99.13 + k * 7.7) * 10000; return x - Math.floor(x); };
    const w = 120 + Math.round(r(1) * 60), floors = 4 + Math.floor(r(2) * 4), H = floors * 44 + 30;
    const wall = ['#6b4a35', '#5a3d2b', '#7a5440', '#4e3526'][Math.floor(r(3) * 4)];
    const cols = Math.max(2, Math.floor((w - 20) / 34));
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${H}" viewBox="0 0 ${w} ${H}"><rect width="${w}" height="${H}" fill="${wall}"/><rect width="${w}" height="10" fill="#EDE2CC"/>`;
    for (let f = 0; f < floors; f++) {
      const y = 22 + f * 44;
      s += `<rect x="0" y="${y - 8}" width="${w}" height="3" fill="#EDE2CC" opacity=".8"/>`;
      for (let c = 0; c < cols; c++) {
        const x = 12 + c * ((w - 24) / cols) + ((w - 24) / cols - 18) / 2;
        const lit = r(10 + f * 5 + c) > (night ? 0.35 : 0.9);
        const qc = ['#FFB43D', '#56C8FF', '#FF4D5E', '#1FC7A0', '#FFD66B'][Math.floor(r(20 + f + c * 3) * 5)];
        s += `<rect x="${x - 3}" y="${y - 4}" width="24" height="34" rx="2" fill="none" stroke="#EDE2CC" stroke-width="2.5"/>`;
        s += `<path d="M${x} ${y + 8} a9 9 0 0 1 18 0 Z" fill="${lit ? qc : '#2a1d15'}"/>`;
        s += `<rect x="${x}" y="${y + 8}" width="18" height="18" fill="${lit ? '#FFD08A' : '#20160f'}"/>`;
      }
    }
    return s + `<rect x="${w / 2 - 12}" y="${H - 34}" width="24" height="34" rx="12" fill="#1a120d"/></svg>`;
  }
  /* بيت شبام الطيني الطويل */
  function shibamHouse(seed = 1) {
    const r = (k) => { const x = Math.sin(seed * 51.7 + k * 3.3) * 10000; return x - Math.floor(x); };
    const w = 90 + Math.round(r(1) * 40), H = 260 + Math.round(r(2) * 140);
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${H}" viewBox="0 0 ${w} ${H}"><path d="M6 ${H} L10 8 L${w - 10} 8 L${w - 6} ${H} Z" fill="#C9A06B"/><rect x="10" y="0" width="${w - 20}" height="12" fill="#EFE6D6"/>`;
    for (let y = 30; y < H - 20; y += 34) for (let x = 20; x < w - 20; x += 22) s += `<rect x="${x}" y="${y}" width="9" height="13" fill="#5b3c22"/>`;
    return s + '</svg>';
  }
  function palm() { return `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="220" viewBox="0 0 120 220"><path d="M58 220 Q52 140 62 70" stroke="#6b4a2b" stroke-width="10" fill="none"/>${[[-50, -10], [-40, 25], [0, -40], [45, -15], [50, 25]].map(([dx, dy]) => `<path d="M62 70 Q${62 + dx / 2} ${60 + dy / 2 - 20} ${62 + dx} ${70 + dy}" stroke="#2E8B3D" stroke-width="9" fill="none" stroke-linecap="round"/>`).join('')}</svg>`; }
  function dragonTree() { return `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200" viewBox="0 0 200 200"><path d="M96 200 L100 110 L104 200 Z" fill="#7a6a5a"/><path d="M100 120 L60 80 M100 120 L140 80 M100 120 L100 75 M100 120 L75 95 M100 120 L125 95" stroke="#7a6a5a" stroke-width="6"/><ellipse cx="100" cy="66" rx="92" ry="30" fill="#2f7d3a"/><ellipse cx="100" cy="58" rx="80" ry="22" fill="#3c9a48"/></svg>`; }
  function pine() { return `<svg xmlns="http://www.w3.org/2000/svg" width="110" height="200" viewBox="0 0 110 200"><rect x="50" y="150" width="10" height="50" fill="#5b4030"/><path d="M55 0 L105 160 L5 160 Z" fill="#1f6b3a"/><path d="M55 30 L95 150 L15 150 Z" fill="#2a8a4a" opacity=".6"/></svg>`; }
  function rock() { return `<svg xmlns="http://www.w3.org/2000/svg" width="140" height="80" viewBox="0 0 140 80"><path d="M0 80 Q10 30 50 20 Q90 0 120 30 Q140 50 140 80 Z" fill="#cfc6b8"/><path d="M20 80 Q40 40 70 35" stroke="#fff" stroke-width="4" opacity=".4" fill="none"/></svg>`; }
  function lamp() { return `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="260" viewBox="0 0 80 260"><rect x="36" y="20" width="7" height="240" fill="#3a4060"/><path d="M40 22 Q40 6 64 8" stroke="#3a4060" stroke-width="6" fill="none"/><ellipse cx="66" cy="12" rx="10" ry="6" fill="#FFE2A0"/><circle cx="66" cy="14" r="26" fill="#FFD08A" opacity=".18"/></svg>`; }
  function trafficLight(state) {
    const c = (s, on) => (state === s ? on : '#1a1a1a');
    return `<svg xmlns="http://www.w3.org/2000/svg" width="70" height="250" viewBox="0 0 70 250"><rect x="31" y="90" width="8" height="160" fill="#444"/><rect x="15" y="0" width="40" height="100" rx="8" fill="#111" stroke="#333" stroke-width="2"/>
      <circle cx="35" cy="20" r="11" fill="${c('red', '#FF3B3B')}"/><circle cx="35" cy="50" r="11" fill="${c('yellow', '#FFC13B')}"/><circle cx="35" cy="80" r="11" fill="${c('green', '#29E36B')}"/>
      ${state ? `<circle cx="35" cy="${state === 'red' ? 20 : state === 'yellow' ? 50 : 80}" r="22" fill="${state === 'red' ? '#FF3B3B' : state === 'yellow' ? '#FFC13B' : '#29E36B'}" opacity=".3"/>` : ''}</svg>`;
  }
  function speedSign(limit) { return `<svg xmlns="http://www.w3.org/2000/svg" width="70" height="170" viewBox="0 0 70 170" style="direction:ltr"><rect x="32" y="60" width="6" height="110" fill="#8a93b0"/><circle cx="35" cy="35" r="32" fill="#fff" stroke="#E5484D" stroke-width="8"/><text x="35" y="46" text-anchor="middle" font-size="28" font-weight="900" fill="#111" font-family="Plex Latin, sans-serif">${limit}</text><rect x="22" y="100" width="26" height="16" rx="3" fill="#222"/><circle cx="35" cy="108" r="5" fill="#56C8FF"/></svg>`; }
  function guideSign(line1, line2) { return `<svg xmlns="http://www.w3.org/2000/svg" width="240" height="190" viewBox="0 0 240 190"><rect x="56" y="90" width="7" height="100" fill="#8a93b0"/><rect x="176" y="90" width="7" height="100" fill="#8a93b0"/><rect x="4" y="4" width="232" height="90" rx="8" fill="#0E6B3A" stroke="#fff" stroke-width="4"/><text x="220" y="42" text-anchor="end" font-size="26" font-weight="900" fill="#fff" font-family="NobleUI, sans-serif">${line1}</text><text x="220" y="78" text-anchor="end" font-size="22" font-weight="800" fill="#fff" font-family="NobleUI, sans-serif">${line2}</text></svg>`; }
  function coin() { return `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="60" viewBox="0 0 60 60"><circle cx="30" cy="30" r="27" fill="#FFB43D"/><circle cx="30" cy="30" r="20" fill="#FFD66B"/><text x="30" y="39" text-anchor="middle" font-size="24" font-weight="900" fill="#B8661E" font-family="Plex Latin">N</text></svg>`; }
  function nitroCan() { return `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="80" viewBox="0 0 60 80"><rect x="12" y="10" width="36" height="66" rx="10" fill="#2E5BFF"/><rect x="22" y="2" width="16" height="12" rx="3" fill="#8aa"/><text x="30" y="52" text-anchor="middle" font-size="16" font-weight="900" fill="#fff" font-family="Plex Latin">N2O</text></svg>`; }
  function barrier() { return `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="90" viewBox="0 0 200 90"><rect x="10" y="20" width="180" height="34" fill="#fff"/>${[0, 1, 2, 3, 4].map((i) => `<path d="M${10 + i * 40} 20 l20 0 l-20 34 l-20 0 Z" fill="#E5484D"/>`).join('')}<rect x="20" y="54" width="10" height="36" fill="#555"/><rect x="170" y="54" width="10" height="36" fill="#555"/><circle cx="25" cy="14" r="8" fill="#FFC13B"/><circle cx="175" cy="14" r="8" fill="#FFC13B"/></svg>`; }
  function minaret() { return `<svg xmlns="http://www.w3.org/2000/svg" width="60" height="320" viewBox="0 0 60 320"><rect x="20" y="40" width="20" height="280" fill="#E9DCC6"/><rect x="14" y="110" width="32" height="8" fill="#cbb89a"/><rect x="16" y="190" width="28" height="7" fill="#cbb89a"/><path d="M20 40 Q30 0 40 40 Z" fill="#E9DCC6"/><circle cx="30" cy="4" r="4" fill="#FFD66B"/></svg>`; }

  /* تحويل SVG إلى صورة للرسم السريع على الـ canvas */
  const cache = new Map();
  function img(key, svg) {
    if (cache.has(key)) return cache.get(key);
    const im = new Image();
    im.decoding = 'async';
    im.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
    cache.set(key, im);
    return im;
  }
  const ready = (list) => Promise.all(list.map((im) => (im.complete && im.naturalWidth ? Promise.resolve() : im.decode().catch(() => {}))));
  return { GOVS, plate, carSVG, sanaaHouse, shibamHouse, palm, dragonTree, pine, rock, lamp, trafficLight, speedSign, guideSign, coin, nitroCan, barrier, minaret, img, ready, shade };
})();
