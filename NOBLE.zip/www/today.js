/* NOBLE — «يومي»: صفحة واحدة لكل يومك + الإضافة السريعة بالذكاء الاصطناعي + تقاريري
 * كل الحسابات تتم على الجهاز من بياناتك المشفّرة. الإضافة السريعة ترسل النص المكتوب فقط لـ Gemini.
 */
'use strict';
const TODAY = { rep: 'week', money: false, qa: { text: '', items: null, busy: false, local: false } };
const tdKey = (d = new Date()) => ymd(d);
const tdAdd = (n, d = new Date()) => { const x = new Date(d); x.setDate(x.getDate() + n); return x; };
const arDigits = (s) => String(s).replace(/[٠-٩]/g, (c) => '٠١٢٣٤٥٦٧٨٩'.indexOf(c)).replace(/[۰-۹]/g, (c) => '۰۱۲۳۴۵۶۷۸۹'.indexOf(c));
const tdFeat = (k) => typeof Pro === 'undefined' || Pro.visible('today.' + k);

/* سجل يومي بسيط (زيارات المواقع) — للتقارير */
function bumpDay(v, key, n = 1) {
  v.act = v.act && typeof v.act === 'object' ? v.act : {};
  const d = tdKey();
  v.act[d] = { ...(v.act[d] || {}), [key]: ((v.act[d] || {})[key] || 0) + n };
  const keys = Object.keys(v.act).sort();
  if (keys.length > 400) keys.slice(0, keys.length - 400).forEach((k) => delete v.act[k]);
}

/* ================= يومي ================= */
function renderToday() {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  const root = $('#td-root');
  if (!root || !S.vault) return;
  const now = new Date();
  const hr = now.getHours();
  const hello = hr < 12 ? 'صباح الخير' : hr < 18 ? 'مساء النور' : 'مساء الخير';
  const name = (S.profile?.display_name || '').split(/\s+/)[0];
  const greg = now.toLocaleDateString(UI.loc(), { weekday: 'long', day: 'numeric', month: 'long' });
  let hijri = '';
  try { hijri = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura-nu-latn', { day: 'numeric', month: 'long' }).format(now); } catch { /* لا شيء */ }
  const parts = [
    h('div', { class: 'td-head' },
      h('div', {}, h('h1', { class: 'view-title', text: `${hello}${name ? '، ' + name : ''} ${hr < 18 ? '☀️' : '🌙'}` }), h('small', { text: [greg, hijri].filter(Boolean).join(' · ') })),
      tdFeat('reports') ? h('button', { type: 'button', class: 'td-rep-btn', onclick: () => openReports() }, '📊 تقاريري') : null),
  ];
  if (tdFeat('quick')) parts.push(h('button', { type: 'button', class: 'td-qa', onclick: () => openQuickAdd() },
    h('span', { text: '✨ اكتب أو قل: «ادفع الكهرباء ٣٠٠ بكرة»' }), h('b', { class: 'td-mic', text: '🎙' })));
  const alert = tdAlert();
  if (alert) parts.push(alert);
  if (typeof ainTodayCard === 'function') parts.push(ainTodayCard());
  if (typeof tdDailyCard === 'function') parts.push(tdDailyCard());
  parts.push(tdTasksCard());
  parts.push(h('div', { class: 'td-row' }, tdMoneyCard(), tdGamesCard()));
  const nc = tdNewsCard();
  if (nc) parts.push(nc);
  root.replaceChildren(...parts.filter(Boolean));
  if (typeof dscPaintRing === 'function') { dscPaintRing(); loadFeed(); }
  if (typeof loadAiNews === 'function') loadAiNews();
  UI.digitize(root);
}
const tdOpen = (tab) => () => setTab(tab);
function tdAlert() {
  const tasks = (S.vault.tasks || []).filter((t) => t.status !== 'done');
  const over = tasks.filter((t) => typeof isOverdue === 'function' && isOverdue(t));
  if (over.length) return h('button', { type: 'button', class: 'td-alert bad', onclick: tdOpen('tasks') }, '⚠️ ', h('span', {}, h('b', { text: `${UI.n(over.length)} مهمة متأخرة` }), ` — أقدمها: ${over[0].title}`));
  if (typeof fin !== 'function' || !S.vault.fin || secOff('finance')) return null;
  const f = fin(), soon = tdKey(tdAdd(3));
  const r = (f.recurring || []).filter((x) => x.active !== false && x.type === 'expense' && x.next && x.next <= soon).sort((a, b) => a.next.localeCompare(b.next))[0];
  if (!r) return null;
  const when = r.next <= tdKey() ? 'تستحق اليوم' : r.next === tdKey(tdAdd(1)) ? 'تستحق بكرة' : 'تستحق قريباً';
  return h('button', { type: 'button', class: 'td-alert', onclick: tdOpen('finance') }, '⏰ ', h('span', {}, h('b', { text: r.name }), ` — ${when} · ${money(r.amount, { show: true })}`));
}
function tdTasksCard() {
  const all = S.vault.tasks || [];
  const today = tdKey();
  const list = all.filter((t) => t.status !== 'done' && t.due && t.due <= today).sort((a, b) => (a.due + (a.time || '99')).localeCompare(b.due + (b.time || '99')));
  const doneToday = all.filter((t) => t.status === 'done' && t.doneAt && tdKey(new Date(t.doneAt)) === today);
  const total = list.length + doneToday.length, pct = total ? doneToday.length / total : 0;
  const ring = h('div', { class: 'td-ring', style: { '--p': Math.round(pct * 100) + '%' } }, h('b', { class: 'num', text: `${doneToday.length}/${total}` }));
  const row = (t, done) => h('div', { class: `td-task${done ? ' done' : ''}` },
    h('button', { type: 'button', class: 'td-chk', 'aria-label': done ? 'إلغاء الإنجاز' : 'إنجاز', onclick: async (e) => { e.stopPropagation(); await toggleDone(t.id, e.currentTarget); renderToday(); } }, done ? '✓' : ''),
    h('span', { class: 'td-tt', text: t.title, onclick: () => openTaskById(t.id) }),
    t.priority === 'high' ? h('i', { class: 'td-hi' }) : null,
    h('em', { text: !done && typeof isOverdue === 'function' && isOverdue(t) ? 'متأخرة' : t.time ? fmtTime(t.time) : 'اليوم' }));
  return h('section', { class: 'td-card' },
    h('div', { class: 'td-ct' }, h('b', { text: '✅ مهام اليوم' }), total ? ring : null),
    total ? h('div', { class: 'td-tasks' }, ...list.slice(0, 4).map((t) => row(t, false)), ...doneToday.slice(0, Math.max(0, 4 - Math.min(4, list.length))).map((t) => row(t, true)))
      : h('p', { class: 'td-empty', text: 'ما عندك مهام اليوم 👌 — أضف وحدة بالإضافة السريعة.' }),
    list.length > 4 ? h('button', { type: 'button', class: 'link-btn td-more', onclick: tdOpen('tasks') }, `+${UI.n(list.length - 4)} مهام ثانية`) : null);
}
function tdMoneyCard() {
  if (typeof fin !== 'function' || (typeof blockedTabs === 'function' && blockedTabs().has('finance'))) return null;
  const f = fin(), ym = tdKey().slice(0, 7);
  const spent = f.tx.filter((t) => t.type === 'expense' && String(t.date).slice(0, 7) === ym).reduce((s, t) => s + t.amount, 0);
  const budget = Object.values(f.budgets || {}).reduce((s, v) => s + (Number(v) || 0), 0);
  const pct = budget ? Math.min(100, Math.round((spent / budget) * 100)) : 0;
  return h('button', { type: 'button', class: 'td-card td-mini', onclick: tdOpen('finance') },
    h('b', { text: '💳 مصروف الشهر' }), h('span', { class: 'td-big num', text: money(spent, { bare: true }) }),
    budget ? h('div', { class: 'td-bar' + (pct >= 100 ? ' over' : '') }, h('i', { style: { width: pct + '%' } })) : null,
    h('small', { text: budget ? `من ميزانية ${money(budget, { show: true })}` : f.settings.currency }));
}
function tdGamesCard() {
  if (typeof gstate !== 'function' || (typeof blockedTabs === 'function' && blockedTabs().has('games'))) return null;
  const g = gstate();
  const streak = g.streak?.last === todayKey() || g.streak?.last === new Date(Date.now() - 864e5).toISOString().slice(0, 10) ? g.streak.n : 0;
  return h('button', { type: 'button', class: 'td-card td-mini', onclick: tdOpen('games') },
    h('b', { text: '🎮 الألعاب' }), h('span', { class: 'td-big num', text: UI.n(g.points || 0) }),
    h('small', { text: `نقطة${streak ? ` · 🔥 ${UI.n(streak)} يوم` : ''}` }), h('small', { class: 'td-go', text: 'العب ←' }));
}
function tdNewsCard() {
  if (typeof newsCache !== 'function' || (typeof blockedTabs === 'function' && blockedTabs().has('news'))) return null;
  const items = (typeof NEWS !== 'undefined' && NEWS.items.length ? NEWS.items : newsCache()).slice(0, 2);
  if (!items.length) { if (typeof loadNews === 'function' && Cloud.enabled && !NEWS.loaded) loadNews().then(() => S.tab === 'today' && renderToday()); return null; }
  return h('section', { class: 'td-card' },
    h('div', { class: 'td-ct' }, h('b', { text: `⚡ ${NEWS.meta?.title || 'نبض AI'}` }), h('button', { type: 'button', class: 'link-btn', onclick: tdOpen('news') }, 'الكل')),
    ...items.map((it) => h('button', { type: 'button', class: 'td-news', onclick: () => openNews(it) }, newsImg(it, 'td-nth'), h('span', { text: it.title }))));
}

/* ================= الإضافة السريعة ================= */
let qaEl = null;
/* 1.17.1: وين يروح الكلام؟ (تلقائي · مهام · مصروف · دخل · المواقع) — الإدارة تتحكم من «🎙 الصوت والمايك» */
const QA_DEST = [['auto', 'qaAuto'], ['task', 'qaTask'], ['expense', 'qaExpense'], ['income', 'qaIncome'], ['site', 'qaSite']];
const QA_SEC = { task: 'tasks', expense: 'finance', income: 'finance', site: 'sites' }; // كل وجهة ← قسمها
const qaOff = (k) => !!QA_SEC[k] && typeof secOff === 'function' && secOff(QA_SEC[k]);
const qaDcfg = () => { const v = (typeof Market !== 'undefined' && Market.get().voice) || {}; const d = v.dest || {}; return { pick: v.destPick !== false, def: v.destDef || 'auto', on: (k) => k === 'auto' || d[k] !== false }; };
const qaDests = () => QA_DEST.filter(([k]) => qaDcfg().on(k) && !qaOff(k));
function qaDestNow() { const c = qaDcfg(); let k = ''; try { k = localStorage.getItem('nw:qaDest') || ''; } catch { /* لا شيء */ } if (!c.pick) k = c.def; return qaDests().some(([x]) => x === k) ? k : (qaDests().some(([x]) => x === c.def) ? c.def : 'auto'); }
/* نفهم الوجهة من الكلام نفسه: «ضيف مصروف ٥٠ بنزين» · «سجل في المالية…» · «ذكّرني…» · «احفظ الموقع…» */
function qaIntent(raw) { const k = qaIntent0(raw); return k && qaOff(k) ? '' : k; }
function qaIntent0(raw) {
  const t = arDigits(String(raw || ''));
  const amt = /\d/.test(t);
  if (/https?:\/\/|\b[a-z0-9-]+\.(?:com|net|org|io|ai|sa|co|app|dev)\b|(?:^|\s)(?:موقع|رابط)(?=\s|$)/i.test(t) && !amt) return 'site';
  if (amt && /دخل|إيراد|ايراد|راتب|استلمت|جاني|حوّل لي|حول لي/.test(t)) return 'income';
  if (amt && /مصروف|مصاريف|المالي[ةه]|الخزن[ةه]|الحساب|صرفت|دفعت|اشتريت|شريت|سددت|خصم/.test(t)) return 'expense';
  if (/مهم[ةه]|ذكّرني|ذكرني|تذكير|موعد|لا تنسى/.test(t)) return 'task';
  return '';
}
const qaNum = (s) => { const m = arDigits(String(s || '')).match(/(\d+(?:[.,]\d+)?)/); return m ? Number(m[1].replace(',', '.')) : 0; };
const QA_STRIP = /^(?:ضيف|أضف|اضف|سجّل|سجل|حط)\s+|\s*(?:في|ف|على)\s+(?:المالي[ةه]|الخزن[ةه]|المهام|الحساب)\s*|(?<=^|\s)(?:مصروف|مصاريف|دخل|مهم[ةه])(?=\s|$)\s*/g;
/* تحويل بطاقة لنوع ثاني (المستخدم يضغط النوع) */
function qaConvert(it, type) {
  const text = TODAY.qa.text;
  const title = (it.title || it.note || text.replace(QA_STRIP, ' ').replace(/\d+(?:[.,]\d+)?\s*(?:ريال|ر\.س|﷼)?/g, '').replace(/\s+/g, ' ').trim() || text).slice(0, 200);
  if (type === 'task') return { type, title, due: it.due || it.date || tdKey(), time: it.time || '', remind: it.remind ?? '', priority: it.priority || 'none', on: true };
  if (type === 'expense' || type === 'income') return { type, amount: it.amount || qaNum(it.title || it.note) || qaNum(text), category: it.type === type ? it.category : '', account: it.account || '', date: it.date || it.due || tdKey(), note: title, on: true };
  if (type === 'site') { const u = (String(it.url || text).match(/https?:\/\/\S+|\b[a-z0-9-]+\.(?:com|net|org|io|ai|sa|co|app|dev)(?:\/\S*)?/i) || [])[0]; if (!u) return null; return { type, url: /^https?:/.test(u) ? u : 'https://' + u, name: u.replace(/^https?:\/\//, '').split('/')[0], on: true }; }
  return null;
}
/* نطبّق الوجهة على نتيجة الفهم */
function qaApplyDest(items, dest) {
  const tidy = (n) => String(n || '').replace(QA_STRIP, ' ').replace(/\s+/g, ' ').trim();
  items = items.map((x) => (x.type === 'expense' || x.type === 'income' ? { ...x, amount: Number(x.amount) > 0 ? x.amount : qaNum(TODAY.qa.text), note: tidy(x.note) } : x.type === 'task' ? { ...x, title: tidy(x.title) || x.title } : x));
  // نتيجة لقسم مخفي (مالية/مواقع…) تتحوّل لمهمة — ما نذكر القسم المخفي أبد
  items = items.map((x) => (qaOff(x.type) ? (qaOff('task') ? null : qaConvert(x, 'task')) : x)).filter(Boolean);
  const want = dest !== 'auto' && !qaOff(dest) ? dest : qaIntent(TODAY.qa.text);
  if (!want) return items;
  const same = items.filter((x) => x.type === want);
  if (same.length) return dest !== 'auto' ? same : items;
  const base = items[0] || { type: 'task', title: TODAY.qa.text };
  const c = qaConvert(base, want);
  return c ? [c] : items;
}
function openQuickAdd(text = '', o = {}) {
  if (typeof Pro !== 'undefined' && !Pro.gate('today.quick', qaUsed())) return;
  if (!qaEl) { qaEl = h('section', { class: 'sheet qa-sheet', id: 'qa-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(qaEl); }
  TODAY.qa = { text, items: null, busy: false, local: false, dest: qaDestNow() };
  paintQuickAdd();
  openSheet('#qa-sheet');
  if (o.voice && text && typeof Voice !== 'undefined' && Voice.ucfg().auto) { qaRun(); return; }
  setTimeout(() => qaEl.querySelector('textarea')?.focus(), 250);
}
const qaKey = () => 'nw:qa:' + tdKey();
const qaUsed = () => { try { return Number(localStorage.getItem(qaKey())) || 0; } catch { return 0; } };
/* المثال داخل الخانة: لو يذكر المالية أو المواقع وهي مخفية، نعرض مثال المهمة */
function qaAutoPh() {
  const x = Content.get('exQuick') || '';
  const fin = /ريال|﷼|فاتور|مصروف|دخل|راتب/.test(x), site = /https?:|\.(?:com|app|net|sa)\b|موقع|رابط/.test(x);
  return (fin && qaOff('expense')) || (site && qaOff('site')) ? Content.get('qaPhTask') : x;
}
function paintQuickAdd() {
  const q = TODAY.qa;
  const ta = h('textarea', { class: 'input textarea qa-in', rows: 2, maxlength: 400, placeholder: ({ task: Content.get('qaPhTask'), expense: Content.get('qaPhExpense'), income: Content.get('qaPhIncome'), site: Content.get('qaPhSite') })[q.dest] || qaAutoPh() });
  ta.value = q.text;
  ta.addEventListener('input', () => { q.text = ta.value; });
  ta.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); qaRun(); } });
  // 1.17: مايك الجوال الحقيقي (Voice) — ضغطة/ضغط مطوّل + شاشة استماع
  const mic = typeof Voice !== 'undefined' ? Voice.button({ sec: 'quick', input: ta, onText: () => { q.text = ta.value; if (Voice.ucfg().auto) qaRun(); } }) : null;
  if (mic) mic.classList.add('qa-mic');
  const ex = String(Content.get('exQuickList') || '').split('|').map((x) => x.trim()).filter((x) => x && !qaOff(qaIntent0(x))).slice(0, 6); // أمثلة الأقسام المخفية ما تطلع
  const res = q.items ? (q.items.length ? h('div', { class: 'qa-res' },
    h('b', { class: 'qa-lbl', text: q.local ? `${Content.get('qaGot').replace(/:$/, '')} (فهم مبسّط بدون نت):` : Content.get('qaGot') }),
    ...q.items.map((it, i) => qaCard(it, i)),
    h('div', { class: 'qa-btns' },
      h('button', { type: 'button', class: 'btn', onclick: () => { q.items = null; paintQuickAdd(); setTimeout(() => qaEl.querySelector('textarea')?.focus(), 50); } }, '✎ عدّل'),
      h('button', { type: 'button', class: 'btn btn-primary', disabled: !q.items.some((x) => x.on !== false), onclick: qaSave }, `أضف ${q.items.filter((x) => x.on !== false).length > 1 ? 'الكل' : ''} ✓`)))
    : h('p', { class: 'td-empty', text: Content.get('qaFail') })) : null;
  qaEl.replaceChildren(h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: Content.get('qaTitle') }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(qaEl) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body qa-body' },
      qaDcfg().pick && qaDests().length > 2 ? h('div', { class: 'qa-dest', role: 'radiogroup', 'aria-label': Content.get('qaWhere') }, h('span', { class: 'qa-dl', text: Content.get('qaWhere') }),
        ...qaDests().map(([k, ck]) => h('button', { type: 'button', class: q.dest === k ? 'on' : '', 'aria-pressed': String(q.dest === k), onclick: () => { q.dest = k; try { localStorage.setItem('nw:qaDest', k); } catch { /* لا شيء */ } if (q.items) qaRun(); else paintQuickAdd(); } }, Content.get(ck)))) : null,
      h('div', { class: 'qa-box' }, ta, mic),
      q.items ? null : h('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: q.busy, onclick: qaRun }, q.busy ? h('span', { class: 'qa-dots' }, Content.get('qaBusy'), h('i'), h('i'), h('i')) : Content.get('qaBtn')),
      res,
      q.items ? null : h('div', { class: 'qa-ex' }, ...ex.map((x) => h('button', { type: 'button', onclick: () => { q.text = x; qaRun(); } }, `«${x}»`))),
      h('p', { class: 'qa-note', text: Content.get('qaNote') })));
  UI.digitize(qaEl.querySelector('.qa-res') || qaEl);
}
function qaCard(it, i) {
  const f = typeof fin === 'function' ? fin() : null;
  const dl = (d) => !d ? '' : d === tdKey() ? 'اليوم' : d === tdKey(tdAdd(1)) ? 'بكرة' : new Date(d + 'T12:00').toLocaleDateString(UI.loc(), { weekday: 'long', day: 'numeric', month: 'short' });
  let title = '', sub = '', cls = '';
  if (it.type === 'task') {
    cls = 't'; title = `✅ مهمة: ${it.title}`;
    sub = [dl(it.due), it.time ? fmtTime(it.time) : '', it.remind !== '' ? (it.remind === '0' ? 'تنبيه عند الموعد' : it.remind === '1440' ? 'تنبيه قبل يوم' : `تنبيه قبل ${it.remind === '60' ? 'ساعة' : it.remind + ' د'}`) : '', it.priority === 'high' ? 'أولوية عالية' : ''].filter(Boolean).join(' · ') || 'بدون موعد';
  } else if (it.type === 'expense' || it.type === 'income') {
    cls = it.type === 'income' ? 'i' : 'f';
    const c = f ? qaCat(f, it) : null, a = f ? qaAcc(f, it) : null;
    title = `${it.type === 'income' ? '💰 دخل' : '💳 مصروف'}: ${money(it.amount, { show: true })}`;
    sub = [c?.name, a?.name, dl(it.date || tdKey()), it.note].filter(Boolean).join(' · ');
  } else if (it.type === 'site') { cls = 's'; title = `🔗 موقع: ${it.name || it.url}`; sub = it.url; }
  const q = TODAY.qa;
  const sw = qaDests().filter(([k]) => k !== 'auto').map(([k, ck]) => { const l = Content.get(ck); const ok = k === it.type || !!qaConvert(it, k); return h('button', { type: 'button', class: k === it.type ? 'on' : '', disabled: !ok, title: `حوّلها ${l}`, onclick: () => { if (k === it.type) return; const c = qaConvert(it, k); if (c) { q.items[i] = c; paintQuickAdd(); } } }, l); });
  const amt = (it.type === 'expense' || it.type === 'income') ? h('label', { class: 'qa-amt' }, h('span', { text: 'المبلغ' }), (() => { const n = h('input', { class: 'input num', type: 'number', inputmode: 'decimal', min: 0, step: 'any', value: it.amount || '' }); n.addEventListener('input', () => { it.amount = Math.max(0, Number(n.value) || 0); const b = n.closest('.qa-card')?.querySelector('.qa-ck b'); if (b) b.textContent = `${it.type === 'income' ? '💰 دخل' : '💳 مصروف'}: ${money(it.amount, { show: true })}`; }); return n; })()) : null;
  return h('div', { class: `qa-card ${cls}${it.on === false ? ' off' : ''}` },
    h('label', { class: 'qa-ck' }, h('input', { type: 'checkbox', checked: it.on !== false, onchange: (e) => { it.on = e.target.checked; paintQuickAdd(); } }),
      h('span', {}, h('b', { text: title }), h('small', { text: sub }))),
    amt,
    sw.length > 1 ? h('div', { class: 'qa-sw' }, h('small', { text: 'مو هنا؟ حوّلها:' }), ...sw) : null);
}
const CAT_HINT = [[/بنزين|وقود|سيار|غسيل|زيت/i, 'سيار'], [/كهرب|ماء|مويه|جوال|نت|انترنت|فاتور|اتصال|stc|موبايلي|زين/i, 'فواتير'], [/قهو|مطعم|غدا|عشا|فطور|أكل|اكل|كوفي|بيتزا|برجر/i, 'أكل'], [/ايجار|إيجار|سكن/i, 'سكن'], [/صيدلي|دكتور|مستشفى|علاج/i, 'صحة'], [/اشتراك|chatgpt|claude|midjourney|adobe|figma|canva/i, 'اشتراك'], [/سوق|مول|ملابس|amazon|نون|شراء/i, 'تسوق'], [/تصميم|شعار|هوي/i, 'تصميم'], [/تصوير/i, 'تصوير'], [/راتب/i, 'راتب']];
function qaCat(f, it) {
  const kind = it.type === 'income' ? 'income' : 'expense';
  const cats = f.cats.filter((c) => c.kind === kind);
  const name = String(it.category || '').trim();
  let c = name && cats.find((x) => x.name === name || x.name.includes(name) || name.includes(x.name));
  if (!c) { const txt = `${name} ${it.note || ''} ${TODAY.qa.text}`; const hint = CAT_HINT.find(([re]) => re.test(txt)); if (hint) c = cats.find((x) => x.name.includes(hint[1])); }
  return c || cats.find((x) => /أخرى|آخر/.test(x.name)) || cats[0];
}
const qaAcc = (f, it) => f.accounts.find((a) => it.account && (a.name === it.account || a.name.includes(it.account))) || f.accounts.find((a) => !a.archived) || f.accounts[0];

async function qaRun() {
  const q = TODAY.qa;
  const text = q.text.trim();
  if (text.length < 2 || q.busy) return;
  if (typeof Pro !== 'undefined' && !Pro.gate('today.quick', qaUsed())) return;
  q.busy = true; paintQuickAdd();
  const tok = (q.tok = (q.tok || 0) + 1);
  let items = null, local = false;
  if (Cloud.enabled && navigator.onLine !== false) {
    try {
      const f = typeof fin === 'function' ? fin() : null;
      const r = await Cloud.quickParse(text, { today: tdKey(), cats: f ? f.cats.map((c) => c.name) : [], accounts: f ? f.accounts.filter((a) => !a.archived).map((a) => a.name) : [] });
      items = r.items || [];
      try { localStorage.setItem(qaKey(), String(qaUsed() + 1)); } catch { /* لا شيء */ }
    } catch (e) {
      if (e.code === 'limit') toast(`وصلت الحد اليومي للإضافة الذكية (${UI.n(e.max || '')}) — استخدمنا الفهم المبسّط`, { duration: 5000 });
    }
  }
  if (tok !== q.tok || TODAY.qa !== q) return;
  if (!items) { items = localParse(text); local = true; }
  items = qaApplyDest(items.map((x) => ({ ...x, on: true })), q.dest || 'auto').filter((x) => qaDests().some(([k]) => k === x.type));
  q.items = items.map((x) => ({ ...x, on: true })); q.local = local; q.busy = false;
  paintQuickAdd();
}
/* فهم مبسّط بدون نت (احتياطي) */
function localParse(raw) {
  const text = arDigits(raw).replace(/\s+/g, ' ').trim();
  const items = [];
  const url = text.match(/https?:\/\/\S+|\b[a-z0-9-]+\.(?:com|net|org|io|ai|sa|co|app|dev)(?:\/\S*)?/i);
  if (url) { const u = /^https?:/.test(url[0]) ? url[0] : 'https://' + url[0]; items.push({ type: 'site', url: u, name: url[0].replace(/^https?:\/\//, '').split('/')[0] }); return items; }
  let date = tdKey();
  if (/بعد بكر[هة]/.test(text)) date = tdKey(tdAdd(2)); else if (/بكر[هة]|غد[اًا]?/.test(text)) date = tdKey(tdAdd(1));
  const tm = text.match(/(?:الساعة|ساعة)\s*(\d{1,2})(?::(\d{2}))?\s*(م|مساء|ص|صباح|العصر|المغرب|الليل)?/);
  let time = '';
  if (tm) { let hh = Number(tm[1]); const pm = /م|مساء|العصر|المغرب|الليل/.test(tm[3] || '') || (!tm[3] && hh < 7); if (pm && hh < 12) hh += 12; time = `${String(hh).padStart(2, '0')}:${tm[2] || '00'}`; }
  const am = text.match(/(\d+(?:[.,]\d+)?)\s*(?:ريال|ر\.س|﷼|sar|رس)?/i);
  const amount = am && !(tm && am.index === tm.index + tm[0].indexOf(tm[1])) ? Number(am[1].replace(',', '.')) : 0;
  const clean = (s) => s.replace(/(?:الساعة|ساعة)\s*\d{1,2}(?::\d{2})?\s*(?:م|مساء|ص|صباح|العصر|المغرب|الليل)?/g, '').replace(/\d+(?:[.,]\d+)?\s*(?:ريال|ر\.س|﷼|sar|رس)?/gi, '').replace(/بعد بكر[هة]|بكر[هة]|اليوم|ذكرني|لازم|أبي|ابي/g, '').replace(/\s+/g, ' ').trim();
  if (amount && /صرفت|دفعت|اشتريت|شريت|سددت/.test(text)) { items.push({ type: 'expense', amount, category: '', account: '', date: tdKey(), note: clean(text.replace(/صرفت|دفعت|اشتريت|شريت|سددت/, '')) }); return items; }
  if (amount && /استلمت|جاني|دخل|حوّل لي|حول لي|راتب/.test(text)) { items.push({ type: 'income', amount, category: '', account: '', date, note: clean(text.replace(/استلمت|جاني|دخل لي/, '')) }); return items; }
  items.push({ type: 'task', title: clean(text) || text, due: date, time, remind: time ? '60' : (date !== tdKey() ? '0' : ''), priority: /ضروري|مهم|عاجل/.test(text) ? 'high' : 'none' });
  if (amount && /ادفع|سدد|فاتور|قسط|إيجار|ايجار/.test(text)) items.push({ type: 'expense', amount, category: '', account: '', date, note: clean(text) });
  return items;
}
async function qaSave() {
  const items = TODAY.qa.items.filter((x) => x.on !== false);
  if (!items.length) return;
  if (items.some((x) => (x.type === 'expense' || x.type === 'income') && !(Number(x.amount) > 0))) { toast('اكتب المبلغ أول 💳', { type: 'error' }); qaEl.querySelector('.qa-amt input')?.focus(); return; }
  const added = [];
  await commit((v) => {
    for (const it of items) {
      if (it.type === 'task') {
        v.tasks = v.tasks || [];
        const due = it.due || '';
        const t = { id: crypto.randomUUID(), title: it.title.slice(0, 200), desc: '', due, time: it.time || (due && it.remind !== '' && it.remind != null ? '09:00' : ''), remind: due ? (it.remind ?? '') : '', repeat: '', project: '', status: 'todo', priority: it.priority || 'none', siteId: '', subtasks: [], createdAt: Date.now(), updatedAt: Date.now(), doneAt: 0, via: 'quick' };
        v.tasks.push(t); added.push(['task', t]);
      } else if (it.type === 'expense' || it.type === 'income') {
        v.fin = normFin(v.fin);
        const c = qaCat(v.fin, it), a = qaAcc(v.fin, it);
        const tx = { id: crypto.randomUUID(), type: it.type, amount: it.amount, acc: a?.id, cat: c?.id, scope: c?.scope === 'work' ? 'work' : 'personal', date: it.date || tdKey(), note: (it.note || TODAY.qa.text).slice(0, 120), createdAt: Date.now(), via: 'quick' };
        v.fin.tx.push(tx); added.push(['tx', tx]);
      } else if (it.type === 'site') {
        Core.insertItem(v, { name: it.name || it.url, url: it.url, category: '' }); added.push(['site']);
      }
    }
  });
  added.filter(([k]) => k === 'task').forEach(([, t]) => { try { Notify.schedule(S.vault.tasks.find((x) => x.id === t.id) || t); } catch { /* لا شيء */ } });
  buzz('success');
  closeSheet(qaEl);
  const n = { task: added.filter((x) => x[0] === 'task').length, tx: added.filter((x) => x[0] === 'tx').length, site: added.filter((x) => x[0] === 'site').length };
  if (typeof markActive === 'function') markActive('quick');
  toast(['تمت الإضافة ✓', n.task ? `${UI.n(n.task)} مهمة` : '', n.tx ? `${UI.n(n.tx)} حركة مالية` : '', n.site ? 'موقع' : ''].filter(Boolean).join(' · '), { type: 'success' });
  Sync?.event?.('quick_add', { n: added.length, local: TODAY.qa.local });
  render();
  if (S.tab === 'today') renderToday();
}

/* ================= تقاريري ================= */
function reportData(period = TODAY.rep) {
  const end = new Date(); end.setHours(23, 59, 59, 999);
  const start = new Date(end);
  if (period === 'week') start.setDate(start.getDate() - 6); else start.setDate(1);
  start.setHours(0, 0, 0, 0);
  const days = [];
  for (let d = new Date(start); d <= end; d.setDate(d.getDate() + 1)) days.push(tdKey(d));
  const prevStart = new Date(start); prevStart.setDate(prevStart.getDate() - days.length);
  const inP = (ts) => ts >= start.getTime() && ts <= end.getTime();
  const inPrev = (ts) => ts >= prevStart.getTime() && ts < start.getTime();
  const tasks = S.vault.tasks || [];
  const done = tasks.filter((t) => t.status === 'done' && t.doneAt && inP(t.doneAt));
  const donePrev = tasks.filter((t) => t.status === 'done' && t.doneAt && inPrev(t.doneAt)).length;
  const missed = tasks.filter((t) => t.status !== 'done' && t.due && t.due >= days[0] && t.due < tdKey()).length;
  const rate = done.length + missed ? Math.round((done.length / (done.length + missed)) * 100) : done.length ? 100 : 0;
  const perDay = days.map((d) => done.filter((t) => tdKey(new Date(t.doneAt)) === d).length);
  let spend = 0, income = 0, byCat = [];
  if (typeof fin === 'function') {
    const f = fin();
    const tx = f.tx.filter((t) => t.date >= days[0] && t.date <= days[days.length - 1]);
    const m = {};
    tx.forEach((t) => { if (t.type === 'expense') { spend += t.amount; m[t.cat] = (m[t.cat] || 0) + t.amount; } else if (t.type === 'income') income += t.amount; });
    byCat = Object.entries(m).map(([id, v]) => ({ name: catOf(f, id)?.name || 'أخرى', v })).sort((a, b) => b.v - a.v).slice(0, 5);
  }
  const act = S.vault.act || {};
  const visits = days.reduce((s, d) => s + (act[d]?.visits || 0), 0);
  const g = typeof gstate === 'function' ? gstate() : {};
  const pts = days.reduce((s, d) => s + (g.pd?.[d] || 0), 0);
  const streak = g.streak?.n || 0;
  const topSites = [...(S.vault.items || [])].filter((x) => x.lastVisited && inP(x.lastVisited)).sort((a, b) => (b.visits || 0) - (a.visits || 0)).slice(0, 3);
  return { period, days, done: done.length, donePrev, rate, perDay, spend, income, byCat, visits, pts, streak, topSites };
}
function openReports() {
  if (typeof Pro !== 'undefined' && !Pro.gate('today.reports')) return;
  openScreen((el) => paintReports(el), { cls: 'td-screen', onBack: () => { closeScreen(); if (S.tab === 'today') renderToday(); } });
}
const tdCount = (n) => n === 1 ? 'مهمة وحدة' : n === 2 ? 'مهمتين' : n <= 10 ? `${UI.n(n)} مهام` : `${UI.n(n)} مهمة`;
function paintReports(el = GS.screen) {
  if (!el) return;
  const R = reportData();
  const wk = R.period === 'week';
  const diff = R.done - R.donePrev;
  const dayLbl = (d) => new Date(d + 'T12:00').toLocaleDateString(UI.loc(), { weekday: 'short' });
  const maxD = Math.max(1, ...R.perDay);
  // الشهر: نجمع بالأسابيع حتى تبقى الأعمدة واضحة
  const bars = wk ? R.perDay.map((n, i) => [dayLbl(R.days[i]), n, i === R.days.length - 1]) :
    Array.from({ length: Math.ceil(R.days.length / 7) }, (_, w) => [`أسبوع ${UI.n(w + 1)}`, R.perDay.slice(w * 7, w * 7 + 7).reduce((a, b) => a + b, 0), w === Math.ceil(R.days.length / 7) - 1]);
  const maxB = Math.max(1, ...bars.map((b) => b[1]));
  const maxC = Math.max(1, ...R.byCat.map((c) => c.v));
  const range = `${new Date(R.days[0] + 'T12:00').toLocaleDateString(UI.loc(), { day: 'numeric', month: 'short' })} – ${new Date(R.days[R.days.length - 1] + 'T12:00').toLocaleDateString(UI.loc(), { day: 'numeric', month: 'short' })}`;
  el.replaceChildren(h('div', { class: 'g-wrap td-rep' },
    gHead('تقاريري', h('span', { class: 'td-range', text: range }), () => GS.onBack()),
    h('div', { class: 'seg seg-2 td-seg' }, ...[['week', 'الأسبوع'], ['month', 'الشهر']].map(([k, l]) => h('label', {}, h('input', { type: 'radio', name: 'tdrep', checked: R.period === k, onchange: () => { TODAY.rep = k; paintReports(); } }), h('span', { text: l })))),
    h('section', { class: 'td-hero' },
      h('div', {}, h('small', { text: wk ? 'أسبوعك' : 'شهرك' }), h('b', { class: 'num', text: `${R.rate}%` }),
        h('small', { text: `إنجاز المهام${R.donePrev || R.done ? ` · ${diff === 0 ? `نفس ${wk ? 'الأسبوع' : 'الشهر'} اللي قبله` : `${diff > 0 ? 'أفضل' : 'أقل'} من ${wk ? 'الأسبوع' : 'الشهر'} اللي قبله بـ ${tdCount(Math.abs(diff))}`}` : ''}` })),
      h('span', { class: 'td-trophy', text: R.rate >= 70 ? '🏆' : R.rate >= 40 ? '💪' : '🌱' })),
    h('div', { class: 'td-tiles' },
      ...[[R.done, 'مهمة منجزة'], secOff('finance') ? null : [TODAY.money ? money(R.spend, { bare: true, show: true }) : '••••', 'مصروف'], secOff('sites') ? null : [R.visits, 'زيارة موقع'], secOff('games') ? null : [R.pts, 'نقطة'], [R.streak, 'أيام متتالية 🔥']].filter(Boolean).slice(0, 4).map(([v, l]) => h('div', {}, h('b', { class: 'num', text: typeof v === 'number' ? UI.n(v) : v }), h('small', { text: l })))),
    h('section', { class: 'td-card' }, h('div', { class: 'td-ct' }, h('b', { text: wk ? 'المهام المنجزة يومياً' : 'المهام المنجزة أسبوعياً' })),
      h('div', { class: 'td-chart', role: 'img', 'aria-label': bars.map((b) => `${b[0]}: ${b[1]}`).join('، ') },
        ...bars.map(([l, n, now]) => h('div', { class: 'td-col', title: `${l}: ${n}` }, h('small', { class: 'num', text: n ? UI.n(n) : '' }), h('i', { class: now ? 'now' : '', style: { height: Math.max(n ? 4 : 2, Math.round((n / maxB) * 84)) + 'px' } }), h('em', { text: l }))))),
    secOff('finance') ? null : h('section', { class: 'td-card' },
      h('div', { class: 'td-ct' }, h('b', { text: 'وين راحت فلوسك' }), h('button', { type: 'button', class: 'link-btn', onclick: () => { TODAY.money = !TODAY.money; paintReports(); } }, TODAY.money ? '🙈 إخفاء المبالغ' : '👁 إظهار المبالغ')),
      R.byCat.length ? h('div', { class: 'td-hbars' }, ...R.byCat.map((c) => h('div', { class: 'td-hb' }, h('span', { text: c.name }), h('i', {}, h('b', { style: { width: Math.round((c.v / maxC) * 100) + '%' } })), h('em', { class: 'num', text: TODAY.money ? money(c.v, { bare: true, show: true }) : '•••' }))))
        : h('p', { class: 'td-empty', text: 'ما فيه مصاريف في هالفترة.' })),
    R.topSites.length && !secOff('sites') ? h('section', { class: 'td-card' }, h('div', { class: 'td-ct' }, h('b', { text: 'أكثر مواقعك زيارة' })),
      ...R.topSites.map((s, i) => h('div', { class: 'td-site' }, h('span', { class: 'num', text: UI.n(i + 1) }), h('b', { text: s.name }), h('em', { class: 'num', text: `${UI.n(s.visits || 0)} زيارة` })))) : null,
    tdFeat('share') ? h('button', { type: 'button', class: 'btn btn-block td-share', onclick: () => shareReport(R) }, '📤 شارك تقريرك كصورة') : null));
  UI.digitize(el);
}

/* صورة المشاركة (١٠٨٠×١٣٥٠) — المبالغ مخفية إلا لو أظهرتها */
async function shareReport(R) {
  try { await Promise.all(['700 64px NobleUI', '400 30px NobleUI', '600 30px "Plex Latin"'].map((f) => document.fonts.load(f))); } catch { /* لا شيء */ }
  const W = 1080, H = 1350, cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  const c = cv.getContext('2d');
  c.fillStyle = '#070c22'; c.fillRect(0, 0, W, H);
  const glow = (x, y, r, col) => { const g = c.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, col); g.addColorStop(1, 'rgba(0,0,0,0)'); c.fillStyle = g; c.fillRect(0, 0, W, H); };
  glow(W, 0, 900, 'rgba(46,91,255,.55)'); glow(0, H, 800, 'rgba(200,80,156,.4)');
  c.direction = 'rtl'; c.textAlign = 'right';
  const font = (w, s) => `${w} ${s}px NobleUI, "Plex Latin", sans-serif`;
  c.fillStyle = '#AEB8DA'; c.font = font(400, 34); c.fillText(R.period === 'week' ? 'تقريري الأسبوعي' : 'تقريري الشهري', W - 80, 130);
  c.fillStyle = '#F3F6FF'; c.font = font(700, 86);
  c.fillText(R.rate >= 70 ? 'أسبوع منتج 🔥' : R.rate >= 40 ? 'ماشي صح 💪' : 'بداية حلوة 🌱', W - 80, 250);
  c.font = font(700, 120); c.fillText(`${R.rate}٪ إنجاز`, W - 80, 400);
  const box = (x, y, val, lbl) => {
    c.fillStyle = 'rgba(255,255,255,.07)'; c.beginPath(); c.roundRect(x, y, 440, 230, 36); c.fill();
    c.fillStyle = '#F3F6FF'; c.font = font(700, 80); c.fillText(String(val), x + 400, y + 120);
    c.fillStyle = '#AEB8DA'; c.font = font(400, 34); c.fillText(lbl, x + 400, y + 185);
  };
  box(560, 500, UI.n(R.done), 'مهمة منجزة'); box(80, 500, UI.n(R.streak), 'أيام متتالية 🔥');
  // الصندوقين تحت: من الأقسام الظاهرة بس
  const extra = [secOff('games') ? null : [UI.n(R.pts), 'نقطة ألعاب'], secOff('finance') ? null : (TODAY.money ? [money(R.spend, { bare: true, show: true }), 'مصروف'] : null), secOff('sites') ? null : [UI.n(R.visits), 'زيارة موقع'], [`${R.rate}%`, 'نسبة الإنجاز']].filter(Boolean);
  if (extra[0]) box(560, 770, extra[0][0], extra[0][1]); if (extra[1]) box(80, 770, extra[1][0], extra[1][1]);
  c.fillStyle = '#AEB8DA'; c.font = font(400, 32); c.fillText(Content.get('authTagline') || 'رفيقك اليومي', W - 80, H - 110);
  const grad = c.createLinearGradient(80, 0, 420, 0); ['#FFB43D', '#F0922F', '#C8509C', '#8B45F0'].forEach((col, i) => grad.addColorStop(i / 3, col));
  c.fillStyle = grad; c.textAlign = 'left'; c.direction = 'ltr'; c.font = '700 54px "Plex Latin", sans-serif';
  c.letterSpacing = '14px'; c.fillText(Brand?.name?.() || 'NOBLE', 80, H - 105);
  const url = cv.toDataURL('image/png');
  const name = `noble-report-${tdKey()}.png`;
  try {
    if (Platform.isNative) {
      const res = await Platform.plugin('Filesystem').writeFile({ path: name, data: url.split(',')[1], directory: 'CACHE' });
      await Platform.plugin('Share').share({ title: 'تقريري', url: res.uri, dialogTitle: 'شارك تقريرك' });
    } else {
      const blob = await (await fetch(url)).blob();
      const file = new File([blob], name, { type: 'image/png' });
      if (navigator.canShare?.({ files: [file] })) await navigator.share({ files: [file], title: 'تقريري' });
      else { const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove(); toast('حُفظت الصورة ✓', { type: 'success' }); }
    }
    Sync?.event?.('report_share', { period: R.period });
  } catch { /* أُلغيت */ }
}
