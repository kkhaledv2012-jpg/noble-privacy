/* NOBLE — لوحة التحكم ← النشاط ← «🔥 الأنشط» (1.15)
 * يرتّب المستخدمين حسب نشاطهم (آخر ٧ أيام، السلسلة، آخر ظهور) — المرشحين يصيرون عملاء،
 * وترسل لهم عرض: نافذة داخل التطبيق + كود خصم خاص فيهم يتطبّق بضغطة.
 */
'use strict';
const HOT = { sel: new Set(), loaded: false, subs: null, only: 'free' };
function hotScore(u) {
  const st = A.ustats?.[u.id] || {};
  const g = st.stats?.games || {};
  const ev = Number(st.events_7d) || 0, streak = Number(g.streak) || 0;
  const last = st.last_sync ? new Date(st.last_sync).getTime() : (u.last_seen_at ? new Date(u.last_seen_at).getTime() : 0);
  const days = last ? (Date.now() - last) / 864e5 : 99;
  const recent = days < 1 ? 15 : days < 3 ? 8 : days < 7 ? 3 : 0;
  return { score: Math.round(ev + streak * 3 + recent + Math.min(20, (Number(g.points) || 0) / 50)), ev, streak, days };
}
async function renderHot() {
  const box = $('#act-hot');
  if (!box || !can('users.view')) { if (box) box.hidden = true; return; }
  box.hidden = false;
  if (!HOT.loaded) {
    HOT.loaded = true;
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ حساب الأنشط…' }));
    try { if (!A.users?.length && typeof loadUsers === 'function') await loadUsers(); } catch { /* لا شيء */ }
    try { if (!Object.keys(A.ustats || {}).length && typeof loadUserStats === 'function') await loadUserStats(); } catch { /* لا شيء */ }
    try { if (can('billing.manage')) HOT.subs = await Cloud.admin.subscribers(); } catch { HOT.subs = null; }
  }
  const now = Date.now();
  const paying = new Set((HOT.subs || []).filter((e) => !e.revoked && (!e.until || new Date(e.until).getTime() > now)).map((e) => e.user_id));
  const rows = (A.users || []).filter((u) => u.id !== A.me?.id && u.status !== 'suspended')
    .map((u) => ({ u, ...hotScore(u), pro: paying.has(u.id) }))
    .filter((r) => r.score > 0 && (HOT.only === 'all' || !r.pro))
    .sort((a, b) => b.score - a.score).slice(0, 30);
  const tier = (s) => (s >= 40 ? ['🔥🔥🔥', 'نار'] : s >= 20 ? ['🔥🔥', 'نشيط جداً'] : ['🔥', 'نشيط']);
  const toggle = (id, on) => { if (on) HOT.sel.add(id); else HOT.sel.delete(id); paintBar(); };
  const bar = h('div', { class: 'hot-bar' });
  const paintBar = () => bar.replaceChildren(
    h('span', { text: HOT.sel.size ? `اخترت ${UI.n(HOT.sel.size)}` : 'اختر المستخدمين اللي تبي ترسل لهم عرض' }),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { rows.slice(0, 10).forEach((r) => HOT.sel.add(r.u.id)); renderHot(); } }, 'أنشط ١٠'),
    h('button', { type: 'button', class: 'btn sm btn-primary', disabled: !HOT.sel.size, onclick: () => hotOffer([...HOT.sel].map((id) => A.users.find((u) => u.id === id)).filter(Boolean)) }, '🎁 أرسل عرض'));
  paintBar();
  box.replaceChildren(
    h('div', { class: 'set-row hot-h' }, h('h3', { class: 'set-title', text: '🔥 الأنشط — عملاء محتملين' }),
      h('nav', { class: 'chips' }, ...[['free', 'غير المشتركين'], ['all', 'الكل']].map(([k, l]) => h('button', { type: 'button', class: `chip${HOT.only === k ? ' on' : ''}`, onclick: () => { HOT.only = k; renderHot(); } }, l)))),
    h('p', { class: 'hint', text: 'الترتيب حسب: نشاطه آخر ٧ أيام + أيامه المتواصلة + آخر ظهور. الأنشط غالباً يستاهل عرض يخليه عميل.' }),
    rows.length ? h('div', { class: 'hot-list' }, ...rows.map((r, i) => {
      const cb = h('input', { type: 'checkbox', checked: HOT.sel.has(r.u.id) });
      cb.addEventListener('change', () => toggle(r.u.id, cb.checked));
      const [fire, lbl] = tier(r.score);
      return h('label', { class: `hot-row${HOT.sel.has(r.u.id) ? ' on' : ''}` }, cb,
        h('span', { class: 'hot-n num', text: UI.n(i + 1) }),
        h('span', { class: 'hot-c' }, h('b', { text: nameOf(r.u) }, r.pro ? h('em', { class: 'hot-pro', text: '★ مشترك' }) : null),
          h('small', { text: `${UI.n(r.ev)} نشاط بالأسبوع · ${UI.n(r.streak)} يوم متواصل · ${r.days < 1 ? 'نشط اليوم' : r.days < 99 ? `آخر ظهور قبل ${UI.n(Math.round(r.days))} يوم` : '—'}` })),
        h('span', { class: 'hot-s', title: lbl }, h('b', { text: fire }), h('small', { class: 'num', text: UI.n(r.score) })));
    })) : h('p', { class: 'hint', text: 'ما فيه بيانات نشاط كافية للحين — تتجمع مع استخدام التطبيق.' }),
    rows.length ? bar : null);
  UI.digitize(box);
}
/* إرسال العرض: كود خصم خاص + رسالة داخل التطبيق لكل واحد باسمه */
function hotOffer(users) {
  const o = { pct: 20, days: 7, title: 'عرض خاص لك يا {الاسم} 🎁', body: 'شكراً إنك من أنشط مستخدمي NOBLE 🤍 جهزنا لك خصم {الخصم}٪ على الاشتراك — صالح {المدة} أيام بس.', code: 'VIP' + Math.random().toString(36).slice(2, 6).toUpperCase() };
  const box = h('div', { class: 'hot-of' });
  const paint = () => {
    const ti = h('input', { class: 'input', value: o.title, maxlength: 80 }); ti.addEventListener('input', () => { o.title = ti.value; pv(); });
    const bd = h('textarea', { class: 'input textarea', rows: 3, maxlength: 400 }); bd.value = o.body; bd.addEventListener('input', () => { o.body = bd.value; pv(); });
    const cd = h('input', { class: 'input ltr', value: o.code, maxlength: 20 }); cd.addEventListener('input', () => { o.code = cd.value.toUpperCase().replace(/[^A-Z0-9_-]/g, ''); pv(); });
    const prevBox = h('div', { class: 'hot-pv' });
    const fill = (t, u) => String(t).replace(/\{الاسم\}/g, (nameOf(u) || '').split(' ')[0]).replace(/\{الخصم\}/g, UI.n(o.pct)).replace(/\{المدة\}/g, UI.n(o.days));
    function pv() { prevBox.replaceChildren(h('small', { text: 'معاينة' }), h('b', { text: fill(o.title, users[0]) }), h('p', { text: fill(o.body, users[0]) }), h('span', { class: 'mk-renew-code', text: '🎁 ' + o.code }), h('span', { class: 'btn sm btn-primary', text: 'استخدم العرض 🎁' })); }
    box.replaceChildren(
      h('p', { class: 'hint', text: `لـ ${UI.n(users.length)} مستخدم: ${users.slice(0, 4).map(nameOf).join('، ')}${users.length > 4 ? '…' : ''}` }),
      h('div', { class: 'field' }, h('span', { text: 'الخصم' }), mkSeg([['10', '١٠٪'], ['20', '٢٠٪'], ['30', '٣٠٪'], ['50', '٥٠٪'], ['100', 'مجاني ١٠٠٪']], String(o.pct), (v) => { o.pct = Number(v); pv(); })),
      h('div', { class: 'field' }, h('span', { text: 'صالح لمدة' }), mkSeg([['3', '٣ أيام'], ['7', 'أسبوع'], ['14', 'أسبوعين']], String(o.days), (v) => { o.days = Number(v); pv(); })),
      h('div', { class: 'field' }, h('span', { text: 'العنوان' }), ti),
      h('div', { class: 'field' }, h('span', { text: 'الرسالة' }), bd, h('small', { class: 'hint', text: 'متغيرات: {الاسم} {الخصم} {المدة}' })),
      h('div', { class: 'field' }, h('span', { text: 'كود الخصم (خاص فيهم — عدد استخداماته بعدد المختارين)' }), cd),
      prevBox);
    pv();
    UI.digitize(box);
  };
  paint();
  mkSheet('🎁 عرض للأنشط', [box], [h('button', { type: 'button', class: 'btn btn-primary', onclick: async (e) => {
    if (!o.code || o.code.length < 4) return toast('اكتب كود من ٤ حروف على الأقل');
    const b = e.currentTarget; b.disabled = true;
    try {
      const until = new Date(Date.now() + o.days * 864e5).toISOString();
      await Cloud.admin.setDiscount({ code: o.code, pct: o.pct, max: users.length, until, active: true });
      let n = 0;
      for (const u of users) {
        const fill = (t) => String(t).replace(/\{الاسم\}/g, (nameOf(u) || '').split(' ')[0]).replace(/\{الخصم\}/g, UI.n(o.pct)).replace(/\{المدة\}/g, UI.n(o.days));
        try { await Cloud.admin.sendMessage(u.id, fill(o.title), `${fill(o.body)}\n\nكودك: ${o.code}`, `noble:offer?code=${o.code}`, 'استخدم العرض 🎁', { icon: '🎁', theme: 'gold' }); n++; b.textContent = `جارٍ الإرسال… ${UI.n(n)}/${UI.n(users.length)}`; } catch { /* نكمل */ }
      }
      closeSheet($('#mk-sheet'));
      toast(`وصل العرض لـ ${UI.n(n)} مستخدم 🎁 — الكود ${o.code} صالح ${UI.n(o.days)} أيام`, { type: 'success', duration: 6000 });
      HOT.sel.clear(); renderHot();
    } catch (er) { toast(Cloud.msg(er), { type: 'error' }); b.disabled = false; }
  } }, 'أرسل العرض')]);
}
