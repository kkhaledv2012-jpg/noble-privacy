/* NOBLE — لوحة «⚡ NOBLE عاجل» (1.18) — يظهر للمستخدم داخل قسم الأخبار بأيقونة فوق
 * أعداد ملخص الذكاء الاصطناعي (يومي · أسبوعي · شهري — تختار الدورية حسب كمية الأخبار): Gemini يجهّز المسودة من المصادر (رسمية · ثانوية · يوتيوب)، وأنت تراجع،
 * ترفع مقطع المصدر لكل خبر، تختار شكل الغلاف والألوان والمقاس، تسحب شعارك وشريط توقيعك، تصدّر فيديو/صور، وتنشر.
 * النشر: يظهر في قسم «⚡ NOBLE عاجل» بالتطبيق، وينزل منشور في «اكتشف» تلقائياً، ويتثبّت كمهم بالمدة اللي تختارها.
 */
'use strict';
const AIA = { list: null, kit: null, cfg: {}, hasKey: false, cron: null, ed: null, raf: 0 };
const AIA_DEF = { period: 'weekly', min: 3, titles: {}, kickers: {}, look: { style: 'aura', theme: 'noble' }, dow: 4, dom: 1, hour: 18 };
/* الدوريات: أيام البحث وعدد الأخبار الافتراضي والعناوين */
const AIA_PER = {
  daily: { ic: '☀️', name: 'يومي', days: 1, count: 4, title: 'ملخص اليوم في الذكاء الاصطناعي', kicker: 'ملخص اليوم', gen: 'جهّز عدد اليوم', auto: 'كل يوم' },
  weekly: { ic: '📰', name: 'أسبوعي', days: 7, count: 6, title: 'ملخص أسبوع الذكاء الاصطناعي', kicker: 'ملخص الأسبوع', gen: 'جهّز عدد الأسبوع', auto: 'كل أسبوع' },
  monthly: { ic: '🗓️', name: 'شهري', days: 31, count: 8, title: 'ملخص شهر الذكاء الاصطناعي', kicker: 'ملخص الشهر', gen: 'جهّز عدد الشهر', auto: 'كل شهر' },
};
const aiaPer = () => AIA_PER[AIA.cfg.period] || AIA_PER.weekly;
const aiaKindTxt = (k, n) => k === 'urgent' ? '⚡ عاجل' : k === 'weekly' ? `📰 الأسبوع ${aiaN(n)}` : `${AIA_PER[k]?.ic || '📰'} ${AIA_PER[k]?.name || ''}`;
const aiaNum = (k, d = new Date()) => k === 'daily' ? d.getDate() : k === 'monthly' ? d.getMonth() + 1 : aiaWeek(d);
const aiaTitleOf = (k) => (AIA.cfg.titles || {})[k] || AIA_PER[k]?.title || AIA_PER.weekly.title;
const aiaKickerOf = (k) => k === 'urgent' ? '⚡ عاجل' : (AIA.cfg.kickers || {})[k] || AIA_PER[k]?.kicker || AIA_PER.weekly.kicker;
const AIA_TIER = { official: '✅ رسمي', secondary: '🗞️ ثانوي', video: '🎬 يوتيوب' };
const aiaN = (x) => UI.n(x);
const aiaWeek = (d = new Date()) => { const t = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day); const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return Math.ceil(((t - y0) / 864e5 + 1) / 7); };
const aiaDate = (d = new Date(), k = '') => new Intl.DateTimeFormat('ar-SA-u-ca-gregory', k === 'monthly' ? { month: 'long', year: 'numeric' } : { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
const aiaSizeH = (k) => AISlides.SIZES[k]?.[0] || 1350;

async function openAiNewsAdmin(force) {
  const box = $('#a-ainews');
  if (!box) return;
  if (AIA.ed && !force) return aiaEditor();
  box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  try {
    const r = await Cloud.admin.aiList();
    AIA.list = r.items || []; AIA.kit = AISlides.kitOf(r.kit); AIA.cfg = { ...AIA_DEF, ...(r.ai || {}) };
    if (!AIA_PER[AIA.cfg.period]) AIA.cfg.period = 'weekly'; AIA.hasKey = !!r.has_key; AIA.cron = r.cron;
  } catch (e) {
    const msg = Cloud.msg(e);
    box.replaceChildren(h('p', { class: 'note-box', text: /function|schema/i.test(msg) ? 'شغّل ملف supabase/update-1.18.sql (أو update-all.sql كامل) في Supabase ← SQL Editor أولاً.' : 'تعذّر التحميل: ' + msg }));
    return;
  }
  await AISlides.fonts();
  aiaDraftPaint();
  // 1.21.26: جاي من إشعار — افتح المسودة نفسها، أو فلتر المسودات
  const want = AIA.want; AIA.want = null;
  if (typeof want === 'number') { const it = AIA.list.find((x) => x.id === want); if (it) return aiaOpen(it); }
  if (want) AIA.filter = 'draft';
  aiaHome();
}
/* 1.21.26 — 📝 المسودات اللي تنتظرك: شارة على تبويب «عاجل» + شريط فوق الأعداد */
const aiaWaiting = () => (AIA.list || []).filter((x) => x.status !== 'published');
async function aiaDraftCount() {
  if (typeof can === 'function' && !can('news.manage')) return;
  if (!AIA.list) { try { AIA.list = (await Cloud.admin.aiList()).items || []; } catch { return; } }
  aiaDraftPaint();
}
function aiaDraftPaint() {
  if (typeof A === 'undefined') return;
  A.aiDrafts = aiaWaiting().length;
  const b = document.querySelector('#a-tabs [data-tab="ainews"]');
  if (b) { b.querySelector('.aia-dbadge')?.remove(); if (A.aiDrafts > 0) b.append(h('em', { class: 'supa-badge num aia-dbadge', title: 'مسودات تنتظر مراجعتك', text: '📝' + UI.n(A.aiDrafts) })); }
}

/* ---------- القائمة ---------- */
function aiaHome() {
  cancelAnimationFrame(AIA.raf); AIA.ed = null; AISlides.sync(null, [], false);
  const mini = document.getElementById('aia-mini'); if (mini) { mini.hidden = true; mini._io?.disconnect(); mini._cv = null; }
  const box = $('#a-ainews');
  const card = (it) => {
    const cv = h('canvas', { width: 216, height: 270, class: 'aia-th' });
    requestAnimationFrame(() => AISlides.draw(cv.getContext('2d'), it, 0, 3, { kit: AIA.kit }));
    const pin = it.pinned_until && new Date(it.pinned_until) > new Date();
    return h('button', { type: 'button', class: 'aia-card', onclick: () => aiaOpen(it) }, cv,
      h('div', { class: 'aia-cb' },
        h('div', { class: 'aia-tags' }, h('span', { class: `aia-st ${it.status}${it.status !== 'published' && it.publish_at ? ' sched' : ''}`, text: it.status === 'published' ? '● منشور' : it.publish_at ? '⏰ ' + aiaWhen(it.publish_at) : '○ مسودة' }),
          h('span', { text: aiaKindTxt(it.kind, it.week) }), pin ? h('span', { text: '📌 مثبّت' }) : null, it.ai ? h('span', { text: '🤖' }) : null),
        h('b', { text: it.title || 'بدون عنوان' }),
        h('small', { text: `${aiaN((it.slides || []).length)} أخبار · ${(it.slides || []).filter((s) => s.media?.kind === 'video').length ? aiaN((it.slides || []).filter((s) => s.media?.kind === 'video').length) + ' فيديو · ' : ''}${it.status === 'published' ? aiaN(it.views || 0) + ' مشاهدة · ' : ''}${UI.relTime(new Date(it.updated_at || it.created_at).getTime())}` })));
  };
  // 1.21.9: ترتيب جديد — رأس مختصر (العنوان + الحالة + 🪪 ⚙️)، بطاقة «جهّز عدد» فيها الدورية والزر، واختصارين، وفلتر للأعداد
  const P0 = aiaPer(), days = Number(AIA.cfg.days) || P0.days, cnt = Number(AIA.cfg.count) || P0.count;
  const F = AIA.filter || 'all', pubN = AIA.list.filter((x) => x.status === 'published').length;
  const shown = AIA.list.filter((x) => F === 'all' || (F === 'pub' ? x.status === 'published' : x.status !== 'published'));
  const pill = (t, cls = '') => h('span', { class: `aia-pill ${cls}`, text: t });
  box.replaceChildren(...[
    h('section', { class: 'aia-top' },
      h('div', { class: 'aia-top-t' }, h('h2', { text: '⚡ NOBLE عاجل' })),
      h('div', { class: 'aia-top-a' },
        h('button', { type: 'button', class: 'aia-ib', title: 'هويتي: الشعار والتوقيع والألوان', onclick: () => aiaOpen(null, 'kit') }, h('span', { text: '🪪' }), h('small', { text: 'هويتي' })),
        h('button', { type: 'button', class: 'aia-ib', title: 'إعدادات عاجل', onclick: aiaSettings }, h('span', { text: '⚙️' }), h('small', { text: 'الإعدادات' })))),
    h('div', { class: 'aia-pills' }, pill(AIA.hasKey ? '✓ Gemini جاهز' : '✕ بدون مفتاح Gemini', AIA.hasKey ? 'ok' : 'bad'),
      pill(AIA.cron ? `🕒 تلقائي · ${P0.auto}` : '🕒 التلقائي مقفول', AIA.cron ? 'ok' : ''), pill(`${aiaN(AIA.list.length)} عدد · ${aiaN(pubN)} منشور`)),
    h('section', { class: 'aia-make' },
      h('div', { class: 'aia-make-h' }, h('b', { text: '🤖 جهّز عدد جديد' }), h('small', { text: 'Gemini يجهّز المسودة من المصادر، وأنت تراجع وتنشر' })),
      h('div', { class: 'aia-seg' }, ...Object.entries(AIA_PER).map(([k, v]) => h('button', { type: 'button', class: AIA.cfg.period === k ? 'on' : '', onclick: () => aiaSetPeriod(k) }, h('span', { text: v.ic }), h('b', { text: v.name })))),
      h('button', { type: 'button', class: 'btn btn-primary aia-go', disabled: !AIA.hasKey, onclick: (e) => aiaGenerate(e.currentTarget, { period: AIA.cfg.period }) }, '🤖 ' + P0.gen),
      h('p', { class: 'aia-make-n', text: `يدوّر في أخبار آخر ${aiaN(days)} ${days === 1 ? 'يوم' : 'أيام'} ويختار ${aiaN(cnt)} أخبار · لو لقى أقل من ${aiaN(AIA.cfg.min || 3)} ما يجهّز` }),
      AIA.hasKey ? null : h('p', { class: 'note-box', text: 'أضف مفتاح Gemini من الأخبار ← الإعدادات عشان يجهّز تلقائياً. تقدر تسوي عدد فاضي وتعبيه بنفسك.' })),
    h('div', { class: 'aia-quick' },
      h('button', { type: 'button', class: 'aia-q', disabled: !AIA.hasKey, onclick: aiaUrgentPick }, h('span', { text: '⚡' }), h('b', { text: 'عاجل من خبر' }), h('small', { text: 'خبر واحد مهم بسلايدات' })),
      h('button', { type: 'button', class: 'aia-q', onclick: aiaBlank }, h('span', { text: '＋' }), h('b', { text: 'عدد فاضي' }), h('small', { text: 'تعبيه بنفسك' }))),
    h('details', { class: 'aia-how' }, h('summary', { text: 'ℹ️ من وين يجيب الأخبار؟' }),
      h('p', { class: 'hint', text: 'من الأخبار ← المصادر: ✅ الرسمية تنفضّل، 🗞️ الثانوية للسياق، و🎬 قنوات يوتيوب تقترح لك مقطع العرض الرسمي لكل خبر.' })),
    (() => { // 1.21.26: 📝 شريط «تنتظر مراجعتك»
      const w = aiaWaiting(); if (!w.length) return null;
      const next = w.filter((x) => x.publish_at).sort((a, b) => new Date(a.publish_at) - new Date(b.publish_at))[0];
      return h('button', { type: 'button', class: 'aia-wait', onclick: () => (w.length === 1 ? aiaOpen(w[0]) : (AIA.filter = 'draft', aiaHome())) },
        h('span', { class: 'aia-wait-ic', text: '📝' }),
        h('div', {}, h('b', { text: w.length === 1 ? 'عندك مسودة تنتظر مراجعتك' : `عندك ${aiaN(w.length)} مسودات تنتظر مراجعتك` }),
          h('small', { text: next ? `⏰ «${next.title || 'عدد'}» ينشر ${aiaWhen(next.publish_at)} — شيّك عليه قبلها` : 'ما تنتشر إلا بيدك — راجعها وانشرها أو جدولها' })),
        h('span', { class: 'aia-wait-go', text: 'راجع ←' }));
    })(),
    AIA.list.length ? h('div', { class: 'aia-lh' }, h('b', { text: 'الأعداد' }),
      h('div', { class: 'aia-f' }, ...[['all', `الكل ${aiaN(AIA.list.length)}`], ['pub', `منشور ${aiaN(pubN)}`], ['draft', `مسودة ${aiaN(AIA.list.length - pubN)}`]].map(([k, l]) =>
        h('button', { type: 'button', class: F === k ? 'on' : '', onclick: () => { AIA.filter = k; aiaHome(); } }, l)))) : null,
    AIA.list.length ? (shown.length ? h('div', { class: 'aia-grid' }, ...shown.map(card)) : h('div', { class: 'empty' }, h('small', { text: 'ما فيه أعداد بهذا الفلتر' })))
      : h('div', { class: 'empty' }, h('b', { text: 'ما فيه أعداد للحين' }), h('small', { text: `اضغط «🤖 ${P0.gen}» أو «＋ عدد فاضي».` }))].filter(Boolean));
  UI.digitize(box);
  aiaDraftPaint();
}
async function aiaGenerate(btn, extra = {}) {
  const old = btn?.textContent; if (btn) { btn.disabled = true; btn.textContent = '⏳ Gemini يجهّز…'; }
  try {
    const r = await Cloud.admin.newsRun('ai_issue', extra);
    if (r?.error) throw new Error(r.error);
    toast(`جاهز ✓ ${aiaN(r.slides)} أخبار من ${aiaN(r.from)}${r.videos ? ` · ${aiaN(r.videos)} مقطع رسمي مقترح` : ''}`, { type: 'success' });
    const lst = await Cloud.admin.aiList(); AIA.list = lst.items || [];
    const it = AIA.list.find((x) => x.id === r.id); if (it) return aiaOpen(it);
    aiaHome();
  } catch (e) { toast(Cloud.msg(e), { type: 'error', duration: 9000 }); }
  if (btn) { btn.disabled = false; btn.textContent = old; }
}
async function aiaUrgentPick() {
  let rows = [];
  try { rows = [...await Cloud.admin.newsList('published', 80), ...await Cloud.admin.newsList('draft', 80)].filter((x) => x.cat === 'ai'); } catch (e) { return toast(Cloud.msg(e), { type: 'error' }); }
  rows.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  const sel = new Set();
  const list = h('div', { class: 'aia-pick' }, ...(rows.length ? rows.slice(0, 40).map((x) => {
    const c = h('input', { type: 'checkbox' });
    c.addEventListener('change', () => { if (c.checked) { if (sel.size >= 3) { c.checked = false; return toast('أقصى ٣ أخبار للعاجل'); } sel.add(x.id); } else sel.delete(x.id); });
    return h('label', { class: 'aia-pr' }, c, h('div', {}, h('b', { text: x.title || x.src_title }), h('small', { text: `${AIA_TIER[x.tier] || ''} ${x.src_name} · ${UI.relTime(new Date(x.created_at).getTime())}` })));
  }) : [h('p', { class: 'hint', text: 'ما فيه أخبار ذكاء اصطناعي — اسحب الأخبار أول من قسم الأخبار.' })]));
  mkSheet('⚡ عاجل من خبر', [h('p', { class: 'hint', text: 'اختر خبر إلى ٣ — Gemini يكتب سلايد لكل خبر بنفس الأسلوب.' }), list],
    [h('button', { type: 'button', class: 'btn btn-primary', onclick: (e) => { if (!sel.size) return toast('اختر خبر واحد على الأقل'); closeSheet($('#mk-sheet')); aiaGenerate(e.currentTarget, { kind: 'urgent', ids: [...sel] }); } }, 'جهّز العاجل')]);
}
/* تغيير الدورية من الصفحة مباشرة (وإعادة جدولة التجهيز التلقائي لو شغّال) */
async function aiaSetPeriod(k) {
  const c = { ...AIA.cfg, period: k }; delete c.days; delete c.count; // الأيام والعدد يرجعون لافتراضي الدورية
  try {
    await Cloud.admin.aiConfigSet(c); AIA.cfg = c;
    if (AIA.cron) await Cloud.admin.aiSchedule(k, c.dow, c.dom, (c.hour + 21) % 24, true).catch((e) => toast(Cloud.msg(e), { type: 'error' }));
    toast(`الدورية: ${AIA_PER[k].name} ✓`, { type: 'success' }); aiaHome();
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
async function aiaBlank() {
  const k = AIA.cfg.period || 'weekly';
  const issue = { kind: k, week: aiaNum(k), title: aiaTitleOf(k), kicker: aiaKickerOf(k), date_label: aiaDate(new Date(), k), look: { ...AIA_DEF.look, ...(AIA.cfg.look || {}) },
    slides: [{ company: 'اسم الشركة', initial: 'AI', head: 'عنوان الخبر', body: 'اكتب ملخص الخبر هنا في ٢٥–٤٠ كلمة.', source: '', url: '', tier: '', media: null, trim: [0, 0], rights: false }] };
  try { issue.id = await Cloud.admin.aiSave(issue); issue.status = 'draft'; AIA.list.unshift(issue); aiaOpen(issue); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
function aiaSettings() {
  const c = { ...AIA_DEF, ...AIA.cfg, look: { ...AIA_DEF.look, ...(AIA.cfg.look || {}) }, titles: { ...(AIA.cfg.titles || {}) }, kickers: { ...(AIA.cfg.kickers || {}) } };
  const body = h('div', { class: 'aia-set' });
  const sel = (label, opts, val, set) => { const el = h('select', { class: 'input select' }, ...opts.map(([v, l]) => h('option', { value: v, text: l, selected: String(v) === String(val) }))); el.addEventListener('change', () => set(el.value)); return h('label', { class: 'field' }, h('span', { text: label }), el); };
  const auto = h('input', { type: 'checkbox', checked: !!AIA.cron });
  const days = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت'];
  const paint = () => {
    const P = AIA_PER[c.period] || AIA_PER.weekly;
    const num = (label, key, min, max, def) => { const i = h('input', { class: 'input num ltr', type: 'number', min, max, placeholder: String(def), value: c[key] ?? '' }); i.addEventListener('input', () => { if (i.value === '') delete c[key]; else c[key] = Math.max(min, Math.min(max, Number(i.value) || min)); }); return h('label', { class: 'field' }, h('span', { text: label }), i); };
    const txt = (label, obj, key, def) => { const i = h('input', { class: 'input', placeholder: def, value: obj[key] || '' }); i.addEventListener('input', () => { if (i.value.trim()) obj[key] = i.value.trim(); else delete obj[key]; }); return h('label', { class: 'field' }, h('span', { text: label }), i); };
    body.replaceChildren(
      h('div', { class: 'field' }, h('span', { text: 'الدورية — حسب كمية أخبار الذكاء الاصطناعي اللي تنسحب' }),
        h('div', { class: 'chips' }, ...Object.entries(AIA_PER).map(([k, v]) => h('button', { type: 'button', class: `chip${c.period === k ? ' on' : ''}`, onclick: () => { c.period = k; delete c.days; delete c.count; paint(); } }, `${v.ic} ${v.name}`)))),
      h('div', { class: 'two-col' }, num('عدد الأخبار في العدد', 'count', 2, 8, P.count), num('يدوّر في آخر كم يوم', 'days', 1, 45, P.days)),
      num('الحد الأدنى للأخبار المسترجعة', 'min', 1, 10, 3),
      h('small', { class: 'hint', text: 'لو الأخبار المسترجعة في المدة أقل من الحد، ما يجهّز عدد (عشان ما يطلع عدد ضعيف). فاضي = الافتراضي.' }),
      txt(`عنوان العدد (${P.name})`, c.titles, c.period, P.title), txt('الشارة فوق العنوان', c.kickers, c.period, P.kicker),
      h('div', { class: 'two-col' }, sel('شكل الغلاف الافتراضي', AISlides.COVERS.filter((x) => x[0] !== 'custom'), c.look.style, (v) => (c.look.style = v)),
        sel('الألوان الافتراضية', Object.entries(AISlides.THEMES).map(([k, v]) => [k, v.name]), c.look.theme, (v) => (c.look.theme = v))),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: `🕒 جهّز العدد تلقائياً ${P.auto}` }), h('small', { text: 'ينزل لك مسودة جاهزة للمراجعة — ما ينشر بدونك' })), h('span', { class: 'switch' }, auto, h('span', { class: 'track' }))),
      h('div', { class: 'two-col' },
        c.period === 'weekly' ? sel('اليوم', days.map((d, i) => [i, d]), c.dow, (v) => (c.dow = +v)) : c.period === 'monthly' ? sel('يوم الشهر', Array.from({ length: 28 }, (_, i) => [i + 1, String(i + 1)]), c.dom, (v) => (c.dom = +v)) : h('span'),
        sel('الساعة (توقيت السعودية)', Array.from({ length: 24 }, (_, i) => [i, `${i}:00`]), c.hour, (v) => (c.hour = +v))));
  };
  paint();
  // 1.21.26 — 🔔 تنبيهاتي (للمشرف بس): مسودة جاهزة · تذكير لو ما انتشرت · قبل موعد النشر المجدول
  const rm = { on: true, ready: true, late: 60, soon: 15 }, rbox = h('div', { class: 'aia-rm' }, h('p', { class: 'hint', text: 'جارٍ تحميل التنبيهات…' }));
  const rpaint = () => rbox.replaceChildren(
    h('h3', { text: '🔔 تنبيهاتي (توصلك أنت والمشرفين بس)' }),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'شغّل التنبيهات' }), h('small', { text: 'إشعار على جوالك — النشر يبقى بيدك' })), h('span', { class: 'switch' }, (() => { const i = h('input', { type: 'checkbox', checked: rm.on !== false }); i.addEventListener('change', () => { rm.on = i.checked; rpaint(); }); return i; })(), h('span', { class: 'track' }))),
    ...(rm.on !== false ? [
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: '📝 أول ما تجهز المسودة' }), h('small', { text: 'مثلاً الساعة ٨ يجهز عدد اليوم ← يوصلك إشعار يفتحها لك' })), h('span', { class: 'switch' }, (() => { const i = h('input', { type: 'checkbox', checked: rm.ready !== false }); i.addEventListener('change', () => { rm.ready = i.checked; }); return i; })(), h('span', { class: 'track' }))),
      h('div', { class: 'field' }, h('span', { text: '⏰ ذكّرني لو ما نشرتها بعد' }), aiaChips([[0, 'بدون'], [30, '٣٠ د'], [60, 'ساعة'], [120, 'ساعتين'], [180, '٣ ساعات']].map(([v, l]) => [String(v), l]), String(rm.late ?? 60), (k) => { rm.late = +k; })),
      h('div', { class: 'field' }, h('span', { text: '⏰ قبل موعد النشر المجدول بـ' }), aiaChips([[0, 'بدون'], [5, '٥ د'], [10, '١٠ د'], [15, 'ربع ساعة'], [30, 'نص ساعة'], [60, 'ساعة']].map(([v, l]) => [String(v), l]), String(rm.soon ?? 15), (k) => { rm.soon = +k; })),
      h('small', { class: 'hint', text: 'يفحص كل ٥ دقايق. تحتاج تكون مسجّل دخول في التطبيق على جوالك ومسموح له بالإشعارات.' }),
    ] : []));
  Cloud.admin.aiRemind().then((r) => { Object.assign(rm, r?.remind || {}); rpaint(); }).catch((e) => rbox.replaceChildren(h('p', { class: 'note-box', text: /function|schema/i.test(Cloud.msg(e)) ? 'التنبيهات تحتاج تشغيل supabase/update-1.21.26.sql' : Cloud.msg(e) })));
  mkSheet('⚙️ إعدادات NOBLE عاجل', [body, rbox], [h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
    try {
      await Cloud.admin.aiConfigSet(c); AIA.cfg = c;
      if (rbox.querySelector('.switch-row')) await Cloud.admin.aiRemind(rm).catch((e) => toast(Cloud.msg(e), { type: 'error' }));
      const r = await Cloud.admin.aiSchedule(c.period, c.dow, c.dom, (c.hour + 21) % 24, auto.checked).catch((e) => { toast(Cloud.msg(e), { type: 'error' }); return null; });
      if (r) AIA.cron = r === 'on';
      closeSheet($('#mk-sheet')); toast('حُفظ ✓', { type: 'success' }); aiaHome();
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  } }, 'حفظ')]);
}

/* ---------- المحرر ---------- */
function aiaOpen(issue, mode = 'slide') {
  const it = issue ? JSON.parse(JSON.stringify(issue)) : null;
  if (it) { it.look = { style: 'aura', theme: 'noble', ...(it.look || {}) }; it.slides = it.slides || []; }
  AIA.ed = { issue: it, cur: 0, size: it?.look?.size || 'post', t0: performance.now(), playing: true, mode: it ? mode : 'kit', dirty: false, kitDirty: false, drag: null, last: 0 };
  aiaEditor();
}
const aiaDemoIssue = () => ({ kind: AIA.cfg.period || 'weekly', title: aiaTitleOf(AIA.cfg.period), kicker: aiaKickerOf(AIA.cfg.period), week: aiaNum(AIA.cfg.period), date_label: aiaDate(new Date(), AIA.cfg.period), look: { ...AIA_DEF.look, ...(AIA.cfg.look || {}) },
  slides: [{ company: 'اسم الشركة', initial: 'AI', head: 'عنوان الخبر', body: 'معاينة لمكان الشعار وشريط التوقيع على سلايد خبر.', media: null }] });
/* 1.21.9 — معاينة عائمة: لما تنزل تحت للإعدادات، المعاينة تبقى معك في الزاوية (اضغطها ترجع فوق، ✕ تخفيها، ⤢ تكبّرها) */
function aiaMini(cv) {
  let M = document.getElementById('aia-mini');
  if (!M) {
    const mc = h('canvas', { width: 432, height: 540 });
    M = h('div', { id: 'aia-mini', class: 'aia-mini', hidden: true },
      mc, h('div', { class: 'aia-mini-a' },
        h('button', { type: 'button', title: 'كبّر/صغّر', onclick: (e) => { e.stopPropagation(); M.classList.toggle('big'); try { localStorage.setItem('nw:aia-mini-big', M.classList.contains('big') ? '1' : ''); } catch { /* لا شيء */ } } }, '⤢'),
        h('button', { type: 'button', title: 'إخفاء', onclick: (e) => { e.stopPropagation(); M.hidden = true; M.dataset.off = '1'; } }, '✕')));
    M.addEventListener('click', () => M._cv?.scrollIntoView({ behavior: 'smooth', block: 'center' }));
    try { if (localStorage.getItem('nw:aia-mini-big')) M.classList.add('big'); } catch { /* لا شيء */ }
    document.body.append(M);
    const ctx = mc.getContext('2d');
    (function loop() { if (!M.hidden && M._cv?.isConnected) { const c = M._cv; if (mc.height !== Math.round(432 * c.height / c.width)) mc.height = Math.round(432 * c.height / c.width); ctx.drawImage(c, 0, 0, mc.width, mc.height); }
      if (M._cv && !M._cv.isConnected) M.hidden = true; requestAnimationFrame(loop); })();
  }
  M._cv = cv; delete M.dataset.off;
  M._io?.disconnect();
  M._io = new IntersectionObserver(([e]) => { if (M.dataset.off) return; M.hidden = e.isIntersecting || !cv.isConnected; }, { threshold: .15 });
  M._io.observe(cv);
}
function aiaEditor() {
  const E = AIA.ed, box = $('#a-ainews');
  const issue = E.issue || (E.preview ||= aiaDemoIssue());
  const total = AISlides.total(issue, AIA.kit);
  E.cur = Math.min(E.cur, total - 1);
  const cv = h('canvas', { class: 'aia-cv', width: 1080, height: aiaSizeH(E.size) });
  cv.style.aspectRatio = `1080 / ${aiaSizeH(E.size)}`;
  E.cv = cv;
  // سحب الشعار وشريط التوقيع
  const pt = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width * 1080, y: (e.clientY - r.top) / r.height * cv.height }; };
  cv.addEventListener('pointerdown', (e) => { const p = pt(e), key = AISlides.hitLayer(p); if (!key) return; const pos = AISlides.layerPos(AIA.kit, key, cv.height, E.igPrev); E.drag = { key, px: p.x, py: p.y, ox: pos.x, oy: pos.y }; cv.setPointerCapture(e.pointerId); cv.style.cursor = 'grabbing'; });
  cv.addEventListener('pointermove', (e) => { const p = pt(e); if (!E.drag) { cv.style.cursor = AISlides.hitLayer(p) ? 'grab' : ''; return; }
    const pos = AISlides.layerPos(AIA.kit, E.drag.key, cv.height, E.igPrev); pos.x = Math.round(E.drag.ox + p.x - E.drag.px); pos.y = Math.round(E.drag.oy + p.y - E.drag.py);
    if (E.drag.key === 'sig' && Math.abs(pos.x - 540) < 14) pos.x = 540; });
  cv.addEventListener('pointerup', () => { if (E.drag) { E.drag = null; cv.style.cursor = 'grab'; aiaKitDirty(); } });

  const list = h('div', { class: 'aia-list' });
  const paintList = () => {
    list.replaceChildren(...(E.issue ? Array.from({ length: total }, (_, i) => {
      const s = i ? issue.slides[i - 1] : null, isO = i > issue.slides.length; // 🏁 الصفحة الأخيرة
      const th = h('canvas', { width: 88, height: 110, dataset: { i } }), sel = E.mode !== 'kit' && E.cur === i;
      if (isO) return [h('div', { class: `aia-it${sel ? ' on' : ''}`, role: 'button', onclick: () => { E.mode = 'slide'; E.cur = i; E.t0 = performance.now(); aiaEditor(); } }, th,
        h('div', { class: 'aia-tx' }, h('b', { text: '🏁 الصفحة الأخيرة' }), h('small', { text: 'تتعدّل من هويتي' })), aiaBadges(issue, i)), sel ? aiaQuick(issue, i) : null];
      const row = h('div', { class: `aia-it${sel ? ' on' : ''}${s?.opt?.skip ? ' skip' : ''}`, role: 'button', onclick: () => { E.mode = 'slide'; E.cur = i; E.t0 = performance.now(); AISlides.rewind(issue, i); aiaEditor(); } }, th,
        h('div', { class: 'aia-tx' }, h('b', { text: i ? s.company || 'خبر' : '🎬 الغلاف' }),
          h('small', { text: i ? `${s.media ? (s.media.kind === 'video' ? '🎬 فيديو' : '🖼️ صورة') : '⚪ بدون وسائط'}${s.media?.kind === 'video' ? (s.rights ? ' · ✅' : ' · ⚠️ الحقوق') : ''}` : issue.title })),
        aiaBadges(issue, i));
      if (i) row.append(h('div', { class: 'aia-mv' },
        h('button', { type: 'button', 'aria-label': 'لفوق', onclick: (e) => { e.stopPropagation(); aiaMove(i, -1); } }, '▲'),
        h('button', { type: 'button', 'aria-label': 'لتحت', onclick: (e) => { e.stopPropagation(); aiaMove(i, 1); } }, '▼')));
      return [row, sel ? aiaQuick(issue, i) : null];
    }).flat().filter(Boolean) : []),
    E.issue ? h('div', { class: 'aia-row' }, h('button', { type: 'button', class: 'btn sm', onclick: aiaAddSlide }, '＋ خبر'), E.cur > 0 && E.cur <= issue.slides.length ? h('button', { type: 'button', class: 'btn sm', onclick: aiaDelSlide }, '🗑️ حذف المحدد') : null) : null,
    h('button', { type: 'button', class: `btn btn-block${E.mode === 'kit' ? ' btn-primary' : ''}`, onclick: () => { E.mode = E.mode === 'kit' && E.issue ? 'slide' : 'kit'; aiaEditor(); } }, '🪪 هويتي: الشعار والتوقيع'));
  };
  paintList();

  const sizes = h('div', { class: 'chips aia-sizes' }, ...Object.entries(AISlides.SIZES).map(([k, [, n]]) => h('button', { type: 'button', class: `chip${E.size === k ? ' on' : ''}`, onclick: () => { E.size = k; if (E.issue) { issue.look.size = k; aiaDirty(); } aiaEditor(); } }, n)));
  const st = h('div', { class: 'aia-status', text: E.issue ? (E.dirty ? '● تعديلات غير محفوظة' : 'جاهز.') : 'عدّل هويتك — تنحفظ تلقائياً.' });
  E.st = st;
  const play = h('button', { type: 'button', class: 'btn sm', onclick: () => { E.playing = !E.playing; play.textContent = E.playing ? '⏸' : '▶'; E.t0 = performance.now() - (E.pt || 0) * 1000; } }, E.playing ? '⏸' : '▶');
  // 1.21.25: «👁️ معاينة الحفظ» — نفس اللي بيطلع في الصورة/الفيديو المحفوظ (إعدادات «📸 عند الحفظ»)
  const igBtn = h('button', { type: 'button', class: `btn sm${E.igPrev ? ' btn-primary' : ''}`, onclick: () => { E.igPrev = !E.igPrev; aiaEditor(); } }, E.igPrev ? '📸 معاينة الحفظ (انستقرام) ✓' : '👁️ معاينة الحفظ (انستقرام)');
  const stage = h('div', { class: 'aia-stage' }, sizes, h('div', { class: 'aia-row' }, igBtn), cv,
    h('p', { class: 'hint', text: E.igPrev ? '📸 تشوف الحين شكل الحفظ — اسحب الشعار هنا ينحفظ مكانه للحفظ بس (التطبيق ما يتأثر).' : '✋ اسحب الشعار أو شريط التوقيع على المعاينة — كل مقاس يحفظ مكانه.' }),
    h('div', { class: 'aia-row' },
      h('button', { type: 'button', class: 'btn sm', onclick: () => aiaGo(-1) }, '→'), play, h('button', { type: 'button', class: 'btn sm', onclick: () => aiaGo(1) }, '←')),
    // 1.21.9: أزرار التصدير مرتّبة بمجموعات — كل مجموعة سطر يشرح وش تطلع
    E.issue ? aiaExports() : null,
    st);

  const panel = h('div', { class: 'aia-panel' });
  if (E.mode === 'kit') aiaKitPanel(panel);
  else if (E.cur === 0) aiaCoverPanel(panel, issue);
  else if (E.cur > issue.slides.length) aiaOutroPanel(panel);
  else aiaSlidePanel(panel, issue, issue.slides[E.cur - 1]);

  const top = h('div', { class: 'aia-top' },
    h('button', { type: 'button', class: 'btn sm', onclick: async () => { if (E.dirty && !(await confirmSheet({ title: 'تعديلات غير محفوظة', text: 'تطلع بدون حفظ؟', ok: 'اطلع' }))) return; aiaHome(); } }, '← الأعداد'),
    E.issue ? h('b', { text: `${aiaKindTxt(issue.kind, issue.week)} · ${issue.status === 'published' ? '● منشور' : issue.publish_at ? '⏰ ' + aiaWhen(issue.publish_at) : '○ مسودة'}` }) : h('b', { text: '🪪 هويتي' }),
    E.issue?.status !== 'published' && E.issue?.publish_at ? h('button', { type: 'button', class: 'btn sm', onclick: aiaUnsched }, '✕ ألغِ الجدولة') : null,
    h('span', { class: 'spacer' }),
    E.issue ? h('button', { type: 'button', class: 'btn sm', onclick: () => aiaSave(true) }, '💾 حفظ') : null,
    E.issue ? (issue.status === 'published'
      ? h('button', { type: 'button', class: 'btn sm', onclick: () => aiaPublish(false) }, '🙈 إخفاء')
      : h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => aiaPublish(true) }, '🚀 نشر')) : null,
    E.issue?.status === 'published' ? h('button', { type: 'button', class: 'btn sm', onclick: () => aiaPublish(true) }, '🔄 تحديث المنشور') : null,
    E.issue?.status === 'published' ? h('button', { type: 'button', class: 'btn sm', onclick: () => aiaCmtStats(E.issue) }, '📊 التعليقات') : null,
    E.issue ? h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف العدد', onclick: aiaDelete }, icon('trash', { size: 16 })) : null);
  box.replaceChildren(top, h('div', { class: 'aia-ed' }, h('div', { class: 'aia-side' }, list), stage, panel));
  aiaMini(cv);
  UI.digitize(top);
  cancelAnimationFrame(AIA.raf);
  const loop = (now) => {
    if (!AIA.ed || !document.body.contains(cv)) return;
    if (E.playing) E.pt = (now - E.t0) / 1000;
    const dur = AISlides.duration(issue, E.cur, AIA.kit);
    const vid = E.cur > 0 && issue.slides[E.cur - 1]?.media?.kind === 'video';
    if (E.playing && E.pt > dur + 1.2 && !vid) { E.t0 = now; }
    AISlides.sync(issue, [E.cur], E.playing);
    const pvIssue = E.mode === 'kit' && AIA.kscope && issue.kind !== AIA.kscope ? { ...issue, kind: AIA.kscope } : issue; // 1.21.12: المعاينة تعرض النوع اللي تعدّله
    AISlides.draw(cv.getContext('2d'), pvIssue, E.cur, E.pt || 0, { kit: AIA.kit, main: true, drag: E.drag?.key, igPrev: !!E.igPrev });
    if (now - E.last > 500) { E.last = now; list.querySelectorAll('canvas[data-i]').forEach((t) => AISlides.draw(t.getContext('2d'), issue, +t.dataset.i, 3, { kit: AIA.kit })); }
    AIA.raf = requestAnimationFrame(loop);
  };
  AIA.raf = requestAnimationFrame(loop);
}
function aiaGo(d) { const E = AIA.ed, issue = E.issue || E.preview; E.cur = Math.max(0, Math.min(AISlides.total(issue, AIA.kit) - 1, E.cur + d)); E.mode = E.issue ? 'slide' : 'kit'; E.t0 = performance.now(); AISlides.rewind(issue, E.cur); aiaEditor(); }
function aiaDirty() { const E = AIA.ed; if (!E?.issue) return; E.dirty = true; if (E.st) E.st.textContent = '● تعديلات غير محفوظة'; }
/* 1.21.9 — شارات صغيرة في مساحة السطر: المدة · الانتقال · الصوت · مخفي من الفيديو */
const AIA_TR = [['', '⚙️ مثل الكل'], ['dip', '🌑 يظلم'], ['cross', '🌫️ يذوب'], ['push', '👉 يدفع'], ['zoom', '🔍 زوم'], ['flash', '⚡ فلاش'], ['none', '✂️ قطع']];
function aiaBadges(issue, i) {
  const nS = issue.slides.length, o = AISlides.slideOpt(issue, i), d = AISlides.duration(issue, i, AIA.kit), tr = AIA_TR.find((x) => x[0] === o.trans);
  const fx = o.sfx && typeof Sfx !== 'undefined' ? Sfx.LIST.find((x) => x[0] === o.sfx) : null;
  return h('div', { class: 'aia-bdg' }, h('span', { text: `⏱️ ${aiaN(Math.round(d))}ث${+o.secs ? '' : i > nS ? '' : ' تلقائي'}` }),
    i > 0 && i <= nS && o.trans ? h('span', { text: tr ? tr[1] : '' }) : null, fx ? h('span', { text: fx[1] }) : null, o.skip ? h('span', { class: 'off', text: '🙈 مو في الفيديو' }) : null);
}
/* 1.21.9 — أدوات سريعة تحت السلايد المحدد: مدته، دخوله، صوته، تكراره، نقله، إخفاؤه من الفيديو */
function aiaQuick(issue, i) {
  const E = AIA.ed, nS = issue.slides.length, isO = i > nS, s = i && !isO ? issue.slides[i - 1] : null, L = issue.look = issue.look || {};
  const O = isO ? null : i === 0 ? (L.cOpt = L.cOpt || {}) : (s.opt = s.opt || {});
  const isV = s?.media?.kind === 'video' || (i === 0 && L.cover?.kind === 'video' && L.style === 'custom');
  const repaint = () => { aiaDirty(); const b = document.querySelector('.aia-it.on .aia-bdg'); if (b) b.replaceWith(aiaBadges(issue, i)); };
  const chips = (list, cur, fn) => h('div', { class: 'chips' }, ...list.map(([v, l]) => h('button', { type: 'button', class: `chip${String(cur ?? '') === String(v) ? ' on' : ''}`, onclick: (e) => { fn(v); [...e.currentTarget.parentNode.children].forEach((x) => x.classList.toggle('on', x === e.currentTarget)); } }, l)));
  const row = (lbl, el) => h('div', { class: 'aia-qr' }, h('span', { text: lbl }), el);
  const kids = [];
  if (isO) {
    const K = AIA.kit.outro;
    kids.push(row('⏱️ المدة', chips([3, 5, 7, 10].map((v) => [v, `${aiaN(v)}ث`]), K.secs || 5, (v) => { K.secs = v; aiaKitDirty(); })),
      h('div', { class: 'aia-qa' }, h('button', { type: 'button', class: 'btn sm', onclick: () => aiaOutroGo() }, '🪪 كل إعدادات الصفحة الأخيرة')));
  } else {
    kids.push(row('⏱️ المدة', isV ? h('small', { class: 'hint', text: 'فيديو — بطول القص (عدّله من الإعدادات تحت)' })
      : chips([[0, 'تلقائي'], ...[3, 4, 5, 6, 8, 10, 15].map((v) => [v, `${aiaN(v)}ث`])], +O.secs || 0, (v) => { if (v) O.secs = v; else delete O.secs; repaint(); })));
    if (i > 0) kids.push(row('🎬 الدخول', chips(AIA_TR, O.trans || '', (v) => { if (v) O.trans = v; else delete O.trans; repaint(); })));
    if (typeof Sfx !== 'undefined') {
      const sel = h('select', { class: 'input select sm' }, h('option', { value: '', text: i === 0 ? '⚙️ صوت الغلاف العام' : '⚙️ صوت الانتقال العام' }), ...Sfx.LIST.map(([id, nm]) => h('option', { value: id, text: nm, selected: O.sfx === id })));
      sel.addEventListener('change', () => { if (sel.value) { O.sfx = sel.value; Sfx.preview(sel.value); } else delete O.sfx; repaint(); });
      kids.push(row(i === 0 ? '🔊 صوت البداية' : '🔊 صوت الدخول', sel));
    }
    if (i > 0) {
      const c = h('input', { type: 'checkbox', checked: !!O.skip }); c.addEventListener('change', () => { if (c.checked) O.skip = true; else delete O.skip; document.querySelector('.aia-it.on')?.classList.toggle('skip', c.checked); repaint(); });
      kids.push(h('label', { class: 'switch-row aia-qsw' }, h('span', {}, h('b', { text: '🙈 خفّه من الفيديو الكامل' }), h('small', { text: 'يظل في التطبيق والكاروسيل — بس ما يدخل الدمج' })), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))));
      kids.push(h('div', { class: 'aia-qa' },
        h('button', { type: 'button', class: 'btn sm', onclick: () => { E.t0 = performance.now(); AISlides.rewind(issue, i); E.playing = true; } }, '▶ شغّل من هنا'),
        h('button', { type: 'button', class: 'btn sm', onclick: () => { if (nS >= 10) return toast('أقصى ١٠ أخبار في العدد'); issue.slides.splice(i, 0, JSON.parse(JSON.stringify(s))); E.cur = i + 1; aiaDirty(); aiaEditor(); toast('⧉ انسخ — عدّل النسخة'); } }, '⧉ كرّر'),
        h('button', { type: 'button', class: 'btn sm', disabled: i === 1 || null, onclick: () => { issue.slides.unshift(...issue.slides.splice(i - 1, 1)); E.cur = 1; aiaDirty(); aiaEditor(); } }, '⤒ خلّه الأول'),
        h('button', { type: 'button', class: 'btn sm', disabled: i === nS || null, onclick: () => { issue.slides.push(...issue.slides.splice(i - 1, 1)); E.cur = nS; aiaDirty(); aiaEditor(); } }, '⤓ خلّه الأخير'),
        s.url ? h('button', { type: 'button', class: 'btn sm', onclick: () => window.open(s.url, '_blank', 'noopener') }, '🔗 المصدر') : null,
        h('button', { type: 'button', class: 'btn sm danger', onclick: aiaDelSlide }, '🗑️ حذف')));
    } else kids.push(h('div', { class: 'aia-qa' }, h('button', { type: 'button', class: 'btn sm', onclick: () => { E.t0 = performance.now(); AISlides.rewind(issue, 0); E.playing = true; } }, '▶ شغّل من البداية'),
      h('button', { type: 'button', class: 'btn sm', onclick: () => aiaMergeSheet() }, '🎞️ ادمج الفيديو كامل')));
    kids.push(h('button', { type: 'button', class: 'btn sm aia-q-all', onclick: () => { for (let k = 0; k <= nS; k++) { const x = k ? (issue.slides[k - 1].opt = issue.slides[k - 1].opt || {}) : (L.cOpt = L.cOpt || {}); if (O.secs) x.secs = O.secs; else delete x.secs; if (k && i) { if (O.trans) x.trans = O.trans; else delete x.trans; } }
      aiaDirty(); aiaEditor(); toast('✅ انطبقت المدة' + (i ? ' والدخول' : '') + ' على كل السلايدات'); } }, '⇉ طبّق المدة' + (i ? ' والدخول' : '') + ' على الكل'));
  }
  return h('div', { class: 'aia-quick-t' }, ...kids);
}
function aiaOutroGo() { AIA.ed.mode = 'kit'; aiaEditor(); setTimeout(() => [...document.querySelectorAll('.aia-panel h3')].find((x) => x.textContent.includes('الصفحة الأخيرة'))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120); }
/* 🏷️ شعار المصدر: الشعار الحقيقي (ترفعه مرة ويتذكّره لكل الأعداد) أو حرف أنيق أو اسم أو إيموجي أو NOBLE أو بدون */
function aiaMarkCtl(s) {
  const K = AIA.kit, key = AISlides.logoKey(s.company), M = s.mark = s.mark || {}, saved = key && K.logos?.[key];
  const set = (k, v) => { if (v === '' || v == null) delete M[k]; else M[k] = v; aiaDirty(); aiaEditor(); };
  const upLogo = () => aiaPickFile('image/*', async (f) => { s.logo = URL.createObjectURL(f); M.kind = 'logo'; aiaEditor();
    try { s.logo = await aiaUpload(f); if (key) { K.logos = { ...(K.logos || {}), [key]: s.logo }; aiaKitDirty(); }
      aiaDirty(); aiaStatus(`✅ انرفع الشعار${key ? ` — ويطلع تلقائياً في أي خبر لـ«${s.company}»` : ''}`); aiaEditor(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
  const kinds = [['auto', '✨ تلقائي'], ['logo', '🏢 الشعار'], ['letter', '🔤 حرف'], ['word', '🅰️ الاسم'], ['emoji', '😀 إيموجي'], ['noble', '✦ NOBLE'], ['none', '🚫 بدون']];
  const cur = M.kind || 'auto', eff = AISlides.markOf(s).kind;
  return [h('h3', { class: 'aia-sub', text: '🏷️ شعار المصدر' }),
    h('div', { class: 'aia-mk-top' },
      h('button', { type: 'button', class: 'aia-drop sm', onclick: upLogo }, s.logo ? '✅ شعار هذا الخبر · بدّل' : saved ? `🧠 محفوظ لـ«${s.company}» · بدّل` : '📤 ارفع شعار الشركة (PNG)'),
      s.logo || saved ? h('button', { type: 'button', class: 'btn sm', onclick: () => { s.logo = ''; if (key && K.logos?.[key]) { delete K.logos[key]; aiaKitDirty(); } aiaDirty(); aiaEditor(); } }, '✕ شيله') : null),
    aiaField('وش يطلع', aiaChips(kinds, cur, (k) => set('kind', k === 'auto' ? '' : k))),
    h('p', { class: 'hint', text: cur === 'auto' ? `تلقائي = الشعار لو موجود، وإلا حرف واحد أنيق. الحين: ${(kinds.find((x) => x[0] === eff) || [, ''])[1]}` : eff !== cur ? '⚠️ ما فيه شعار مرفوع — يطلع حرف لين ترفع' : '' }),
    ['letter', 'word', 'auto'].includes(cur) && eff !== 'logo' ? aiaField(cur === 'word' ? 'النص داخل الدائرة (فاضي = اسم الشركة)' : 'الحرف (فاضي = أول حرف من الاسم)', (() => { const i = h('input', { class: 'input ltr', dir: 'ltr', value: M.txt || '', maxlength: cur === 'word' ? 14 : 2 }); i.addEventListener('input', () => { if (i.value) M.txt = i.value; else delete M.txt; aiaDirty(); }); return i; })()) : null,
    cur === 'emoji' ? aiaField('اختر إيموجي', h('div', { class: 'chips aia-emo' }, ...['🤖', '🧠', '💡', '⚡', '🚀', '📱', '💻', '🔒', '🎮', '🛰️', '💰', '📈', '🧬', '🎨', '🔬', '🌐'].map((e) =>
      h('button', { type: 'button', class: `chip${(M.emoji || '🤖') === e ? ' on' : ''}`, onclick: () => set('emoji', e) }, e)))) : null,
    eff === 'logo' ? aiaField('الشعار داخل الدائرة', aiaChips([['contain', '🔲 كامل بمسافة'], ['cover', '⬛ يعبّيها']], M.fit || 'contain', (k) => set('fit', k))) : null,
    !['none', 'noble'].includes(eff) ? aiaField('الخلفية', aiaChips([['white', '⚪ أبيض'], ['theme', '🎨 لون الثيم'], ['dark', '⚫ داكن'], ['glass', '🫧 زجاج']], M.bg || 'white', (k) => set('bg', k))) : null,
    !s.media ? aiaField('🎞️ الخلفية المتحركة ورا الشعار', aiaChips([['', '⚙️ مثل هويتي'], ...AISlides.PH_FX], M.fx || '', (k) => set('fx', k))) : h('p', { class: 'hint', text: '🎞️ الخلفية المتحركة تطلع لما الخبر ما فيه صورة أو فيديو.' }),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { const all = AIA.ed.issue.slides; all.forEach((x) => { if (x !== s) x.mark = { ...(x.mark || {}), ...Object.fromEntries(Object.entries(M).filter(([k]) => ['kind', 'fit', 'bg', 'fx'].includes(k))) }; }); aiaDirty(); aiaEditor(); toast('✅ نفس الشكل لكل أخبار العدد'); } }, '⇉ طبّق نفس الشكل على كل الأخبار')];
}
/* 🎞️ الصورة أو الفيديو داخل مربع الخبر */
function aiaMediaFit(s) {
  const sl = (label, key, d, mn, mx, unit = '٪') => { const v0 = Number.isFinite(+s[key]) && s[key] !== '' && s[key] != null ? +s[key] : d, lb = h('span', { text: `${label} — ${aiaN(v0)}${unit}` });
    const r = h('input', { type: 'range', min: mn, max: mx, step: 1, value: v0, dir: key === 'mpx' ? 'ltr' : null }); r.addEventListener('input', () => { s[key] = +r.value; lb.textContent = `${label} — ${aiaN(+r.value)}${unit}`; aiaDirty(); }); return h('label', { class: 'field' }, lb, r); };
  const set = (k, v) => { s[k] = v; aiaDirty(); aiaEditor(); };
  return [h('div', { class: 'aia-grp-b aia-mfit' },
    aiaField('داخل المربع', aiaChips([['cover', '⬛ يعبّي المربع كامل'], ['contain', '🔲 يطلع كامل بدون قص']], s.mfit || 'cover', (k) => set('mfit', k))),
    s.mfit === 'contain' ? aiaField('الفراغ حوله', aiaChips([['dark', '⚫ داكن'], ['blur', '🌫️ نفس الصورة مغبّشة']], s.mbg || 'dark', (k) => set('mbg', k))) : null,
    sl('تكبير', 'mzoom', 100, 50, 300), sl('حرّكها يمين ↔ يسار', 'mpx', 0, -100, 100, ''), sl('حرّكها فوق ↕ تحت', 'mpy', 0, -100, 100, ''),
    s.media?.kind === 'image' ? aiaField('حركة زوم بطيئة للصورة', aiaChips([[true, '✨ شغّالة'], [false, 'ثابتة']], s.kb !== false, (k) => set('kb', k))) : null,
    h('button', { type: 'button', class: 'btn sm', onclick: () => { ['mfit', 'mbg', 'mzoom', 'mpx', 'mpy', 'kb'].forEach((k) => delete s[k]); aiaDirty(); aiaEditor(); } }, '↺ رجّع'))];
}
/* 🧊 أيقونة الغلاف: ترفع PNG شفاف (أو فيديو/WebM شفاف) وتتحكم بكل شي */
function aiaCoverIcon(L) {
  const I = L.icon = L.icon || {};
  const sl = (label, key, d, mn, mx, unit = '') => { const v0 = Number.isFinite(+I[key]) && I[key] !== '' && I[key] != null ? +I[key] : d, lb = h('span', { text: `${label} — ${aiaN(v0)}${unit}` });
    const r = h('input', { type: 'range', min: mn, max: mx, step: 1, value: v0, dir: key === 'x' ? 'ltr' : null }); r.addEventListener('input', () => { I[key] = +r.value; lb.textContent = `${label} — ${aiaN(+r.value)}${unit}`; aiaDirty(); if (AIA.ed) AIA.ed.cur = 0; }); return h('label', { class: 'field' }, lb, r); };
  const set = (k, v) => { I[k] = v; aiaDirty(); aiaEditor(); };
  const pick = () => aiaPickFile('image/png,image/webp,image/*,video/webm,video/mp4,video/*', async (f) => {
    const kind = f.type.startsWith('video/') ? 'video' : 'image', local = URL.createObjectURL(f);
    Object.assign(I, { url: local, kind, name: f.name.slice(0, 40), local: true }); AIA.ed.cur = 0; AIA.ed.t0 = performance.now(); aiaDirty(); aiaEditor();
    try { const url = await aiaUpload(f); if (I.url === local) { I.url = url; delete I.local; } aiaStatus('✅ انرفعت الأيقونة — اضغط 💾 حفظ'); aiaEditor(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
  return [h('h3', { class: 'aia-sub', text: '🧊 أيقونة الغلاف' }),
    aiaField('مكان العنوان', aiaChips([['', '⬇️ العنوان تحت'], ['top', '⬆️ العنوان فوق والأيقونة تحته']], L.layout || '', (k) => { L.layout = k; aiaDirty(); aiaEditor(); })),
    h('div', { class: 'aia-mk-top' }, h('button', { type: 'button', class: 'aia-drop sm', onclick: pick }, I.url ? `${I.kind === 'video' ? '🎬' : '🖼️'} ${I.local ? 'يرفع…' : I.name || 'مرفوعة'} · بدّل` : '📤 ارفع أيقونتك (PNG شفاف أو فيديو)'),
      I.url ? h('button', { type: 'button', class: 'btn sm', onclick: () => { L.icon = {}; aiaDirty(); aiaEditor(); } }, '✕ شيلها') : null),
    ...(I.url ? [
      aiaField('الحركة', aiaChips([['float', '🎈 تطفو'], ['swing', '🔔 تتمايل'], ['pulse', '💓 تنبض'], ['spin', '🔄 تلف'], ['drop', '⬇️ تنزل وتثبت'], ['none', '⏸️ ثابتة']], I.anim || 'float', (k) => set('anim', k))),
      sl('الحجم', 'size', 100, 20, 250, '٪'), sl('يمين ↔ يسار', 'x', 0, -500, 500), sl('فوق ↕ تحت', 'y', 0, -700, 700), sl('الميلان', 'rot', 0, -45, 45, '°'),
      sl('سرعة الحركة', 'speed', 100, 0, 300, '٪'), sl('التوهج وراها', 'glow', 60, 0, 200, '٪'), sl('الشفافية', 'op', 100, 10, 100, '٪'),
      aiaField('الطبقة', aiaChips([['front', '⬆️ قدام العنوان'], ['behind', '⬇️ ورا العنوان']], I.layer || 'front', (k) => set('layer', k))),
      aiaField('الظل', aiaChips([[true, '🌑 بظل'], [false, 'بدون']], I.shadow !== false, (k) => set('shadow', k))),
      aiaField('اقلبها', aiaChips([[false, 'عادي'], [true, '↔️ مقلوبة']], !!I.flip, (k) => set('flip', k))),
      h('button', { type: 'button', class: 'btn sm', onclick: () => { L.icon = { url: I.url, kind: I.kind, name: I.name }; aiaDirty(); aiaEditor(); } }, '↺ رجّع الإعدادات')] : []),
    h('p', { class: 'hint', text: 'أفضل شي PNG بخلفية شفافة (من الفوتوشوب أو أي أداة 3D). الفيديو يشتغل بدون صوت ويعيد، والـWebM الشفاف يطلع بدون خلفية. استخدم أيقونات من تصميمك أو عندك حقوقها.' })];
}
function aiaMove(i, d) { const E = AIA.ed, a = E.issue.slides, j = i - 1 + d; if (j < 0 || j >= a.length) return; [a[i - 1], a[j]] = [a[j], a[i - 1]]; E.cur = j + 1; aiaDirty(); aiaEditor(); }
function aiaAddSlide() { const E = AIA.ed; if (E.issue.slides.length >= 10) return toast('أقصى ١٠ أخبار في العدد'); E.issue.slides.push({ company: 'شركة', initial: 'AI', head: '', body: 'اكتب ملخص الخبر هنا.', source: '', url: '', tier: '', media: null, trim: [0, 0], rights: false }); E.cur = E.issue.slides.length; E.mode = 'slide'; aiaDirty(); aiaEditor(); }
async function aiaDelSlide() { const E = AIA.ed; if (E.cur < 1 || E.cur > E.issue.slides.length) return; if (!(await confirmSheet({ title: 'حذف السلايد', text: 'ينحذف الخبر من العدد.', ok: 'حذف' }))) return; E.issue.slides.splice(E.cur - 1, 1); E.cur = Math.max(0, E.cur - 1); aiaDirty(); aiaEditor(); }

/* حقول */
function aiaField(label, el, hint) { return h('label', { class: 'field' }, h('span', { text: label }), el, hint ? h('small', { class: 'hint', text: hint }) : null); }
function aiaInput(o, key, opt = {}) {
  const el = opt.area ? h('textarea', { class: 'input textarea', rows: opt.rows || 4, maxlength: opt.max || 420 }) : h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, type: opt.type || 'text', maxlength: opt.max || 160 });
  el.value = o[key] ?? '';
  el.addEventListener('input', () => { o[key] = opt.type === 'number' ? Number(el.value) || 0 : el.value; opt.onInput?.(); aiaDirty(); });
  if (opt.ltr) el.dir = 'ltr';
  return el;
}
function aiaChips(opts, val, set) { return h('div', { class: 'chips' }, ...opts.map(([k, n, extra]) => h('button', { type: 'button', class: `chip${val === k ? ' on' : ''}`, onclick: (e) => { const b = e.currentTarget; [...b.parentNode.children].forEach((x) => x.classList.toggle('on', x === b)); set(k); } }, extra || null, n))); }
async function aiaUpload(file, onP) {
  let f = file;
  if (f.type.startsWith('video/') && typeof faCompress === 'function' && f.size > 12e6) { aiaStatus('⏳ ضغط الفيديو…'); f = await faCompress(f, (p) => aiaStatus(`⏳ ضغط الفيديو ${aiaN(Math.round(p * 100))}٪`)); }
  if (f.size > 48e6) throw new Error('الملف أكبر من ٤٨ ميجا — قصّه أو صغّره');
  aiaStatus('⏳ رفع…'); onP?.();
  return Cloud.admin.designUpload(f, 'ai');
}
const aiaStatus = (m) => { if (AIA.ed?.st) AIA.ed.st.textContent = m; };
function aiaPickFile(accept, cb) { const i = h('input', { type: 'file', accept }); i.addEventListener('change', () => i.files[0] && cb(i.files[0])); i.click(); }
/* ملف ← معاينة فورية من الجهاز، وبعد الرفع نبدّل للرابط */
function aiaMediaIn(target, key, accept = 'video/*,image/*') {
  return h('button', { type: 'button', class: 'aia-drop', onclick: () => aiaPickFile(accept, async (file) => {
    const kind = file.type.startsWith('video/') ? 'video' : 'image', local = URL.createObjectURL(file);
    target[key] = { url: local, kind, name: file.name, local: true };
    if (kind === 'video') { const v = AISlides.vidOf(local); v.addEventListener('loadedmetadata', () => { if (target.trim) target.trim = [0, Math.min(60, +v.duration.toFixed(1))]; aiaEditor(); }, { once: true }); }
    AIA.ed.t0 = performance.now(); aiaDirty(); aiaEditor();
    try { const url = await aiaUpload(file); if (target[key]?.url === local) { target[key] = { url, kind, name: file.name }; } aiaStatus('✅ انرفع — اضغط 💾 حفظ'); aiaEditor(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); aiaStatus('⚠️ ما انرفع: ' + Cloud.msg(e)); }
  }) }, target[key] ? h('b', { text: `${target[key].kind === 'video' ? '🎬' : '🖼️'} ${target[key].local ? 'يرفع…' : target[key].name || 'مرفوع'} — اضغط للتبديل` }) : h('b', { text: '📤 ارفع فيديو أو صورة' }), h('small', { text: 'MP4 / MOV / PNG / JPG — الفيديو يُفضّل ٦٠ ثانية أو أقل' }));
}

function aiaCoverPanel(P, issue) {
  const L = issue.look;
  P.replaceChildren(h('h3', { text: '🎬 الغلاف' }),
    aiaField('نوع العدد', aiaChips([...Object.entries(AIA_PER).map(([k, v]) => [k, `${v.ic} ${v.name}`]), ['urgent', '⚡ عاجل']], issue.kind, (k) => {
      const old = issue.kind; issue.kind = k;
      if (issue.kicker === aiaKickerOf(old)) issue.kicker = aiaKickerOf(k);
      if (k !== 'urgent' && issue.title === aiaTitleOf(old)) issue.title = aiaTitleOf(k);
      if (k !== 'urgent') { issue.week = aiaNum(k); issue.date_label = aiaDate(new Date(), k); }
      aiaDirty(); aiaEditor(); })),
    aiaField('العنوان', aiaInput(issue, 'title', { max: 120, onInput: () => {} })),
    h('div', { class: 'two-col' }, aiaField(issue.kind === 'daily' ? 'رقم اليوم' : issue.kind === 'monthly' ? 'رقم الشهر' : 'رقم الأسبوع', aiaInput(issue, 'week', { type: 'number', ltr: true })), aiaField('التاريخ', aiaInput(issue, 'date_label', { max: 40 }))),
    aiaField('الشارة فوق العنوان', aiaInput(issue, 'kicker', { max: 40 })),
    aiaField('شكل الغلاف والتحريك', aiaChips(AISlides.COVERS, L.style, (k) => { L.style = k; AIA.ed.t0 = performance.now(); aiaDirty(); aiaEditor(); })),
    L.style === 'custom' ? aiaMediaIn(L, 'cover', 'image/*,video/*') : null,
    // 1.21.9: تحكم الغلاف — التوهج والخلفية، وفيديو كامل للغلاف
    ...aiaCoverCtl(L),
    ...aiaCoverIcon(L),
    aiaField('الألوان', aiaChips(Object.entries(AISlides.THEMES).map(([k, v]) => [k, v.name, h('i', { class: 'aia-sw', style: { background: `linear-gradient(90deg,${v.c.join(',')})` } })]), L.theme, (k) => { L.theme = k; aiaDirty(); aiaEditor(); })),
    h('p', { class: 'hint', text: 'اللون ينطبق على الغلاف وكل سلايدات الأخبار. المقاس اللي تختاره فوق المعاينة يصير الافتراضي لهذا العدد.' }),
    // 1.21.9: موسيقى العدد — تنحفظ معه وتشتغل في التطبيق والفيديو الكامل
    h('h3', { class: 'aia-sub', text: '🎵 موسيقى العدد' }), aiaMusicBox(AIA.merge || (AIA.merge = {}), issue));
}
function aiaCoverCtl(L) {
  const sl = (label, key, d, mn, mx, unit = '٪') => { const v0 = Number.isFinite(+L[key]) && L[key] !== '' ? +L[key] : d, lb = h('span', { text: `${label} — ${aiaN(v0)}${unit}` });
    const r = h('input', { type: 'range', min: mn, max: mx, step: 5, value: v0 });
    r.addEventListener('input', () => { L[key] = +r.value; lb.textContent = `${label} — ${aiaN(+r.value)}${unit}`; aiaDirty(); if (AIA.ed) AIA.ed.cur = 0; }); return h('label', { class: 'field' }, lb, r); };
  const isVid = L.style === 'custom' && L.cover?.kind === 'video', v = isVid ? AISlides.vidOf(L.cover.url) : null, d = v?.duration && isFinite(v.duration) ? v.duration : 0;
  L.cTrim = L.cTrim || [0, 0];
  const tIn = (k) => { const el = h('input', { class: 'input num ltr', type: 'number', step: '.5', min: 0, max: d || 600, value: L.cTrim[k] || (k ? Math.min(60, d || 0) : 0) });
    el.addEventListener('input', () => { L.cTrim[k] = Math.max(0, +el.value || 0); if (L.cTrim[1] && L.cTrim[1] <= L.cTrim[0]) L.cTrim[1] = L.cTrim[0] + 1; if (v) v.currentTime = L.cTrim[0]; aiaDirty(); }); return el; };
  const reset = h('button', { type: 'button', class: 'btn sm', onclick: () => { ['glow', 'gsize', 'speed', 'shade', 'vzoom', 'fit'].forEach((k) => delete L[k]); L.cTrim = [0, 0]; aiaDirty(); aiaEditor(); } }, '↺ رجّع الغلاف الافتراضي');
  return [h('h3', { class: 'aia-sub', text: '✨ التوهج والخلفية' }),
    L.style !== 'custom' ? sl('قوة التوهج', 'glow', 100, 0, 200) : null,
    L.style !== 'custom' ? sl('حجم التوهج', 'gsize', 100, 50, 160) : null,
    sl('سرعة الحركة', 'speed', 100, 0, 300),
    sl('تعتيم الخلفية', 'shade', 0, 0, 90),
    L.style === 'custom' ? aiaField('ملء الشاشة', aiaChips([['cover', 'يملى الغلاف'], ['contain', 'كامل بدون قص']], L.fit || 'cover', (k) => { L.fit = k; aiaDirty(); aiaEditor(); })) : null,
    L.style === 'custom' ? sl('تكبير', 'vzoom', 100, 50, 200) : null,
    isVid ? h('h3', { class: 'aia-sub', text: '🎬 فيديو الغلاف' }) : null,
    isVid && d ? h('div', { class: 'two-col' }, aiaField('يبدأ من (ث)', tIn(0)), aiaField('ينتهي عند (ث)', tIn(1))) : null,
    isVid ? h('p', { class: 'hint', text: d ? `مدة المقطع ${aiaN(d.toFixed(1))} ث — الغلاف يمشي بطول القص (أقصى ٦٠ ث)، والكلام يطلع فوقه. «تعتيم الخلفية» يخلي الكلام أوضح.` : '⏳ يحمّل الفيديو… افتح الغلاف مرة ثانية لو ما طلعت خانات القص.' }) : null,
    L.style !== 'custom' ? h('p', { class: 'hint', text: 'تبي فيديو كامل للغلاف؟ اختر «🖼️ خلفيتك» فوق وارفع فيديو.' }) : null,
    reset].filter(Boolean);
}
function aiaOutroPanel(P) {
  P.replaceChildren(h('h3', { text: '🏁 الصفحة الأخيرة' }),
    h('p', { class: 'hint', text: 'نفسها لكل الأعداد — شكلها ونصها وزرها ورابط الـQR تتعدّل من «🪪 هويتي» ← «🏁 الصفحة الأخيرة».' }),
    h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { AIA.ed.mode = 'kit'; aiaEditor(); setTimeout(() => [...document.querySelectorAll('.aia-panel h3')].find((x) => x.textContent.includes('الصفحة الأخيرة'))?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 120); } }, '🪪 عدّل الصفحة الأخيرة'));
}
function aiaSlidePanel(P, issue, s) {
  const v = s.media?.kind === 'video' ? AISlides.vidOf(s.media.url) : null, d = v?.duration && isFinite(v.duration) ? Math.min(600, v.duration) : 0;
  s.trim = s.trim || [0, 0];
  const trimIn = (k) => { const el = h('input', { class: 'input num ltr', type: 'number', step: '.1', min: 0, max: d, value: s.trim[k] || (k ? Math.min(60, d) : 0) });
    el.addEventListener('input', () => { s.trim[k] = Math.max(0, +el.value || 0); if (s.trim[1] && s.trim[1] <= s.trim[0]) s.trim[1] = s.trim[0] + 1; if (v) v.currentTime = s.trim[0]; aiaDirty(); }); return el; };
  const rights = h('input', { type: 'checkbox', checked: !!s.rights });
  rights.addEventListener('change', () => { s.rights = rights.checked; aiaDirty(); });
  P.replaceChildren(...[h('h3', {}, `📰 خبر ${aiaN(AIA.ed.cur)} من ${aiaN(issue.slides.length)}`, s.tier ? h('small', { text: ' ' + (AIA_TIER[s.tier] || '') }) : null),
    s.video?.url ? h('div', { class: 'aia-sug' }, h('b', { text: '🎬 مقطع رسمي مقترح:' }), h('a', { href: s.video.url, target: '_blank', rel: 'noopener', text: `${s.video.title || 'افتح المقطع'} ↗` }), h('small', { text: `من ${s.video.src || 'القناة الرسمية'} — نزّل المقطع بطريقة تسمح بها المنصة، وارفعه هنا.` })) : null,
    aiaMediaIn(s, 'media'),
    s.media ? h('button', { type: 'button', class: 'btn sm', onclick: () => { s.media = null; aiaDirty(); aiaEditor(); } }, '✕ شيل الوسائط') : null,
    // 1.21.9: الصورة/الفيديو داخل المربع — يعبّيه أو كامل، تكبير، تحريك
    ...(s.media ? aiaMediaFit(s) : []),
    d ? h('div', { class: 'two-col' }, aiaField('البداية (ث)', trimIn(0)), aiaField('النهاية (ث)', trimIn(1))) : null,
    d ? h('p', { class: 'hint', text: `مدة المقطع ${aiaN(d.toFixed(1))} ث — السلايد يصدّر بمدة القص (أقصى ٦٠ ث لإنستقرام).` }) : null,
    h('div', { class: 'two-col' }, aiaField('اسم الشركة', aiaInput(s, 'company', { max: 40 })),
      h('span')),
    // 1.21.9: «🏷️ شعار المصدر» — تتحكم فيه لكل سلايد
    ...aiaMarkCtl(s),
    aiaField('العنوان (اختياري)', aiaInput(s, 'head', { max: 120 })),
    aiaField('نص الخبر', aiaInput(s, 'body', { area: true, max: 420 }), 'أفضل طول: ٢٥–٤٠ كلمة.'),
    h('div', { class: 'two-col' }, aiaField('المصدر (يظهر على البطاقة)', aiaInput(s, 'source', { max: 60 })), aiaField('رابط الخبر', aiaInput(s, 'url', { max: 500, ltr: true }))),
    s.media?.kind === 'video' ? h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'أؤكد حقوق المقطع' }), h('small', { text: 'المقطع رسمي من الشركة أو عندي حق استخدامه، ومذكور مصدره.' })), h('span', { class: 'switch' }, rights, h('span', { class: 'track' }))) : null].filter(Boolean));
}

/* هويتي: الشعار + شريط التوقيع (تنحفظ تلقائياً) */
let aiaKitT = 0;
/* 1.21.3: ما نحفظ أبداً رابط مؤقت (blob:) — كان يصير لو عدّلت شي ثاني والصورة لسا ترفع، فتطلع الدائرة فاضية عند الكل */
const aiaNoBlob = (o) => JSON.parse(JSON.stringify(o, (k, v) => (typeof v === 'string' && v.startsWith('blob:') ? undefined : v)));
function aiaKitDirty() { clearTimeout(aiaKitT); aiaKitT = setTimeout(async () => { try { await Cloud.admin.aiKitSet(aiaNoBlob(AIA.kit)); aiaStatus('✅ انحفظت هويتك'); } catch (e) { aiaStatus('⚠️ ' + Cloud.msg(e)); } }, 700); }
/* 1.21.9 — «💾 قوالبي»: تحفظ تعديلاتك كقالب باسم وترجع له بضغطة (مرجع لك بدل ما تعيد كل زر وسطر)
 * bucket: 'outro' (الصفحة الأخيرة) · 'ui' (عناصر السلايد والغلاف) — تنحفظ في هويتي (kit.presets) */
function aiaPresets(bucket, obj, skip = [], max = 10) {
  const K = AIA.kit; K.presets = K.presets || {}; const L = K.presets[bucket] = K.presets[bucket] || [];
  const snap = () => Object.fromEntries(Object.entries(obj).filter(([k, v]) => !skip.includes(k) && !(typeof v === 'string' && v.startsWith('blob:'))));
  const save = () => {
    const inp = h('input', { class: 'input', value: `قالب ${aiaN(L.length + 1)}`, maxlength: 30 });
    const go = () => { closeSheet(); done(inp.value.trim()); };
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    pickSheet('💾 احفظ الشكل كقالب', 'اكتب اسم تعرفه فيه — لو نفس اسم قالب موجود ينحدّث', [h('div', { class: 'aia-m' }, aiaField('اسم القالب', inp),
      L.length ? h('div', { class: 'chips' }, ...L.map((x) => h('button', { type: 'button', class: 'chip', onclick: () => { inp.value = x.name; } }, `↻ ${x.name}`))) : null,
      h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: go }, '💾 احفظ'))]);
    setTimeout(() => { inp.focus(); inp.select(); }, 80);
  };
  const done = (name) => {
    if (!name) return; const i = L.findIndex((x) => x.name === name), row = { name: name.slice(0, 30), data: snap(), at: Date.now() };
    if (i >= 0) L[i] = row; else { if (L.length >= max) return toast(`أقصى ${aiaN(max)} قوالب — احذف واحد أول`); L.push(row); }
    aiaKitDirty(); aiaEditor(); toast(`💾 انحفظ «${row.name}»`, { type: 'success' });
  };
  const apply = (row) => { const keep = Object.fromEntries(skip.map((k) => [k, obj[k]])); Object.keys(obj).forEach((k) => { if (!skip.includes(k)) delete obj[k]; }); Object.assign(obj, row.data, keep); aiaKitDirty(); aiaEditor(); toast(`✅ طبّقت «${row.name}»`); };
  const del = async (row) => { if (!(await confirmSheet({ title: 'حذف القالب', text: `«${row.name}» ينحذف.`, ok: 'حذف' }))) return; L.splice(L.indexOf(row), 1); aiaKitDirty(); aiaEditor(); };
  return h('div', { class: 'aia-pre' },
    h('div', { class: 'aia-pre-h' }, h('b', { text: '💾 قوالبي' }), h('button', { type: 'button', class: 'btn sm btn-primary', onclick: save }, '＋ احفظ الشكل الحالي')),
    L.length ? h('div', { class: 'aia-pre-l' }, ...L.map((row) => h('div', { class: 'aia-pre-i' },
      h('button', { type: 'button', class: 'aia-pre-n', onclick: () => apply(row) }, h('b', { text: row.name }), h('small', { text: 'اضغط للتطبيق' })),
      h('button', { type: 'button', class: 'aia-pre-x', 'aria-label': 'حذف', onclick: () => del(row) }, '✕'))))
      : h('small', { class: 'hint', text: 'عجبك شكل؟ احفظه هنا باسم، وترجع له بضغطة بعدين.' }));
}
/* 🏁 الصفحة الأخيرة — تحكم كامل */
function aiaOutroCtl(O, E, sw, kin, up) {
  const T = AISlides.OUTRO_TXT;
  const osl = (label, key, def, min, max, step = 5, unit = '٪') => { const v0 = Number.isFinite(+O[key]) && O[key] !== '' && O[key] != null ? +O[key] : def;
    const lb = h('span', { text: `${label} — ${aiaN(v0)}${unit}` }), r = h('input', { type: 'range', min, max, step, value: v0 });
    r.addEventListener('input', () => { O[key] = +r.value; lb.textContent = `${label} — ${aiaN(+r.value)}${unit}`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); };
  const grp = (title, ...kids) => h('details', { class: 'aia-grp' }, h('summary', { text: title }), h('div', { class: 'aia-grp-b' }, ...kids.filter(Boolean)));
  if (!O.on) return [sw('إظهار الصفحة الأخيرة', 'سلايد بعد آخر خبر يدعو لتحميل NOBLE', O, 'on')];
  const st = O.style || 'card', qr = st === 'qr', ph = st === 'phone';
  // النص الحالي (جاهز أو اللي كتبته) — دايم قابل للتعديل
  const P0 = AISlides.outroText(O);
  const tx = (label, k, i) => { const inp = h('input', { class: 'input', value: P0[i] || '', maxlength: 90, placeholder: 'فاضي = يختفي السطر' });
    inp.addEventListener('input', () => { if (O.preset !== 'custom') { [O.t1, O.t2, O.t3] = AISlides.outroText(O); O.preset = 'custom'; } O[k] = inp.value; aiaKitDirty(); }); return aiaField(label, inp); };
  const icRow = (n, e0, l0) => { const on = O[`i${n}`] !== false;
    const e = h('input', { class: 'input aia-ic-e', value: O[`i${n}e`] ?? e0, maxlength: 4 }), l = h('input', { class: 'input', value: O[`i${n}l`] ?? l0, maxlength: 20 });
    e.addEventListener('input', () => { O[`i${n}e`] = e.value; aiaKitDirty(); }); l.addEventListener('input', () => { O[`i${n}l`] = l.value; aiaKitDirty(); });
    const c = h('input', { type: 'checkbox', checked: on }); c.addEventListener('change', () => { O[`i${n}`] = c.checked; aiaKitDirty(); });
    return h('div', { class: 'aia-ic-row' }, h('label', { class: 'switch sm' }, c, h('span', { class: 'track' })), e, l); };
  return [
    sw('إظهار الصفحة الأخيرة', 'سلايد بعد آخر خبر يدعو لتحميل NOBLE', O, 'on'),
    aiaPresets('outro', O, ['on', 'inApp'], 8),
    // 1.21.26: 💬 زر التعليقات في العارض (التطبيق) — مع الصفحة الأخيرة
    sw('💬 زر «اكتب رأيك» في التطبيق', 'يطلع فوق الصفحة الأخيرة لما يعرضها المستخدم في التطبيق، ويفتح التعليقات', O, 'cmtOn'),
    O.cmtOn !== false ? kin('نص الزر', O, 'cmtText') : null,
    aiaField('الشكل', aiaChips([['card', '📇 بطاقة التطبيق'], ['phone', '📱 جوال'], ['qr', '🔳 QR']], st, (k) => { O.style = k; aiaKitDirty(); aiaEditor(); })),
    O.on && E ? h('button', { type: 'button', class: 'btn sm', onclick: () => { E.cur = AISlides.total(E.issue || E.preview, AIA.kit) - 1; E.t0 = performance.now(); } }, '👁️ شوفها في المعاينة') : null,
    grp('✏️ النص',
      aiaField('ابدأ من نص جاهز (يتعبّى تحت وتعدّله)', aiaChips([[1, 'مباشر'], [2, 'ودّك تعرف أكثر؟'], [3, 'من المصدر'], [4, 'لا يفوتك'], [5, 'قصير'], [6, 'تفاعل']], O.preset, (k) => {
        const P = T[k] || T[1]; O.preset = k; O.t1 = P[0]; O.t2 = P[1]; O.t3 = P[2]; aiaKitDirty(); aiaEditor(); })),
      tx('السطر الكبير', 't1', 0), tx('السطر الثاني', 't2', 1), tx('السطر الملوّن', 't3', 2),
      aiaField('لون السطر الملوّن', aiaChips([['theme', '🎨 لون الثيم'], ['white', '⚪ أبيض']], O.t3col || 'theme', (k) => { O.t3col = k; aiaKitDirty(); aiaEditor(); })),
      !ph ? kin('نص الزر', O, 'cta') : null, !ph ? sw('إظهار الزر', '', O, 'btnOn') : null),
    grp('🔠 الأحجام',
      osl('السطر الكبير', 's1', 100, 40, 180), osl('السطر الثاني', 's2', 100, 40, 180), osl('السطر الملوّن', 's3', 100, 40, 180),
      osl(ph ? 'حجم الجوال' : 'الشعار', 'logo', 100, 30, 200), !ph && !qr ? osl('الأيقونات', 'ico', 100, 50, 160) : null,
      qr ? osl('الـQR', 'qr', 100, 50, 180) : null, !ph ? osl('الزر', 'btn', 100, 50, 160) : null),
    grp('↕️ المسافات',
      osl('ارفع كل المحتوى ↑ / نزّله ↓', 'lift', 0, -400, 400, 4, ''),
      !ph ? osl('الشعار ← السطر الكبير', 'g1', 120, 0, 400, 4, '') : null,
      osl('السطر الكبير ← الثاني', 'g2', 10, 0, 200, 2, ''),
      !ph ? osl(qr ? 'السطر الثاني ← الـQR' : 'السطر الثاني ← الأيقونات', 'g3', 20, 0, 200, 2, '') : null,
      osl(qr ? 'الـQR ← السطر الملوّن' : 'الأيقونات ← السطر الملوّن', 'g4', 10, 0, 200, 2, ''),
      !ph ? osl('السطر الملوّن ← الزر', 'g5', 14, 0, 200, 2, '') : null,
      osl('تعتيم الخلفية', 'shade', 35, 0, 90, 5)),
    !ph ? grp('🧩 الشعار والأيقونات',
      sw('شعار NOBLE فوق', '', O, 'logoOn'),
      !qr ? sw('الأيقونات الثلاث', 'تقدر تغيّر الإيموجي والكلمة لكل وحدة', O, 'icons') : null,
      ...(!qr && O.icons !== false ? [icRow(1, '📰', 'الخبر كامل'), icRow(2, '🔗', 'المصادر'), icRow(3, '🔔', 'إشعارات')] : [])) : null,
    ph ? grp('📱 الجوال', aiaField('مكان الجوال', aiaChips([['left', '⬅️ يسار'], ['right', '➡️ يمين']], O.phoneSide || 'left', (k) => { O.phoneSide = k; aiaKitDirty(); aiaEditor(); }))) : null,
    qr ? grp('🔳 الـQR',
      aiaField('مصدره', aiaChips([['gen', '🔗 من الرابط'], ['img', '🖼️ صورتي']], O.qrImg ? 'img' : 'gen', (k) => { if (k === 'gen') { O.qrImg = ''; aiaKitDirty(); aiaEditor(); } else toast('ارفع صورة الـQR تحت'); })),
      kin('الرابط (يتولّد منه الـQR)', O, 'link', true),
      up('صورة QR من عندك (PNG/JPG)', O, 'qrImg'),
      O.qrImg ? h('button', { type: 'button', class: 'btn sm', onclick: () => { O.qrImg = ''; aiaKitDirty(); aiaEditor(); } }, '🗑️ شيل صورتي وارجع للرابط') : null,
      !O.qrImg ? sw('شعار NOBLE في نص الـQR', '', O, 'qrMark') : null,
      h('p', { class: 'hint', text: 'لو رفعت صورتك تنعرض بدل الـQR المولّد. جرّب تمسحه بجوالك من المعاينة قبل النشر.' })) : null,
    (() => { const v0 = +O.secs || 5, lb = h('span', { text: `مدتها في الفيديو — ${aiaN(v0)} ثواني` }), r = h('input', { type: 'range', min: 2, max: 15, step: 1, value: v0 });
      r.addEventListener('input', () => { O.secs = +r.value; lb.textContent = `مدتها في الفيديو — ${aiaN(+r.value)} ثواني`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); })(),
    sw('تطلع للمستخدمين داخل التطبيق كمان', 'بدونه: تطلع في التصدير والفيديو بس', O, 'inApp'),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { const keep = { on: O.on, style: O.style, link: O.link, qrImg: O.qrImg };
      Object.keys(O).forEach((k) => delete O[k]); Object.assign(O, AISlides.DEF_KIT.outro, keep); aiaKitDirty(); aiaEditor(); } }, '↺ رجّع الأحجام والمسافات والنص الافتراضي'),
  ];
}

/* 1.21.12 — «ينطبق على»: الكل · يومي · أسبوعي · شهري · عاجل */
const AIA_KINDS = [['', '🌐 الكل'], ['daily', '📅 يومي'], ['weekly', '🗓️ أسبوعي'], ['monthly', '📆 شهري'], ['urgent', '⚡ عاجل']];
const AIA_ALT = {
  pill: { weekly: ['العدد {n}', 'الأسبوع {n}', 'أسبوع {n}', '#{n}', 'NOBLE · {n}'], daily: ['عدد اليوم', 'اليوم', 'نشرة اليوم', 'موجز اليوم', '⚡ اليوم'], monthly: ['عدد الشهر', 'الشهر', 'حصاد الشهر', 'موجز الشهر'], urgent: ['⚡ عاجل', 'عاجل', '🔴 الآن', 'خبر عاجل'] },
  kicker: { weekly: ['ملخص الأسبوع', 'حصاد الأسبوع', 'أبرز أخبار الأسبوع', 'أسبوعك في دقيقة', 'وش صار هالأسبوع؟'], daily: ['ملخص اليوم', 'أخبار اليوم', 'موجز اليوم', 'يومك في دقيقة', 'وش صار اليوم؟'], monthly: ['ملخص الشهر', 'حصاد الشهر', 'أبرز أحداث الشهر', 'شهرك في دقيقة'], urgent: ['عاجل', 'الآن', 'خبر مهم', 'لحظة بلحظة'] },
};
function aiaKindScope(SC, BK) {
  const K = AIA.kit, D = AISlides.KIND_DEF, custom = (k) => !!K.byKind?.[k] && Object.keys(K.byKind[k]).some((x) => K.byKind[k][x] != null && K.byKind[k][x] !== '');
  const kids = [aiaField('ينطبق على', h('div', { class: 'chips aia-kinds' }, ...AIA_KINDS.map(([k, l]) => h('button', { type: 'button', class: `chip${SC === k ? ' on' : ''}`, onclick: () => { AIA.kscope = k; aiaEditor(); } }, l, k && custom(k) ? h('b', { class: 'an-star', text: ' •' }) : null))))];
  if (!SC) {
    kids.push(h('p', { class: 'hint', text: `اللي تعدّله الحين ينطبق على كل الأنواع${AIA_KINDS.slice(1).some(([k]) => custom(k)) ? ' — ماعدا اللي عليها • (لها تخصيص)' : ''}.` }));
    if (AIA_KINDS.slice(1).some(([k]) => custom(k))) kids.push(h('button', { type: 'button', class: 'btn sm', onclick: async () => { if (!(await confirmSheet({ title: 'شيل كل التخصيصات', text: 'كل الأنواع ترجع تاخذ إعدادات «الكل».', ok: 'تمام' }))) return; K.byKind = {}; aiaKitDirty(); aiaEditor(); toast('✅ صار كل شي مثل «الكل»'); } }, '↺ خلّ كل الأنواع مثل «الكل»'));
    return h('div', { class: 'aia-scope' }, ...kids);
  }
  const name = AIA_KINDS.find((x) => x[0] === SC)[1];
  const txt = (key, label) => { const cur = BK[key] ?? '', ph = (K.labels?.[SC]?.[key]) || D[SC][key];
    const i = h('input', { class: 'input', value: cur, maxlength: 40, placeholder: ph }); i.addEventListener('input', () => { if (i.value.trim()) BK[key] = i.value; else delete BK[key]; aiaKitDirty(); });
    return h('div', { class: 'field' }, h('span', { text: label }), i, h('div', { class: 'chips aia-alts' }, h('small', { class: 'hint', text: 'بدائل:' }), ...(AIA_ALT[key][SC] || []).map((v) => h('button', { type: 'button', class: `chip${(BK[key] || ph) === v ? ' on' : ''}`, onclick: () => { BK[key] = v; aiaKitDirty(); aiaEditor(); } }, v.replace('{n}', '42'))))); };
  kids.push(
    h('p', { class: 'hint', text: `✏️ تعدّل ${name} لحاله — المعاينة فوق تعرضه. التوقيع والصفحة الأخيرة وشعار المصادر مشتركة للكل.` }),
    txt('pill', `النص فوق يمين ({n} = رقم العدد)`), txt('kicker', 'الكلمة فوق العنوان'),
    aiaField('شعار NOBLE فوق', aiaChips([['', '⚙️ مثل الكل'], ['on', '✅ ظاهر'], ['off', '🚫 مخفي']], BK.brand ? (BK.brand.on === false ? 'off' : 'on') : '', (k) => { if (!k) delete BK.brand; else BK.brand = { ...(BK.brand || {}), on: k === 'on' }; aiaKitDirty(); aiaEditor(); })),
    BK.brand && BK.brand.on !== false ? (() => { const v0 = Math.round((BK.brand.scale || K.brand.scale || 1) * 100), lb = h('span', { text: `حجم الشعار لـ${name} — ${aiaN(v0)}٪` }), r = h('input', { type: 'range', min: 50, max: 200, value: v0 });
      r.addEventListener('input', () => { BK.brand.scale = +r.value / 100; lb.textContent = `حجم الشعار لـ${name} — ${aiaN(+r.value)}٪`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); })() : null,
    BK.ui ? h('div', { class: 'aia-scope-on' }, h('b', { text: `🎚️ الشريط و«اسحب للمزيد» والعنوان والمسافات: خاصة بـ${name}` }),
      h('div', { class: 'aia-qa' },
        h('button', { type: 'button', class: 'btn sm', onclick: () => { delete BK.ui; aiaKitDirty(); aiaEditor(); toast(`${name} رجع مثل «الكل»`); } }, '↺ رجّعها مثل الكل'),
        h('button', { type: 'button', class: 'btn sm', onclick: async () => { if (!(await confirmSheet({ title: 'طبّق على الكل', text: `إعدادات ${name} تصير لكل الأنواع.`, ok: 'طبّق' }))) return; K.ui = { ...K.ui, ...BK.ui }; Object.values(K.byKind).forEach((x) => delete x.ui); aiaKitDirty(); AIA.kscope = ''; aiaEditor(); toast('✅ انطبقت على الكل'); } }, '⇉ طبّقها على الكل')))
      : h('div', { class: 'aia-scope-on off' }, h('span', { text: `الشريط و«اسحب للمزيد» والعنوان والمسافات: ${name} ياخذ إعدادات «الكل» — وأي تعديل تحت ينطبق على الكل لين تضغط «خصّص».` }),
        h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => { BK.ui = JSON.parse(JSON.stringify(K.ui)); aiaKitDirty(); aiaEditor(); } }, `✏️ خصّصها لـ${name}`)));
  return h('div', { class: 'aia-scope' }, ...kids);
}
function aiaKitPanel(P) {
  AIA.kit.ui = { ...AISlides.DEF_KIT.ui, ...(AIA.kit.ui || {}) };
  AIA.kit.outro = { ...AISlides.DEF_KIT.outro, ...(AIA.kit.outro || {}) };
  AIA.kit.ig = { ...AISlides.DEF_KIT.ig, ...(AIA.kit.ig || {}) }; AIA.kit.ig.bpos = AIA.kit.ig.bpos || {};
  // 1.21.12: «ينطبق على» — الكل أو نوع واحد (يومي/أسبوعي/شهري/عاجل). النوع اللي له تخصيص ياخذ نسخته، والباقي ياخذ «الكل»
  AIA.kit.byKind = AIA.kit.byKind || {};
  const SC = AIA.kscope || '', BK = SC ? (AIA.kit.byKind[SC] = AIA.kit.byKind[SC] || {}) : null;
  const B = AIA.kit.brand, G = AIA.kit.sig, U = SC && BK.ui ? BK.ui : AIA.kit.ui, O = AIA.kit.outro, E = AIA.ed;
  const sw = (label, sub, o, key, re = true) => { const i = h('input', { type: 'checkbox', checked: !!o[key] }); i.addEventListener('change', () => { o[key] = i.checked; aiaKitDirty(); if (re) aiaEditor(); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); };
  const kin = (label, o, key, ltr) => { const i = h('input', { class: `input${ltr ? ' ltr' : ''}`, value: o[key] || '', maxlength: 80 }); if (ltr) i.dir = 'ltr'; i.addEventListener('input', () => { o[key] = i.value; aiaKitDirty(); }); return aiaField(label, i); };
  const range = (label, o, key, min, max) => { const i = h('input', { type: 'range', min, max, value: Math.round((o[key] || 1) * 100) }); const lb = h('span', { text: `${label} — ${aiaN(Math.round((o[key] || 1) * 100))}٪` }); i.addEventListener('input', () => { o[key] = i.value / 100; lb.textContent = `${label} — ${aiaN(i.value)}٪`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, i); };
  const up = (label, o, key, accept = 'image/*') => h('div', { class: 'field' }, h('span', { text: label }), h('button', { type: 'button', class: 'aia-drop sm', onclick: () => aiaPickFile(accept, async (f) => { o[key] = URL.createObjectURL(f); aiaEditor(); try { o[key] = await aiaUpload(f); aiaKitDirty(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }) },
    o[key] && !/^img\//.test(o[key]) ? '✅ مرفوع · بدّل' : (key === 'logo' ? 'شعار NOBLE · ارفع PNG' : key === 'avatar' ? '✅ صورتك (من الـPSD) · بدّل' : '✅ من ملف PSD حقك · بدّل')));
  const pl = h('select', { class: 'input select' }, ...[['ig', 'إنستقرام'], ['x', 'X'], ['tt', 'تيك توك'], ['sc', 'سناب'], ['none', 'بدون أيقونة']].map(([k, n]) => h('option', { value: k, text: n, selected: G.platform === k })));
  pl.addEventListener('change', () => { G.platform = pl.value; aiaKitDirty(); });
  const acc = h('input', { type: 'color', value: G.accent || '#F5A623', class: 'aia-color' });
  acc.addEventListener('input', () => { G.accent = acc.value; aiaKitDirty(); });
  P.replaceChildren(...[h('h3', { text: '🪪 هويتي' }), h('p', { class: 'hint', text: 'تنحفظ تلقائياً. اختر «الكل» أو نوع معيّن تعدّله لحاله.' }),
    aiaKindScope(SC, BK),
    sw('الشعار فوق السلايد', '', B, 'on'),
    B.on ? h('div', { class: 'two-col' }, up('صورة الشعار', B, 'logo'), kin('نص بجانبه (فاضي = بدون)', B, 'text', true)) : null,
    B.on ? range('حجم الشعار', B, 'scale', 50, 200) : null,
    sw('شريط التوقيع', 'صورتك، اسمك، حسابك، الحقوق', G, 'on'),
    ...(G.on ? [
      aiaField('مصدر الشريط', aiaChips([['data', '✏️ بيانات أعدّلها'], ['png', '🎨 تصميمي PNG']], G.mode, (k) => { G.mode = k; aiaKitDirty(); aiaEditor(); })),
      ...(G.mode === 'data' ? [
        h('div', { class: 'two-col' }, up('صورتك', G, 'avatar'), aiaField('لون الأيقونة والإطار', acc)),
        h('div', { class: 'two-col' }, kin('الاسم', G, 'name', true), kin('الحساب', G, 'handle', true)),
        aiaField('المنصة', pl), kin('السطر الأول (يمين)', G, 'line1', true), kin('السطر الثاني (يمين)', G, 'line2', true)]
        : [up('الشريط PNG (شفاف بعرض 1080 من الفوتوشوب)', G, 'png', 'image/png,image/webp'), h('p', { class: 'hint', text: 'الشريط الحالي طالع من ملف الـPSD اللي أرسلته. تعدّل في الفوتوشوب وتصدّره PNG شفاف وترفعه هنا.' })]),
      range('حجم الشريط', G, 'scale', 50, 150),
      aiaField('المكان (أو اسحبه على المعاينة)', aiaChips([['bottom', '⬇️ تحت'], ['top', '⬆️ فوق'], ['center', '↔️ توسيط']], '', (k) => { AISlides.sigPreset(AIA.kit, aiaSizeH(E.size), k); aiaKitDirty(); })),
      aiaField('يظهر في', aiaChips([['all', 'كل السلايدات'], ['news', 'الأخبار فقط'], ['cover', 'الغلاف فقط'], ['last', 'آخر سلايد']], G.where, (k) => { G.where = k; aiaKitDirty(); aiaEditor(); })),
      sw('يظهر للمستخدمين داخل التطبيق كمان', 'بدونه: يطلع في التصدير لحساباتك فقط، والتطبيق يعرض هوية NOBLE', G, 'inApp', false)] : []),
    // 1.21.1: عناصر السلايد
    // 1.21.9: «🏁 الصفحة الأخيرة» — خاتمة بعد آخر خبر
    // 1.21.9: «🏁 الصفحة الأخيرة» — كل شي فيها يتعدّل (النص، الأحجام، المسافات، الأيقونات، الـQR)
    h('h3', { text: '🏁 الصفحة الأخيرة' }),
    ...aiaOutroCtl(O, E, sw, kin, up),
    ...aiaIgCtl(AIA.kit.ig, E, sw),
    h('h3', { text: '📐 عناصر السلايد' }),
    aiaPresets('ui', U, [], 5),
    aiaField('الأرقام', aiaChips([['latn', 'English 1 2 3'], ['arab', 'عربي ١ ٢ ٣']], U.digits, (k) => { U.digits = k; aiaKitDirty(); aiaEditor(); })),
    sw('رقم السلايد فوق (3 / 6)', '', U, 'counter'),
    h('h3', { class: 'aia-sub', text: '🎚️ الشريط المتحرك تحت + «اسحب للمزيد»' }),
    sw('شريط التقدّم تحت', 'الشرط الصغيرة اللي توضّح وين أنت', U, 'progress'),
    U.progress ? aiaField('اتجاه الشريط', aiaChips([['rtl', '⬅️ من اليمين لليسار'], ['ltr', '➡️ من اليسار لليمين']], U.dir, (k) => { U.dir = k; aiaKitDirty(); aiaEditor(); })) : null,
    U.progress ? aiaField('مكان الشريط', aiaChips([['auto', 'تلقائي'], ['right', '➡️ يمين'], ['center', '⏺️ وسط'], ['left', '⬅️ يسار']], U.barAlign || 'auto', (k) => { U.barAlign = k; aiaKitDirty(); aiaEditor(); })) : null,
    ...(U.progress ? [['barUp', 'ارفع الشريط لفوق', 0, -60, 600], ['barX', 'زحزحه يمين ↔ يسار', 0, -400, 400]].map(([k, l, d, mn, mx]) => {
      const v0 = Number.isFinite(+U[k]) ? +U[k] : d, lb = h('span', { text: `${l} — ${aiaN(v0)}` }), r = h('input', { type: 'range', min: mn, max: mx, step: 2, value: v0, dir: k === 'barX' ? 'ltr' : null });
      r.addEventListener('input', () => { U[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); }) : []),
    U.progress ? h('button', { type: 'button', class: 'btn sm', onclick: () => { U.barUp = 0; U.barX = 0; U.barAlign = 'auto'; aiaKitDirty(); aiaEditor(); } }, '↺ رجّع مكان الشريط') : null,
    U.progress ? h('p', { class: 'hint', text: 'اتجاه الشريط يحدد كمان اتجاه أسهم «اسحب للمزيد» (‹‹‹ أو ›››)، و«اسحب للمزيد» يمشي مع الشريط وين ما تحطه.' }) : null,
    sw('«اسحب للمزيد» تحت', 'يطلع في كل سلايد إلا الأخير', U, 'swipe'),
    U.swipe ? kin('نص السحب', U, 'swipeText') : null,
    // 1.21.9: مكان «اسحب للمزيد» من الشريط اللي تحت + المسافة بينهم
    U.swipe ? h('div', { class: 'field' }, h('span', { text: 'مكانه من الشريط' }), h('div', { class: 'chips' }, ...[['auto', 'تلقائي'], ['above', '⬆️ فوق'], ['below', '⬇️ تحت'], ['right', '➡️ يمين'], ['left', '⬅️ يسار']].map(([v, l]) =>
      h('button', { type: 'button', class: `chip${(U.swipePos || 'auto') === v ? ' on' : ''}`, onclick: (e) => { U.swipePos = v; [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); aiaKitDirty(); } }, l)))) : null,
    U.swipe ? (() => { const v0 = Number.isFinite(+U.swipeGap) ? +U.swipeGap : 14, lb = h('span', { text: `المسافة بينه وبين الشريط — ${aiaN(v0)}` }), r = h('input', { type: 'range', min: 0, max: 120, step: 2, value: v0 });
      r.addEventListener('input', () => { U.swipeGap = +r.value; lb.textContent = `المسافة بينه وبين الشريط — ${aiaN(+r.value)}`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); })() : null,
    // 1.21.19: تحكم كامل في «اسحب للمزيد» — الحجم والمسافات والمكان
    ...(U.swipe ? [['swipeSize', 'حجم الكلام', 22, 14, 48, 1, ''], ['swipeArrGap', 'المسافة بين الكلام والأسهم ‹‹‹', 28, 0, 120, 2, ''], ['swipeArrStep', 'المسافة بين الأسهم نفسها', 16, 8, 40, 1, ''], ['swipeArrY', 'ارفع/نزّل الأسهم', 0, -30, 30, 1, ''], ['swipeOp', 'وضوح الكلام', 55, 15, 100, 5, '٪'], ['swipeX', 'زحزحه يمين ↔ يسار', 0, -400, 400, 2, ''], ['swipeY', 'ارفعه لفوق ↕', 0, -200, 200, 2, '']].map(([k, l, d, mn, mx, st, u]) => {
      const v0 = Number.isFinite(+U[k]) && U[k] !== '' && U[k] != null ? +U[k] : d, lb = h('span', { text: `${l} — ${aiaN(v0)}${u}` }), r = h('input', { type: 'range', min: mn, max: mx, step: st, value: v0, dir: k === 'swipeX' ? 'ltr' : null });
      r.addEventListener('input', () => { U[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}${u}`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); }) : []),
    U.swipe ? sw('🔁 اقلب اتجاه الأسهم ‹‹‹ ↔ ›››', 'الشريط يبقى مكانه — الأسهم بس تنعكس', U, 'arrFlip') : null,
    U.swipe ? h('button', { type: 'button', class: 'btn sm', onclick: () => { ['swipeSize', 'swipeArrGap', 'swipeArrStep', 'swipeArrY', 'swipeOp', 'swipeX', 'swipeY'].forEach((k) => delete U[k]); U.swipeGap = 14; U.swipePos = 'auto'; aiaKitDirty(); aiaEditor(); } }, '↺ رجّع «اسحب للمزيد» الافتراضي') : null,
    sw('اسم الشركة فوق العنوان', 'مثل «NVIDIA» مع الشعار', U, 'company'),
    // 1.21.9: خبر بدون صورة أو فيديو — وش يطلع مكانها
    h('h3', { class: 'aia-sub', text: '🖼️ خبر بدون صورة أو فيديو' }),
    aiaField('وش يطلع مكانها', aiaChips([['logo', '🏢 شعار الخبر'], ['name', '🔤 اسم الشركة'], ['brand', '✦ شعار NOBLE'], ['glow', '🌫️ توهج بس']], U.ph || 'logo', (k) => { U.ph = k; aiaKitDirty(); aiaEditor(); })),
    (U.ph || 'logo') === 'logo' ? sw('اسم الشركة تحت الشعار', '', U, 'phName') : null,
    ['logo', 'name', 'brand'].includes(U.ph || 'logo') ? (() => { const v0 = +U.phSize || 100, lb = h('span', { text: `الحجم — ${aiaN(v0)}٪` }), r = h('input', { type: 'range', min: 50, max: 160, step: 5, value: v0 });
      r.addEventListener('input', () => { U.phSize = +r.value; lb.textContent = `الحجم — ${aiaN(+r.value)}٪`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); })() : null,
    aiaField('🎞️ الخلفية المتحركة (الافتراضي لكل الأخبار)', aiaChips(AISlides.PH_FX, U.phFx || 'glow', (k) => { U.phFx = k; aiaKitDirty(); aiaEditor(); })),
    ...((U.phFx || 'glow') !== 'glow' ? [['phFxSpeed', 'سرعة الحركة', 100, 0, 300], ['phFxOp', 'وضوحها', 100, 10, 100]].map(([k, l, d, mn, mx]) => { const v0 = Number.isFinite(+U[k]) && U[k] !== '' ? +U[k] : d, lb = h('span', { text: `${l} — ${aiaN(v0)}٪` }), r = h('input', { type: 'range', min: mn, max: mx, step: 5, value: v0 });
      r.addEventListener('input', () => { U[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}٪`; aiaKitDirty(); }); return h('label', { class: 'field' }, lb, r); }) : []),
    h('p', { class: 'hint', text: 'تقدر تغيّرها لكل خبر لحاله من «🏷️ شعار المصدر». الحروف تاخذ اسم الشركة نفسه.' }),
    h('p', { class: 'hint', text: 'كلمة «ارفع صورة…» تطلع لك أنت بس في المعاينة هنا — المستخدمين والتصدير يشوفون الشعار.' }),
    sw('«المصدر» على الصورة', '', U, 'source'),
    // 1.21.3: المسافات في الغلاف — بين «ملخص الأسبوع» والعنوان، وبين العنوان والتاريخ
    // 1.21.28: 🔢 رقم العدد كبير وباهت ورا الغلاف
    h('h3', { text: '🔢 رقم العدد ورا الغلاف' }),
    sw('رقم العدد كبير وباهت في الخلفية', 'مثل «48» — يعطي الغلاف عمق ويميّز كل أسبوع', U, 'bigNum'),
    ...(U.bigNum ? [['bnSize', 'حجم الرقم', 820, 300, 1400], ['bnOp', 'وضوحه ٪', 10, 2, 40], ['bnX', 'يمين ↔ يسار', 0, -600, 600], ['bnY', 'فوق ↕ تحت', 0, -800, 800]].map(([k, l, d, mn, mx]) => {
      const v = Number.isFinite(+U[k]) ? +U[k] : d, lb = h('span', { text: `${l} — ${aiaN(v)}` });
      const r = h('input', { type: 'range', min: mn, max: mx, step: 2, value: v, dir: k === 'bnX' ? 'ltr' : null });
      r.addEventListener('input', () => { U[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}`; aiaKitDirty(); if (AIA.ed) AIA.ed.cur = 0; });
      return h('label', { class: 'field' }, lb, r);
    }) : []),
    ...(U.bigNum ? [
      aiaField('النص ورا (فاضي = رقم العدد)', (() => { const i = h('input', { class: 'input', maxlength: 12, value: U.bnText || '', placeholder: 'مثلاً: 48 أو AI' }); i.addEventListener('input', () => { U.bnText = i.value; aiaKitDirty(); }); return i; })()),
      aiaField('لونه', aiaChips([['theme', 'لون الثيم'], ['c2', 'اللون الثاني'], ['white', 'أبيض'], ['gold', 'ذهبي']], U.bnColor || 'theme', (k) => { U.bnColor = k; aiaKitDirty(); aiaEditor(); })),
      aiaField('شكله', aiaChips([['fill', 'معبّى'], ['outline', 'إطار بس']], U.bnStyle || 'fill', (k) => { U.bnStyle = k; aiaKitDirty(); aiaEditor(); })),
    ] : []),
    // 1.21.28: 📐 الإطار — حجم وهامش الشريط العلوي والسفلي
    ...aiaFrameCtl(U, 'fr', '📐 الإطار — الشعار والرقم فوق · التوقيع والحقوق و«اسحب للمزيد» تحت'),
    h('h3', { text: '🔤 العنوان والمسافات في الغلاف' }),
    h('div', { class: 'field' }, h('span', { text: 'سماكة الخط' }), h('div', { class: 'chips' }, ...[['700', 'عريض'], ['400', 'عادي']].map(([v, l]) =>
      h('button', { type: 'button', class: `chip${String(U.tWeight || '700') === v ? ' on' : ''}`, onclick: (e) => { U.tWeight = v; [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); aiaKitDirty(); if (AIA.ed) AIA.ed.cur = 0; } }, l)))),
    ...[['tSize', 'حجم العنوان', 96, 56, 140], ['tLine', 'المسافة بين أسطر العنوان', 112, 60, 200], ['tLines', 'أقصى عدد أسطر', 3, 1, 4], ['lift', 'ارفع الكلام كله لفوق', 0, 0, 500], ['dSize', 'حجم التاريخ', 32, 20, 56],
      ['gapKick', 'بين «ملخص…» والعنوان', 60, 10, 200], ['gapDate', 'بين العنوان والتاريخ', 76, 30, 200]].map(([k, l, d, mn, mx]) => {
      const v = Number.isFinite(+U[k]) ? +U[k] : d, lb = h('span', { text: `${l} — ${aiaN(v)}` });
      const r = h('input', { type: 'range', min: mn, max: mx, step: mx - mn <= 10 ? 1 : 2, value: v });
      r.addEventListener('input', () => { U[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}`; aiaKitDirty(); if (AIA.ed) AIA.ed.cur = 0; });
      return h('label', { class: 'field' }, lb, r);
    }),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { Object.assign(U, { gapKick: 60, gapDate: 76, tSize: 96, tLine: 112, tLines: 3, lift: 0, dSize: 32, tWeight: '700' }); aiaKitDirty(); aiaEditor(); } }, '↺ رجّع العنوان والمسافات الافتراضية'),
    // 1.21.3: ذيل كابشن «📸 انشر في إنستقرام» (العنوان والأخبار تنكتب تلقائياً فوقه)
    h('h3', { text: '📸 كابشن إنستقرام' }),
    (() => { const t = h('textarea', { class: 'input', rows: 5, placeholder: '📲 التفاصيل كاملة بالفيديو في تطبيق NOBLE — الرابط في البايو\n#الذكاء_الاصطناعي #تقنية #AI #NOBLE\n@noble_designer1' }); t.value = U.igTail || ''; t.addEventListener('input', () => { U.igTail = t.value; aiaKitDirty(); });
      return aiaField('آخر الكابشن: دعوة + هاشتاقات + حسابك (فاضي = الافتراضي)', t); })(),
    h('p', { class: 'hint', text: 'الكابشن يتكوّن تلقائياً: عنوان العدد + التاريخ + أهم الأخبار مرقّمة + هذا النص. ينسخ لحاله لما يضغط «📸 انشر في إنستقرام»، وفي إنستقرام يلصقه.' }),
    h('p', { class: 'hint', text: '📐 كل مقاس (منشور، مربع، ٣:٤، ستوري) يحفظ مكان الشعار والتوقيع لحاله. في الستوري يطلع خط أحمر لمنطقة واجهة إنستقرام — ما يطلع في التصدير.' })].filter(Boolean));
}

/* حفظ / نشر / حذف */
function aiaClean(issue) {
  const pending = [issue.look?.cover, issue.look?.music, issue.look?.icon, ...issue.slides.map((s) => s.media)].some((m) => m?.local) || issue.slides.some((s) => /^blob:/.test(s.logo || ''));
  if (pending) throw new Error('استنى لين يخلص رفع الملفات');
  return { id: issue.id, kind: issue.kind, week: issue.week, title: issue.title, kicker: issue.kicker, date_label: issue.date_label, look: issue.look, cover_url: issue.cover_url || '',
    slides: issue.slides.map((s) => ({ company: s.company || '', initial: s.initial || '', logo: s.logo || '', head: s.head || '', body: s.body || '', source: s.source || '', url: s.url || '', tier: s.tier || '', news_id: s.news_id || null,
      media: s.media ? { url: s.media.url, kind: s.media.kind, name: s.media.name || '' } : null, trim: s.trim || [0, 0], rights: !!s.rights, video: s.video || null, opt: s.opt && Object.keys(s.opt).length ? s.opt : null, mark: s.mark && Object.keys(s.mark).length ? s.mark : null, ...Object.fromEntries(['mfit', 'mbg', 'mzoom', 'mpx', 'mpy', 'kb'].filter((k) => s[k] != null).map((k) => [k, s[k]])) })) };
}
async function aiaSave(msg) {
  const E = AIA.ed, issue = E.issue;
  try {
    await Cloud.admin.aiSave(aiaClean(issue)); E.dirty = false;
    const k = AIA.list.findIndex((x) => x.id === issue.id); if (k >= 0) AIA.list[k] = JSON.parse(JSON.stringify(issue));
    if (msg) { aiaStatus('✅ انحفظ'); toast('انحفظ ✓', { type: 'success' }); }
    return true;
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); return false; }
}
async function aiaPublish(on) {
  const E = AIA.ed, issue = E.issue;
  if (!on) {
    if (!(await confirmSheet({ title: 'إخفاء العدد', text: 'يختفي من التطبيق ومن «اكتشف».', ok: 'إخفاء' }))) return;
    try { await Cloud.admin.aiSet(issue.id, 'draft'); issue.status = 'draft'; toast('انخفى'); aiaEditor(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    return;
  }
  const bad = issue.slides.filter((s) => s.media?.kind === 'video' && !s.rights).length;
  if (bad) return toast(`⚠️ أكّد حقوق المقطع في ${aiaN(bad)} سلايد قبل النشر`, { type: 'error' });
  if (!issue.slides.length) return toast('أضف خبر واحد على الأقل');
  let pin = '7';
  const disc = h('input', { type: 'checkbox', checked: true });
  const pinSel = h('select', { class: 'input select' }, ...[['0', 'بدون تثبيت'], ['1', 'يوم'], ['3', '٣ أيام'], ['7', 'أسبوع']].map(([v, l]) => h('option', { value: v, text: l, selected: v === pin })));
  pinSel.addEventListener('change', () => (pin = pinSel.value));
  // 1.21.13: ⏰ انشر الحين أو جدوله لوقت تختاره + 🔔 نبّه المستخدمين
  let mode = 'now';
  const pad = (x) => String(x).padStart(2, '0'), d0 = new Date(Date.now() + 864e5); d0.setHours(8, 0, 0, 0);
  const whenIn = h('input', { type: 'datetime-local', class: 'input ltr', dir: 'ltr', value: `${d0.getFullYear()}-${pad(d0.getMonth() + 1)}-${pad(d0.getDate())}T08:00`, min: new Date(Date.now() - new Date().getTimezoneOffset() * 6e4).toISOString().slice(0, 16) });
  const whenBox = h('div', { hidden: true }, aiaField('⏰ متى ينتشر (بتوقيت جوالك)', whenIn),
    h('div', { class: 'chips' }, ...[['بكرة ٨ص', 1, 8], ['بكرة ١٢م', 1, 12], ['بكرة ٨م', 1, 20], ['بعد ساعة', 0, -1]].map(([l, dd, hh]) => h('button', { type: 'button', class: 'chip', onclick: () => { const x = new Date(); if (hh < 0) x.setTime(Date.now() + 36e5); else { x.setDate(x.getDate() + dd); x.setHours(hh, 0, 0, 0); } whenIn.value = `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}T${pad(x.getHours())}:${pad(x.getMinutes())}`; } }, l))),
    h('p', { class: 'hint', text: 'نشيّك كل ٥ دقايق — ممكن يتأخر لين ٥ دقايق عن الوقت بالضبط. لو نشرته بيدك قبلها تنلغي الجدولة.' }));
  const ntf = h('input', { type: 'checkbox', checked: true });
  const cmtSw = h('input', { type: 'checkbox', checked: issue.look?.cmt !== false }); // 1.21.26
  // 🖼️ 1.21.22: صورة الإشعار الكبيرة لهذا العدد — تلقائي (عنوانه + نوعه + شعارك) / صورتك / بدون
  const KL = { daily: 'عدد اليوم', weekly: 'عدد الأسبوع', monthly: 'عدد الشهر', urgent: 'عاجل' };
  let nimg = 'auto', nCv = null;
  const nPv = h('div', { class: 'pi-pubpv' }), nSt = h('small', { class: 'hint' });
  const nAuto = () => (typeof PushImg !== 'undefined' ? PushImg.banner({ kind: 'issue', label: '⚡ ' + (KL[issue.kind] || 'عاجل'), title: KL[issue.kind] || 'عدد جديد', sub: issue.title || 'أهم الأخبار في دقيقة' }) : null);
  const nPaint = async () => {
    if (typeof PushImg === 'undefined') return nPv.replaceChildren();
    if (nimg === 'auto' && !nCv) nCv = await nAuto();
    const src = nimg === 'auto' ? nCv?.toDataURL('image/jpeg', .7) : nimg === 'none' ? '' : nimg;
    nPv.replaceChildren(PushImg.preview(src, `⚡ ${KL[issue.kind] || 'عدد جديد'} نزل في NOBLE عاجل`, `${issue.title || ''} — ${issue.slides.length} أخبار`));
  };
  const nBox = h('div', { class: 'pi-pub' },
    aiaField('🖼️ صورة الإشعار', aiaChips([['auto', '✨ تلقائي'], ['up', '⬆️ صورتي'], ['none', 'بدون']], 'auto', (k) => {
      if (k === 'up') { aiaPickFile('image/*', async (f) => { nSt.textContent = '⏳ رفع…'; try { nimg = await PushImg.upload(await PushImg.fromFile(f)); nSt.textContent = '✓ انرفعت'; nPaint(); } catch (x) { nSt.textContent = Cloud.msg(x); } }); return; }
      nimg = k; nPaint();
    })), nSt, nPv,
    h('small', { class: 'hint', text: 'تطلع كبيرة لما المستخدم يسحب الإشعار. الشكل يختلف شوي حسب الجوال.' }));
  ntf.addEventListener('change', () => (nBox.hidden = !ntf.checked));
  setTimeout(nPaint, 50);
  mkSheet('🚀 نشر العدد', [
    h('p', { class: 'hint', text: 'يظهر في قسم «⚡ NOBLE عاجل» بالتطبيق، والمستخدم يقدر ينزّله كاروسيل أو ستوري ويشاركه.' }),
    aiaField('متى', aiaChips([['now', '🚀 الحين'], ['later', '⏰ جدوله']], mode, (k) => { mode = k; whenBox.hidden = k !== 'later'; const b = document.querySelector('#mk-sheet .aia-go-pub'); if (b) b.textContent = k === 'later' ? '⏰ جدول' : 'نشر'; })),
    whenBox,
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: '🔔 نبّه المستخدمين' }), h('small', { text: 'إشعار فوري «⚡ عدد جديد نزل» لكل اللي مفعلين الإشعارات' })), h('span', { class: 'switch' }, ntf, h('span', { class: 'track' }))),
    nBox,
    aiaField('📌 تثبيت كمهم في الرئيسية', pinSel),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: '💬 التعليقات على هذا العدد' }), h('small', { text: 'زر «💬» في العارض + «اكتب رأيك» في الصفحة الأخيرة' })), h('span', { class: 'switch' }, cmtSw, h('span', { class: 'track' }))),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: '🧭 منشور في «اكتشف»' }), h('small', { text: 'بغلاف العدد — المستخدمين يعجبون ويعلّقون ويشاركون' })), h('span', { class: 'switch' }, disc, h('span', { class: 'track' })))],
  [h('button', { type: 'button', class: 'btn btn-primary aia-go-pub', onclick: async (e) => {
    const b = e.currentTarget, later = mode === 'later', at = later ? new Date(whenIn.value) : null;
    if (later && (!whenIn.value || isNaN(at) || at.getTime() < Date.now() + 60e3)) return toast('اختر وقت جاي (بعد دقيقة على الأقل)', { type: 'error' });
    b.disabled = true; b.textContent = '⏳ تجهيز الغلاف…';
    try {
      await AISlides.fonts();
      const blob = await AISlides.still(issue, 0, 1350, { kit: AIA.kit }, 'image/jpeg', 3);
      issue.cover_url = await Cloud.admin.designUpload(new File([blob], 'cover.jpg', { type: 'image/jpeg' }), 'ai');
      // 🖼️ صورة الإشعار تنحفظ مع العدد (حتى المجدول — الـcron ياخذها من هنا)
      if (ntf.checked && typeof PushImg !== 'undefined') {
        b.textContent = '⏳ صورة الإشعار…';
        issue.look = issue.look || {};
        try { issue.look.notifImg = nimg === 'none' ? 'none' : nimg === 'auto' ? await PushImg.upload(nCv || (nCv = await nAuto())) : nimg; } catch { delete issue.look.notifImg; }
      }
      issue.look = issue.look || {}; if (cmtSw.checked) delete issue.look.cmt; else issue.look.cmt = false;
      if (!(await aiaSave(false))) throw new Error('ما انحفظ');
      if (later) {
        const r = await Cloud.admin.aiSchedulePub(issue.id, at.toISOString(), Number(pin), disc.checked, ntf.checked);
        Object.assign(issue, r || {});
      } else {
        const r = await Cloud.admin.aiSet(issue.id, 'published', Number(pin), disc.checked);
        Object.assign(issue, r || {}, { status: 'published', publish_at: null });
        if (ntf.checked && Cloud.admin.pushSend) Cloud.admin.pushSend({ kind: 'issue', id: issue.id }).then((x) => x?.sent != null && toast(`🔔 وصل الإشعار لـ${aiaN(x.sent)} جهاز`)).catch((x) => toast('ما انرسل الإشعار: ' + Cloud.msg(x), { type: 'error' }));
      }
      const k = AIA.list.findIndex((x) => x.id === issue.id); if (k >= 0) AIA.list[k] = JSON.parse(JSON.stringify(issue));
      closeSheet($('#mk-sheet')); toast(later ? `⏰ انجدول — ينتشر ${aiaWhen(issue.publish_at)}` : '🚀 انتشر العدد', { type: 'success' }); aiaEditor();
    } catch (er) { toast(/admin_ai_schedule_pub|function|schema cache/i.test(Cloud.msg(er)) ? 'الصق ملف update-1.21.13.sql في Supabase أول' : Cloud.msg(er), { type: 'error' }); b.disabled = false; b.textContent = later ? '⏰ جدول' : 'نشر'; }
  } }, 'نشر')]);
}
function aiaWhen(t) { const d = new Date(t); if (isNaN(d)) return ''; const day = d.toDateString() === new Date().toDateString() ? 'اليوم' : d.toDateString() === new Date(Date.now() + 864e5).toDateString() ? 'بكرة' : d.toLocaleDateString('ar', { weekday: 'long', day: 'numeric', month: 'short' });
  return `${day} ${d.toLocaleTimeString('ar', { hour: 'numeric', minute: '2-digit' })}`; }
async function aiaUnsched() {
  const issue = AIA.ed.issue;
  try { const r = await Cloud.admin.aiSchedulePub(issue.id, null, null, true, true); Object.assign(issue, r || {}, { publish_at: null }); const k = AIA.list.findIndex((x) => x.id === issue.id); if (k >= 0) AIA.list[k].publish_at = null; toast('انلغت الجدولة — رجع مسودة'); aiaEditor(); }
  catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
async function aiaDelete() {
  const issue = AIA.ed.issue;
  if (!(await confirmSheet({ title: 'حذف العدد', text: 'ينحذف العدد ومنشوره في «اكتشف» وملفاته من التخزين نهائياً.', ok: 'حذف' }))) return;
  try {
    const d = await Cloud.admin.aiDelete(issue.id);
    const urls = [d?.cover, d?.look?.cover?.url, ...(d?.slides || []).flatMap((s) => [s.media?.url, s.logo])].filter((u) => /\/designs\/ai\//.test(u || ''));
    if (urls.length) await Cloud.admin.storageRemove(urls).catch(() => 0);
    AIA.list = AIA.list.filter((x) => x.id !== issue.id); toast('انحذف'); aiaHome();
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

/* 1.21.3 — «📸 انشر في إنستقرام» (للإدارة فقط، مو للمستخدمين): الكاروسيل كامل + كابشن ملخص ينسخ تلقائياً (إنستقرام ما يسمح يتعبّى الكابشن من برا — تلصقه بضغطة) */
function aiaCaption(issue) {
  const U = AISlides.kitOf(AIA.kit).ui || {}, n = (x) => String(x ?? '').replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
  const head = issue.kind === 'urgent' ? `⚡ ${issue.title}` : issue.kind === 'weekly' ? `🗞️ ملخص الأسبوع ${n(issue.week)} في الذكاء الاصطناعي` : `🗞️ ${issue.title || 'ملخص الذكاء الاصطناعي'}`;
  const lines = (issue.slides || []).filter((s) => s?.head).slice(0, 10).map((s, i) => `${n(i + 1)}. ${n(s.head)}${s.company ? ` — ${s.company}` : ''}`);
  const tail = U.igTail || '📲 التفاصيل كاملة بالفيديو في تطبيق NOBLE — الرابط في البايو\n💾 احفظ المنشور · 🔁 شاركه مع اللي يهمه\n\n#الذكاء_الاصطناعي #تقنية #AI #NOBLE\n@noble_designer1';
  return [head, issue.date_label ? `📅 ${n(issue.date_label)}` : '', '', ...lines, '', tail].filter((x, i, a) => !(x === '' && a[i - 1] === '')).join('\n').replace(/\n{3,}/g, '\n\n').trim();
}
async function aiaCopy(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch { /* نجرب الطريقة القديمة */ }
  try { const ta = h('textarea', { style: { position: 'fixed', opacity: 0 } }); ta.value = t; document.body.append(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; } catch { return false; }
}
async function aiaInsta(issue, mode = 'video') {
  const E = AIA.ed; const was = E?.playing; if (E) E.playing = false;
  const cap = aiaCaption(issue);
  const copied = await aiaCopy(cap); // أول شي قبل التجهيز (الجوال يسمح بالنسخ بس بعد الضغط مباشرة)
  toast(`${copied ? '✅ الكابشن منسوخ — ' : ''}⏳ نجهّز ${mode === 'video' ? 'الموشن (ياخذ ثواني لكل سلايد)' : 'صور الكاروسيل'}…`, { duration: 5000 });
  try {
    await aiaShareFiles(await (mode === 'video' ? aiaFilesVideo(issue, 1350) : aiaFiles(issue, 1350)), issue.title);
    if (copied) toast('في إنستقرام: اختر «منشور»، وفي خانة الكابشن اضغط مطوّل ← لصق 📋', { type: 'success', duration: 7000 });
    else aiaCapSheet(cap);
  } catch (e) { if (e?.name !== 'AbortError') toast('ما قدرنا نجهّزها: ' + (e?.message || e), { type: 'error' }); }
  if (E) { E.playing = was; E.t0 = performance.now(); }
}
function aiaCapSheet(cap) {
  const ov = h('div', { class: 'pp-ov ain-cap' },
    h('button', { type: 'button', class: 'pp-x', onclick: () => ov.remove() }, '✕'),
    h('div', { class: 'ain-cap-in' }, h('b', { text: 'الكابشن — انسخه والصقه في إنستقرام' }), h('textarea', { class: 'input', rows: 14, readonly: true }, cap),
      h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => { if (await aiaCopy(cap)) { toast('✅ انسخ'); ov.remove(); } } }, '📋 نسخ')));
  document.body.append(ov);
}
async function aiaFiles(issue, h0) {
  await AISlides.fonts();
  const base = `NOBLE-${issue.kind === 'weekly' ? 'week-' + issue.week : issue.kind}-instagram`, out = [];
  for (let i = 0; i < AISlides.total(issue, AIA.kit); i++) {
    aiaStatus(`📸 نجهّز الصورة ${aiaN(i + 1)} من ${aiaN(AISlides.total(issue, AIA.kit))}…`);
    const b = await AISlides.still(issue, i, h0, { kit: AIA.kit }, 'image/jpeg', 3);
    out.push(new File([b], `${base}-${String(i + 1).padStart(2, '0')}.jpg`, { type: 'image/jpeg' }));
  }
  aiaStatus('✅ الصور جاهزة');
  return out;
}
/* موشن متحرك نفس التطبيق: كل سلايد فيديو MP4 (كاروسيل فيديوهات في إنستقرام) */
async function aiaFilesVideo(issue, h0) {
  await AISlides.fonts();
  const type = AISlides.bestType(); if (!type) throw new Error('الجوال ما يدعم تسجيل الفيديو — جرّب «صور»');
  const base = `NOBLE-${issue.kind === 'weekly' ? 'week-' + issue.week : issue.kind}-instagram`, out = [], n = AISlides.total(issue, AIA.kit);
  for (let i = 0; i < n; i++) {
    const r = await AISlides.record(issue, i, h0, { kit: AIA.kit }, (p) => aiaStatus(`🎬 موشن السلايد ${aiaN(i + 1)} من ${aiaN(n)} — ${aiaN(Math.round(p * 100))}٪`));
    out.push(new File([r.blob], `${base}-${String(i + 1).padStart(2, '0')}.${r.ext}`, { type: r.blob.type }));
  }
  aiaStatus(type.includes('mp4') ? '✅ الفيديوهات جاهزة (MP4)' : '⚠️ طلعت WebM — إنستقرام ما يقبلها، استخدم «صور» أو حوّلها MP4');
  return out;
}
/* 1.21.5 — «💾 احفظ في الجوال»: نفس ملفات إنستقرام، تنحفظ في المستندات ← NOBLE (وفي المتصفح تنزل في التنزيلات) */
async function aiaSaveLocal(issue, mode = 'image') {
  const E = AIA.ed; const was = E?.playing; if (E) E.playing = false;
  toast(`⏳ نجهّز ${mode === 'video' ? 'الموشن' : 'الصور'}…`);
  try {
    const files = await (mode === 'video' ? aiaFilesVideo(issue, 1350) : aiaFiles(issue, 1350));
    const b64 = (f) => new Promise((r, j) => { const fr = new FileReader(); fr.onload = () => r(String(fr.result).split(',')[1]); fr.onerror = j; fr.readAsDataURL(f); });
    if (typeof Platform !== 'undefined' && Platform.isNative) {
      const FS = Platform.plugin('Filesystem');
      for (const f of files) await FS.writeFile({ path: `NOBLE/${f.name}`, data: await b64(f), directory: 'DOCUMENTS', recursive: true });
      aiaStatus(`💾 انحفظت ${aiaN(files.length)} ملفات في: الملفات ← المستندات (Documents) ← NOBLE`);
      toast(`انحفظت ${aiaN(files.length)} ${mode === 'video' ? 'فيديو' : 'صور'} في المستندات ← NOBLE ✓`, { type: 'success', duration: 6000 });
    } else {
      files.forEach((f, k) => setTimeout(() => aiaDl(f, f.name), k * 250));
      aiaStatus(`💾 نزلت ${aiaN(files.length)} ملفات في «التنزيلات»`);
    }
  } catch (e) { toast('ما قدرنا نحفظها: ' + (e?.message || e), { type: 'error' }); }
  if (E) { E.playing = was; E.t0 = performance.now(); }
}
async function aiaShareFiles(files, title) {
  const b64 = (f) => new Promise((r, j) => { const fr = new FileReader(); fr.onload = () => r(String(fr.result).split(',')[1]); fr.onerror = j; fr.readAsDataURL(f); });
  if (typeof Platform !== 'undefined' && Platform.isNative) {
    const FS = Platform.plugin('Filesystem'), Sh = Platform.plugin('Share'), uris = [];
    for (const f of files) uris.push((await FS.writeFile({ path: f.name, data: await b64(f), directory: 'CACHE' })).uri);
    return Sh.share({ title, files: uris, dialogTitle: 'انشر في إنستقرام' });
  }
  if (navigator.canShare?.({ files })) { try { await navigator.share({ files, title }); return; } catch (e) { if (e?.name === 'AbortError') throw e; } }
  files.forEach((f, k) => setTimeout(() => aiaDl(f, f.name), k * 250));
}

/* التصدير */
function aiaDl(blob, name) { const a = h('a', { href: URL.createObjectURL(blob), download: name }); document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 5000); }
/* 1.21.9 — «🎞️ ادمج الفيديو كامل»: كل السلايدات في فيديو واحد، وتتحكم بمدة كل سلايد */
function aiaMergeSheet() {
  const E = AIA.ed; if (!E) return;
  const M = AIA.merge = { secs: 0, size: 'post', trans: 'dip', videoFull: true, sfx: { on: true, trans: 'whoosh', cover: 'impact', outro: 'sparkle', vol: 90 }, ...(AIA.merge || {}) };
  const n = AISlides.total(E.issue, AIA.kit);
  const est = () => { let a = 0; for (let i = 0; i < n; i++) { const s = i > 0 ? E.issue.slides[i - 1] : null, isV = s?.media?.kind === 'video'; a += M.secs && !(isV && M.videoFull) ? M.secs : AISlides.duration(E.issue, i, AIA.kit); } return Math.round(a); };
  const info = h('p', { class: 'hint aia-m-est' });
  const paint = () => { info.textContent = `${aiaN(n)} سلايد · المدة تقريباً ${aiaN(est())} ثانية`; };
  const lab = h('b', { class: 'num' });
  const rng = h('input', { type: 'range', min: 0, max: 15, step: 1, value: M.secs });
  const upd = () => { M.secs = +rng.value; lab.textContent = M.secs ? `${aiaN(M.secs)} ثواني` : 'تلقائي'; paint(); };
  rng.addEventListener('input', upd); upd();
  const chips = (list, key) => h('div', { class: 'chips' }, ...list.map(([v, l]) => h('button', { type: 'button', class: `chip${M[key] === v ? ' on' : ''}`, onclick: (e) => { M[key] = v; [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); paint(); } }, l)));
  const go = h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { closeSheet(); aiaMerge(); } }, '🎞️ ابدأ الدمج');
  pickSheet('🎞️ ادمج الفيديو كامل', 'كل السلايدات من الغلاف لآخر خبر في فيديو واحد — يتسجل بنفس وقته الحقيقي', [h('div', { class: 'aia-m' },
    h('div', { class: 'field' }, h('span', { text: 'المقاس' }), chips([['post', '📱 بوست ٤:٥'], ['story', '🎬 ستوري ٩:١٦']], 'size')),
    h('label', { class: 'field' }, h('span', {}, 'مدة كل سلايد: ', lab), rng, h('small', { class: 'hint', text: '٠ = تلقائي (٦ ثواني، والمقاطع بطولها)' })),
    h('div', { class: 'field' }, h('span', { text: 'سلايدات الفيديو' }), chips([[true, 'بطول المقطع'], [false, 'نفس المدة']], 'videoFull')),
    h('div', { class: 'field' }, h('span', { text: 'الانتقال بين السلايدات' }), chips([['dip', '🌑 يظلم'], ['cross', '🌫️ يذوب'], ['push', '👉 يدفع'], ['zoom', '🔍 زوم'], ['flash', '⚡ فلاش'], ['none', '✂️ قطع']], 'trans')),
    aiaSfxBox(M), aiaMusicBox(M, E.issue), info, go)]);
  paint();
}
/* 🔊 مكتبة المؤثرات: أصوات مصنوعة بالكود (ملكك بالكامل) — صوت الانتقال، وصوت الغلاف، وصوت الصفحة الأخيرة */
function aiaSfxBox(M) {
  const X = M.sfx;
  const row = (key, label) => {
    const sel = h('div', { class: 'aia-fx-l' }, h('button', { type: 'button', class: `aia-fx${!X[key] ? ' on' : ''}`, onclick: (e) => pick(e, '') }, '🔇 بدون'),
      ...Sfx.LIST.map(([id, nm, sub]) => h('button', { type: 'button', class: `aia-fx${X[key] === id ? ' on' : ''}`, title: sub, onclick: (e) => pick(e, id) }, nm)));
    function pick(e, id) { X[key] = id; [...sel.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); if (id) Sfx.preview(id, (X.vol || 90) / 100); }
    return h('div', { class: 'field' }, h('span', { text: label }), sel);
  };
  const v0 = X.vol || 90, lb = h('span', { text: `صوت المؤثرات — ${aiaN(v0)}٪` }), r = h('input', { type: 'range', min: 0, max: 150, step: 5, value: v0 });
  r.addEventListener('input', () => { X.vol = +r.value; lb.textContent = `صوت المؤثرات — ${aiaN(X.vol)}٪`; });
  const on = h('input', { type: 'checkbox', checked: X.on !== false }), body = h('div', { class: 'aia-mu-b', hidden: X.on === false || null });
  on.addEventListener('change', () => { X.on = on.checked; body.hidden = !on.checked; });
  body.append(h('p', { class: 'hint', text: 'اضغط أي صوت تسمعه على طول. الأصوات مصنوعة بالكود — ملكك ١٠٠٪ بدون حقوق.' }),
    row('trans', '💨 صوت الانتقال بين السلايدات'), row('cover', '🎬 صوت أول الغلاف'), row('outro', '🏁 صوت الصفحة الأخيرة'), h('label', { class: 'field' }, lb, r));
  return h('div', { class: 'aia-mu aia-fxbox' }, h('label', { class: 'aia-mu-h' }, h('span', { text: '🔊 مؤثرات صوتية' }), h('b', { text: 'ووش · خش · هووب · بوب…' }), h('span', { class: 'switch' }, on, h('span', { class: 'track' }))), body);
}
/* 🎵 موسيقى العدد (1.21.9): ملف من جوالك (اللي عندك حقوقه) — تنرفع وتنحفظ مع العدد
 * تشتغل في: الفيديو الكامل (الدمج) + داخل التطبيق للمستخدمين لما تفتح العدد (لو فعّلت «🎵 في التطبيق») */
function aiaMusicBox(M, issue = AIA.ed?.issue) {
  const L = issue ? (issue.look = issue.look || {}) : null;
  const A = { url: '', name: '', start: 0, vol: 80, fade: true, loop: true, dur: 0, app: true, auto: true, ...((L ? L.music : M.audio) || {}) };
  if (L) L.music = A; M && (M.audio = A);
  const dirty = () => { if (L) aiaDirty(); };
  const el = new Audio(); el.crossOrigin = 'anonymous'; let stopT = 0;
  if (A.url) { el.src = A.url; el.onloadedmetadata = () => { A.dur = el.duration || 0; paint(); }; }
  const name = h('b', { text: A.name ? '🎵 ' + A.name : 'ما اخترت موسيقى' });
  const st = h('input', { class: 'input num ltr', type: 'number', min: 0, step: 1, value: A.start || 0 });
  const stL = h('small', { class: 'hint' });
  const vol = h('input', { type: 'range', min: 0, max: 100, step: 5, value: A.vol });
  const volL = h('span', { text: `مستوى الصوت — ${aiaN(A.vol)}٪` });
  const body = h('div', { class: 'aia-mu-b', hidden: !A.url || null });
  const fmt = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
  function paint() { stL.textContent = A.dur ? `طول المقطع ${fmt(A.dur)} — يبدأ من ${fmt(+A.start || 0)}` : ''; }
  const pick = () => aiaPickFile('audio/*', async (f) => {
    const local = URL.createObjectURL(f); A.url = local; A.name = f.name.slice(0, 40); A.local = true; name.textContent = '⏳ ' + A.name; body.hidden = false;
    el.src = local; el.onloadedmetadata = () => { A.dur = el.duration || 0; st.max = Math.max(0, Math.floor(A.dur - 1)); paint(); };
    try { const url = await aiaUpload(f); if (A.url === local) { A.url = url; delete A.local; } name.textContent = '🎵 ' + A.name; dirty(); aiaStatus('✅ الموسيقى انرفعت — اضغط 💾 حفظ'); }
    catch (e) { name.textContent = '⚠️ ' + A.name; toast('ما انرفعت الموسيقى: ' + Cloud.msg(e), { type: 'error' }); } });
  st.addEventListener('input', () => { A.start = Math.max(0, Math.min(Math.max(0, (A.dur || 9999) - 1), +st.value || 0)); paint(); dirty(); });
  vol.addEventListener('input', () => { A.vol = +vol.value; volL.textContent = `مستوى الصوت — ${aiaN(A.vol)}٪`; el.volume = A.vol / 100; dirty(); });
  const play = h('button', { type: 'button', class: 'btn sm', onclick: () => { clearTimeout(stopT); if (!el.paused) { el.pause(); play.textContent = '▶️ اسمع'; return; }
    el.currentTime = +A.start || 0; el.volume = A.vol / 100; el.play().catch(() => {}); play.textContent = '⏸️ وقف'; stopT = setTimeout(() => { el.pause(); play.textContent = '▶️ اسمع'; }, 8000); } }, '▶️ اسمع');
  const chip = (key, list) => h('div', { class: 'chips' }, ...list.map(([v, l]) => h('button', { type: 'button', class: `chip${A[key] === v ? ' on' : ''}`, onclick: (e) => { A[key] = v; [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); dirty(); } }, l)));
  paint();
  return h('div', { class: 'aia-mu' },
    h('div', { class: 'aia-mu-h' }, h('span', { text: '🎵 موسيقى العدد' }), name,
      h('button', { type: 'button', class: 'btn sm', onclick: pick }, A.url ? 'غيّر' : '＋ اختر من الجوال'),
      A.url ? h('button', { type: 'button', class: 'btn sm', onclick: (e) => { el.pause(); Object.assign(A, { url: '', name: '', dur: 0 }); name.textContent = 'ما اخترت موسيقى'; body.hidden = true; e.currentTarget.remove(); dirty(); } }, '✕') : null),
    (body.replaceChildren(
      h('label', { class: 'field' }, h('span', { text: 'تبدأ من الثانية' }), h('div', { class: 'aia-mu-r' }, st, play), stL),
      h('label', { class: 'field' }, volL, vol),
      h('div', { class: 'field' }, h('span', { text: '📱 داخل التطبيق للمستخدمين' }), chip('app', [[true, '🎵 تشتغل لما يفتحون العدد'], [false, 'بس في الفيديو اللي أصدّره']])),
      h('div', { class: 'field' }, h('span', { text: 'في التطبيق تبدأ' }), chip('auto', [[true, '🔊 بالصوت على طول'], [false, '🔇 لين يضغط 🔊']])),
      h('div', { class: 'field' }, h('span', { text: 'البداية والنهاية' }), chip('fade', [[true, '✨ تظهر وتختفي بنعومة'], [false, 'مباشر']])),
      h('div', { class: 'field' }, h('span', { text: 'لو المقطع أقصر' }), chip('loop', [[true, '🔁 يعيد'], [false, 'يسكت']])),
      h('p', { class: 'hint', text: '⚠️ استخدم موسيقى عندك حقوقها أو مجانية للاستخدام — إنستقرام يكتم المقاطع المحمية. لما يشتغل فيديو خبر بصوته، الموسيقى توطى تلقائياً.' })), body));
}
function aiaExports() {
  const E = AIA.ed, b = (t, sub, fn, cls = '') => h('button', { type: 'button', class: `aia-xb ${cls}`, onclick: fn }, h('b', { text: t }), sub ? h('small', { text: sub }) : null);
  const g = (title, hint, ...btns) => h('div', { class: 'aia-xg' }, h('div', { class: 'aia-xg-h' }, h('b', { text: title }), h('small', { text: hint })), h('div', { class: 'aia-xg-b' }, ...btns));
  return h('div', { class: 'aia-xs' },
    g('👆 السلايد اللي قدامك', 'تنزل في التنزيلات',
      b('🖼️ صورة', 'PNG', () => aiaExport('png')), b('🎬 فيديو', 'MP4 متحرك', () => aiaExport('video'))),
    g('🎞️ العدد كامل — ملف لكل سلايد', 'للنشر كألبوم (كاروسيل) في إنستقرام',
      b('📱 كاروسيل منشور', 'فيديو ٤:٥ لكل سلايد', () => aiaExport('carousel')), b('🎬 ستوري', 'فيديو ٩:١٦ لكل سلايد', () => aiaExport('story'))),
    g('🎬 فيديو واحد من البداية للنهاية', 'مع انتقالات ومؤثرات وموسيقى — للريلز',
      b('🎞️ ادمج الفيديو كامل', 'تختار المدة والانتقال والصوت', () => aiaMergeSheet(), 'aia-merge')),
    g('📸 إنستقرام مباشر', 'ينسخ الكابشن ويفتح المشاركة — الصق الكابشن في إنستقرام',
      b('📸 موشن + الكابشن', 'فيديوهات متحركة', () => aiaInsta(E.issue, 'video'), 'aia-ig'), b('🖼️ صور + الكابشن', 'صور ثابتة', () => aiaInsta(E.issue, 'image'))),
    g('💾 احفظ في جوالك', 'الملفات ← المستندات ← NOBLE',
      b('🖼️ الصور', '', () => aiaSaveLocal(E.issue, 'image')), b('🎬 الموشن', '', () => aiaSaveLocal(E.issue, 'video'))));
}
async function aiaMerge() {
  const E = AIA.ed, issue = E.issue, M = { ...(AIA.merge || {}), audio: issue.look?.music?.url ? issue.look.music : null }, base = `NOBLE-${issue.kind === 'weekly' ? 'week-' + issue.week : issue.kind}`;
  const was = E.playing; E.playing = false;
  try {
    await AISlides.fonts();
    const r = await AISlides.recordAll(issue, M.size === 'story' ? 1920 : 1350, { kit: AIA.kit },
      (p, i) => aiaStatus(`🎞️ دمج الفيديو — السلايد ${aiaN(i + 1)} من ${aiaN(AISlides.total(issue, AIA.kit))} · ${aiaN(Math.round(p * 100))}٪`), M);
    const f = new File([r.blob], `${base}-full${M.size === 'story' ? '-story' : ''}.${r.ext}`, { type: r.blob.type });
    if (typeof Platform !== 'undefined' && Platform.isNative) {
      const b64 = await new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.onerror = rej; fr.readAsDataURL(f); });
      await Platform.plugin('Filesystem').writeFile({ path: `NOBLE/${f.name}`, data: b64, directory: 'DOCUMENTS', recursive: true });
      aiaStatus(`✅ الفيديو الكامل (${aiaN(r.secs)} ثانية) انحفظ في: الملفات ← المستندات ← NOBLE ← ${f.name}`);
      toast('🎞️ انحفظ الفيديو الكامل في المستندات ← NOBLE ✓', { type: 'success', duration: 6000 });
    } else { aiaDl(f, f.name); aiaStatus(`✅ الفيديو الكامل (${aiaN(r.secs)} ثانية) نزل في «التنزيلات»`); }
    if (r.audio || r.sfx) toast(`${r.audio ? '🎵 الموسيقى' : ''}${r.audio && r.sfx ? ' و' : ''}${r.sfx ? '🔊 المؤثرات' : ''} انضافت ✓`, { duration: 3000 });
    if (!r.ext.includes('mp4')) toast('⚠️ طلع WebM — إنستقرام يفضّل MP4، حوّله لو احتجت', { duration: 7000 });
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); aiaStatus('⚠️ ' + Cloud.msg(e)); }
  E.playing = was; E.t0 = performance.now();
}
async function aiaExport(kind) {
  const E = AIA.ed, issue = E.issue, base = `NOBLE-${issue.kind === 'weekly' ? 'week-' + issue.week : issue.kind}`;
  const pad = (i) => String(i + 1).padStart(2, '0');
  await AISlides.fonts();
  if (kind === 'png') { const b = await AISlides.still(issue, E.cur, aiaSizeH(E.size), { kit: AIA.kit }, 'image/png', E.pt || 3); return aiaDl(b, `${base}-${pad(E.cur)}.png`); }
  const h0 = kind === 'story' ? 1920 : kind === 'carousel' ? (E.size === 'story' ? 1350 : aiaSizeH(E.size)) : aiaSizeH(E.size);
  const idx = kind === 'video' ? [E.cur] : Array.from({ length: AISlides.total(issue, AIA.kit) }, (_, i) => i);
  const was = E.playing; E.playing = false;
  try {
    for (const i of idx) {
      const r = await AISlides.record(issue, i, h0, { kit: AIA.kit }, (p) => aiaStatus(`🎬 تسجيل السلايد ${aiaN(i + 1)} من ${aiaN(idx.length)} — ${aiaN(Math.round(p * 100))}٪`));
      aiaDl(r.blob, `${base}${h0 === 1920 ? '-story' : ''}-${pad(i)}.${r.ext}`);
    }
    aiaStatus(`✅ تم التصدير (${AISlides.bestType().includes('mp4') ? 'MP4' : 'WebM — حوّله MP4 قبل إنستقرام لو احتجت'}) — كل سلايد ملف لحاله.`);
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); aiaStatus('⚠️ ' + Cloud.msg(e)); }
  E.playing = was; E.t0 = performance.now();
}

/* 1.21.25 — «📸 عند الحفظ (انستقرام)»: تنطبق على الصور والفيديو المحفوظة بس — التطبيق يبقى مثل ما هو */
function aiaIgCtl(I, E, sw) {
  const sk = Object.keys(AISlides.SIZES).find((k) => k === E.size) || 'post';
  const rg = (label, key, d, mn, mx, st = 1, u = '', ltr = false) => {
    const v0 = Number.isFinite(+I[key]) && I[key] !== '' && I[key] != null && !(key === 'bscale' && !+I[key]) ? +I[key] : d;
    const lb = h('span', { text: `${label} — ${aiaN(v0)}${u}` }), r = h('input', { type: 'range', min: mn, max: mx, step: st, value: v0, dir: ltr ? 'ltr' : null });
    r.addEventListener('input', () => { I[key] = key === 'bscale' ? +r.value / 100 : +r.value; lb.textContent = `${label} — ${aiaN(+r.value)}${u}`; aiaKitDirty(); });
    return h('label', { class: 'field' }, lb, r);
  };
  const on = I.on !== false;
  return [
    h('h3', { text: '📸 عند الحفظ (انستقرام)' }),
    h('p', { class: 'hint', text: 'إعدادات تنطبق بس لما تحفظ صورة أو فيديو — التطبيق يبقى مثل ما هو. شغّل «👁️ معاينة الحفظ» فوق المعاينة عشان تشوف النتيجة.' }),
    sw('شغّل إعدادات الحفظ', 'بدونها: الحفظ يطلع نفس شكل التطبيق بالضبط', I, 'on'),
    ...(on ? [
      aiaField('اتجاه الشريط و«اسحب للمزيد» في الحفظ', aiaChips([['ltr', '➡️ من اليسار لليمين (انستقرام)'], ['rtl', '⬅️ من اليمين لليسار'], ['same', 'نفس التطبيق']], I.dir || 'ltr', (k) => { I.dir = k; aiaKitDirty(); aiaEditor(); })),
      sw('📐 إطار خاص بالحفظ', 'حجم وهامش مختلف لفوق وتحت في الصور المحفوظة بس', I, 'frOn'),
      ...(I.frOn ? aiaFrameCtl(I, 'fr', '📐 إطار الحفظ (انستقرام)') : []),
      sw('🔁 اقلب اتجاه الأسهم في الحفظ ‹‹‹ ↔ ›››', 'الشريط يبقى مثل ما هو — الأسهم بس تنعكس', I, 'aflip'),
      h('h3', { class: 'aia-sub', text: '✦ شعار NOBLE فوق' }),
      sw('إخفاء الشعار في الحفظ', '', I, 'bhide'),
      ...(!I.bhide ? [
        rg('حجم الشعار في الحفظ', 'bscale', Math.round((AIA.kit.brand.scale || 1) * 100), 40, 200, 5, '٪'),
        rg('وضوح الشعار', 'bop', 100, 10, 100, 5, '٪'),
        h('p', { class: 'hint', text: `المكان: شغّل «👁️ معاينة الحفظ» واسحب الشعار على المعاينة — كل مقاس له مكانه (الحالي: ${AISlides.SIZES[sk][1]}).` }),
        h('button', { type: 'button', class: 'btn sm', onclick: () => { delete I.bpos[sk]; delete I.bscale; I.bop = 100; aiaKitDirty(); aiaEditor(); } }, '↺ نفس مكان وحجم التطبيق'),
      ] : []),
      h('h3', { class: 'aia-sub', text: '🔢 رقم السلايد (3 / 6)' }),
      sw('يظهر في الحفظ', 'انستقرام يحط رقمه فوق يمين — صغّر رقمنا أو أخفه', I, 'cshow'),
      ...(I.cshow !== false ? [
        rg('حجمه في الحفظ', 'csize', 70, 30, 160, 5, '٪'),
        rg('زحزحه يمين ↔ يسار', 'cdx', 0, -800, 0, 4, '', true),
        rg('نزّله لتحت', 'cdy', 0, -40, 500, 4),
        h('button', { type: 'button', class: 'btn sm', onclick: () => { I.csize = 70; I.cdx = 0; I.cdy = 0; aiaKitDirty(); aiaEditor(); } }, '↺ رجّع الرقم'),
      ] : []),
    ] : []),
  ];
}

/* 1.21.26 — 📊 أي خبر شدّ الناس (من التعليقات اللي فيها «📌 الخبر N») */
async function aiaCmtStats(issue) {
  try {
    const r = await Cloud.admin.aiCmtStats(issue.id), by = r?.by || {}, tot = r?.total || 0, mx = Math.max(1, ...Object.values(by).map(Number));
    const rows = (issue.slides || []).map((s, k) => { const n = Number(by[k + 1] || 0); return h('div', { class: 'aia-cs' },
      h('div', { class: 'aia-cs-h' }, h('b', { text: `${aiaN(k + 1)} · ${String(s.head || s.company || '').slice(0, 46)}` }), h('span', { class: 'num', text: aiaN(n) })),
      h('i', { class: 'aia-cs-bar' }, h('u', { style: `width:${Math.round(n / mx * 100)}%` }))); });
    mkSheet('📊 تعليقات العدد', [
      h('p', { class: 'hint', text: `${aiaN(tot)} تعليق${r?.pending ? ` · ${aiaN(r.pending)} بانتظار موافقتك (من اكتشف ← التعليقات)` : ''}` }),
      h('h3', { text: '📌 أي خبر شدّ الناس أكثر' }), ...rows,
      h('small', { class: 'hint', text: 'يحسب التعليقات اللي اختار فيها صاحبها خبر معيّن. الموافقة والرفض من «اكتشف ← التعليقات».' })], []);
  } catch (e) { toast(/function|schema/i.test(Cloud.msg(e)) ? 'شغّل supabase/update-1.21.26.sql' : Cloud.msg(e), { type: 'error' }); }
}

/* 1.21.28 — 📐 الإطار: يكبّر/يصغّر الشريط العلوي والسفلي ويبعدهم عن الحواف — عشان يبقون داخل إطار انستقرام */
function aiaFrameCtl(O, key, title) {
  const F = (O[key] = O[key] || {});
  const rows = [['tk', 'حجم الشعار والرقم فوق ٪', 100, 50, 160, 5], ['tm', 'بعدهم عن الحافة ↔', 0, -40, 300, 4], ['ty', 'نزّلهم لتحت ↕', 0, -40, 300, 4],
    ['bk', 'حجم الشريط تحت ٪', 100, 50, 160, 5], ['bm', 'بعده عن الحواف ↔', 0, 0, 300, 4], ['by', 'ارفعه لفوق ↕', 0, -60, 400, 4]];
  return [h('h3', { class: 'aia-sub', text: title }),
    h('p', { class: 'hint', text: 'يكبّر ويصغّر العناصر كمجموعة وحدة عشان يبقى التصميم متناسق — والخلفية تبقى مليانة لين الحواف.' }),
    ...rows.map(([k, l, d, mn, mx, st]) => {
      const v = Number.isFinite(+F[k]) ? +F[k] : d, lb = h('span', { text: `${l} — ${aiaN(v)}` });
      const r = h('input', { type: 'range', min: mn, max: mx, step: st, value: v });
      r.addEventListener('input', () => { F[k] = +r.value; lb.textContent = `${l} — ${aiaN(+r.value)}`; aiaKitDirty(); });
      return h('label', { class: 'field' }, lb, r);
    }),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { O[key] = {}; aiaKitDirty(); aiaEditor(); } }, '↺ رجّع الإطار الافتراضي')];
}
