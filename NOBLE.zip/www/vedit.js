/* NOBLE — «🎬 محرّر الفيديو» (1.21) — داخل التصاميم ← استوديو
 * محرّر خفيف على الجوال (بدون رفع، يشتغل بدون نت): مقاطع وصور ورا بعض، قص البداية والنهاية، ترتيب،
 * نصوص عربية متحركة، موسيقى وارتفاع الصوت، مقاسات (ستوري/مربع/بوست/عرضي)، خلفية مموّهة، انتقال ناعم،
 * وتصدير MP4 (أو WebM لو الجهاز ما يدعم) — بالوقت الحقيقي على الجهاز. كود NOBLE الخاص (بدون مكتبات خارجية).
 */
'use strict';
var VEdit = (() => {
  const RATIOS = { story: ['ستوري', 9, 16], square: ['مربع', 1, 1], post: ['بوست', 4, 5], wide: ['عرضي', 16, 9] };
  const COLORS = ['#FFFFFF', '#111111', '#FFD36E', '#F08A3C', '#E5487A', '#56C8FF', '#4CD63C', '#B86BFF'];
  const PX = 46; // بكسل لكل ثانية في الخط الزمني
  const MAXT = 180; // ٣ دقائق
  const N = (n) => (typeof UI !== 'undefined' ? UI.n(n) : String(n));
  const fmt = (s) => { s = Math.max(0, s || 0); const m = Math.floor(s / 60), r = Math.floor(s % 60); return `${N(m)}:${N(String(r).padStart(2, '0'))}`; };
  const fmt1 = (s) => N((Math.round((s || 0) * 10) / 10).toFixed(1));
  const uid = () => Math.random().toString(36).slice(2, 9);
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const E = (tag, a = {}, ...k) => h(tag, a, ...k);
  const icon2 = (n, s = 20) => (typeof icon === 'function' ? icon(n, { size: s }) : '');

  let V = null, root = null, cv = null, ctx = null, AC = null, master = null, raf = 0, iv = 0;

  /* ---------- الحالة ---------- */
  function fresh() {
    return { ratio: 'story', bg: 'blur', fade: true, clips: [], texts: [], music: null, clipVol: 1, t: 0, cur: 0, playing: false, sel: null, tool: null, exporting: false };
  }
  const len = (c) => Math.max(0.1, c.out - c.in);
  const total = () => V.clips.reduce((s, c) => s + len(c), 0);
  const offs = () => { let o = 0; return V.clips.map((c) => { const x = o; o += len(c); return x; }); };
  function at(t) { // أي مقطع عند الوقت t
    const o = offs();
    for (let i = 0; i < V.clips.length; i++) if (t < o[i] + len(V.clips[i]) - 1e-3 || i === V.clips.length - 1) return { i, local: clamp(t - o[i], 0, len(V.clips[i])), off: o[i] };
    return { i: 0, local: 0, off: 0 };
  }
  const size = () => { const [, a, b] = RATIOS[V.ratio]; const k = 1080 / Math.max(a, b); return { W: Math.round(a * k / 2) * 2, H: Math.round(b * k / 2) * 2 }; };

  /* ---------- الصوت ---------- */
  function audio() {
    if (!AC) {
      const C = window.AudioContext || window.webkitAudioContext; if (!C) return null;
      AC = new C(); master = AC.createGain(); master.connect(AC.destination);
    }
    if (AC.state === 'suspended') AC.resume().catch(() => {});
    return AC;
  }
  function wire(el, vol) { // يمرّر صوت العنصر عبر مكسر NOBLE (للمعاينة والتسجيل)
    const a = audio(); if (!a || el._g) return;
    try { const s = a.createMediaElementSource(el), g = a.createGain(); g.gain.value = vol; s.connect(g); g.connect(master); el._g = g; } catch { /* لا شيء */ }
  }
  function vols() {
    V.clips.forEach((c) => { if (c.el?._g) c.el._g.gain.value = c.mute ? 0 : V.clipVol; else if (c.el && c.kind === 'video') c.el.volume = c.mute ? 0 : V.clipVol; });
    if (V.music?.el) { if (V.music.el._g) V.music.el._g.gain.value = V.music.vol; else V.music.el.volume = V.music.vol; }
  }

  /* ---------- إضافة ملفات ---------- */
  function pick(accept, multiple, cb) {
    const i = E('input', { type: 'file', accept, multiple: multiple || null, hidden: true });
    i.addEventListener('change', () => { const f = [...(i.files || [])]; i.remove(); if (f.length) cb(f); });
    document.body.append(i); i.click();
  }
  const seek = (el, t) => new Promise((res) => {
    if (Math.abs(el.currentTime - t) < 0.02 && el.readyState >= 2) return res();
    let done = false; const fin = () => { if (!done) { done = true; res(); } };
    el.addEventListener('seeked', fin, { once: true }); setTimeout(fin, 1200);
    try { el.currentTime = t; } catch { fin(); }
  });
  function loadVideo(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file), el = document.createElement('video');
      Object.assign(el, { src: url, preload: 'auto', playsInline: true, muted: false, crossOrigin: 'anonymous' }); el.setAttribute('playsinline', '');
      let tries = 0;
      el.onloadedmetadata = async () => {
        if (!isFinite(el.duration)) { el.currentTime = 1e7; await new Promise((r) => { el.ontimeupdate = () => { el.ontimeupdate = null; r(); }; setTimeout(r, 1500); }); }
        const dur = isFinite(el.duration) && el.duration > 0 ? el.duration : 5;
        await seek(el, Math.min(0.1, dur / 2));
        res({ id: uid(), kind: 'video', name: file.name, url, el, dur, in: 0, out: Math.min(dur, 60), mute: false, fit: 'auto', w: el.videoWidth, h: el.videoHeight, thumb: thumbOf(el) });
      };
      el.onerror = () => { if (tries++ < 1) return; URL.revokeObjectURL(url); rej(new Error('video')); };
      el.load();
    });
  }
  function loadImage(file) {
    return new Promise((res, rej) => {
      const url = URL.createObjectURL(file), el = new Image();
      el.onload = () => res({ id: uid(), kind: 'image', name: file.name, url, el, dur: 30, in: 0, out: 3, mute: true, fit: 'auto', w: el.naturalWidth, h: el.naturalHeight, thumb: thumbOf(el) });
      el.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
      el.src = url;
    });
  }
  function thumbOf(el) {
    try {
      const w = el.videoWidth || el.naturalWidth || 160, hh = el.videoHeight || el.naturalHeight || 90, k = 120 / Math.max(w, hh);
      const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(w * k)); c.height = Math.max(1, Math.round(hh * k));
      c.getContext('2d').drawImage(el, 0, 0, c.width, c.height); return c.toDataURL('image/jpeg', 0.7);
    } catch { return ''; }
  }
  async function addFiles(files) {
    busy(true, 'يجهّز الملفات…');
    let bad = 0;
    for (const f of files) {
      try {
        const c = /^video\//.test(f.type) ? await loadVideo(f) : /^image\//.test(f.type) ? await loadImage(f) : null;
        if (!c) { bad++; continue; }
        if (c.kind === 'video') wire(c.el, V.clipVol);
        V.clips.push(c);
      } catch { bad++; }
    }
    busy(false);
    if (bad) toast(`${N(bad)} ملف ما قدرنا نفتحه`, { type: 'error' });
    if (total() > MAXT) toast('الفيديو أطول من ٣ دقائق — قصّ شوي عشان التصدير يكون أسرع');
    if (!V.sel && V.clips.length) V.sel = { type: 'clip', id: V.clips[V.clips.length - 1].id };
    paint(); await showAt(V.t);
  }

  /* ---------- الرسم ---------- */
  function drawMedia(x, W, H, c, alpha) {
    const el = c.el, sw = c.w || el.videoWidth || el.naturalWidth, sh = c.h || el.videoHeight || el.naturalHeight;
    if (!sw || !sh) return;
    const cover = Math.max(W / sw, H / sh), contain = Math.min(W / sw, H / sh);
    const fit = c.fit === 'auto' ? (Math.abs(sw / sh - W / H) < 0.25 ? 'cover' : 'contain') : c.fit;
    x.save(); x.globalAlpha = alpha;
    if (fit === 'contain') {
      if (V.bg === 'blur') { x.save(); try { x.filter = 'blur(28px) brightness(.7)'; } catch { /* لا شيء */ } const k = cover * 1.15; x.drawImage(el, (W - sw * k) / 2, (H - sh * k) / 2, sw * k, sh * k); x.restore(); }
      x.drawImage(el, (W - sw * contain) / 2, (H - sh * contain) / 2, sw * contain, sh * contain);
    } else x.drawImage(el, (W - sw * cover) / 2, (H - sh * cover) / 2, sw * cover, sh * cover);
    x.restore();
  }
  function wrap(x, text, maxW) {
    const out = [];
    for (const para of String(text).split('\n')) {
      let line = '';
      for (const w of para.split(/\s+/)) { const t = line ? line + ' ' + w : w; if (x.measureText(t).width > maxW && line) { out.push(line); line = w; } else line = t; }
      out.push(line);
    }
    return out;
  }
  const FONT = () => { try { return getComputedStyle(document.body).fontFamily || 'sans-serif'; } catch { return 'sans-serif'; } };
  function drawText(x, W, H, T, t) {
    if (t < T.start || t > T.end || !T.text.trim()) return;
    const a = Math.min(1, (t - T.start) / 0.4, (T.end - t) / 0.4), e = 1 - Math.pow(1 - clamp(a, 0, 1), 3);
    const fs = Math.round(W * T.size / 100), lh = fs * 1.35;
    x.save(); x.font = `800 ${fs}px ${FONT()}`; x.direction = 'rtl'; x.textAlign = 'center'; x.textBaseline = 'middle';
    const lines = wrap(x, T.text, W * 0.84), bh = lines.length * lh;
    let cy = T.pos === 'top' ? H * 0.16 + bh / 2 : T.pos === 'bottom' ? H * 0.84 - bh / 2 : H / 2;
    let sc = 1, alpha = 1;
    if (T.anim === 'fade') alpha = e;
    else if (T.anim === 'slide') { alpha = e; cy += (1 - e) * fs * 1.2; }
    else if (T.anim === 'pop') { const p = clamp(a, 0, 1) - 1, c1 = 1.70158; alpha = clamp(a * 2, 0, 1); sc = 0.6 + 0.4 * (1 + (c1 + 1) * p * p * p + c1 * p * p); }
    x.globalAlpha = alpha; x.translate(W / 2, cy); x.scale(sc, sc);
    if (T.box) {
      const mw = Math.max(...lines.map((l) => x.measureText(l).width)) + fs * 1.1, r = fs * 0.45;
      x.fillStyle = T.color === '#111111' ? 'rgba(255,255,255,.88)' : 'rgba(0,0,0,.55)';
      x.beginPath(); x.roundRect ? x.roundRect(-mw / 2, -bh / 2 - fs * 0.3, mw, bh + fs * 0.6, r) : x.rect(-mw / 2, -bh / 2 - fs * 0.3, mw, bh + fs * 0.6); x.fill();
    } else { x.shadowColor = 'rgba(0,0,0,.55)'; x.shadowBlur = fs * 0.35; x.shadowOffsetY = fs * 0.06; }
    x.fillStyle = T.color;
    lines.forEach((l, i) => x.fillText(l, 0, -bh / 2 + lh / 2 + i * lh));
    x.restore();
  }
  function draw(x, W, H) {
    x.save(); x.fillStyle = V.bg === 'white' ? '#fff' : '#000'; x.fillRect(0, 0, W, H);
    if (V.clips.length) {
      const { i, local } = at(V.t), c = V.clips[i], L = len(c);
      let alpha = 1;
      if (V.fade && V.clips.length > 1) { const d = 0.35; if (i > 0 && local < d) alpha = local / d; if (i < V.clips.length - 1 && L - local < d) alpha = Math.min(alpha, (L - local) / d); }
      drawMedia(x, W, H, c, clamp(alpha, 0, 1));
    }
    V.texts.forEach((T) => drawText(x, W, H, T, V.t));
    x.restore();
  }
  function frame() {
    if (!cv) return;
    const { W, H } = size();
    if (cv.width !== W / 2 || cv.height !== H / 2) { cv.width = W / 2; cv.height = H / 2; }
    ctx.setTransform(0.5, 0, 0, 0.5, 0, 0); draw(ctx, W, H);
    const tt = root?.querySelector('.ve-time'); if (tt) tt.textContent = `${fmt(V.t)} / ${fmt(total())}`;
    const ph = root?.querySelector('.ve-ph'); if (ph) ph.style.insetInlineStart = `${V.t * PX}px`;
  }
  /* عرض لحظة معيّنة (وقت التوقف أو السحب) */
  async function showAt(t) {
    V.t = clamp(t, 0, total());
    const { i, local } = at(V.t), c = V.clips[i];
    if (c?.kind === 'video') await seek(c.el, c.in + local);
    frame();
  }

  /* ---------- التشغيل (للمعاينة وللتصدير) ---------- */
  async function startClip(i, local) {
    V.clips.forEach((c, k) => { if (k !== i && c.kind === 'video' && !c.el.paused) c.el.pause(); });
    const c = V.clips[i]; V.cur = i;
    if (c.kind === 'video') { await seek(c.el, c.in + local); vols(); try { await c.el.play(); } catch { /* لا شيء */ } }
    V.clipT0 = performance.now() - local * 1000;
  }
  function syncMusic() {
    const m = V.music; if (!m?.el) return;
    const d = m.el.duration || 0, want = d ? (V.t % d) : V.t;
    if (Math.abs(m.el.currentTime - want) > 0.35) try { m.el.currentTime = want; } catch { /* لا شيء */ }
    if (m.el.paused) m.el.play().catch(() => {});
  }
  async function play(opts = {}) {
    if (!V.clips.length || V.playing) return;
    audio();
    if (V.t >= total() - 0.05) V.t = 0;
    V.playing = true; paintPlay();
    const { i, local } = at(V.t);
    await startClip(i, local);
    let switching = false, last = 0;
    return new Promise((resolve) => {
      const stopAll = () => { V.playing = false; cancelAnimationFrame(raf); clearInterval(iv); V.clips.forEach((c) => c.kind === 'video' && c.el.pause()); V.music?.el?.pause(); paintPlay(); resolve(); };
      V._stop = stopAll;
      const tick = () => {
        if (!V.playing) return;
        const now = performance.now(); if (now - last < 16) return; last = now;
        if (switching) { opts.onFrame?.(); return; }
        const o = offs(), i2 = V.cur, c = V.clips[i2]; if (!c) return stopAll();
        let local = c.kind === 'video' ? c.el.currentTime - c.in : (now - V.clipT0) / 1000;
        if (c.kind === 'video' && c.el.paused && !c.el.ended && local < len(c) - 0.05) { c.el.play().catch(() => {}); }
        const endNow = local >= len(c) - 0.02 || (c.kind === 'video' && c.el.ended);
        V.t = clamp(o[i2] + Math.min(local, len(c)), 0, total());
        if (V.music) syncMusic();
        frame(); opts.onFrame?.();
        if (endNow) {
          if (i2 >= V.clips.length - 1) { V.t = total(); frame(); opts.onFrame?.(); return stopAll(); }
          switching = true; if (c.kind === 'video') c.el.pause();
          startClip(i2 + 1, 0).then(() => { switching = false; });
        }
      };
      const loop = () => { if (V.playing) { tick(); raf = requestAnimationFrame(loop); } };
      raf = requestAnimationFrame(loop);
      iv = setInterval(tick, 1000 / 30); // أندرويد يبطّئ rAF أحياناً
    });
  }
  const pause = () => V?._stop?.();
  function paintPlay() { const b = root?.querySelector('.ve-play'); if (b) b.textContent = V.playing ? '❚❚' : '▶'; }

  /* ---------- التصدير ---------- */
  async function exportVideo() {
    if (!V.clips.length) return toast('أضف مقطع أو صورة أول');
    if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
    pause();
    const type = typeof MotionKit !== 'undefined' && MotionKit.bestType ? MotionKit.bestType(true) : ['video/mp4', 'video/webm'].find((m) => typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m));
    if (!type || !HTMLCanvasElement.prototype.captureStream) return toast('جهازك ما يدعم حفظ الفيديو', { type: 'error' });
    const { W, H } = size(), k = 1280 / Math.max(W, H), EW = Math.round(W * k / 2) * 2, EH = Math.round(H * k / 2) * 2;
    const c = document.createElement('canvas'); c.width = EW; c.height = EH;
    Object.assign(c.style, { position: 'fixed', left: 0, top: 0, width: '2px', height: '2px', opacity: 0.01, pointerEvents: 'none', zIndex: -1 }); document.body.append(c);
    const x = c.getContext('2d');
    const manual = typeof CanvasCaptureMediaStreamTrack !== 'undefined' && 'requestFrame' in CanvasCaptureMediaStreamTrack.prototype;
    const stream = c.captureStream(manual ? 0 : 30), vt = stream.getVideoTracks()[0];
    const a = audio(); let dst = null;
    if (a) { dst = a.createMediaStreamDestination(); master.connect(dst); dst.stream.getAudioTracks().forEach((tr) => stream.addTrack(tr)); }
    let wake = null; try { navigator.wakeLock?.request('screen').then((w) => { wake = w; }).catch(() => {}); } catch { /* لا شيء */ }
    const rec = new MediaRecorder(stream, { mimeType: type, videoBitsPerSecond: 6e6, ...(dst ? { audioBitsPerSecond: 160000 } : {}) }), chunks = [];
    rec.ondataavailable = (ev) => ev.data?.size && chunks.push(ev.data);
    const done = new Promise((r) => (rec.onstop = r));
    V.exporting = true; V.cancel = false;
    const ov = root.querySelector('.ve-exp'); ov.hidden = false;
    const pct = ov.querySelector('b'), bar = ov.querySelector('i');
    V.t = 0; await showAt(0);
    rec.start(250);
    const T = total();
    await play({ onFrame: () => {
      x.setTransform(k, 0, 0, k, 0, 0); draw(x, W, H); if (manual) try { vt.requestFrame(); } catch { /* لا شيء */ }
      const p = clamp(V.t / T, 0, 1); pct.textContent = `${N(Math.round(p * 100))}٪`; bar.style.width = `${p * 100}%`;
      if (V.cancel) pause();
    } });
    await new Promise((r) => setTimeout(r, 200));
    rec.stop(); await done; c.remove(); try { wake?.release(); } catch { /* لا شيء */ }
    if (dst) try { master.disconnect(dst); } catch { /* لا شيء */ }
    stream.getTracks().forEach((tr) => tr.stop());
    V.exporting = false; ov.hidden = true;
    if (V.cancel) return toast('انلغى التصدير');
    const blob = new Blob(chunks, { type: type.split(';')[0] }), ext = /mp4/.test(type) ? 'mp4' : 'webm';
    if (!blob.size) return toast('تعذّر تسجيل الفيديو', { type: 'error' });
    deliverSheet(blob, ext);
  }
  function deliverSheet(blob, ext) {
    const name = `NOBLE-video-${new Date().toISOString().slice(0, 10)}-${uid()}.${ext}`;
    const go = async (how) => {
      sh.remove();
      try {
        if (typeof dsDeliver === 'function') await dsDeliver(blob, name, how, 'فيديو NOBLE');
        else { const u = URL.createObjectURL(blob); const l = E('a', { href: u, download: name }); document.body.append(l); l.click(); l.remove(); setTimeout(() => URL.revokeObjectURL(u), 6e4); }
        if (typeof buzz === 'function') buzz('success');
        if (typeof markActive === 'function') markActive('design');
        Sync?.event?.('design', { tpl: 'video', how, motion: true });
      } catch { /* أُلغيت */ }
    };
    const url = URL.createObjectURL(blob);
    const sh = E('div', { class: 've-done' }, E('div', { class: 've-done-c' },
      E('video', { src: url, controls: true, playsinline: true, class: 've-done-v' }),
      E('b', { text: `جاهز ✓ — ${fmt(total())} · ${(blob.size / 1048576).toFixed(1)} ميجا` }),
      E('div', { class: 've-done-a' },
        E('button', { type: 'button', class: 'btn btn-primary', onclick: () => go('share') }, '📤 مشاركة'),
        E('button', { type: 'button', class: 'btn', onclick: () => go('save') }, '💾 حفظ'),
        E('button', { type: 'button', class: 'btn btn-ghost', onclick: () => { sh.remove(); URL.revokeObjectURL(url); } }, 'رجوع'))));
    root.append(sh);
  }

  /* ---------- الواجهة ---------- */
  function busy(on, msg) { const b = root?.querySelector('.ve-busy'); if (!b) return; b.hidden = !on; if (msg) b.querySelector('span').textContent = msg; }
  const selClip = () => (V.sel?.type === 'clip' ? V.clips.find((c) => c.id === V.sel.id) : null);
  const selText = () => (V.sel?.type === 'text' ? V.texts.find((t) => t.id === V.sel.id) : null);
  function seg(opts, cur, on) {
    return E('div', { class: 've-seg' }, ...opts.map(([v, l]) => E('button', { type: 'button', class: v === cur ? 'on' : '', onclick: () => on(v) }, l)));
  }
  function slider(label, val, min, max, step, on, show) {
    const o = E('em', { class: 'num', text: show(val) }), r = E('input', { type: 'range', min, max, step, value: val });
    r.addEventListener('input', () => { o.textContent = show(+r.value); on(+r.value, false); });
    r.addEventListener('change', () => on(+r.value, true));
    return E('label', { class: 've-sl' }, E('span', { text: label }), r, o);
  }
  function timeline() {
    const T = total(), w = Math.max(T * PX, 10);
    const track = E('div', { class: 've-track', style: { width: `${w + 90}px` } },
      ...V.clips.map((c) => E('button', { type: 'button', class: `ve-clip${V.sel?.id === c.id ? ' on' : ''}${c.kind === 'image' ? ' img' : ''}`, style: { width: `${Math.max(36, len(c) * PX)}px`, backgroundImage: c.thumb ? `url(${c.thumb})` : '' },
        onclick: (ev) => { ev.stopPropagation(); V.sel = { type: 'clip', id: c.id }; V.tool = 'clip'; paint(); showAt(offs()[V.clips.indexOf(c)] + 0.01); } },
        E('small', { class: 'num', text: `${fmt1(len(c))}ث` }), c.mute && c.kind === 'video' ? E('i', { text: '🔇' }) : null)),
      E('button', { type: 'button', class: 've-add', onclick: (ev) => { ev.stopPropagation(); pick('video/*,image/*', true, addFiles); } }, '＋'));
    // النصوص المتداخلة بالوقت تنزل صف تحت (ما تغطي بعض)
    const rowEnd = [], rowOf = new Map();
    [...V.texts].sort((a, b) => a.start - b.start).forEach((t) => { let r = rowEnd.findIndex((e) => e <= t.start + 0.01); if (r < 0) { r = rowEnd.length; rowEnd.push(0); } rowEnd[r] = t.end; rowOf.set(t.id, r); });
    const texts = E('div', { class: 've-lane', style: { width: `${w + 90}px`, height: `${Math.max(1, rowEnd.length) * 30 - 4}px` } }, ...V.texts.map((t) => E('button', { type: 'button', class: `ve-tx${V.sel?.id === t.id ? ' on' : ''}`, style: { top: `${rowOf.get(t.id) * 30}px`, insetInlineStart: `${t.start * PX}px`, width: `${Math.max(30, (t.end - t.start) * PX)}px` }, onclick: (ev) => { ev.stopPropagation(); V.sel = { type: 'text', id: t.id }; V.tool = 'text'; paint(); showAt(t.start + 0.3); } }, `Aa ${t.text.split('\n')[0]}`)));
    const mus = V.music ? E('div', { class: 've-lane' }, E('button', { type: 'button', class: `ve-mu${V.tool === 'music' ? ' on' : ''}`, style: { width: `${w}px` }, onclick: (ev) => { ev.stopPropagation(); V.tool = 'music'; V.sel = null; paint(); } }, `🎵 ${V.music.name}`)) : null;
    const box = E('div', { class: 've-tl' }, E('div', { class: 've-tl-in' }, E('i', { class: 've-ph' }), track, V.texts.length ? texts : null, mus));
    // الضغط على الخط الزمني يقدّم/يرجّع
    box.addEventListener('click', (ev) => { if (ev.target.closest('button')) return; const r = box.firstChild.getBoundingClientRect(); const xx = document.dir === 'rtl' || getComputedStyle(box).direction === 'rtl' ? r.right - ev.clientX : ev.clientX - r.left; pause(); showAt(xx / PX); });
    return box;
  }
  function panel() {
    const c = selClip(), T = selText();
    if (V.tool === 'clip' && c) {
      const i = V.clips.indexOf(c), maxOut = c.kind === 'image' ? 30 : c.dur;
      return E('div', { class: 've-panel' },
        E('div', { class: 've-ph-t' }, E('b', { text: c.kind === 'image' ? '🖼 صورة' : '🎬 مقطع' }), E('small', { text: `${N(i + 1)} من ${N(V.clips.length)}` })),
        ...(c.kind === 'image'
          ? [slider('المدة', len(c), 0.5, 15, 0.5, (v, fin) => { c.out = c.in + v; if (fin) paint(); else frame(); }, (v) => `${fmt1(v)}ث`)]
          : [slider('البداية', c.in, 0, Math.max(0, maxOut - 0.2), 0.1, (v, fin) => { c.in = Math.min(v, c.out - 0.2); if (fin) paint(); showAt(offs()[i]); }, (v) => `${fmt1(v)}ث`),
            slider('النهاية', c.out, 0.2, maxOut, 0.1, (v, fin) => { c.out = Math.max(v, c.in + 0.2); if (fin) paint(); showAt(offs()[i] + len(c) - 0.05); }, (v) => `${fmt1(v)}ث`)]),
        E('div', { class: 've-row' }, E('span', { text: 'العرض' }), seg([['auto', 'تلقائي'], ['cover', 'ملء'], ['contain', 'كامل']], c.fit, (v) => { c.fit = v; paint(); frame(); })),
        E('div', { class: 've-acts' },
          E('button', { type: 'button', class: 'btn sm', disabled: i === 0 || null, onclick: () => { V.clips.splice(i, 1); V.clips.splice(i - 1, 0, c); paint(); showAt(V.t); } }, '→ قدّم'),
          E('button', { type: 'button', class: 'btn sm', disabled: i === V.clips.length - 1 || null, onclick: () => { V.clips.splice(i, 1); V.clips.splice(i + 1, 0, c); paint(); showAt(V.t); } }, 'أخّر ←'),
          c.kind === 'video' ? E('button', { type: 'button', class: 'btn sm', onclick: () => { c.mute = !c.mute; vols(); paint(); } }, c.mute ? '🔊 صوته' : '🔇 كتم') : null,
          E('button', { type: 'button', class: 'btn sm', onclick: () => split(c) }, '✂️ قسّم'),
          E('button', { type: 'button', class: 'btn sm danger', onclick: () => { V.clips.splice(i, 1); V.sel = null; V.tool = null; paint(); showAt(Math.min(V.t, total())); } }, '🗑')));
    }
    if (V.tool === 'text' && T) {
      const ta = E('textarea', { class: 'input ve-ta', rows: 2, maxlength: 160, value: T.text });
      ta.value = T.text; ta.addEventListener('input', () => { T.text = ta.value; frame(); });
      ta.addEventListener('input', () => { const b = root.querySelector('.ve-tx.on'); if (b) b.textContent = `Aa ${T.text.split('\n')[0]}`; });
      const TT = Math.max(total(), 0.5);
      return E('div', { class: 've-panel' }, ta,
        slider('الحجم', T.size, 4, 14, 0.5, (v) => { T.size = v; frame(); }, (v) => N(v)),
        E('div', { class: 've-cols' }, ...COLORS.map((col) => E('button', { type: 'button', class: `ve-col${T.color === col ? ' on' : ''}`, style: { background: col }, 'aria-label': col, onclick: () => { T.color = col; paint(); frame(); } })),
          E('button', { type: 'button', class: `ve-box${T.box ? ' on' : ''}`, onclick: () => { T.box = !T.box; paint(); frame(); } }, 'خلفية')),
        E('div', { class: 've-row' }, E('span', { text: 'المكان' }), seg([['top', 'فوق'], ['center', 'وسط'], ['bottom', 'تحت']], T.pos, (v) => { T.pos = v; paint(); frame(); })),
        E('div', { class: 've-row' }, E('span', { text: 'الحركة' }), seg([['fade', 'ظهور'], ['slide', 'صعود'], ['pop', 'نبضة'], ['none', 'بدون']], T.anim, (v) => { T.anim = v; paint(); showAt(T.start + 0.1); })),
        slider('يبدأ', T.start, 0, TT, 0.1, (v, fin) => { T.start = Math.min(v, T.end - 0.3); if (fin) paint(); showAt(T.start + 0.45); }, (v) => `${fmt1(v)}ث`),
        slider('ينتهي', T.end, 0.3, TT, 0.1, (v, fin) => { T.end = Math.max(v, T.start + 0.3); if (fin) paint(); showAt(T.end - 0.45); }, (v) => `${fmt1(v)}ث`),
        E('div', { class: 've-acts' }, E('button', { type: 'button', class: 'btn sm', onclick: () => { const n = { ...T, id: uid(), start: Math.min(T.end, TT - 1), end: Math.min(TT, T.end + (T.end - T.start)) }; V.texts.push(n); V.sel = { type: 'text', id: n.id }; paint(); } }, '⧉ نسخ'),
          E('button', { type: 'button', class: 'btn sm danger', onclick: () => { V.texts = V.texts.filter((x) => x !== T); V.sel = null; V.tool = null; paint(); frame(); } }, '🗑 حذف')));
    }
    if (V.tool === 'music') {
      return E('div', { class: 've-panel' },
        V.music ? E('div', { class: 've-ph-t' }, E('b', { text: `🎵 ${V.music.name}` }), E('small', { text: 'يتكرر لو أقصر من الفيديو' })) : E('p', { class: 'hint', text: 'أضف موسيقى من جوالك (MP3 أو M4A) — استخدم بس الأصوات اللي لك حق فيها.' }),
        E('div', { class: 've-acts' }, E('button', { type: 'button', class: 'btn sm', onclick: () => pick('audio/*', false, ([f]) => setMusic(f)) }, V.music ? '🔁 غيّرها' : '＋ اختر موسيقى'),
          V.music ? E('button', { type: 'button', class: 'btn sm danger', onclick: () => { V.music.el.pause(); URL.revokeObjectURL(V.music.url); V.music = null; paint(); } }, '🗑 شيلها') : null),
        V.music ? slider('صوت الموسيقى', V.music.vol, 0, 1, 0.05, (v) => { V.music.vol = v; vols(); }, (v) => `${N(Math.round(v * 100))}٪`) : null,
        slider('صوت المقاطع', V.clipVol, 0, 1, 0.05, (v) => { V.clipVol = v; vols(); }, (v) => `${N(Math.round(v * 100))}٪`));
    }
    if (V.tool === 'size') {
      return E('div', { class: 've-panel' },
        E('div', { class: 've-sizes' }, ...Object.entries(RATIOS).map(([k, [l, a, b]]) => E('button', { type: 'button', class: V.ratio === k ? 'on' : '', onclick: () => { V.ratio = k; paint(); frame(); } }, E('i', { style: { aspectRatio: `${a}/${b}` } }), l, E('small', { class: 'num', text: `${N(a)}:${N(b)}` })))),
        E('div', { class: 've-row' }, E('span', { text: 'الخلفية' }), seg([['blur', 'مموّهة'], ['black', 'أسود'], ['white', 'أبيض']], V.bg, (v) => { V.bg = v; paint(); frame(); })),
        E('label', { class: 've-chk' }, (() => { const i = E('input', { type: 'checkbox', checked: V.fade || null }); i.addEventListener('change', () => { V.fade = i.checked; frame(); }); return i; })(), E('span', { text: 'انتقال ناعم بين المقاطع' })));
    }
    return E('div', { class: 've-panel ve-hint' }, E('p', { text: V.clips.length ? 'اختر مقطع من الخط الزمني تعدّله، أو أضف نص وموسيقى من الأدوات.' : 'ابدأ بإضافة مقاطع فيديو أو صور من جوالك — كل شي يصير على جهازك بدون رفع.' }));
  }
  async function split(c) {
    const i = V.clips.indexOf(c), { i: ai, local } = at(V.t);
    if (ai !== i || local < 0.2 || len(c) - local < 0.2) return toast('حرّك المؤشر لنص المقطع وبعدين قسّم');
    const cut = c.in + local, b = { ...c, id: uid(), in: cut };
    if (c.kind === 'video') { const el = c.el.cloneNode(); el.src = c.url; el.setAttribute('playsinline', ''); await new Promise((r) => { el.onloadeddata = r; el.load(); setTimeout(r, 2500); }); b.el = el; wire(el, V.clipVol); }
    c.out = cut; V.clips.splice(i + 1, 0, b); V.sel = { type: 'clip', id: b.id }; paint(); showAt(V.t);
  }
  function setMusic(f) {
    if (V.music) { V.music.el.pause(); URL.revokeObjectURL(V.music.url); }
    const url = URL.createObjectURL(f), el = new Audio(url); el.loop = true; el.preload = 'auto'; el.crossOrigin = 'anonymous';
    V.music = { url, el, vol: 0.8, name: f.name.replace(/\.[^.]+$/, '').slice(0, 28) }; wire(el, 0.8); vols(); V.tool = 'music'; paint();
  }
  function addText() {
    const T = total() || 3, st = clamp(V.t, 0, Math.max(0, T - 0.5));
    const t = { id: uid(), text: 'اكتب هنا', size: 8, color: '#FFFFFF', pos: 'center', anim: 'slide', box: false, start: st, end: Math.min(T, st + 3) };
    V.texts.push(t); V.sel = { type: 'text', id: t.id }; V.tool = 'text'; paint(); showAt(st + 0.5);
    setTimeout(() => root.querySelector('.ve-ta')?.select(), 60);
  }
  function paint() {
    if (!root) return;
    const tools = [['clip', 'image', 'مقطع', () => { if (!V.clips.length) return pick('video/*,image/*', true, addFiles); V.sel = V.sel?.type === 'clip' ? V.sel : { type: 'clip', id: V.clips[at(V.t).i].id }; V.tool = 'clip'; paint(); }],
      ['add', 'plus', 'إضافة', () => pick('video/*,image/*', true, addFiles)],
      ['text', 'type', 'نص', addText],
      ['music', 'bell', 'موسيقى', () => { V.tool = 'music'; V.sel = null; paint(); }],
      ['size', 'grid', 'المقاس', () => { V.tool = 'size'; V.sel = null; paint(); }]];
    const keepScroll = root.querySelector('.ve-tl')?.scrollLeft;
    root.querySelector('.ve-bottom').replaceChildren(
      timeline(),
      panel(),
      E('nav', { class: 've-tools' }, ...tools.map(([k, ic, l, fn]) => E('button', { type: 'button', class: V.tool === k ? 'on' : '', onclick: fn }, E('span', {}, icon2(ic, 20)), l))));
    if (keepScroll != null) root.querySelector('.ve-tl').scrollLeft = keepScroll;
    root.querySelector('.ve-stage').style.aspectRatio = `${RATIOS[V.ratio][1]}/${RATIOS[V.ratio][2]}`;
    root.querySelector('.ve-empty').hidden = V.clips.length > 0;
    if (typeof UI !== 'undefined') UI.digitize?.(root.querySelector('.ve-bottom'));
    frame();
  }
  async function close() {
    if (V?.exporting) { V.cancel = true; return; }
    if (V?.clips.length && !(await (typeof confirmSheet === 'function' ? confirmSheet({ title: 'تطلع من المحرّر؟', text: 'الفيديو ما ينحفظ لين تصدّره.', ok: 'اطلع' }) : Promise.resolve(confirm('تطلع؟'))))) return;
    pause();
    V?.clips.forEach((c) => { try { c.el.pause?.(); } catch { /* لا شيء */ } URL.revokeObjectURL(c.url); });
    if (V?.music) { V.music.el.pause(); URL.revokeObjectURL(V.music.url); }
    root?.remove(); root = null; V = null; cv = null;
    document.body.classList.remove('ve-open');
  }
  function open() {
    if (root) return;
    V = fresh();
    root = E('section', { class: 've', role: 'dialog', 'aria-label': 'محرّر الفيديو' },
      E('header', { class: 've-top' },
        E('button', { type: 'button', class: 've-ib', 'aria-label': 'إغلاق', onclick: close }, '✕'),
        E('b', { text: '🎬 محرّر الفيديو' }),
        E('button', { type: 'button', class: 've-export', onclick: exportVideo }, 'تصدير')),
      E('div', { class: 've-mid' },
        E('div', { class: 've-stage' }, (cv = E('canvas', { class: 've-cv' })),
          E('button', { type: 'button', class: 've-empty', onclick: () => pick('video/*,image/*', true, addFiles) }, E('b', { text: '＋' }), E('span', { text: 'أضف مقاطع أو صور' }), E('small', { text: 'تقدر تختار أكثر من ملف' })))),
      E('div', { class: 've-ctl' }, E('button', { type: 'button', class: 've-play', onclick: () => (V.playing ? pause() : play()) }, '▶'), E('span', { class: 've-time num', text: '0:00 / 0:00' })),
      E('div', { class: 've-bottom' }),
      E('div', { class: 've-busy', hidden: true }, E('i'), E('span', { text: '' })),
      E('div', { class: 've-exp', hidden: true }, E('div', { class: 've-exp-c' }, E('b', { class: 'num', text: '٠٪' }), E('div', { class: 've-exp-bar' }, E('i')), E('p', { text: 'يسجّل الفيديو… خلّ الشاشة مفتوحة' }),
        E('button', { type: 'button', class: 'btn btn-ghost sm', onclick: () => { V.cancel = true; } }, 'إلغاء'))));
    ctx = cv.getContext('2d');
    document.body.append(root); document.body.classList.add('ve-open');
    paint();
  }
  return { open, close, isOpen: () => !!root, _state: () => V, _add: addFiles };
})();
