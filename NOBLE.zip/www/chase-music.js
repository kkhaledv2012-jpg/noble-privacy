/* NOBLE — موسيقى المطاردة: مؤلَّفة داخل التطبيق لكل طريق (مقامات وإيقاعات بطابع يمني) وتعمل بدون نت
 * عود (نقر وتر) + طبلة (دُم/تَك) + قرار منخفض. أو رابط موسيقى يملكه المالك من لوحة التحكم.
 */
'use strict';
var ChaseMusic = (() => {
  const SCALES = {
    hijaz: [0, 1, 4, 5, 7, 8, 10, 12],
    bayati: [0, 1.5, 3, 5, 7, 8, 10, 12], // ربع تون
    kurd: [0, 1, 3, 5, 7, 8, 10, 12],
    nahawand: [0, 2, 3, 5, 7, 8, 11, 12],
    saba: [0, 1.5, 3, 4, 7, 8, 10, 12],
  };
  /* D = دُم (منخفض) · T = تَك (عالٍ) · k = تَك خفيف */
  const RHYTHMS = {
    sanaani: 'D..TkTD.T.Tk',
    lahji: 'D.TkD.TTD.TkD.T.',
    dan: 'D..TD.TkD..TD.TT',
    island: 'D...k.T.D...k.Tk',
    fog: 'D.......T.....k.',
  };
  const TRACKS = {
    sanaa: { name: 'ليل صنعاء', bpm: 96, root: 146.83, scale: 'hijaz', rhythm: 'sanaani', seed: 3, lead: 0.9 },
    aden: { name: 'موج عدن', bpm: 122, root: 164.81, scale: 'bayati', rhythm: 'lahji', seed: 7, lead: 1 },
    socotra: { name: 'جزيرة', bpm: 88, root: 174.61, scale: 'kurd', rhythm: 'island', seed: 11, lead: 0.8 },
    shibam: { name: 'دان حضرمي', bpm: 104, root: 130.81, scale: 'saba', rhythm: 'dan', seed: 5, lead: 1 },
    mountains: { name: 'ضباب', bpm: 78, root: 146.83, scale: 'nahawand', rhythm: 'fog', seed: 13, lead: 0.7 },
  };
  let ac = null, out = null, timer = 0, nextT = 0, step = 0, cur = null, el = null, vol = 0.32, phrase = [];
  const ctx = () => (ac = ac || new (window.AudioContext || window.webkitAudioContext)());
  const freq = (root, semi, oct = 0) => root * Math.pow(2, (semi + oct * 12) / 12);
  function rng(seed) { let s = seed * 9301 + 49297; return () => ((s = (s * 9301 + 49297) % 233280) / 233280); }

  /* جملة لحنية من المقام (تتكرر وتتنوّع) */
  function makePhrase(t, bars = 2) {
    const r = rng(t.seed + Math.floor(Math.random() * 3));
    const sc = SCALES[t.scale];
    const steps = (RHYTHMS[t.rhythm].length) * bars;
    const out = [];
    let deg = 4;
    for (let i = 0; i < steps; i++) {
      const strong = i % 4 === 0;
      if (r() < (strong ? 0.75 : 0.32)) {
        deg = Math.max(0, Math.min(sc.length - 1, deg + Math.round((r() - 0.5) * 3)));
        out.push({ i, semi: sc[deg] + (r() < 0.15 ? 12 : 0), len: strong ? 0.5 : 0.25, trill: r() < 0.12 });
      }
    }
    // القفلة على الأساس
    out.push({ i: steps - 2, semi: 0, len: 0.8 });
    return out;
  }
  function oud(t, f, at, len, v = 0.18) {
    const o1 = ac.createOscillator(), o2 = ac.createOscillator(), g = ac.createGain(), lp = ac.createBiquadFilter();
    o1.type = 'sawtooth'; o2.type = 'triangle';
    o1.frequency.setValueAtTime(f * 1.012, at); o1.frequency.exponentialRampToValueAtTime(f, at + 0.03);
    o2.frequency.setValueAtTime(f * 2.003, at);
    lp.type = 'lowpass'; lp.frequency.setValueAtTime(2600, at); lp.frequency.exponentialRampToValueAtTime(700, at + len); lp.Q.value = 6;
    g.gain.setValueAtTime(0.0001, at); g.gain.exponentialRampToValueAtTime(v, at + 0.008); g.gain.exponentialRampToValueAtTime(0.0001, at + len + 0.25);
    o1.connect(lp); o2.connect(lp); lp.connect(g).connect(out);
    o1.start(at); o2.start(at); o1.stop(at + len + 0.3); o2.stop(at + len + 0.3);
  }
  function drum(kind, at) {
    if (kind === 'D') {
      const o = ac.createOscillator(), g = ac.createGain();
      o.type = 'sine'; o.frequency.setValueAtTime(130, at); o.frequency.exponentialRampToValueAtTime(52, at + 0.18);
      g.gain.setValueAtTime(0.55, at); g.gain.exponentialRampToValueAtTime(0.001, at + 0.3);
      o.connect(g).connect(out); o.start(at); o.stop(at + 0.32);
    } else {
      const len = kind === 'T' ? 0.07 : 0.04;
      const b = ac.createBuffer(1, Math.floor(ac.sampleRate * len), ac.sampleRate);
      const d = b.getChannelData(0);
      for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / d.length, 3);
      const s = ac.createBufferSource(), hp = ac.createBiquadFilter(), g = ac.createGain();
      s.buffer = b; hp.type = 'bandpass'; hp.frequency.value = kind === 'T' ? 3200 : 5200; hp.Q.value = 1.2;
      g.gain.value = kind === 'T' ? 0.5 : 0.22;
      s.connect(hp).connect(g).connect(out); s.start(at);
    }
  }
  let drone = null;
  function startDrone(t) {
    stopDrone();
    const o = ac.createOscillator(), o2 = ac.createOscillator(), g = ac.createGain(), lfo = ac.createOscillator(), lg = ac.createGain();
    o.type = 'triangle'; o.frequency.value = t.root / 2; o2.type = 'sine'; o2.frequency.value = (t.root / 2) * 1.5;
    g.gain.value = 0.06; lfo.frequency.value = 0.15; lg.gain.value = 0.025;
    lfo.connect(lg).connect(g.gain); o.connect(g); o2.connect(g); g.connect(out);
    o.start(); o2.start(); lfo.start();
    drone = { stop: () => { try { o.stop(); o2.stop(); lfo.stop(); } catch { /* لا شيء */ } } };
  }
  function stopDrone() { drone?.stop(); drone = null; }

  function tick() {
    if (!cur || !ac) return;
    const t = cur, R = RHYTHMS[t.rhythm], spb = 60 / t.bpm / 4; // سادس عشر
    while (nextT < ac.currentTime + 0.14) {
      const k = R[step % R.length];
      if (k !== '.') drum(k, nextT);
      const total = R.length * 2;
      const pos = step % total;
      if (pos === 0 && Math.floor(step / total) % 2 === 0) phrase = makePhrase(t);
      for (const n of phrase) if (n.i === pos) {
        oud(t, freq(t.root, n.semi, 1), nextT, n.len * spb * 4, 0.16 * t.lead);
        if (n.trill) oud(t, freq(t.root, n.semi + 1, 1), nextT + spb * 0.5, spb * 0.5, 0.08);
      }
      nextT += spb; step++;
    }
  }
  function play(world, url) {
    stop();
    if (url) {
      el = new Audio(url); el.loop = true; el.volume = vol; el.play().catch(() => {});
      return TRACKS[world]?.name || 'موسيقى';
    }
    try {
      ctx();
      if (ac.state === 'suspended') ac.resume();
      out = ac.createGain(); out.gain.value = vol; out.connect(ac.destination);
      cur = TRACKS[world] || TRACKS.sanaa; step = 0; nextT = ac.currentTime + 0.1; phrase = [];
      startDrone(cur);
      timer = setInterval(tick, 25);
    } catch { /* لا صوت */ }
    return cur?.name || '';
  }
  function stop() {
    clearInterval(timer); timer = 0; cur = null;
    stopDrone();
    if (out) { try { out.disconnect(); } catch { /* لا شيء */ } out = null; }
    if (el) { el.pause(); el = null; }
  }
  function pause(on) { if (el) on ? el.pause() : el.play().catch(() => {}); if (ac) on ? ac.suspend() : ac.resume(); }
  return { TRACKS, play, stop, pause, ctx: () => ctx() };
})();
