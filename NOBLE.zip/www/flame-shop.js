/* NOBLE — مغامرة اللهب: خزانة البطل، المتجر، الوحوش، وأزرار التحكم */
'use strict';
var Look = (() => {
  const DEF = { color: 'flame', acc: '', trail: 'none', monsters: ['scorp', 'bat', 'crab'], tod: '', ctrl: { style: 'classic', size: 1, opacity: 1, left: false } };
  const TRAILS = { none: 'بدون', flame: 'لهب', stars: 'نجوم', bolt: 'برق' };
  const CTRL = {
    classic: 'كلاسيك دائري', stick: 'عصا تحكم', dpad: 'أسهم كلاسيكية', ghost: 'شفافة بسيطة', big: 'أزرار كبيرة',
  };
  const CATS = () => ({ colors: Object.keys(HERO_COLORS), acc: Object.keys(HERO_ACC), trails: Object.keys(TRAILS), monsters: MONSTERS.map((m) => m.id) });
  const shop = () => GCfg.get().flame.shop || {};

  function get() {
    const l = gstate().look || {};
    return {
      ...DEF, ...l,
      ctrl: { ...DEF.ctrl, ...(l.ctrl || {}) },
      owned: l.owned || {},
      monsters: Array.isArray(l.monsters) && l.monsters.length ? l.monsters : DEF.monsters,
    };
  }
  const totalStars = () => Object.values(gstate().flame.stars || {}).reduce((a, b) => a + b, 0);
  function item(cat, id) {
    const c = (shop()[cat] || {})[id] || {};
    return { on: c.on !== false, price: Math.max(0, Number(c.price) || 0), stars: Math.max(0, Number(c.stars) || 0), pro: c.pro === true }; // pro = شكل ذهبي لمشتركي Pro
  }
  function owns(cat, id) {
    const it = item(cat, id);
    if ((get().owned[cat] || []).includes(id)) return true;
    if (it.stars) return totalStars() >= it.stars;
    return it.price === 0;
  }
  function balance() {
    const g = gstate();
    return Math.max(0, (g.flame.beans || 0) + (g.wallet?.gift || 0) - (g.wallet?.spent || 0));
  }
  const nameOf = (cat, id) => !id ? 'بدون' : cat === 'colors' ? HERO_COLORS[id]?.name : cat === 'acc' ? HERO_ACC[id]?.name : cat === 'trails' ? TRAILS[id] : (shop().monsters?.[id]?.name || monsterById(id).name);

  async function set(patch) {
    await gsave((x) => {
      const lk = x.look || {};
      x.look = { ...lk, ...patch, ctrl: patch.ctrl ? { ...DEF.ctrl, ...(lk.ctrl || {}), ...patch.ctrl } : lk.ctrl };
    });
  }
  async function buy(cat, id) {
    const it = item(cat, id);
    if (owns(cat, id)) return true;
    if (it.pro && typeof Pro !== 'undefined' && !Pro.has('games.gold')) { Pro.gate('games.gold', `«${nameOf(cat, id)}» شكل ذهبي لمشتركي Pro`); return false; }
    if (it.stars) { toast(`يُفتح عند جمع ${UI.n(it.stars)} نجوم في مغامرة اللهب`); return false; }
    const bal = balance();
    if (bal < it.price) { toast(`تحتاج ${UI.n(it.price - bal)} حبة بن إضافية — اجمعها في المراحل ☕`); return false; }
    const ok = await confirmSheet({ title: `شراء «${nameOf(cat, id)}»؟`, text: `سيُخصم ${UI.n(it.price)} حبة بن من رصيدك (${UI.n(bal)}).`, ok: 'شراء', tone: 'primary' });
    if (!ok) return false;
    await gsave((x) => {
      x.wallet = { ...(x.wallet || {}), spent: (x.wallet?.spent || 0) + it.price };
      const lk = x.look || {};
      const ow = { ...(lk.owned || {}) };
      ow[cat] = [...new Set([...(ow[cat] || []), id])];
      x.look = { ...lk, owned: ow };
    });
    Sync.event('shop_buy', { cat, id, name: nameOf(cat, id), price: it.price });
    buzz('success');
    toast(`صار لك «${nameOf(cat, id)}» 🎉`, { type: 'success' });
    return true;
  }
  /* أشكال الوحوش الفعلية في المرحلة (مختارة + مفعّلة + مملوكة) */
  function skins() {
    const usable = (id) => item('monsters', id).on && owns('monsters', id);
    const chosen = get().monsters.filter((id) => MONSTERS.some((m) => m.id === id) && usable(id));
    const pick = (fly) => {
      const list = chosen.filter((id) => !!monsterById(id).fly === fly);
      if (list.length) return list;
      const alt = MONSTERS.filter((m) => !!m.fly === fly && usable(m.id)).map((m) => m.id);
      return alt.length ? [alt[0]] : [fly ? 'bat' : 'scorp'];
    };
    return { walk: pick(false), fly: pick(true) };
  }

  /* ================= خزانة البطل ================= */
  const beanChip = () => h('span', { class: 'chip g-chip fl-bean' }, h('i', { class: 'bean' }), UI.n(balance()));
  function openCloset(tab = 'colors', back) {
    const l = get();
    const hero = myHero();
    openScreen((el) => {
      const stage = h('div', { class: 'cl-stage' },
        h('span', { class: 'cl-ped' }),
        l.trail !== 'none' ? h('span', { class: `cl-trail tr-${l.trail}` }, ...[0, 1, 2, 3].map((i) => h('i', { style: { '--i': i } }))) : null,
        h('span', { class: 'cl-hero' }, heroNode(hero, 118, 'run1', l)),
        h('span', { class: 'cl-tag' }, `${heroById(hero).name} · ${HERO_COLORS[l.color]?.name || ''}${l.acc ? ' + ' + HERO_ACC[l.acc]?.name : ''}${l.trail !== 'none' ? ' + أثر ' + TRAILS[l.trail] : ''}`));
      const tabs = h('div', { class: 'cl-tabs' }, ...[['colors', 'الألوان'], ['acc', 'الإكسسوارات'], ['trails', 'الأثر'], ['monsters', 'الوحوش']].map(([k, t]) =>
        h('button', { type: 'button', class: k === tab ? 'on' : '', onclick: () => openCloset(k, back) }, t)));
      const body = h('div', { class: 'cl-body' });
      const price = (cat, id) => {
        const it = item(cat, id);
        if (owns(cat, id)) return h('span', { class: 'cl-pr own', text: it.price || it.stars ? 'مملوك' : 'مجاني' });
        if (it.pro && typeof Pro !== 'undefined' && !Pro.has('games.gold')) return h('span', { class: 'cl-pr pro-lock', text: '★ Pro' });
        return h('span', { class: 'cl-pr' }, it.stars ? `⭐ ${UI.n(it.stars)} نجوم` : [h('i', { class: 'bean' }), UI.n(it.price)]);
      };
      const tile = (cat, id, art, isOn, onPick) => {
        const it = item(cat, id);
        if (!it.on) return null;
        const own = owns(cat, id);
        return h('button', { type: 'button', class: `cl-it${isOn ? ' on' : ''}${own ? '' : ' locked'}`, onclick: async () => { if (!own && !(await buy(cat, id))) return; await onPick(); openCloset(tab, back); } },
          isOn ? h('span', { class: 'cl-ok', text: '✓' }) : !own ? h('span', { class: 'cl-lk', text: '🔒' }) : null,
          art, h('b', { text: nameOf(cat, id) }), price(cat, id));
      };
      if (tab === 'colors') {
        body.append(h('p', { class: 'cl-t', text: 'ألوان الملابس' }), h('div', { class: 'cl-grid' }, ...Object.entries(HERO_COLORS).map(([id, c]) =>
          tile('colors', id, h('span', { class: 'cl-sw', style: { background: `radial-gradient(circle at 35% 30%, #fff9, transparent 42%), linear-gradient(135deg, ${c.a}, ${c.b} 55%, ${c.c})` } }), l.color === id, () => set({ color: id })))));
      } else if (tab === 'acc') {
        body.append(h('p', { class: 'cl-t', text: 'الإكسسوارات — تظهر على بطلك في كل الألعاب' }), h('div', { class: 'cl-grid' },
          tile('acc', '', h('span', { class: 'cl-sw none', text: '∅' }), !l.acc, () => set({ acc: '' })) || null,
          ...Object.keys(HERO_ACC).map((id) => tile('acc', id, h('span', { class: 'cl-acc' }, heroNode(hero, 54, 'stand', { ...l, acc: id })), l.acc === id, () => set({ acc: id })))));
      } else if (tab === 'trails') {
        body.append(h('p', { class: 'cl-t', text: 'أثر الحركة — يظهر خلف بطلك وهو يجري ويقفز' }), h('div', { class: 'cl-grid' }, ...Object.keys(TRAILS).map((id) =>
          tile('trails', id, h('span', { class: `cl-trail sm tr-${id}` }, ...(id === 'none' ? [h('b', { text: '∅' })] : [0, 1, 2, 3].map((i) => h('i', { style: { '--i': i } })))), l.trail === id, () => set({ trail: id })))));
      } else {
        const sel = new Set(l.monsters);
        body.append(h('p', { class: 'cl-t', text: 'اختر حتى ٣ أشكال تظهر لك في المراحل — الطائرة تحلّق، والباقي يمشي أو يقفز' }),
          h('div', { class: 'cl-mgrid' }, ...MONSTERS.map((m) => {
            const it = item('monsters', m.id);
            if (!it.on) return null;
            const own = owns('monsters', m.id), on = sel.has(m.id);
            const cfg = shop().monsters?.[m.id] || {};
            return h('button', { type: 'button', class: `cl-mon${on ? ' on' : ''}${own ? '' : ' locked'}`, onclick: async () => {
              if (!own && !(await buy('monsters', m.id))) return;
              const s = new Set(get().monsters);
              if (s.has(m.id)) { if (s.size <= 1) return toast('اختر شكلاً واحداً على الأقل'); s.delete(m.id); }
              else { if (s.size >= 3) return toast('الحد ٣ أشكال — ألغِ واحداً أولاً'); s.add(m.id); }
              await set({ monsters: [...s] });
              openCloset(tab, back);
            } },
              on ? h('span', { class: 'cl-mtag', text: '✓ مختار' }) : !own ? h('span', { class: 'cl-mtag lock' }, it.stars ? `⭐ ${UI.n(it.stars)}` : `🔒 ${UI.n(it.price)} حبة`) : null,
              h('span', { class: 'cl-mart' }, (() => { const d = document.createElement('span'); d.innerHTML = monsterSVG(m.id, cfg.c1, cfg.c2).replace('width="120" height="72"', 'width="100%" height="100%"'); return d; })()),
              h('b', { text: nameOf('monsters', m.id) }), h('small', { text: cfg.desc || m.desc }), h('span', { class: 'cl-kind', text: m.fly ? '🪽 طائر' : m.hop ? '↕️ يقفز' : '🐾 يمشي' }));
          })));
      }
      el.append(h('div', { class: 'g-wrap cl-wrap' }, gHead(tab === 'monsters' ? 'اختر وحوشك' : 'خزانة البطل', beanChip(), () => (back ? back() : closeScreen())), tab === 'monsters' ? null : stage, tabs, body));
      UI.digitize(el);
    }, { onBack: () => (back ? back() : closeScreen()) });
  }

  /* ================= أزرار التحكم ================= */
  const PV = {
    classic: '<span class="pb" style="left:8px;bottom:8px;width:52px;height:52px;background:rgb(255 255 255/.12);border:1.5px solid rgb(255 255 255/.3)">◀ ▶</span><span class="pb" style="right:46px;bottom:10px;width:30px;height:30px;background:rgb(240 146 47/.55)">🔥</span><span class="pb" style="right:8px;bottom:18px;width:36px;height:36px;background:var(--grad-flame);color:#1a0e04">قفز</span>',
    stick: '<span class="pb" style="left:10px;bottom:6px;width:58px;height:58px;background:rgb(255 255 255/.1);border:1.5px solid rgb(255 255 255/.25)"><i style="width:26px;height:26px;border-radius:50%;background:radial-gradient(circle at 35% 30%,#fff,#9AB0FF)"></i></span><span class="pb" style="right:46px;bottom:10px;width:30px;height:30px;background:rgb(240 146 47/.55)">🔥</span><span class="pb" style="right:8px;bottom:18px;width:36px;height:36px;background:var(--grad-flame);color:#1a0e04">⤒</span>',
    dpad: '<span style="position:absolute;left:10px;bottom:6px;display:grid;grid-template-columns:repeat(3,18px);gap:2px">' + ['', '▲', '', '◀', '', '▶'].map((x) => `<i style="height:18px;border-radius:4px;display:grid;place-items:center;font-size:9px;font-style:normal;background:${x ? 'rgb(255 255 255/.25)' : 'transparent'}">${x}</i>`).join('') + '</span><span class="pb" style="right:8px;bottom:18px;width:28px;height:28px;border-radius:8px;background:#E5484D">A</span><span class="pb" style="right:40px;bottom:8px;width:28px;height:28px;border-radius:8px;background:#F0922F">B</span>',
    ghost: '<span class="pb" style="left:10px;bottom:10px;width:30px;height:30px;border:1.5px solid rgb(255 255 255/.5)">◀</span><span class="pb" style="left:44px;bottom:10px;width:30px;height:30px;border:1.5px solid rgb(255 255 255/.5)">▶</span><span class="pb" style="right:46px;bottom:10px;width:24px;height:24px;border:1.5px solid rgb(255 255 255/.5);font-size:10px">🔥</span><span class="pb" style="right:10px;bottom:10px;width:32px;height:32px;border:1.5px solid rgb(255 255 255/.5)">⤒</span>',
    big: '<span class="pb" style="left:0;bottom:0;width:48%;height:40px;border-radius:0 14px 0 0;background:rgb(255 255 255/.14)">◀ ▶</span><span class="pb" style="right:0;bottom:0;width:48%;height:40px;border-radius:14px 0 0 0;background:rgb(46 91 255/.6)">قفز</span><span class="pb" style="right:14px;bottom:46px;width:24px;height:24px;background:rgb(240 146 47/.6);font-size:10px">🔥</span>',
  };
  function openControls(back) {
    const c = get().ctrl;
    openScreen((el) => {
      const range = (label, key, min, max, step, fmt) => {
        const out = h('b', { text: fmt(c[key]) });
        const r = h('input', { type: 'range', min, max, step, value: c[key], class: 'cl-range' });
        r.addEventListener('input', () => { out.textContent = fmt(Number(r.value)); });
        r.addEventListener('change', () => set({ ctrl: { [key]: Number(r.value) } }));
        return h('label', { class: 'cl-slider' }, h('span', { class: 'row' }, h('span', { text: label }), out), r);
      };
      const leftSw = h('input', { type: 'checkbox', checked: !!c.left, onchange: (e) => set({ ctrl: { left: e.target.checked } }) });
      el.append(h('div', { class: 'g-wrap cl-wrap' },
        gHead('أزرار التحكم', null, () => (back ? back() : closeScreen())),
        h('div', { class: 'cl-cs' }, ...Object.entries(CTRL).map(([k, name]) => {
          const pv = h('div', { class: 'cl-pv' }); pv.innerHTML = PV[k];
          return h('button', { type: 'button', class: `cl-cc${c.style === k ? ' on' : ''}${k === 'big' ? ' wide' : ''}`, onclick: async () => { await set({ ctrl: { style: k } }); openControls(back); } },
            pv, h('b', { text: name + (c.style === k ? ' ✓' : '') }));
        })),
        range('حجم الأزرار', 'size', 0.8, 1.3, 0.05, (v) => (v < 0.95 ? 'صغير' : v > 1.1 ? 'كبير' : 'عادي')),
        range('الوضوح', 'opacity', 0.35, 1, 0.05, (v) => UI.n(`${Math.round(v * 100)}٪`)),
        h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'وضع اليد اليسرى' }), h('small', { text: 'يقلب مكان الحركة والقفز' })), h('span', { class: 'switch' }, leftSw, h('span', { class: 'track' })))));
      UI.digitize(el);
    }, { onBack: () => (back ? back() : closeScreen()) });
  }

  return { get, set, buy, owns, item, balance, skins, openCloset, openControls, TRAILS, CTRL, nameOf, totalStars };
})();
