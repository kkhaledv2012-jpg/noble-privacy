/* NOBLE — المواقع المميزة (1.15): مواقع تختارها الإدارة تظهر أعلى قسم المواقع
 * المستخدم يفتحها أو يحفظها في خزنته بضغطة. الإعداد من لوحة التحكم ← التطبيقات ← «المواقع المميزة» (Market.featured).
 */
'use strict';
const FEAT_DEF = { on: true, title: '⭐ مواقع مميزة', style: 'row', hideable: true, list: [] };
const featCfg = () => { const m = (typeof Market !== 'undefined' && Market.get().featured) || {}; return { ...FEAT_DEF, ...m, list: Array.isArray(m.list) ? m.list : [] }; };
const featBadge = { new: ['جديد', 'n'], free: 'مجاني', hot: ['رائج 🔥', 'h'], pick: ['اختيارنا', 'p'] };
function featIcon(f, size = 44) {
  const ic = String(f.ic || '');
  if (/^https?:/.test(ic)) return UI.avatar({ name: f.name, url: f.url, favIcon: ic }, size);
  if (ic) return h('span', { class: 'avatar feat-emo', style: { width: size + 'px', height: size + 'px' }, text: ic });
  return UI.avatar({ name: f.name, url: f.url }, size);
}
const featSaved = (url) => { const k = Core.urlKey(Core.normalizeUrl(url) || url); return (S.vault?.items || []).some((it) => Core.urlKey(it.url) === k); };
async function featSave(f, btn) {
  if (featSaved(f.url)) return toast('محفوظ عندك مسبقاً ✓');
  if (typeof Pro !== 'undefined' && !Pro.gate('vault.sites', S.vault.items.length)) return;
  const res = await commit((v) => Core.insertItem(v, { name: f.name, url: Core.normalizeUrl(f.url), note: f.desc || '', category: f.cat || '', tags: 'مميز', status: 'active', favIcon: /^https?:/.test(f.ic || '') ? f.ic : '' }));
  if (!res) return;
  buzz('success');
  toast(`انحفظ «${res.name}» في خزنتك #${res.num} ✓`, { type: 'success' });
  if (btn) { btn.textContent = '✓ محفوظ'; btn.disabled = true; }
  render();
}
/* القسم أعلى المواقع (يختفي وقت البحث أو التصفية) */
function renderFeatured() {
  const view = $('#view-sites');
  if (!view) return;
  let box = $('#featured');
  if (!box) { box = h('section', { class: 'feat', id: 'featured' }); view.insertBefore(box, $('#list-head') || view.querySelector('.list-head') || $('#list')); }
  const C = featCfg();
  const list = C.list.filter((f) => f && f.on !== false && f.url);
  const filtering = !!(S.filter?.q || (S.filter?.chip && S.filter.chip !== 'all') || S.filter?.cat);
  if (!C.on || !list.length || filtering) { box.hidden = true; return; }
  box.hidden = false;
  const closed = C.hideable && pref('featHidden');
  const head = h('div', { class: 'feat-h' }, h('b', { text: C.title || FEAT_DEF.title }), h('small', { class: 'num', text: UI.n(list.length) }), h('span', { class: 'spacer' }),
    C.hideable ? h('button', { type: 'button', class: 'link-btn', onclick: () => setPref({ featHidden: !closed }).then(renderFeatured) }, closed ? 'عرض ▾' : 'إخفاء ▴') : null);
  if (closed) { box.replaceChildren(head); return; }
  const card = (f) => {
    const saved = featSaved(f.url);
    const b = featBadge[f.badge];
    const save = h('button', { type: 'button', class: `btn sm feat-save${saved ? ' on' : ''}`, disabled: saved, onclick: (e) => { e.stopPropagation(); featSave(f, e.currentTarget); } }, saved ? '✓ محفوظ' : '＋ احفظ');
    return h('article', { class: 'feat-card', onclick: () => Links.open(f.url) },
      b ? h('span', { class: `feat-badge ${Array.isArray(b) ? b[1] : ''}`, text: Array.isArray(b) ? b[0] : b }) : null,
      featIcon(f, C.style === 'grid' ? 40 : 46),
      h('div', { class: 'feat-t' }, h('b', { text: f.name || Core.domainOf(f.url) }), h('small', { text: f.desc || Core.domainOf(f.url) })),
      h('div', { class: 'feat-acts' }, h('button', { type: 'button', class: 'btn sm btn-primary', onclick: (e) => { e.stopPropagation(); Links.open(f.url); } }, 'فتح ↗'), save));
  };
  box.replaceChildren(head, h('div', { class: `feat-${C.style === 'grid' ? 'grid' : 'row'}` }, ...list.map(card)));
  UI.digitize?.(box);
}
