/* NOBLE — لوحة تحكم الألعاب (الأسماء، العروض، النقاط، الأبطال، المراحل، الصدارة) */
'use strict';
const GA = { data: null, dirty: false, sec: 'look', period: 'all', rows: null, q: '' };
const GAME_KEYS = { word: 'كلمة اليوم', daily: 'التفاعل اليومي', xo: 'إكس أو', flame: 'مغامرة اللهب', chase: 'المطاردة', tasks: 'نقاط المهام' };
const LEVEL_IDS = ['1-1', '1-2', '1-3'];
const LEVEL_IDS2 = ['2-1', '2-2', '2-3'];

const getP = (o, path) => path.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
function setP(o, path, v) {
  const ks = path.split('.');
  let t = o;
  ks.slice(0, -1).forEach((k) => { if (typeof t[k] !== 'object' || t[k] === null) t[k] = {}; t = t[k]; });
  t[ks[ks.length - 1]] = v;
}
const clone = (x) => JSON.parse(JSON.stringify(x));

async function openGamesAdmin() {
  const box = $('#a-games');
  if (!GA.data) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      const conf = await Cloud.getConfig();
      GA.data = GCfg.merge(clone(GCfg.DEFAULTS), conf?._games || {});
      GA.updated = conf?._updated;
      GA.noColumn = conf && !('_games' in conf);
    } catch (e) {
      GA.data = clone(GCfg.DEFAULTS);
      toast('تعذّر التحميل: ' + Cloud.msg(e), { type: 'error' });
    }
  }
  renderGA();
}

/* ---------- عناصر مساعدة ---------- */
function field(label, path, opt = {}) {
  const v = getP(GA.data, path);
  const input = opt.area
    ? h('textarea', { class: 'input textarea', rows: opt.rows || 2, maxlength: opt.max || 200 })
    : h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, type: opt.type || 'text', maxlength: opt.max || 60, min: opt.min, max: opt.maxv, step: opt.step, placeholder: opt.ph || '' });
  input.value = v ?? '';
  input.addEventListener('input', () => { setP(GA.data, path, opt.type === 'number' ? Number(input.value) : input.value); changedGA(); });
  return h('label', { class: 'field' }, h('span', { text: label }), input, opt.hint ? h('small', { class: 'hint', text: opt.hint }) : null);
}
function toggle(label, path, sub, onChange) {
  const sw = h('input', { type: 'checkbox', checked: getP(GA.data, path) !== false });
  sw.addEventListener('change', () => { setP(GA.data, path, sw.checked); changedGA(); onChange?.(); });
  return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, sw, h('span', { class: 'track' })));
}
function segOf(name, path, opts, onChange) {
  const cur = String(getP(GA.data, path));
  return h('div', { class: `seg seg-${opts.length}` }, ...opts.map(([v, l]) => {
    const r = h('input', { type: 'radio', name, value: v, checked: String(v) === cur });
    r.addEventListener('change', () => { setP(GA.data, path, typeof v === 'number' ? v : v); changedGA(); onChange?.(); });
    return h('label', {}, r, h('span', { text: l }));
  }));
}
const gaCard = (title, ...kids) => h('div', { class: 'set-card ga-card' }, title ? h('strong', { class: 'ga-ct', text: title }) : null, ...kids);

function changedGA() {
  GA.dirty = true;
  const st = $('#ga-status');
  if (st) st.textContent = 'تعديلات غير منشورة';
  $('#ga-save')?.classList.add('pulse');
  paintEventPreview();
}

/* ---------- الإطار ---------- */
const GA_SECS = [['look', 'العرض والأسماء', 'edit'], ['event', 'العروض', 'bolt'], ['points', 'النقاط', 'trophy'], ['heroes', 'الأبطال', 'users'], ['levels', 'المراحل والعوالم', 'layers'], ['shop', 'المتجر والأشكال', 'tag'], ['chase', 'المطاردة', 'flag'], ['word', 'كلمة اليوم', 'edit'], ['daily', 'التفاعل اليومي', 'sun'], ['board', 'الصدارة واللاعبون', 'shield']];
function renderGA() {
  const box = $('#a-games');
  box.replaceChildren(...[
    h('section', { class: 'a-hero' },
      h('div', {}, h('h1', {}, h('span', { class: 'title-pill', text: 'لوحة الألعاب' })),
        h('p', { class: 'lead', text: 'تحكم في أسماء الألعاب والأبطال والمراحل، وأطلق عروض النقاط المضاعفة، وأدر الصدارة — تصل التعديلات للجميع عند فتح التطبيق.' })),
      h('div', { class: 'a-save' }, h('span', { class: 'hint', id: 'ga-status', text: GA.dirty ? 'تعديلات غير منشورة' : GA.updated ? `آخر نشر ${UI.relTime(new Date(GA.updated).getTime())}` : '' }),
        h('button', { type: 'button', class: `btn btn-primary${GA.dirty ? ' pulse' : ''}`, id: 'ga-save', onclick: saveGA }, 'نشر إعدادات الألعاب'))),
    GA.noColumn ? h('p', { class: 'note-box', text: 'شغّل ملف supabase/update-1.3-games.sql في Supabase أولاً حتى يمكن حفظ إعدادات الألعاب.' }) : null,
    h('nav', { class: 'chips ga-nav' }, ...GA_SECS.map(([id, l, ic]) => h('button', { type: 'button', class: `chip${GA.sec === id ? ' on' : ''}`, onclick: () => { GA.sec = id; renderGA(); } }, icon(ic, { size: 15 }), l))),
    h('div', { class: 'ga-body', id: 'ga-body' })].filter(Boolean));
  const body = $('#ga-body');
  ({ look: secLook, event: secEvent, points: secPoints, heroes: secHeroes, levels: secLevels, shop: secShop, chase: secChase, word: secWord, daily: secDaily, board: secBoard })[GA.sec](body);
  UI.digitize(box);
}

/* ---------- العرض والأسماء ---------- */
function secLook(body) {
  const d = GA.data;
  const order = [...new Set([...(d.order || []), 'word', 'xo', 'flame', 'chase'])].filter((k) => ['word', 'xo', 'flame', 'chase'].includes(k));
  const move = (i, dir) => { const o = [...order]; const j = i + dir; if (j < 0 || j >= o.length) return; [o[i], o[j]] = [o[j], o[i]]; d.order = o; changedGA(); renderGA(); };
  body.append(
    gaCard('قسم الألعاب', field('عنوان القسم في التطبيق', 'hubTitle', { max: 30 })),
    ...order.map((k, i) => gaCard(null,
      h('div', { class: 'ga-game-head' },
        h('span', { class: `ga-gic gi-${k}` }, icon({ xo: 'grid', flame: 'bolt', chase: 'flag', word: 'edit' }[k], { size: 20 })),
        h('b', { text: `${i + 1}. ${GAME_KEYS[k]}` }),
        h('div', { class: 'spacer' }),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'لأعلى', disabled: i === 0, onclick: () => move(i, -1) }, icon('arrowUp', { size: 16 })),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'لأسفل', disabled: i === order.length - 1, onclick: () => move(i, 1) }, icon('arrowDown', { size: 16 }))),
      toggle('ظاهرة للمستخدمين', `${k}.on`, 'عند الإيقاف تختفي من قسم الألعاب ولا تُقبل نقاطها'),
      h('div', { class: 'row-2' }, field('اسم اللعبة', `${k}.name`, { max: 30 }), field('وصف قصير', `${k}.desc`, { max: 60 })),
      k === 'xo' ? toggle('اللعب أونلاين', 'xo.online', 'إظهار «تحدّي صديق أونلاين»') : null,
      k === 'xo' ? h('div', { class: 'ga-3' }, field('اسم المستوى السهل', 'xo.levels.easy', { max: 14 }), field('المتوسط', 'xo.levels.medium', { max: 14 }), field('الصعب', 'xo.levels.hard', { max: 14 })) : null)));
}

/* ---------- العروض ---------- */
function toLocalInput(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function secEvent(body) {
  const e = GA.data.event;
  const until = h('input', { class: 'input ltr', type: 'datetime-local', value: toLocalInput(e.until) });
  until.addEventListener('change', () => { e.until = until.value ? new Date(until.value).toISOString() : ''; changedGA(); });
  const quick = (label, hours) => h('button', { type: 'button', class: 'chip', onclick: () => { e.until = new Date(Date.now() + hours * 36e5).toISOString(); e.on = true; changedGA(); renderGA(); } }, label);
  const gamesBox = h('div', { class: 'ga-checks' }, ...Object.entries(GAME_KEYS).map(([k, l]) => {
    const c = h('input', { type: 'checkbox', checked: (e.games || []).includes(k) });
    c.addEventListener('change', () => { const s = new Set(e.games || []); if (c.checked) s.add(k); else s.delete(k); e.games = [...s]; changedGA(); });
    return h('label', { class: 'ga-check' }, c, h('span', { text: l }));
  }));
  const active = e.on && (!e.until || new Date(e.until) > new Date());
  body.append(
    h('div', { class: 'ga-2col' },
      h('div', { class: 'ga-col' },
        gaCard('عرض النقاط المضاعفة',
          toggle('تفعيل العرض الآن', 'event.on', 'يظهر شريط العرض في قسم الألعاب وتتضاعف النقاط', () => renderGA()),
          h('div', { class: `ga-state ${active ? 'on' : ''}`, text: active ? (e.until ? 'العرض فعّال — ' + leftTextA(e.until) : 'العرض فعّال بدون نهاية') : e.on ? 'انتهت مدة العرض' : 'لا يوجد عرض فعّال' }),
          field('عنوان العرض', 'event.title', { max: 40 }),
          field('نص العرض', 'event.text', { area: true, max: 120 }),
          h('div', { class: 'field' }, h('span', { text: 'المضاعف' }), segOf('ga-mult', 'event.mult', [[1.5, '×١٫٥'], [2, '×٢'], [3, '×٣'], [5, '×٥']])),
          h('div', { class: 'field' }, h('span', { text: 'ينتهي في (فارغ = بدون نهاية)' }), until,
            h('div', { class: 'chips ga-quick' }, quick('ساعة', 1), quick('٦ ساعات', 6), quick('يوم', 24), quick('٣ أيام', 72), quick('أسبوع', 168),
              h('button', { type: 'button', class: 'chip', onclick: () => { e.until = ''; changedGA(); renderGA(); } }, 'بدون نهاية'))),
          h('div', { class: 'field' }, h('span', { text: 'يشمل' }), gamesBox))),
      h('div', { class: 'ga-col' },
        gaCard('معاينة في التطبيق', h('div', { id: 'ga-ev-prev' }),
          h('p', { class: 'hint', text: 'تظهر أيضاً شارة ×المضاعف على بطاقة كل لعبة مشمولة. الحد الأقصى للنقاط في الخادم يتضاعف تلقائياً مع العرض.' })))));
  paintEventPreview();
}
function leftTextA(until) {
  const ms = new Date(until).getTime() - Date.now();
  if (ms <= 0) return 'انتهى';
  const d = Math.floor(ms / 864e5), hh = Math.floor((ms % 864e5) / 36e5), mm = Math.floor((ms % 36e5) / 6e4);
  return d ? `باقي ${d} يوم و${hh} ساعة` : hh ? `باقي ${hh} ساعة و${mm} دقيقة` : `باقي ${mm} دقيقة`;
}
function paintEventPreview() {
  const box = $('#ga-ev-prev');
  if (!box) return;
  const e = GA.data.event;
  box.replaceChildren(h('div', { class: `ga-ev${e.on ? '' : ' off'}` },
    h('span', { class: 'ge-mult', text: UI.n('×' + e.mult) }),
    h('div', { class: 'ge-t' }, h('b', { text: e.title || '—' }), h('small', { text: e.text || '' }), e.until ? h('small', { class: 'ge-left', text: leftTextA(e.until) }) : null)));
}

/* ---------- النقاط ---------- */
function secPoints(body) {
  const n = (label, path, hint) => field(label, path, { type: 'number', min: 0, maxv: 100, ltr: true, hint });
  body.append(
    gaCard('إكس أو — ضد الجوال',
      h('div', { class: 'ga-3' }, n('فوز على السهل', 'xo.pts.easy'), n('فوز على المتوسط', 'xo.pts.medium'), n('فوز على الصعب', 'xo.pts.hard')),
      h('div', { class: 'ga-3' }, n('تعادل مع الصعب', 'xo.pts.hardDraw'), n('فوز أونلاين', 'xo.pts.onlineWin'), n('تعادل أونلاين', 'xo.pts.onlineDraw')),
      h('p', { class: 'hint', text: 'الخسارة والمباريات مع صديق على نفس الجوال بدون نقاط. أقصى ما يقبله الخادم ١٠٠ نقطة للدفعة الواحدة.' })),
    gaCard('مغامرة اللهب',
      field('معدّل التحويل: كل كم من النتيجة = نقطة واحدة', 'flame.ptsRate', { type: 'number', min: 1, maxv: 100, ltr: true, hint: 'كلما قلّ الرقم زادت النقاط. النقاط تُحسب على تحسّن أفضل نتيجة لكل مرحلة فقط.' })),
    gaCard('المهام', n('نقاط كل مهمة منجزة', 'tasksPts', 'تُمنح مرة واحدة لكل مهمة. ٠ = إيقاف.')));
}

/* ---------- الأبطال ---------- */
function secHeroes(body) {
  const H = GA.data.heroes;
  H.off = H.off || []; H.names = H.names || {}; H.descs = H.descs || {};
  const grid = h('div', { class: 'ga-heroes' }, ...HEROES.map((x) => {
    const off = H.off.includes(x.id);
    const name = h('input', { class: 'input', maxlength: 20, placeholder: x.name, value: H.names[x.id] || '' });
    name.addEventListener('input', () => { if (name.value.trim()) H.names[x.id] = name.value.trim(); else delete H.names[x.id]; changedGA(); });
    const desc = h('input', { class: 'input', maxlength: 50, placeholder: x.desc, value: H.descs[x.id] || '' });
    desc.addEventListener('input', () => { if (desc.value.trim()) H.descs[x.id] = desc.value.trim(); else delete H.descs[x.id]; changedGA(); });
    const sw = h('input', { type: 'checkbox', checked: !off });
    sw.addEventListener('change', () => {
      const s = new Set(H.off);
      if (sw.checked) s.delete(x.id); else s.add(x.id);
      if (s.size >= HEROES.length) { sw.checked = true; return toast('يجب أن يبقى بطل واحد على الأقل'); }
      H.off = [...s];
      if (H.off.includes(H.def)) H.def = HEROES.find((y) => !H.off.includes(y.id)).id;
      changedGA(); renderGA();
    });
    return h('article', { class: `ga-hero${off ? ' off' : ''}` },
      h('div', { class: 'ga-hero-art' }, heroNode(x.id, 70), H.featured === x.id ? h('span', { class: 'hp-feat', text: 'مميز' }) : null, H.def === x.id ? h('span', { class: 'ga-def', text: 'افتراضي' }) : null),
      h('label', { class: 'field' }, h('span', { text: 'الاسم' }), name),
      h('label', { class: 'field' }, h('span', { text: 'الوصف' }), desc),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'متاح للاختيار' })), h('span', { class: 'switch' }, sw, h('span', { class: 'track' }))),
      h('div', { class: 'btn-grid' },
        h('button', { type: 'button', class: `btn sm${H.def === x.id ? ' btn-primary' : ''}`, disabled: off, onclick: () => { H.def = x.id; changedGA(); renderGA(); } }, 'افتراضي'),
        h('button', { type: 'button', class: `btn sm${H.featured === x.id ? ' btn-primary' : ''}`, disabled: off, onclick: () => { H.featured = H.featured === x.id ? '' : x.id; changedGA(); renderGA(); } }, '★ مميز')));
  }));
  body.append(h('p', { class: 'hint ga-p', text: 'الافتراضي يُعطى لمن لم يختر بطلاً، ولمن أُوقف بطله. «مميز» يظهر بنجمة في شاشة الاختيار.' }), grid);
}

/* ---------- المراحل والعوالم ---------- */
function secLevels(body) {
  const F = GA.data.flame;
  F.levels = F.levels || {}; F.locked = F.locked || []; F.worlds = F.worlds || {}; F.worlds[2] = F.worlds[2] || {};
  F.daily = F.daily || { on: true, mult: 2 };
  const lvRows = (ids) => ids.map((id, i) => {
    const nm = h('input', { class: 'input', maxlength: 30, value: F.levels[id] || '' });
    nm.addEventListener('input', () => { F.levels[id] = nm.value; changedGA(); });
    const sw = h('input', { type: 'checkbox', checked: !F.locked.includes(id) });
    sw.addEventListener('change', () => { const st = new Set(F.locked); if (sw.checked) st.delete(id); else st.add(id); F.locked = [...st]; changedGA(); });
    return h('div', { class: 'ga-level' },
      h('span', { class: 'ga-lv-n num', text: id }),
      h('label', { class: 'field' }, h('span', { text: `اسم المرحلة ${i + 1}${id === '2-3' ? ' (فيها الحارس)' : ''}` }), nm),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'متاحة' })), h('span', { class: 'switch' }, sw, h('span', { class: 'track' }))));
  });
  const w2 = (k) => { const inp = h('input', { class: 'input', maxlength: k === 'name' ? 30 : 80, value: F.worlds[2][k] || '' }); inp.addEventListener('input', () => { F.worlds[2][k] = inp.value; changedGA(); }); return inp; };
  body.append(
    gaCard('فتح المراحل',
      h('div', { class: 'field' }, h('span', { text: 'طريقة الفتح' }), segOf('ga-unlock', 'flame.unlock', [['seq', 'بالتسلسل — تنفتح بعد إنهاء السابقة'], ['all', 'كل المراحل مفتوحة']])),
      h('p', { class: 'hint', text: 'بالتسلسل: المرحلة التالية تنفتح عند إنهاء التي قبلها، والعالم الجديد بعد إنهاء كل العالم السابق. تقدر تفتح كل المراحل للاعب معيّن من «الصدارة واللاعبون» ← مكافأة.' })),
    gaCard('وقت اللعب الافتراضي',
      segOf('ga-tod', 'flame.tod', [['level', 'حسب المرحلة'], ['day', 'نهار'], ['dusk', 'غروب'], ['night', 'ليل'], ['auto', 'حسب الساعة']]),
      h('p', { class: 'hint', text: 'يطبَّق على من لم يختر بنفسه. اللاعب يقدر يغيّره من الخريطة أو أثناء اللعب.' })),
    gaCard('تحدّي اليوم',
      toggle('تفعيل تحدّي اليوم', 'flame.daily.on', 'مرحلة مختلفة كل يوم بنقاط مضاعفة لمرة واحدة'),
      h('div', { class: 'field' }, h('span', { text: 'مضاعف النقاط' }), segOf('ga-dmult', 'flame.daily.mult', [[2, '×٢'], [3, '×٣'], [5, '×٥']]))),
    gaCard('العالم ١',
      h('div', { class: 'row-2' }, field('اسم العالم', 'flame.world', { max: 30 }), field('وصف العالم', 'flame.worldDesc', { max: 60 })),
      ...lvRows(LEVEL_IDS)),
    gaCard('العالم ٢ — مدينة الفوانيس',
      h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'اسم العالم' }), w2('name')), h('label', { class: 'field' }, h('span', { text: 'وصف العالم' }), w2('desc'))),
      ...lvRows(LEVEL_IDS2)),
    gaCard('عام',
      field('نص العوالم القادمة', 'flame.soon', { max: 20, hint: 'يظهر على العوالم المقفلة، مثل: قريباً' }),
      h('div', { class: 'field' }, h('span', { text: 'عدد القلوب في كل مرحلة' }), segOf('ga-hearts', 'flame.hearts', [[1, '١'], [2, '٢'], [3, '٣'], [4, '٤'], [5, '٥']]))));
}

/* ---------- المتجر والأشكال ---------- */
function secShop(body) {
  const F = GA.data.flame;
  F.shop = F.shop || {};
  ['colors', 'acc', 'trails', 'monsters'].forEach((k) => { F.shop[k] = F.shop[k] || {}; });
  GA.shopTab = GA.shopTab || 'monsters';
  const cfg = (cat, id) => (F.shop[cat][id] = F.shop[cat][id] || {});
  const num = (cat, id, key, ph) => {
    const c = cfg(cat, id);
    const inp = h('input', { class: 'input num ga-price', type: 'number', min: 0, max: 100000, placeholder: ph, value: c[key] ?? '' });
    inp.addEventListener('input', () => { const v = inp.value === '' ? undefined : Math.max(0, Math.round(Number(inp.value) || 0)); if (v === undefined) delete c[key]; else c[key] = v; changedGA(); });
    return inp;
  };
  const onSw = (cat, id) => {
    const c = cfg(cat, id);
    const sw = h('input', { type: 'checkbox', checked: c.on !== false });
    sw.addEventListener('change', () => { c.on = sw.checked; changedGA(); });
    return h('span', { class: 'switch' }, sw, h('span', { class: 'track' }));
  };
  const color = (cat, id, key, def) => {
    const c = cfg(cat, id);
    const inp = h('input', { type: 'color', class: 'ga-color', value: c[key] || def });
    inp.addEventListener('input', () => { c[key] = inp.value; changedGA(); art(); });
    let art = () => {};
    return [inp, (fn) => { art = fn; }];
  };
  const row = (artEl, name, extra, cat, id) => h('div', { class: 'ga-shop-row' },
    h('span', { class: 'ga-shop-art' }, artEl), h('div', { class: 'ga-shop-t' }, ...name),
    ...extra, h('label', { class: 'ga-shop-f' }, h('small', { text: 'السعر (حبة بن)' }), num(cat, id, 'price', '0 = مجاني')),
    h('label', { class: 'ga-shop-f' }, h('small', { text: 'أو نجوم مطلوبة' }), num(cat, id, 'stars', '—')), onSw(cat, id));
  const tabs = h('div', { class: 'seg seg-4 ga-shop-tabs' }, ...[['monsters', 'الوحوش'], ['colors', 'الألوان'], ['acc', 'الإكسسوارات'], ['trails', 'الأثر']].map(([k, l]) =>
    h('label', {}, h('input', { type: 'radio', name: 'ga-shop', checked: GA.shopTab === k, onchange: () => { GA.shopTab = k; renderGA(); } }), h('span', { text: l }))));
  const list = h('div', { class: 'ga-shop' });
  if (GA.shopTab === 'monsters') {
    MONSTERS.forEach((m) => {
      const c = cfg('monsters', m.id);
      const artBox = h('span', { class: 'ga-mon' });
      const paint = () => { artBox.innerHTML = monsterSVG(m.id, c.c1, c.c2).replace('width="120" height="72"', 'width="100%" height="100%"'); };
      paint();
      const [c1, on1] = color('monsters', m.id, 'c1', m.c1); on1(paint);
      const [c2, on2] = color('monsters', m.id, 'c2', m.c2); on2(paint);
      const nm = h('input', { class: 'input', maxlength: 20, placeholder: m.name, value: c.name || '' });
      nm.addEventListener('input', () => { if (nm.value.trim()) c.name = nm.value.trim(); else delete c.name; changedGA(); });
      list.append(row(artBox, [nm, h('small', { class: 'hint', text: `${m.desc} · ${m.fly ? 'طائر' : m.hop ? 'يقفز' : 'يمشي'}` })], [h('span', { class: 'ga-colors' }, c1, c2)], 'monsters', m.id));
    });
  } else if (GA.shopTab === 'colors') {
    Object.entries(HERO_COLORS).forEach(([id, c]) => list.append(row(h('span', { class: 'ga-sw', style: { background: `linear-gradient(135deg, ${c.a}, ${c.b} 55%, ${c.c})` } }), [h('b', { text: c.name })], [], 'colors', id)));
  } else if (GA.shopTab === 'acc') {
    Object.entries(HERO_ACC).forEach(([id, a]) => list.append(row(heroNode(GA.data.heroes.def || 'lahhoub', 46, 'stand', { acc: id }), [h('b', { text: a.name })], [], 'acc', id)));
  } else {
    Object.entries({ none: 'بدون', flame: 'لهب', stars: 'نجوم', bolt: 'برق' }).forEach(([id, n]) => list.append(row(h('span', { class: 'ga-trail', text: { none: '∅', flame: '🔥', stars: '✦', bolt: '⚡' }[id] }), [h('b', { text: n })], [], 'trails', id)));
  }
  body.append(
    h('p', { class: 'hint ga-p', text: 'اللاعب يشتري الأشكال بحبوب البن التي يجمعها في مغامرة اللهب. السعر ٠ = مجاني. «النجوم المطلوبة» تفتح الشكل تلقائياً عند جمعها بدل الشراء. الإيقاف يخفي الشكل من المتجر ومن اللعبة.' }),
    tabs, list);
}

/* ---------- المطاردة ---------- */
function secChase(body) {
  const C = (GA.data.chase = GA.data.chase || clone(GCfg.DEFAULTS.chase));
  ['worlds', 'cars', 'plates', 'ups'].forEach((k) => { C[k] = C[k] || {}; });
  const hasArt = typeof ChaseArt !== 'undefined' && typeof Chase !== 'undefined';
  const numIn = (obj, key, { min = 0, max = 100000, step = 1, ph = '' } = {}) => {
    const inp = h('input', { class: 'input num ga-price', type: 'number', min, max, step, placeholder: ph, value: obj[key] ?? '' });
    inp.addEventListener('input', () => { if (inp.value === '') delete obj[key]; else obj[key] = Math.max(min, Math.min(max, Number(inp.value) || 0)); changedGA(); });
    return inp;
  };
  const sw = (obj, key, def = true) => {
    const i = h('input', { type: 'checkbox', checked: def ? obj[key] !== false : !!obj[key] });
    i.addEventListener('change', () => { obj[key] = i.checked; changedGA(); });
    return h('span', { class: 'switch' }, i, h('span', { class: 'track' }));
  };
  const lf = (label, el) => h('label', { class: 'ga-shop-f' }, h('small', { text: label }), el);
  const n = (label, path, o = {}) => field(label, path, { type: 'number', ltr: true, ...o });
  // الطرق
  const worlds = h('div', { class: 'ga-shop' }, ...Object.entries(hasArt ? Chase.WORLDS : { sanaa: {}, aden: {}, socotra: {}, shibam: {}, mountains: {} }).map(([id, w]) => {
    const c = (C.worlds[id] = C.worlds[id] || {});
    const url = h('input', { class: 'input ltr', type: 'url', placeholder: 'رابط موسيقى (اختياري) https://…', value: c.music || '' });
    url.addEventListener('input', () => { const v = url.value.trim(); if (v) c.music = v; else delete c.music; changedGA(); });
    return h('div', { class: 'ga-shop-row ch-arow' },
      h('span', { class: 'ga-shop-art ch-wsw', style: { background: w.bg || '#222' } }),
      h('div', { class: 'ga-shop-t' }, h('b', { text: w.name || id }), h('small', { class: 'hint', text: `🎵 ${typeof ChaseMusic !== 'undefined' ? ChaseMusic.TRACKS[id]?.name || '' : ''} · مؤلفة داخل التطبيق` }), url),
      lf('يُفتح عند (كم)', numIn(c, 'unlock', { max: 500, ph: '0' })), sw(c, 'on'));
  }));
  // السيارات
  const cars = h('div', { class: 'ga-shop' }, ...Object.entries(hasArt ? Chase.CARS : {}).map(([id, car]) => {
    const c = (C.cars[id] = C.cars[id] || {});
    const art = h('span', { class: 'ga-shop-art ch-acar' }); art.innerHTML = ChaseArt.carSVG(car.color, { body: car.body });
    return h('div', { class: 'ga-shop-row' }, art,
      h('div', { class: 'ga-shop-t' }, h('b', { text: car.name }), h('small', { class: 'hint', text: `فئة ${car.cls} · ${car.top} كم/س` })),
      lf('السعر (عملة)', numIn(c, 'price', { ph: '0 = مجانية' })), lf('تُفتح عند (كم)', numIn(c, 'unlock', { max: 500, ph: '—' })),
      h('label', { class: 'ga-shop-f' }, h('small', { text: 'ذهبية ★' }), sw(c, 'pro', false)), sw(c, 'on'));
  }));
  // اللوحات المميزة
  const plates = h('div', { class: 'ch-aplates' });
  const paintPlates = () => {
    plates.replaceChildren(...Object.entries(C.plates).map(([num, cost]) => h('div', { class: 'ch-aplate' },
      h('b', { class: 'num', text: num }),
      (() => { const i = h('input', { class: 'input num ga-price', type: 'number', min: 0, max: 100000, value: cost }); i.addEventListener('input', () => { C.plates[num] = Math.max(0, Number(i.value) || 0); changedGA(); }); return i; })(),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { delete C.plates[num]; changedGA(); paintPlates(); } }, icon('trash', { size: 15 })))));
    UI.digitize(plates);
  };
  paintPlates();
  const newNum = h('input', { class: 'input ltr num', maxlength: 3, inputmode: 'numeric', placeholder: '٧٧٧' });
  const newCost = h('input', { class: 'input num', type: 'number', min: 0, placeholder: 'السعر' });
  const addPlate = () => {
    const v = UI.toLatin ? UI.toLatin(newNum.value) : newNum.value.replace(/[٠-٩]/g, (d) => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
    if (!/^\d{3}$/.test(v)) return toast('اكتب ٣ أرقام');
    C.plates[v] = Math.max(0, Number(newCost.value) || 0); newNum.value = ''; newCost.value = ''; changedGA(); paintPlates();
  };
  body.append(
    h('p', { class: 'hint ga-p', text: 'المطاردة: طرق اليمن بلا نهاية والشرطة خلف اللاعب. اللاعب يجمع العملات في الطريق ويشتري بها السيارات والترقيات واللوحات المميزة. من هنا تتحكم في كل شيء، والتعديلات تصل للجميع بعد النشر.' }),
    gaCard('اللعب والنقاط',
      h('div', { class: 'ga-3' }, n('نقاط كل ١ كم', 'chase.ptsPerKm', { min: 1, maxv: 200 }), n('مضاعف العملات', 'chase.coinsMult', { min: 0.1, maxv: 5, step: 0.1 }), n('قوة الشرطة (١ = عادي)', 'chase.police', { min: 0.5, maxv: 1.5, step: 0.05 })),
      n('سرعة ارتفاع نجوم المطاردة لكل كم', 'chase.heatPerKm', { min: 0, maxv: 3, step: 0.05, hint: 'كلما زاد الرقم زادت الدوريات والحواجز بسرعة.' }),
      toggle('إشارات المرور', 'chase.redLight', 'قطع الإشارة الحمراء يرفع المطاردة'),
      toggle('رادار السرعة', 'chase.speedCam', 'تجاوز حد السرعة يصوّر اللاعب ويرفع المطاردة'),
      h('p', { class: 'hint', text: 'أقصى ما يقبله الخادم ٣٠٠٠ نقطة للمطاردة الواحدة. المجاني والمدفوع من «الاشتراكات ← مزايا كل قسم».' })),
    gaCard('طرق اليمن والموسيقى', h('p', { class: 'hint', text: 'كل طريق له موسيقى مؤلفة بطابع يمني. لو حطيت رابط موسيقى تملك حقوقها تُشغَّل بدلها.' }), worlds),
    hasArt ? gaCard('السيارات', cars) : null,
    gaCard('اللوحات المميزة', h('p', { class: 'hint', text: 'أرقام من ٣ خانات يشتريها اللاعب بالعملات. الأرقام العادية مجانية وعشوائية.' }), plates,
      h('div', { class: 'ch-aplate add' }, newNum, newCost, h('button', { type: 'button', class: 'btn', onclick: addPlate }, icon('plus', { size: 15 }), 'إضافة'))),
    gaCard('الترقيات', h('div', { class: 'row-2' }, n('سعر أول ترقية', 'chase.ups.base', { min: 10, maxv: 100000 }), n('مضاعف السعر لكل مستوى', 'chase.ups.step', { min: 1, maxv: 4, step: 0.1 }))),
  );
}

/* ---------- الصدارة واللاعبون ---------- */
function secBoard(body) {
  body.append(
    h('div', { class: 'ga-2col' },
      h('div', { class: 'ga-col' },
        gaCard('إعدادات الصدارة',
          toggle('إظهار لوحة الصدارة', 'board.on', 'عند الإيقاف تختفي من التطبيق وتبقى النقاط محفوظة'),
          field('عنوان اللوحة', 'board.title', { max: 30 }),
          h('div', { class: 'field' }, h('span', { text: 'عدد اللاعبين المعروضين' }), segOf('ga-size', 'board.size', [[10, '١٠'], [20, '٢٠'], [50, '٥٠'], [100, '١٠٠']])),
          h('div', { class: 'field' }, h('span', { text: 'الفترة الافتراضية' }), segOf('ga-period', 'board.period', [['week', 'الأسبوع'], ['month', 'الشهر'], ['all', 'الكل']])))),
      h('div', { class: 'ga-col' },
        gaCard('موسم جديد',
          h('p', { class: 'hint', text: 'تصفير النقاط يحذفها من الصدارة نهائياً (لا يمس تقدّم اللاعبين داخل التطبيق).' }),
          h('div', { class: 'btn-grid' },
            h('button', { type: 'button', class: 'btn', onclick: () => resetAll('xo') }, 'تصفير إكس أو'),
            h('button', { type: 'button', class: 'btn', onclick: () => resetAll('flame') }, 'تصفير مغامرة اللهب'),
            h('button', { type: 'button', class: 'btn', onclick: () => resetAll('chase') }, 'تصفير المطاردة'),
            h('button', { type: 'button', class: 'btn btn-danger-ghost span-2', onclick: () => resetAll(null) }, 'تصفير كل النقاط — موسم جديد'))))),
    h('div', { class: 'ga-players-head' },
      h('strong', { text: 'اللاعبون' }),
      h('div', { class: 'seg seg-3 seg-mini' }, ...[['week', 'الأسبوع'], ['month', 'الشهر'], ['all', 'الكل']].map(([k, l]) =>
        h('label', {}, h('input', { type: 'radio', name: 'ga-lbp', value: k, checked: GA.period === k, onchange: () => { GA.period = k; GA.rows = null; loadPlayers(); } }), h('span', { text: l })))),
      h('input', { class: 'input ga-search', type: 'search', placeholder: 'ابحث بالاسم أو البريد…', value: GA.q, oninput: (e) => { GA.q = e.target.value; paintPlayers(); } })),
    h('div', { class: 'ga-players', id: 'ga-players' }));
  loadPlayers();
}
async function loadPlayers() {
  const box = $('#ga-players');
  if (!box) return;
  if (!GA.rows) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try { GA.rows = (await Cloud.admin.board(GA.period)) || []; } catch (e) { GA.rows = []; box.replaceChildren(h('p', { class: 'hint', text: 'تعذّر التحميل: ' + Cloud.msg(e) })); return; }
  }
  paintPlayers();
}
function paintPlayers() {
  const box = $('#ga-players');
  if (!box || !GA.rows) return;
  const q = UI.normAr(GA.q.trim());
  const rows = GA.rows.filter((r) => !q || UI.normAr(`${r.nickname || ''} ${r.email || ''}`).includes(q));
  if (!rows.length) return box.replaceChildren(h('div', { class: 'empty' }, icon('trophy', { size: 34 }), h('p', { text: GA.rows.length ? 'لا نتائج' : 'لا توجد نقاط في هذه الفترة' })));
  const medal = ['🥇', '🥈', '🥉'];
  box.replaceChildren(...rows.map((r, i) => h('div', { class: `ga-pl${r.game_banned ? ' banned' : ''}` },
    h('span', { class: 'lb-rank num', text: medal[i] || i + 1 }),
    h('div', { class: 'ga-pl-t' },
      h('b', {}, r.nickname || 'بدون اسم مستعار',
        !r.show_on_board ? h('span', { class: 'pill nick', text: 'مخفي' }) : null,
        r.game_banned ? h('span', { class: 'pill suspended', text: 'محظور' }) : null),
      h('small', { class: 'ltr', text: r.email })),
    h('div', { class: 'ga-pl-n' }, h('b', { class: 'num', text: r.points }), h('small', { class: 'num', text: `${r.plays} مرة · ${UI.relTime(new Date(r.last_play).getTime())}` })),
    h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'إجراءات', onclick: () => playerActions(r) }, icon('more', { size: 18 })))));
  UI.digitize(box);
}
function playerActions(r) {
  const who = r.nickname || r.email;
  const act = (ic, label, fn, cls = '') => h('button', { type: 'button', class: `action ${cls}`, onclick: () => { closeSheet(); fn(); } }, icon(ic, { size: 20 }), label);
  const done = async (fn, msg) => { try { await fn(); toast(msg, { type: 'success' }); GA.rows = null; loadPlayers(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  pickSheet(who, r.email, [
    act('tag', '🎁 مكافأة (حبوب بن / فتح المراحل / شكل)', () => giftPlayer(r.user_id, who)),
    act('edit', 'تعديل الاسم المستعار', async () => {
      const v = await confirmSheet({ title: 'الاسم المستعار', text: 'يظهر في لوحة الصدارة بدل الاسم الحالي. اتركه فارغاً للاسم التلقائي.', ok: 'حفظ', input: r.nickname || '' });
      if (v !== false) done(() => Cloud.admin.setPlayer(r.user_id, v, null, null), 'تم تغيير الاسم');
    }),
    act(r.show_on_board ? 'eyeOff' : 'eye', r.show_on_board ? 'إخفاء من الصدارة' : 'إظهار في الصدارة', () => done(() => Cloud.admin.setPlayer(r.user_id, r.nickname || '', !r.show_on_board, null), 'تم')),
    act('lock', r.game_banned ? 'رفع الحظر عن الألعاب' : 'حظر من الصدارة والنقاط', () => done(() => Cloud.admin.setPlayer(r.user_id, r.nickname || '', null, !r.game_banned), r.game_banned ? 'رُفع الحظر' : 'تم الحظر'), r.game_banned ? '' : 'danger'),
    act('repeat', 'تصفير نقاطه', async () => {
      if (await confirmSheet({ title: `تصفير نقاط ${who}؟`, text: 'تُحذف كل نقاطه من الصدارة.', ok: 'تصفير' })) done(() => Cloud.admin.resetScores(r.user_id, null), 'تم التصفير');
    }, 'danger'),
  ]);
}
/* مكافأة لاعب — تصله عند فتح التطبيق مع رسالة */
function giftPlayer(uid, who) {
  if (!$('#pick-sheet').hidden) return setTimeout(() => giftPlayer(uid, who), 230); // انتظار إغلاق القائمة السابقة
  let kind = 'beans', n = 200, item = 'monsters:ghost';
  const items = [...MONSTERS.map((m) => [`monsters:${m.id}`, `وحش: ${m.name}`]), ...Object.entries(HERO_COLORS).map(([k, c]) => [`colors:${k}`, `لون: ${c.name}`]), ...Object.entries(HERO_ACC).map(([k, a]) => [`acc:${k}`, `إكسسوار: ${a.name}`]), ...['flame', 'stars', 'bolt'].map((k) => [`trails:${k}`, `أثر: ${{ flame: 'لهب', stars: 'نجوم', bolt: 'برق' }[k]}`])];
  const nInp = h('input', { class: 'input num', type: 'number', min: 1, max: 100000, value: n });
  const sel = h('select', { class: 'input select' }, ...items.map(([v, l]) => h('option', { value: v, text: l })));
  const note = h('input', { class: 'input', maxlength: 120, placeholder: 'رسالة تظهر مع الهدية (اختياري) — مثال: شكراً لمشاركتك' });
  const beansBox = h('div', { class: 'field' }, h('span', { text: 'عدد حبوب البن' }), h('div', { class: 'btn-grid ga-quick' }, ...[50, 100, 250, 500].map((v) => h('button', { type: 'button', class: 'chip', onclick: () => { nInp.value = v; } }, `${v}`))), nInp);
  const itemBox = h('label', { class: 'field', hidden: true }, h('span', { text: 'الشكل' }), sel);
  const seg = h('div', { class: 'seg seg-3' }, ...[['beans', 'حبوب بن'], ['unlock', 'فتح كل المراحل'], ['item', 'شكل مجاني']].map(([k, l]) =>
    h('label', {}, h('input', { type: 'radio', name: 'gift-k', checked: k === kind, onchange: () => { kind = k; beansBox.hidden = k !== 'beans'; itemBox.hidden = k !== 'item'; } }), h('span', { text: l }))));
  const send = h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
    const value = kind === 'beans' ? { n: Math.max(1, Math.round(Number(nInp.value) || 0)) } : kind === 'item' ? { cat: sel.value.split(':')[0], id: sel.value.split(':')[1] } : {};
    send.disabled = true;
    try { await Cloud.admin.grant(uid, kind, value, note.value.trim()); closeSheet(); toast(`أُرسلت الهدية إلى ${who} — تصله عند فتح التطبيق`, { type: 'success', duration: 5000 }); }
    catch (e) { toast(/function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.7.sql أولاً' : Cloud.msg(e), { type: 'error' }); }
    finally { send.disabled = false; }
  } }, '🎁 إرسال الهدية');
  pickSheet(`مكافأة ${who}`, 'تُضاف لحسابه تلقائياً مع رسالة عند فتح التطبيق', [h('div', { class: 'ga-gift' }, seg, beansBox, itemBox, h('label', { class: 'field' }, h('span', { text: 'رسالة' }), note), send)]);
}
async function resetAll(game) {
  const label = game ? GAME_KEYS[game] : 'كل الألعاب';
  const ok = await confirmSheet({ title: `تصفير نقاط ${label}؟`, text: 'تُحذف النقاط من الصدارة لكل اللاعبين ولا يمكن التراجع.', ok: 'تصفير نهائي', typeToConfirm: 'تصفير' });
  if (!ok) return;
  try { const n = await Cloud.admin.resetScores(null, game); toast(`تم — حُذف ${UI.n(n ?? 0)} سجل`, { type: 'success' }); GA.rows = null; loadPlayers(); }
  catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

/* ---------- الحفظ ---------- */
async function saveGA() {
  const btn = $('#ga-save');
  const d = GA.data;
  // تنظيف
  ['xo', 'flame', 'chase', 'word'].forEach((k) => { d[k] = d[k] || clone(GCfg.DEFAULTS[k]); d[k].name = (d[k].name || '').trim() || GCfg.DEFAULTS[k].name; });
  if (d.word) d.word.pts = (d.word.pts || []).slice(0, 6).map((x) => Math.max(0, Math.min(120, Number(x) || 0)));
  d.event.mult = Math.max(1, Math.min(5, Number(d.event.mult) || 2));
  d.flame.ptsRate = Math.max(1, Math.min(100, Number(d.flame.ptsRate) || 10));
  d.flame.hearts = Math.max(1, Math.min(5, Number(d.flame.hearts) || 3));
  d.tasksPts = Math.max(0, Math.min(50, Number(d.tasksPts) || 0));
  Object.keys(d.xo.pts).forEach((k) => { d.xo.pts[k] = Math.max(0, Math.min(100, Number(d.xo.pts[k]) || 0)); });
  btn.disabled = true;
  try {
    await Cloud.admin.setGames(d);
    GCfg.set(d);
    GA.dirty = false;
    GA.updated = new Date().toISOString();
    toast('نُشرت إعدادات الألعاب — تظهر للاعبين عند فتح التطبيق', { type: 'success', duration: 5000 });
    renderGA();
  } catch (e) {
    toast('تعذّر النشر: ' + Cloud.msg(e), { type: 'error' });
  } finally {
    btn.disabled = false;
  }
}
window.addEventListener('beforeunload', (e) => { if (GA.dirty) { e.preventDefault(); e.returnValue = ''; } });

/* ---------- كلمة اليوم ---------- */
function secWord(body) {
  const W = (GA.data.word = GCfg.merge(clone(GCfg.DEFAULTS.word), GA.data.word || {}));
  W.custom = { ar: [], en: [], ...(W.custom || {}) };
  W.pins = W.pins || {};
  const hasW = typeof Words !== 'undefined';
  const langBox = h('div', { class: 'ga-checks' }, ...[['ar', 'عربي'], ['en', 'English']].map(([k, l]) => {
    const c = h('input', { type: 'checkbox', checked: (W.langs || []).includes(k) });
    c.addEventListener('change', () => { const st = new Set(W.langs || []); c.checked ? st.add(k) : st.delete(k); W.langs = ['ar', 'en'].filter((x) => st.has(x)); if (!W.langs.length) { W.langs = ['ar']; c.checked = k === 'ar'; } changedGA(); });
    return h('label', { class: 'ga-check' }, c, h('span', { text: l }));
  }));
  const pts = h('div', { class: 'ga-3 ga-wpts' }, ...Array.from({ length: 6 }, (_, i) => {
    const inp = h('input', { class: 'input num', type: 'number', min: 0, max: 120, value: W.pts?.[i] ?? 0 });
    inp.addEventListener('input', () => { W.pts = [...(W.pts || [])]; W.pts[i] = Number(inp.value) || 0; changedGA(); });
    return h('label', { class: 'field' }, h('span', { text: `حلّها بـ ${UI.n(i + 1)}` }), inp);
  }));
  const listCard = (lang, title) => {
    const ta = h('textarea', { class: `input textarea${lang === 'en' ? ' ltr' : ''}`, rows: 5, maxlength: 20000, placeholder: lang === 'en' ? 'apple\nbrave\n…' : 'مدرسة\nسيارة\n…' });
    ta.value = (W.custom[lang] || []).join('\n');
    const info = h('small', { class: 'hint' });
    const check = () => {
      const words = ta.value.split(/[\n،,]+/).map((x) => x.trim()).filter(Boolean);
      const bad = hasW ? words.filter((w) => Words.norm(lang, w).length !== Words.LEN) : [];
      W.custom[lang] = words.filter((w) => !bad.includes(w)).slice(0, 2000);
      info.textContent = `${UI.n(W.custom[lang].length)} كلمة صالحة${bad.length ? ` · تُتجاهل ${UI.n(bad.length)} (لازم ${UI.n(Words.LEN)} حروف): ${bad.slice(0, 6).join('، ')}` : ''}${hasW ? ` · الجاهزة: ${UI.n((lang === 'en' ? Words.EN : Words.AR).length)}` : ''}`;
    };
    ta.addEventListener('input', () => { check(); changedGA(); });
    check();
    return gaCard(title, ta, info);
  };
  const pinsBox = h('div', { class: 'ga-pins' });
  const paintPins = () => {
    const rows = Object.entries(W.pins).sort();
    const date = h('input', { class: 'input ltr', type: 'date' }), lang = h('select', { class: 'input' }, h('option', { value: 'ar', text: 'عربي' }), h('option', { value: 'en', text: 'English' })), word = h('input', { class: 'input', maxlength: 12, placeholder: 'الكلمة' });
    const dayOf = (v) => { const [y, m, d] = v.split('-').map(Number); return Words.dayNum(new Date(y, m - 1, d)); };
    const dateOf = (n) => { const d = new Date(Date.UTC(2026, 0, 1) + (n - 1) * 864e5); return d.toISOString().slice(0, 10); };
    pinsBox.replaceChildren(
      ...rows.map(([k, w]) => { const [lg, n] = k.split(':'); return h('div', { class: 'ga-pin' }, h('span', { class: 'num ltr', text: dateOf(+n) }), h('small', { text: lg === 'en' ? 'English' : 'عربي' }), h('b', { text: w }),
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { delete W.pins[k]; changedGA(); paintPins(); } }, icon('trash', { size: 15 }))); }),
      h('div', { class: 'ga-pin add' }, date, lang, word, h('button', { type: 'button', class: 'btn', onclick: () => {
        if (!date.value) return toast('اختر التاريخ');
        if (!hasW || Words.norm(lang.value, word.value).length !== Words.LEN) return toast(`الكلمة لازم ${UI.n(Words.LEN)} حروف`);
        W.pins[`${lang.value}:${dayOf(date.value)}`] = word.value.trim(); changedGA(); paintPins();
      } }, icon('plus', { size: 15 }), 'ثبّت')));
  };
  paintPins();
  const prev = hasW ? h('p', { class: 'note-box', text: `كلمة اليوم الحين: ${(W.langs || ['ar']).map((l) => `${l === 'en' ? 'English' : 'عربي'} «${Words.today(l, W)?.word || '—'}»`).join(' · ')} — لا تقولها لأحد 🤫` }) : null;
  body.append(
    h('p', { class: 'hint ga-p', text: 'كلمة اليوم: كلمة من ٥ حروف كل يوم، نفس الكلمة لكل المستخدمين، ٦ محاولات، وتشتغل بدون نت. اللاعب يشارك نتيجته بالمربعات الملوّنة بدون ما يكشف الكلمة.' }),
    prev,
    gaCard('اللعب', toggle('ظاهرة للمستخدمين', 'word.on'), h('div', { class: 'row-2' }, field('الاسم بالعربي', 'word.name', { max: 30 }), field('الاسم بالإنجليزي', 'word.nameEn', { max: 30, ltr: true })), field('وصف قصير', 'word.desc', { max: 60 }),
      h('label', { class: 'field' }, h('span', { text: 'اللغات' }), langBox)),
    gaCard('النقاط حسب عدد المحاولات', pts, h('small', { class: 'hint', text: 'الحد الأعلى ١٢٠ نقطة. الخسارة بدون نقاط وتصفّر السلسلة.' })),
    listCard('ar', 'كلماتك بالعربي (كل سطر كلمة)'),
    listCard('en', 'English words (one per line)'),
    gaCard(null, toggle('كلماتي فقط', 'word.onlyCustom', 'عند التشغيل تُستخدم كلماتك بدل الجاهزة (إذا فيه كلمات)', () => setTimeout(() => renderGA(), 0))),
    gaCard('📌 تثبيت كلمة ليوم معيّن (مناسبة، حدث…)', pinsBox));
}

/* ---------- التفاعل اليومي: السلسلة + تحدي اليوم + الموجز ---------- */
function secDaily(body) {
  const D = (GA.data.daily = GCfg.merge(clone(GCfg.DEFAULTS.daily), GA.data.daily || {}));
  const KINDS = { task: 'إنجاز مهمة', tx: 'تسجيل حركة مالية', news: 'قراءة خبر', game: 'لعب أي لعبة', word: 'حل كلمة اليوم', design: 'حفظ/مشاركة تصميم', quick: 'إضافة سريعة', site: 'فتح موقع محفوظ' };
  const num = (obj, key, opt = {}) => { const i = h('input', { class: 'input num', type: 'number', min: opt.min ?? 0, max: opt.max ?? 1000, value: obj[key] ?? '' }); i.addEventListener('input', () => { obj[key] = Number(i.value) || 0; changedGA(); }); return i; };
  const txt = (obj, key, max = 120) => { const i = h('input', { class: 'input', maxlength: max, value: obj[key] ?? '' }); i.addEventListener('input', () => { obj[key] = i.value; changedGA(); }); return i; };
  const rew = h('div', { class: 'ga-pins' });
  const paintRew = () => {
    D.streak.rewards = (D.streak.rewards || []).slice().sort((a, b) => a[0] - b[0]);
    rew.replaceChildren(...D.streak.rewards.map((r, i) => h('div', { class: 'ga-pin ga-rew' },
      h('label', { class: 'field' }, h('span', { text: 'بعد كم يوم' }), (() => { const x = h('input', { class: 'input num', type: 'number', min: 2, max: 365, value: r[0] }); x.addEventListener('change', () => { r[0] = Math.max(2, Number(x.value) || 2); changedGA(); paintRew(); }); return x; })()),
      h('label', { class: 'field' }, h('span', { text: 'نقاط المكافأة' }), (() => { const x = h('input', { class: 'input num', type: 'number', min: 0, max: 1000, value: r[1] }); x.addEventListener('input', () => { r[1] = Number(x.value) || 0; changedGA(); }); return x; })()),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { D.streak.rewards.splice(i, 1); changedGA(); paintRew(); } }, icon('trash', { size: 15 })))),
      h('button', { type: 'button', class: 'btn', onclick: () => { D.streak.rewards.push([(D.streak.rewards.at(-1)?.[0] || 0) + 7, 100]); changedGA(); paintRew(); } }, icon('plus', { size: 15 }), 'أضف مكافأة'));
  };
  paintRew();
  const chBox = h('div', { class: 'ga-pins' });
  const paintCh = () => chBox.replaceChildren(...D.challenge.list.map((c, i) => h('div', { class: `ga-ch${c.on === false ? ' off' : ''}` },
    (() => { const sw = h('input', { type: 'checkbox', checked: c.on !== false }); sw.addEventListener('change', () => { c.on = sw.checked; changedGA(); paintCh(); }); return h('label', { class: 'switch' }, sw, h('span', { class: 'track' })); })(),
    txt(c, 'text', 60),
    (() => { const s2 = h('select', { class: 'input' }, ...Object.entries(KINDS).map(([k, l]) => h('option', { value: k, text: l }))); s2.value = c.kind; s2.addEventListener('change', () => { c.kind = s2.value; changedGA(); }); return s2; })(),
    num(c, 'n', { min: 1, max: 10 }),
    h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { D.challenge.list.splice(i, 1); changedGA(); paintCh(); } }, icon('trash', { size: 15 })))),
    h('button', { type: 'button', class: 'btn', onclick: () => { D.challenge.list.push({ id: 'c' + Date.now().toString(36).slice(-5), kind: 'task', n: 1, text: 'تحدي جديد' }); changedGA(); paintCh(); } }, icon('plus', { size: 15 }), 'أضف تحدي'));
  paintCh();
  body.append(
    h('p', { class: 'hint ga-p', text: 'يرجّع المستخدم كل يوم: سلسلة نشاط موحّدة (أي نشاط في التطبيق يكمّلها) مع مكافآت، وتحدي يومي يتغيّر كل يوم، وموجز صباحي ومسائي كإشعار على الجوال — كله يشتغل بدون نت.' }),
    gaCard('التشغيل', toggle('التفاعل اليومي', 'daily.on', 'بطاقة السلسلة والتحدي في «يومي»')),
    gaCard('🔥 مكافآت السلسلة', toggle('مكافآت السلسلة', 'daily.streak.on'), rew),
    gaCard('🎯 تحدي اليوم', toggle('تحدي اليوم', 'daily.challenge.on', 'التحديات تتبدّل يومياً، ويُتجاهل التحدي لو قسمه مخفي عند المستخدم'),
      h('label', { class: 'field' }, h('span', { text: 'نقاط إنجاز التحدي' }), num(D.challenge, 'pts', { max: 100 })),
      h('small', { class: 'hint', text: 'كل تحدي: النص · النشاط · العدد المطلوب' }), chBox),
    gaCard('🔔 الموجز الصباحي والمسائي (إشعار محلي)', toggle('الموجز', 'daily.brief.on', 'المستخدم يفعّله من بطاقة «يومي»'),
      h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'ساعة الصباح (0-23)' }), num(D.brief, 'morning', { max: 23 })), h('label', { class: 'field' }, h('span', { text: 'ساعة المساء (0-23)' }), num(D.brief, 'evening', { max: 23 }))),
      h('small', { class: 'hint', text: 'متغيرات: {name} الاسم · {tasks} مهام اليوم · {done} المنجز · {streak} السلسلة · {challenge} تحدي اليوم' }),
      ...[['mTitle', 'عنوان الصباح'], ['mBody', 'نص الصباح (عنده مهام)'], ['mBodyFree', 'نص الصباح (بدون مهام)'], ['eTitle', 'عنوان المساء (سوّى نشاط)'], ['eBody', 'نص المساء (سوّى نشاط)'], ['eTitleRisk', 'عنوان المساء (ما سوّى شي)'], ['eBodyRisk', 'نص المساء (ما سوّى شي)']]
        .map(([k, l]) => h('label', { class: 'field' }, h('span', { text: l }), txt(D.brief, k)))));
}
