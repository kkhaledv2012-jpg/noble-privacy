/* NOBLE — لوحة الإدارة: «📊 تفاصيل المستخدم» (1.21.6) — المسموح فقط في سياسات قوقل بلاي
 * حالته (نشيط/قلّ/مهدد يترك) · الاشتراك · الإشعارات · الأخبار وعاجل · رحلته (الإصدارات، أول قسم) · تفضيلاته · الأعطال · ملاحظاتك ووسومك
 */
'use strict';
const INS_TAGS = ['⭐ VIP', '💼 عميل', '🧪 مختبر', '🤝 صديق', '⚠️ متابعة'];
const INS_TAB = { sites: 'المواقع', tasks: 'المهام', news: 'الأخبار', today: 'يومي', azkar: 'أذكاري', designs: 'تصاميم', finance: 'المالية', games: 'الألعاب', discover: 'اكتشف' };
const INS_PERM = { granted: '✅ مسموحة', denied: '🚫 مقفولة', prompt: '❔ ما اختار بعد', 'prompt-with-rationale': '❔ ما اختار بعد' };
const INS_THEME = { midnight: 'ليل أزرق', neon: 'نيون أخضر', sunset: 'غروب', noble: 'نبيل', copper: 'نحاسي', rose: 'وردي', graphite: 'فحمي', system: 'الافتراضي', custom: 'لون مخصص' };
const insDay = (t) => (t ? new Date(t).toLocaleDateString('ar', { day: 'numeric', month: 'short' }) : '—');

/* حالة المستخدم من آخر ظهور ونشاط آخر ٧ أيام */
function insStatus(u) {
  const st = A.ustats?.[u.id], seen = ts(u.last_seen_at) || ts(st?.last_sync), ev = st?.events_7d ?? 0, d = seen ? (Date.now() - seen) / 864e5 : 999;
  if (Date.now() - ts(u.created_at) < 3 * 864e5) return { cls: 'new', t: '🆕 جديد', s: 'ثبّت التطبيق قبل أقل من ٣ أيام' };
  if (d <= 2 && ev >= 5) return { cls: 'ok', t: '🟢 نشيط', s: 'يفتح التطبيق باستمرار' };
  if (d <= 7) return { cls: 'mid', t: '🟡 قلّ استخدامه', s: `آخر ظهور قبل ${UI.n(Math.max(1, Math.round(d)))} يوم` };
  if (d <= 30) return { cls: 'risk', t: '🔴 مهدد يترك', s: `ما فتح من ${UI.n(Math.round(d))} يوم — رسالة أو إشعار ممكن يرجّعه` };
  return { cls: 'gone', t: '⚫ ترك', s: seen ? `آخر ظهور ${insDay(seen)}` : 'ما وصلت له بيانات' };
}

function insCards(u) {
  const st = A.ustats?.[u.id], ins = st?.stats?.ins || null, c = ins?.cnt || {};
  const tile = (v, l) => h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: v ?? '—' }), h('small', { text: l }));
  const card = (title, sub, ...kids) => h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: title }), sub ? h('small', { class: 'hint', text: sub }) : null), ...kids);
  const S0 = insStatus(u);
  const none = h('p', { class: 'hint', text: 'تطلع بعد ما يفتح التطبيق بإصدار 1.21.6 أو أحدث (أو موقّف «مشاركة الإحصائيات»).' });
  const pf = ins?.prefs || {};
  return [
    card('📊 حالته', '', h('div', { class: `ins-st ${S0.cls}` }, h('b', { text: S0.t }), h('span', { text: S0.s }))),
    h('div', { id: 'ins-sub' }),
    card('🔔 الإشعارات', '', ins ? h('div', { class: 'ua-grid' }, tile(INS_PERM[ins.perm] || '—', 'الإذن'), tile(c.notifIn || 0, 'وصله'), tile(c.notifOpen || 0, 'فتحها'),
      tile(c.notifIn ? `${UI.n(Math.round(((c.notifOpen || 0) / c.notifIn) * 100))}٪` : '—', 'نسبة الفتح')) : none),
    card('📰 الأخبار وعاجل', 'أرقام بس — بدون عناوين', ins ? h('div', { class: 'ua-grid' }, tile(c.newsRead || 0, 'خبر قرأه'), tile(c.aiSeen || 0, 'عدد عاجل شافه'),
      tile(c.saves || 0, 'حفظ'), tile(c.shares || 0, 'شارك'), tile(c.saved ?? 0, 'في محفوظاته'), tile(c.downloads || 0, 'نزّل صور')) : none),
    card('🧭 رحلته', '', ins ? h('div', { class: 'ins-j' },
      h('p', { class: 'ua-line' }, h('b', { text: 'أول قسم فتحه: ' }), INS_TAB[ins.first] || ins.first || '—'),
      h('p', { class: 'ua-line' }, h('b', { text: 'أول فتح: ' }), insDay(u.created_at)),
      (ins.vers || []).length ? h('div', { class: 'ins-vers' }, ...(ins.vers || []).map((x) => h('span', {}, h('b', { class: 'num', text: x.v }), h('small', { text: insDay(x.at) })))) : null) : none),
    card('🎨 تفضيلاته', '', ins ? h('div', { class: 'ua-grid' }, tile({ dark: 'داكن', light: 'فاتح', system: 'حسب الجهاز' }[pf.mode] || pf.mode || '—', 'المظهر'),
      tile(INS_THEME[pf.theme] || pf.theme || 'الافتراضي', 'الثيم'), tile(pf.font && pf.font !== 1 ? `${UI.n(Math.round(pf.font * 100))}٪` : 'عادي', 'حجم الخط'),
      tile(pf.hidden || 0, 'أقسام قفلها'), tile(INS_TAB[pf.start] || 'الافتراضي', 'يبدأ من'), tile(pf.digits === 'arab' ? '١٢٣' : '123', 'الأرقام')) : none),
    card('⚠️ الأعطال', 'آخر ٧ أيام — تقنية بس', ins ? (ins.errs?.n
      ? h('div', {}, h('div', { class: 'ua-grid' }, tile(ins.errs.n, 'خطأ'), tile(insDay(ins.errs.at), 'آخر مرة')), h('p', { class: 'ins-err', dir: 'ltr', text: ins.errs.last || '' }))
      : h('p', { class: 'hint', text: '✅ ما صار عنده أي خطأ' })) : none),
    h('div', { id: 'ins-note' }),
  ];
}

/* بعد ما ينفتح: الاشتراك + الملاحظات (تحتاج طلب من السيرفر) */
async function insLoad(u) {
  const sub = $('#ins-sub');
  if (sub && can('billing.manage')) {
    try {
      const info = await Cloud.admin.userAccess(u.id), ents = info?.ents || [], a = info?.access || {};
      const live = ents.filter((e) => !e.until || new Date(e.until) > new Date());
      const SRC = { code: 'كود', payment: 'تحويل', admin: 'منك', gateway: 'دفع إلكتروني' }, PLAN = { m: 'شهري', y: 'سنوي', l: 'مدى الحياة', custom: 'مخصص' };
      const tUntil = a.trial_until ? new Date(a.trial_until) : null, tLeft = tUntil ? Math.ceil((tUntil - Date.now()) / 864e5) : null;
      sub.replaceChildren(h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '💳 الاشتراك' })),
        h('div', { class: 'ua-grid' },
          h('div', { class: 'ua-tile' }, h('b', { text: live.length ? '★ Pro' : 'مجاني' }), h('small', { text: 'الحالة' })),
          h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: tLeft == null ? '—' : tLeft > 0 ? `${UI.n(tLeft)} يوم` : 'انتهت' }), h('small', { text: 'التجربة' })),
          h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: UI.n(ents.length) }), h('small', { text: 'اشتراكات' }))),
        ...ents.slice(0, 5).map((e) => h('p', { class: 'ua-line' }, h('b', { text: `${e.app === 'all' ? 'الكل' : e.app} · ${PLAN[e.plan] || e.plan}` }),
          ` — ${SRC[e.source] || e.source}${e.ref ? ` (${e.ref})` : ''} · ${e.until ? 'لين ' + insDay(e.until) : 'دائم'}`))));
    } catch { /* بدون الاشتراك */ }
  }
  const box = $('#ins-note'); if (!box) return;
  if (!A.unotes) A.unotes = await Cloud.admin.userNotes().catch(() => null);
  if (A.unotes === null) return box.replaceChildren(h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '🏷️ ملاحظاتك عنه' })),
    h('p', { class: 'hint', text: 'تحتاج تلصق ملف update-1.21.7.sql في Supabase ← SQL Editor مرة وحدة.' })));
  const cur = A.unotes.find((x) => x.user_id === u.id) || { tags: [], note: '' };
  const tags = new Set(cur.tags || []), edit = can('users.manage');
  const ta = h('textarea', { class: 'input', rows: 3, maxlength: 2000, placeholder: 'مثلاً: صاحب محل، طلب ميزة كذا، يحتاج متابعة…', readonly: !edit || null }); ta.value = cur.note || '';
  const st = h('small', { class: 'hint' });
  const chips = h('div', { class: 'ins-tags' }, ...INS_TAGS.map((t) => h('button', { type: 'button', class: 'chip' + (tags.has(t) ? ' on' : ''), disabled: !edit || null,
    onclick: (e) => { const b = e.currentTarget; tags.has(t) ? tags.delete(t) : tags.add(t); b.classList.toggle('on', tags.has(t)); } }, t)));
  const save = h('button', { type: 'button', class: 'btn btn-primary sm', hidden: !edit || null, onclick: async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try { await Cloud.admin.userNoteSet(u.id, [...tags], ta.value.trim()); const i = A.unotes.findIndex((x) => x.user_id === u.id), row = { user_id: u.id, tags: [...tags], note: ta.value.trim(), updated_at: new Date().toISOString() };
      if (i >= 0) A.unotes[i] = row; else A.unotes.push(row); st.textContent = '✅ انحفظت'; } catch (x) { toast(Cloud.msg(x), { type: 'error' }); } finally { b.disabled = false; }
  } }, '💾 احفظ');
  box.replaceChildren(h('section', { class: 'ua-card' }, h('div', { class: 'ua-h' }, h('b', { text: '🏷️ ملاحظاتك عنه' }), h('small', { class: 'hint', text: 'لك وللفريق بس — المستخدم ما يشوفها' })),
    chips, ta, h('div', { class: 'ins-save' }, save, st)));
}
