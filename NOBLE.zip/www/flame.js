/* NOBLE — مغامرة اللهب: لعبة منصّات أصلية بعالم مستوحى من اليمن */
'use strict';
var Flame = (() => {
  const T = 32, ROWS = 12, WH = ROWS * T;
  const DBG = {};
  const FOOT = { lahhoub: 104, logo: 86, round: 91, band: 80, limbs: 104, pixel: 84, noon: 96 };

  /* ================= المراحل ================= */
  const PAL = {
    dusk: { sky: ['#0B1440', '#4A2A6E', '#E07A3A'], sun: '#FFB43D', far: '#3A2A5E', farLine: '#6B4A7A', mid: '#9A6A5E', midWin: '#4A2E24', near: '#7A4A34', nearTrim: '#F3EDE4', win: '#243A8C', brick: ['#C98A4B', '#A8703A', '#DCA465'], haze: '#9A6A48', stars: 0.6, lit: false },
    day: { sky: ['#1B5FA8', '#5FB4D8', '#F6D8A8'], sun: '#FFE08A', far: '#4F7A6A', farLine: '#7FA88A', mid: '#C4935E', midWin: '#6A3E28', near: '#9A6242', nearTrim: '#FFF6EA', win: '#1F4FA0', brick: ['#D39A5A', '#B07A42', '#E8B878'], haze: '#E6C08A', stars: 0, lit: false },
    night: { sky: ['#02040F', '#0B1440', '#2A1E52'], sun: '#F3EDE4', far: '#141B3E', farLine: '#26306A', mid: '#2A2350', midWin: '#FFB43D', near: '#3A2A2E', nearTrim: '#8A8AA8', win: '#FFB43D', brick: ['#7A5A48', '#5A4034', '#9A7A62'], haze: '#241A3E', stars: 1, lit: true },
  };
  /* ألوان عالم مدينة الفوانيس حسب الوقت */
  const PAL_L = {
    day: { sky: ['#2A6FB8', '#7CC4E4', '#F6E2B8'], sun: '#FFE08A', far: '#8A6A9E', farLine: '#B08AC0', mid: '#C9A27A', midWin: '#6A4A7A', near: '#B8865A', nearTrim: '#FFF3DE', win: '#2E5BFF', brick: ['#3F8FA0', '#2A6070', '#5FB4C4'], haze: '#E8C8A0', stars: 0, lit: false, str: '#8A6A5A' },
    dusk: { sky: ['#1A1446', '#6A2A6E', '#F08A4A'], sun: '#FFB43D', far: '#3B2A66', farLine: '#6B4A8A', mid: '#5A3A6E', midWin: '#FFB43D', near: '#6A3E5A', nearTrim: '#F3DDE8', win: '#3B2A66', brick: ['#2F6E80', '#1E4A58', '#4A9AAE'], haze: '#9A5A7A', stars: 0.4, lit: true, str: '#C88AA0' },
    night: { sky: ['#02040F', '#1A1446', '#3B2A66'], sun: '#F3EDE4', far: '#141038', farLine: '#2A2260', mid: '#241A4E', midWin: '#FFB43D', near: '#2E2150', nearTrim: '#8A7AB8', win: '#FFB43D', brick: ['#1E4A5E', '#12303E', '#2F6E80'], haze: '#1A1446', stars: 1, lit: true, str: '#6B4A7A' },
  };
  const LEVELS = [
    {
      id: '1-1', name: 'باب اليمن', pal: 'dusk', w: 150,
      ground: [[0, 34], [38, 62], [63, 70, 8], [71, 88], [92, 118], [122, 149]],
      plat: [[14, 6, 4], [24, 7, 3], [44, 6, 5], [52, 3, 3], [76, 6, 4], [98, 7, 3], [104, 5, 3], [128, 6, 4]],
      q: [[16, 3], [46, 3], [106, 2]],
      beans: [[6, 9, 4], [14, 5, 4], [24, 6, 3], [35, 7, 3, 1], [44, 5, 5], [52, 2, 3], [64, 7, 6], [76, 5, 4], [89, 7, 3, 1], [98, 6, 3], [104, 4, 3], [119, 7, 3, 1], [128, 5, 4], [136, 9, 4]],
      scorp: [30, 55, 80, 86, 112, 134], thorn: [[48, 9], [100, 9], [126, 9]],
      check: [72], start: [2, 9], goal: 144,
    },
    {
      id: '1-2', name: 'سوق الملح', pal: 'day', w: 175,
      ground: [[0, 22], [26, 40], [41, 46, 7], [47, 58], [63, 76], [81, 84, 8], [88, 104], [105, 110, 6], [111, 128], [133, 146], [150, 174]],
      plat: [[10, 6, 3], [18, 4, 3], [30, 6, 4], [51, 5, 4], [59, 6, 3], [66, 5, 3], [72, 3, 3], [77, 7, 3], [92, 6, 4], [114, 6, 3], [120, 4, 3], [129, 7, 3], [138, 5, 4], [147, 6, 3], [156, 5, 4]],
      q: [[11, 2], [32, 2], [68, 1], [94, 2], [140, 1]],
      beans: [[3, 9, 3], [10, 5, 3], [18, 3, 3], [23, 7, 3, 1], [30, 5, 4], [41, 6, 6], [51, 4, 4], [59, 5, 3], [66, 4, 3], [72, 2, 3], [77, 6, 3], [85, 6, 3, 1], [92, 5, 4], [105, 5, 6], [114, 5, 3], [120, 3, 3], [129, 6, 3], [138, 4, 4], [147, 5, 3], [156, 4, 4], [162, 9, 5]],
      scorp: [16, 34, 52, 70, 95, 100, 116, 124, 140, 158, 164], thorn: [[37, 9], [56, 9], [98, 9], [143, 9], [153, 9]],
      check: [62, 111], start: [2, 9], goal: 169,
    },
    {
      id: '1-3', name: 'سطوح صنعاء ليلاً', pal: 'night', w: 195,
      ground: [[0, 16], [20, 30, 9], [34, 42, 7], [46, 60], [64, 66, 8], [70, 72, 6], [76, 92], [97, 108, 8], [112, 118], [123, 126, 7], [130, 146], [150, 152, 8], [156, 158, 6], [162, 194]],
      plat: [[8, 6, 3], [24, 5, 3], [38, 3, 3], [50, 6, 4], [56, 3, 3], [80, 6, 3], [86, 3, 3], [100, 4, 4], [114, 5, 3], [134, 6, 3], [140, 3, 3], [166, 6, 4], [174, 4, 3]],
      q: [[9, 2], [51, 2], [87, 0], [135, 2], [167, 2]],
      beans: [[3, 9, 3], [8, 5, 3], [17, 7, 3, 1], [24, 4, 3], [31, 5, 3, 1], [38, 2, 3], [43, 5, 3, 1], [50, 5, 4], [56, 2, 3], [61, 6, 3, 1], [67, 4, 3, 1], [73, 3, 3, 1], [80, 5, 3], [86, 2, 3], [93, 6, 4, 1], [100, 3, 4], [109, 5, 3, 1], [114, 4, 3], [119, 5, 4, 1], [127, 4, 3, 1], [134, 5, 3], [140, 2, 3], [147, 5, 3, 1], [153, 4, 3, 1], [159, 3, 3, 1], [166, 5, 4], [174, 3, 3], [180, 9, 5]],
      scorp: [12, 26, 40, 52, 58, 82, 88, 102, 106, 116, 136, 142, 168, 176, 184], thorn: [[48, 9], [78, 9], [91, 9], [114, 9], [132, 9], [145, 9], [164, 9]],
      check: [64, 130], start: [2, 9], goal: 189,
    },
  ];
  /* العالم الثاني: مدينة الفوانيس — منصات متحركة، أعداء طائرة، وحارس في النهاية */
  const LEVELS2 = [
    {
      id: '2-1', name: 'سوق الفوانيس', pal: 'dusk', theme: 'lantern', w: 160,
      ground: [[0, 30], [34, 55], [59, 62, 8], [66, 90], [94, 110], [114, 130], [134, 159]],
      plat: [[12, 6, 4], [40, 6, 3], [46, 4, 3], [72, 6, 4], [80, 5, 3], [100, 6, 4], [120, 6, 3], [140, 6, 4]],
      q: [[14, 2], [47, 1], [101, 2]],
      beans: [[5, 9, 4], [12, 5, 4], [31, 7, 3, 1], [40, 5, 3], [46, 3, 3], [56, 7, 3, 1], [63, 7, 3, 1], [72, 5, 4], [80, 4, 3], [91, 7, 3, 1], [100, 5, 4], [111, 7, 3, 1], [120, 5, 3], [131, 7, 3, 1], [140, 5, 4], [148, 9, 4]],
      scorp: [24, 50, 76, 86, 104, 126, 146], fly: [[44, 5], [96, 4], [136, 5]], thorn: [[52, 9], [108, 9]], move: [],
      check: [66, 114], start: [2, 9], goal: 154,
    },
    {
      id: '2-2', name: 'قباب الليل', pal: 'night', theme: 'lantern', w: 180,
      ground: [[0, 24], [32, 48], [52, 54, 8], [58, 76], [86, 100], [104, 106, 7], [110, 128], [138, 152], [156, 179]],
      plat: [[10, 6, 3], [18, 5, 3], [38, 6, 4], [62, 6, 3], [68, 4, 3], [90, 6, 4], [114, 6, 3], [120, 4, 3], [142, 6, 4], [164, 6, 4]],
      q: [[11, 2], [69, 0], [121, 0], [165, 2]],
      beans: [[4, 9, 4], [10, 5, 3], [18, 4, 3], [26, 6, 4], [38, 5, 4], [49, 7, 3, 1], [55, 6, 3, 1], [62, 5, 3], [68, 3, 3], [79, 5, 5], [90, 5, 4], [101, 7, 3, 1], [107, 6, 3, 1], [114, 5, 3], [120, 3, 3], [130, 6, 5], [142, 5, 4], [153, 7, 3, 1], [164, 5, 4], [172, 9, 4]],
      scorp: [14, 40, 64, 72, 94, 116, 124, 144, 168], fly: [[20, 4], [46, 5], [82, 4], [112, 4], [134, 4], [160, 5]], thorn: [[45, 9], [98, 9], [150, 9]],
      move: [[25, 8, 3, 4, 'x'], [77, 7, 3, 6, 'x'], [129, 8, 3, 6, 'x']],
      check: [58, 110], start: [2, 9], goal: 174,
    },
    {
      id: '2-3', name: 'حارس المدينة', pal: 'night', theme: 'lantern', w: 200,
      ground: [[0, 20], [24, 40], [44, 46, 8], [50, 66], [76, 90], [94, 96, 7], [100, 120], [130, 146], [150, 199]],
      plat: [[8, 6, 3], [28, 6, 4], [34, 4, 3], [54, 6, 3], [60, 4, 3], [80, 6, 4], [104, 6, 3], [134, 6, 4], [156, 6, 3]],
      q: [[9, 2], [35, 0], [61, 0], [135, 2], [157, 2]],
      beans: [[3, 9, 4], [8, 5, 3], [21, 7, 3, 1], [28, 5, 4], [34, 3, 3], [41, 7, 3, 1], [47, 6, 3, 1], [54, 5, 3], [60, 3, 3], [68, 6, 6], [80, 5, 4], [91, 7, 3, 1], [97, 6, 3, 1], [104, 5, 3], [111, 3, 3], [122, 6, 6], [134, 5, 4], [147, 7, 3, 1], [152, 9, 4]],
      scorp: [12, 30, 38, 56, 64, 82, 88, 104, 116, 136, 144], fly: [[16, 4], [48, 4], [70, 3], [98, 4], [124, 3], [140, 4]], thorn: [[42, 9], [92, 9], [148, 9]],
      move: [[67, 8, 3, 5, 'x'], [121, 8, 3, 5, 'x'], [110, 6, 3, 3, 'y']],
      boss: 176, check: [50, 100, 150], start: [2, 9], goal: 192,
    },
  ];
  const WORLDS = [
    { id: 1, name: 'صنعاء القديمة', desc: 'بيوت برجية ونوافذ قمرية ملوّنة', bg: 'linear-gradient(160deg,#1A2A6B,#8A3E6E 60%,#F0922F)', levels: LEVELS },
    { id: 2, name: 'مدينة الفوانيس', desc: 'قباب وأسواق مسقوفة وفوانيس معلّقة — وحارس في النهاية', bg: 'linear-gradient(160deg,#02040F,#1A1446 55%,#3B2A66)', levels: LEVELS2 },
    { id: 3, name: 'مدرّجات الجبل', desc: 'جبال خضراء ومزارع البن', bg: 'linear-gradient(160deg,#0E4A5E,#2E8B7A)' },
    { id: 4, name: 'الجزيرة البعيدة', desc: 'أشجار غريبة وشواطئ بيضاء', bg: 'linear-gradient(160deg,#05223A,#0B6E8F)' },
  ];
  const ALL_LEVELS = [...LEVELS, ...LEVELS2];
  const worldOf = (def) => WORLDS.find((w) => w.levels?.includes(def)) || WORLDS[0];

  const FC = () => GCfg.get().flame;
  const lvName = (def) => FC().levels?.[def.id] || def.name;
  const isLocked = (def) => (FC().locked || []).includes(def.id);
  const worldName = (w) => (w.id === 1 ? FC().world : FC().worlds?.[w.id]?.name) || w.name;
  const worldDesc = (w) => (w.id === 1 ? FC().worldDesc : FC().worlds?.[w.id]?.desc) || w.desc;
  /* المرحلة مفتوحة إذا أنهى اللاعب التي قبلها (والعالم الجديد بعد إنهاء كل العالم السابق) */
  function levelOpen(def, stars) {
    if (isLocked(def)) return false;
    if (FC().unlock === 'all' || gstate().flame.all) return true;
    const i = ALL_LEVELS.indexOf(def);
    return i <= 0 || (stars[ALL_LEVELS[i - 1].id] || 0) > 0;
  }
  function dailyLevel(stars) {
    const open = ALL_LEVELS.filter((d) => levelOpen(d, stars));
    if (!open.length) return null;
    let hs = 0;
    for (const c of todayKey()) hs = (hs * 31 + c.charCodeAt(0)) >>> 0;
    return open[hs % open.length];
  }
  const maxHearts = () => Math.max(1, Math.min(5, Number(FC().hearts) || 3)) + (typeof Pro !== 'undefined' && Pro.has('games.bonus') ? 1 : 0); // Pro: قلب إضافي

  function buildLevel(def) {
    const W = def.w;
    const grid = Array.from({ length: ROWS }, () => Array(W).fill('.'));
    const set = (x, y, c) => { if (x >= 0 && x < W && y >= 0 && y < ROWS) grid[y][x] = c; };
    def.ground.forEach(([a, b, top = 10]) => { for (let x = a; x <= b; x++) for (let y = top; y < ROWS; y++) set(x, y, '#'); });
    def.plat.forEach(([x, y, n]) => { for (let i = 0; i < n; i++) set(x + i, y, '='); });
    def.q.forEach(([x, y]) => set(x, y, '?'));
    const beans = [];
    def.beans.forEach(([x, y, n, arc]) => {
      for (let i = 0; i < n; i++) {
        const lift = arc ? Math.round(Math.sin((i + 0.5) / n * Math.PI) * 2) : 0;
        const bx = x + i, by = y - lift;
        if (grid[by]?.[bx] === '.') beans.push({ x: bx * T + 6, y: by * T + 4, w: 20, h: 24, got: false, t: Math.random() * 6 });
      }
    });
    const groundY = (x) => { for (let y = 0; y < ROWS; y++) if (grid[y][x] !== '.') return y; return ROWS; };
    const enemies = def.scorp.map((x, i) => ({ kind: 'walk', slot: i, x: x * T + 2, y: (groundY(x) - 1) * T + 12, w: 28, h: 20, vx: -48, vy: 0, dead: 0, t: Math.random() * 3, hp: 1 }));
    (def.fly || []).forEach(([x, y], i) => enemies.push({ kind: 'fly', slot: i, x: x * T, y: y * T, x0: x * T, y0: y * T, w: 30, h: 20, vx: -46, vy: 0, dead: 0, t: Math.random() * 6, hp: 1 }));
    def.thorn.forEach(([x]) => enemies.push({ kind: 'thorn', x: x * T + 4, y: (groundY(x) - 1) * T + 6, w: 24, h: 26, vx: 0, vy: 0, dead: 0, t: 0 }));
    let boss = null;
    if (def.boss) { boss = { kind: 'boss', x: def.boss * T, y: (groundY(def.boss) - 2) * T, x0: def.boss * T, w: 56, h: 64, vx: -70, vy: 0, hp: 3, dead: 0, t: 0, inv: 0, jumpT: 2 }; enemies.push(boss); }
    const movers = (def.move || []).map(([x, y, n, r, axis]) => ({ x: x * T, y: y * T, x0: x * T, y0: y * T, w: n * T, h: 14, range: r * T, axis, t: Math.random() * 3, dx: 0, dy: 0 }));
    const checks = def.check.map((x) => ({ x: x * T, y: (groundY(x) - 1) * T, on: false }));
    const gx = def.goal;
    return { def, W, grid, beans, enemies, checks, movers, boss, total: beans.length,
      goal: { x: gx * T, y: (groundY(gx) - 4) * T, w: 3 * T, h: 4 * T },
      start: { x: def.start[0] * T + 5, y: def.start[1] * T + 2 } };
  }

  /* ================= الرسومات ================= */
  const loadImg = (svg, w, h) => new Promise((res) => {
    const img = new Image();
    img.onload = () => res(img);
    img.onerror = () => res(null);
    img.width = w; img.height = h;
    img.src = 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  });
  const QAM = (x, y, w, h, frame, glass) => `<g transform="translate(${x},${y}) scale(${w / 30},${h / 40})"><path d="M3 40V16a12 12 0 0 1 24 0v24z" fill="${frame}"/><path d="M6 38V17a9 9 0 0 1 18 0v21z" fill="${glass}"/><path d="M15 8v30M6 22h18M8 13l14 14M22 13 8 27" stroke="${frame}" stroke-width="1.4"/><path d="M9 20a6 6 0 0 1 12 0z" fill="#F0922F"/><circle cx="15" cy="30" r="3" fill="#C8509C"/><circle cx="10" cy="33" r="2" fill="#4CC93C"/><circle cx="20" cy="33" r="2" fill="#FFB43D"/></g>`;
  const crenel = (x, y, w, c) => { let d = `M${x} ${y}`; for (let i = 0; i < w; i += 14) d += `l7-9 7 9`; return `<path d="${d}z" fill="${c}"/>`; };

  function layerFar(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="384" viewBox="0 0 960 384">`;
    s += `<path d="M0 250 90 200 170 222 260 170 360 214 460 182 560 220 660 176 760 208 860 186 960 250V384H0z" fill="${p.far}" opacity=".9"/>`;
    s += `<g stroke="${p.farLine}" stroke-width="2" opacity=".7" fill="none"><path d="M60 236h60M200 214h80M300 226h70M420 208h70M600 204h80M700 214h70M820 208h60M150 250h90M480 244h110M740 240h120"/></g>`;
    s += `<path d="M0 290C160 270 300 296 480 284S760 266 960 290V384H0z" fill="${p.far}"/>`;
    return s + '</svg>';
  }
  function layerMid(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="384" viewBox="0 0 1100 384">`;
    const tower = (x, w, top) => {
      let t = `<rect x="${x}" y="${top}" width="${w}" height="${384 - top}" fill="${p.mid}"/><rect x="${x}" y="${top}" width="${w}" height="7" fill="${p.nearTrim}" opacity=".8"/>`;
      for (let yy = top + 18; yy < 330; yy += 26) for (let xx = x + 6; xx < x + w - 8; xx += 13) if ((xx * 7 + yy) % 5) t += `<rect x="${xx}" y="${yy}" width="5" height="8" fill="${p.midWin}"/>`;
      return t;
    };
    s += tower(80, 34, 150) + tower(116, 30, 128) + tower(148, 38, 160) + tower(188, 28, 176) + tower(560, 36, 158) + tower(598, 30, 136) + tower(630, 34, 170);
    // شجرة دم الأخوين
    s += `<g transform="translate(360,190)"><path d="M43 150c2-40 2-70 0-96" stroke="#4A3424" stroke-width="8" fill="none"/><path d="M44 58 20 34M44 58l24-24M44 54V30" stroke="#4A3424" stroke-width="6" stroke-linecap="round"/><ellipse cx="45" cy="26" rx="52" ry="18" fill="#2E6B45"/><ellipse cx="45" cy="21" rx="42" ry="11" fill="#3F8A58"/></g>`;
    s += `<g transform="translate(860,200)"><path d="M38 140c2-30 4-60 2-100" stroke="#4a3520" stroke-width="7" fill="none"/><g fill="#2E6B45"><path d="M40 40C28 26 12 28 2 36c14-2 26 2 38 4z"/><path d="M40 40C52 26 68 28 78 36c-14-2-26 2-38 4z"/><path d="M40 40C34 22 22 12 10 12c12 6 22 16 30 28z"/><path d="M40 40c6-18 18-28 30-28-12 6-22 16-30 28z"/></g></g>`;
    s += `<path d="M0 318C140 300 260 318 400 310S640 292 1100 316V384H0z" fill="${p.haze}" opacity=".55"/>`;
    return s + '</svg>';
  }
  function layerNear(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="384" viewBox="0 0 1280 384">`;
    const house = (x, w, top) => {
      let t = `<rect x="${x}" y="${top}" width="${w}" height="${384 - top}" fill="${p.near}"/>` + crenel(x, top, w, p.nearTrim) + `<rect x="${x}" y="${top}" width="${w}" height="6" fill="${p.nearTrim}"/>`;
      for (let yy = top + 44; yy < 330; yy += 46) t += `<rect x="${x}" y="${yy}" width="${w}" height="4" fill="${p.nearTrim}"/>`;
      const cols = Math.max(1, Math.floor((w - 12) / 30));
      for (let yy = top + 12; yy < 300; yy += 46) for (let c = 0; c < cols; c++) {
        const wx = x + 10 + c * ((w - 20) / cols) + ((w - 20) / cols - 18) / 2;
        t += QAM(wx, yy, 18, 24, p.nearTrim, p.lit && (c + yy) % 3 ? '#FFB43D' : p.win);
      }
      return t;
    };
    s += house(30, 76, 150) + house(116, 58, 118) + house(420, 92, 170) + house(740, 64, 136) + house(812, 80, 186) + house(1110, 70, 150);
    return s + '</svg>';
  }
  /* ---------- رسومات مدينة الفوانيس ---------- */
  function layerFarL(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="960" height="384" viewBox="0 0 960 384">`;
    s += `<path d="M0 260C120 230 220 250 320 236S520 214 640 238 820 228 960 250V384H0z" fill="${p.far}"/>`;
    const dome = (x, w, y) => `<rect x="${x}" y="${y}" width="${w}" height="${384 - y}" fill="${p.far}"/><path d="M${x + w * 0.1} ${y}a${w * 0.4} ${w * 0.42} 0 0 1 ${w * 0.8} 0z" fill="${p.far}"/><rect x="${x + w / 2 - 1.5}" y="${y - w * 0.42 - 12}" width="3" height="12" fill="${p.farLine}"/>`;
    s += dome(60, 90, 220) + dome(300, 120, 205) + dome(560, 80, 226) + dome(760, 110, 212);
    s += `<g fill="${p.farLine}" opacity=".7"><rect x="200" y="150" width="10" height="100"/><path d="M196 150h18l-9-16z"/><rect x="700" y="160" width="10" height="90"/><path d="M696 160h18l-9-16z"/></g>`;
    return s + '</svg>';
  }
  function layerMidL(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="1100" height="384" viewBox="0 0 1100 384">`;
    const block = (x, w, top) => {
      let t = `<rect x="${x}" y="${top}" width="${w}" height="${384 - top}" fill="${p.mid}"/><path d="M${x + w * 0.15} ${top}a${w * 0.35} ${w * 0.36} 0 0 1 ${w * 0.7} 0z" fill="${p.mid}"/>`;
      for (let yy = top + 20; yy < 330; yy += 34) for (let xx = x + 8; xx < x + w - 14; xx += 18) t += `<path d="M${xx} ${yy + 14}v-7a4 4 0 0 1 8 0v7z" fill="${p.midWin}" opacity="${p.lit ? 0.85 : 0.5}"/>`;
      return t;
    };
    s += block(40, 70, 170) + block(130, 90, 150) + block(420, 80, 180) + block(700, 100, 160) + block(860, 70, 190);
    s += `<g transform="translate(280,120)"><rect x="0" y="40" width="22" height="224" fill="${p.mid}"/><rect x="-4" y="36" width="30" height="8" fill="${p.nearTrim}" opacity=".7"/><path d="M-2 40h26l-13-30z" fill="${p.mid}"/><circle cx="11" cy="6" r="4" fill="${p.lit ? '#FFB43D' : p.nearTrim}"/></g>`;
    s += `<path d="M0 320C160 304 300 322 460 312S760 298 1100 318V384H0z" fill="${p.haze}" opacity=".5"/>`;
    return s + '</svg>';
  }
  function layerNearL(p) {
    let s = `<svg xmlns="http://www.w3.org/2000/svg" width="1280" height="384" viewBox="0 0 1280 384">`;
    const arcade = (x, w, top) => {
      let t = `<rect x="${x}" y="${top}" width="${w}" height="${384 - top}" fill="${p.near}"/><rect x="${x - 4}" y="${top}" width="${w + 8}" height="7" rx="2" fill="${p.nearTrim}"/>`;
      const n = Math.max(1, Math.floor(w / 34));
      for (let i = 0; i < n; i++) {
        const ax = x + 6 + i * ((w - 12) / n), aw = (w - 12) / n - 6;
        t += `<path d="M${ax} 384V${top + 70}a${aw / 2} ${aw / 2} 0 0 1 ${aw} 0V384z" fill="${p.lit ? '#3A2A1E' : '#5A3E2E'}"/>`;
        t += `<path d="M${ax + aw * 0.2} ${top + 46}v-10a${aw * 0.3} ${aw * 0.3} 0 0 1 ${aw * 0.6} 0v10z" fill="${p.lit ? '#FFB43D' : p.win}" opacity=".9"/>`;
      }
      return t;
    };
    s += arcade(40, 120, 190) + arcade(430, 100, 170) + arcade(780, 140, 200) + arcade(1100, 110, 180);
    // حبال الفوانيس
    const cols = ['#FFB43D', '#C8509C', '#56C8FF', '#1FC7A0'];
    s += `<path d="M0 120Q160 160 320 124T640 124T960 124T1280 120" fill="none" stroke="${p.str}" stroke-width="2"/>`;
    for (let i = 0; i < 16; i++) {
      const x = 40 + i * 80, y = 132 + Math.sin(i * 1.3) * 10;
      s += `<g transform="translate(${x},${y})">${p.lit ? `<circle r="20" fill="${cols[i % 4]}" opacity=".22"/>` : ''}<path d="M-6-8h12l-2 16h-8z" fill="${cols[i % 4]}"/><path d="M-8-10h16l-3-5h-10z" fill="#7A5A2E"/></g>`;
    }
    return s + '</svg>';
  }
  /* بوابة المدينة (هدف عالم الفوانيس) */
  const GATE = (p) => `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="256" viewBox="0 0 96 128"><path d="M8 128V44a40 40 0 0 1 80 0v84z" fill="#2E6B80"/><path d="M8 44a40 40 0 0 1 80 0" fill="none" stroke="#FFD66B" stroke-width="3"/><circle cx="48" cy="6" r="4" fill="#FFD66B"/><rect x="46" y="8" width="4" height="8" fill="#FFD66B"/><path d="M26 128V70a22 22 0 0 1 44 0v58z" fill="${p.lit ? '#FFB43D' : '#1E3A48'}"/><circle cx="48" cy="72" r="34" fill="#FFB43D" opacity="${p.lit ? 0.22 : 0.08}"/><g fill="#FFD66B"><circle cx="18" cy="60" r="3"/><circle cx="78" cy="60" r="3"/><circle cx="18" cy="84" r="3"/><circle cx="78" cy="84" r="3"/></g><path d="M36 50h24M40 56h16" stroke="#FFD66B" stroke-width="2" stroke-linecap="round"/></svg>`;
  /* الحارس — فانوس عملاق */
  const BOSS = (hurt) => `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="216" viewBox="0 0 96 108"><circle cx="48" cy="56" r="46" fill="#FFB43D" opacity=".18"/><path d="M30 6h36l-6 12H36z" fill="#7A5A2E"/><rect x="44" y="0" width="8" height="8" rx="3" fill="#7A5A2E"/><path d="M22 20h52l-6 64H28z" fill="${hurt ? '#FF6B6B' : '#3B2A66'}"/><path d="M28 26h40l-5 52H33z" fill="#FFB43D" opacity=".9"/><path d="M48 26v52M30 44h36M31 62h34" stroke="#3B2A66" stroke-width="3"/><ellipse cx="40" cy="40" rx="5" ry="6" fill="#fff"/><ellipse cx="56" cy="40" rx="5" ry="6" fill="#fff"/><circle cx="41" cy="41" r="3" fill="#E5484D"/><circle cx="55" cy="41" r="3" fill="#E5484D"/><path d="M34 32l10 4M62 32l-10 4" stroke="#1a0e04" stroke-width="3" stroke-linecap="round"/><path d="M40 54c4 3 12 3 16 0" stroke="#1a0e04" stroke-width="2.5" fill="none" stroke-linecap="round"/><path d="M26 84h44l-4 10H30z" fill="#7A5A2E"/><path d="M34 94v12M62 94v12" stroke="#7A5A2E" stroke-width="6" stroke-linecap="round"/><path d="M22 40 8 30M74 40l14-10" stroke="#3B2A66" stroke-width="6" stroke-linecap="round"/></svg>`;
  const SCORP = (c1) => `<svg xmlns="http://www.w3.org/2000/svg" width="120" height="72" viewBox="0 0 60 36"><ellipse cx="28" cy="26" rx="16" ry="8" fill="${c1}"/><path d="M42 24c10-2 14-10 10-18-2-4-6-2-5 2 2 6-2 10-6 10" fill="none" stroke="${c1}" stroke-width="5" stroke-linecap="round"/><circle cx="50" cy="5" r="3" fill="#C8509C"/><path d="M14 22 4 16M14 28 3 32M20 32l-4 4M36 32l4 4" stroke="${c1}" stroke-width="3" stroke-linecap="round"/><circle cx="18" cy="22" r="2.2" fill="#FFB43D"/><circle cx="24" cy="21" r="2.2" fill="#FFB43D"/></svg>`;
  const THORN = `<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80" viewBox="0 0 40 40"><circle cx="20" cy="22" r="11" fill="#5A6B3A"/><g stroke="#5A6B3A" stroke-width="4" stroke-linecap="round"><path d="M20 4v8M20 32v6M2 22h8M30 22h8M7 9l6 6M27 29l6 6M33 9l-6 6M13 29l-6 6"/></g><circle cx="16" cy="19" r="2" fill="#C8509C"/><circle cx="24" cy="24" r="2" fill="#C8509C"/></svg>`;
  const BEAN = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="48" viewBox="0 0 20 24"><ellipse cx="10" cy="12" rx="8" ry="10.5" fill="#7A4424" transform="rotate(-18 10 12)"/><path d="M12.5 2.5c-5 4-5 14 0 19" stroke="#2A1408" stroke-width="2" fill="none" transform="rotate(-18 10 12)"/><ellipse cx="6.5" cy="8" rx="1.8" ry="3.6" fill="#C0784A" opacity=".8" transform="rotate(-18 10 12)"/></svg>`;
  const HOUSE = (p) => `<svg xmlns="http://www.w3.org/2000/svg" width="192" height="256" viewBox="0 0 96 128"><rect x="4" y="18" width="88" height="110" fill="#8A5A3E"/>${crenel(4, 18, 88, '#F3EDE4')}<rect x="4" y="18" width="88" height="5" fill="#F3EDE4"/><rect x="4" y="62" width="88" height="4" fill="#F3EDE4"/>${QAM(34, 26, 28, 34, '#F3EDE4', '#FFB43D')}<circle cx="48" cy="44" r="30" fill="#FFB43D" opacity=".22"/><path d="M34 128V96a14 14 0 0 1 28 0v32z" fill="#4A2E1E"/><path d="M37 128V97a11 11 0 0 1 22 0v31z" fill="${p.lit ? '#FFB43D' : '#6A3E28'}"/><rect x="12" y="74" width="14" height="18" rx="7" fill="#243A8C"/><rect x="70" y="74" width="14" height="18" rx="7" fill="#243A8C"/></svg>`;
  const LANTERN = (on) => `<svg xmlns="http://www.w3.org/2000/svg" width="64" height="128" viewBox="0 0 32 64"><rect x="14" y="20" width="4" height="44" fill="#5a4630"/><path d="M6 8h20l-3 16H9z" fill="${on ? '#FFB43D' : '#6A5A48'}"/><path d="M4 7h24l-5-7H9z" fill="#7A5A2E"/>${on ? '<circle cx="16" cy="16" r="15" fill="#FFB43D" opacity=".28"/>' : ''}</svg>`;

  function brickTile(p, top, kind) {
    const c = document.createElement('canvas');
    c.width = c.height = 64;
    const x = c.getContext('2d');
    x.scale(2, 2);
    const [base, mortar, light] = p.brick;
    if (kind === '?') {
      const g = x.createLinearGradient(0, 0, 32, 32); g.addColorStop(0, '#FFB43D'); g.addColorStop(1, '#E0702F');
      x.fillStyle = g; roundRect(x, 1, 1, 30, 30, 6); x.fill();
      x.strokeStyle = '#FFE0A0'; x.lineWidth = 2; roundRect(x, 2, 2, 28, 28, 5); x.stroke();
      x.fillStyle = '#fff'; x.font = 'bold 20px sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.fillText('✦', 16, 17);
      return c;
    }
    if (kind === 'u') {
      x.fillStyle = mortar; roundRect(x, 1, 1, 30, 30, 6); x.fill();
      x.fillStyle = 'rgba(0,0,0,.15)'; x.fillRect(6, 6, 20, 20);
      return c;
    }
    x.fillStyle = kind === '=' ? light : base; x.fillRect(0, 0, 32, 32);
    x.strokeStyle = mortar; x.lineWidth = 2;
    x.beginPath(); x.moveTo(0, 11); x.lineTo(32, 11); x.moveTo(0, 22); x.lineTo(32, 22);
    x.moveTo(16, 0); x.lineTo(16, 11); x.moveTo(8, 11); x.lineTo(8, 22); x.moveTo(24, 11); x.lineTo(24, 22); x.moveTo(16, 22); x.lineTo(16, 32); x.stroke();
    if (top) { x.fillStyle = light; x.fillRect(0, 0, 32, 4); x.fillStyle = 'rgba(255,255,255,.25)'; x.fillRect(0, 0, 32, 1.5); }
    if (kind === '=') { x.fillStyle = 'rgba(0,0,0,.18)'; x.fillRect(0, 28, 32, 4); }
    return c;
  }
  function roundRect(x, a, b, w, h, r) { x.beginPath(); x.moveTo(a + r, b); x.arcTo(a + w, b, a + w, b + h, r); x.arcTo(a + w, b + h, a, b + h, r); x.arcTo(a, b + h, a, b, r); x.arcTo(a, b, a + w, b, r); x.closePath(); }

  /* الوقت: نهار/غروب/ليل/تلقائي (حسب الساعة)/الأصلي للمرحلة */
  const TODS = { day: ['☀️', 'نهار'], dusk: ['🌇', 'غروب'], night: ['🌙', 'ليل'], auto: ['⏱️', 'تلقائي'] };
  function todKey(def, tod) {
    if (tod === 'auto') { const hr = new Date().getHours(); return hr >= 6 && hr < 16 ? 'day' : hr >= 16 && hr < 19 ? 'dusk' : 'night'; }
    return TODS[tod] && tod !== 'auto' ? tod : def.pal;
  }
  const palOf = (def, key) => (def.theme === 'lantern' ? PAL_L : PAL)[key] || PAL[def.pal];

  async function loadArt(def, heroId, key, look, skins) {
    const p = palOf(def, key);
    const L2 = def.theme === 'lantern';
    const poses = ['stand', 'run1', 'run2', 'jump'];
    const monIds = [...new Set([...(skins?.walk || []), ...(skins?.fly || [])])];
    const monCfg = (id) => (FC().shop?.monsters || {})[id] || {};
    const [far, mid, near, thorn, bean, house, lOff, lOn, boss, bossHurt, ...rest] = await Promise.all([
      loadImg(L2 ? layerFarL(p) : layerFar(p), 960, 384), loadImg(L2 ? layerMidL(p) : layerMid(p), 1100, 384), loadImg(L2 ? layerNearL(p) : layerNear(p), 1280, 384),
      loadImg(THORN, 80, 80), loadImg(BEAN, 40, 48),
      loadImg(L2 ? GATE(p) : HOUSE(p), 192, 256), loadImg(LANTERN(false), 64, 128), loadImg(LANTERN(true), 64, 128),
      def.boss ? loadImg(BOSS(false), 192, 216) : null, def.boss ? loadImg(BOSS(true), 192, 216) : null,
      ...poses.map((ps) => loadImg(heroSVG(heroId, ps, 160, look), 160, 220)),
      ...monIds.map((id) => loadImg(monsterSVG(id, monCfg(id).c1, monCfg(id).c2), 120, 72)),
    ]);
    const hero = {}, mon = {};
    poses.forEach((ps, i) => (hero[ps] = rest[i]));
    monIds.forEach((id, i) => (mon[id] = rest[poses.length + i]));
    return { p, key, far, mid, near, thorn, bean, house, lOff, lOn, hero, mon, boss, bossHurt,
      tiles: { top: brickTile(p, true, '#'), in: brickTile(p, false, '#'), plat: brickTile(p, true, '='), q: brickTile(p, false, '?'), u: brickTile(p, false, 'u') } };
  }

  /* ================= الصوت ================= */
  let AC = null;
  function beep(kind) {
    if (!gstate().sound) return;
    try {
      AC = AC || new (window.AudioContext || window.webkitAudioContext)();
      const t = AC.currentTime;
      const tone = (f1, f2, dur, type = 'square', vol = 0.06, at = 0) => {
        const o = AC.createOscillator(), g = AC.createGain();
        o.type = type; o.frequency.setValueAtTime(f1, t + at); o.frequency.exponentialRampToValueAtTime(f2, t + at + dur);
        g.gain.setValueAtTime(vol, t + at); g.gain.exponentialRampToValueAtTime(0.001, t + at + dur);
        o.connect(g).connect(AC.destination); o.start(t + at); o.stop(t + at + dur + 0.02);
      };
      if (kind === 'jump') tone(380, 760, 0.13);
      else if (kind === 'jump2') tone(560, 1100, 0.12);
      else if (kind === 'bean') { tone(988, 988, 0.06, 'sine', 0.08); tone(1319, 1319, 0.12, 'sine', 0.08, 0.06); }
      else if (kind === 'stomp') tone(260, 70, 0.16, 'triangle', 0.14);
      else if (kind === 'hurt') tone(320, 90, 0.3, 'sawtooth', 0.07);
      else if (kind === 'fire') tone(700, 240, 0.14, 'triangle', 0.08);
      else if (kind === 'block') tone(520, 1040, 0.1, 'square', 0.06);
      else if (kind === 'check') { tone(660, 660, 0.08, 'sine', 0.08); tone(990, 990, 0.14, 'sine', 0.08, 0.08); }
      else if (kind === 'win') [523, 659, 784, 1046].forEach((f, i) => tone(f, f, 0.16, 'square', 0.06, i * 0.12));
      else if (kind === 'over') [392, 330, 262].forEach((f, i) => tone(f, f * 0.98, 0.22, 'triangle', 0.08, i * 0.2));
    } catch { /* لا شيء */ }
  }

  /* ================= خريطة المراحل التفاعلية ================= */
  const MAP = { world: 0, sel: null };
  const PATH_D = 'M300 470 C 220 440, 70 430, 110 372 S 300 300, 262 262 S 60 196, 106 158 S 300 96, 276 58';
  const NODE_POS = [[77, 88], [28, 70], [67, 49], [27, 29], [71, 11]];
  function worldDone(w, stars) { return !!w.levels && w.levels.every((d) => (stars[d.id] || 0) > 0); }
  function worldOpen(w, stars) { return !!w.levels && levelOpen(w.levels[0], stars); }

  function openMap() {
    const g = gstate();
    const stars = g.flame.stars || {};
    const total = Object.values(stars).reduce((a, b) => a + b, 0);
    const maxStars = ALL_LEVELS.length * 3;
    // العالم الافتراضي: آخر عالم مفتوح
    if (MAP.world == null || !WORLDS[MAP.world]?.levels || !worldOpen(WORLDS[MAP.world], stars)) {
      MAP.world = 0;
      WORLDS.forEach((w, i) => { if (w.levels && worldOpen(w, stars)) MAP.world = i; });
    }
    const W = WORLDS[MAP.world];
    const firstOpen = W.levels.find((d) => levelOpen(d, stars) && !(stars[d.id] > 0)) || [...W.levels].reverse().find((d) => levelOpen(d, stars)) || W.levels[0];
    if (!MAP.sel || !W.levels.includes(MAP.sel) || !levelOpen(MAP.sel, stars)) MAP.sel = firstOpen;
    const look = Look.get();
    const tod = look.tod || FC().tod || 'level';
    const daily = FC().daily?.on !== false ? dailyLevel(stars) : null;
    const dailyDone = g.flame.daily === todayKey();
    openScreen((el) => {
      const nextW = WORLDS[MAP.world + 1];
      const nodes = [...W.levels.map((d, i) => ({ d, i })), nextW ? { next: nextW } : null].filter(Boolean);
      const mapBox = h('div', { class: `fl-map${W.id === 2 ? ' w2' : ''}` });
      const bg = W.id === 2
        ? `<defs><linearGradient id="mk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#02040F"/><stop offset=".6" stop-color="#1A1446"/><stop offset="1" stop-color="#3B2A66"/></linearGradient></defs><rect width="390" height="530" fill="url(#mk)"/><path d="M300 70a26 26 0 1 0 17 46 21 21 0 1 1-17-46z" fill="#F3EDE4"/>${Array.from({ length: 36 }, (_, i) => `<circle cx="${(i * 137) % 390}" cy="${(i * 53) % 240}" r="${i % 3 ? 1 : 1.6}" fill="#fff" opacity=".7"/>`).join('')}<g fill="#241A4E">${[[0, 380, 80], [70, 350, 110], [170, 395, 80], [240, 360, 150]].map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="${530 - y}"/><path d="M${x + w * 0.15} ${y}a${w * 0.35} ${w * 0.36} 0 0 1 ${w * 0.7} 0z"/>`).join('')}</g><path d="M0 330Q100 360 200 330T390 330" fill="none" stroke="#6B4A7A" stroke-width="1.6"/>${[30, 90, 150, 210, 270, 330].map((x, i) => `<g transform="translate(${x},${340 + Math.sin(i) * 6})"><circle r="14" fill="#FFB43D" opacity=".22"/><path d="M-5-7h10l-2 13h-6z" fill="${['#FFB43D', '#C8509C', '#56C8FF'][i % 3]}"/></g>`).join('')}`
        : `<defs><linearGradient id="mk" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#0B1440"/><stop offset=".55" stop-color="#4A2A6E"/><stop offset="1" stop-color="#E07A3A"/></linearGradient></defs><rect width="390" height="530" fill="url(#mk)"/><circle cx="320" cy="70" r="26" fill="#FFB43D" opacity=".9"/><circle cx="320" cy="70" r="46" fill="#FFB43D" opacity=".15"/>${Array.from({ length: 30 }, (_, i) => `<circle cx="${(i * 137) % 390}" cy="${(i * 53) % 220}" r="${i % 3 ? 1 : 1.6}" fill="#fff" opacity=".6"/>`).join('')}<g fill="#2A1E48" opacity=".9">${[[0, 380, 60], [50, 340, 50], [95, 400, 70], [160, 360, 46], [200, 410, 80], [275, 350, 55], [325, 390, 65]].map(([x, y, w]) => `<rect x="${x}" y="${y}" width="${w}" height="${530 - y}"/><rect x="${x + w / 2 - 6}" y="${y + 20}" width="12" height="16" rx="6" fill="#FFB43D" opacity=".7"/>`).join('')}</g>`;
      mapBox.innerHTML = `<svg viewBox="0 0 390 530" preserveAspectRatio="xMidYMid slice" class="fl-map-bg">${bg}<path d="${PATH_D}" fill="none" stroke="#000" stroke-opacity=".35" stroke-width="22" stroke-linecap="round"/><path d="${PATH_D}" fill="none" stroke="#F3EDE4" stroke-opacity=".85" stroke-width="14" stroke-linecap="round"/><path d="${PATH_D}" fill="none" stroke="#C98A4B" stroke-width="3" stroke-dasharray="2 12" stroke-linecap="round"/></svg>`;
      nodes.forEach((n, k) => {
        const [x, y] = NODE_POS[Math.min(k, NODE_POS.length - 1)];
        if (n.next) {
          const open = worldOpen(n.next, stars);
          mapBox.append(h('button', { type: 'button', class: `fl-node ${n.next.levels && open ? 'next' : 'lock'}`, style: { left: x + '%', top: y + '%' }, onclick: () => { if (n.next.levels && open) { MAP.world += 1; MAP.sel = null; openMap(); } else toast(n.next.levels ? 'أنهِ كل مراحل هذا العالم لتفتح التالي' : `${FC().soon} 🔥`); } },
            h('span', { class: 'c', text: n.next.levels ? (open ? '→' : '🔒') : '✨' }), h('small', { text: worldName(n.next) })));
          return;
        }
        const d = n.d, open = levelOpen(d, stars), st = stars[d.id] || 0, sel = MAP.sel === d;
        mapBox.append(h('button', { type: 'button', class: `fl-node ${open ? (st ? 'done' : 'cur') : 'lock'}${sel ? ' sel' : ''}${daily === d && !dailyDone ? ' daily' : ''}`, style: { left: x + '%', top: y + '%' }, disabled: !open,
          onclick: () => { MAP.sel = d; openMap(); } },
          h('span', { class: 'c num', text: open ? d.id : '🔒' }),
          open ? h('span', { class: 'st', text: '★'.repeat(st) + '☆'.repeat(3 - st) }) : null,
          h('small', { text: isLocked(d) ? 'مغلقة حالياً' : lvName(d) + (d.boss ? ' 🏮' : '') })));
        if (sel) mapBox.append(h('span', { class: 'fl-map-hero', style: { left: x + '%', top: (y - 6) + '%' } }, heroNode(myHero(), 44, 'stand', look)));
      });
      const todSeg = h('div', { class: 'fl-tod' }, ...Object.entries(TODS).map(([k, [ic, l]]) => h('button', { type: 'button', class: tod === k ? 'on' : '', onclick: async () => { await Look.set({ tod: tod === k ? 'level' : k }); openMap(); } }, h('b', { text: ic }), h('small', { text: l }))));
      el.append(h('div', { class: 'g-wrap fl-mapwrap' },
        gHead(FC().name, h('button', { type: 'button', class: 'chip g-chip fl-bean', onclick: () => Look.openCloset('colors', openMap) }, h('i', { class: 'bean' }), UI.n(Look.balance()))),
        h('div', { class: 'fl-wtabs' }, ...WORLDS.map((w, i) => {
          const open = w.levels && worldOpen(w, stars);
          return h('button', { type: 'button', class: `fl-wtab${i === MAP.world ? ' on' : ''}${!open ? ' lock' : ''}`, onclick: () => { if (!open) return toast(w.levels ? 'أنهِ العالم السابق لتفتح هذا العالم' : `${worldName(w)} — ${FC().soon} 🔥`); MAP.world = i; MAP.sel = null; openMap(); } },
            h('span', { class: 'num', text: UI.n(i + 1) }), open ? worldName(w) : `🔒 ${w.levels ? worldName(w) : FC().soon}`, worldDone(w, stars) ? ' ✓' : '');
        })),
        h('p', { class: 'fl-wdesc', text: worldDesc(W) }),
        mapBox,
        daily ? h('button', { type: 'button', class: `fl-daily${dailyDone ? ' done' : ''}`, onclick: () => { const wi = WORLDS.findIndex((w) => w.levels?.includes(daily)); MAP.world = wi; MAP.sel = daily; openMap(); } },
          h('span', { text: dailyDone ? '✅' : '⚡' }), h('div', {}, h('b', { text: dailyDone ? 'أنهيت تحدّي اليوم' : `تحدّي اليوم: ${daily.id} · ${lvName(daily)}` }), h('small', { text: dailyDone ? 'تحدٍّ جديد غداً' : `نقاط ×${FC().daily?.mult || 2} مرة واحدة اليوم` }))) : null,
        todSeg,
        h('button', { type: 'button', class: 'fl-play', disabled: !MAP.sel || !levelOpen(MAP.sel, stars), onclick: () => start(MAP.sel) }, '▶ ', `ابدأ ${MAP.sel.id} · ${lvName(MAP.sel)}`),
        h('div', { class: 'fl-tools' },
          h('button', { type: 'button', onclick: () => Look.openCloset('colors', openMap) }, heroNode(myHero(), 26, 'stand', look), h('span', { text: 'خزانة البطل' })),
          h('button', { type: 'button', onclick: () => Look.openCloset('monsters', openMap) }, h('span', { class: 'ic' }, monsterNode(Look.skins().walk[0], 34)), h('span', { text: 'الوحوش' })),
          h('button', { type: 'button', onclick: () => Look.openControls(openMap) }, h('span', { class: 'ic', text: '🎮' }), h('span', { text: 'الأزرار' })),
          h('button', { type: 'button', onclick: () => openGameSettings() }, h('span', { class: 'ic', text: '⚙️' }), h('span', { text: 'الإعدادات' }))),
        h('p', { class: 'fl-sub', text: `⭐ ${total}/${maxStars} · أنهِ المرحلة لتفتح التالية، وأنهِ العالم لتفتح الذي بعده` })));
      UI.digitize(el);
    }, { onBack: closeScreen });
  }
  const monsterNode = (id, w) => { const d = document.createElement('span'); d.className = 'mon-art'; d.style.width = w + 'px'; const m = (FC().shop?.monsters || {})[id] || {}; d.innerHTML = monsterSVG(id, m.c1, m.c2).replace('width="120" height="72"', 'width="100%" height="100%"'); return d; };

  /* إعدادات اللعبة: الاتجاه والصوت */
  function openGameSettings() {
    const g = gstate();
    const sheet = $('#hero-sheet') || document.body.appendChild(h('section', { class: 'sheet', id: 'hero-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }));
    const orientSeg = h('div', { class: 'seg seg-3' }, ...[['landscape', 'بالعرض'], ['portrait', 'بالطول'], ['auto', 'تلقائي']].map(([k, l]) =>
      h('label', {}, h('input', { type: 'radio', name: 'fl-or', value: k, checked: (g.orient || 'landscape') === k, onchange: () => gsave((x) => { x.orient = k; }) }), h('span', { text: l }))));
    const soundSw = h('input', { type: 'checkbox', checked: g.sound !== false, onchange: (e) => gsave((x) => { x.sound = e.target.checked; }) });
    sheet.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('h2', { text: 'إعدادات اللعبة' })),
      h('div', { class: 'sheet-body' },
        h('div', { class: 'set-row' }, h('strong', {}, icon('phone', { size: 16 }), ' اتجاه الشاشة')), orientSeg,
        h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'الأصوات' })), h('span', { class: 'switch' }, soundSw, h('span', { class: 'track' }))),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => { closeSheet(sheet); setTimeout(() => openHeroPicker(() => openMap()), 220); } }, 'تغيير البطل')));
    openSheet('#hero-sheet');
  }

  async function lockOrientation(mode) {
    if (!Platform.isNative) return;
    const so = Platform.plugin('ScreenOrientation');
    try { if (mode === 'auto') await so.unlock(); else await so.lock({ orientation: mode }); } catch { /* لا شيء */ }
  }
  let unlockTimer = 0;
  function unlockOrientation() {
    clearTimeout(unlockTimer);
    if (!Platform.isNative) return;
    unlockTimer = setTimeout(() => Platform.plugin('ScreenOrientation').unlock().catch(() => {}), 400);
  }

  /* ================= أزرار التحكم (٥ أشكال) ================= */
  function buildControls(c, input, btn) {
    const style = c.style || 'classic';
    const wrap = h('div', { class: `fl-ctrl ctl-${style}${c.left ? ' is-left' : ''}`, style: { '--ctl-s': String(c.size || 1), '--ctl-o': String(c.opacity || 1) } });
    const jumpB = (cls = 'fl-jump', txt = 'قفز') => { const b = btn(cls, 'قفز', 'jump'); b.append(h('span', { text: txt })); return b; };
    const fireB = (cls = 'fl-fire') => { const b = btn(cls, 'لهب', 'fire'); b.append(h('span', { text: '🔥' })); return b; };
    const zoneMove = (el, onDir) => {
      el.addEventListener('pointerdown', (e) => { e.preventDefault(); el.setPointerCapture?.(e.pointerId); onDir(e); });
      el.addEventListener('pointermove', (e) => { if (el.hasPointerCapture?.(e.pointerId)) onDir(e); });
      ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((ev) => el.addEventListener(ev, () => { input.l = input.r = false; delete el.dataset.dir; onDir(null); }));
    };
    let left, right;
    if (style === 'stick') {
      const knob = h('i', { class: 'fl-knob' });
      const stick = h('div', { class: 'fl-stick', 'aria-label': 'عصا التحكم' }, knob);
      zoneMove(stick, (e) => {
        if (!e) { knob.style.transform = ''; return; }
        const r = stick.getBoundingClientRect();
        const dx = Math.max(-1, Math.min(1, (e.clientX - (r.left + r.width / 2)) / (r.width / 2)));
        knob.style.transform = `translateX(${dx * r.width * 0.28}px)`;
        input.l = dx < -0.22; input.r = dx > 0.22;
      });
      left = [stick]; right = [fireB(), jumpB()];
    } else if (style === 'dpad') {
      const d = (cls, lbl, key) => { const b = btn(`fl-dp ${cls}`, lbl, key); b.append(h('span', { text: lbl })); return b; };
      left = [h('div', { class: 'fl-dpad' }, d('dp-u', '▲', 'jump'), d('dp-l', '◀', 'l'), h('span', { class: 'dp-c' }), d('dp-r', '▶', 'r'))];
      const bFire = fireB('fl-ab ab-b'); bFire.firstChild.textContent = 'B';
      right = [bFire, jumpB('fl-ab ab-a', 'A')];
    } else if (style === 'ghost') {
      const g1 = btn('fl-gh', 'يسار', 'l'); g1.append(h('span', { text: '◀' }));
      const g2 = btn('fl-gh', 'يمين', 'r'); g2.append(h('span', { text: '▶' }));
      left = [g1, g2]; right = [fireB('fl-gh sm'), jumpB('fl-gh big', '⤒')];
    } else if (style === 'big') {
      const zone = h('div', { class: 'fl-zone move' }, h('span', { class: 'z-l', text: '◀' }), h('span', { class: 'z-r', text: '▶' }));
      zoneMove(zone, (e) => { if (!e) return; const r = zone.getBoundingClientRect(); const lft = e.clientX < r.left + r.width / 2; input.l = lft; input.r = !lft; zone.dataset.dir = lft ? 'l' : 'r'; });
      left = [zone]; right = [fireB('fl-fire fl-zfire'), jumpB('fl-zone jump', 'قفز')];
    } else {
      const pad = h('div', { class: 'fl-pad', 'aria-label': 'تحريك' }, h('span', { class: 'fl-arrow l', text: '◀' }), h('span', { class: 'fl-arrow r', text: '▶' }));
      zoneMove(pad, (e) => { if (!e) return; const r = pad.getBoundingClientRect(); const lft = e.clientX < r.left + r.width / 2; input.l = lft; input.r = !lft; pad.dataset.dir = lft ? 'l' : 'r'; });
      left = [pad]; right = [fireB(), jumpB()];
    }
    wrap.append(h('div', { class: 'fl-cl' }, ...left), h('div', { class: 'fl-cr' }, ...right));
    return wrap;
  }

  /* ================= اللعب ================= */
  async function start(def) {
    // حد المراحل المجانية (من لوحة التحكم) لغير المشتركين
    if (typeof Pro !== 'undefined' && !Pro.allows('games.flame', ALL_LEVELS.indexOf(def))) return Pro.gate('games.flame', ALL_LEVELS.indexOf(def));
    const g = gstate();
    const orient = g.orient || 'landscape';
    const L = buildLevel(def);
    const look = Look.get();
    const skins = Look.skins();
    let todSel = look.tod || FC().tod || 'level';
    let palKey = todKey(def, todSel);
    // أشكال الوحوش حسب اختيار اللاعب
    for (const e of L.enemies) {
      if (e.kind === 'walk') {
        e.skin = skins.walk[e.slot % skins.walk.length];
        const m = monsterById(e.skin);
        if (m.hop) { e.kind = 'hop'; e.vx = -30; e.hopT = 0.6 + Math.random(); }
        if (e.skin === 'beetle') { e.hp = 2; e.vx = -40; }
        if (e.skin === 'crab') e.vx = -72;
        if (e.skin === 'snake') e.vx = -58;
      } else if (e.kind === 'fly') {
        e.skin = skins.fly[e.slot % skins.fly.length];
        e.ghost = e.skin === 'ghost';
      }
    }
    let art;
    let raf = 0, alive = true, paused = false, state = 'play';
    const input = { l: false, r: false, jump: false, jumpPressed: false, fire: false };
    const P = { x: L.start.x, y: L.start.y, w: 22, h: 30, vx: 0, vy: 0, face: 1, ground: false, jumps: 0, coyote: 0, buffer: 0, inv: 0, anim: 0, cool: 0, hearts: maxHearts(), lost: 0, spawn: { ...L.start }, win: 0 };
    const stats = { beans: 0, kills: 0, time: 0 };
    const shots = [], parts = [], pops = [], trail = [];
    let trailT = 0, bossMsgT = 0;
    let cam = 0, view = { w: 800, h: WH, s: 1, dpr: 1 };
    let canvas, ctx, hud = {}, overlay;

    const heroId = myHero();
    const ctrl = look.ctrl;
    const zoomWas = document.body.style.zoom;
    document.body.style.zoom = '';
    openScreen((el) => {
      el.classList.add('g-flame');
      canvas = h('canvas', { class: 'fl-canvas' });
      const btn = (cls, label, key) => {
        const b = h('button', { type: 'button', class: `fl-btn ${cls}`, 'aria-label': label });
        b.addEventListener('pointerdown', (e) => { e.preventDefault(); b.setPointerCapture?.(e.pointerId); input[key] = true; if (key === 'jump') input.jumpPressed = true; b.classList.add('on'); });
        ['pointerup', 'pointercancel', 'lostpointercapture'].forEach((ev) => b.addEventListener(ev, () => { input[key] = false; b.classList.remove('on'); }));
        return b;
      };
      const controls = buildControls(ctrl, input, btn);
      hud.hearts = h('span', { class: 'fl-pill' });
      hud.beans = h('span', { class: 'fl-pill num' });
      hud.time = h('span', { class: 'fl-pill num' });
      overlay = h('div', { class: 'fl-over', hidden: true });
      el.append(
        h('div', { class: 'fl-stage' }, canvas,
          h('div', { class: 'fl-hud' },
            h('div', { class: 'fl-hg' }, hud.hearts, hud.beans),
            h('div', { class: 'fl-hg' }, hud.time, h('span', { class: 'fl-pill num', text: UI.n(def.id) }),
              h('button', { type: 'button', class: 'fl-pill fl-pause', 'aria-label': 'إيقاف مؤقت', onclick: () => pause(true) }, '❚❚'))),
          hud.boss = h('div', { class: 'fl-boss', hidden: true }, h('b', { text: 'حارس المدينة' }), h('span', { class: 'fl-boss-bar' }, h('i'))),
          hud.title = h('div', { class: 'fl-title', text: `${lvName(def)} · ${def.theme === 'lantern' ? (def.boss ? 'اهزم الحارس ووصل للبوابة' : 'اجمع البن ووصل لبوابة المدينة') : 'اجمع البن ووصل للقمرية'}` })),
        controls,
        overlay);
      el.dataset.orient = orient;
    }, { onBack: () => (state === 'play' && !paused ? pause(true) : exit()), cleanup: () => { alive = false; cancelAnimationFrame(raf); window.removeEventListener('resize', resize); window.removeEventListener('keydown', key); window.removeEventListener('keyup', key); document.removeEventListener('visibilitychange', vis); unlockOrientation(); document.body.style.zoom = zoomWas; }, cls: 'g-full' });
    clearTimeout(unlockTimer);
    lockOrientation(orient);

    const KEYS = { ArrowLeft: 'l', KeyA: 'l', ArrowRight: 'r', KeyD: 'r', ArrowUp: 'jump', KeyW: 'jump', Space: 'jump', KeyX: 'fire', KeyK: 'fire', KeyF: 'fire' };
    function key(e) {
      if ((e.code === 'Escape' || e.code === 'KeyP') && e.type === 'keydown') return pause(!paused);
      const k = KEYS[e.code];
      if (!k) return;
      e.preventDefault();
      const down = e.type === 'keydown';
      if (k === 'jump' && down && !input.jump) input.jumpPressed = true;
      input[k] = down;
    }
    function vis() { if (document.hidden && state === 'play') pause(true); }
    window.addEventListener('keydown', key);
    window.addEventListener('keyup', key);
    window.addEventListener('resize', resize);
    document.addEventListener('visibilitychange', vis);

    function resize() {
      if (!canvas) return;
      const stage = canvas.parentElement;
      const r = stage.getBoundingClientRect();
      const cw = r.width, ch = r.height;
      view.dpr = Math.min(2, window.devicePixelRatio || 1);
      view.s = ch / WH;
      view.w = cw / view.s;
      canvas.width = Math.round(cw * view.dpr);
      canvas.height = Math.round(ch * view.dpr);
      canvas.style.width = cw + 'px';
      canvas.style.height = ch + 'px';
      ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      GS.screen?.classList.toggle('is-land', window.innerWidth > window.innerHeight);
    }

    overlay.hidden = false;
    overlay.replaceChildren(h('div', { class: 'fl-card' }, h('span', { class: 'xo-spin' }), h('b', { text: `جارٍ تجهيز ${worldOf(def).id === 1 ? FC().world : (FC().worlds?.[worldOf(def).id]?.name || worldOf(def).name)}…` })));
    art = await loadArt(def, heroId, palKey, look, skins);
    if (!alive) return;
    overlay.hidden = true;
    requestAnimationFrame(() => { resize(); setTimeout(resize, 350); });
    setTimeout(() => hud.title?.classList.add('out'), 2600);

    /* ---------- أدوات التصادم ---------- */
    const tileAt = (tx, ty) => (tx < 0 || tx >= L.W ? '#' : ty < 0 || ty >= ROWS ? '.' : L.grid[ty][tx]);
    const solid = (c) => c === '#' || c === '=' || c === '?' || c === 'u';
    function moveX(o, dx) {
      o.x += dx;
      const y0 = Math.floor(o.y / T), y1 = Math.floor((o.y + o.h - 0.01) / T);
      if (dx > 0) { const tx = Math.floor((o.x + o.w) / T); for (let ty = y0; ty <= y1; ty++) if (solid(tileAt(tx, ty))) { o.x = tx * T - o.w - 0.01; return true; } }
      else if (dx < 0) { const tx = Math.floor(o.x / T); for (let ty = y0; ty <= y1; ty++) if (solid(tileAt(tx, ty))) { o.x = (tx + 1) * T + 0.01; return true; } }
      return false;
    }
    function moveY(o, dy) {
      o.y += dy;
      const x0 = Math.floor(o.x / T), x1 = Math.floor((o.x + o.w - 0.01) / T);
      if (dy > 0) { const ty = Math.floor((o.y + o.h) / T); for (let tx = x0; tx <= x1; tx++) if (solid(tileAt(tx, ty))) { o.y = ty * T - o.h - 0.01; return 'down'; } }
      else if (dy < 0) {
        const ty = Math.floor(o.y / T);
        let hit = null;
        for (let tx = x0; tx <= x1; tx++) if (solid(tileAt(tx, ty))) { hit = hit || { tx, ty }; if (tileAt(tx, ty) === '?') hit = { tx, ty }; }
        if (hit) { o.y = (hit.ty + 1) * T + 0.01; return hit; }
      }
      return null;
    }
    const overlap = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
    function burst(x, y, color, n = 8, spd = 160) {
      for (let i = 0; i < n; i++) { const a = Math.random() * Math.PI * 2, v = spd * (0.4 + Math.random()); parts.push({ x, y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 60, life: 0.5 + Math.random() * 0.3, t: 0, color, r: 2 + Math.random() * 2.5 }); }
    }

    /* ---------- التحديث ---------- */
    const G = 2000, RUN = 215, ACC = 1500, FRIC = 1900, JV = 670, JV2 = 590;
    function hurt(from) {
      if (P.inv > 0 || P.win) return;
      P.hearts--; P.lost++;
      P.inv = 1.5; P.vy = -330; P.vx = (from < P.x ? 1 : -1) * 220;
      beep('hurt'); buzz('warning');
      burst(P.x + P.w / 2, P.y + P.h / 2, '#FF6B6B', 10);
      if (P.hearts <= 0) gameOver();
    }
    function step(dt) {
      stats.time += dt;
      P.inv = Math.max(0, P.inv - dt);
      P.cool = Math.max(0, P.cool - dt);
      P.anim += dt;
      // المنصات المتحركة (تحمل اللاعب معها)
      for (const m of L.movers) {
        m.t += dt;
        const k = (1 - Math.cos(m.t * 1.1)) / 2;
        const nx = m.axis === 'x' ? m.x0 + k * m.range : m.x0, ny = m.axis === 'y' ? m.y0 + k * m.range : m.y0;
        m.dx = nx - m.x; m.dy = ny - m.y; m.x = nx; m.y = ny;
      }
      if (P.onM) { P.x += P.onM.dx; P.y += P.onM.dy; }
      if (P.win) { P.vx = 70; P.win += dt; if (P.win > 1.2) return winLevel(); }
      else {
        const dir = (input.r ? 1 : 0) - (input.l ? 1 : 0);
        if (dir) { P.vx += dir * ACC * dt; P.face = dir; } else { const f = FRIC * dt; P.vx = Math.abs(P.vx) <= f ? 0 : P.vx - Math.sign(P.vx) * f; }
        P.vx = Math.max(-RUN, Math.min(RUN, P.vx));
        if (input.jumpPressed) { P.buffer = 0.12; input.jumpPressed = false; }
        P.buffer = Math.max(0, P.buffer - dt);
        P.coyote = P.ground ? 0.1 : Math.max(0, P.coyote - dt);
        if (P.buffer > 0) {
          if (P.ground || P.coyote > 0) { P.vy = -JV; P.jumps = 1; P.buffer = 0; P.coyote = 0; beep('jump'); }
          else if (P.jumps < 2) { P.vy = -JV2; P.jumps = 2; P.buffer = 0; beep('jump2'); burst(P.x + P.w / 2, P.y + P.h, '#FFB43D', 6, 90); }
        }
        if (!input.jump && P.vy < -260) P.vy = -260;
        if (input.fire && P.cool <= 0 && shots.length < 3) {
          P.cool = 0.38;
          shots.push({ x: P.x + (P.face > 0 ? P.w : -12), y: P.y + 8, w: 12, h: 12, vx: P.face * 400 + P.vx * 0.3, vy: -60, life: 1.6 });
          beep('fire');
        }
      }
      P.vy = Math.min(900, P.vy + G * dt);
      moveX(P, P.vx * dt);
      P.ground = false;
      const pb = P.y + P.h;
      const hy = moveY(P, P.vy * dt);
      if (hy === 'down') { if (P.vy > 0) { P.ground = true; P.jumps = 0; } P.vy = 0; }
      else if (hy && typeof hy === 'object') {
        P.vy = 60;
        if (L.grid[hy.ty][hy.tx] === '?') {
          L.grid[hy.ty][hy.tx] = 'u';
          beep('block'); buzz('medium');
          const bx = hy.tx * T + T / 2, by = hy.ty * T;
          if (P.hearts < maxHearts()) { P.hearts++; pops.push({ x: bx, y: by, t: 0, text: '❤️' }); }
          else { stats.beans += 5; pops.push({ x: bx, y: by, t: 0, text: '+5 ☕' }); }
          burst(bx, by, '#FFD08A', 10, 120);
        }
      }
      P.onM = null;
      if (P.vy >= 0) for (const m of L.movers) {
        if (P.x + P.w > m.x + 3 && P.x < m.x + m.w - 3 && pb <= m.y + 8 + Math.abs(m.dy) && P.y + P.h >= m.y) { P.y = m.y - P.h; P.vy = 0; P.ground = true; P.jumps = 0; P.onM = m; }
      }
      // أثر الحركة
      trailT -= dt;
      if (look.trail && look.trail !== 'none' && trailT <= 0 && (Math.abs(P.vx) > 40 || !P.ground)) {
        trailT = look.trail === 'bolt' ? 0.05 : 0.035;
        trail.push({ x: P.x + P.w / 2 - P.face * 8, y: P.y + P.h * (look.trail === 'stars' ? 0.3 + Math.random() * 0.5 : 0.62), t: 0, life: look.trail === 'stars' ? 0.6 : 0.42, r: Math.random() });
      }
      for (let i = trail.length - 1; i >= 0; i--) { trail[i].t += dt; if (trail[i].t > trail[i].life) trail.splice(i, 1); }
      if (P.y > WH + 60) {
        P.hearts--; P.lost++;
        beep('hurt'); buzz('warning');
        if (P.hearts <= 0) return gameOver();
        Object.assign(P, { x: P.spawn.x, y: P.spawn.y, vx: 0, vy: 0, inv: 1.6 });
      }

      // البن
      for (const b of L.beans) {
        b.t += dt;
        if (!b.got && overlap(P, b)) { b.got = true; stats.beans++; beep('bean'); burst(b.x + 10, b.y + 12, '#C0784A', 5, 90); }
      }
      // نقاط الحفظ
      for (const c of L.checks) if (!c.on && P.x > c.x) { c.on = true; P.spawn = { x: c.x + 4, y: c.y - 8 }; beep('check'); pops.push({ x: c.x + 16, y: c.y - 20, t: 0, text: 'نقطة حفظ' }); }
      // الأعداء
      const killE = (e, color = '#8A6ACE', pts = 50) => { e.dead = 0.001; stats.kills++; burst(e.x + e.w / 2, e.y + 6, color, 10); pops.push({ x: e.x + e.w / 2, y: e.y, t: 0, text: `+${pts}` }); };
      for (const e of L.enemies) {
        if (e.dead) { e.dead += dt; continue; }
        if (Math.abs(e.x - P.x) > view.w + 200 && e.kind !== 'boss') continue;
        e.t += dt;
        if (e.stun > 0) { e.stun -= dt; if (e.stun <= 0) e.vx = e.vx || -40; }
        if (e.kind === 'walk' || e.kind === 'hop' || e.kind === 'boss') {
          e.vy = Math.min(900, e.vy + G * dt);
          if (e.kind === 'boss') {
            e.inv = Math.max(0, e.inv - dt);
            const near = Math.abs(P.x - e.x) < 280;
            if (near && !P.win) e.vx = Math.sign(P.x - e.x || 1) * (e.hp < 2 ? 120 : 95);
            if (e.x < e.x0 - 7 * T) e.vx = Math.abs(e.vx); if (e.x > e.x0 + 7 * T) e.vx = -Math.abs(e.vx);
            e.jumpT -= dt;
          }
          if (e.kind === 'hop') { e.hopT -= dt; e.vx = Math.sign(P.x - e.x || -1) * 34; }
          const moving = !(e.stun > 0);
          if (moving && moveX(e, e.vx * dt)) e.vx = -e.vx;
          if (moveY(e, e.vy * dt) === 'down') {
            e.vy = 0;
            if (e.kind === 'hop' && e.hopT <= 0) { e.vy = -520; e.hopT = 1.1 + Math.random() * 0.6; }
            else if (e.kind === 'boss' && e.jumpT <= 0) { e.vy = -640; e.jumpT = 2 + Math.random(); }
            else if (e.kind === 'walk') {
              const ahead = e.vx > 0 ? e.x + e.w + 2 : e.x - 2;
              if (!solid(tileAt(Math.floor(ahead / T), Math.floor((e.y + e.h + 4) / T)))) e.vx = -e.vx;
            }
          }
          if (e.y > WH + 60) e.dead = 1;
        } else if (e.kind === 'fly') {
          const px = e.x;
          e.x = e.x0 + Math.sin(e.t * 0.8) * 3 * T;
          const dive = !e.ghost && Math.abs(P.x - e.x) < 110 && P.y > e.y;
          const ty = dive ? Math.min(P.y - 6, e.y0 + 5 * T) : e.y0 + Math.sin(e.t * 2.4) * 12;
          e.y += (ty - e.y) * Math.min(1, dt * (dive ? 1.8 : 3));
          e.vx = e.x - px;
          e.vis = !e.ghost || Math.sin(e.t * 1.3) > -0.45;
        }
        if (!P.win && overlap(P, e) && e.vis !== false) {
          const stompable = e.kind !== 'thorn';
          const stomp = stompable && P.vy > 60 && P.y + P.h - e.y < (e.kind === 'boss' ? 26 : 16);
          if (stomp) {
            P.vy = input.jump ? -560 : -400; P.jumps = 1; beep('stomp'); buzz('light');
            if (e.kind === 'boss') {
              if (e.inv <= 0) { e.hp -= 1; e.inv = 1; burst(e.x + e.w / 2, e.y, '#FFB43D', 14); pops.push({ x: e.x + e.w / 2, y: e.y - 10, t: 0, text: e.hp > 0 ? 'ضربة!' : '' }); if (e.hp <= 0) { killE(e, '#FFB43D', 300); pops.push({ x: e.x + e.w / 2, y: e.y - 30, t: 0, text: 'هزمت الحارس! 🏆' }); buzz('success'); } }
            } else if (e.hp > 1) { e.hp--; e.stun = 1.4; e.vx = 0; pops.push({ x: e.x + e.w / 2, y: e.y, t: 0, text: 'درع!' }); burst(e.x + e.w / 2, e.y + 6, '#7CF0C8', 6); }
            else killE(e);
          } else hurt(e.x);
        }
      }
      // كرات اللهب
      for (let i = shots.length - 1; i >= 0; i--) {
        const s = shots[i];
        s.life -= dt;
        s.vy = Math.min(700, s.vy + 1300 * dt);
        const wall = moveX(s, s.vx * dt);
        if (moveY(s, s.vy * dt) === 'down') s.vy = -330;
        let gone = wall || s.life <= 0 || s.y > WH;
        for (const e of L.enemies) if (!e.dead && e.vis !== false && overlap(s, e)) {
          gone = true; beep('stomp'); burst(e.x + e.w / 2, e.y + e.h / 2, '#FFB43D', 12);
          if (e.kind === 'boss') { e.hp -= 0.34; if (e.hp <= 0.01) { e.dead = 0.001; stats.kills++; pops.push({ x: e.x + e.w / 2, y: e.y - 30, t: 0, text: 'هزمت الحارس! 🏆' }); } }
          else { e.dead = 0.001; stats.kills++; pops.push({ x: e.x + e.w / 2, y: e.y, t: 0, text: '+50' }); }
          break;
        }
        if (gone) { burst(s.x + 6, s.y + 6, '#FFB43D', 6, 80); shots.splice(i, 1); }
      }
      // جزيئات
      for (let i = parts.length - 1; i >= 0; i--) { const q = parts[i]; q.t += dt; q.vy += 500 * dt; q.x += q.vx * dt; q.y += q.vy * dt; if (q.t > q.life) parts.splice(i, 1); }
      for (let i = pops.length - 1; i >= 0; i--) { pops[i].t += dt; if (pops[i].t > 1) pops.splice(i, 1); }
      // الهدف
      bossMsgT = Math.max(0, bossMsgT - dt);
      if (!P.win && P.x + P.w / 2 > L.goal.x + T * 1.2 && P.y > L.goal.y) {
        if (L.boss && !L.boss.dead) {
          P.x = L.goal.x + T * 1.2 - P.w / 2 - 2; P.vx = -160;
          if (!bossMsgT) { bossMsgT = 2; pops.push({ x: P.x, y: P.y - 20, t: 0, text: 'اهزم الحارس أولاً!' }); }
        } else { P.win = 0.001; beep('win'); buzz('success'); input.l = input.r = false; }
      }
    }

    /* ---------- الرسم ---------- */
    function draw() {
      if (!ctx) return;
      const { s, dpr } = view;
      const vw = view.w;
      const target = P.x + P.w / 2 - vw * (vw < 500 ? 0.35 : 0.4);
      cam += (Math.max(0, Math.min(L.W * T - vw, target)) - cam) * 0.18;
      if (L.W * T < vw) cam = 0;
      ctx.setTransform(dpr * s, 0, 0, dpr * s, 0, 0);
      const p = art.p;
      // السماء
      const sky = ctx.createLinearGradient(0, 0, 0, WH);
      sky.addColorStop(0, p.sky[0]); sky.addColorStop(0.55, p.sky[1]); sky.addColorStop(1, p.sky[2]);
      ctx.fillStyle = sky; ctx.fillRect(0, 0, vw + 2, WH);
      if (p.stars) { ctx.fillStyle = 'rgba(255,255,255,.75)'; for (let i = 0; i < 40; i++) { const x = ((i * 137.5 + 20) % 1000) - (cam * 0.03) % 1000; const y = (i * 53) % 170; ctx.globalAlpha = p.stars * (0.4 + 0.6 * Math.abs(Math.sin(stats.time * 0.8 + i))); ctx.fillRect((x + 1000) % 1000 * (vw / 1000 + 0.3), y, 1.6, 1.6); } ctx.globalAlpha = 1; }
      const sunX = vw * 0.72 - cam * 0.02;
      ctx.fillStyle = p.sun; ctx.globalAlpha = 0.18; ctx.beginPath(); ctx.arc(sunX, 170, 78, 0, 7); ctx.fill();
      ctx.globalAlpha = 0.95; ctx.beginPath(); ctx.arc(sunX, 170, 44, 0, 7); ctx.fill(); ctx.globalAlpha = 1;
      if (art.key === 'night') { ctx.fillStyle = 'rgba(160,160,190,.35)'; [[-14, -8, 9], [12, 10, 7], [8, -18, 5], [-6, 20, 5]].forEach(([dx, dy, r]) => { ctx.beginPath(); ctx.arc(sunX + dx, 170 + dy, r, 0, 7); ctx.fill(); }); }
      const layer = (img, f, w) => { if (!img) return; const off = -((cam * f) % w); for (let x = off; x < vw; x += w) ctx.drawImage(img, x, 0, w, WH); };
      layer(art.far, 0.12, 960); layer(art.mid, 0.3, 1100); layer(art.near, 0.55, 1280);

      ctx.save();
      ctx.translate(-Math.round(cam * s) / s, 0);
      const x0 = Math.max(0, Math.floor(cam / T) - 1), x1 = Math.min(L.W - 1, Math.ceil((cam + vw) / T) + 1);
      // البيت الهدف
      ctx.drawImage(art.house, L.goal.x, L.goal.y, 96, 128);
      // نقاط الحفظ
      for (const c of L.checks) ctx.drawImage(c.on ? art.lOn : art.lOff, c.x + 8, c.y - 32, 32, 64);
      // البلاط
      for (let ty = 0; ty < ROWS; ty++) for (let tx = x0; tx <= x1; tx++) {
        const c = L.grid[ty][tx];
        if (c === '.') continue;
        const up = ty > 0 ? L.grid[ty - 1][tx] : '.';
        const img = c === '#' ? (solid(up) ? art.tiles.in : art.tiles.top) : c === '=' ? art.tiles.plat : c === '?' ? art.tiles.q : art.tiles.u;
        if (c === '?') { ctx.save(); ctx.shadowColor = '#FFB43D'; ctx.shadowBlur = 10 + Math.sin(stats.time * 4) * 5; ctx.drawImage(img, tx * T, ty * T, T, T); ctx.restore(); }
        else ctx.drawImage(img, tx * T, ty * T, T, T);
      }
      // المنصات المتحركة
      for (const m of L.movers) {
        if (m.x > cam + vw + 40 || m.x + m.w < cam - 40) continue;
        for (let i = 0; i < m.w / T; i++) ctx.drawImage(art.tiles.plat, m.x + i * T, m.y, T, 16);
        ctx.fillStyle = '#FFD66B'; ctx.fillRect(m.x, m.y, m.w, 2.5);
        ctx.fillStyle = 'rgba(0,0,0,.25)'; ctx.fillRect(m.x + 2, m.y + 16, m.w - 4, 3);
      }
      // البن
      for (const b of L.beans) if (!b.got && b.x > cam - 40 && b.x < cam + vw + 40) ctx.drawImage(art.bean, b.x, b.y + Math.sin(b.t * 3) * 3, 20, 24);
      // الأعداء
      for (const e of L.enemies) {
        if (e.dead > 0.35 || e.x < cam - 90 || e.x > cam + vw + 90) continue;
        ctx.save();
        if (e.dead) { ctx.globalAlpha = 1 - e.dead / 0.35; ctx.translate(e.x + e.w / 2, e.y + e.h); ctx.scale(1.2, 0.35); ctx.translate(-(e.x + e.w / 2), -(e.y + e.h)); }
        if (e.kind === 'walk' || e.kind === 'hop') {
          const img = art.mon[e.skin];
          ctx.translate(e.x + e.w / 2, e.y + e.h);
          if (e.vx > 0) ctx.scale(-1, 1);
          if (e.stun > 0) { ctx.translate(0, -12); ctx.scale(1, -1); ctx.translate(0, 12); }
          const wob = e.kind === 'hop' ? 0 : Math.sin(e.t * 12) * 1.2;
          if (img) ctx.drawImage(img, -e.w / 2 - 6, -26 + wob * 0.3, 40, 24);
        } else if (e.kind === 'fly') {
          const img = art.mon[e.skin];
          if (e.ghost) ctx.globalAlpha *= e.vis ? 0.95 : 0.16;
          ctx.translate(e.x + e.w / 2, e.y + e.h / 2);
          if (e.vx > 0) ctx.scale(-1, 1);
          const flap = e.ghost ? 1 : 1 + Math.sin(e.t * 16) * 0.08;
          ctx.scale(1, flap);
          if (img) ctx.drawImage(img, -24, -15, 48, 29);
        } else if (e.kind === 'boss') {
          const img = e.inv > 0 && Math.floor(e.inv * 10) % 2 ? art.bossHurt : art.boss;
          ctx.translate(e.x + e.w / 2, e.y + e.h);
          if (e.vx > 0) ctx.scale(-1, 1);
          const sq = Math.sin(e.t * 6) * 0.03;
          ctx.scale(1 + sq, 1 - sq);
          if (img) ctx.drawImage(img, -38, -84, 76, 86);
        } else {
          const pulse = 1 + Math.sin(stats.time * 3 + e.x) * 0.04;
          ctx.translate(e.x + e.w / 2, e.y + e.h);
          ctx.scale(pulse, pulse);
          ctx.drawImage(art.thorn, -16, -30, 32, 32);
        }
        ctx.restore();
      }
      // أثر الحركة
      for (const q of trail) {
        const a = 1 - q.t / q.life;
        ctx.globalAlpha = a;
        if (look.trail === 'flame') { const r = 3 + a * 6; const gr = ctx.createRadialGradient(q.x, q.y - q.t * 30, 0, q.x, q.y - q.t * 30, r); gr.addColorStop(0, '#FFF3C4'); gr.addColorStop(0.5, '#FFB43D'); gr.addColorStop(1, 'rgba(240,146,47,0)'); ctx.fillStyle = gr; ctx.beginPath(); ctx.arc(q.x, q.y - q.t * 30, r, 0, 7); ctx.fill(); }
        else if (look.trail === 'stars') { ctx.fillStyle = q.r > 0.5 ? '#FFD66B' : '#FFFFFF'; ctx.font = `${8 + a * 6}px sans-serif`; ctx.textAlign = 'center'; ctx.fillText('✦', q.x + (q.r - 0.5) * 10, q.y - q.t * 20); }
        else if (look.trail === 'bolt') { ctx.strokeStyle = '#7FD8FF'; ctx.lineWidth = 2; ctx.shadowColor = '#56C8FF'; ctx.shadowBlur = 8; ctx.beginPath(); ctx.moveTo(q.x, q.y - 6); ctx.lineTo(q.x - 4, q.y); ctx.lineTo(q.x + 2, q.y + 1); ctx.lineTo(q.x - 3, q.y + 8); ctx.stroke(); ctx.shadowBlur = 0; }
      }
      ctx.globalAlpha = 1;
      // كرات اللهب
      for (const sh of shots) {
        const g2 = ctx.createRadialGradient(sh.x + 6, sh.y + 6, 1, sh.x + 6, sh.y + 6, 12);
        g2.addColorStop(0, '#FFF3C4'); g2.addColorStop(0.4, '#FFB43D'); g2.addColorStop(1, 'rgba(240,146,47,0)');
        ctx.fillStyle = g2; ctx.beginPath(); ctx.arc(sh.x + 6, sh.y + 6, 12, 0, 7); ctx.fill();
      }
      // البطل
      if (!(P.inv > 0 && Math.floor(P.inv * 12) % 2)) {
        const pose = !P.ground ? 'jump' : Math.abs(P.vx) > 30 ? (Math.floor(P.anim * 10) % 2 ? 'run1' : 'run2') : 'stand';
        const img = art.hero[pose] || art.hero.stand;
        const k = heroById(heroId).limbs ? 0.52 : 0.62, dw = 80 * k, dh = 110 * k;
        const foot = (FOOT[heroId] || 100) * k;
        const cx = P.x + P.w / 2, by = P.y + P.h;
        ctx.save();
        ctx.translate(cx, by);
        if (P.face < 0) ctx.scale(-1, 1);
        const limb = heroById(heroId).limbs;
        if (!limb) {
          if (!P.ground) ctx.scale(0.94, 1.07);
          else if (Math.abs(P.vx) > 30) { ctx.rotate(0.08); ctx.scale(1, 1 + Math.sin(P.anim * 22) * 0.05); }
          else ctx.scale(1 + Math.sin(P.anim * 3) * 0.02, 1 - Math.sin(P.anim * 3) * 0.02);
        }
        const glow = ctx.createRadialGradient(0, -dh * 0.45, 2, 0, -dh * 0.45, 34);
        glow.addColorStop(0, 'rgba(255,180,61,.28)'); glow.addColorStop(1, 'rgba(255,180,61,0)');
        ctx.fillStyle = glow; ctx.beginPath(); ctx.arc(0, -dh * 0.45, 34, 0, 7); ctx.fill();
        ctx.drawImage(img, -dw / 2, -foot, dw, dh);
        ctx.restore();
      }
      // جزيئات ونصوص
      for (const q of parts) { ctx.globalAlpha = Math.max(0, 1 - q.t / q.life); ctx.fillStyle = q.color; ctx.beginPath(); ctx.arc(q.x, q.y, q.r, 0, 7); ctx.fill(); }
      ctx.globalAlpha = 1;
      ctx.font = 'bold 13px NobleUI, sans-serif'; ctx.textAlign = 'center'; ctx.direction = 'ltr';
      for (const q of pops) { ctx.globalAlpha = 1 - q.t; ctx.fillStyle = '#fff'; ctx.strokeStyle = 'rgba(0,0,0,.5)'; ctx.lineWidth = 3; const ty = q.y - 10 - q.t * 30; ctx.strokeText(UI.n(q.text), q.x, ty); ctx.fillText(UI.n(q.text), q.x, ty); }
      ctx.globalAlpha = 1;
      ctx.restore();
    }

    let lastHud = '';
    function paintHud() {
      const key2 = `${P.hearts}|${stats.beans}|${Math.floor(stats.time)}|${L.boss ? L.boss.hp.toFixed(2) + (L.boss.dead ? 'd' : '') : ''}`;
      if (key2 === lastHud) return;
      lastHud = key2;
      hud.hearts.textContent = '❤️'.repeat(Math.max(0, P.hearts)) + '🤍'.repeat(Math.max(0, maxHearts() - P.hearts));
      hud.beans.textContent = UI.n(`☕ ${stats.beans}/${L.total}`);
      if (L.boss) {
        const show = !L.boss.dead && Math.abs(L.boss.x - P.x) < 420;
        hud.boss.hidden = !show;
        if (show) $('i', hud.boss).style.width = Math.max(0, L.boss.hp / 3 * 100) + '%';
      }
      const t = Math.floor(stats.time);
      hud.time.textContent = UI.n(`⏱ ${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`);
    }

    DBG.cur = { P, L, stats, input };
    let last = performance.now(), acc = 0;
    function loop(now) {
      if (!alive) return;
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      if (!paused && state === 'play') {
        acc += dt;
        while (acc >= 1 / 120) { step(1 / 120); acc -= 1 / 120; if (state !== 'play') break; }
      }
      draw();
      paintHud();
    }
    raf = requestAnimationFrame(loop);

    /* ---------- القوائم ---------- */
    function card(...kids) { overlay.hidden = false; overlay.replaceChildren(h('div', { class: 'fl-card' }, ...kids)); UI.digitize(overlay); }
    function pause(on) {
      if (state !== 'play') return;
      paused = on;
      input.l = input.r = input.jump = input.fire = false;
      if (!on) { overlay.hidden = true; last = performance.now(); return; }
      const todSeg = h('div', { class: 'fl-tod' }, ...[...Object.entries(TODS), ['level', ['🎬', 'الأصلي']]].map(([k, [ic, l]]) =>
        h('button', { type: 'button', class: todSel === k ? 'on' : '', onclick: async (ev) => {
          if (todSel === k) return;
          todSel = k; Look.set({ tod: k });
          $$('.fl-tod button', overlay).forEach((b) => b.classList.toggle('on', b === ev.currentTarget));
          const nk = todKey(def, k);
          if (nk !== palKey) { palKey = nk; const a2 = await loadArt(def, heroId, palKey, look, skins); if (alive) art = a2; }
        } }, h('b', { text: ic }), h('small', { text: l }))));
      card(h('h2', { text: 'استراحة' }),
        h('div', { class: 'fl-tod-t' }, h('small', { text: 'وقت اللعب' })), todSeg,
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => pause(false) }, 'متابعة'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => { exit(true); start(def); } }, 'إعادة المرحلة'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => exit() }, 'خريطة المراحل'));
    }
    function exit(silent) {
      alive = false;
      if (silent) return;
      openMap();
    }
    function gameOver() {
      state = 'over';
      beep('over');
      Sync.event('level_fail', { id: def.id, beans: stats.beans, time: Math.round(stats.time) });
      /* فرصة ثانية: مرة واحدة لكل محاولة — مجانية لمشتركي Pro، أو بإعلان اختياري */
      const proRevive = typeof Pro !== 'undefined' && Pro.has('games.bonus');
      const canRevive = !P.revived && (proRevive || (typeof Ads !== 'undefined' && Ads.rewardAvailable()));
      const revive = () => { P.revived = true; P.hearts = 1; P.inv = 2.5; P.x = P.spawn.x; P.y = P.spawn.y; P.vx = P.vy = 0; state = 'play'; overlay.hidden = true; last = performance.now(); buzz('success'); Sync.event('revive', { id: def.id, pro: proRevive }); };
      card(h('div', { class: 'fl-big', text: '💔' }), h('h2', { text: 'انطفأت الشعلة!' }), h('p', { text: `جمعت ${stats.beans} حبة بن — جرّب مرة أخرى` }),
        canRevive ? h('button', { type: 'button', class: 'ad-reward', onclick: async () => { if (proRevive) return revive(); if (await Ads.reward()) revive(); } },
          h('span', { text: '❤️' }), h('div', {}, h('b', { text: 'كمّل من نفس المكان بقلب إضافي' }), h('small', { text: proRevive ? 'ميزة Pro ★' : 'شاهد إعلاناً قصيراً — اختياري' })), h('span', { class: 'go', text: proRevive ? 'كمّل' : '🎬 شاهد' })) : null,
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { exit(true); start(def); } }, 'حاول مجدداً'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => exit() }, 'الخريطة'));
    }
    async function winLevel() {
      if (state !== 'play') return;
      state = 'won';
      const ratio = stats.beans / Math.max(1, L.total);
      const stars = 1 + (ratio >= 0.8 ? 1 : 0) + (P.lost === 0 ? 1 : 0);
      const score = stats.beans * 10 + stats.kills * 50 + stars * 150 + Math.max(0, 300 - Math.floor(stats.time)) + (P.lost === 0 ? 200 : 0);
      Sync.event('level_complete', { id: def.id, stars, score, beans: stats.beans, time: Math.round(stats.time) });
      const cur = gstate();
      const prevBest = cur.flame.best?.[def.id] || 0;
      const rate = Math.max(1, Number(FC().ptsRate) || 10);
      const dl = dailyLevel(cur.flame.stars || {});
      const daily = FC().daily?.on !== false && dl && dl.id === def.id && cur.flame.daily !== todayKey();
      let base = Math.max(0, Math.round((score - prevBest) / rate));
      if (daily) { base = Math.max(20, base) * Math.max(1, Math.min(5, Number(FC().daily?.mult) || 2)); Sync.event('daily', { id: def.id }); }
      const gain = await addPoints('flame', base, { mut: (x, give) => {
        x.flame = { ...(x.flame || {}), best: { ...(x.flame?.best || {}) }, stars: { ...(x.flame?.stars || {}) }, beans: (x.flame?.beans || 0) + stats.beans };
        if (daily) x.flame.daily = todayKey();
        if (def.id === '2-3') give('guardian');
        x.flame.best[def.id] = Math.max(prevBest, score);
        x.flame.stars[def.id] = Math.max(x.flame.stars[def.id] || 0, stars);
        if (stars === 3) give('three_stars');
        if (def.id === '1-3') give('sanaa');
        if (x.flame.beans >= 100) give('beans_100');
      } });
      const idx = ALL_LEVELS.indexOf(def);
      const nx = ALL_LEVELS[idx + 1];
      const next = nx && levelOpen(nx, gstate().flame.stars || {}) ? nx : null;
      const newWorld = next && worldOf(next) !== worldOf(def);
      /* حبوب مضاعفة: تلقائياً لمشتركي Pro، أو بإعلان اختياري — للمتجر فقط، لا تؤثر على الصدارة */
      const proBeans = typeof Pro !== 'undefined' && Pro.has('games.bonus');
      const giveBeans = (n, how) => gsave((x) => { x.wallet = { ...(x.wallet || {}), gift: (x.wallet?.gift || 0) + n }; }).then(() => Sync.event('bonus_beans', { id: def.id, n, how }));
      if (proBeans && stats.beans > 0) giveBeans(stats.beans, 'pro');
      const dblBtn = !proBeans && stats.beans > 0 && typeof Ads !== 'undefined' && Ads.rewardAvailable()
        ? h('button', { type: 'button', class: 'ad-reward', onclick: async (e) => { const b = e.currentTarget; if (await Ads.reward()) { await giveBeans(stats.beans, 'ad'); b.replaceWith(h('p', { class: 'fl-gain', text: `+${stats.beans} حبة بن إضافية ☕` })); buzz('success'); } } },
          h('span', { text: '☕' }), h('div', {}, h('b', { text: `ضاعف حبوب البن (+${stats.beans})` }), h('small', { text: 'شاهد إعلاناً قصيراً — اختياري' })), h('span', { class: 'go', text: '🎬 شاهد' }))
        : null;
      card(h('div', { class: 'fl-stars' }, ...[1, 2, 3].map((i) => h('span', { class: i <= stars ? 'on' : '', text: '★', style: { animationDelay: i * 0.18 + 's' } }))),
        h('h2', { text: def.theme === 'lantern' ? 'وصلت لبوابة المدينة! 🎉' : 'وصلت للقمرية! 🎉' }),
        h('div', { class: 'fl-res' },
          h('div', {}, h('b', { class: 'num', text: `${stats.beans}/${L.total}` }), h('small', { text: 'حبة بن' })),
          h('div', {}, h('b', { class: 'num', text: stats.kills }), h('small', { text: 'وحش هُزم' })),
          h('div', {}, h('b', { class: 'num', text: score }), h('small', { text: 'النتيجة' }))),
        h('p', { class: 'fl-gain', text: gain ? `+${gain} نقطة للصدارة${daily ? ' — تحدّي اليوم ×' + (FC().daily?.mult || 2) : prevBest ? ' — رقم قياسي جديد!' : ''}` : `أفضل نتيجة لك ${prevBest}` }),
        proBeans && stats.beans > 0 ? h('p', { class: 'fl-gain', text: `★ Pro: +${stats.beans} حبة بن إضافية` }) : dblBtn,
        newWorld ? h('p', { class: 'fl-unlock', text: `🔓 فتحت عالماً جديداً: ${worldName(worldOf(next))}!` }) : null,
        next ? h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { exit(true); typeof Ads !== 'undefined' ? Ads.inter(() => start(next)) : start(next); } }, `${newWorld ? 'ادخل' : 'المرحلة التالية'}: ${lvName(next)}`)
          : h('p', { class: 'hint', text: `أنهيت كل العوالم المتاحة! عوالم جديدة ${FC().soon} 🔥` }),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => { exit(true); start(def); } }, 'إعادة المرحلة'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => exit() }, 'الخريطة'));
    }
  }

  /* يسأل عن اتجاه الشاشة أول مرة */
  function openMapFirst() {
    const g = gstate();
    if (g.orient) return openMap();
    const sheet = $('#hero-sheet') || document.body.appendChild(h('section', { class: 'sheet', id: 'hero-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }));
    const opt = (k, title, sub, ic) => h('button', { type: 'button', class: 'or-opt', onclick: async () => { await gsave((x) => { x.orient = k; }); closeSheet(sheet); setTimeout(openMap, 220); } },
      h('span', { class: `or-ic or-${k}` }, icon(ic, { size: 26 })), h('b', { text: title }), h('small', { text: sub }));
    sheet.replaceChildren(h('div', { class: 'grab' }),
      h('header', { class: 'sheet-head' }, h('h2', { text: 'كيف تحب تلعب؟' })),
      h('div', { class: 'sheet-body' }, h('p', { class: 'hint', text: 'تقدر تغيّرها لاحقاً من خريطة المراحل.' }),
        h('div', { class: 'or-grid' }, opt('landscape', 'بالعرض', 'شاشة أوسع — الأفضل', 'phone'), opt('portrait', 'بالطول', 'بيد واحدة وأزرار أكبر', 'phone'), opt('auto', 'تلقائي', 'حسب دوران الجوال', 'rotate'))));
    openSheet('#hero-sheet');
  }

  return { openMap: openMapFirst, reopen: () => openMap(), LEVELS, ALL_LEVELS, WORLDS, buildLevel, levelOpen, DBG, start };
})();
