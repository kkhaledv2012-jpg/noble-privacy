/* NOBLE — محرّر التصاميم (1.14)
 * صورة ثابتة أو متحرك (فيديو) · خلفيات NOBLE (صور وفيديو) أو صورتك · خطوط الإدارة · مخطوطات · أصوات وأناشيد تتفاعل معها الحركة
 * المميزات المدفوعة: يجربها المستخدم عادي، ولما يحفظ/يشارك تطلع له «اشترك» أو «احفظ نسخة مجانية» (الإدارة تحدد السياسة).
 */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const dsKind = (k) => (DS.list || []).filter((x) => x.kind === k && x.url);
const dsBgs = () => dsKind('bg');
const dsFontsList = () => dsKind('font');
const dsSounds = () => dsKind('sound');
const dsCallig = () => (DS.list || []).filter((x) => x.kind === 'callig' && x.image);
const DS_MOTION = { on: true, video: 'free', freeMax: 8, hq: 'pro', policy: 'try', freeCopy: true, sound: 'free', access: {} };
const dsMotion = () => ({ ...DS_MOTION, ...(dsCfg().motion || {}), access: { ...((dsCfg().motion || {}).access || {}) } });
/* الوصول لحركة: free | pro | off (الإدارة) */
const mAcc = (prefix, k) => { const map = prefix === 't:' ? MotionKit.TEXT : prefix === 'b:' ? MotionKit.BG : MotionKit.LAYER; return dsMotion().access[prefix + k] || (map[k]?.pro ? 'pro' : 'free'); };
const dsHas = (f) => typeof Pro === 'undefined' || Pro.has(f);
const dsMotionPro = () => dsHas('designs.motion');
const dsTry = () => dsMotion().policy !== 'lock';
/* التوقيع والشعار المائي */
function dsSign(hide) {
  const sg = dsCfg().sign;
  if (!sg.on) return null;
  if (hide && dsCanHideSign()) return null;
  return { ...sg, logoSrc: sg.logo === false ? '' : (sg.logoUrl || (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png')) };
}
const dsCanHideSign = () => !!dsCfg().sign.paidHide && dsHas('designs.nosign');
const dsPhotoPro = () => dsHas('designs.photo');
function dsWm(ed) {
  const wm = dsCfg().wm;
  if (!wm.on || (wm.scope !== 'all' && !ed.azkar)) return null;
  if (ed.noWm && wm.paidHide && dsHas('designs.nosign')) return null;
  return { ...wm, logoSrc: wm.logoUrl || (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png') };
}
/* أقرب بديل مجاني لكل حركة مدفوعة */
const DS_FREE_ALT = { glow: 'fade', shine: 'fade', wave: 'rise', bounce: 'words', blur: 'rise', sparkle: 'stars', sweep: 'stars', bokeh: 'stars', snow: 'stars', draw: 'pop', float: 'pop' };
const DS_DEF_ANIM = { main: 'rise', sub: 'words', name: 'fade' };

function openDesign(t, values0 = null, style0 = null, extra0 = null) {
  if (t.premium && !dsPremium() && !dsTry()) { if (typeof Pro !== 'undefined') Pro.gate('designs.premium', 'هذا القالب للمشتركين ★'); return; }
  const values = {}; (t.slots || []).forEach((s) => (values[s.k] = values0?.[s.k] ?? s.def ?? ''));
  const style = JSON.parse(JSON.stringify(style0 || {}));
  const clone = (x) => (x ? JSON.parse(JSON.stringify(x)) : x);
  const M = dsMotion();
  const ed = {
    id: extra0?.id || '', size: extra0?.size || t.size || 'post', layers: clone(extra0?.layers || []),
    photo: extra0?.photo ? { ...clone({ ...extra0.photo, url: '' }), url: extra0.photo.url } : null,
    overlay: clone(extra0?.overlay) || null, noSign: !!extra0?.noSign, noWm: !!extra0?.noWm, azkar: !!(extra0?.azkar || t.azkar || t.cat === 'azkar'),
    motion: !!(extra0?.motion ?? t.motion) && M.on, bgAnim: extra0?.bgAnim || t.bgAnim || 'stars', dur: extra0?.dur || 8, q: extra0?.q || 'light',
    sound: clone(extra0?.sound) || null,
    extras: clone(extra0?.extras || []).filter((E) => E && (E.type === 'text' || E.url)), grad: clone(extra0?.grad) || null, deco: clone(extra0?.deco) || null,
  };
  // خطوط الإدارة: نسجلها عشان تنقرأ
  DesignKit.registerFonts(dsFontsList().map((f) => ({ id: f.id, url: f.url, title: f.title, premium: f.premium })));
  let dirty = false;
  const touch = () => { dirty = true; };
  let sel = (t.slots || [])[0] ? 's:' + t.slots[0].k : '';
  let tab = 'text';
  const cfg = dsCfg();
  const sugg = cfg.texts[t.cat] || cfg.texts.general || [];
  const COLORS = ['#FFFFFF', '#111111', '#F6D68E', '#FFB43D', '#C8509C', '#56C8FF', '#1FC7A0', '#8B45F0'];
  const T = () => ({ ...t, size: ed.size });
  const slotOf = (k) => (t.slots || []).find((s) => s.k === k);
  const animOf = (k) => (style[k] || {}).anim || DS_DEF_ANIM[k] || 'fade';
  const posOf = (id) => {
    if (id.startsWith('s:')) { const s = slotOf(id.slice(2)); if (!s) return null; const st = style[s.k] || {}; return { x: st.x ?? s.x, y: st.y ?? s.y }; }
    if (id === 'p') return ed.photo ? { x: ed.photo.x ?? 0.5, y: ed.photo.y ?? 0.42 } : null;
    if (id.startsWith('e:')) { const E = exOf(id); return E ? { x: E.x ?? 0.5, y: E.y ?? 0.5 } : null; }
    const L = ed.layers[+id.slice(2)]; return L ? { x: L.x ?? 0.5, y: L.y ?? 0.3 } : null;
  };
  const exOf = (id) => ed.extras.find((E) => 'e:' + E.id === id);
  const opts = (w) => ({ width: w, style, layers: ed.layers, photo: ed.photo, overlay: ed.overlay, sign: dsSign(ed.noSign), wm: dsWm(ed), extras: ed.extras, grad: ed.grad, deco: ed.deco });

  /* ---------- الحركة: مشهد MotionKit من حالة المحرّر ---------- */
  const MS = { base: null, baseKey: '', W: 0, H: 0, tplBg: null, video: null, imgs: new Map(), eimgs: new Map(), ecv: new Map(), logo: null, wmLogo: null, player: null, audio: null, audioUrl: '' };
  /* لوحة العنصر الإضافي (شعار/صورة) — نخزنها ونعيد رسمها لو تغيّر شكلها بس */
  const exCanvas = (E) => {
    const im = MS.eimgs.get(E.url); if (!im) return null;
    const key = JSON.stringify([MS.W, E.url.length, E.url.slice(-40), { ...E, x: 0, y: 0, url: '', anim: '' }]);
    let it = MS.ecv.get(E.id);
    if (!it || it.key !== key) { it = { key, cv: DesignKit.extraCanvas(E, im, MS.W, MS.H), sig: Math.random().toString(36).slice(2) }; MS.ecv.set(E.id, it); }
    return it;
  };
  const dimsFor = (w) => { const [bw, bh] = DesignKit.SIZES[ed.size] || DesignKit.SIZES.post; const sc = w / bw; return [Math.round(bw * sc / 2) * 2, Math.round(bh * sc / 2) * 2]; };
  async function buildBase(w) {
    const [W, H] = dimsFor(w);
    const vid = ed.photo && DesignKit.isVideo(ed.photo);
    const key = JSON.stringify([W, ed.size, t.id, ed.photo && { ...ed.photo, url: (ed.photo.url || '').slice(-60) }, ed.overlay, ed.grad]);
    if (key !== MS.baseKey) {
      MS.baseKey = key; MS.W = W; MS.H = H;
      if (vid) {
        MS.tplBg = ed.photo.mode === 'frame' ? await DesignKit.render(T(), {}, { width: W, noText: true, sign: null, grad: ed.grad }) : null;
        MS.video = await DesignKit.loadVideo(ed.photo.url);
        try { MS.video?.play(); } catch { /* لا شيء */ }
        MS.base = null;
      } else {
        MS.video = null;
        MS.base = await DesignKit.render(T(), {}, { width: W, noText: true, sign: null, photo: ed.photo, overlay: ed.overlay, grad: ed.grad });
      }
    }
    const sg = dsSign(ed.noSign), wm = dsWm(ed);
    MS.logo = sg?.logoSrc ? await DesignKit.loadImg(sg.logoSrc) : null;
    MS.wmLogo = wm?.logoSrc ? await DesignKit.loadImg(wm.logoSrc) : null;
    for (const L of ed.layers) if (!MS.imgs.has(L.url)) MS.imgs.set(L.url, await DesignKit.loadImg(L.url));
    for (const E of ed.extras) if (E.url && !MS.eimgs.has(E.url)) MS.eimgs.set(E.url, await DesignKit.loadImg(E.url));
    await DesignKit.ensureFonts([...(t.slots || []).map((s) => (style[s.k] || {}).font || s.font), ...ed.extras.map((E) => E.font)]);
  }
  function scene() {
    const W = MS.W, H = MS.H, U = Math.min(W, H);
    const n = (t.slots || []).length;
    return {
      W, H, bg: MS.base, duration: ed.dur, bgAnim: ed.bgAnim, seed: 11,
      base: MS.video ? (c) => { if (MS.tplBg) c.drawImage(MS.tplBg, 0, 0, W, H); else { c.fillStyle = '#000'; c.fillRect(0, 0, W, H); } DesignKit.drawPhoto(c, W, H, ed.photo, MS.video); DesignKit.drawOverlay(c, W, H, ed.overlay); } : null,
      layers: [...ed.layers.map((L, i) => ({ ...L, id: 'L' + i, im: MS.imgs.get(L.url), anim: L.anim || 'pop', delay: 0.2 + i * 0.3, dur: L.anim === 'draw' ? 1.8 : 1.2 })),
        ...ed.extras.filter((E) => !E.hide && E.type !== 'text').map((E, i) => { const it = exCanvas(E); return it?.cv ? { id: 'E' + E.id, sig: it.sig, im: it.cv, x: E.x ?? 0.5, y: E.y ?? 0.5, w: it.cv.width / W, rot: E.rot, op: E.op, anim: E.anim || 'pop', delay: 0.7 + i * 0.35, dur: 1.2 } : null; }).filter(Boolean)],
      texts: (t.slots || []).map((s, i) => {
        const st = style[s.k] || {};
        if (st.hide) return { text: '' };
        const a = animOf(s.k);
        return { text: values[s.k] ?? s.def ?? '', x: st.x ?? s.x, y: st.y ?? s.y, size: s.size, scale: st.scale || 1, color: st.color || s.color, weight: s.weight, fam: DesignKit.family(st.font || s.font), maxW: s.maxW, lines: s.lines || 2, shadow: s.shadow, fx: st.fx, fxColor: st.fxColor, anim: a, delay: 0.5 + i * 0.85, dur: a === 'words' || a === 'bounce' ? 1.8 : 1.2 };
      }).concat(ed.extras.filter((E) => !E.hide && E.type === 'text').map((E, i) => { const x = DesignKit.extraText(E), a = E.anim || 'fade'; return { ...x, text: E.text || '', fam: DesignKit.family(x.font), anim: a, delay: 0.5 + (n + i) * 0.7, dur: a === 'words' || a === 'bounce' ? 1.8 : 1.2 }; })),
      deco: ed.deco,
      sign: dsSign(ed.noSign), logo: MS.logo, wm: dsWm(ed), wmLogo: MS.wmLogo,
      react: !!ed.sound?.react, level: MS.audio ? MS.audio.level() : 0,
    };
  }
  function stopAudio() { MS.audio?.kill(); MS.audio = null; MS.audioUrl = ''; }
  function syncAudio(autoplay) {
    const url = ed.motion && ed.sound?.url ? ed.sound.url : '';
    if (url !== MS.audioUrl) { stopAudio(); if (url) { MS.audio = MotionKit.audioRig(url, { vol: ed.sound.vol ?? 0.8 }); MS.audioUrl = url; if (autoplay) MS.audio.play(ed.sound.from || 0); } }
    else if (MS.audio) MS.audio.gain.gain.value = ed.sound.vol ?? 0.8;
  }

  const closeEd = async () => {
    MS.player?.stop(); stopAudio(); try { MS.video?.pause(); } catch { /* لا شيء */ }
    if (dirty) { try { await dsRemember(t, values, style, ed); toast('انحفظ في «تصاميمي» — ترجع له وقت ما تبي ✓', { type: 'success' }); } catch { /* لا شيء */ } }
    closeScreen(); renderDesigns();
  };
  openScreen((el) => {
    const cv = h('canvas', { class: 'ds-cv' });
    const ribbon = h('span', { class: 'ds-ribbon', text: '★ تجربة — للحفظ اشترك' });
    const stage = h('div', { class: 'ds-stage' }, cv, ribbon);
    // زر تكبير/تصغير المعاينة وهي مثبتة فوق
    const pinBtn = h('button', { type: 'button', class: 'ds-pin', 'aria-label': 'حجم المعاينة', onclick: (e) => { e.stopPropagation(); dock.classList.toggle('big'); pinBtn.textContent = dock.classList.contains('big') ? '⤡' : '⤢'; } }, '⤢');
    stage.append(pinBtn);
    const tl = h('i');
    const tlBar = h('div', { class: 'ds-tl' }, tl);
    let pend = 0;
    const paintRibbon = () => { ribbon.classList.toggle('on', dsProUsed().length > 0); };
    /* الرسم: ثابت = DesignKit مع إطار التحديد، متحرك = حلقة MotionKit */
    const draw = () => {
      const n = ++pend;
      paintRibbon();
      requestAnimationFrame(async () => {
        if (n !== pend || MS.lock) return;
        const [bw, bh] = DesignKit.SIZES[ed.size] || DesignKit.SIZES.post;
        if (ed.motion) {
          await buildBase(bw >= bh ? 720 : 540);
          if (n !== pend) return;
          tlBar.hidden = false;
          if (!MS.player) MS.player = MotionKit.play(cv, scene, { onTime: (tt, D) => { tl.style.width = `${(tt / D) * 100}%`; } });
          return;
        }
        MS.player?.stop(); MS.player = null; tlBar.hidden = true;
        await DesignKit.render(T(), values, { ...opts(bw >= bh ? 900 : 720), canvas: cv });
        if (n !== pend) return;
        const c = cv.getContext('2d'), W = cv.width, H = cv.height, U = Math.min(W, H);
        if (tab === 'bg' && ed.photo) {
          const b = DesignKit.photoBox(ed.photo, W, H);
          c.save(); c.strokeStyle = '#56C8FF'; c.lineWidth = 3; c.setLineDash([10, 7]); c.strokeRect(b.x + 2, b.y + 2, b.w - 4, b.h - 4); c.restore();
          return;
        }
        const p = posOf(sel); if (!p) return;
        let w, hh;
        if (sel.startsWith('s:')) { const s = slotOf(sel.slice(2)), st = style[s.k] || {}; if (st.hide) return; w = (s.maxW || 0.84) * W; hh = (Number(s.size) || 60) * (st.scale || 1) * (U / 1080) * 1.5 * Math.min(2, s.lines || 1); }
        else if (sel.startsWith('l:')) { const L = ed.layers[+sel.slice(2)]; const im = L && await DesignKit.loadImg(L.url); if (!im) return; w = (L.w || 0.6) * W; hh = w * im.height / im.width; }
        else if (sel.startsWith('e:')) {
          const E = exOf(sel); if (!E || E.hide) return;
          if (E.type === 'text') { w = (E.maxW || 0.84) * W; hh = (Number(E.size) || 44) * (U / 1080) * 1.6; }
          else { const im = await DesignKit.loadImg(E.url); const cv2 = im && DesignKit.extraCanvas(E, im, W, H); if (!cv2) return; w = cv2.width; hh = cv2.height; }
        }
        else return;
        c.save(); c.strokeStyle = '#FFB43D'; c.lineWidth = 3; c.setLineDash([10, 7]);
        c.strokeRect(p.x * W - w / 2, p.y * H - hh / 2, w, hh); c.restore();
      });
    };
    /* السحب: في تبويب «الخلفية» يحرّك الصورة، وغيره يحرّك النص أو المخطوطة الأقرب */
    let drag = null;
    const frac = (e) => { const r = cv.getBoundingClientRect(); return { x: (e.clientX - r.left) / r.width, y: (e.clientY - r.top) / r.height, ar: r.height / r.width }; };
    cv.addEventListener('pointerdown', (e) => {
      const f = frac(e);
      if (tab === 'bg' && ed.photo) {
        const P = ed.photo;
        drag = (P.mode || 'bg') === 'bg' ? { pan: true, f, px: P.px || 0, py: P.py || 0 } : { id: 'p', dx: (P.x ?? 0.5) - f.x, dy: (P.y ?? 0.42) - f.y };
      } else {
        const ids = [...(t.slots || []).filter((s) => !(style[s.k] || {}).hide).map((s) => 's:' + s.k), ...ed.layers.map((_, i) => 'l:' + i), ...ed.extras.filter((E) => !E.hide).map((E) => 'e:' + E.id)];
        let best = null, bd = 0.2;
        ids.forEach((id) => { const p = posOf(id); if (!p) return; const d = Math.hypot(p.x - f.x, (p.y - f.y) * f.ar); if (d < bd) { bd = d; best = id; } });
        if (best && best !== sel) { sel = best; if (best.startsWith('l:') && tab !== 'callig') setTab('callig'); else if ((best.startsWith('s:') || best.startsWith('e:')) && tab !== 'text') setTab('text'); else paintPanel(); }
        const p = posOf(sel); if (!p) return;
        drag = { id: sel, dx: p.x - f.x, dy: p.y - f.y };
      }
      cv.setPointerCapture?.(e.pointerId); e.preventDefault();
    });
    cv.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const f = frac(e);
      touch();
      if (drag.pan) { const P = ed.photo; P.px = Math.max(-1, Math.min(1, drag.px - (f.x - drag.f.x) * 2.2)); P.py = Math.max(-1, Math.min(1, drag.py - (f.y - drag.f.y) * 2.2)); return draw(); }
      const x = Math.round(Math.min(0.97, Math.max(0.03, f.x + drag.dx)) * 1000) / 1000, y = Math.round(Math.min(0.97, Math.max(0.03, f.y + drag.dy)) * 1000) / 1000;
      if (drag.id === 'p') { ed.photo.x = x; ed.photo.y = y; }
      else if (drag.id.startsWith('s:')) { const k = drag.id.slice(2); style[k] = { ...(style[k] || {}), x, y }; }
      else if (drag.id.startsWith('e:')) { const E = exOf(drag.id); if (E) { E.x = x; E.y = y; } }
      else { const L = ed.layers[+drag.id.slice(2)]; if (L) { L.x = x; L.y = y; } }
      draw();
    });
    const end = () => { drag = null; };
    cv.addEventListener('pointerup', end); cv.addEventListener('pointercancel', end);

    const panel = h('div', { class: 'ds-panel' });
    const tabsEl = h('nav', { class: 'ds-tabs' });
    const dock = h('div', { class: 'ds-dock' }, stage, tlBar, tabsEl);
    const sent = h('i', { class: 'ds-sent', 'aria-hidden': 'true' });
    const modeEl = h('div', { class: 'ds-seg ds-mode' });
    const tabsList = () => [['text', '✍️', 'النصوص'], ['bg', '🖼', 'الخلفية'], ...(cfg.callig && dsCallig().length ? [['callig', '✒️', 'مخطوطات']] : []), ...(ed.motion ? [['sound', '🎵', 'الصوت']] : []), ['size', '📐', ed.motion ? 'المقاس والمدة' : 'المقاس'], ['more', '✨', 'لمسات']];
    function setTab(k) { tab = k; RC(tabsEl, ...tabsList().map(([id, ic, l]) => h('button', { type: 'button', class: id === tab ? 'on' : '', onclick: () => setTab(id) }, h('i', { text: ic }), h('span', { text: l })))); paintPanel(); draw(); }
    function paintMode() {
      if (!M.on) return RC(modeEl);
      RC(modeEl, ...[[false, '🖼 صورة ثابتة'], [true, '🎬 متحرك — فيديو']].map(([v, l]) => h('button', { type: 'button', class: ed.motion === v ? 'on' : '', onclick: () => {
        if (ed.motion === v) return;
        if (v && !dsTry() && !dsMotionPro() && M.video === 'pro') { if (typeof Pro !== 'undefined') Pro.gate('designs.motion', 'التصاميم المتحركة للمشتركين ★'); return; }
        ed.motion = v; touch(); if (!v) { stopAudio(); MS.player?.stop(); MS.player = null; } else syncAudio(true);
        paintMode(); paintActs(); if (tab === 'sound' && !v) tab = 'text'; setTab(tab);
      } }, l, v && M.video === 'pro' ? h('span', { class: 'ds-st', text: '★' }) : null)));
    }
    const colorRow = (cur, set, reset) => h('div', { class: 'ds-colors' }, ...COLORS.map((col) => h('button', { type: 'button', class: `ds-col${String(cur || '').toLowerCase() === col.toLowerCase() ? ' on' : ''}`, style: { background: col }, 'aria-label': col, onclick: () => { set(col); touch(); paintPanel(); draw(); } })),
      reset ? h('button', { type: 'button', class: 'ds-col ds-reset', title: 'الأصلي', onclick: () => { reset(); touch(); paintPanel(); draw(); } }, '↺') : null);
    const rng = (label, val, min, max, step, on, fmt = () => '') => {
      const r = h('input', { type: 'range', min, max, step, value: val });
      const out = h('em', { class: 'num', text: fmt(Number(val)) });
      r.addEventListener('input', () => { on(Number(r.value)); out.textContent = fmt(Number(r.value)); touch(); draw(); });
      return h('label', { class: 'ds-rng' }, h('span', { text: label }), r, out);
    };
    /* مدفوع: في سياسة «جرّب» يشتغل عادي مع نجمة، وفي «مقفل» يفتح الاشتراك */
    const proOk = (allowed, feature, msg) => { if (allowed || dsTry()) return true; if (typeof Pro !== 'undefined') Pro.gate(feature, msg); return false; };
    const star = (on) => (on ? h('span', { class: 'ds-st', text: '★' }) : null);
    const animChips = (map, prefix, cur, set) => h('div', { class: 'chips ds-anims' }, ...Object.entries(map).filter(([k]) => k !== 'none' && mAcc(prefix, k) !== 'off').map(([k, v]) => {
      const pro = mAcc(prefix, k) === 'pro';
      return h('button', { type: 'button', class: `chip${cur === k ? ' on' : ''}`, onclick: () => { if (pro && !proOk(dsMotionPro(), 'designs.motion', 'هذي الحركة للمشتركين ★')) return; set(k); touch(); paintPanel(); draw(); MS.player?.restart(); } }, v.name, star(pro && !dsMotionPro()));
    }));

    /* ----- النصوص: الكتابة + الخط + اللون + الحجم + الحركة + التأثير · وعناصر إضافية (سطر، شركة، شعار، صورتك) ----- */
    const EX_KIND = { text: ['✏️', 'سطر نص'], company: ['🏢', 'اسم الشركة'], logo: ['🏷', 'شعار'], photo: ['👤', 'صورتك'] };
    const exLabel = (E) => (E.kind === 'company' ? EX_KIND.company[1] : E.type === 'text' ? (E.text || '').slice(0, 14) || EX_KIND.text[1] : EX_KIND[E.type][1]);
    const exIcon = (E) => EX_KIND[E.kind === 'company' ? 'company' : E.type][0];
    const exFile = h('input', { type: 'file', accept: 'image/*', hidden: true });
    let exWant = null;
    exFile.addEventListener('change', async () => {
      const f = exFile.files[0]; exFile.value = ''; if (!f || !exWant) return;
      const w = exWant; exWant = null;
      try {
        const logo = w.type === 'logo';
        const url = await dsShrink(f, logo ? 700 : 900, logo && !/jpe?g/i.test(f.type) ? 'image/png' : 'image/jpeg');
        if (w.E) { w.E.url = url; w.E.px = 0; w.E.py = 0; } else addExtra(logo ? { type: 'logo', url, w: 0.24, plate: 'none', y: 0.14 } : { type: 'photo', url, w: 0.34, shape: 'circle', border: 'line', bcolor: '#FFFFFF', bwid: 1.2, shadow: true, zoom: 1, y: 0.36 });
        touch(); paintPanel(); draw();
      } catch { toast('تعذّر فتح الصورة', { type: 'error' }); }
    });
    const pickImg = (type, E = null) => { exWant = { type, E }; exFile.click(); };
    function addExtra(o) {
      const E = { id: Math.random().toString(36).slice(2, 8), x: 0.5, y: 0.5, ...o };
      ed.extras.push(E); sel = 'e:' + E.id; touch(); paintPanel(); draw();
      stage.scrollIntoView?.({ block: 'nearest', behavior: 'smooth' });
      return E;
    }
    const fxChips = (cur, set) => h('div', { class: 'chips ds-fx' }, ...Object.entries(DesignKit.FX).map(([k, l]) => h('button', { type: 'button', class: `chip fx-${k}${(cur || 'none') === k ? ' on' : ''}`, onclick: () => { set(k); touch(); paintPanel(); draw(); } }, h('b', { text: 'أ' }), l)));
    const fontRow = (cur, set) => h('div', { class: 'ds-fonts' }, ...Object.entries(DesignKit.FONTS).map(([k, f]) => {
      const b = h('button', { type: 'button', class: `ds-font${cur === k ? ' on' : ''}`, onclick: async () => { if (f.premium && !proOk(dsPremium(), 'designs.premium', 'هذا الخط للمشتركين ★')) return; await DesignKit.ensureFont(k); set(k); touch(); paintPanel(); draw(); } },
        h('b', { text: 'أبجد', style: { fontFamily: f.fam } }), h('small', { text: f.name }), star(f.premium && !dsPremium()));
      if (f.url) DesignKit.ensureFont(k).then(() => { b.firstChild.style.fontFamily = f.fam; });
      return b;
    }));
    function panelText() {
      const targets = h('div', { class: 'chips ds-targets' },
        ...(t.slots || []).map((s) => h('button', { type: 'button', 'data-k': 's:' + s.k, class: `chip${sel === 's:' + s.k ? ' on' : ''}${(style[s.k] || {}).hide ? ' off' : ''}`, onclick: () => { sel = 's:' + s.k; paintPanel(); draw(); } }, s.label || s.k)),
        ...ed.extras.map((E) => h('button', { type: 'button', 'data-k': 'e:' + E.id, class: `chip ds-exchip${sel === 'e:' + E.id ? ' on' : ''}${E.hide ? ' off' : ''}`, onclick: () => { sel = 'e:' + E.id; paintPanel(); draw(); } }, exIcon(E) + ' ' + exLabel(E))));
      const fields = h('div', { class: 'ds-fields' }, ...(t.slots || []).map((s) => {
        const inp = h('input', { class: `input${sel === 's:' + s.k ? ' on' : ''}`, value: values[s.k] || '', maxlength: s.max || 80, placeholder: s.label || '' });
        inp.addEventListener('input', () => { values[s.k] = inp.value; touch(); draw(); });
        inp.addEventListener('focus', () => quiet('s:' + s.k));
        inp.dataset.k = 's:' + s.k;
        const lab = h('label', { class: 'field ds-f' }, h('span', { text: s.label || s.k }), inp);
        if (typeof Voice !== 'undefined') Voice.attach(inp, 'designs');
        return lab;
      }), ...ed.extras.filter((E) => E.type === 'text').map((E) => {
        const inp = h('input', { class: `input${sel === 'e:' + E.id ? ' on' : ''}`, value: E.text || '', maxlength: 90, placeholder: E.kind === 'company' ? 'اسم الشركة' : 'اكتب سطرك هنا' });
        inp.dataset.k = 'e:' + E.id;
        inp.addEventListener('input', () => { E.text = inp.value; touch(); draw(); });
        inp.addEventListener('focus', () => quiet('e:' + E.id));
        const lab = h('label', { class: 'field ds-f ds-f-ex' }, h('span', { text: exIcon(E) + ' ' + (E.kind === 'company' ? 'اسم الشركة' : 'سطر إضافي') }), inp);
        if (typeof Voice !== 'undefined') Voice.attach(inp, 'designs');
        return lab;
      }));
      // ➕ إضافة عنصر
      const adds = h('div', { class: 'ds-sec ds-addex' }, h('div', { class: 'ds-sec-h' }, h('b', { text: '➕ أضف للتصميم' }), h('small', { text: 'كلها اختيارية — تسحبها وتكبّرها وترتّبها' })),
        h('div', { class: 'ds-addex-row' },
          h('button', { type: 'button', onclick: () => addExtra({ type: 'text', text: '', size: 40, color: '#FFFFFF', y: 0.66 }) }, h('i', { text: '✏️' }), h('b', { text: 'سطر نص' }), h('small', { text: 'سطر ثاني، تاريخ، رقم…' })),
          h('button', { type: 'button', onclick: () => addExtra({ type: 'text', kind: 'company', text: '', size: 34, color: '#F6D68E', weight: 700, fx: 'none', y: 0.86 }) }, h('i', { text: '🏢' }), h('b', { text: 'اسم الشركة' }), h('small', { text: 'أو الجهة / العائلة' })),
          h('button', { type: 'button', onclick: () => pickImg('logo') }, h('i', { text: '🏷' }), h('b', { text: 'شعار الشركة' }), h('small', { text: 'PNG شفاف أفضل' })),
          h('button', { type: 'button', onclick: () => pickImg('photo') }, h('i', { text: '👤' }), h('b', { text: 'صورتك بإطار' }), h('small', { text: 'دائرة، قلب، قوس…' }))));
      const tools = h('div', { class: 'ds-tools' });
      const moveBtns = (E) => {
        const i = ed.extras.indexOf(E);
        return h('div', { class: 'ds-tl-a' },
          h('button', { type: 'button', class: 'btn sm', disabled: i >= ed.extras.length - 1, title: 'للأمام', onclick: () => { ed.extras.splice(i, 1); ed.extras.splice(i + 1, 0, E); touch(); paintPanel(); draw(); } }, '⬆ للأمام'),
          h('button', { type: 'button', class: 'btn sm', disabled: i <= 0, title: 'للخلف', onclick: () => { ed.extras.splice(i, 1); ed.extras.splice(i - 1, 0, E); touch(); paintPanel(); draw(); } }, '⬇ للخلف'),
          h('button', { type: 'button', class: 'btn sm', onclick: () => { const c2 = { ...JSON.parse(JSON.stringify(E)), id: Math.random().toString(36).slice(2, 8), y: Math.min(0.95, (E.y ?? 0.5) + 0.08) }; ed.extras.splice(i + 1, 0, c2); sel = 'e:' + c2.id; touch(); paintPanel(); draw(); } }, '⧉ نسخة'));
      };
      function paintExTools(E) {
        const common = [
          h('div', { class: 'ds-tl-a' },
            h('button', { type: 'button', class: 'btn sm', onclick: () => { E.x = 0.5; touch(); draw(); } }, '↔ توسيط'),
            h('button', { type: 'button', class: 'btn sm', onclick: () => { E.hide = !E.hide; touch(); paintPanel(); draw(); } }, E.hide ? '👁 أظهره' : '🙈 أخفِه'),
            h('button', { type: 'button', class: 'btn sm danger', onclick: () => { ed.extras = ed.extras.filter((x) => x !== E); MS.ecv.delete(E.id); sel = (t.slots || [])[0] ? 's:' + t.slots[0].k : ''; touch(); paintPanel(); draw(); } }, '🗑 احذفه')),
          moveBtns(E)];
        const anim = ed.motion ? h('div', { class: 'ds-sub' }, h('small', { text: '🎬 حركته' }), E.type === 'text' ? animChips(MotionKit.TEXT, 't:', E.anim || 'fade', (k) => { E.anim = k; }) : animChips(MotionKit.LAYER, 'l:', E.anim || 'pop', (k) => { E.anim = k; })) : null;
        if (E.type === 'text') {
          return RC(tools, h('small', { text: `${exIcon(E)} اسحبه على الصورة لتغيير مكانه` }),
            fontRow(E.font || 'noor', (k) => (E.font = k)),
            colorRow(E.color || '#FFFFFF', (c) => (E.color = c)),
            rng('الحجم', E.size || 40, 18, 110, 1, (v) => (E.size = v), (v) => `${UI.n(Math.round(v))}`),
            h('div', { class: 'ds-row2' }, h('span', { text: 'السماكة' }), h('div', { class: 'chips' }, ...[[400, 'عادي'], [700, 'عريض']].map(([w2, l]) => h('button', { type: 'button', class: `chip${(E.weight || 700) === w2 ? ' on' : ''}`, onclick: () => { E.weight = w2; touch(); paintPanel(); draw(); } }, l)))),
            h('div', { class: 'ds-sub' }, h('small', { text: '✨ تأثير الكتابة' }), fxChips(E.fx, (k) => (E.fx = k)), E.fx && E.fx !== 'none' && E.fx !== 'gold' ? colorRow(E.fxColor || (E.fx === 'box' ? '#000000' : '#111111'), (c) => (E.fxColor = c)) : null),
            anim, ...common);
        }
        if (E.type === 'logo') {
          return RC(tools, h('small', { text: '🏷 اسحب الشعار لأي مكان' }),
            h('div', { class: 'ds-exprev' }, h('img', { src: E.url, alt: '' }), h('button', { type: 'button', class: 'btn sm', onclick: () => pickImg('logo', E) }, '🔄 غيّر الشعار')),
            rng('الحجم', E.w || 0.24, 0.06, 0.8, 0.01, (v) => (E.w = v), (v) => `${UI.n(Math.round(v * 100))}٪`),
            rng('الشفافية', E.op ?? 1, 0.15, 1, 0.05, (v) => (E.op = v), (v) => `${UI.n(Math.round(v * 100))}٪`),
            h('div', { class: 'ds-row2' }, h('span', { text: 'خلفية الشعار' }), h('div', { class: 'chips' }, ...[['none', 'بدون'], ['round', 'مربع'], ['circle', 'دائرة']].map(([k, l]) => h('button', { type: 'button', class: `chip${(E.plate || 'none') === k ? ' on' : ''}`, onclick: () => { E.plate = k; touch(); paintPanel(); draw(); } }, l)))),
            E.plate && E.plate !== 'none' ? colorRow(E.pcolor || '#FFFFFF', (c) => (E.pcolor = c)) : null,
            h('div', { class: 'ds-sub' }, h('small', { text: '🎨 لوّن الشعار (للشعارات الشفافة)' }), colorRow(E.tint || '', (c) => (E.tint = c), () => delete E.tint)),
            anim, ...common);
        }
        // صورة شخصية بإطار
        return RC(tools, h('small', { text: '👤 اسحب الصورة لأي مكان' }),
          h('div', { class: 'ds-exprev' }, h('img', { src: E.url, alt: '' }), h('button', { type: 'button', class: 'btn sm', onclick: () => pickImg('photo', E) }, '🔄 غيّر الصورة')),
          h('div', { class: 'ds-shapes' }, ...Object.entries(DesignKit.SHAPES).map(([k, [l]]) => h('button', { type: 'button', class: `ds-shape sh-${k}${(E.shape || 'circle') === k ? ' on' : ''}`, onclick: () => { E.shape = k; touch(); paintPanel(); draw(); } }, h('i'), h('span', { text: l })))),
          rng('الحجم', E.w || 0.34, 0.1, 0.9, 0.01, (v) => (E.w = v), (v) => `${UI.n(Math.round(v * 100))}٪`),
          rng('التكبير', E.zoom || 1, 1, 3, 0.02, (v) => (E.zoom = v), (v) => `${v.toFixed(1)}×`),
          rng('يمين/يسار', E.px || 0, -1, 1, 0.02, (v) => (E.px = v), (v) => `${Math.round(v * 100)}`),
          rng('فوق/تحت', E.py || 0, -1, 1, 0.02, (v) => (E.py = v), (v) => `${Math.round(v * 100)}`),
          h('div', { class: 'ds-sub' }, h('small', { text: '🖼 الإطار' }),
            h('div', { class: 'chips' }, ...Object.entries(DesignKit.BORDERS).map(([k, l]) => h('button', { type: 'button', class: `chip${(E.border || 'none') === k ? ' on' : ''}`, onclick: () => { E.border = k; if (k !== 'none' && !E.bwid) E.bwid = 1.2; touch(); paintPanel(); draw(); } }, l))),
            E.border && E.border !== 'none' && E.border !== 'gold' ? colorRow(E.bcolor || '#FFFFFF', (c) => (E.bcolor = c)) : null,
            E.border && E.border !== 'none' ? rng('سماكة الإطار', E.bwid || 1.2, 0.3, 4, 0.1, (v) => (E.bwid = v), (v) => v.toFixed(1)) : null),
          h('label', { class: 'ds-sign' }, (() => { const c = h('input', { type: 'checkbox', checked: E.shadow !== false }); c.addEventListener('change', () => { E.shadow = c.checked; touch(); draw(); }); return c; })(), h('span', { text: 'ظل خلف الصورة' })),
          h('label', { class: 'ds-sign' }, (() => { const c = h('input', { type: 'checkbox', checked: !!E.bw }); c.addEventListener('change', () => { E.bw = c.checked; touch(); draw(); }); return c; })(), h('span', { text: 'أبيض وأسود' })),
          anim, ...common);
      }
      function paintTextTools() {
        if (sel.startsWith('e:')) { const E = exOf(sel); if (E) { paintExTools(E); UI.digitize(tools); return; } }
        const s = slotOf(sel.slice(2)); if (!s) return RC(tools);
        const st = style[s.k] = style[s.k] || {};
        RC(tools,
          h('small', { text: `«${s.label || s.k}» — اسحبه على الصورة لتغيير مكانه` }),
          fontRow(st.font || s.font || 'noor', (k) => (st.font = k)),
          colorRow(st.color || s.color || '#fff', (c) => (st.color = c), () => delete st.color),
          rng('الحجم', st.scale || 1, 0.5, 1.8, 0.05, (v) => (st.scale = v), (v) => `${UI.n(Math.round(v * 100))}٪`),
          h('div', { class: 'ds-sub' }, h('small', { text: '✨ تأثير الكتابة' }), fxChips(st.fx, (k) => (st.fx = k)), st.fx && st.fx !== 'none' && st.fx !== 'gold' ? colorRow(st.fxColor || (st.fx === 'box' ? '#000000' : '#111111'), (c) => (st.fxColor = c)) : null),
          ed.motion ? h('div', { class: 'ds-sub' }, h('small', { text: '🎬 حركة هذا النص' }), animChips(MotionKit.TEXT, 't:', animOf(s.k), (k) => { st.anim = k; })) : null,
          h('div', { class: 'ds-tl-a' },
            h('button', { type: 'button', class: 'btn sm', onclick: () => { delete st.x; delete st.y; touch(); draw(); } }, '↺ المكان'),
            h('button', { type: 'button', class: 'btn sm', onclick: () => { st.hide = !st.hide; touch(); paintPanel(); draw(); } }, st.hide ? '👁 أظهره' : '🙈 أخفِه')));
        UI.digitize(tools);
      }
      // تحديد بدون إعادة رسم اللوحة (عشان الكيبورد ما يقفل)
      function quiet(id) { if (sel === id) return; sel = id; [targets, fields].forEach((box) => box.querySelectorAll('[data-k]').forEach((x) => x.classList.toggle('on', x.dataset.k === id))); paintTextTools(); draw(); }
      paintTextTools();
      const sg = sugg.length ? h('div', { class: 'ds-sugg' }, h('small', { text: '💡 نصوص مقترحة — اضغط لتستخدمها' }),
        h('div', { class: 'chips ds-wrap' }, ...sugg.map((x) => h('button', { type: 'button', class: 'chip', onclick: () => { const k = slotOf('main') ? 'main' : (t.slots || [])[0]?.k; if (!k) return; values[k] = x; touch(); paintPanel(); draw(); } }, x)))) : null;
      return [exFile, targets, fields, tools, adds, sg];
    }

    /* ----- الخلفية: خلفيات NOBLE (صور وفيديو) · صورتك · أدوات الصورة · حركة الخلفية ----- */
    function panelBg() {
      const file = h('input', { type: 'file', accept: 'image/*', hidden: true });
      const newPhoto = (url, extra = {}) => ({ url, mode: 'bg', shape: 'arch', x: 0.5, y: 0.42, w: 0.62, zoom: 1, px: 0, py: 0, rot: 0, flip: false, f: {}, preset: 'none', vig: 0, dim: 0.2, border: { color: '#FFFFFF', w: 0 }, shadow: true, ...extra });
      file.addEventListener('change', async () => {
        const f = file.files[0]; if (!f) return;
        try { const url = await dsShrink(f, 1920); ed.photo = ed.photo && !ed.photo.lib ? { ...ed.photo, url, px: 0, py: 0, zoom: 1, rot: 0 } : newPhoto(url); touch(); paintPanel(); draw(); }
        catch { toast('تعذّر فتح الصورة', { type: 'error' }); }
      });
      const lib = dsBgs();
      const libList = [...lib.filter((x) => x.cat === t.cat), ...lib.filter((x) => x.cat !== t.cat && (!x.cat || x.cat === 'all')), ...lib.filter((x) => x.cat && x.cat !== 'all' && x.cat !== t.cat)];
      const pickLib = (it) => {
        if (it.premium && !proOk(dsPremium(), 'designs.premium', 'هذي الخلفية للمشتركين ★')) return;
        ed.photo = newPhoto(it.url, { lib: it.id, video: !!it.video, premium: !!it.premium, dim: it.dim ?? 0.15 });
        if (it.anim && ed.motion) ed.bgAnim = it.anim;
        // صوت الخلفية الافتراضي (لو المستخدم ما اختار صوت بنفسه)
        if (it.sound && !ed.sound?.picked) { const snd = dsSounds().find((x) => String(x.id) === String(it.sound)); if (snd) { ed.sound = { id: snd.id, url: snd.url, title: snd.title, vol: snd.vol ?? 0.8, react: true, premium: !!snd.premium }; syncAudio(ed.motion); } }
        touch(); paintPanel(); draw();
      };
      const libGrid = libList.length ? h('div', { class: 'ds-sec ds-lib' }, h('div', { class: 'ds-sec-h' }, h('b', { text: '✨ خلفيات NOBLE' }), h('small', { text: `${UI.n(libList.length)} خلفية` })),
        h('div', { class: 'ds-lib-row' },
          h('button', { type: 'button', class: `ds-lib-it ds-lib-tpl${!ed.photo && !ed.grad ? ' on' : ''}`, onclick: () => { ed.photo = null; ed.grad = null; touch(); paintPanel(); draw(); } }, h('span', { text: '↺' }), h('small', { text: 'خلفية القالب' })),
          ...libList.map((it) => h('button', { type: 'button', class: `ds-lib-it${ed.photo?.lib === it.id ? ' on' : ''}`, onclick: () => pickLib(it) },
            it.video ? h('video', { src: it.url, muted: '', loop: '', playsinline: '', preload: 'metadata', autoplay: '' }) : h('img', { src: it.url, alt: '', loading: 'lazy' }),
            it.video ? h('i', { class: 'ds-vid', text: '🎬' }) : null, it.sound ? h('i', { class: 'ds-snd', text: '🎵' }) : null, star(it.premium && !dsPremium()))))) : null;
      const P = ed.photo;
      // 🎨 تدرّجات لونية — بدون صورة
      const gradSec = h('div', { class: 'ds-sec ds-grads' }, h('div', { class: 'ds-sec-h' }, h('b', { text: '🎨 تدرّجات لونية' }), h('small', { text: P && (P.mode || 'bg') === 'bg' ? 'تظهر لو شلت الصورة' : 'خلفية سادة أنيقة بضغطة' })),
        h('div', { class: 'ds-grad-row' }, ...DesignKit.GRADS.map(([k, l, cols, ang]) => h('button', { type: 'button', class: `ds-grad${ed.grad?.id === k ? ' on' : ''}`, onclick: () => { ed.grad = ed.grad?.id === k ? null : { id: k }; if (ed.grad && P && (P.mode || 'bg') === 'bg') ed.photo = null; touch(); paintPanel(); draw(); } },
          h('i', { style: { background: `linear-gradient(${ang}deg, ${cols.join(', ')})` } }), h('small', { text: l })))),
        ed.grad ? rng('اتجاه التدرّج', ed.grad.a ?? (DesignKit.GRADS.find((x) => x[0] === ed.grad.id) || [])[3] ?? 160, 0, 360, 5, (v) => { ed.grad.a = v; }, (v) => `${UI.n(Math.round(v))}°`) : null);
      const motionBg = ed.motion ? h('details', { class: 'ds-sec', open: true }, h('summary', { text: '🌌 حركة الخلفية' }), animChips(MotionKit.BG, 'b:', ed.bgAnim, (k) => { ed.bgAnim = k; })) : null;
      if (!P) return [file, libGrid, gradSec, h('button', { type: 'button', class: 'ds-addphoto', onclick: () => file.click() }, h('b', { text: '📷 حط صورتك خلفية' }), h('small', { text: 'خلفية كاملة أو داخل إطار (قوس، دائرة…) — الصورة تبقى على جهازك' })), motionBg];
      P.f = P.f || {};
      const isVid = DesignKit.isVideo(P);
      const mode = h('div', { class: 'ds-seg' }, ...[['bg', '🖼 خلفية كاملة'], ['frame', '🕌 داخل إطار']].map(([k, l]) => h('button', { type: 'button', class: (P.mode || 'bg') === k ? 'on' : '', onclick: () => {
        if (k === 'frame' && !proOk(dsPhotoPro(), 'designs.photo', 'الإطارات والأدوات الاحترافية للمشتركين ★')) return;
        P.mode = k; touch(); paintPanel(); draw();
      } }, l, k === 'frame' ? star(!dsPhotoPro()) : null)));
      const shapes = (P.mode || 'bg') === 'frame' ? h('div', { class: 'ds-shapes' }, ...Object.entries(DesignKit.SHAPES).map(([k, [l]]) => h('button', { type: 'button', class: `ds-shape sh-${k}${(P.shape || 'arch') === k ? ' on' : ''}`, onclick: () => { P.shape = k; touch(); paintPanel(); draw(); } }, h('i'), h('span', { text: l })))) : null;
      const presets = h('div', { class: 'ds-presets' }, ...DesignKit.PRESETS.map(([k, l, f]) => h('button', { type: 'button', class: `ds-pre${(P.preset || 'none') === k ? ' on' : ''}`, onclick: () => {
        if (k !== 'none' && !proOk(dsPhotoPro(), 'designs.photo', 'الفلاتر الاحترافية للمشتركين ★')) return;
        P.preset = k; P.f = { ...f }; touch(); paintPanel(); draw();
      } }, h('i', { class: `pv-${k}`, style: isVid ? {} : { backgroundImage: `url(${P.url})`, backgroundSize: 'cover', backgroundPosition: 'center' } }), h('span', { text: l }), k !== 'none' ? star(!dsPhotoPro()) : null)));
      const adjRaw = h('div', { class: 'ds-adj' },
        rng('السطوع', P.f.b ?? 1, 0.4, 1.6, 0.02, (v) => (P.f.b = v), (v) => `${Math.round((v - 1) * 100)}`),
        rng('التباين', P.f.c ?? 1, 0.5, 1.6, 0.02, (v) => (P.f.c = v), (v) => `${Math.round((v - 1) * 100)}`),
        rng('التشبّع', P.f.s ?? 1, 0, 2, 0.02, (v) => (P.f.s = v), (v) => `${Math.round((v - 1) * 100)}`),
        rng('الدفء', P.f.warm ?? 0, -1, 1, 0.05, (v) => (P.f.warm = v), (v) => `${Math.round(v * 100)}`),
        rng('ضبابية', P.f.blur ?? 0, 0, 2, 0.05, (v) => (P.f.blur = v), (v) => `${Math.round(v * 50)}`),
        rng('إطار معتم', P.vig ?? 0, 0, 0.9, 0.05, (v) => (P.vig = v), (v) => `${Math.round(v * 100)}`));
      const adj = dsPhotoPro() || dsTry() ? adjRaw : h('div', { class: 'ds-locked', onclick: () => typeof Pro !== 'undefined' && Pro.gate('designs.photo', 'التعديلات الاحترافية للمشتركين ★') }, adjRaw, h('span', { class: 'ds-lock', text: '★ للمشتركين' }));
      const pos = h('div', { class: 'ds-adj' },
        rng('التكبير', P.zoom || 1, 1, 3, 0.02, (v) => (P.zoom = v), (v) => `${v.toFixed(1)}×`),
        (P.mode || 'bg') === 'frame' ? rng('حجم الإطار', P.w || 0.62, 0.2, 1, 0.01, (v) => (P.w = v), (v) => `${Math.round(v * 100)}٪`) : rng('تعتيم الخلفية', P.dim ?? 0.2, 0, 0.8, 0.05, (v) => (P.dim = v), (v) => `${Math.round(v * 100)}٪`),
        h('div', { class: 'ds-tl-a' },
          h('button', { type: 'button', class: 'btn sm', onclick: () => { P.rot = ((P.rot || 0) + 90) % 360; touch(); draw(); } }, '⟳ تدوير'),
          h('button', { type: 'button', class: 'btn sm', onclick: () => { P.flip = !P.flip; touch(); draw(); } }, '⇋ قلب'),
          h('button', { type: 'button', class: 'btn sm', onclick: () => { Object.assign(P, { px: 0, py: 0, zoom: 1, rot: 0, flip: false, x: 0.5, y: 0.42 }); touch(); paintPanel(); draw(); } }, '↺ التموضع')));
      const frameStyle = (P.mode || 'bg') === 'frame' ? h('div', { class: 'ds-adj' },
        h('small', { text: 'حدّ الإطار' }), colorRow(P.border?.color, (c) => { P.border = { ...(P.border || {}), color: c, w: P.border?.w || 1.2 }; }),
        rng('سماكة الحدّ', P.border?.w || 0, 0, 4, 0.1, (v) => { P.border = { ...(P.border || { color: '#FFFFFF' }), w: v }; }, (v) => v.toFixed(1)),
        h('label', { class: 'ds-sign' }, (() => { const c = h('input', { type: 'checkbox', checked: P.shadow !== false }); c.addEventListener('change', () => { P.shadow = c.checked; touch(); draw(); }); return c; })(), h('span', { text: 'ظل خلف الإطار' }))) : null;
      return [file, libGrid, (P.mode || 'bg') === 'frame' ? gradSec : null,
        h('p', { class: 'ds-hint', text: (P.mode || 'bg') === 'bg' ? '👆 اسحب على الصورة لتحريكها داخل التصميم' : '👆 اسحب الإطار لأي مكان' }),
        mode, shapes,
        motionBg,
        h('details', { class: 'ds-sec', open: true }, h('summary', { text: '📐 التموضع والتكبير' }), pos),
        h('details', { class: 'ds-sec' }, h('summary', { text: '🎞 فلاتر جاهزة' }), presets),
        h('details', { class: 'ds-sec' }, h('summary', { text: '🎚 تعديلات احترافية' }), adj),
        frameStyle ? h('details', { class: 'ds-sec' }, h('summary', { text: '🖌 شكل الإطار' }), frameStyle) : null,
        h('div', { class: 'ds-soon' }, h('b', { text: '✂️ إزالة الخلفية' }), h('small', { text: 'ميزة قادمة — المس الشخص أو العنصر وتنقص خلفيته' }), h('span', { class: 'ds-badge2', text: 'قريباً' })),
        h('div', { class: 'ds-tl-a' },
          h('button', { type: 'button', class: 'btn sm', onclick: () => file.click() }, '📷 صورة من جهازي'),
          h('button', { type: 'button', class: 'btn sm danger', onclick: () => { ed.photo = null; ed.grad = null; touch(); paintPanel(); draw(); } }, '↺ خلفية القالب'))];
    }

    /* ----- المخطوطات ----- */
    function panelCallig() {
      const all = dsCallig();
      const list = [...all.filter((x) => x.cat === t.cat), ...all.filter((x) => x.cat !== t.cat)];
      const add = (it) => {
        if (it.premium && !proOk(dsPremium(), 'designs.premium', 'هذي المخطوطة للمشتركين ★')) return;
        ed.layers.push({ id: it.id, url: it.image, x: 0.5, y: ed.layers.length ? 0.55 : 0.3, w: Number(it.w) || 0.6, tintable: it.tint !== false, premium: !!it.premium, anim: 'draw', ...(it.color ? { tint: it.color } : {}) });
        sel = 'l:' + (ed.layers.length - 1); touch(); paintPanel(); draw();
        stage.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
      };
      const strip = h('div', { class: 'ds-cal-row' }, ...list.map((it) => h('button', { type: 'button', class: 'ds-cal-it', title: it.title || '', onclick: () => add(it) },
        h('img', { src: it.image, alt: it.title || '', loading: 'lazy', crossorigin: 'anonymous' }), it.premium && !dsPremium() ? h('span', { class: 'ds-pro', text: '★' }) : null)));
      const chips = ed.layers.length ? h('div', { class: 'chips ds-targets' }, ...ed.layers.map((_, i) => h('button', { type: 'button', class: `chip${sel === 'l:' + i ? ' on' : ''}`, onclick: () => { sel = 'l:' + i; paintPanel(); draw(); } }, `✒️ ${UI.n(i + 1)}`))) : null;
      let tools = null;
      if (sel.startsWith('l:') && ed.layers[+sel.slice(2)]) {
        const i = +sel.slice(2), L = ed.layers[i];
        tools = h('div', { class: 'ds-tools' }, h('small', { text: 'اسحب المخطوطة على الصورة لتغيير مكانها' }),
          rng('الحجم', L.w || 0.6, 0.15, 1.2, 0.01, (v) => (L.w = v), (v) => `${Math.round(v * 100)}٪`),
          rng('تدوير', L.rot || 0, -180, 180, 1, (v) => (L.rot = v), (v) => `${UI.n(Math.round(v))}°`),
          rng('الشفافية', L.op ?? 1, 0.1, 1, 0.05, (v) => (L.op = v), (v) => `${UI.n(Math.round(v * 100))}٪`),
          L.tintable ? colorRow(L.tint, (c) => (L.tint = c), () => delete L.tint) : null,
          ed.motion ? h('div', { class: 'ds-sub' }, h('small', { text: '🎬 حركتها' }), animChips(MotionKit.LAYER, 'l:', L.anim || 'pop', (k) => { L.anim = k; })) : null,
          h('div', { class: 'ds-tl-a' }, h('button', { type: 'button', class: 'btn sm', onclick: () => { L.x = 0.5; L.y = 0.3; L.w = 0.6; L.rot = 0; L.op = 1; L.flip = false; touch(); paintPanel(); draw(); } }, '↺ المكان'),
            h('button', { type: 'button', class: 'btn sm', onclick: () => { L.flip = !L.flip; touch(); draw(); } }, '⇋ قلب'),
            h('button', { type: 'button', class: 'btn sm', onclick: () => { const c2 = { ...L, x: Math.min(0.95, (L.x ?? 0.5) + 0.06), y: Math.min(0.95, (L.y ?? 0.3) + 0.06) }; ed.layers.push(c2); sel = 'l:' + (ed.layers.length - 1); touch(); paintPanel(); draw(); } }, '⧉ نسخة'),
            h('button', { type: 'button', class: 'btn sm danger', onclick: () => { ed.layers.splice(i, 1); sel = (t.slots || [])[0] ? 's:' + t.slots[0].k : ''; touch(); paintPanel(); draw(); } }, '🗑 احذفها')));
      }
      return [h('small', { class: 'ds-cap2', text: 'اضغط مخطوطة لإضافتها — تقدر تضيف أكثر من وحدة' }), strip, chips, tools];
    }

    /* ----- الصوت: أصوات طبيعية وأناشيد من الإدارة + التفاعل مع الحركة ----- */
    function panelSound() {
      const list = dsSounds();
      const proSound = M.sound === 'pro' && !dsMotionPro();
      const TYPES = { nature: '🌿 أصوات طبيعية', nasheed: '🎶 أناشيد', ambient: '✨ أجواء', effect: '🔔 مؤثرات' };
      const pick = (it) => {
        if ((it.premium && !proOk(dsPremium(), 'designs.premium', 'هذا الصوت للمشتركين ★')) || (M.sound === 'pro' && !proOk(dsMotionPro(), 'designs.motion', 'الصوت في الفيديو للمشتركين ★'))) return;
        ed.sound = { id: it.id, url: it.url, title: it.title, vol: it.vol ?? 0.8, react: ed.sound?.react ?? true, premium: !!it.premium, picked: true, dur: Number(it.dur) || 0, from: 0, fade: ed.sound?.fade ?? true };
        touch(); syncAudio(true); paintPanel(); paintRibbon();
      };
      const groups = Object.entries(TYPES).map(([k, l]) => [l, list.filter((x) => (x.type || 'nature') === k)]).filter(([, a]) => a.length);
      if (!list.length) return [h('div', { class: 'empty' }, h('b', { text: '🎵 الأصوات جاية قريب' }), h('small', { text: 'الإدارة تضيف أصوات طبيعية وأناشيد — ترجع لها هنا.' }))];
      return [
        h('button', { type: 'button', class: `ds-snd-it${!ed.sound ? ' on' : ''}`, onclick: () => { ed.sound = { picked: true }; ed.sound = null; touch(); stopAudio(); paintPanel(); paintRibbon(); } }, h('span', { text: '🔇' }), h('b', { text: 'بدون صوت' })),
        ...groups.map(([l, arr]) => h('div', { class: 'ds-sec ds-snds' }, h('div', { class: 'ds-sec-h' }, h('b', { text: l })),
          ...arr.map((it) => h('button', { type: 'button', class: `ds-snd-it${String(ed.sound?.id) === String(it.id) ? ' on' : ''}`, onclick: () => pick(it) },
            h('span', { text: String(ed.sound?.id) === String(it.id) ? '🔊' : '▶' }), h('b', { text: it.title || 'صوت' }), it.dur ? h('small', { class: 'num', text: `${Math.floor(it.dur / 60)}:${String(it.dur % 60).padStart(2, '0')}` }) : null, star((it.premium && !dsPremium()) || proSound))))),
        ed.sound?.url ? h('div', { class: 'ds-tools' },
          rng('مستوى الصوت', ed.sound.vol ?? 0.8, 0.05, 1, 0.05, (v) => { ed.sound.vol = v; syncAudio(); }, (v) => `${UI.n(Math.round(v * 100))}٪`),
          (() => {
            // ⏱ من وين يبدأ الصوت
            const total = Number(ed.sound.dur) || (MS.audio?.el?.duration > 0 ? MS.audio.el.duration : 0) || 180;
            const mmss = (x) => `${Math.floor(x / 60)}:${String(Math.floor(x % 60)).padStart(2, '0')}`;
            const box = h('div', { class: 'ds-sndstart' });
            const r = h('input', { type: 'range', min: 0, max: Math.max(1, Math.floor(total - 2)), step: 0.5, value: ed.sound.from || 0, 'data-keep': '1' });
            const out = h('em', { class: 'num ltr', text: mmss(ed.sound.from || 0) });
            const bar = h('i', { class: 'ds-sndwin' });
            const paintWin = () => { const f = (ed.sound.from || 0) / total, w = Math.min(1 - f, ed.dur / total); bar.style.insetInlineStart = `${f * 100}%`; bar.style.width = `${Math.max(2, w * 100)}%`; };
            r.addEventListener('input', () => { ed.sound.from = Number(r.value); out.textContent = mmss(ed.sound.from); paintWin(); touch(); });
            r.addEventListener('change', () => { MS.audio?.play(ed.sound.from || 0); MS.player?.restart(); });
            if (!ed.sound.dur && MS.audio?.el) MS.audio.el.addEventListener('loadedmetadata', () => { if (MS.audio.el.duration > 0 && !ed.sound.dur) { ed.sound.dur = Math.round(MS.audio.el.duration); paintPanel(); } }, { once: true });
            paintWin();
            return RC(box, h('div', { class: 'ds-sndstart-h' }, h('span', { text: '⏱ بداية الصوت' }), out, h('small', { class: 'num', text: `/ ${mmss(total)}` })),
              h('div', { class: 'ds-sndtrack' }, bar, r),
              h('small', { class: 'ds-cap2', text: `المظلّل = الجزء اللي يدخل في الفيديو (${UI.n(ed.dur)} ث) — اسحب لتختار أحلى مقطع` })), box;
          })(),
          h('label', { class: 'ds-sign' }, (() => { const c = h('input', { type: 'checkbox', checked: ed.sound.fade !== false }); c.addEventListener('change', () => { ed.sound.fade = c.checked; touch(); }); return c; })(), h('span', { text: '🌊 دخول وخروج ناعم للصوت (Fade)' })),
          h('label', { class: 'ds-sign' }, (() => { const c = h('input', { type: 'checkbox', checked: !!ed.sound.react }); c.addEventListener('change', () => { ed.sound.react = c.checked; touch(); }); return c; })(), h('span', { text: '💫 الحركة تتفاعل مع الصوت (تنبض مع الإيقاع)' })),
          h('div', { class: 'ds-tl-a' }, h('button', { type: 'button', class: 'btn sm', onclick: () => { MS.audio?.play(ed.sound.from || 0); MS.player?.restart(); } }, '▶ من نقطة البداية'), h('button', { type: 'button', class: 'btn sm', onclick: () => MS.audio?.stop() }, '⏸ إيقاف'))) : null];
    }

    /* ----- المقاس (+ المدة والجودة في المتحرك) ----- */
    function panelSize() {
      return [
        ed.motion ? h('div', { class: 'ds-sec ds-vidset' },
          h('div', { class: 'ds-sec-h' }, h('b', { text: '🎬 الفيديو' })),
          h('div', { class: 'ds-row2' }, h('span', { text: 'المدة' }), h('div', { class: 'chips' }, ...[5, 8, 12, 15, 20, 30].map((d) => h('button', { type: 'button', class: `chip${ed.dur === d ? ' on' : ''}`, onclick: () => { if (d > M.freeMax && !proOk(dsMotionPro(), 'designs.motion', 'المدة الأطول للمشتركين ★')) return; ed.dur = d; touch(); paintPanel(); draw(); MS.player?.restart(); } }, `${UI.n(d)} ث`, star(d > M.freeMax && !dsMotionPro()))))),
          h('div', { class: 'ds-row2' }, h('span', { text: 'الجودة' }), h('div', { class: 'chips' }, ...[['light', 'خفيف 720p'], ['hq', 'عالي 1080p']].map(([k, l]) => h('button', { type: 'button', class: `chip${ed.q === k ? ' on' : ''}`, onclick: () => { if (k === 'hq' && M.hq === 'pro' && !proOk(dsMotionPro(), 'designs.motion', 'الجودة العالية للمشتركين ★')) return; ed.q = k; touch(); paintPanel(); paintRibbon(); } }, l, star(k === 'hq' && M.hq === 'pro' && !dsMotionPro()))))),
          h('small', { class: 'ds-cap2', text: 'الخفيف مناسب للواتساب والحالات — حجم صغير وجودة ممتازة على الجوال.' })) : null,
        h('small', { class: 'ds-cap2', text: 'اختر المقاس حسب المنصة — النصوص والمخطوطات تتكيّف تلقائياً' }),
        h('div', { class: 'ds-sizes' }, ...Object.entries(DesignKit.SIZES).filter(([k]) => !ed.motion || k !== 'a5').map(([k, [w, hh, l, sub]]) => h('button', { type: 'button', class: `ds-sz${ed.size === k ? ' on' : ''}`, onclick: () => { ed.size = k; touch(); paintPanel(); draw(); } },
          h('i', { style: { aspectRatio: `${w}/${hh}` } }), h('b', { text: l }), h('small', { text: sub || '' }), h('em', { class: 'num ltr', text: `${w}×${hh}` }))))];
    }

    /* ----- لمسات: طبقة لون + التوقيع + الشعار المائي ----- */
    function panelMore() {
      const O = ed.overlay || { color: '#000000', op: 0, dir: 'bottom' };
      const setO = (k, v) => { ed.overlay = { ...O, ...(ed.overlay || {}), [k]: v }; };
      const sg = dsCfg().sign, wm = dsCfg().wm;
      const overlay = h('div', { class: 'ds-adj' },
        h('div', { class: 'ds-seg' }, ...[['bottom', 'من تحت'], ['top', 'من فوق'], ['full', 'كاملة']].map(([k, l]) => h('button', { type: 'button', class: (ed.overlay?.dir || 'bottom') === k ? 'on' : '', onclick: () => { if (!proOk(dsPhotoPro(), 'designs.photo', 'طبقات اللون للمشتركين ★')) return; setO('dir', k); if (!(ed.overlay.op > 0)) ed.overlay.op = 0.5; touch(); paintPanel(); draw(); } }, l))),
        colorRow(ed.overlay?.color || '#000000', (c) => setO('color', c)),
        rng('القوة', ed.overlay?.op || 0, 0, 0.95, 0.05, (v) => setO('op', v), (v) => `${Math.round(v * 100)}٪`));
      const hideRow = (title, sub, on, set, feature, msg) => h('div', { class: 'ds-signbox' }, h('div', {}, h('b', { text: title }), h('small', { text: sub })),
        dsHas(feature) ? h('label', { class: 'switch' }, (() => { const c = h('input', { type: 'checkbox', checked: on }); c.addEventListener('change', () => { set(!c.checked); touch(); draw(); }); return c; })(), h('span', { class: 'track' }))
          : h('button', { type: 'button', class: 'btn sm', onclick: () => typeof Pro !== 'undefined' && Pro.gate(feature, msg) }, '★ إخفاء'));
      const D = ed.deco || {};
      const setD = (k, v) => { ed.deco = { ...(ed.deco || {}), [k]: v }; };
      const frames = h('div', { class: 'ds-adj' },
        h('div', { class: 'ds-frames' }, ...Object.entries(DesignKit.FRAMES).map(([k, l]) => h('button', { type: 'button', class: `ds-frm fr-${k}${(D.frame || 'none') === k ? ' on' : ''}`, onclick: () => { setD('frame', k); touch(); paintPanel(); draw(); } }, h('i'), h('span', { text: l })))),
        D.frame && D.frame !== 'none' ? colorRow(D.fcolor || '#F6D68E', (c) => setD('fcolor', c)) : null);
      const cine = h('div', { class: 'ds-adj' },
        h('div', { class: 'ds-row2' }, h('span', { text: 'إضاءة' }), h('div', { class: 'chips' }, ...Object.entries(DesignKit.LEAKS).map(([k, l]) => h('button', { type: 'button', class: `chip leak-${k}${(D.leak || 'none') === k ? ' on' : ''}`, onclick: () => { setD('leak', k); touch(); paintPanel(); draw(); } }, l)))),
        D.leak && D.leak !== 'none' ? rng('قوة الإضاءة', D.leakOp ?? 0.55, 0.1, 1, 0.05, (v) => setD('leakOp', v), (v) => `${UI.n(Math.round(v * 100))}٪`) : null,
        rng('حبيبات فيلم', D.grain || 0, 0, 1, 0.05, (v) => setD('grain', v), (v) => `${UI.n(Math.round(v * 100))}٪`),
        rng('تعتيم الأطراف', D.vig || 0, 0, 0.85, 0.05, (v) => setD('vig', v), (v) => `${UI.n(Math.round(v * 100))}٪`),
        h('small', { class: 'ds-cap2', text: ed.motion ? '🎬 في الفيديو: الإضاءة تتحرك والحبيبات ترجف مثل الأفلام' : 'جرّبها مع التصاميم المتحركة — تتحرك بشكل سينمائي' }));
      return [
        h('details', { class: 'ds-sec', open: true }, h('summary', { text: '🖼 إطار للتصميم' }), frames),
        h('details', { class: 'ds-sec', open: true }, h('summary', { text: '🎞 لمسة سينمائية' }), cine),
        h('details', { class: 'ds-sec' }, h('summary', { text: '🌗 طبقة لون (توضّح النص)' }), overlay),
        sg.on ? (sg.paidHide ? hideRow('✍️ توقيع NOBLE', 'يظهر تحت التصميم — إخفاؤه للمشتركين', !ed.noSign, (v) => (ed.noSign = v), 'designs.nosign', 'إخفاء التوقيع للمشتركين ★') : h('div', { class: 'ds-signbox' }, h('div', {}, h('b', { text: '✍️ توقيع NOBLE' }), h('small', { text: 'يظهر تحت كل تصميم' })))) : null,
        dsWm({ ...ed, noWm: false }) && wm.paidHide ? hideRow('💧 الشعار المائي', 'حقوق العمل — إخفاؤه للمشتركين', !ed.noWm, (v) => (ed.noWm = v), 'designs.nosign', 'إخفاء الشعار للمشتركين ★') : null];
    }

    function paintPanel() {
      const kids = tab === 'bg' ? panelBg() : tab === 'callig' ? panelCallig() : tab === 'sound' ? panelSound() : tab === 'size' ? panelSize() : tab === 'more' ? panelMore() : panelText();
      RC(panel, ...kids);
      UI.digitize(panel);
    }

    /* ---------- المميزات المدفوعة المستخدمة (للتحقق وقت الحفظ) ---------- */
    function dsProUsed() {
      const out = [];
      const add = (label, fix) => out.push({ label, fix });
      if (t.premium && !dsPremium()) add('القالب ★', null);
      if (ed.photo?.lib && ed.photo.premium && !dsPremium()) add('خلفية NOBLE ★', () => { ed.photo = null; });
      ed.layers.forEach((L) => { if (L.premium && !dsPremium()) add('مخطوطة ★', () => { ed.layers = ed.layers.filter((x) => x !== L); }); });
      (t.slots || []).forEach((s) => { const f = DesignKit.FONTS[(style[s.k] || {}).font]; if (f?.premium && !dsPremium()) add(`خط «${f.name}»`, () => { delete style[s.k].font; }); });
      if (!dsPhotoPro()) {
        const P = ed.photo;
        if (P && P.mode === 'frame') add('الصورة داخل إطار', () => { P.mode = 'bg'; });
        if (P && P.preset && P.preset !== 'none') add('فلتر الصورة', () => { P.preset = 'none'; P.f = {}; });
        else if (P && Object.keys(P.f || {}).length) add('تعديلات الصورة', () => { P.f = {}; });
        if (P && P.vig > 0) add('الإطار المعتم', () => { P.vig = 0; });
        if (ed.overlay?.op > 0) add('طبقة اللون', () => { ed.overlay = null; });
      }
      if (ed.motion && !dsMotionPro()) {
        if (M.video === 'pro') add('حفظ الفيديو', null);
        (t.slots || []).forEach((s) => { const a = animOf(s.k); if (!(style[s.k] || {}).hide && values[s.k] && mAcc('t:', a) === 'pro') add(`حركة «${MotionKit.TEXT[a].name}»`, () => { style[s.k] = { ...(style[s.k] || {}), anim: mAcc('t:', DS_FREE_ALT[a]) === 'free' ? DS_FREE_ALT[a] : 'fade' }; }); });
        if (mAcc('b:', ed.bgAnim) === 'pro') add(`خلفية «${MotionKit.BG[ed.bgAnim].name}»`, () => { ed.bgAnim = mAcc('b:', DS_FREE_ALT[ed.bgAnim]) === 'free' ? DS_FREE_ALT[ed.bgAnim] : 'none'; });
        ed.layers.forEach((L) => { if (mAcc('l:', L.anim || 'pop') === 'pro') add(`حركة المخطوطة «${MotionKit.LAYER[L.anim].name}»`, () => { L.anim = 'pop'; }); });
        if (ed.dur > M.freeMax) add(`مدة ${ed.dur} ثانية`, () => { ed.dur = M.freeMax; });
        if (ed.q === 'hq' && M.hq === 'pro') add('جودة 1080p', () => { ed.q = 'light'; });
        if (ed.sound?.url && M.sound === 'pro') add('الصوت داخل الفيديو', () => { ed.sound = null; stopAudio(); });
      }
      if (ed.sound?.url && ed.sound.premium && !dsPremium() && ed.motion) add(`صوت «${ed.sound.title || ''}» ★`, () => { ed.sound = null; stopAudio(); });
      return out;
    }
    /* نافذة «اشترك واحفظ» */
    function gate(used, how) {
      const box = h('div', { class: 'ds-gate' });
      const close = () => box.remove();
      const fixable = used.every((u) => u.fix);
      RC(box, h('div', { class: 'ds-gate-c' },
        h('h3', { text: '★ تصميمك فيه مميزات للمشتركين' }),
        h('p', { text: 'جرّبتها وشفت النتيجة 👌 — عشان تحفظها أو تشاركها اشترك، أو احفظ نسخة مجانية.' }),
        h('ul', {}, ...used.map((u) => h('li', { text: u.label }))),
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => { close(); if (typeof Pro !== 'undefined') Pro.gate(ed.motion ? 'designs.motion' : 'designs.premium', 'اشترك وافتح كل مميزات التصاميم ★'); } }, '★ اشترك واحفظ'),
        M.freeCopy !== false && fixable ? h('button', { type: 'button', class: 'btn', onclick: async () => { used.forEach((u) => u.fix()); close(); touch(); paintPanel(); draw(); MS.baseKey = ''; await exportNow(how, true); } }, 'احفظ نسخة مجانية (نبدّل المميزات بأقرب بديل)') : null,
        h('button', { type: 'button', class: 'btn ghost', onclick: close }, 'ارجع للتصميم')));
      box.addEventListener('click', (e) => { if (e.target === box) close(); });
      el.append(box);
    }
    async function exportNow(how, skipCheck) {
      if (!skipCheck) { const used = dsProUsed(); if (used.length) return gate(used, how); }
      if (ed.motion) { await dsExportVideo(T(), values, style, how, ed, { buildBase, scene, MS, setBusy }); draw(); }
      else await dsExport(T(), values, style, how, ed);
      dirty = false;
    }
    const acts = h('div', { class: 'ds-acts' });
    function setBusy(txt) { acts.querySelectorAll('button').forEach((b) => (b.disabled = !!txt)); const b = acts.querySelector('.btn-primary'); if (b) b.textContent = txt || (ed.motion ? '↗ مشاركة الفيديو' : '↗ مشاركة'); }
    function paintActs() {
      RC(acts,
        h('button', { type: 'button', class: 'btn btn-primary', onclick: () => exportNow('share') }, ed.motion ? '↗ مشاركة الفيديو' : '↗ مشاركة'),
        h('button', { type: 'button', class: 'btn', onclick: () => exportNow('save') }, ed.motion ? '⬇️ حفظ فيديو' : '⬇️ حفظ في الجهاز'));
    }

    el.append(h('div', { class: 'ds-ed' },
      h('div', { class: 'ds-ed-top' },
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'رجوع', onclick: closeEd }, icon('arrowLeft', { size: 20 })),
        h('b', { text: t.title || dsOcc(t.cat)?.name || 'تصميم' }),
        h('button', { type: 'button', class: 'btn sm ds-keep', onclick: async () => { await dsRemember(t, values, style, ed); dirty = false; buzz('success'); toast('انحفظ في «تصاميمي» ✓', { type: 'success' }); } }, '💾 احفظ للتعديل')),
      modeEl, sent, dock, panel, acts));
    // لما ينزل للخيارات: المعاينة تتثبت فوق وتصغر — يشوف التعديل مباشرة بدون ما يطلع فوق
    const onScroll = () => { const on = sent.getBoundingClientRect().top < el.getBoundingClientRect().top + 2 && el.scrollHeight > el.clientHeight + 40; if (on !== dock.classList.contains('stuck')) dock.classList.toggle('stuck', on); };
    el.addEventListener('scroll', onScroll, { passive: true });
    paintMode(); paintActs();
    setTab(tab);
    if (ed.motion) syncAudio(false);
    UI.digitize(el);
  }, { cls: 'ds-screen', onBack: closeEd, cleanup: () => { MS.player?.stop(); stopAudio(); } });
}

/* صورة المستخدم: تصغير على الجهاز (ما ترتفع لأي مكان) */
function dsShrink(file, max, type = 'image/jpeg') {
  return new Promise((res, rej) => {
    const url = URL.createObjectURL(file);
    const im = new Image();
    im.onload = () => {
      const sc = Math.min(1, max / Math.max(im.width, im.height)); let c = document.createElement('canvas'); c.width = Math.round(im.width * sc); c.height = Math.round(im.height * sc); c.getContext('2d').drawImage(im, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
      // الشعار: نقص الفراغ الشفاف حوله عشان الحجم يكون صح
      if (type === 'image/png') { try { const d = c.getContext('2d').getImageData(0, 0, c.width, c.height).data; let x0 = c.width, y0 = c.height, x1 = -1, y1 = -1; for (let y = 0; y < c.height; y++) for (let x = 0; x < c.width; x++) if (d[(y * c.width + x) * 4 + 3] > 10) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
        if (x1 > x0 && y1 > y0 && (x1 - x0 + 1 < c.width - 2 || y1 - y0 + 1 < c.height - 2)) { const pad = 2, n = document.createElement('canvas'); n.width = x1 - x0 + 1 + pad * 2; n.height = y1 - y0 + 1 + pad * 2; n.getContext('2d').drawImage(c, x0 - pad, y0 - pad, n.width, n.height, 0, 0, n.width, n.height); c = n; } } catch { /* لا شيء */ } }
      res(c.toDataURL(type, 0.9));
    };
    im.onerror = () => { URL.revokeObjectURL(url); rej(new Error('img')); };
    im.src = url;
  });
}
const dsBlobB64 = (blob) => new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.onerror = rej; r.readAsDataURL(blob); });
/* حفظ/مشاركة ملف (صورة أو فيديو) على الجوال أو المتصفح */
async function dsDeliver(blob, name, how, title) {
  if (Platform.isNative) {
    const data = await dsBlobB64(blob);
    if (how === 'save') {
      await Platform.plugin('Filesystem').writeFile({ path: `NOBLE/${name}`, data, directory: 'DOCUMENTS', recursive: true });
      toast('انحفظ في مجلد المستندات ← NOBLE ✓ — وتلقاه في «تصاميمي» للتعديل', { type: 'success' });
    } else {
      const res = await Platform.plugin('Filesystem').writeFile({ path: name, data, directory: 'CACHE' });
      await Platform.plugin('Share').share({ title, url: res.uri, dialogTitle: 'شارك التصميم' });
    }
    return;
  }
  const file = new File([blob], name, { type: blob.type });
  if (how === 'share' && navigator.canShare?.({ files: [file] })) { await navigator.share({ files: [file], title }); return; }
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: name }); document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
  toast('انحفظ ✓ — وتلقاه في «تصاميمي» للتعديل', { type: 'success' });
}
async function dsAfterExport(t, values, style, ed, how) {
  await dsRemember(t, values, style, ed);
  if (t.rid) Cloud.designUsed(t.rid);
  if (ed.photo?.lib) Cloud.designUsed(ed.photo.lib);
  if (ed.sound?.id) Cloud.designUsed(ed.sound.id);
  Sync?.event?.('design', { tpl: t.id, cat: t.cat, how, motion: !!ed.motion });
  if (typeof markActive === 'function') markActive('design');
  buzz('success');
}
async function dsExport(t, values, style, how, ed = {}) {
  if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
  const [w] = DesignKit.SIZES[t.size] || DesignKit.SIZES.post;
  const cv = await DesignKit.render(t, values, { width: w, style, layers: ed.layers || [], photo: ed.photo || null, overlay: ed.overlay || null, sign: dsSign(ed.noSign), wm: dsWm(ed), extras: ed.extras || [], grad: ed.grad || null, deco: ed.deco || null });
  let blob;
  try { blob = await new Promise((r) => cv.toBlob(r, 'image/png')); } catch { blob = null; }
  if (!blob) return toast('تعذّر تجهيز الصورة — جرّب قالب ثاني', { type: 'error' });
  try { await dsDeliver(blob, `noble-${t.cat || 'design'}-${Date.now().toString(36)}.png`, how, t.title || 'تصميم'); await dsAfterExport(t, values, style, ed, how); }
  catch { /* أُلغيت */ }
}
/* تصدير الفيديو: نسجّل المشهد بالوقت الحقيقي مع الصوت */
async function dsExportVideo(t, values, style, how, ed, ctx) {
  if (typeof Pro !== 'undefined' && !Pro.gate('designs.use')) return;
  if (!MotionKit.canVideo()) return toast('جهازك ما يدعم حفظ الفيديو — احفظه صورة ثابتة', { type: 'error' });
  const { buildBase, scene, MS, setBusy } = ctx;
  MS.lock = true;
  MS.player?.stop(); MS.player = null; MS.audio?.stop();
  try {
    MS.baseKey = '';
    await buildBase(ed.q === 'hq' ? 1080 : 720);
    try { if (MS.video) { MS.video.currentTime = 0; await MS.video.play(); } } catch { /* لا شيء */ }
    setBusy('⏺ يجهّز الفيديو… ٠٪');
    const blob = await MotionKit.record(() => ({ ...scene(), level: undefined }), {
      fps: 30, bitrate: ed.q === 'hq' ? 6e6 : 2.5e6, audio: ed.sound?.url || null, vol: ed.sound?.vol ?? 0.8, audioFrom: ed.sound?.from || 0, fadeIn: ed.sound?.fade === false ? 0.15 : 1.4, fadeOut: ed.sound?.fade === false ? 0.3 : 1.8,
      onProgress: (p) => setBusy(`⏺ يجهّز الفيديو… ${UI.n(Math.round(p * 100))}٪`),
    });
    setBusy('');
    await dsDeliver(blob, `noble-${t.cat || 'design'}-${Date.now().toString(36)}.${MotionKit.ext(blob)}`, how, t.title || 'تصميم');
    await dsAfterExport(t, values, style, ed, how);
  } catch (e) { setBusy(''); if (e?.name !== 'AbortError') toast('تعذّر حفظ الفيديو: ' + (e?.message || e), { type: 'error' }); }
  MS.lock = false;
  MS.baseKey = '';
}
