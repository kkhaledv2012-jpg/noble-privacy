/* NOBLE — منطق التطبيق */
'use strict';

const { h, icon, toast } = UI;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const PRI = {
  high: { label: 'عالية', w: 3 },
  medium: { label: 'متوسطة', w: 2 },
  low: { label: 'منخفضة', w: 1 },
  none: { label: 'بدون', w: 0 },
};
const PRI_CYCLE = ['none', 'low', 'medium', 'high'];
const STATUS = { active: 'نشط', review: 'للمراجعة', archived: 'مؤرشف' };
const SORTS = [
  { key: 'num', dir: 1, label: 'الرقم', ic: 'sort' },
  { key: 'createdAt', dir: -1, label: 'الأحدث إضافة', ic: 'clock' },
  { key: 'rating', dir: -1, label: 'الأعلى تقييماً', ic: 'star' },
  { key: 'priority', dir: -1, label: 'الأولوية', ic: 'flag' },
  { key: 'name', dir: 1, label: 'الاسم (أ-ي)', ic: 'tag' },
  { key: 'visits', dir: -1, label: 'الأكثر زيارة', ic: 'external' },
];

const S = {
  vault: null,
  settings: null,
  filter: { q: '', chip: 'all', cat: '' },
  sort: SORTS[0],
  editingId: null,
  unlocked: false,
  sheets: [],
  tab: 'sites',
};

/* ================= الأقسام ================= */
function setTab(tab, opts = {}) {
  // 🧭 «اكتشف» مدموج داخل الأخبار (من لوحة التحكم)
  if (tab === 'discover' && typeof newsHasDiscover === 'function' && newsHasDiscover() && typeof NEWS !== 'undefined') { NEWS.view = 'discover'; tab = 'news'; }
  if (typeof visibleTabs === 'function' && !visibleTabs().includes(tab)) tab = visibleTabs()[0];
  const changed = S.tab !== tab;
  // سجل التنقل: زر الرجوع يرجّعك للقسم اللي قبله
  S.tabHist = S.tabHist || [];
  if (changed && S.tab && !opts.back) { S.tabHist = [...S.tabHist.filter((t) => t !== S.tab), S.tab].slice(-12); }
  if (changed && !opts.back && !opts.fwd && typeof NavKit !== 'undefined') NavKit.clearFwd();
  S.tab = tab;
  if (typeof Usage !== 'undefined') Usage.onTab(tab);
  if (typeof Insights !== 'undefined') Insights.firstTab(tab);
  $$('#tabbar button').forEach((b) => b.classList.toggle('on', b.dataset.tab === tab));
  if (typeof TabStyles !== 'undefined') TabStyles.move();
  const order = typeof visibleTabs === 'function' ? visibleTabs() : [];
  const dir = order.indexOf(tab) >= order.indexOf(setTab.prev || tab) ? -1 : 1; // RTL: التالي يدخل من اليسار
  $$('.view').forEach((v) => {
    v.hidden = v.dataset.view !== tab;
    if (!v.hidden && changed) { v.style.setProperty('--dir', dir); v.classList.remove('view-in'); void v.offsetWidth; v.classList.add('view-in'); }
  });
  setTab.prev = tab;
  $('#fab').hidden = tab === 'games' || tab === 'news' || tab === 'designs' || tab === 'azkar' || tab === 'discover';
  $('#fab').setAttribute('aria-label', { sites: 'إضافة موقع', tasks: 'مهمة جديدة', finance: 'حركة جديدة', today: 'إضافة سريعة', games: '' }[tab] || '');
  $('#fab').classList.toggle('fab-ai', tab === 'today');
  if (tab === 'games' && typeof renderGames === 'function') renderGames();
  if (tab === 'finance' && typeof renderFinance === 'function') renderFinance();
  if (tab === 'news' && typeof loadNews === 'function') { loadNews(); if (typeof newsHasDiscover === 'function' && newsHasDiscover() && typeof loadFeed === 'function') loadFeed(); }
  if (tab === 'today' && typeof renderToday === 'function') renderToday();
  if (tab === 'designs' && typeof loadDesigns === 'function') loadDesigns();
  if (tab === 'azkar' && typeof renderAzkar === 'function') renderAzkar();
  if (tab === 'discover' && typeof renderDiscover === 'function') { renderDiscover(); loadFeed(); }
  if (typeof renderTabbar === 'function' && changed) renderTabbar();
  if (changed && typeof buzz === 'function') buzz('select');
  if (typeof Ads !== 'undefined') Ads.banner();
  if (typeof AccessUI !== 'undefined' && tab !== 'games' && tab !== 'news' && tab !== 'designs' && tab !== 'azkar' && tab !== 'discover') $('#fab').hidden = AccessUI.locked(tab);
  window.scrollTo({ top: 0 });
  updateNavBack();
  if (typeof NavKit !== 'undefined') NavKit.sync();
}

/* ================= الرجوع والتنقل ================= */
/* خطوة رجوع واحدة داخل التطبيق — يرجّع false إذا ما فيه شي يُرجع له */
function navBack() {
  if (!$('#notice-gate').hidden) return true;
  if (typeof VEdit !== 'undefined' && VEdit.isOpen()) { if (!S.sheets.length) { VEdit.close(); return true; } }
  if (document.querySelector('.dsc-viewer') && typeof dscOpenStories === 'function' && dscOpenStories.close) { dscOpenStories.close(); return true; }
  if (typeof ainClose === 'function' && ainClose()) return true;
  if (S.tab === 'news' && typeof NEWS !== 'undefined' && NEWS.view === 'ai') { NEWS.view = 'feed'; renderNews(); window.scrollTo({ top: 0 }); return true; }
  if (typeof Upgrade !== 'undefined' && Upgrade.isOpen?.()) { Upgrade.close(); return true; }
  if (typeof gameBack === 'function' && gameBack()) return true;
  if (document.documentElement.classList.contains('vc-open') && typeof Voice !== 'undefined') { Voice.cancel(); return true; }
  if (S.sheets.length) { closeSheet(); return true; }
  if (typeof azBack === 'function' && azBack()) return true;
  if (!S.unlocked) return false;
  if (S.tab === 'finance' && typeof FIN !== 'undefined' && FIN.sub && FIN.sub !== 'home') { FIN.sub = 'home'; renderFinance(); window.scrollTo({ top: 0 }); updateNavBack(); return true; }
  if (S.tab === 'news' && typeof NEWS !== 'undefined' && NEWS.view === 'saved') { NEWS.view = 'feed'; renderNews(); updateNavBack(); return true; }
  if (S.tab === 'news' && typeof NEWS !== 'undefined' && NEWS.cat) { NEWS.cat = ''; NEWS.items = []; loadNews({ force: true }); updateNavBack(); return true; }
  if (S.tab === 'sites' && (S.filter.q || S.filter.chip !== 'all' || S.filter.cat)) { clearFilters(); updateNavBack(); return true; }
  const vis = visibleTabs();
  while ((S.tabHist || []).length) {
    const t = S.tabHist.pop();
    if (t !== S.tab && vis.includes(t)) { setTab(t, { back: true }); return true; }
  }
  if (S.tab !== startTab()) { setTab(startTab(), { back: true }); return true; }
  return false;
}
/* زر الرجوع الظاهر أعلى التطبيق */
function canNavBack() {
  if (!S.unlocked) return false;
  if (S.tab === 'finance' && typeof FIN !== 'undefined' && FIN.sub && FIN.sub !== 'home') return true;
  if (S.tab === 'news' && typeof NEWS !== 'undefined' && (NEWS.view === 'saved' || NEWS.cat)) return true;
  if (S.tab === 'sites' && (S.filter.q || S.filter.chip !== 'all' || S.filter.cat)) return true;
  const vis = typeof visibleTabs === 'function' ? visibleTabs() : [];
  return (S.tabHist || []).some((t) => t !== S.tab && vis.includes(t)) || (typeof startTab === 'function' && S.tab !== startTab());
}
function updateNavBack() {
  const b = $('#nav-back');
  if (!b) return;
  const on = canNavBack();
  if (b.hidden === !on) return;
  b.hidden = !on;
  if (on) { b.classList.remove('nb-in'); void b.offsetWidth; b.classList.add('nb-in'); }
}
let exitArmed = 0;

/* ================= تشغيل ================= */
document.addEventListener('DOMContentLoaded', boot);

async function boot() {
  decorate();
  S.settings = await Core.getSettings();
  applyPrefs();
  applyContent();
  loadRemoteContent();
  bindAuth();
  bindApp();
  bindNative();
  bindStorage();

  await route();
  const splashOut = () => $('#splash').classList.add('out');
  // 🎬 1.18.3: فيديو الافتتاح (لو مفعّل ووقته) — يغطي الشاشة، والتطبيق يجهز وراه
  let intro = false;
  if (typeof Intro !== 'undefined') try { intro = await Intro.run({ onReady: splashOut }); } catch (e) { console.warn('intro', e); }
  if (intro) splashOut();
  else setTimeout(splashOut, !pref('motion') ? 400 : ({ calm: 650, normal: 1100, lively: 1600 })[Brand.cfg().motion] || 1100);
}

function decorate() {
  $$('.pw-toggle').forEach((b) => b.append(icon('eye', { size: 20 })));
  $('#settings-btn').append(icon('settings', { size: 20 }));
  $('#nav-back').append(icon('arrowLeft', { size: 20 }));
  $('#nav-back').addEventListener('click', () => { navBack(); updateNavBack(); });
  $('#lock-btn').append(icon('lock', { size: 20 }));
  $('.search-ic').append(icon('search', { size: 20 }));
  $('#sort-btn').append(icon('sliders', { size: 20 }));
  $('#fab').append(icon('plus', { size: 30, stroke: 2.4 }));
  $('#inbox-btn').prepend(icon('inbox', { size: 20 }));
  $('.bio-ic').append(icon('finger', { size: 22 }));
  $$('[data-close]').forEach((b) => b.append(icon('x', { size: 20 })));
  $('#item-delete').append(icon('trash', { size: 18 }), 'حذف');
  const ri = $('#rating-input');
  for (let i = 1; i <= 5; i++) {
    ri.append(h('button', { type: 'button', class: 'star-btn', dataset: { v: i }, 'aria-label': `${i} من 5` }, icon('star', { size: 34, fill: true, stroke: 0 })));
  }
  ri.addEventListener('click', (e) => {
    const b = e.target.closest('[data-v]');
    if (!b) return;
    const v = Number(b.dataset.v);
    setFormRating(Number($('#item-form').dataset.rating) === v ? 0 : v);
  });
}

/* ================= الدخول ================= */
/* يحدد الشاشة المناسبة: محلي فقط، أو حساب سحابي */
/* 1.17: المايك في خانات البحث والكتابة الثابتة + الزر العائم */
function voiceInit() {
  if (typeof Voice === 'undefined') return;
  Voice.attach($('#search'), 'sites');
  Voice.attach($('#t-search'), 'tasks');
  Voice.attach($('#task-form [name=title]'), 'tasks', { replace: false });
  Voice.refresh();
}
async function route() {
  try { LoginUI.apply(); } catch (e) { console.warn('loginui', e); }
  try { voiceInit(); } catch (e) { console.warn('voice', e); }
  if (S.unlocked && typeof loadSectionAccess === 'function') loadSectionAccess().catch(() => {});
  if (!Cloud.enabled) {
    if (!(await Core.isSetup())) return showAuth('setup');
    return (await Core.isUnlocked()) ? enterApp() : showAuth('login');
  }
  await migrateProject();
  await storeConfigReady();
  const u = await Cloud.user();
  const { meta } = await browser.storage.local.get('meta');
  // 🏪 جهاز بحساب خفي (وضع المتجر): يفتح تلقائياً بمفتاح الجهاز — بدون كلمة مرور
  if (meta?.anon && (await Core.isSetup())) return storeUnlock(u, meta);
  // الحساب محفوظ على الجهاز: يفتح بكلمة المرور/البصمة حتى لو انتهت جلسة السحابة أو لا يوجد إنترنت
  if ((await Core.isSetup()) && meta?.owner && (!u || meta.owner === u.id)) {
    return (await Core.isUnlocked()) ? enterApp() : showAuth('login');
  }
  // 🏪 وضع المتجر: بدون شاشة دخول — حساب خفي تلقائي
  if (typeof Store !== 'undefined' && Store.noLogin() && !(u && !u.is_anonymous)) return storeAutoEnter(u);
  return showAuth('cloud', u?.email || meta?.email);
}

async function showAuth(mode, email) {
  if (mode === 'login' && Cloud.enabled) {
    const { meta } = await browser.storage.local.get('meta');
    if (meta?.anon) { const k = typeof Store !== 'undefined' ? Store.deviceKey(false) : ''; if (k && (await Core.unlock(k)).ok) return enterApp(); }
  }
  S.unlocked = false;
  S.vault = null;
  closeAllSheets(true);
  $('#notice-gate').hidden = true; $('#notice-bar').hidden = true;
  if (typeof NT !== 'undefined') NT.showing = null;
  document.body.classList.remove('noticed');
  $('#app').hidden = true;
  $('#auth').hidden = false;
  $('#setup-form').hidden = mode !== 'setup';
  $('#login-form').hidden = mode !== 'login';
  $('#cloud-form').hidden = mode !== 'cloud';
  if (mode === 'cloud') {
    setCloudMode('signin');
    let last = '';
    try { last = localStorage.getItem('nw:last-email') || ''; } catch { /* لا شيء */ }
    if (email || last) $('#c-email').value = email || last;
    initSavedAccounts(email || last);
    offStartPaint();
    { const g = $('#c-guest'); if (g) g.hidden = !(typeof Store !== 'undefined' && Store.on() && Store.cfg().login !== false && Store.wantLogin()); }
  }
  if (typeof LoginUI !== 'undefined') try { LoginUI.refreshName(); } catch { /* لا شيء */ }
  if (mode === 'login' && Cloud.enabled) {
    const u = await Cloud.user();
    const { meta } = await browser.storage.local.get('meta');
    const who = u?.email || meta?.email || '';
    $('#login-who').hidden = !who;
    $('#login-who').textContent = who ? `مسجّل باسم ${who}` : '';
    $('#signout-btn').hidden = !(u || meta?.owner);
  }
  if (mode === 'login') {
    $('#login-pw').value = '';
    $('#login-error').textContent = '';
    checkLockout();
    setupBioLogin();
  }
}

let lockoutTimer;
async function checkLockout() {
  clearInterval(lockoutTimer);
  const btn = $('#login-form [type=submit]');
  const tick = async () => {
    const ms = await Core.lockoutRemaining();
    btn.disabled = ms > 0;
    if (ms > 0) $('#login-error').textContent = `محاولات كثيرة خاطئة. حاول بعد ${Math.ceil(ms / 1000)} ثانية.`;
    else {
      if ($('#login-error').textContent.startsWith('محاولات')) $('#login-error').textContent = '';
      clearInterval(lockoutTimer);
    }
  };
  await tick();
  lockoutTimer = setInterval(tick, 1000);
}

/* 👁️ 1.21.20: عين «إظهار كلمة المرور» على كل خانة كلمة مرور في التطبيق — حتى اللي تنفتح بعدين
   (التأكيد، نسيت كلمة المرور، تغيير كلمة المرور، احفظ حسابك…) عشان ما يغلط ويتقفل عليه */
function pwEyeToggle(b) {
  const input = b.parentElement?.querySelector('input');
  if (!input) return;
  const show = input.type === 'password';
  input.type = show ? 'text' : 'password';
  b.setAttribute('aria-label', show ? 'إخفاء كلمة المرور' : 'إظهار كلمة المرور');
  b.replaceChildren(icon(show ? 'eyeOff' : 'eye', { size: 20 }));
  try { input.focus({ preventScroll: true }); const n = input.value.length; input.setSelectionRange(n, n); } catch { /* لا شيء */ }
}
function pwEyes(root = document) {
  const list = root.matches?.('input[type="password"]') ? [root] : [...(root.querySelectorAll?.('input[type="password"]') || [])];
  for (const input of list) {
    if (input.dataset.eye || input.closest('.pw-wrap')) { input.dataset.eye = '1'; continue; }
    input.dataset.eye = '1';
    const wrap = document.createElement('div'); wrap.className = 'pw-wrap pw-auto';
    input.before(wrap); wrap.append(input);
    const btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'icon-btn pw-toggle'; btn.setAttribute('aria-label', 'إظهار كلمة المرور'); btn.tabIndex = -1;
    btn.append(icon('eye', { size: 20 }));
    btn.addEventListener('click', (e) => { e.preventDefault(); pwEyeToggle(btn); });
    wrap.append(btn);
  }
}
(() => {
  const go = () => { pwEyes(); new MutationObserver((ms) => { for (const m of ms) for (const n of m.addedNodes) if (n.nodeType === 1) pwEyes(n); }).observe(document.body, { childList: true, subtree: true }); };
  document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', go) : go();
})();

function bindAuth() {
  $$('.pw-toggle').forEach((b) => { if (b.closest('.pw-auto')) return; b.addEventListener('click', () => pwEyeToggle(b)); });

  $('#setup-pw').addEventListener('input', (e) => {
    const pw = e.target.value;
    const s = UI.strength(pw);
    $('.meter').dataset.level = pw ? s : '';
    $('#setup-strength').textContent = pw ? `القوة: ${UI.STRENGTH_LABELS[s]}` : '٦ أحرف على الأقل';
  });

  $('#setup-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const pw = $('#setup-pw').value, pw2 = $('#setup-pw2').value;
    const err = $('#setup-error');
    if (pw.length < 6) return (err.textContent = 'كلمة المرور ٦ أحرف على الأقل.');
    if (pw !== pw2) return (err.textContent = 'كلمتا المرور غير متطابقتين.');
    err.textContent = '';
    const btn = $('#setup-form [type=submit]');
    btn.disabled = true;
    try {
      await Core.setup(pw);
      $('#setup-form').reset();
      await enterApp();
      toast('تم إنشاء الخزنة — أضف أول موقع', { type: 'success' });
    } catch (ex) {
      err.textContent = 'تعذّر الإنشاء: ' + ex.message;
    } finally {
      btn.disabled = false;
    }
  });

  $('#login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const input = $('#login-pw');
    if (!input.value) return input.focus();
    const btn = $('#login-form [type=submit]');
    btn.disabled = true;
    const res = await Core.unlock(input.value);
    btn.disabled = false;
    if (res.ok) {
      Resume.pw = input.value;
      input.value = '';
      input.blur();
      return enterApp();
    }
    input.classList.add('is-invalid', 'shake');
    setTimeout(() => input.classList.remove('shake'), 400);
    if (res.wait) checkLockout();
    else $('#login-error').textContent = `كلمة المرور غير صحيحة — تبقّى ${res.left} ${res.left === 1 ? 'محاولة' : 'محاولات'}.`;
  });
  $('#login-pw').addEventListener('input', (e) => e.target.classList.remove('is-invalid'));

  bindCloudAuth();
  $('#forgot-btn').addEventListener('click', async () => {
    if (Cloud.enabled) return forgotCloud();
    const ok = await confirmSheet({
      title: 'البدء من جديد؟',
      text: 'لا يمكن استعادة كلمة المرور لأن البيانات مشفّرة بها. الحل الوحيد حذف كل البيانات والبدء من جديد.',
      ok: 'حذف والبدء',
      typeToConfirm: 'حذف',
    });
    if (!ok) return;
    await Core.reset();
    showAuth('setup');
  });
}

/* تسجيل فتح التطبيق (يُحفظ حتى بدون نت) + تغيّر الإصدار */
function trackOpen() {
  let prev = '';
  try { prev = localStorage.getItem('nw:last-ver') || ''; localStorage.setItem('nw:last-ver', Cloud.VERSION); } catch { /* لا شيء */ }
  if (prev && prev !== Cloud.VERSION) Sync.event('version_change', { from: prev, to: Cloud.VERSION });
  Sync.event('app_open', { v: Cloud.VERSION, net: Sync.online() });
}

async function enterApp() {
  try {
    S.vault = await Core.load();
  } catch {
    return showAuth('login');
  }
  try { const { meta } = await browser.storage.local.get('meta'); if (meta && !meta.anon && typeof Store !== 'undefined') Store.setWantLogin(false); } catch { /* لا شيء */ }
  setTimeout(() => paintAcctBtn(), 0);
  const first = !S.entered;
  try { const { meta } = await browser.storage.local.get('meta'); document.documentElement.classList.toggle('anon', !!meta?.anon); } catch { /* لا شيء */ }
  S.unlocked = true;
  S.entered = true;
  // 1.19: 📊 إحصائيات الاستخدام + 🔔 الإشعارات الخاصة
  if (typeof Usage !== 'undefined') { Usage.bind(); Usage.start(); }
  if (typeof PushNotes !== 'undefined') { PushNotes.bind(); setTimeout(() => PushNotes.sync(true), 2500); }
  // 1.20: 👋 «وش نناديك؟» مرة وحدة للي دخل بدون حساب
  if (typeof GuestName !== 'undefined') setTimeout(() => GuestName.maybeAsk(), 1500);
  $('#auth').hidden = true;
  $('#app').hidden = false;
  if (first) setTab(startTab());
  if (S.vault.notes !== undefined) { await commit((v) => { delete v.notes; }); } // أُلغي قسم الملاحظات في 1.4
  render();
  if (typeof Trash !== 'undefined') Trash.purge().catch(() => {});
  startActivityWatch();
  if (typeof syncReminders === 'function') syncReminders();
  if (typeof scheduleFinReminders === 'function') scheduleFinReminders();
  if (typeof dBriefSchedule === 'function') dBriefSchedule();
  if (S.pendingTask) { const id = S.pendingTask; S.pendingTask = null; openTaskById(id); }
  if (Cloud.enabled) {
    const { meta } = await browser.storage.local.get('meta');
    Sync.init(meta?.owner || '');
    Pro.init(meta?.owner || '');
    setTimeout(() => { try { Pro.promoPopup(); } catch { /* لا شيء */ } if (typeof dsNewsCheck === 'function') dsNewsCheck(); }, 1800);
    setTimeout(() => { if (typeof azkarToastWhenClear === 'function') azkarToastWhenClear(); }, 2600);
    // رسائل التجديد (بعد ما تهدأ النوافذ الأولى) + عروض المستخدم
    setTimeout(() => { if (typeof msRemindCheck === 'function' && !document.querySelector('.promo-pop, .ms-pop, .offer-pop')) msRemindCheck().catch(() => {}); }, 6500);
    if (first) trackOpen();
    afterCloudEnter();
  }
  await consumeShared();
}

/* ================= القفل التلقائي ================= */
let activityBound = false, lastTouch = 0, expiryTimer, hiddenAt = 0;
function startActivityWatch() {
  if (!activityBound) {
    const onActivity = () => {
      if (!S.unlocked) return;
      const now = Date.now();
      if (now - lastTouch > 15000) { lastTouch = now; Core.touch(); }
    };
    ['pointerdown', 'keydown'].forEach((ev) => document.addEventListener(ev, onActivity, { passive: true }));
    document.addEventListener('visibilitychange', async () => {
      if (document.hidden) hiddenAt = Date.now();
      else if (S.unlocked && !(await Core.getKey())) lockedOut();
    });
    activityBound = true;
  }
  clearInterval(expiryTimer);
  expiryTimer = setInterval(async () => {
    if (S.unlocked && !(await Core.getKey())) lockedOut();
  }, 10000);
}
function lockedOut(msg = 'تم قفل الخزنة') {
  if (typeof FIN !== 'undefined') FIN.unlocked = false;
  if (!S.unlocked) return;
  clearInterval(expiryTimer);
  showAuth('login');
  if (!document.documentElement.classList.contains('anon')) toast(msg); // الحساب الخفي يرجع ينفتح بصمت
}

function bindStorage() {
  browser.storage.onChanged.addListener(async (changes, area) => {
    if (area === 'session' && changes.sessionKey && !changes.sessionKey.newValue && S.unlocked) lockedOut();
    if (area === 'local' && changes.auth && !changes.auth.newValue) location.reload();
  });
}

const APP_TAGLINES = { vault: 'خزنة مواقعك', tasks: 'مهامك وتذكيراتك', finance: 'أموالك بوضوح', games: 'العب واجمع النقاط' };
const appTagline = () => (APP.id !== 'nobleweb' && APP_TAGLINES[APP.id]) || Content.get('tagline');

/* ================= الحفظ ================= */
const SYNC_SKIP = new Set(['rev', 'savedAt', '_ts']);
function sectionHashes(v) {
  const o = {};
  for (const k of Object.keys(v || {})) if (!SYNC_SKIP.has(k)) o[k] = JSON.stringify(v[k] ?? null);
  return o;
}
/* دمج نسخة السحابة مع نسخة الجهاز قسماً قسماً (الأحدث تعديلاً يفوز)
 * — التطبيقات المنفصلة تشترك في نفس الحساب، فلا يمسح تطبيق تعديلات تطبيق آخر */
async function mergeRemote(remote, remoteNewer) {
  const theirs = await Core.openVault(remote.vault);
  const mine = await Core.load();
  mine._ts = { ...(mine._ts || {}) };
  let took = 0;
  for (const k of new Set([...Object.keys(mine), ...Object.keys(theirs)])) {
    if (SYNC_SKIP.has(k)) continue;
    const tL = mine._ts[k] || 0, tR = theirs._ts?.[k] || 0;
    if (tR > tL || (!tR && !tL && remoteNewer)) {
      if (JSON.stringify(mine[k] ?? null) !== JSON.stringify(theirs[k] ?? null)) { mine[k] = theirs[k]; took++; }
      if (tR) mine._ts[k] = tR;
    }
  }
  mine.rev = Math.max(mine.rev || 0, theirs.rev || 0);
  if (took) { S.vault = await Core.save(mine); render(); }
  return took;
}
/* مزامنة الخزنة: سحب ← دمج ← رفع. ترجع 'pw' إذا تغيّرت كلمة المرور من جهاز آخر */
async function syncVault() {
  const remote = await Cloud.pullVault();
  const { meta, auth } = await browser.storage.local.get(['meta', 'auth']);
  const rs = remote?.savedAt || 0, ls = meta?.savedAt || 0;
  if (remote && remote.auth?.salt !== auth?.salt) {
    if (rs > ls) return 'pw';
  } else if (remote && rs !== ls && rs > (meta?.syncedAt || 0)) {
    await mergeRemote(remote, rs > ls);
  }
  const m2 = (await browser.storage.local.get('meta')).meta || {};
  if (!remote || (m2.savedAt || 0) !== rs) await Cloud.pushVault();
  await browser.storage.local.set({ meta: await Core.metaWith({ syncedAt: m2.savedAt || 0 }) });
  return 'ok';
}
async function commit(mutate) {
  try {
    const fresh = await Core.load();
    const before = sectionHashes(fresh);
    const result = mutate(fresh);
    // وقت تعديل كل قسم — حتى يُدمج بأمان مع تعديلات التطبيقات الأخرى على نفس الحساب
    const after = sectionHashes(fresh), now = Date.now();
    fresh._ts = { ...(fresh._ts || {}) };
    for (const k of new Set([...Object.keys(before), ...Object.keys(after)])) if (before[k] !== after[k]) fresh._ts[k] = now;
    S.vault = await Core.save(fresh);
    render();
    schedulePush();
    return result ?? true;
  } catch (e) {
    if (e.message === 'locked') lockedOut('انتهت الجلسة — افتح الخزنة مجدداً');
    else toast('تعذّر الحفظ: ' + e.message, { type: 'error' });
    return false;
  }
}
const byId = (v, id) => v.items.find((it) => it.id === id);

/* ================= العرض ================= */
function matchesChip(it, chip) {
  switch (chip) {
    case 'fav': return it.favorite;
    case 'high': case 'medium': case 'low': return it.priority === chip;
    case 'review': return it.status === 'review';
    case 'archived': return it.status === 'archived';
    default: return true;
  }
}

function visibleItems() {
  const { q, chip, cat } = S.filter;
  const terms = UI.normAr(q.trim()).split(/\s+/).filter(Boolean);
  const list = S.vault.items.filter((it) => {
    if (!matchesChip(it, chip)) return false;
    if (chip === 'all' && it.status === 'archived' && !terms.length) return false; // المؤرشف يُخفى افتراضياً
    if (cat && it.category !== cat) return false;
    if (terms.length) {
      const hay = UI.normAr([it.name, it.url, it.note, it.category, (it.tags || []).join(' '), '#' + it.num].join(' '));
      if (!terms.every((t) => hay.includes(t))) return false;
    }
    return true;
  });
  const { key, dir } = S.sort;
  const val = (it) => (key === 'name' ? it.name || '' : key === 'priority' ? PRI[it.priority].w : it[key] ?? 0);
  list.sort((a, b) => {
    const va = val(a), vb = val(b);
    const c = typeof va === 'string' ? va.localeCompare(vb, 'ar') : va - vb;
    return c * dir || a.num - b.num;
  });
  return list;
}

function render() {
  if (!S.vault) return;
  setTimeout(updateNavBack, 0);
  if (typeof renderTasks === 'function') renderTasks();
  if (S.tab === 'finance' && typeof renderFinance === 'function') renderFinance();
  if (S.tab === 'news' && typeof renderNews === 'function') renderNews();
  if (S.tab === 'today' && typeof renderToday === 'function') renderToday();
  if (S.tab === 'designs' && typeof renderDesigns === 'function') renderDesigns();
  if (S.tab === 'azkar' && typeof renderAzkar === 'function') renderAzkar();
  if (S.tab === 'discover' && typeof renderDiscover === 'function') renderDiscover();
  renderStats();
  renderChips();
  if (typeof renderFeatured === 'function') renderFeatured();
  const list = visibleItems();
  const frag = document.createDocumentFragment();
  list.forEach((it, i) => {
    const c = renderCard(it);
    c.style.animationDelay = Math.min(i, 8) * 30 + 'ms';
    frag.append(c);
  });
  $('#list').replaceChildren(frag);
  if (typeof Ads !== 'undefined') { Ads.inject($('#list')); Ads.banner(); }
  if (typeof AccessUI !== 'undefined') AccessUI.apply();

  const total = S.vault.items.length;
  $('#result-count').textContent = list.length === total ? `${total} موقع` : `${list.length} من ${total}`;
  $('#stats').hidden = !!S.settings.hideStats;
  $('#sort-label').textContent = 'الترتيب: ' + S.sort.label;
  if (Cloud.enabled && S.sync) setSync(S.sync);
  else $('#brand-sub').textContent = total && visibleTabs().includes('sites') ? `${UI.n(total)} موقع محفوظ` : appTagline();

  const empty = $('#empty');
  empty.hidden = list.length > 0;
  if (!list.length) {
    empty.replaceChildren(...(total === 0
      ? [h('img', { src: (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'), alt: '' }), h('h3', { text: Content.get('emptySitesTitle') }),
         h('p', { text: Content.get('emptySitesText') })]
      : [icon('search', { size: 36 }), h('h3', { text: 'لا نتائج' }), h('p', { text: 'جرّب كلمة أخرى أو غيّر التصفية.' }),
         h('button', { class: 'btn sm', type: 'button', onclick: clearFilters, text: 'عرض الكل' })]));
  }
  UI.digitize($('#app'));
}

function renderStats() {
  const items = S.vault.items;
  const rated = items.filter((i) => i.rating > 0);
  const avg = rated.length ? (rated.reduce((s, i) => s + i.rating, 0) / rated.length).toFixed(1) : '—';
  const cats = new Set(items.map((i) => i.category).filter(Boolean)).size;
  const card = (cls, chip, label, value, ic, icCls, sub) =>
    h('button', { type: 'button', class: `stat ${cls}${S.filter.chip === chip && chip !== 'all' ? ' active' : ''}`, onclick: () => setChip(chip) },
      h('span', { class: `stat-ic ${icCls || ''}` }, ic),
      h('span', { class: 'stat-value num', text: value }),
      h('span', { class: 'stat-label', text: label }),
      sub ? h('span', { class: 'stat-sub', text: sub }) : null);
  $('#stats').replaceChildren(
    card('stat-hero', 'all', 'إجمالي المواقع', items.length, icon('layers', { size: 18 }), '', `${cats} تصنيف`),
    card('', 'fav', 'المفضلة', items.filter((i) => i.favorite).length, icon('heart', { size: 16, fill: true, stroke: 0 }), 'i-fav'),
    card('', 'high', 'أولوية عالية', items.filter((i) => i.priority === 'high').length, icon('flag', { size: 16 }), 'i-high'),
    card('', 'review', 'للمراجعة', items.filter((i) => i.status === 'review').length, icon('clock', { size: 16 }), 'i-review'),
    h('button', { type: 'button', class: 'stat', onclick: () => { S.sort = SORTS[2]; render(); } },
      h('span', { class: 'stat-ic i-rate' }, icon('star', { size: 16, fill: true, stroke: 0 })),
      h('span', { class: 'stat-value num', text: avg }),
      h('span', { class: 'stat-label', text: 'متوسط التقييم' }))
  );
}

function renderChips() {
  const items = S.vault.items;
  const count = (fn) => items.filter(fn).length;
  const chip = (id, label, cls = '', n = null, dot = false) =>
    h('button', { type: 'button', class: `chip ${cls}${S.filter.chip === id && !S.filter.cat ? ' on' : ''}`, onclick: () => setChip(id) },
      dot ? h('i') : null, label, n != null ? h('span', { class: 'count num', text: n }) : null);
  const cats = new Map();
  items.forEach((i) => i.category && cats.set(i.category, (cats.get(i.category) || 0) + 1));
  $('#chips').replaceChildren(
    chip('all', 'الكل'),
    chip('fav', 'المفضلة', '', count((i) => i.favorite)),
    chip('high', 'عالية', 'c-high', null, true),
    chip('medium', 'متوسطة', 'c-medium', null, true),
    chip('low', 'منخفضة', 'c-low', null, true),
    chip('review', 'للمراجعة'),
    chip('archived', 'المؤرشف', '', count((i) => i.status === 'archived')),
    cats.size ? h('span', { class: 'chip-sep' }) : null,
    ...[...cats.entries()].sort((a, b) => b[1] - a[1]).map(([c, n]) =>
      h('button', { type: 'button', class: `chip${S.filter.cat === c ? ' on' : ''}`, onclick: () => { S.filter.cat = S.filter.cat === c ? '' : c; S.filter.chip = 'all'; render(); } },
        c, h('span', { class: 'count num', text: n })))
  );
}

function setChip(id) {
  S.filter.chip = S.filter.chip === id && id !== 'all' ? 'all' : id;
  S.filter.cat = '';
  render();
}
function clearFilters() {
  S.filter = { q: '', chip: 'all', cat: '' };
  $('#search').value = '';
  render();
}

function renderCard(it) {
  let path = '';
  try { const u = new URL(it.url); path = (u.pathname + u.search).replace(/\/$/, ''); } catch {}
  const card = h('article', { class: ['card', it.favorite && 'fav', it.status === 'archived' && 'is-archived'].filter(Boolean).join(' '), dataset: { id: it.id } });

  card.append(h('div', { class: 'card-top' },
    UI.avatar(it, 46),
    h('div', { class: 'card-title', dataset: { act: 'menu' } },
      h('div', { class: 'card-name', text: it.name || Core.domainOf(it.url) }),
      h('div', { class: 'card-url' }, Core.domainOf(it.url), path ? h('span', { class: 'path', text: path }) : null)),
    h('span', { class: 'num-pill num', text: '#' + it.num }),
    h('button', { type: 'button', class: `fav-btn${it.favorite ? ' on' : ''}`, dataset: { act: 'fav' }, 'aria-label': 'مفضلة' },
      icon('heart', { size: 22, fill: it.favorite }))));

  const stars = h('div', { class: 'stars' });
  for (let i = 1; i <= 5; i++) stars.append(h('button', { type: 'button', class: `star-btn${i <= it.rating ? ' on' : ''}`, dataset: { act: 'rate', v: i }, 'aria-label': `${i} من 5` }, icon('star', { size: 20, fill: true, stroke: 0 })));
  card.append(h('div', { class: 'card-mid' }, stars,
    h('button', { type: 'button', class: `badge pri-${it.priority}`, dataset: { act: 'pri' } }, h('i'), PRI[it.priority].label)));

  if (it.note) card.append(h('p', { class: 'card-note', dataset: { act: 'note' }, text: it.note }));

  const foot = h('div', { class: 'card-foot' });
  if (it.category) foot.append(h('span', { class: 'cat', dataset: { act: 'cat', v: it.category }, text: it.category }));
  if (it.status !== 'active') foot.append(h('span', { class: `status st-${it.status}`, text: STATUS[it.status] }));
  (it.tags || []).slice(0, 3).forEach((t) => foot.append(h('span', { class: 'tag', dataset: { act: 'tag', v: t }, text: '#' + t })));
  foot.append(h('div', { class: 'card-actions' },
    h('button', { type: 'button', class: 'icon-btn', dataset: { act: 'menu' }, 'aria-label': 'المزيد' }, icon('more', { size: 18 })),
    h('a', { class: 'open-btn', href: it.url, target: '_blank', rel: 'noopener noreferrer', dataset: { act: 'visit' } }, 'فتح', icon('arrowLeft', { size: 16 }))));
  card.append(foot);
  return card;
}

/* ================= أحداث ================= */
function bindApp() {
  $('#list').addEventListener('click', onCardClick);
  $('#fab').addEventListener('click', () => {
    if (S.tab === 'today' && typeof openQuickAdd === 'function') openQuickAdd();
    else if (S.tab === 'tasks') openTaskSheet();
    else if (S.tab === 'finance') openTxSheet();
    else openItemSheet();
  });
  $('#tabbar').addEventListener('click', (e) => { const b = e.target.closest('button[data-tab]'); if (b) setTab(b.dataset.tab); });
  $('#lock-btn').addEventListener('click', async () => { await Core.lock(); lockedOut(); });
  $('#settings-btn').addEventListener('click', openSettings);
  $('#sort-btn').addEventListener('click', openSortSheet);
  let t;
  $('#search').addEventListener('input', (e) => { clearTimeout(t); t = setTimeout(() => { S.filter.q = e.target.value; render(); }, 120); });
  $('#backdrop').addEventListener('click', () => closeSheet());
  $$('[data-close]').forEach((b) => b.addEventListener('click', () => closeSheet()));
  bindItemForm();
  bindSettings();
}

async function onCardClick(e) {
  const el = e.target.closest('[data-act]');
  if (!el) return;
  const card = el.closest('.card');
  const id = card?.dataset.id;
  const it = id && byId(S.vault, id);
  if (!it) return;
  switch (el.dataset.act) {
    case 'fav':
      buzz('light');
      await commit((v) => { const x = byId(v, id); x.favorite = !x.favorite; x.updatedAt = Date.now(); });
      break;
    case 'rate': {
      const val = Number(el.dataset.v);
      await commit((v) => { const x = byId(v, id); x.rating = x.rating === val ? 0 : val; x.updatedAt = Date.now(); });
      break;
    }
    case 'pri':
      await commit((v) => { const x = byId(v, id); x.priority = PRI_CYCLE[(PRI_CYCLE.indexOf(x.priority) + 1) % 4]; });
      break;
    case 'visit':
      commit((v) => { const x = byId(v, id); x.visits = (x.visits || 0) + 1; x.lastVisited = Date.now(); if (typeof bumpDay === 'function') bumpDay(v, 'visits'); });
      if (typeof markActive === 'function') markActive('site');
      break;
    case 'note':
      card.classList.toggle('open');
      break;
    case 'cat':
      S.filter.cat = el.dataset.v; S.filter.chip = 'all'; render(); window.scrollTo({ top: 0, behavior: 'smooth' });
      break;
    case 'tag':
      $('#search').value = el.dataset.v; S.filter.q = el.dataset.v; render();
      break;
    case 'menu':
      openActionSheet(it);
      break;
  }
}

function openActionSheet(it) {
  $('#action-head').replaceChildren(UI.avatar(it, 44), h('div', {}, h('b', { text: it.name }), h('small', { text: Core.domainOf(it.url) })));
  const act = (ic, label, run, cls = '') => h('button', { type: 'button', class: `action ${cls}`, onclick: () => { closeSheet(); run(); } }, icon(ic, { size: 20 }), label);
  $('#action-list').replaceChildren(...[
    act('edit', 'تعديل', () => openItemSheet(it)),
    act('copy', 'نسخ الرابط', () => copyText(it.url)),
    Platform.isNative ? act('share', 'مشاركة', () => shareOut(it)) : null,
    act('archive', it.status === 'archived' ? 'إلغاء الأرشفة' : 'أرشفة', () =>
      commit((v) => { const x = byId(v, it.id); x.status = x.status === 'archived' ? 'active' : 'archived'; })),
    act('trash', 'حذف', () => deleteItem(it), 'danger')].filter(Boolean));
  openSheet('#action-sheet');
}

function openSortSheet() {
  $('#sort-list').replaceChildren(...SORTS.map((s) =>
    h('button', { type: 'button', class: `action${S.sort.key === s.key ? ' selected' : ''}`, onclick: () => { S.sort = s; closeSheet(); render(); } },
      icon(S.sort.key === s.key ? 'check' : s.ic, { size: 20 }), s.label)));
  openSheet('#sort-sheet');
}

async function deleteItem(it) {
  await commit((v) => { if (typeof Trash !== 'undefined') Trash.put(v, 'site', it); v.items = v.items.filter((x) => x.id !== it.id); });
  toast(`🗑️ «${it.name || Core.domainOf(it.url)}» انتقل لسلة المحذوفات`, { action: { label: 'تراجع', run: () => Trash.undo('site', it.id) }, duration: 6000 });
}

async function copyText(text) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = h('textarea', { style: { position: 'fixed', opacity: '0' } });
    ta.value = text; document.body.append(ta); ta.select(); document.execCommand('copy'); ta.remove();
  }
  toast('تم نسخ الرابط', { type: 'success', duration: 2000 });
}

async function shareOut(it) {
  try {
    await Platform.plugin('Share').share({ title: it.name, text: it.note ? `${it.name}\n${it.note}` : it.name, url: it.url, dialogTitle: 'مشاركة الموقع' });
  } catch { /* أُلغيت */ }
}

/* ================= الأوراق السفلية ================= */
function openSheet(sel) {
  const el = $(sel);
  if (!S.sheets.includes(el)) S.sheets.push(el);
  $('#backdrop').hidden = false;
  // 1.21.15: اللي ينفتح آخر يطلع فوق دائماً (قبل كان ترتيب الـ HTML يحدد، فالتأكيد يطلع ورا بعض النوافذ)
  el.style.zIndex = '';
  const others = S.sheets.filter((s) => s !== el && !s.hidden);
  if (others.length) { const top = Math.max(...others.map((s) => Number(getComputedStyle(s).zIndex) || 50)); const own = Number(getComputedStyle(el).zIndex) || 50; if (own <= top) el.style.zIndex = String(top + 1); }
  el.hidden = false;
  el.classList.remove('closing');
}
function closeSheet(el = S.sheets[S.sheets.length - 1]) {
  if (!el) return;
  S.sheets = S.sheets.filter((s) => s !== el);
  el.classList.add('closing');
  setTimeout(() => { el.hidden = true; el.classList.remove('closing'); el.dispatchEvent(new Event('closed')); }, 190);
  if (!S.sheets.length) $('#backdrop').hidden = true;
}
function closeAllSheets(instant) {
  S.sheets.forEach((s) => { s.hidden = true; s.dispatchEvent(new Event('closed')); });
  S.sheets = [];
  $('#backdrop').hidden = true;
}

/* ================= نموذج الموقع ================= */
function setFormRating(n) {
  $('#item-form').dataset.rating = n;
  $$('#rating-input .star-btn').forEach((b) => b.classList.toggle('on', Number(b.dataset.v) <= n));
}

function openItemSheet(item = null, draft = null) {
  const form = $('#item-form');
  form.reset();
  delete form.dataset.dupAck;
  S.editingId = item?.id || null;
  const src = item || draft || {};
  const f = form.elements;
  $('#item-title').textContent = item ? `تعديل #${item.num}` : 'إضافة موقع';
  f.num.value = item ? item.num : S.vault.nextNum;
  f.name.value = src.name || '';
  f.url.value = src.url || '';
  f.note.value = src.note || '';
  f.category.value = src.category || '';
  f.status.value = src.status || 'active';
  f.favorite.checked = !!src.favorite;
  f.tags.value = (src.tags || []).join('، ');
  $$('input[name=priority]', form).forEach((r) => (r.checked = r.value === (src.priority || 'none')));
  setFormRating(src.rating || 0);
  form.dataset.favIcon = src.favIcon || '';
  $('#url-error').textContent = '';
  f.url.classList.remove('is-invalid');
  $('#save-btn').textContent = 'حفظ';
  $('#item-delete').hidden = !item;
  $('#item-meta').textContent = item ? `أُضيف ${UI.formatDate(item.createdAt)} · ${item.visits || 0} زيارة` : '';
  const cats = new Set([...S.vault.categories, ...S.vault.items.map((i) => i.category).filter(Boolean)]);
  $('#cat-list').replaceChildren(...[...cats].map((c) => h('option', { value: c })));
  checkDuplicate();
  openSheet('#item-sheet');
  $('#item-sheet').scrollTop = 0;
}

function checkDuplicate() {
  const url = Core.normalizeUrl($('#item-form').elements.url.value);
  const box = $('#dup-warning');
  const dup = url && Core.findDuplicate(S.vault, url, S.editingId);
  box.hidden = !dup;
  if (dup) box.replaceChildren(icon('alert', { size: 16 }), h('span', {}, 'محفوظ مسبقاً باسم ', h('b', { text: `«${dup.name}» #${dup.num}` })));
  return dup;
}

function bindItemForm() {
  const form = $('#item-form');
  const f = form.elements;
  f.url.addEventListener('input', () => {
    f.url.classList.remove('is-invalid');
    $('#url-error').textContent = '';
    delete form.dataset.dupAck;
    $('#save-btn').textContent = 'حفظ';
    const u = Core.normalizeUrl(f.url.value);
    f.name.placeholder = u ? Core.nameFromUrl(u) : 'مثال: بيهانس';
    checkDuplicate();
  });
  form.addEventListener('submit', (e) => { e.preventDefault(); saveItem(); });
  $('#item-delete').addEventListener('click', () => {
    const it = byId(S.vault, S.editingId);
    closeSheet();
    if (it) deleteItem(it);
  });
}

async function saveItem() {
  const form = $('#item-form');
  const f = form.elements;
  const url = Core.normalizeUrl(f.url.value);
  if (!url) {
    f.url.classList.add('is-invalid');
    $('#url-error').textContent = f.url.value.trim() ? 'الرابط غير صالح (مثال: behance.net)' : 'رابط الموقع مطلوب';
    return f.url.focus();
  }
  if (checkDuplicate() && !form.dataset.dupAck) {
    form.dataset.dupAck = '1';
    $('#save-btn').textContent = 'حفظ رغم التكرار';
    return;
  }
  const data = {
    num: f.num.value, name: f.name.value, url, note: f.note.value, category: f.category.value,
    status: f.status.value, favorite: f.favorite.checked, tags: f.tags.value,
    priority: form.querySelector('input[name=priority]:checked')?.value || 'none',
    rating: Number(form.dataset.rating) || 0, favIcon: form.dataset.favIcon,
  };
  const editingId = S.editingId;
  // حدود النسخة المجانية (من لوحة التحكم) — المواقع الموجودة لا تتأثر
  if (!editingId && typeof Pro !== 'undefined' && !Pro.gate('vault.sites', S.vault.items.length)) return;
  const res = await commit((v) => {
    if (editingId) {
      const it = byId(v, editingId);
      const clean = Core.sanitize(data);
      if (Core.urlKey(clean.url) !== Core.urlKey(it.url)) clean.favIcon = '';
      Object.assign(it, clean, { updatedAt: Date.now() });
      const n = Math.floor(Number(data.num));
      if (n >= 1 && !v.items.some((x) => x.num === n && x.id !== it.id)) it.num = n;
      v.nextNum = Math.max(v.nextNum, ...v.items.map((i) => i.num + 1));
      Core.rememberCategory(v, it.category);
      return it;
    }
    return Core.insertItem(v, data);
  });
  if (!res) return;
  closeSheet($('#item-sheet'));
  toast(editingId ? 'تم الحفظ' : `أُضيف «${res.name}» #${res.num}`, { type: 'success' });
  requestAnimationFrame(() => {
    const c = $(`.card[data-id="${CSS.escape(res.id)}"]`);
    if (c) { c.classList.add('flash'); c.scrollIntoView({ block: 'center', behavior: 'smooth' }); }
  });
}

/* ================= التأكيد ================= */
function confirmSheet({ title, text, ok = 'تأكيد', typeToConfirm = '', tone = 'danger' }) {
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  const okBtn = $('#confirm-ok');
  okBtn.className = `btn ${tone === 'primary' ? 'btn-primary' : 'btn-danger'}`;
  const input = $('#confirm-type');
  okBtn.textContent = ok;
  input.hidden = !typeToConfirm;
  input.value = '';
  input.placeholder = typeToConfirm ? `اكتب «${typeToConfirm}» للتأكيد` : '';
  okBtn.disabled = !!typeToConfirm;
  input.oninput = () => (okBtn.disabled = input.value.trim() !== typeToConfirm);
  openSheet('#confirm-sheet');
  return new Promise((resolve) => {
    let result = false;
    const sheet = $('#confirm-sheet');
    okBtn.onclick = () => { result = true; closeSheet(sheet); };
    $('#confirm-cancel').onclick = () => closeSheet(sheet);
    sheet.addEventListener('closed', () => resolve(result), { once: true });
  });
}

/* ================= الإعدادات ================= */
const PRO_THEMES = ['sunset', 'noble']; // ثيمات Pro (قبل 1.20 — الحين من لوحة التحكم ← الواجهة)
function renderThemes() {
  const TC = typeof ThemeCtl !== 'undefined' ? ThemeCtl : null;
  const eff = themeSettings();
  const cur = eff.themeId || 'midnight';
  const allow = !TC || TC.cfg().allowPick;
  const list = TC ? TC.list() : Themes.LIST;
  const locked = (id) => (TC ? !TC.usable(id) : PRO_THEMES.includes(id) && typeof Pro !== 'undefined' && !Pro.has('vault.themes'));
  $('#theme-list').hidden = !allow;
  $('#theme-locked').hidden = allow;
  $('#theme-list').replaceChildren(...list.map((t) =>
    h('button', { type: 'button', class: `theme-opt${t.id === cur ? ' on' : ''}`, onclick: () => { if (locked(t.id) && t.id !== cur && typeof Pro !== 'undefined' && !Pro.gate('vault.themes')) return; setTheme({ themeId: t.id, customColor: '' }); } },
      h('span', { class: 'theme-dot' },
        h('i', { style: { background: t.night } }),
        h('i', { style: { background: `linear-gradient(135deg, ${t.priLight}, ${t.priDeep})` } }),
        h('i', { style: { background: t.flame } })),
      t.name, locked(t.id) ? h('span', { class: 'pro-lock', text: 'Pro' }) : null)));
  // اللون المخصص
  const cm = TC ? TC.customMode() : 'pro';
  $('.custom-color').hidden = !allow || cm === 'off';
  const custom = eff.customColor;
  $('#custom-color').value = custom || Themes.LIST.find((t) => t.id === cur)?.pri || '#2E5BFF';
  $('.color-swatch span').style.setProperty('--custom', custom || 'transparent');
  $('#color-reset').hidden = !S.settings.customColor;
  // الأوضاع المسموحة
  if (TC) {
    const seg = $('#p-mode'); let n = 0;
    seg?.querySelectorAll('label').forEach((l) => { const ok = TC.modeOk(l.querySelector('input').value); l.hidden = !ok; if (ok) n++; });
    if (seg) { seg.hidden = n < 2; seg.className = `seg seg-${Math.max(2, n)}`; if (seg.previousElementSibling) seg.previousElementSibling.hidden = n < 2; const m = eff.mode; seg.querySelectorAll('input').forEach((i) => { i.checked = i.value === m; }); }
  }
}

async function setTheme(patch) {
  S.settings = await Core.setSettings(patch);
  Themes.apply(themeSettings());
  renderThemes();
}

function openSettings() {
  renderThemes();
  renderAccount();
  renderPrefs();
  $('#autolock').value = String(S.settings.autoLockMin);
  $('#pw-form').reset();
  $('#pw-error').textContent = '';
  openSheet('#settings-sheet');
}

function bindSettings() {
  let colorTimer;
  $('#custom-color').addEventListener('click', (e) => { const ok = typeof ThemeCtl !== 'undefined' ? ThemeCtl.customOk() : typeof Pro === 'undefined' || Pro.has('vault.themes'); if (!ok) { e.preventDefault(); if (typeof Pro !== 'undefined') Pro.gate('vault.themes'); } });
  $('#custom-color').addEventListener('input', (e) => {
    const c = e.target.value.toUpperCase();
    Themes.apply({ ...themeSettings(), customColor: c }); // معاينة فورية
    $('.color-swatch span').style.setProperty('--custom', c);
    clearTimeout(colorTimer);
    colorTimer = setTimeout(() => setTheme({ customColor: c }), 250);
  });
  $('#color-reset').addEventListener('click', () => setTheme({ customColor: '' }));

  $('#autolock').addEventListener('change', async (e) => {
    S.settings = await Core.setSettings({ autoLockMin: Number(e.target.value) });
    await Core.touch();
    toast('تم الحفظ', { type: 'success', duration: 1500 });
  });
  $('#pw-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const o = $('#pw-old').value, n1 = $('#pw-new').value, n2 = $('#pw-new2').value;
    const err = $('#pw-error');
    if (!o) return (err.textContent = 'أدخل كلمة المرور الحالية');
    if (n1.length < 6) return (err.textContent = 'الجديدة ٦ أحرف على الأقل');
    if (n1 !== n2) return (err.textContent = 'غير متطابقتين');
    const res = await Core.changePassword(o, n1);
    if (!res.ok) return (err.textContent = res.error);
    const hadBio = !!S.settings.biometric;
    if (Cloud.enabled && (await Cloud.user())) {
      try {
        await Cloud.updatePassword(n1);
        await pushNow();
      } catch (ex) {
        await Core.changePassword(n1, o); // تراجع حتى تبقى كلمة المرور متطابقة
        return (err.textContent = 'تعذّر التحديث: ' + Cloud.msg(ex));
      }
    }
    err.textContent = '';
    $('#pw-form').reset();
    toast('تم تغيير كلمة المرور', { type: 'success' });
    if (hadBio) await Bio.refresh(n1);
    if (typeof Keys !== 'undefined') Keys.sync();
  });
  $('#export-json').addEventListener('click', exportJSON);
  $('#export-csv').addEventListener('click', exportCSV);
  $('#import-btn').addEventListener('click', () => $('#import-file').click());
  $('#import-file').addEventListener('change', async (e) => {
    const file = e.target.files[0];
    e.target.value = '';
    if (file) await importFile(file);
  });
  $('#reset-btn').addEventListener('click', async () => {
    closeSheet();
    const ok = await confirmSheet({ title: 'حذف كل البيانات؟', text: `سيُحذف ${S.vault.items.length} موقع وكلمة المرور نهائياً.`, ok: 'حذف نهائي', typeToConfirm: 'حذف' });
    if (!ok) return;
    await Bio.off();
    await Core.reset();
    location.reload();
  });
}

/* ================= تصدير / استيراد ================= */
const stamp = () => new Date().toISOString().slice(0, 10);

async function saveFile(name, content, mime) {
  if (Platform.isNative) {
    // اكتب في ذاكرة التطبيق المؤقتة ثم افتح قائمة المشاركة (حفظ في Drive، واتساب، الملفات…)
    const fs = Platform.plugin('Filesystem');
    const res = await fs.writeFile({ path: name, data: content, directory: 'CACHE', encoding: 'utf8' });
    await Platform.plugin('Share').share({ title: name, url: res.uri, dialogTitle: 'حفظ النسخة الاحتياطية' });
    return;
  }
  const a = h('a', { href: URL.createObjectURL(new Blob([content], { type: mime })), download: name });
  document.body.append(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

async function exportJSON() {
  const data = { app: 'noble-web', version: 1, exportedAt: new Date().toISOString(), categories: S.vault.categories, items: S.vault.items };
  try { await saveFile(`noble-web-${stamp()}.json`, JSON.stringify(data, null, 2), 'application/json'); }
  catch (e) { toast('تعذّر التصدير: ' + e.message, { type: 'error' }); }
}

const CSV_COLS = [['num', 'الرقم'], ['name', 'اسم الموقع'], ['url', 'رابط الموقع'], ['note', 'ملاحظة'], ['rating', 'التقييم'], ['priority', 'الأولوية'], ['category', 'التصنيف'], ['tags', 'الوسوم'], ['status', 'الحالة'], ['favorite', 'مفضلة']];
function csvCell(v) {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return /[",\n\r]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}
async function exportCSV() {
  const rows = [CSV_COLS.map((c) => c[1])];
  [...S.vault.items].sort((a, b) => a.num - b.num).forEach((it) => rows.push(CSV_COLS.map(([k]) =>
    k === 'priority' ? PRI[it.priority].label : k === 'status' ? STATUS[it.status] : k === 'favorite' ? (it.favorite ? 'نعم' : '') : k === 'tags' ? (it.tags || []).join('، ') : it[k])));
  try { await saveFile(`noble-web-${stamp()}.csv`, '﻿' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n'), 'text/csv'); }
  catch (e) { toast('تعذّر التصدير: ' + e.message, { type: 'error' }); }
}

function parseCSV(text) {
  text = text.replace(/^﻿/, '');
  const rows = []; let row = [], cell = '', q = false;
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    if (q) { if (c === '"' && text[i + 1] === '"') { cell += '"'; i++; } else if (c === '"') q = false; else cell += c; }
    else if (c === '"') q = true;
    else if (c === ',' || c === ';' || c === '\t') { row.push(cell); cell = ''; }
    else if (c === '\n' || c === '\r') { if (c === '\r' && text[i + 1] === '\n') i++; row.push(cell); rows.push(row); row = []; cell = ''; }
    else cell += c;
  }
  if (cell || row.length) { row.push(cell); rows.push(row); }
  return rows.filter((r) => r.some((c) => c.trim()));
}
const HEADERS = {
  num: ['الرقم', 'رقم', '#', 'num'], name: ['اسم الموقع', 'الاسم', 'name', 'title'], url: ['رابط الموقع', 'الرابط', 'رابط', 'url', 'link'],
  note: ['ملاحظة', 'ملاحظات', 'note', 'notes'], rating: ['التقييم', 'rating'], priority: ['الأولوية', 'priority'],
  category: ['التصنيف', 'category'], tags: ['الوسوم', 'tags'], status: ['الحالة', 'status'], favorite: ['مفضلة', 'favorite'],
};
const PRI_FROM = { 'عالية': 'high', 'متوسطة': 'medium', 'منخفضة': 'low', high: 'high', medium: 'medium', low: 'low' };
const STATUS_FROM = { 'نشط': 'active', 'للمراجعة': 'review', 'مؤرشف': 'archived', active: 'active', review: 'review', archived: 'archived' };
function rowsToItems(rows) {
  const head = rows[0].map((c) => UI.normAr(c.trim()));
  const idx = {};
  for (const [k, names] of Object.entries(HEADERS)) {
    const i = head.findIndex((x) => names.some((n) => UI.normAr(n) === x));
    if (i >= 0) idx[k] = i;
  }
  let body = rows.slice(1);
  if (idx.url == null) { Object.assign(idx, { num: 0, name: 1, url: 2, note: 3 }); body = rows; }
  return body.map((r) => {
    const g = (k) => (idx[k] != null ? (r[idx[k]] || '').trim().replace(/^'(?=[=+\-@])/, '') : '');
    return { num: g('num'), name: g('name'), url: g('url'), note: g('note'), rating: g('rating'),
      priority: PRI_FROM[g('priority').toLowerCase()] || 'none', category: g('category'), tags: g('tags'),
      status: STATUS_FROM[g('status').toLowerCase()] || 'active', favorite: /^(نعم|yes|true|1)$/i.test(g('favorite')) };
  });
}
async function importFile(file) {
  let incoming;
  try {
    const text = await file.text();
    if (/^\s*[[{]/.test(text)) {
      const d = JSON.parse(text);
      incoming = Array.isArray(d) ? d : d.items;
      if (!Array.isArray(incoming)) throw new Error('صيغة غير معروفة');
    } else incoming = rowsToItems(parseCSV(text));
  } catch (e) {
    return toast('تعذّرت قراءة الملف: ' + e.message, { type: 'error' });
  }
  let added = 0, dup = 0, bad = 0;
  await commit((v) => {
    for (const raw of incoming) {
      const url = Core.normalizeUrl(raw?.url);
      if (!url) { bad++; continue; }
      if (Core.findDuplicate(v, url)) { dup++; continue; }
      Core.insertItem(v, { ...raw, url }); added++;
    }
  });
  closeSheet();
  toast([`استيراد ${added}`, dup && `${dup} مكرر`, bad && `${bad} غير صالح`].filter(Boolean).join(' · '), { type: added ? 'success' : 'info', duration: 5000 });
}

/* ================= أندرويد: زر الرجوع + استقبال المشاركة ================= */
function bindNative() {
  if (!Platform.isNative) return;
  const App = Platform.plugin('App');
  App.addListener('backButton', () => {
    if (navBack()) { exitArmed = 0; return; }
    // في الصفحة الرئيسية: ضغطتين للخروج حتى ما تطلع بالغلط
    if (Date.now() - exitArmed < 2200) { exitArmed = 0; App.minimizeApp(); return; }
    exitArmed = Date.now();
    toast('اضغط رجوع مرة ثانية للخروج', { duration: 2000 });
  });
  const SR = Platform.plugin('ShareReceiver');
  SR.addListener('shared', () => { if (S.unlocked) consumeShared(); });
}

/* يستخرج أول رابط من النص المُشارَك من تطبيق آخر */
function draftFromShared({ text = '', subject = '' }) {
  const m = String(text).match(/https?:\/\/[^\s<>"']+/i);
  if (!m) return null;
  const url = m[0].replace(/[).,،]+$/, '');
  const rest = String(text).replace(m[0], '').trim();
  return { url, name: (subject || rest.split('\n')[0] || '').trim().slice(0, 200), note: rest && rest !== subject ? '' : '' };
}

async function consumeShared() {
  if (!Platform.isNative) return;
  try {
    const data = await Platform.plugin('ShareReceiver').getShared();
    if (!data || !data.text) return;
    const draft = draftFromShared(data);
    if (draft) openItemSheet(null, draft);
    else toast('لم أجد رابطاً في المحتوى المُشارَك', { type: 'error' });
  } catch (e) { /* لا شيء */ }
}


/* ================= الحساب السحابي ================= */
let cloudMode = 'signin';
function setCloudMode(mode) {
  cloudMode = mode;
  const up = mode === 'signup';
  $$('.auth-tabs button').forEach((b) => b.classList.toggle('on', b.dataset.mode === mode));
  $('#c-name').hidden = !up;
  $('#c-pw2').hidden = !up;
  $('#c-note').hidden = !up;
  $('#c-forgot').hidden = up;
  $('#c-pw').autocomplete = up ? 'new-password' : 'current-password';
  $('#c-submit').firstChild.textContent = up ? 'إنشاء الحساب ' : 'دخول ';
  $('#c-error').textContent = '';
  $('#c-ok').textContent = '';
  if (typeof paintSavedAccounts === 'function') paintSavedAccounts();
}

function bindCloudAuth() {
  $$('.auth-tabs button').forEach((b) => b.addEventListener('click', () => setCloudMode(b.dataset.mode)));
  $('#c-forgot').addEventListener('click', forgotCloud);
  $('#signout-btn').addEventListener('click', signOutAll);
  $('#cloud-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const email = $('#c-email').value.trim(), pw = $('#c-pw').value, err = $('#c-error');
    const remember = $('#c-remember').checked;
    err.textContent = ''; $('#c-ok').textContent = '';
    if (!/^\S+@\S+\.\S+$/.test(email)) return (err.textContent = 'أدخل بريداً إلكترونياً صحيحاً');
    if (pw.length < 6) return (err.textContent = 'كلمة المرور ٦ أحرف على الأقل');
    const btn = $('#c-submit');
    btn.disabled = true;
    try {
      if (cloudMode === 'signup') {
        if (pw !== $('#c-pw2').value) throw new Error('كلمتا المرور غير متطابقتين');
        const res = await Cloud.signUp(email, pw, $('#c-name').value.trim());
        if (res.needsConfirm) {
          setCloudMode('signin');
          $('#c-email').value = email;
          $('#c-ok').textContent = 'أرسلنا رابط تأكيد إلى بريدك — أكّده ثم سجّل الدخول.';
          return;
        }
        await openCloudVault(pw, res.user, null, true);
        afterSignedIn(email, pw, { display_name: $('#c-name').value.trim() }, remember, false);
      } else {
        await cloudSignIn(email, pw, { remember });
      }
      $('#c-pw').value = ''; $('#c-pw2').value = '';
    } catch (ex) {
      err.textContent = Cloud.msg(ex);
    } finally {
      btn.disabled = false;
    }
  });
}

/* يفتح الخزنة بعد تسجيل الدخول: يأخذ نسخة السحابة إن كانت أحدث، أو ينشئ خزنة جديدة */
async function openCloudVault(pw, user, remote, fresh = false) {
  const { meta } = await browser.storage.local.get('meta');
  const localIsMine = (await Core.isSetup()) && meta?.owner === user.id;
  const localIsLegacy = (await Core.isSetup()) && !meta?.owner; // بيانات محلية قبل تفعيل الحسابات

  if (remote && !fresh) {
    if (!localIsMine || (remote.savedAt || 0) > (meta?.savedAt || 0)) await Cloud.adoptRemote(remote);
    const res = await Core.unlock(pw);
    if (!res.ok) throw new Error(res.wait ? 'محاولات كثيرة — انتظر قليلاً' : 'تعذّر فك تشفير بياناتك بهذه الكلمة. إن غيّرتها مؤخراً من جهاز آخر فاستخدم كلمة المرور الأحدث.');
  } else if ((localIsMine || localIsLegacy) && (await Core.unlock(pw)).ok) {
    /* نرفع البيانات المحلية الموجودة إلى الحساب */
  } else {
    await Core.setup(pw);
  }
  await browser.storage.local.set({ meta: await Core.metaWith({ owner: user.id, project: Cloud.REF, email: Acc.norm(user.email) }) });
  await pushNow();
  await enterApp();
}

/* ================= استئناف جلسة السحابة بصمت =================
 * إذا انتهت جلسة Supabase (أو حُذفت) نعيد الدخول بنفس كلمة المرور التي فُتحت بها الخزنة،
 * فلا يطلب التطبيق الإيميل من جديد. كلمة المرور تبقى في الذاكرة فقط حتى تنجح الاستعادة. */
const Resume = { pw: '', busy: false, warned: false };
async function resumeSession({ ask = false } = {}) {
  if (!Cloud.enabled) return false;
  if (await Cloud.user()) { Resume.pw = ''; return true; }
  if (Resume.busy) return false;
  const { meta } = await browser.storage.local.get('meta');
  const email = meta?.email || (() => { try { return localStorage.getItem('nw:last-email') || ''; } catch { return ''; } })();
  // 1.20: اللي بدون حساب: الجلسة الخفية ضاعت ← نفتح وحدة جديدة بهدوء وبياناته المحلية ترتفع لها
  if (!email && meta?.anon && navigator.onLine !== false) {
    if (Resume.busy) return false;
    Resume.busy = true;
    try {
      const nu = await Cloud.signInAnon();
      if (!nu) return false;
      await browser.storage.local.set({ meta: await Core.metaWith({ ...meta, owner: nu.id, anon: true }) });
      Sync.init(nu.id); Pro.init(nu.id);
      Resume.warned = false;
      return true;
    } catch { return false; } finally { Resume.busy = false; }
  }
  if (!email) return false;
  let pw = Resume.pw;
  if (!pw && ask) {
    pw = await askPassword({ title: 'استئناف المزامنة', text: `أدخل كلمة مرور حسابك ${email} لإعادة ربط الجهاز بالسحابة.`, verifyWith: (p) => Core.verify(p) });
    if (!pw) return false;
  }
  if (!pw) return false;
  Resume.busy = true;
  try {
    const u = await Cloud.signIn(email, pw);
    if (meta?.owner && u.id !== meta.owner) { await Cloud.signOut(); return false; }
    Resume.pw = ''; Resume.warned = false;
    return true;
  } catch (e) {
    const m = Cloud.msg(e);
    if (/غير صحيحة/.test(m)) {
      Resume.pw = '';
      if (!Resume.warned) {
        Resume.warned = true;
        toast('تغيّرت كلمة مرور حسابك من جهاز آخر — سجّل الدخول بالجديدة لاستئناف المزامنة', { type: 'error', duration: 9000, action: { label: 'دخول', run: async () => { await Core.lock(); showAuth('cloud', email); } } });
      }
    }
    return false;
  } finally { Resume.busy = false; }
}
/* انقطاع النت: نبيّن الحالة فوراً — ورجوعه: مزامنة كاملة وتحديث القسم المفتوح */
window.addEventListener('offline', () => { if (typeof Sync !== 'undefined') Sync.markOffline(); if (S.unlocked && Cloud.enabled) setSync('off'); });
let onlineTimer = 0;
window.addEventListener('online', () => {
  clearTimeout(onlineTimer);
  onlineTimer = setTimeout(async () => {
    if (!S.unlocked || !Cloud.enabled) return;
    await afterCloudEnter();
    if (S.tab === 'news' && typeof loadNews === 'function') loadNews({ force: true });
    if (S.tab === 'today' && typeof renderToday === 'function') renderToday();
  }, 800);
});

let autoBusy = false, autoAt = 0;
async function autoSync(force = false) {
  if (!S.unlocked || !Cloud.enabled || autoBusy || navigator.onLine === false) return;
  if (!force && Date.now() - autoAt < 15000) return; // ما نكرر خلال ١٥ ثانية
  autoBusy = true; autoAt = Date.now();
  try { await afterCloudEnter(); } finally { autoBusy = false; }
}
async function afterCloudEnter() {
  autoAt = Date.now();
  setSync('busy');
  if (!(await Cloud.user()) && !(await resumeSession())) {
    setSync('off');
    if (!Sync.online()) Sync.markOffline();
    if (navigator.onLine !== false && !Resume.warned && !Resume.pw) {
      Resume.warned = true;
      toast('المزامنة متوقفة — بياناتك محفوظة على الجهاز', { duration: 8000, action: { label: 'استئناف', run: async () => { Resume.warned = false; if (await resumeSession({ ask: true })) afterCloudEnter(); } } });
    }
    return;
  }
  try {
    if ((await syncVault()) === 'pw') {
      // تغيّرت كلمة المرور من جهاز آخر
      await Cloud.adoptRemote(await Cloud.pullVault());
      await Core.lock();
      return lockedOut('تغيّرت كلمة المرور من جهاز آخر — أدخل الجديدة');
    }
    const prof = await Cloud.touch(S.vault.items.length);
    if (prof?.status === 'suspended') return suspendedOut();
    S.profile = prof || (await Cloud.profile());
    setSync('ok');
    if (typeof PushNotes !== 'undefined') PushNotes.sync(true); if (typeof Usage !== 'undefined') Usage.push();
    if (typeof FCM !== 'undefined') setTimeout(() => FCM.start(), 2500); // 1.21.8: إشعارات فورية (Firebase)
    renderTabbar();
    loadInbox();
    loadNotices();
    if (!S.liveOn) { S.liveOn = true; startLive(); }
    Sync.flush({ stats: true });
    Pro.refresh();
    if (typeof Keys !== 'undefined') Keys.sync();
  } catch (e) {
    setSync('off');
    Sync.markOffline();
  }
}

let pushTimer;
function schedulePush() {
  if (!Cloud.enabled) return;
  clearTimeout(pushTimer);
  setSync('busy');
  pushTimer = setTimeout(pushNow, 900);
}
async function pushNow() {
  if (!Cloud.enabled || !(await Cloud.user())) return;
  try {
    if ((await syncVault()) === 'pw') return afterCloudEnter();
    const prof = await Cloud.touch(S.vault?.items.length ?? 0);
    if (prof?.status === 'suspended') return suspendedOut();
    if (prof) S.profile = prof;
    setSync('ok');
  } catch {
    setSync('off');
  }
}

function setSync(state) {
  S.sync = state;
  if (!S.unlocked) return;
  const pend = typeof Sync !== 'undefined' ? Sync.count() : 0;
  const label = { ok: 'متزامن', busy: 'جارٍ المزامنة…', off: pend ? `بدون نت · ${UI.n(pend)} معلّق` : 'بدون نت · محفوظ' }[state];
  const total = visibleTabs().includes('sites') ? S.vault?.items.length || 0 : 0;
  // 1.21.1: «متزامن» ما يطلع — النقطة الخضراء تكفي (تبين الحالة لو ضغطت عليها). «بدون نت» يبقى ظاهر لأنه مهم
  $('#brand-sub').replaceChildren(h('i', { class: `sync-dot ${state}`, title: label, 'aria-label': label }), state === 'off' ? label : (total ? UI.n(total) + ' موقع' : appTagline()));
}

async function suspendedOut() {
  const u = await Cloud.user();
  if (u?.email) await Acc.forget(u.email);
  await signOutAll(true);
  toast('تم إيقاف هذا الحساب — تواصل مع الإدارة', { type: 'error', duration: 6000 });
}

/* 👤 1.21.18: أيقونة الحساب فوق (للضيف): تظهر بس لو داخل كضيف */
async function paintAcctBtn() {
  const b = $('#acct-btn'); if (!b) return;
  let anon = false;
  try { anon = !!(await browser.storage.local.get('meta')).meta?.anon; } catch { /* لا شيء */ }
  b.hidden = !(anon && Cloud.enabled && S.unlocked);
  const d = $('#acct-dot'); if (d) { let seen = false; try { seen = localStorage.getItem('nw:acct-seen') === '1'; } catch { /* لا شيء */ } d.hidden = seen; }
}
function openAcctSheet() {
  try { localStorage.setItem('nw:acct-seen', '1'); } catch { /* لا شيء */ }
  $('#acct-dot') && ($('#acct-dot').hidden = true);
  const opt = (ic, t, sub, fn, cls) => h('button', { type: 'button', class: 'acct-opt ' + (cls || ''), onclick: () => { closeSheet(); setTimeout(fn, 60); } },
    h('span', { class: 'acct-ic', text: ic }), h('span', { class: 'acct-tx' }, h('b', { text: t }), h('small', { text: sub })));
  uiSheet('acct-sheet', '👤 حسابك', [
    h('p', { class: 'acct-note', text: 'أنت داخل كضيف — بياناتك محفوظة على هالجوال بس.' }),
    typeof LinkAcc !== 'undefined' ? opt('🔗', 'احفظ حسابك بإيميل', 'عشان ما تضيع بياناتك لو غيّرت جوالك أو حذفت التطبيق', () => LinkAcc.open(), 'pri') : null,
    opt('🔑', 'عندي حساب — سجّل دخول', 'ادخل بإيميلك وكلمة مرورك', () => $('#login-acc')?.click()),
  ]);
}

async function signOutAll(silent) {
  clearTimeout(pushTimer);
  // لا نطلب البصمة تلقائياً بعد خروج متعمّد (حتى لو أُعيد تحميل الصفحة)
  AccUI.autoTried = true;
  try { sessionStorage.setItem('nw:no-auto', '1'); } catch { /* لا شيء */ }
  const meta0 = (await browser.storage.local.get('meta')).meta;
  const who = (await Cloud.user())?.email || meta0?.email;
  if (meta0 && !meta0.anon && typeof Store !== 'undefined') Store.setWantLogin(true); // 1.21.17: ما يرجّعه ضيف تلقائياً
  await Core.lock();
  // الحساب المحفوظ ببصمة يبقى جاهزاً للدخول بلمسة بعد الخروج
  if (!(who && Acc.get(who)?.bio)) await Bio.off();
  S.perms = null; S.profile = null; S.entered = false; S.liveOn = false;
  Cloud.stopLive();
  await Cloud.signOut();
  await browser.storage.local.remove(['auth', 'vault', 'meta', 'attempts']); // نسخة الجهاز تُحذف؛ الأصل في حسابك
  S.unlocked = false;
  showAuth('cloud', who);
  if (silent !== true) toast('تم تسجيل الخروج');
}


/* ================= 🏪 وضع المتجر: دخول تلقائي بدون حساب ظاهر ================= */
/* أول تشغيل بدون إعداد محفوظ: ننتظر إعداد السيرفر شوي (عشان نعرف هل الدخول مخفي) */
/* 📴 أول تشغيل بدون نت: ابدأ على الجهاز بحساب ضيف، ويرتبط بالسحابة لما يرجع النت (1.19) */
async function offStartPaint() {
  const box = $('#c-offline'); if (!box) return;
  box.hidden = navigator.onLine !== false || (await Core.isSetup());
  if (!offStartPaint.bound) {
    offStartPaint.bound = true;
    $('#c-offline-go')?.addEventListener('click', () => storeAutoEnter(null));
    ['online', 'offline'].forEach((ev) => window.addEventListener(ev, () => { if (!$('#cloud-form').hidden) offStartPaint(); }));
  }
}
async function storeConfigReady() {
  let has = false;
  try { has = !!localStorage.getItem('nw:content'); } catch { /* لا شيء */ }
  if (has || !navigator.onLine) return;
  await Promise.race([loadRemoteContent(), new Promise((r) => setTimeout(r, 4500))]);
}
async function storeAutoEnter(u) {
  const key = Store.deviceKey();
  try { if (!u) u = await Cloud.signInAnon(); } catch (e) { console.warn('anon', e); u = null; }
  try {
    if (await Core.isSetup()) {
      // بيانات موجودة على الجهاز بكلمة مرور قديمة: ما نمسحها — يدخل بحسابه
      if (!(await Core.unlock(key)).ok) return showAuth((await browser.storage.local.get('meta')).meta?.owner ? 'login' : 'cloud');
    } else await Core.setup(key);
    await browser.storage.local.set({ meta: await Core.metaWith({ owner: u?.id || '', project: Cloud.REF, email: '', anon: true }) });
    if (u) await pushNow().catch(() => {});
    return enterApp();
  } catch (e) {
    console.warn('store enter', e);
    return showAuth('cloud');
  }
}
async function storeUnlock(u, meta) {
  const key = Store.deviceKey(false);
  if (!(await Core.isUnlocked())) {
    const r = key ? await Core.unlock(key) : { ok: false };
    if (!r.ok) return showAuth('cloud');
  }
  // الجلسة الخفية ضاعت (أو أول مرة بدون نت): حساب خفي جديد، والبيانات المحلية ترتفع له
  if (!u && navigator.onLine) {
    try { const nu = await Cloud.signInAnon(); if (nu) await browser.storage.local.set({ meta: await Core.metaWith({ ...meta, owner: nu.id, anon: true }) }); } catch { /* نكمل محلي */ }
  }
  return enterApp();
}
/* حذف حسابي وكل بياناتي (Google Play يشترطه) */
async function deleteMyAccount() {
  closeSheet();
  const ok = await confirmSheet({ title: 'حذف حسابي وبياناتي', text: 'ينحذف حسابك وكل بياناتك نهائياً، وما يمديك تتراجع بعدها.', ok: 'حذف نهائي', typeToConfirm: 'حذف' });
  if (!ok) return;
  try {
    await Cloud.deleteMe();
    try { localStorage.removeItem('nw:dk'); } catch { /* لا شيء */ }
    await Core.lock().catch(() => {});
    await browser.storage.local.remove(['auth', 'vault', 'meta', 'attempts', 'vault_backup']);
    S.perms = null; S.profile = null; S.entered = false; S.unlocked = false;
    toast('انحذف حسابك وبياناتك ✓', { type: 'success' });
    route();
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

/* «نسيت كلمة المرور» للحساب السحابي: في recovery.js */

function renderAccount() {
  const card = $('#account-card');
  card.hidden = !Cloud.enabled;
  if (!Cloud.enabled) return;
  Cloud.user().then(async (u) => {
    if (!u) return (card.hidden = true);
    const p = S.profile || (await Cloud.soon(Cloud.profile(), 5000).catch(() => null)) || {}; // 1.21.17: بدون نت ما يعلّق الكرت
    const anon = !u.email;
    const name = p.display_name || (u.email || '').split('@')[0] || 'ضيف NOBLE';
    $('#acc-av').textContent = name.charAt(0).toUpperCase();
    $('#acc-name').textContent = name;
    $('#profile-btn').textContent = anon ? '👤 اسمك' : 'تعديل الملف';
    { const lb = $('#link-acc'); if (lb) lb.hidden = !anon || typeof LinkAcc === 'undefined'; }
    { const la = $('#login-acc'); if (la) la.hidden = !anon; }
    $('#acc-email').textContent = anon ? 'بدون حساب — بياناتك على هالجهاز ومحفوظة في السحابة' : u.email;
    const perm = S.perms || (S.perms = await Cloud.permissions());
    const staff = (perm.perms || []).length > 0;
    $('#acc-role').hidden = !staff;
    $('#acc-role').textContent = ROLE_LABEL[perm.role] || 'فريق';
    $('#admin-link').hidden = !staff;
    // 1.21.26: 📝 مسودات «عاجل» تنتظر مراجعتك — شارة على زر لوحة الإدارة
    if ((perm.perms || []).includes('news.manage')) Cloud.soon(Cloud.admin.aiList(), 6000).then((r) => { const n = (r?.items || []).filter((x) => x.status !== 'published').length, b = $('#admin-link'); if (!b) return; b.querySelector('.adm-dr')?.remove(); if (n) { b.href = 'admin.html#ainews'; b.append(h('em', { class: 'adm-dr', text: ` 📝${UI.n(n)}` })); } else b.href = 'admin.html'; }).catch(() => {});
    browser.storage.local.get('vault_backup').then(({ vault_backup }) => { $('#restore-old').hidden = !vault_backup; });
    Upgrade.card();
    $('#acc-sync').textContent = S.sync === 'off' ? 'غير متصل — التعديلات محفوظة على الجهاز وستُرفع لاحقاً' : 'بياناتك مشفّرة وتتزامن تلقائياً كل ما تفتح التطبيق';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  $('#logout-btn').addEventListener('click', async () => {
    closeSheet();
    const ok = await confirmSheet({ title: 'تسجيل الخروج؟', text: 'تُحذف نسخة الجهاز، وتبقى مواقعك محفوظة ومشفّرة في حسابك.', ok: 'خروج' });
    if (ok) { await pushNow(); if (typeof FCM !== 'undefined') await FCM.stop(); await signOutAll(); }
  });
  $('#restore-old').addEventListener('click', () => { closeSheet(); restoreOldBackup(); });
  $('#delete-me')?.addEventListener('click', deleteMyAccount);
  $('#link-acc')?.addEventListener('click', () => { closeSheet(); LinkAcc.open(); });
  // 🔑 1.21.17: ضيف عنده حساب بإيميل (مثلاً غيّر جواله أو حذف التطبيق) → شاشة الدخول
  $('#login-acc')?.addEventListener('click', async () => {
    closeSheet();
    const ok = await confirmSheet({ title: '🔑 الدخول بحسابك', text: 'بتطلع من وضع الضيف وتسجّل دخول بإيميلك وكلمة مرورك.\n\nانتبه: بيانات الضيف على هالجوال بتنمسح — لو تبيها، احفظها أول بـ «🔗 احفظ حسابك بإيميل».', ok: 'كمّل للدخول', tone: 'primary' });
    if (!ok) return;
    Store.setWantLogin(true);
    await signOutAll(true);
  });
  $('#c-guest')?.addEventListener('click', () => { Store.setWantLogin(false); route(); });
  $('#sync-now').addEventListener('click', async () => { await afterCloudEnter(); renderAccount(); toast(S.sync === 'ok' ? 'تمت المزامنة' : 'تعذّر الاتصال', { type: S.sync === 'ok' ? 'success' : 'error' }); });
  // 1.20: المزامنة تلقائية — كل ما ينفتح التطبيق أو يرجع من الخلفية أو يرجع النت، وكل ٥ دقائق وهو مفتوح
  document.addEventListener('visibilitychange', () => { if (!document.hidden) autoSync(); });
  // 🤍 الذكر: الرجوع للتطبيق بعد ١٠ دقائق أو أكثر يُحسب فتح جديد
  let azAway = 0;
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { azAway = Date.now(); return; }
    if (azAway && Date.now() - azAway > 10 * 60000 && typeof azkarToastWhenClear === 'function') setTimeout(() => azkarToastWhenClear(), 1200);
    azAway = 0;
  });
  window.addEventListener('online', () => setTimeout(autoSync, 1500));
  setInterval(() => { if (!document.hidden) autoSync(); }, 5 * 60000);
});


/* ================= محتوى التطبيق (من لوحة الأدمن) ================= */
function themeSettings() {
  // الثيم الافتراضي من الأدمن يُطبَّق فقط إن لم يختر المستخدم ثيماً بنفسه
  const s = { ...S.settings };
  if (typeof ThemeCtl !== 'undefined') return ThemeCtl.resolve({ ...s, mode: s.mode || pref('mode') }); // 1.20: قواعد المالك
  if (!s.themeId && !s.customColor) { s.themeId = Content.get('defaultTheme'); s.customColor = Content.get('defaultColor'); }
  return s;
}

function applyContent() {
  if (typeof Store !== 'undefined') Store.apply();
  Themes.apply(themeSettings());
  renderTabbar();
  $$('[data-cfg]').forEach((el) => (el.textContent = Content.get(el.dataset.cfg)));
  $$('[data-ex]').forEach((el) => (el.placeholder = Content.get(el.dataset.ex)));
  Brand.apply();
  if (typeof FontKit !== 'undefined') { FontKit.apply(); if (typeof UI !== 'undefined' && typeof pref === 'function') UI.setFormat({ nu: FontKit.digits(pref('digits')) }); const lk = FontKit.digitsLocked(); document.querySelectorAll('[data-digits-row]').forEach((x) => (x.hidden = lk)); }

  // الإعلان
  const box = $('#announce');
  const text = Content.get('announceText');
  const dismissed = (() => { try { return localStorage.getItem('nw:announce-hide') === text; } catch { return false; } })();
  box.hidden = !(Content.get('announceOn') && text && !dismissed);
  if (!box.hidden) {
    const link = Content.get('announceLink');
    box.replaceChildren(icon('info', { size: 18 }),
      h('div', { style: { flex: '1' } }, ...Links.linkify(text), link ? h('div', { class: 'an-link' }, Links.button(link, Links.isUpdate(link) ? '' : 'التفاصيل', { block: false, small: true, hint: false })) : null),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إخفاء', style: { width: '32px', height: '32px' }, onclick: () => { try { localStorage.setItem('nw:announce-hide', text); } catch {} box.hidden = true; } }, icon('x', { size: 16 })));
  }

  // روابط التواصل
  const links = [['website', 'الموقع', 'external'], ['instagram', 'إنستغرام', 'external'], ['whatsapp', 'واتساب', 'external']]
    .map(([k, label, ic]) => [Content.get(k), label, ic]).filter(([u]) => u);
  $('#links-card').hidden = !links.length;
  $('#links-list').replaceChildren(...links.map(([u, label, ic]) => {
    const href = /^https?:/i.test(u) ? u : u.startsWith('@') ? 'https://instagram.com/' + u.slice(1) : /^\+?\d[\d\s]+$/.test(u) ? 'https://wa.me/' + u.replace(/\D/g, '') : 'https://' + u;
    return h('a', { class: 'btn', href, target: '_blank', rel: 'noopener noreferrer' }, icon(ic, { size: 16 }), label);
  }));
  $('#about-ver').textContent = `${Brand.name()} · الإصدار ${Cloud.VERSION}`;

  // إشعار التحديث الإجباري
  const minV = Market.appCfg().minVersion || Content.get('minVersion');
  if (minV && Content.older(Cloud.VERSION, minV)) showUpdateGate();
  else $('#update-gate')?.remove();
}

function showUpdateGate() {
  $('#update-gate')?.remove();
  const url = Market.appCfg().updateUrl || Content.get('updateUrl');
  document.body.append(h('div', { id: 'update-gate', class: 'update-gate' },
    h('img', { src: (typeof Brand !== 'undefined' ? Brand.logo() : 'img/mark.png'), alt: '' }),
    h('h2', { text: 'تحديث مطلوب' }),
    h('p', {}, ...Links.linkify(Content.get('updateText'))),
    url ? Links.button(url, 'اضغط هنا للتحديث') : null,
    h('small', { text: `إصدارك الحالي ${Cloud.VERSION} · المطلوب ${Market.appCfg().minVersion || Content.get('minVersion')}` })));
}

async function loadRemoteContent() {
  if (!Cloud.enabled) return;
  try {
    const data = await Cloud.getConfig();
    if (data) {
      if ('_games' in data) GCfg.set(data._games || {});
      if ('_market' in data) { Market.set(data._market || {}); try { Themes.apply(themeSettings()); } catch { /* لا شيء */ } try { if (typeof LoginUI !== 'undefined') LoginUI.apply(); if (typeof Voice !== 'undefined') Voice.refresh(); } catch { /* لا شيء */ } if (typeof Ads !== 'undefined') Ads.refresh(); if (typeof proButton === 'function') proButton(); if (S.unlocked && typeof renderTabbar === 'function') renderTabbar(); }
      delete data._games; delete data._market;
      Content.set(data); applyContent(); if (S.unlocked) render();
      if (typeof Store !== 'undefined') { Store.apply(); if (S.unlocked && typeof renderTabbar === 'function') { renderTabbar(); if (!visibleTabs().includes(S.tab)) setTab(visibleTabs()[0]); } if (!S.unlocked && Store.noLogin() && !$('#cloud-form').hidden && !$('#auth').hidden) route(); }
      if (S.tab === 'games' && typeof renderGames === 'function') renderGames();
    }
  } catch { /* نستخدم آخر نسخة محفوظة */ }
}

/* ================= الانتقال لمشروع Supabase جديد =================
 * إذا تغيّر المشروع (رابط جديد) نحتفظ بخزنة الجهاز كنسخة احتياطية مشفّرة،
 * ونعاملها كبيانات محلية تُرفع للحساب الجديد عند الدخول بنفس كلمة المرور. */
async function migrateProject() {
  if (!Cloud.enabled || !Cloud.REF) return;
  const { meta, auth, vault } = await browser.storage.local.get(['meta', 'auth', 'vault']);
  if (!meta || meta.project === Cloud.REF) return;
  if (auth && vault && meta.owner && meta.project) {
    await browser.storage.local.set({ vault_backup: { auth, vault, meta, at: Date.now(), from: meta.project || 'old' } });
    const m = { ...meta };
    delete m.owner;
    m.project = Cloud.REF;
    await browser.storage.local.set({ meta: m });
  } else {
    await browser.storage.local.set({ meta: { ...meta, project: Cloud.REF } });
  }
}

/* استعادة بيانات الحساب السابق (من النسخة الاحتياطية) ودمجها في الخزنة الحالية */
async function restoreOldBackup() {
  const { vault_backup: b } = await browser.storage.local.get('vault_backup');
  if (!b) return toast('لا توجد نسخة سابقة');
  const pw = await askPassword({ title: 'استعادة بياناتك السابقة', text: 'أدخل كلمة مرور حسابك القديم لفك النسخة ودمج مواقعك ومهامك.', verifyWith: async (p) => { try { await Core.openBackup(p, b); return true; } catch { return false; } } });
  if (!pw) return;
  const old = await Core.openBackup(pw, b);
  let added = 0, tasks = 0;
  await commit((v) => {
    for (const it of old.items || []) { if (!Core.findDuplicate(v, it.url)) { Core.insertItem(v, it); added++; } }
    const ids = new Set((v.tasks || []).map((t) => t.id));
    for (const t of old.tasks || []) { if (!ids.has(t.id)) { (v.tasks = v.tasks || []).push(t); tasks++; } }
  });
  await browser.storage.local.remove('vault_backup');
  toast(`تمت الاستعادة: ${UI.n(added)} موقع و${UI.n(tasks)} مهمة`, { type: 'success', duration: 5000 });
  renderAccount();
}
