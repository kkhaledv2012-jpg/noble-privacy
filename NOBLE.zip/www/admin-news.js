/* NOBLE — لوحة تحكم الأخبار: مراجعة ونشر، كتابة خبر، المصادر، Gemini والسحب التلقائي */
'use strict';
const AN = { sub: 'draft', items: null, sources: null, settings: null, stats: null, busy: false, dom: '' };
const AN_SUBS = [['draft', 'بانتظار المراجعة'], ['published', 'المنشورة'], ['rejected', 'المرفوضة'], ['sources', 'المصادر'], ['filter', '🎯 الفلتر والأولويات'], ['domains', '🧭 المجالات والدول'], ['settings', 'الإعدادات']];
/* المجالات والدول الفعّالة (من الإعدادات أو الافتراضي) */
const anCfg = () => NewsCfg.from(AN.settings?.data || {});
const anBack = () => Math.min(168, Math.max(1, Number(AN.settings?.data?.backHours) || 24));
const anCat = (k, t, c) => {
  const cfg = anCfg(), d = cfg.domains.find((x) => x.id === k), fl = c ? cfg.countries.find((x) => x.id === c) : null;
  const sub = (d?.subs || []).find((x) => x[0] === t)?.[1];
  return `${d ? d.ic + ' ' + d.name : '📰 ' + (k || 'عام')}${sub ? ' / ' + sub : ''}${fl ? ' ' + fl.flag : c ? ' ' + c : ''}`;
};
/* مختار: مجال ← اهتمام ← دولة */
/* 1.21.10 — اختيار أكثر من مجال للمصدر: الأول ★ هو الأساسي، وGemini يحط كل خبر في الأنسب منها · «🌐 أي مجال» = Gemini يقرر من كل المجالات */
function anMultiPicker(o, onChange) {
  const cfg = anCfg(), box = h('div', { class: 'an-pick' });
  o.cats = Array.isArray(o.cats) ? o.cats.filter((c) => c !== o.cat) : [];
  const all = () => [o.cat, ...o.cats].filter(Boolean);
  const paint = () => {
    const sel = all(), any = o.cats.includes('*'), d = cfg.domains.find((x) => x.id === o.cat);
    const tog = (id) => {
      if (id === '*') { o.cats = any ? o.cats.filter((c) => c !== '*') : [...o.cats, '*']; }
      else if (sel.includes(id)) { if (sel.filter((c) => c !== '*').length <= 1) return toast('لازم مجال واحد على الأقل'); if (o.cat === id) { o.cat = o.cats.find((c) => c !== '*'); o.cats = o.cats.filter((c) => c !== o.cat); } else o.cats = o.cats.filter((c) => c !== id); o.topic = ''; }
      else { o.cats = [...o.cats, id]; o.topic = ''; }
      paint(); onChange?.();
    };
    const chip = (id, label, on, star) => h('button', { type: 'button', class: `chip an-mc${on ? ' on' : ''}`, onclick: () => tog(id) }, on ? '✓ ' : '', label, star ? h('b', { class: 'an-star', text: ' ★' }) : null);
    const one = sel.filter((c) => c !== '*').length === 1 && !any;
    const csel = (opts, val, set) => { const el = h('select', { class: 'input select' }, ...opts.map(([v, l]) => h('option', { value: v, text: l, selected: v === val }))); el.addEventListener('change', () => { set(el.value); onChange?.(); }); return el; };
    box.replaceChildren(
      h('div', { class: 'field' }, h('span', { text: 'المجالات (تقدر تختار أكثر من واحد)' }),
        h('div', { class: 'chips an-mcs' }, ...cfg.domains.map((x) => chip(x.id, `${x.ic} ${x.name}${x.on ? '' : ' (موقوف)'}`, sel.includes(x.id), x.id === o.cat && sel.length > 1)),
          chip('*', '🌐 أي مجال ثاني — Gemini يقرر', any))),
      h('small', { class: 'hint', text: any ? '🌐 Gemini يحط كل خبر في المجال الأنسب من كل المجالات (★ الأساسي لو ما قدر يحدد).' : sel.length > 1 ? `★ ${d?.name || ''} هو الأساسي — كل خبر ينحط في الأنسب من اللي اخترتها. (المصادر العربية بدون صياغة AI تنزل في الأساسي)` : 'اختر أكثر من مجال لو المصدر ينشر في كذا مجال.' }),
      one ? h('label', { class: 'field' }, h('span', { text: 'الاهتمام' }), csel([['', 'عام — يحدده Gemini'], ...(d?.subs || []).map((x) => [x[0], x[1]])], o.topic || '', (v) => (o.topic = v))) : null,
      h('label', { class: 'field' }, h('span', { text: 'الدولة' }), csel([['', '🌐 عام — للكل'], ...cfg.countries.map((x) => [x.id, `${x.flag} ${x.name}`])], o.country || '', (v) => (o.country = v))));
  };
  paint();
  return box;
}
function anPicker(o, onChange) {
  const cfg = anCfg();
  const box = h('div', { class: 'an-pick' });
  const paint = () => {
    const d = cfg.domains.find((x) => x.id === o.cat);
    const sel = (opts, val, set) => { const el = h('select', { class: 'input select' }, ...opts.map(([v, l]) => h('option', { value: v, text: l, selected: v === val }))); el.addEventListener('change', () => { set(el.value); paint(); onChange?.(); }); return el; };
    box.replaceChildren(
      h('label', { class: 'field' }, h('span', { text: 'المجال' }), sel(cfg.domains.map((x) => [x.id, `${x.ic} ${x.name}${x.on ? '' : ' (موقوف)'}`]), o.cat, (v) => { o.cat = v; o.topic = ''; })),
      h('label', { class: 'field' }, h('span', { text: 'الاهتمام' }), sel([['', 'عام — يحدده Gemini'], ...(d?.subs || []).map((x) => [x[0], x[1]])], o.topic || '', (v) => (o.topic = v))),
      h('label', { class: 'field' }, h('span', { text: 'الدولة' }), sel([['', '🌐 عام — للكل'], ...cfg.countries.map((x) => [x.id, `${x.flag} ${x.name}`])], o.country || '', (v) => (o.country = v))));
  };
  paint();
  return box;
}
const AN_DEF = { auto: false, perRun: 8, hours: 3, model: 'gemini-flash-latest', maxAgeDays: 3, keepDays: 60, backHours: 24, tone: '', title: 'الأخبار', sub: '', hour: 8, digest: true, quickOn: true, quickMax: 40 };

async function openNewsAdmin(force) {
  const box = $('#a-news');
  if (!AN.settings || force) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      [AN.settings, AN.stats] = await Promise.all([Cloud.admin.newsSettings(), Cloud.admin.newsStats()]);
      AN.settings.data = { ...AN_DEF, ...(AN.settings.data || {}) };
    } catch (e) {
      const msg = Cloud.msg(e);
      box.replaceChildren(h('p', { class: 'note-box', text: /function|schema/i.test(msg) ? 'شغّل ملف supabase/update-all.sql (كامل) في Supabase ← SQL Editor أولاً حتى يشتغل قسم الأخبار.' : 'تعذّر التحميل: ' + msg }));
      return;
    }
  }
  renderNewsAdmin();
  loadAnSub();
}
async function loadAnSub() {
  try {
    if (AN.sub === 'sources') AN.sources = await Cloud.admin.newsSources();
    else if (AN.sub !== 'settings' && AN.sub !== 'domains' && AN.sub !== 'filter') {
      AN.items = await Cloud.admin.newsList(AN.sub, 150);
      if (!AN.sources) AN.sources = await Cloud.admin.newsSources().catch(() => null);
    }
  } catch (e) { toast('تعذّر التحميل: ' + Cloud.msg(e), { type: 'error' }); }
  paintAnBody();
}
async function refreshAnStats() { try { AN.stats = await Cloud.admin.newsStats(); paintAnStats(); } catch { /* لا شيء */ } }

function renderNewsAdmin() {
  const st = AN.settings;
  $('#a-news').replaceChildren(...[
    h('section', { class: 'a-hero' },
      h('div', {}, h('h1', {}, h('span', { class: 'title-pill', text: 'الأخبار' })),
        h('p', { class: 'lead', text: 'الأخبار تُسحب من المصادر: العربية تنزل مباشرة، والأجنبية يترجمها ويصنّفها Gemini، وتنتظر موافقتك قبل ما تنزل للمستخدمين. تقدر تكتب خبرك بنفسك أو تعدّل أي خبر.' })),
      h('div', { class: 'a-save' },
        h('button', { type: 'button', class: 'btn', onclick: () => editNews({}) }, icon('plus', { size: 16 }), 'اكتب خبر'),
        h('button', { type: 'button', class: 'btn btn-primary', id: 'an-run', onclick: runNewsFetch }, icon('download', { size: 16 }), 'اسحب الآن'))),
    !st.has_key ? h('p', { class: 'note-box', text: '⚠️ ما أضفت مفتاح Gemini بعد — الأخبار بتنسحب بالإنجليزي بدون ترجمة. أضفه من «الإعدادات».' }) : null,
    h('div', { class: 'an-stats', id: 'an-stats' }),
    h('nav', { class: 'chips an-nav' }, ...AN_SUBS.map(([id, l]) => h('button', { type: 'button', class: `chip${AN.sub === id ? ' on' : ''}`, onclick: () => { AN.sub = id; AN.items = null; renderNewsAdmin(); loadAnSub(); } },
      l, id === 'draft' && AN.stats?.draft ? h('span', { class: 'an-badge num', text: AN.stats.draft }) : null))),
    h('div', { id: 'an-body', class: 'an-body' }, h('p', { class: 'hint', text: 'جارٍ التحميل…' }))].filter(Boolean));
  paintAnStats();
  UI.digitize($('#a-news'));
}
function paintAnStats() {
  const s = AN.stats || {};
  const box = $('#an-stats');
  if (!box) return;
  box.replaceChildren(...[[s.draft, 'بانتظارك'], [s.today, 'منشور اليوم'], [s.views, 'قراءة (٧ أيام)'], [s.saves, 'حفظ (٧ أيام)']].map(([n, l]) =>
    h('div', {}, h('b', { class: 'num', text: UI.n(n || 0) }), h('small', { text: l }))));
}

async function runNewsFetch() {
  if (AN.busy) return;
  AN.busy = true;
  const b = $('#an-run'); if (b) { b.disabled = true; b.lastChild.textContent = 'جارٍ السحب… (حتى دقيقتين)'; }
  try {
    const r = await Cloud.admin.newsRun('fetch');
    const errs = Object.entries(r.sources || {}).filter(([, v]) => typeof v === 'string').map(([k]) => k);
    toast((r.added ? `وصلت ${UI.n(r.added)} أخبار جديدة${r.auto ? ' ونُشرت' : ' — راجعها ✓'}` : 'ما فيه أخبار جديدة الحين') + (r.filtered ? ` · 🎯 الفلتر أبعد ${UI.n(r.filtered)}` : ''), { type: r.added ? 'success' : '' });
    if (r.errors?.length) toast(/quota|rate|429/i.test(r.errors[0]) ? 'ملاحظة: خلص حد Gemini المجاني لليوم — الأخبار الأجنبية بتنتظر لين يرجع الحد بكرة، والعربية نزلت عادي 👍' : 'ملاحظة: ' + r.errors[0], { type: 'error', duration: 6000 });
    else if (errs.length) toast('تعذّر السحب من: ' + errs.join('، '), { type: 'error' });
    AN.sub = r.auto ? 'published' : 'draft';
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  AN.busy = false;
  await refreshAnStats();
  renderNewsAdmin(); loadAnSub();
}

function paintAnBody() {
  const body = $('#an-body');
  if (!body) return;
  if (AN.sub === 'sources') return paintAnSources(body);
  if (AN.sub === 'settings') return paintAnSettings(body);
  if (AN.sub === 'domains') return paintAnDomains(body);
  if (AN.sub === 'filter') return paintAnFilter(body);
  const list = AN.items || [];
  if (!list.length) {
    body.replaceChildren(h('div', { class: 'empty' }, h('b', { text: AN.sub === 'draft' ? 'ما فيه أخبار تنتظرك 👌' : 'لا يوجد شيء هنا' }),
      AN.sub === 'draft' ? h('small', { text: 'اضغط «اسحب الآن» أو انتظر السحب التلقائي.' }) : null));
    return;
  }
  // الأخبار العربية المباشرة ما تحتاج ترجمة — ما نحسبها
  const direct = new Set((AN.sources || []).filter((x) => x.lang === 'ar' && !x.rewrite).map((x) => x.id));
  const raw = list.filter((x) => !x.ai && x.source_id && !direct.has(x.source_id)).length;
  const tr = raw && AN.sub !== 'rejected' ? h('div', { class: 'an-tr' }, h('span', { text: `🌐 ${UI.n(raw)} خبر أجنبي بدون ترجمة (كان Gemini مشغولاً أو خلص حدّه اليومي)` }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async (e) => {
      const b = e.currentTarget; b.disabled = true; b.textContent = 'جارٍ الترجمة… (حتى دقيقتين)';
      try { const r = await Cloud.admin.newsRun('translate'); toast(r.translated ? `تُرجم ${UI.n(r.translated)} خبر ✓${r.left ? ` — باقي ${UI.n(r.left)}، اضغط مرة ثانية` : ''}` : (/quota|rate|429/i.test(r.errors?.[0] || '') ? 'خلص حد Gemini المجاني لليوم — يرجع تلقائياً بكرة الساعة ١٠ الصبح تقريباً، والأخبار العربية ما تتأثر 👍' : 'ما تُرجم شي: ' + (r.errors?.[0] || 'حاول بعد دقائق')), { type: r.translated ? 'success' : 'error', duration: 6000 }); }
      catch (err) { toast(Cloud.msg(err), { type: 'error' }); }
      await refreshAnStats(); loadAnSub();
    } }, '✨ ترجم الكل')) : null;
  // تصفية حسب المجال (أسرع للقراءة والنشر) + نشر كل أخبار المجال بضغطة
  const doms = anCfg().domains;
  const count = {};
  list.forEach((x) => { count[x.cat] = (count[x.cat] || 0) + 1; });
  if (AN.dom && !count[AN.dom]) AN.dom = '';
  const shown = AN.dom ? list.filter((x) => x.cat === AN.dom) : list;
  const dchip = (k, label) => h('button', { type: 'button', class: `chip${AN.dom === k ? ' on' : ''}`, onclick: () => { AN.dom = k; paintAnBody(); } }, label);
  const domNav = Object.keys(count).length > 1 || AN.dom ? h('nav', { class: 'chips an-doms' }, dchip('', `الكل ${UI.n(list.length)}`),
    ...Object.entries(count).sort((a, b) => b[1] - a[1]).map(([k, n]) => { const d = doms.find((x) => x.id === k); return dchip(k, `${d ? d.ic + ' ' + d.name : '📰 ' + (k || 'عام')} ${UI.n(n)}`); })) : null;
  const bulkGo = (down) => async (e) => {
    // 1.21.6: نمسك الزر قبل أي await — بعدها e.currentTarget يصير null والزر كان ما يسوي شي
    const b = e.currentTarget, d = doms.find((x) => x.id === AN.dom), todo = shown.slice();
    if (!(await confirmSheet({ title: down ? 'نشر الكل تحت؟' : 'نشر الكل؟', text: `ينشر ${UI.n(todo.length)} خبر من ${d ? d.name : 'هذا المجال'} للمستخدمين${down ? ' — يطلعون بعد أخبار اليوم الجديدة' : ''}.`, ok: down ? '⬇️ انشر الكل تحت' : 'انشر الكل' }))) return;
    if (b) b.disabled = true;
    let n = 0; const done = new Set(); let err = '';
    for (const it of todo) {
      try { await (down ? Cloud.admin.newsPublishBack(it.id, anBack()) : Cloud.admin.newsSet(it.id, 'published')); n++; done.add(it.id); if (b) b.textContent = `جارٍ النشر… ${UI.n(n)}/${UI.n(todo.length)}`; }
      catch (x) { err = Cloud.msg(x); }
    }
    if (n) toast(`نُشر ${UI.n(n)} خبر ✓`, { type: 'success' });
    if (n && !down) anNotify(n);
    if (n < todo.length) toast(`ما انشر ${UI.n(todo.length - n)} خبر${err ? ': ' + err : ''}`, { type: 'error', duration: 7000 });
    AN.items = AN.items.filter((x) => !done.has(x.id)); if (n === todo.length) AN.dom = '';
    await refreshAnStats(); paintAnBody();
  };
  const bulk = AN.sub === 'draft' && AN.dom && shown.length > 1 ? h('div', { class: 'an-bulks' },
    h('button', { type: 'button', class: 'btn an-ok an-bulk', onclick: bulkGo(false) }, `✓ انشر كل ${UI.n(shown.length)} في هذا المجال`),
    h('button', { type: 'button', class: 'btn an-down an-bulk', onclick: bulkGo(true) }, '⬇️ انشر الكل تحت')) : null;
  body.replaceChildren(...[tr, domNav, bulk, ...anByDay(shown)].filter(Boolean));
  UI.digitize(body);
}
/* 1.21.6 — فاصل لكل يوم: أخبار اليوم لحالها وأمس لحالها (حسب يوم السحب، والمنشور حسب يوم النشر) */
function anByDay(list) {
  const at = (x) => new Date((AN.sub === 'published' ? x.published_at : x.created_at) || x.created_at || 0);
  const key = (d) => d.toLocaleDateString('en-CA');
  const today = key(new Date()), yest = key(new Date(Date.now() - 864e5));
  const sorted = AN.sub === 'published' ? list : list.slice().sort((a, b) => at(b) - at(a));
  const groups = new Map();
  for (const x of sorted) { const k = key(at(x)); if (!groups.has(k)) groups.set(k, []); groups.get(k).push(x); }
  if (groups.size < 2 && !groups.has(yest) && [...groups.keys()][0] === today) return sorted.map(anRow); // كله اليوم: بدون فواصل
  const out = [];
  for (const [k, xs] of groups) {
    const d = at(xs[0]);
    const name = k === today ? 'اليوم' : k === yest ? 'أمس' : d.toLocaleDateString('ar', { weekday: 'long' });
    const date = d.toLocaleDateString('ar', { day: 'numeric', month: 'long' });
    out.push(h('div', { class: `an-day${k === today ? ' today' : ''}` }, h('b', { text: name }), h('span', { text: date }), h('i'), h('small', { text: `${UI.n(xs.length)} خبر` })));
    out.push(...xs.map(anRow));
  }
  return out;
}
/* 1.21.8 — 🔔 إشعارات الأخبار الفورية (Firebase) */
const AN_PUSH = { mode: 'batch', cap: 3, merge: 30, quietFrom: 23, quietTo: 7 };
const anPush = () => ({ ...AN_PUSH, ...(AN.settings?.data?.push || {}) });
async function anNotify(n) {
  if (anPush().mode === 'off') return;
  try { const r = await Cloud.admin.pushSend({ kind: 'batch', n });
    if (r.sent) toast(`🔔 وصل الإشعار لـ ${UI.n(r.sent)} جهاز${r.n > n ? ` (اندمج: ${UI.n(r.n)} أخبار)` : ''}`, { duration: 3500 });
    else if (r.skipped === 'cap') toast('🔕 ما انرسل إشعار — وصلت الحد اليومي', { duration: 3500 });
    else if (r.skipped === 'quiet') toast('🌙 ما انرسل إشعار — ساعات الهدوء', { duration: 3500 });
  } catch (e) { if (!/مو منشورة|not found/i.test(e.message || '')) toast('الإشعار ما انرسل: ' + Cloud.msg(e), { type: 'error', duration: 6000 }); }
}
async function anNotifyOne(id) {
  try { const r = await Cloud.admin.pushSend({ kind: 'one', id }); toast(`نُشر 🔔 ووصل الإشعار لـ ${UI.n(r.sent || 0)} جهاز`, { type: 'success' }); }
  catch (e) { toast('نُشر، بس الإشعار ما انرسل: ' + Cloud.msg(e), { type: 'error', duration: 7000 }); }
}
function anPushCard(d) {
  d.push = anPush(); const P = d.push;
  const num = (label, key, min, max, hint) => { const i = h('input', { class: 'input num ltr', type: 'number', min, max, value: P[key] }); i.addEventListener('input', () => (P[key] = Math.max(min, Math.min(max, Number(i.value) || 0)))); return h('label', { class: 'field' }, h('span', { text: label }), i, hint ? h('small', { class: 'hint', text: hint }) : null); };
  const stats = h('div', { class: 'an-push-st' }, h('small', { class: 'hint', text: 'جارٍ التحميل…' }));
  const modes = [['batch', '📦 مجمّع (أنصح فيه)'], ['off', '🔕 مقفول']];
  const seg = h('div', { class: 'chips' }, ...modes.map(([v, l]) => h('button', { type: 'button', class: `chip${P.mode === v ? ' on' : ''}`, onclick: (e) => { P.mode = v; [...e.currentTarget.parentNode.children].forEach((b, i) => b.classList.toggle('on', modes[i][0] === v)); } }, l)));
  const test = h('button', { type: 'button', class: 'btn', onclick: async (e) => { const b = e.currentTarget; b.disabled = true;
    try { const r = await Cloud.admin.pushSend({ kind: 'test' }); toast(r.sent ? '✅ انرسل لجوالك — قفّل التطبيق وشوف' : (r.note || 'ما انرسل'), { type: r.sent ? 'success' : '', duration: 7000 }); }
    catch (x) { toast(Cloud.msg(x), { type: 'error', duration: 8000 }); } finally { b.disabled = false; } } }, '🧪 جرّب على جوالي');
  (async () => {
    const s = await Cloud.admin.pushStats().catch(() => null);
    if (!s) return stats.replaceChildren(h('p', { class: 'hint', text: '⚠️ يحتاج تلصق update-1.21.8.sql في Supabase وتنشر دالة push-send.' }));
    stats.replaceChildren(h('div', { class: 'ua-grid' },
      ...[[s.devices, 'جهاز مسجّل'], [s.users, 'مستخدم'], [s.today, 'إشعار أخبار اليوم']].map(([v, l]) => h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: UI.n(v || 0) }), h('small', { text: l })))),
      ...(s.log || []).slice(0, 5).map((x) => h('p', { class: 'an-push-l' }, h('b', { text: x.title }), h('small', { text: ` · ${UI.relTime(new Date(x.at).getTime())} · وصل ${UI.n(x.sent)}${x.failed ? ` · فشل ${UI.n(x.failed)}` : ''}` }))));
  })();
  return h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '🔔 إشعارات الأخبار الفورية' }),
    h('p', { class: 'hint', text: 'توصل حتى والتطبيق مسكّر. لما تنشر أخبار يطلع إشعار واحد «نزل ٥ أخبار…»، ولو نشرت ثاني خلال المدة يتحدّث نفس الإشعار بدل واحد جديد. «⬇️ تحت» ما يرسل إشعار، و«🔔 انشر ونبّه» يرسل إشعار خاص للخبر المهم على طول.' }),
    seg,
    h('div', { class: 'ga-3' }, num('أقصى إشعارات أخبار باليوم', 'cap', 1, 10), num('دمج اللي ينشر خلال (دقيقة)', 'merge', 5, 180), h('div')),
    h('div', { class: 'ga-3' }, num('ساعات الهدوء من (٠–٢٣)', 'quietFrom', 0, 23, 'بتوقيت الرياض'), num('إلى', 'quietTo', 0, 23, 'نفس الرقمين = بدون هدوء'), h('div')),
    h('div', { class: 'an-push-a' }, test, h('small', { class: 'hint', text: 'اضغط «حفظ الإعدادات» تحت بعد أي تغيير.' })),
    anPushImgs(P),
    stats);
}
/* 🖼️ 1.21.22: صور الإشعارات الكبيرة (مثل الجزيرة) — لكل نوع: تلقائي / صورة ثابتة / بدون */
function anPushImgs(P) {
  if (typeof PushImg === 'undefined') return null;
  P.img = P.img || {};
  const MODES = {
    issue: [['auto', '✨ تلقائي من العدد'], ['fixed', '🖼️ صورة ثابتة'], ['off', 'بدون']],
    news: [['item', '📰 صورة الخبر نفسه'], ['fixed', '🖼️ صورة ثابتة'], ['off', 'بدون']],
    custom: [['fixed', '🖼️ الافتراضية لإشعاراتك'], ['off', 'بدون']],
  };
  const DEFM = { issue: 'auto', news: 'item', custom: 'fixed' };
  const HINT = {
    issue: 'تلقائي = نرسم صورة فيها عنوان العدد ونوعه وشعارك لحظة النشر. وتقدر تبدّلها لكل عدد من شاشة النشر.',
    news: 'صورة الخبر لو موجودة، ولو ما فيه تطلع الصورة الثابتة تحت.',
    custom: 'تطلع مع إشعاراتك من «🔔 الإشعارات» لو ما رفعت صورة للإشعار نفسه.',
  };
  const slot = (k) => {
    const S = (P.img[k] = { mode: DEFM[k], url: '', ...(P.img[k] || {}) });
    const box = h('div', { class: 'pi-slot' });
    const paint = () => {
      const st = h('small', { class: 'hint' });
      const pickBtn = h('button', { type: 'button', class: 'btn sm', onclick: () => { const i = h('input', { type: 'file', accept: 'image/*' }); i.addEventListener('change', async () => { if (!i.files[0]) return; st.textContent = '⏳ رفع…'; try { S.url = await PushImg.upload(await PushImg.fromFile(i.files[0])); paint(); toast('انرفعت ✓ — اضغط «حفظ الإعدادات»'); } catch (e) { st.textContent = Cloud.msg(e); } }); i.click(); } }, '⬆️ صورتي');
      const genBtn = h('button', { type: 'button', class: 'btn sm', onclick: async () => { st.textContent = '⏳ تجهيز…'; try { S.url = await PushImg.upload(await PushImg.banner({ kind: k })); paint(); toast('جاهزة ✓ — اضغط «حفظ الإعدادات»'); } catch (e) { st.textContent = Cloud.msg(e); } } }, '🎨 تصميم NOBLE');
      box.replaceChildren(
        h('div', { class: 'pi-top' }, h('b', { text: PushImg.KINDS[k].name }),
          h('div', { class: 'chips' }, ...MODES[k].map(([v, l]) => h('button', { type: 'button', class: `chip${S.mode === v ? ' on' : ''}`, onclick: () => { S.mode = v; paint(); } }, l)))),
        h('small', { class: 'hint', text: HINT[k] }),
        S.mode !== 'off' ? h('div', { class: 'pi-row' },
          S.url ? h('img', { class: 'pi-thumb', src: S.url, alt: '' }) : h('div', { class: 'pi-thumb pi-empty', text: 'ما فيه صورة ثابتة' }),
          h('div', { class: 'pi-acts' }, genBtn, pickBtn, S.url ? h('button', { type: 'button', class: 'btn sm', onclick: () => { S.url = ''; paint(); } }, '✕ شيلها') : null, st)) : null);
    };
    paint(); return box;
  };
  return h('details', { class: 'pi-card', open: true }, h('summary', {}, h('b', { text: '🖼️ صور الإشعارات الكبيرة' }), h('small', { text: ' — مثل الجزيرة' })),
    h('p', { class: 'hint', text: 'تطلع كبيرة لما المستخدم يسحب الإشعار لتحت، ومربع صغير من نصها لما يكون مسكّر — خلّ الشعار أو الكلمة المهمة في النص. المقاس 1440×720 (٢:١) — أي صورة ترفعها نقصّها ونصغّرها لحالها. ⚠️ لو المستخدم فاتح التطبيق وقتها يطلع الإشعار بدون صورة.' }),
    slot('issue'), slot('news'), slot('custom'));
}
function anRow(it) {
  const act = async (fn, ok) => { try { await fn(); if (ok) toast(ok, { type: 'success' }); AN.items = AN.items.filter((x) => x.id !== it.id || AN.sub === 'published'); await refreshAnStats(); if (AN.sub === 'published') AN.items = await Cloud.admin.newsList('published', 150); paintAnBody(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  const th = h('div', { class: 'an-th', style: { background: 'linear-gradient(135deg,#0E1B55,#2E5BFF 60%,#56C8FF)' } });
  if (/^https:\/\//.test(it.image || '')) { const im = h('img', { src: it.image, alt: '', loading: 'lazy', referrerpolicy: 'no-referrer' }); im.onerror = () => im.remove(); th.append(im); }
  const when = it.status === 'published' ? it.published_at : it.created_at;
  return h('div', { class: `an-row${it.pinned ? ' pinned' : ''}` }, th,
    h('div', { class: 'an-c' },
      h('b', { text: (it.pinned ? '📌 ' : '') + (it.title || it.src_title) }),
      h('small', { text: `${anCat(it.cat, it.topic, it.country)} · ${it.src_name || '—'} · ${UI.relTime(new Date(when).getTime())}${it.ai ? ' · ترجمة AI' : it.source_id ? ' · مباشر من المصدر' : ' · يدوي'}${it.status === 'published' ? ` · 👁 ${UI.n(it.views)} · 🔖 ${UI.n(it.saves)}` : ''}` }),
      it.summary ? h('p', { text: it.summary }) : null,
      it.src_title && it.src_title !== it.title ? h('span', { class: 'an-en', text: it.src_title }) : null),
    h('div', { class: 'an-a' },
      it.status !== 'published' ? h('button', { type: 'button', class: 'btn an-ok', onclick: () => act(async () => { await Cloud.admin.newsSet(it.id, 'published'); anNotify(1); }, 'نُشر للمستخدمين ✓') }, '✓ انشر') : null,
      it.status !== 'published' ? h('button', { type: 'button', class: 'btn an-bell', title: 'ينشر ويرسل إشعار خاص لهذا الخبر على طول (للأخبار المهمة)', onclick: () => act(async () => { await Cloud.admin.newsSet(it.id, 'published'); await anNotifyOne(it.id); }, null) }, '🔔 انشر ونبّه') : null,
      it.status !== 'published' ? h('button', { type: 'button', class: 'btn an-down', title: 'ينشر بس يطلع بعد أخبار اليوم الجديدة', onclick: () => act(() => Cloud.admin.newsPublishBack(it.id, anBack()), 'نُشر تحت أخبار اليوم ⬇️') }, '⬇️ تحت') : null,
      h('button', { type: 'button', class: 'btn', onclick: () => editNews(it) }, '✎ عدّل'),
      it.status === 'published' ? h('button', { type: 'button', class: 'btn', title: 'تثبيت أعلى القائمة', onclick: () => act(() => Cloud.admin.newsSet(it.id, null, !it.pinned), it.pinned ? 'أُلغي التثبيت' : 'ثُبّت أعلى الأخبار 📌') }, it.pinned ? 'فك 📌' : '📌') : null,
      it.status === 'published' ? h('button', { type: 'button', class: 'btn an-no', onclick: () => act(() => Cloud.admin.newsSet(it.id, 'draft'), 'أُخفي عن المستخدمين') }, 'إخفاء') : null,
      it.status === 'draft' ? h('button', { type: 'button', class: 'btn an-no', 'aria-label': 'رفض', onclick: () => act(() => Cloud.admin.newsSet(it.id, 'rejected')) }, '✕') : null,
      it.status === 'rejected' ? h('button', { type: 'button', class: 'btn an-no', onclick: () => act(() => Cloud.admin.newsDelete(it.id), 'حُذف') }, 'حذف') : null));
}

/* ---------- كتابة / تعديل خبر ---------- */
function editNews(it) {
  const isNew = !it.id;
  const f = (label, key, opt = {}) => {
    const el = opt.area ? h('textarea', { class: 'input textarea', rows: opt.rows || 3, maxlength: opt.max || 600 }) : h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, maxlength: opt.max || 220, placeholder: opt.ph || '' });
    el.value = it[key] || '';
    el.dataset.k = key;
    return h('label', { class: 'field' }, h('span', { text: label }), el, opt.hint ? h('small', { class: 'hint', text: opt.hint }) : null);
  };
  const pick = { cat: it.cat || anCfg().domains[0]?.id || 'ai', topic: it.topic || '', country: it.country || '' };
  const form = h('div', { class: 'an-form' },
    it.src_title ? h('p', { class: 'an-orig' }, h('small', { text: 'العنوان الأصلي:' }), ' ', h('a', { href: it.url, target: '_blank', rel: 'noopener', class: 'ltr', text: it.src_title })) : null,
    f('العنوان', 'title', { max: 220 }),
    f('ملخص قصير (يظهر في القائمة)', 'summary', { area: true, rows: 2, max: 600 }),
    f('نص الخبر', 'body', { area: true, rows: 7, max: 6000, hint: 'افصل الفقرات بسطر فارغ.' }),
    f('💡 ليش يهمك؟ (اختياري)', 'why', { area: true, rows: 2, max: 600 }),
    anPicker(pick),
    h('div', { class: 'row-2' }, f('رابط صورة (https)', 'image', { ltr: true, max: 600, ph: 'https://…' }), f('رابط المصدر', 'url', { ltr: true, max: 600, ph: 'https://…' })),
    f('اسم المصدر', 'src_name', { max: 60, ph: 'فريق NOBLE' }));
  const collect = (status) => {
    const o = { id: it.id || null, cat: pick.cat, topic: pick.topic, country: pick.country, status, pinned: !!it.pinned };
    form.querySelectorAll('[data-k]').forEach((el) => (o[el.dataset.k] = el.value.trim()));
    if (o.title.length < 3) { toast('اكتب عنوان الخبر'); return null; }
    if (o.image && !/^https:\/\//.test(o.image)) { toast('رابط الصورة لازم يبدأ بـ https'); return null; }
    return o;
  };
  const save = async (status) => {
    const o = collect(status);
    if (!o) return;
    try { await Cloud.admin.newsSave(o); toast(status === 'published' ? 'نُشر للمستخدمين ✓' : 'حُفظ ✓', { type: 'success' }); closeSheet($('#mk-sheet')); await refreshAnStats(); AN.sub = status; renderNewsAdmin(); loadAnSub(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  const rewrite = it.id && it.source_id ? h('button', { type: 'button', class: 'btn', onclick: async (e) => {
    const b = e.currentTarget; b.disabled = true; b.textContent = 'جارٍ الصياغة…';
    try { const r = await Cloud.admin.newsRun('rewrite', { id: it.id }); closeSheet($('#mk-sheet')); editNews({ ...it, ...r.item }); toast('أُعيدت الصياغة ✓', { type: 'success' }); }
    catch (err) { toast(Cloud.msg(err), { type: 'error' }); b.disabled = false; b.textContent = '✨ أعد الصياغة'; }
  } }, '✨ أعد الصياغة') : null;
  mkSheet(isNew ? 'خبر جديد' : 'تعديل الخبر', [form], [
    rewrite,
    h('button', { type: 'button', class: 'btn', onclick: () => save(it.status === 'published' ? 'draft' : it.status || 'draft') }, it.status === 'published' ? 'احفظ وأخفِه' : 'احفظ مسودة'),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: () => save('published') }, it.status === 'published' ? 'احفظ التعديل' : 'انشر الآن')]);
}

/* لغة المصدر + صياغة AI (المصدر العربي ينزل مباشرة بدون Gemini إلا لو فعّلتها) */
const AN_TIERS = [['', '📰 مصدر أخبار عادي'], ['official', '✅ رسمي — من الشركة نفسها'], ['secondary', '🗞️ ثانوي — موقع تقني'], ['video', '🎬 قناة يوتيوب رسمية (الصق رابط القناة @)']];
const AN_TIER_TXT = { official: '✅ رسمي', secondary: '🗞️ ثانوي', video: '🎬 يوتيوب' };
function anLangPick(o) {
  const box = h('div', { class: 'an-lang' });
  const paint = () => {
    const sel = h('select', { class: 'input select' }, h('option', { value: 'ar', text: '🇸🇦 عربي — مباشر بدون ترجمة', selected: o.lang === 'ar' }), h('option', { value: 'en', text: '🌐 أجنبي — يترجمه Gemini', selected: o.lang !== 'ar' }));
    sel.addEventListener('change', () => { o.lang = sel.value; paint(); });
    const rw = h('input', { type: 'checkbox', checked: !!o.rewrite });
    rw.addEventListener('change', () => (o.rewrite = rw.checked));
    const tier = h('select', { class: 'input select' }, ...AN_TIERS.map(([v, l]) => h('option', { value: v, text: l, selected: (o.tier || '') === v })));
    tier.addEventListener('change', () => (o.tier = tier.value));
    box.replaceChildren(h('label', { class: 'field' }, h('span', { text: 'لغة المصدر' }), sel),
      h('label', { class: 'field' }, h('span', { text: 'نوع المصدر (لـ«⚡ NOBLE عاجل»)' }), tier),
      o.lang === 'ar' ? h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'صياغة AI' }), h('small', { text: 'يعيد Gemini صياغته ويضيف «ليش يهمك» (يستهلك من الحد المجاني)' })), h('span', { class: 'switch' }, rw, h('span', { class: 'track' }))) : null);
  };
  paint();
  return box;
}
/* ---------- المصادر ---------- */
// 1.21.29: ترجمة أخطاء السحب لعربي واضح + وش تسوي
function anErr(e0) {
  const e = String(e0 || ''), paused = e.startsWith('AUTO_PAUSED');
  const m = e.replace(/^AUTO_PAUSED\s*/, '');
  let t = 'خطأ غير معروف', fix = 'جرّب 🧪 اختبر، ولو تكرر غيّر الرابط';
  const c = (m.match(/HTTP (\d{3})/) || [])[1];
  if (c === '403' || c === '401') { t = `الموقع يرفض السحب (${c})`; fix = 'الموقع يحجب السحب الآلي — ابحث عن رابط RSS الرسمي حقه أو استخدم «أخبار قوقل» بكلمة الموقع'; }
  else if (c === '404' || c === '410') { t = `الرابط ما عاد موجود (${c})`; fix = 'الموقع غيّر رابطه — اضغط 🧪 وخلّه يدور الرابط الجديد'; }
  else if (c === '429') { t = 'طلبات كثيرة (429)'; fix = 'الموقع يقول «خفّف» — بيرجع لحاله، ما تحتاج تسوي شي'; }
  else if (c && c[0] === '5') { t = `الموقع عطلان مؤقتاً (${c})`; fix = 'مشكلة عندهم، بيرجع لحاله'; }
  else if (/TIMEOUT|abort/i.test(m)) { t = 'الموقع بطيء وما رد'; fix = 'غالباً مؤقت — لو تكرر أوقفه'; }
  else if (/NO_FEED/.test(m)) { t = 'ما لقيت أخبار في الرابط'; fix = 'هذا رابط صفحة مو RSS — اضغط 🧪 وأدور لك على رابط RSS'; }
  else if (/YT_ID/.test(m)) { t = 'ما عرفت القناة'; fix = 'انسخ رابط القناة كامل (مثل youtube.com/@اسم)'; }
  else if (/dns|resolve|connect|network|refused|certificate|tls/i.test(m)) { t = 'ما قدرت أوصل للموقع'; fix = 'تأكد من الرابط (مكتوب صح؟ https؟)'; }
  return { t: paused ? '⏸️ توقف تلقائياً بعد ٥ أخطاء — ' + t : t, fix, raw: m, paused };
}
// 🧪 اختبار: يرجع أول العناوين أو سبب الخطأ — ولو الرابط صفحة عادية يدور على RSS بنفسه
async function anProbe(u, btn) {
  if (!/^https?:\/\//.test(String(u || '').trim())) { toast('اكتب رابط يبدأ بـ https://'); return null; }
  const old = btn?.textContent; if (btn) { btn.disabled = true; btn.textContent = '⏳'; }
  try {
    const r = await Cloud.admin.newsRun('probe', { url: u.trim() });
    if (!r.ok) { const E = anErr(r.error); mkSheet('🧪 نتيجة الاختبار', [h('p', { class: 'an-err', text: '✗ ' + E.t }), h('p', { class: 'hint', text: '💡 ' + E.fix }), h('small', { class: 'an-en', text: E.raw })], []); return r; }
    mkSheet('🧪 نتيجة الاختبار', [
      h('p', { text: `✓ شغّال — ${r.count} خبر${r.found ? ' (لقيت رابط RSS بنفسي واستخدمته)' : ''}` }),
      r.found ? h('small', { class: 'an-en', text: r.url }) : null,
      ...(r.items || []).map((x) => h('div', { class: 'an-src' }, h('div', { class: 'an-c' }, h('b', { text: x.title || '—' }), h('small', { class: 'hint', text: `${x.date ? UI.relTime(new Date(x.date).getTime()) : ''}${x.image ? ' · 🖼️ فيه صورة' : ''}` }))))], []);
    UI.digitize($('#mk-sheet'));
    return r;
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); return null; }
  finally { if (btn) { btn.disabled = false; btn.textContent = old; } }
}
function paintAnSources(body) {
  const list = AN.sources || [];
  const name = h('input', { class: 'input', placeholder: 'اسم المصدر', maxlength: 60 });
  const url = h('input', { class: 'input ltr', placeholder: 'https://…/feed (رابط RSS) أو رابط قناة يوتيوب', type: 'url' });
  const gq = h('input', { class: 'input', placeholder: 'كلمة البحث في أخبار قوقل (مثال: الذكاء الاصطناعي السعودية)', maxlength: 80 });
  const gqRow = h('div', { class: 'an-add-row an-gq', hidden: true }, gq, h('button', { type: 'button', class: 'btn', onclick: () => {
    const q = gq.value.trim(); if (!q) return toast('اكتب كلمة البحث');
    const ar = pick.lang === 'ar';
    url.value = `https://news.google.com/rss/search?q=${encodeURIComponent(q + ' when:7d')}&hl=${ar ? 'ar' : 'en-US'}&gl=${ar ? 'SA' : 'US'}&ceid=${ar ? 'SA:ar' : 'US:en'}`;
    if (!name.value.trim()) name.value = 'قوقل: ' + q;
    toast('جهزت الرابط ✓ — اضغط 🧪 اختبر أو إضافة');
  } }, 'جهّز الرابط'));
  const pick = { cat: anCfg().domains[0]?.id || 'ai', cats: [], topic: '', country: '', lang: 'ar', rewrite: false, tier: '' };
  const add = async (ev) => {
    if (!/^https?:\/\//.test(url.value.trim())) return toast('اكتب رابط RSS صحيح');
    const r = await anProbe(url.value, ev?.currentTarget); // نختبر قبل الإضافة
    if (!r) return;
    if (!r.ok && !(await confirmSheet({ title: 'المصدر فيه مشكلة', text: anErr(r.error).t + ' — تضيفه برضو؟', ok: 'أضفه' }))) return;
    if (r.ok && r.url) url.value = r.url;
    closeSheet($('#mk-sheet'));
    try { await Cloud.admin.newsSourceSave({ name: name.value.trim() || new URL(url.value).hostname, url: url.value.trim(), ...pick }); toast('أُضيف المصدر ✓', { type: 'success' }); loadAnSub(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  const row = (s) => {
    const sw = h('input', { type: 'checkbox', checked: s.active });
    sw.addEventListener('change', async () => { try { await Cloud.admin.newsSourceSave({ id: s.id, active: sw.checked }); } catch (e) { sw.checked = !sw.checked; toast(Cloud.msg(e), { type: 'error' }); } });
    return h('div', { class: 'an-src' },
      h('div', { class: 'an-c' }, h('b', { text: s.name }), h('span', { class: 'an-en', text: s.url }),
        h('small', { text: `${AN_TIER_TXT[s.tier] ? AN_TIER_TXT[s.tier] + ' · ' : ''}${anCat(s.cat, s.topic, s.country)}${(s.cats || []).length ? ` +${(s.cats || []).includes('*') ? 'أي مجال' : (s.cats || []).length}` : ''} · ${s.lang === 'ar' ? (s.rewrite ? 'عربي + صياغة AI' : 'عربي مباشر') : 'ترجمة AI'} · ${s.last_fetch ? 'آخر سحب ' + UI.relTime(new Date(s.last_fetch).getTime()) : 'لم يُسحب بعد'}` }),
        s.last_error ? h('small', { class: 'an-err', title: anErr(s.last_error).raw, text: `⚠️ ${anErr(s.last_error).t} — ${anErr(s.last_error).fix}` }) : null),
      h('label', { class: 'switch' }, sw, h('span', { class: 'track' })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'اختبر المصدر', onclick: (e) => anProbe(s.url, e.currentTarget) }, '🧪'),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'تعديل المجال والدولة واللغة', onclick: () => {
        const o = { cat: s.cat, cats: s.cats || [], topic: s.topic || '', country: s.country || '', lang: s.lang === 'ar' ? 'ar' : 'en', rewrite: !!s.rewrite, tier: s.tier || '' };
        mkSheet(`مجال «${s.name}»`, [h('p', { class: 'hint', text: 'كل خبر من هذا المصدر ينزل في المجالات اللي تختارها والدولة، وGemini يختار الأنسب لكل خبر.' }), anMultiPicker(o), anLangPick(o)],
          [h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => { try { await Cloud.admin.newsSourceSave({ id: s.id, ...o }); closeSheet($('#mk-sheet')); toast('حُفظ ✓', { type: 'success' }); loadAnSub(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, 'حفظ')]);
      } }, '🧭'),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => { if (!(await confirmSheet({ title: 'حذف المصدر', text: `يُحذف «${s.name}» (الأخبار المنشورة منه تبقى).`, ok: 'حذف' }))) return; try { await Cloud.admin.newsSourceDelete(s.id); loadAnSub(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, icon('trash', { size: 16 })));
  };
  body.replaceChildren(
    h('p', { class: 'hint', text: 'المصادر روابط RSS. لكل مصدر مجال ودولة (الدولة «عام» = يوصل للكل، ودولة محددة = يوصل بس للي اختارها). اضغط 🧭 لتغيير مجال أي مصدر. الخبر اللي ما يناسب مجاله يُرفض تلقائياً.' }),
    h('div', { class: 'set-card an-srcs' }, ...(list.length ? list.map(row) : [h('p', { class: 'hint', text: 'لا توجد مصادر.' })])),
    h('div', { class: 'set-card an-add' }, h('strong', { text: 'إضافة مصدر' }),
      h('div', { class: 'chips' },
        h('button', { type: 'button', class: 'chip', onclick: () => { url.value = ''; url.placeholder = 'https://www.youtube.com/@اسم-القناة'; url.focus(); toast('الصق رابط القناة — أحوله لـ RSS بنفسي (رسمي ومجاني من يوتيوب)'); } }, '▶️ قناة يوتيوب'),
        h('button', { type: 'button', class: 'chip', onclick: () => { gqRow.hidden = !gqRow.hidden; if (!gqRow.hidden) gq.focus(); } }, '🔎 أخبار قوقل'),
        h('button', { type: 'button', class: 'chip', onclick: () => { url.placeholder = 'https://موقع.com — أدور على RSS بنفسي'; url.focus(); } }, '🌐 موقع عادي')),
      gqRow,
      h('div', { class: 'an-add-row' }, name, url, h('button', { type: 'button', class: 'btn', onclick: (e) => anProbe(url.value, e.currentTarget) }, '🧪 اختبر'), h('button', { type: 'button', class: 'btn btn-primary', onclick: add }, 'إضافة')),
      h('small', { class: 'hint', text: 'كلها مصادر رسمية ومجانية: RSS المواقع نفسها، يوتيوب (RSS رسمي للقنوات)، وأخبار قوقل (RSS عام). نعرض العنوان والملخص مع رابط المصدر — ما ننسخ المقال كامل.' }),
      anMultiPicker(pick), anLangPick(pick)));
  UI.digitize(body);
}

/* ---------- الإعدادات ---------- */
function paintAnSettings(body) {
  const st = AN.settings, d = st.data;
  const num = (label, key, min, max, hint) => {
    const i = h('input', { class: 'input num ltr', type: 'number', min, max, value: d[key] });
    i.addEventListener('input', () => (d[key] = Math.max(min, Math.min(max, Number(i.value) || min))));
    return h('label', { class: 'field' }, h('span', { text: label }), i, hint ? h('small', { class: 'hint', text: hint }) : null);
  };
  const txt = (label, key, max, opt = {}) => {
    const i = opt.area ? h('textarea', { class: 'input textarea', rows: 2, maxlength: max }) : h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, maxlength: max });
    i.value = d[key] || '';
    i.addEventListener('input', () => (d[key] = i.value.trim()));
    return h('label', { class: 'field' }, h('span', { text: label }), i, opt.hint ? h('small', { class: 'hint', text: opt.hint }) : null);
  };
  const sw = (label, sub, key) => {
    const i = h('input', { type: 'checkbox', checked: !!d[key] });
    i.addEventListener('change', () => (d[key] = i.checked));
    return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), h('small', { text: sub })), h('span', { class: 'switch' }, i, h('span', { class: 'track' })));
  };
  const keyIn = h('input', { class: 'input ltr', type: 'password', placeholder: st.has_key ? `المفتاح الحالي ${st.key_hint}` : 'AIza…', autocomplete: 'off' });
  const saveKey = async () => {
    try { await Cloud.admin.newsSetKey(keyIn.value.trim()); st.has_key = !!keyIn.value.trim(); st.key_hint = st.has_key ? '••••' + keyIn.value.trim().slice(-4) : ''; keyIn.value = ''; toast(st.has_key ? 'حُفظ المفتاح في السيرفر ✓' : 'حُذف المفتاح', { type: 'success' }); renderNewsAdmin(); paintAnBody(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  const test = async (e) => {
    const b = e.currentTarget; b.disabled = true;
    try { const r = await Cloud.admin.newsRun('test'); toast(r.ok ? `Gemini يشتغل ✓ — ${r.msg || ''}` : 'Gemini: ' + r.error, { type: r.ok ? 'success' : 'error' }); }
    catch (err) { toast(Cloud.msg(err), { type: 'error' }); }
    b.disabled = false;
  };
  const save = async () => {
    try {
      await Cloud.admin.newsSetSettings(d);
      const r = await Cloud.admin.newsSchedule(Number(d.hours) || 0);
      st.cron = r === 'on';
      toast(r === 'on' ? `حُفظت — السحب التلقائي كل ${UI.n(d.hours)} ساعات ✓` : 'حُفظت الإعدادات ✓ (السحب التلقائي متوقف)', { type: 'success' });
      paintAnBody();
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  body.replaceChildren(
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: 'القسم في التطبيق' }),
      h('div', { class: 'row-2' }, txt('اسم القسم', 'title', 30), num('ساعة إشعار «موجز اليوم» (٠–٢٣)', 'hour', 0, 23)),
      txt('سطر تعريفي (اختياري)', 'sub', 120),
      sw('بطاقة «موجز اليوم»', 'أهم ٣ أخبار أعلى القسم (المثبّتة أولاً)', 'digest')),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: 'السحب والنشر' }),
      sw('النشر التلقائي', 'الخبر ينزل للمستخدمين مباشرة بعد الترجمة بدون مراجعتك (غير مستحسن)', 'auto'),
      h('div', { class: 'ga-3' }, num('السحب التلقائي كل (ساعات)', 'hours', 0, 24, '٠ = إيقاف'), num('أقصى أخبار في كل سحب', 'perRun', 1, 20), num('عمر الخبر الأقصى (أيام)', 'maxAgeDays', 1, 14)),
      num('احذف المنشور بعد (أيام)', 'keepDays', 7, 365, 'المثبّت لا يُحذف.'),
      num('«⬇️ انشر تحت» يرجّع الخبر كم ساعة', 'backHours', 1, 168, 'يطلع بعد أخبار هالمدة. ٢٤ = بعد أخبار اليوم'),
      h('p', { class: 'hint', text: st.cron === null ? '⚠️ السحب التلقائي يحتاج تفعيل pg_cron و pg_net من Supabase ← Database ← Extensions.' : st.cron ? '✓ السحب التلقائي شغّال.' : 'السحب التلقائي متوقف — يشتغل بعد الحفظ إذا حددت عدد الساعات.' })),
    anPushCard(d),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '✨ الإضافة السريعة في «يومي»' }),
      h('p', { class: 'hint', text: 'المستخدم يكتب أو يقول جملة مثل «ادفع الكهرباء ٣٠٠ بكرة» ويفهمها Gemini بنفس المفتاح. المجاني/المدفوع والحد اليومي للمستخدمين من: الاشتراكات ← مزايا كل قسم ← يومي.' }),
      sw('تشغيل الإضافة الذكية', 'عند الإيقاف يشتغل الفهم المبسّط على الجهاز فقط', 'quickOn'),
      num('أقصى استخدام لكل مستخدم يومياً (حماية حصة Gemini)', 'quickMax', 1, 500),
      h('div', { class: 'an-usage', id: 'an-usage' }, h('small', { class: 'hint', text: 'جارٍ تحميل الاستخدام…' }))),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: 'الترجمة والتلخيص (Gemini)' }),
      h('p', { class: 'hint', text: 'المفتاح مجاني من Google AI Studio (aistudio.google.com ← Get API key). يُحفظ في السيرفر فقط ولا يظهر لأي مستخدم.' }),
      h('div', { class: 'an-key' }, keyIn, h('button', { type: 'button', class: 'btn', onclick: saveKey }, st.has_key && !keyIn.value ? 'تغيير' : 'حفظ المفتاح'), st.has_key ? h('button', { type: 'button', class: 'btn', onclick: test }, 'اختبر') : null),
      txt('الموديل', 'model', 60, { ltr: true, hint: 'اتركه gemini-flash-latest إلا لو تبي موديل محدد.' }),
      txt('أسلوب إضافي للكتابة (اختياري)', 'tone', 300, { area: true, hint: 'مثلاً: ركّز على ما يهم المصممين وصنّاع المحتوى في السعودية.' })),
    h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: save }, 'حفظ الإعدادات'));
  UI.digitize(body);
  Cloud.admin.aiUsage(14).then((rows) => {
    const box = $('#an-usage'); if (!box) return;
    const tot = rows.reduce((a, r) => a + Number(r.uses || 0), 0), today = rows.find((r) => String(r.day).slice(0, 10) === new Date().toISOString().slice(0, 10));
    box.replaceChildren(h('small', { class: 'hint', text: `استخدام آخر ١٤ يوم: ${UI.n(tot)} مرة · اليوم: ${UI.n(Number(today?.uses || 0))} مرة من ${UI.n(Number(today?.users || 0))} مستخدم` }));
    UI.digitize(box);
  });
}

/* ---------- المجالات والدول (1.13) ---------- */
function paintAnDomains(body) {
  const d = AN.settings.data;
  const cfg = NewsCfg.from(d);
  // نشتغل على نسخة كاملة — تُحفظ كلها مع «حفظ»
  const W = AN.dw ||= { domains: cfg.domains, countries: cfg.countries, limits: cfg.limits, premium: cfg.premium, ask: cfg.ask, open: '' };
  const again = () => paintAnDomains(body);
  const mv = (arr, i, dlt) => { const j = i + dlt; if (j < 0 || j >= arr.length) return; [arr[i], arr[j]] = [arr[j], arr[i]]; again(); };
  const step = (obj, key, min, max) => h('div', { class: 'an-stp' },
    h('button', { type: 'button', class: 'btn', onclick: () => { obj[key] = Math.max(min, obj[key] - 1); again(); } }, '−'),
    h('b', { class: 'num', text: obj[key] }),
    h('button', { type: 'button', class: 'btn', onclick: () => { obj[key] = Math.min(max, obj[key] + 1); again(); } }, '+'));
  const lim = (label, sub, a, b) => h('div', { class: 'an-lim' }, h('div', {}, h('b', { text: label }), h('small', { text: sub })),
    h('div', { class: 'an-lim-r' }, h('small', { text: 'مجاني' }), step(W.limits[a], 'free', 1, 20), h('small', { text: 'مشترك ★' }), step(W.limits[a], 'paid', 1, 30)));
  const toggle = (arr, v) => { const i = arr.indexOf(v); i >= 0 ? arr.splice(i, 1) : arr.push(v); again(); };
  const sw = (on, fn) => { const i = h('input', { type: 'checkbox', checked: on }); i.addEventListener('change', () => fn(i.checked)); return h('label', { class: 'switch' }, i, h('span', { class: 'track' })); };
  const save = async () => {
    W.limits.favs.paid = Math.max(W.limits.favs.paid, W.limits.favs.free);
    W.limits.countries.paid = Math.max(W.limits.countries.paid, W.limits.countries.free);
    Object.assign(d, { domains: W.domains, countries: W.countries, limits: W.limits, premium: W.premium, ask: W.ask });
    try { await Cloud.admin.newsSetSettings(d); toast('حُفظت المجالات والدول ✓ — توصل للمستخدمين مع فتح الأخبار', { type: 'success' }); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  const uid = (p) => p + Date.now().toString(36).slice(-5);

  const domRow = (x, i) => {
    const ic = h('input', { class: 'input an-ic', value: x.ic, maxlength: 4, 'aria-label': 'أيقونة' }); ic.addEventListener('input', () => (x.ic = ic.value.trim() || '📰'));
    const nm = h('input', { class: 'input', value: x.name, maxlength: 30, 'aria-label': 'الاسم' }); nm.addEventListener('input', () => (x.name = nm.value.trim() || x.name));
    const open = W.open === x.id;
    const addSub = h('input', { class: 'input', placeholder: 'اهتمام جديد…', maxlength: 30 });
    const doAdd = () => { const v = addSub.value.trim(); if (!v) return; x.subs.push([uid('t'), v]); again(); };
    addSub.addEventListener('keydown', (e) => { if (e.key === 'Enter') doAdd(); });
    return h('div', { class: `an-dom${x.on ? '' : ' off'}` },
      h('div', { class: 'an-dom-h' },
        h('div', { class: 'an-mv' }, h('button', { type: 'button', class: 'btn', disabled: i === 0, onclick: () => mv(W.domains, i, -1) }, '▲'), h('button', { type: 'button', class: 'btn', disabled: i === W.domains.length - 1, onclick: () => mv(W.domains, i, 1) }, '▼')),
        ic, nm,
        h('button', { type: 'button', class: 'btn', onclick: () => { W.open = open ? '' : x.id; again(); } }, `${UI.n(x.subs.length)} اهتمامات ${open ? '▴' : '▾'}`),
        sw(x.on, (v) => { x.on = v; again(); })),
      open ? h('div', { class: 'an-subs' },
        ...x.subs.map((s, j) => h('span', { class: 'chip' }, s[1], h('button', { type: 'button', class: 'an-x', 'aria-label': 'حذف', onclick: () => { x.subs.splice(j, 1); again(); } }, '✕'))),
        h('div', { class: 'an-subadd' }, addSub, h('button', { type: 'button', class: 'btn', onclick: doAdd }, '＋ أضف')),
        x.id.startsWith('d') && !NewsCfg.DOMAINS.some((y) => y.id === x.id) ? h('button', { type: 'button', class: 'btn an-no', onclick: () => { W.domains.splice(i, 1); again(); } }, 'حذف المجال') : null) : null);
  };
  const ctyRow = (c, i) => h('div', { class: `an-cty${c.on ? '' : ' off'}` },
    h('div', { class: 'an-mv' }, h('button', { type: 'button', class: 'btn', disabled: i === 0, onclick: () => mv(W.countries, i, -1) }, '▲'), h('button', { type: 'button', class: 'btn', disabled: i === W.countries.length - 1, onclick: () => mv(W.countries, i, 1) }, '▼')),
    h('span', { class: 'an-fl', text: c.flag }), h('b', { text: c.name }), h('small', { class: 'ltr', text: c.id }),
    sw(c.on, (v) => { c.on = v; again(); }));
  const nf = h('input', { class: 'input an-ic', placeholder: '🏳️', maxlength: 6 });
  const nn = h('input', { class: 'input', placeholder: 'اسم الدولة', maxlength: 30 });
  const nc = h('input', { class: 'input ltr an-code', placeholder: 'رمز (مثل tr)', maxlength: 4 });
  const addCty = () => {
    const id = nc.value.trim().toLowerCase();
    if (!/^[a-z]{2,4}$/.test(id) || !nn.value.trim()) return toast('اكتب اسم الدولة ورمزها بالإنجليزي (حرفين)');
    if (W.countries.some((c) => c.id === id)) return toast('الدولة موجودة');
    W.countries.push({ id, flag: nf.value.trim() || '🏳️', name: nn.value.trim(), on: true }); again();
  };
  const appsList = Object.entries(Market.APPS).filter(([k]) => k !== 'today');
  body.replaceChildren(
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: 'الحدود والاشتراك' }),
      h('p', { class: 'hint', text: 'المجاني يختار مجالاته ودولته بحرية لين الحد. المشترك يزيد العدد، ويرتّب مفضلاته، ويختار اهتمامات دقيقة داخل كل مجال.' }),
      lim('المجالات المفضلة', 'كم مجال يتابع', 'favs'), lim('الدول', 'دولته + دول إضافية', 'countries'),
      h('div', { class: 'field' }, h('span', { text: 'مزايا المشتركين تجي مع أي اشتراك؟' }),
        h('div', { class: 'an-cats' }, ...appsList.map(([k, a]) => h('button', { type: 'button', class: `chip${W.premium.apps.includes(k) ? ' on' : ''}`, onclick: () => toggle(W.premium.apps, k) }, k === 'all' ? '👑 الباقة الكاملة' : a.short))),
        h('div', { class: 'an-cats', style: { marginTop: '8px' } }, ...Object.entries(Market.PLAN_NAME).map(([k, l]) => h('button', { type: 'button', class: `chip${W.premium.plans.includes(k) ? ' on' : ''}`, onclick: () => toggle(W.premium.plans, k) }, l))),
        h('small', { class: 'hint', text: 'الاشتراك اللي تمنحه يدوياً من «المستخدمين» يفتحها دائماً، وفترة التجربة كذلك.' })),
      h('div', { class: 'switch-row' }, h('span', {}, h('b', { text: 'اطلب الدولة والاهتمامات أول ما يفتح الأخبار' }), h('small', { text: 'إذا أوقفته: دولته من جواله وأول ٣ مجالات تلقائياً' })), sw(W.ask, (v) => (W.ask = v)))),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: `المجالات (${UI.n(W.domains.filter((x) => x.on).length)} مفعّل)` }),
      h('p', { class: 'hint', text: 'رتّبها بالأسهم — بنفس الترتيب تظهر للمستخدم. اضغط «اهتمامات» لتعديل الاهتمامات الفرعية.' }),
      h('div', { class: 'an-doms' }, ...W.domains.map(domRow)),
      h('button', { type: 'button', class: 'btn btn-block', onclick: () => { const id = uid('d'); W.domains.push({ id, ic: '📰', name: 'مجال جديد', on: true, subs: [] }); W.open = id; again(); } }, '＋ مجال جديد')),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: `الدول (${UI.n(W.countries.filter((x) => x.on).length)} مفعّلة)` }),
      h('p', { class: 'hint', text: 'المستخدم يختار دولته منها (ونقترح له دولته من جواله). الأخبار المحلية توصل بس للي اختار دولتها.' }),
      h('div', { class: 'an-ctys' }, ...W.countries.map(ctyRow)),
      h('div', { class: 'an-subadd' }, nf, nn, nc, h('button', { type: 'button', class: 'btn', onclick: addCty }, '＋ دولة'))),
    h('div', { class: 'an-bar' }, h('button', { type: 'button', class: 'btn', onclick: () => { AN.dw = null; delete d.domains; delete d.countries; delete d.limits; delete d.premium; again(); } }, 'رجّع الافتراضي'),
      h('button', { type: 'button', class: 'btn btn-primary', onclick: save }, 'حفظ المجالات والدول')));
  UI.digitize(body);
}

/* ---------- 🎯 الفلتر والأولويات (1.19) ---------- */
const AN_BLOCK = [['politics', '🏛️ سياسة', 'رؤساء، وزراء، انتخابات، برلمانات، عقوبات'], ['war', '⚔️ حروب ونزاعات', 'غارات، جيوش، اشتباكات، هدنة'], ['crime', '🚔 جرائم', 'قتل، اعتقال، سرقة، سجون'], ['celeb', '🎭 مشاهير وفضائح', 'طلاق، فضائح، قيل وقال'], ['disaster', '🌪️ كوارث وحوادث', 'زلازل، فيضانات، حوادث']];
const AN_W = [[0, 'ما أبيه'], [1, 'قليل'], [2, 'عادي'], [3, 'كثير']];
const AN_WDEF = { ai: 3, tech: 3, news: 0 };
function paintAnFilter(body) {
  const d = AN.settings.data;
  const doms = NewsCfg.from(d).domains || [];
  const F = d.filter = { block: ['politics', 'war', 'crime', 'celeb'], words: '', weights: {}, featured: true, ...(d.filter || {}) };
  doms.forEach((x) => { if (F.weights[x.id] == null) F.weights[x.id] = AN_WDEF[x.id] ?? 1; });
  const again = () => paintAnFilter(body);
  const words = h('textarea', { class: 'input textarea', rows: 3, maxlength: 3000, placeholder: 'كلمات تمنعها — افصل بينها بفاصلة. مثال: كريبتو، مراهنات، bitcoin' });
  words.value = F.words || ''; words.addEventListener('input', () => { F.words = words.value; });
  const tot = doms.reduce((a, x) => a + (Number(F.weights[x.id]) || 0), 0) || 1;
  const save = async (btn) => {
    btn.disabled = true;
    try { await Cloud.admin.newsSetSettings(d); toast('انحفظ الفلتر ✓ — يطبّق من السحب الجاي', { type: 'success' }); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    btn.disabled = false;
  };
  const clean = async (btn) => {
    if (!(await confirmSheet({ title: 'تنظيف الأخبار الحالية؟', text: 'أي خبر منشور أو ينتظر المراجعة (آخر ٤٥ يوم) ينطبق عليه الفلتر ينتقل لـ«المرفوضة». المثبّت ما ينلمس. احفظ الفلتر أول.', ok: 'نظّف' }))) return;
    btn.disabled = true;
    try { await Cloud.admin.newsSetSettings(d); const r = await Cloud.admin.newsRun('clean'); toast(r.cleaned ? `🧹 انشال ${UI.n(r.cleaned)} خبر من ${UI.n(r.checked)}` : 'كل الأخبار الحالية نظيفة 👌', { type: 'success' }); refreshAnStats(); }
    catch (e) { toast(/clean|unknown|action/i.test(Cloud.msg(e)) ? 'حدّث دالة news-fetch في Supabase أول' : Cloud.msg(e), { type: 'error' }); }
    btn.disabled = false;
  };
  body.replaceChildren(
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '🚫 مواضيع ما تبيها' }),
      h('p', { class: 'hint', text: 'تنشال قبل الحفظ من كل المصادر (حتى العربية المباشرة) — بالكلمات، مجاناً بدون Gemini. وGemini بعد يرفضها في الأخبار الأجنبية.' }),
      ...AN_BLOCK.map(([k, n, sub]) => { const on = F.block.includes(k); const i = h('input', { type: 'checkbox', checked: on }); i.addEventListener('change', () => { F.block = i.checked ? [...new Set([...F.block, k])] : F.block.filter((x) => x !== k); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: n }), h('small', { text: sub })), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); }),
      h('label', { class: 'field' }, h('span', { text: 'كلمات إضافية تمنعها' }), words)),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '📊 وش يسحب أكثر' }),
      h('p', { class: 'hint', text: 'كل مجال ياخذ من السحب على قد أولويته. «ما أبيه» = ما يسحب منه أبد. الافتراضي: الذكاء الاصطناعي والتقنية «كثير»، والأخبار العامة «ما أبيه».' }),
      h('div', { class: 'an-wts' }, ...doms.map((x) => { const w = Number(F.weights[x.id]) || 0, pct = Math.round((w / tot) * 100);
        return h('div', { class: `an-wt${w ? '' : ' off'}` }, h('b', { text: x.name }),
          h('div', { class: 'seg seg-4 an-wseg' }, ...AN_W.map(([v, l]) => h('label', {}, h('input', { type: 'radio', name: 'anw-' + x.id, checked: w === v, onchange: () => { F.weights[x.id] = v; again(); } }), h('span', { text: l })))),
          h('small', { class: 'num', text: w ? `≈ ${UI.n(pct)}٪` : '—' })); }))),
    h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '⭐ الأخبار المميزة' }),
      (() => { const i = h('input', { type: 'checkbox', checked: F.featured !== false }); i.addEventListener('change', () => { F.featured = i.checked; }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'Gemini يعلّم الخبر المهم بـ«⭐ مميز»' }), h('small', { text: 'إطلاق كبير، أداة مفيدة، اكتشاف — تطلع بعلامة ⭐ وفيه تبويب «المميزة» في التطبيق' })), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); })()),
    h('div', { class: 'row-2' },
      h('button', { type: 'button', class: 'btn btn-primary', onclick: (e) => save(e.currentTarget) }, '💾 حفظ الفلتر'),
      h('button', { type: 'button', class: 'btn', onclick: (e) => clean(e.currentTarget) }, '🧹 طبّقه على الأخبار الحالية')));
  UI.digitize(body);
}
