/* NOBLE — لعبة «كلمة اليوم / Word of the Day» داخل قسم الألعاب (عربي + English، تشتغل بدون نت) */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const WCFG = () => ({ ...GCfg.DEFAULTS.word, ...(GCfg.get().word || {}) });
const wLangs = () => { const l = (WCFG().langs || ['ar', 'en']).filter((x) => x === 'ar' || x === 'en'); return l.length ? l : ['ar']; };
function wState(g, lang) {
  const w = g.word && typeof g.word === 'object' ? g.word : {};
  const day = Words.dayNum();
  const cur = w[lang] && w[lang].d === day ? w[lang] : { d: day, g: [], end: 0 };
  const st = { played: 0, wins: 0, streak: 0, best: 0, last: 0, dist: [0, 0, 0, 0, 0, 0], ...((w.stats || {})[lang] || {}) };
  return { cur, st };
}
/* بطاقة اللعبة في الصفحة الرئيسية للألعاب */
function wordCard(C, g) {
  const lang = wLangs()[0];
  const { cur } = wState(g, lang);
  const meta = cur.end === 1 ? `✅ حلّيتها اليوم بـ ${UI.n(cur.g.length)}` : cur.end === 2 ? '⏳ ترجع بكرة بكلمة جديدة' : cur.g.length ? `✍️ ${UI.n(Words.TRIES - cur.g.length)} محاولات باقية` : '🆕 كلمة جديدة اليوم';
  return h('button', { type: 'button', class: 'g-card gc-word', onclick: () => openWord(lang) },
    h('span', { class: 'gc-art' }, ...['ك', 'ل', 'م', 'ة'].map((ch, i) => h('i', { class: `gw-t ${['g', 'y', 'g', 'b'][i]}`, text: ch }))),
    GCfg.mult('word') > 1 ? h('span', { class: 'gc-mult num', text: `×${GCfg.mult('word')}` }) : null,
    h('b', { text: C.word.name }), h('small', { text: C.word.desc }),
    h('span', { class: 'gc-meta num', text: meta }));
}

function openWord(lang) {
  const C = WCFG();
  if (!wLangs().includes(lang)) lang = wLangs()[0];
  const T = Words.today(lang, C);
  if (!T) { toast('ما فيه كلمات حالياً'); return; }
  const en = lang === 'en';
  let { cur, st } = wState(gstate(), lang);
  let typed = [];
  let busy = false;
  const L = en ? { tries: 'tries left', enter: 'Enter', short: 'Not enough letters', win: 'Brilliant! 🎉', lose: 'The word was', next: 'Next word in', share: 'Share', played: 'Played', wins: 'Win %', streak: 'Streak', best: 'Best', dist: 'Guess distribution' }
    : { tries: 'محاولات باقية', enter: 'إدخال', short: 'الكلمة ناقصة حروف', win: 'كفو! 🎉', lose: 'الكلمة كانت', next: 'الكلمة الجاية بعد', share: 'شارك نتيجتك', played: 'لعبت', wins: 'نسبة الفوز', streak: 'متتالية', best: 'أفضل سلسلة', dist: 'توزيع المحاولات' };
  const PRAISE = en ? ['Genius!', 'Magnificent!', 'Impressive!', 'Splendid!', 'Great!', 'Phew!'] : ['عبقري! 🤯', 'خرافي! 🔥', 'مبهر! 👏', 'رائع! ✨', 'زين! 👍', 'على الحافة! 😅'];

  openScreen((el) => {
    const grid = h('div', { class: `wd-grid ${en ? 'ltr' : ''}`, dir: en ? 'ltr' : 'rtl' });
    const kb = h('div', { class: 'wd-kb', dir: en ? 'ltr' : 'rtl' });
    const msg = h('div', { class: 'wd-msg', role: 'status' });
    const tries = h('span', { class: 'chip g-chip num' });
    const endBox = h('div', { class: 'wd-end' });
    const langs = wLangs().length > 1 ? h('div', { class: 'chips wd-langs' }, ...wLangs().map((l) => h('button', { type: 'button', class: `chip${l === lang ? ' on' : ''}`, onclick: () => l !== lang && openWord(l) }, l === 'en' ? 'English' : 'عربي'))) : null;
    const say = (t, ms = 1600) => { msg.textContent = t; msg.classList.add('on'); clearTimeout(say.t); say.t = setTimeout(() => msg.classList.remove('on'), ms); };

    const paintGrid = (reveal = -1) => {
      RC(grid, ...Array.from({ length: Words.TRIES }, (_, r) => {
        const word = cur.g[r];
        const res = word ? Words.score(word, T.key) : null;
        const chars = word ? [...word] : r === cur.g.length && !cur.end ? typed : [];
        return h('div', { class: `wd-row${r === cur.g.length && !cur.end && typed.length ? ' cur' : ''}` }, ...Array.from({ length: Words.LEN }, (_, i) =>
          h('span', { class: `wd-t${chars[i] ? ' full' : ''}${res ? ' ' + res[i] : ''}${r === reveal ? ' flip' : ''}`, style: r === reveal ? { animationDelay: `${i * 0.18}s` } : null, text: chars[i] || '' })));
      }));
      tries.textContent = `${UI.n(Words.TRIES - cur.g.length)} ${L.tries}`;
    };
    const paintKb = () => {
      const ks = Words.keyStates(cur.g, T.key);
      RC(kb, ...Words.KEYS[lang].map((row) => h('div', { class: 'wd-kr' }, ...row.map((k) =>
        h('button', { type: 'button', class: `wd-k${k === '⏎' || k === '⌫' ? ' wide' : ''}${ks[k] ? ' ' + ks[k] : ''}`, 'aria-label': k === '⏎' ? L.enter : k === '⌫' ? 'حذف' : k, onclick: () => press(k) }, k === '⏎' ? L.enter : k)))));
    };
    const paintEnd = () => {
      if (!cur.end) { RC(endBox, ); return; }
      const won = cur.end === 1;
      const pct = st.played ? Math.round((st.wins / st.played) * 100) : 0;
      const max = Math.max(1, ...st.dist);
      const left = () => { const n = new Date(); const t = new Date(n.getFullYear(), n.getMonth(), n.getDate() + 1) - n; const hh = Math.floor(t / 36e5), mm = Math.floor((t % 36e5) / 6e4); return `${UI.n(hh)}:${UI.n(String(mm).padStart(2, '0'))}`; };
      const cd = h('b', { class: 'num', text: left() });
      const iv = setInterval(() => { if (!cd.isConnected) return clearInterval(iv); cd.textContent = left(); }, 30000);
      RC(endBox, 
        h('div', { class: `wd-res ${won ? 'won' : 'lost'}` },
          h('b', { text: won ? PRAISE[cur.g.length - 1] : `${L.lose}: ` }, won ? null : h('span', { class: 'wd-ans', text: T.word })),
          won ? h('span', { class: 'wd-ans', text: T.word }) : null,
          cur.pts ? h('small', { class: 'num', text: en ? `+${cur.pts} points` : `+${UI.n(cur.pts)} نقطة` }) : null),
        h('div', { class: 'xo-stats wd-stats' }, ...[[st.played, L.played], [pct + '%', L.wins], [st.streak, L.streak], [st.best, L.best]].map(([n, l]) => h('div', {}, h('b', { class: 'num', text: typeof n === 'number' ? UI.n(n) : n }), h('small', { text: l })))),
        h('div', { class: 'wd-dist' }, h('small', { text: L.dist }), ...st.dist.map((n, i) => h('div', { class: `wd-bar${won && cur.g.length === i + 1 ? ' me' : ''}` }, h('span', { class: 'num', text: UI.n(i + 1) }), h('i', { style: { width: `${Math.max(8, (n / max) * 100)}%` } }, h('em', { class: 'num', text: UI.n(n) }))))),
        h('div', { class: 'wd-next' }, h('small', { text: L.next }), cd),
        h('button', { type: 'button', class: 'btn btn-primary wd-share', onclick: share }, icon('share', { size: 16 }), L.share));
    };
    async function share() {
      const text = Words.shareText(lang, T.day, cur.g, T.key, cur.end === 1, en ? C.nameEn : C.name) + '\n' + (Content.get('shareUrl') || 'NOBLE');
      if (Platform.isNative) { try { await Platform.plugin('Share').share({ text, dialogTitle: L.share }); return; } catch { return; } }
      if (navigator.share) { try { await navigator.share({ text }); return; } catch { /* المستخدم ألغى */ } }
      try { await navigator.clipboard.writeText(text); toast(en ? 'Copied ✓' : 'نُسخت النتيجة ✓', { type: 'success' }); } catch { toast(text); }
    }
    function press(k) {
      if (cur.end || busy) return;
      if (k === '⌫') { typed.pop(); paintGrid(); return; }
      if (k === '⏎') return submit();
      if (!Words.okChar(lang, k) || typed.length >= Words.LEN) return;
      typed.push(k); buzz('light'); paintGrid();
    }
    async function submit() {
      if (typed.length < Words.LEN) { say(L.short); const row = grid.children[cur.g.length]; row?.classList.add('shake'); setTimeout(() => row?.classList.remove('shake'), 500); return; }
      busy = true;
      const word = typed.join('');
      cur = { ...cur, g: [...cur.g, word] };
      typed = [];
      const won = word === T.key, lost = !won && cur.g.length >= Words.TRIES;
      if (won || lost) cur.end = won ? 1 : 2;
      paintGrid(cur.g.length - 1);
      await new Promise((r) => setTimeout(r, Words.LEN * 180 + 350));
      let pts = 0;
      if (cur.end) {
        st = { ...st, played: st.played + 1 };
        if (won) {
          st.wins++; st.dist = [...st.dist]; st.dist[cur.g.length - 1]++;
          st.streak = st.last === T.day - 1 ? st.streak + 1 : 1; st.best = Math.max(st.best, st.streak); st.last = T.day;
          pts = Number((C.pts || [])[cur.g.length - 1]) || 0;
        } else st.streak = 0;
      }
      const snap = { ...cur }, sst = { ...st };
      const save = (x) => { x.word = x.word && typeof x.word === 'object' ? x.word : {}; x.word[lang] = snap; x.word.stats = { ...(x.word.stats || {}), [lang]: sst }; };
      try {
        if (pts > 0) {
          const got = await addPoints('word', pts, { mut: (x, give) => { save(x); give('word_first'); if (sst.streak >= 7) give('word_7'); } });
          cur.pts = got; snap.pts = got; gsave((x) => { if (x.word?.[lang]) x.word[lang].pts = got; });
        } else await gsave(save);
      } catch (e) { console.warn('word save', e); }
      if (typeof markActive === 'function') { markActive('game'); if (won) markActive('word'); }
      busy = false;
      if (won) { buzz('success'); say(PRAISE[cur.g.length - 1], 2200); }
      else if (lost) { buzz('error'); say(`${L.lose}: ${T.word}`, 3000); }
      paintKb(); paintEnd();
      if (cur.end) setTimeout(() => endBox.scrollIntoView({ behavior: 'smooth', block: 'center' }), 400);
    }
    const onKey = (e) => {
      if (e.ctrlKey || e.metaKey || e.altKey || !document.body.contains(el)) return;
      if (e.key === 'Enter') { e.preventDefault(); press('⏎'); return; }
      if (e.key === 'Backspace') { e.preventDefault(); press('⌫'); return; }
      const ch = e.key.length === 1 ? (en ? e.key.toLowerCase() : Words.norm('ar', e.key)) : '';
      if (ch && Words.okChar(lang, ch)) { e.preventDefault(); press(ch); }
    };
    document.addEventListener('keydown', onKey);
    GS.cleanup = () => document.removeEventListener('keydown', onKey);

    el.append(h('div', { class: 'g-wrap wd-wrap' },
      gHead(en ? (C.nameEn || 'Word of the Day') : C.name, tries),
      langs,
      h('p', { class: 'wd-help', text: en ? 'Guess the 5-letter word in 6 tries. 🟩 right spot · 🟨 wrong spot · ⬛ not in word.' : 'خمّن كلمة من ٥ حروف بـ ٦ محاولات. 🟩 بمكانه · 🟨 موجود بمكان ثاني · ⬛ مو موجود. (أ إ آ = ا)' }),
      msg, grid, kb, endBox));
    paintGrid(); paintKb(); paintEnd();
  });
  GS.onBack = closeScreen;
}
