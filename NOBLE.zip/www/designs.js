/* NOBLE — قسم التصاميم: تهاني ومناسبات وخلفيات — المستخدم يختار قالب، يكتب اسمه، ويحفظ أو يشارك
 * القوالب: افتراضية مرسومة بالكود (تشتغل بدون نت) + قوالب الإدارة (صور من Storage تنحفظ على الجهاز بعد أول فتح)
 */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const DS = { cat: '', list: null, meta: {}, loading: false, at: 0, thumbs: new Map() };
const DS_KEY = 'nw:designs';

function dsCache(v) {
  if (v) { try { localStorage.setItem(DS_KEY, JSON.stringify(v)); } catch { /* لا شيء */ } return v; }
  try { return JSON.parse(localStorage.getItem(DS_KEY) || 'null'); } catch { return null; }
}
const dsCfg = () => DesignKit.cfg(DS.meta || {});
const dsCountry = () => (typeof newsPrefs === 'function' ? newsPrefs().home : '') || (typeof NewsCfg !== 'undefined' ? NewsCfg.detectCountry() : '') || 'sa';
/* كل القوالب: قوالب الإدارة أولاً ثم الافتراضية */
function dsAll() {
  const cfg = dsCfg();
  const remote = (DS.list || []).filter((t) => !t.kind || t.kind === 'tpl').map((t) => ({ ...t, id: 'r' + t.id, rid: t.id, slots: Array.isArray(t.slots) ? t.slots : [] }));
  const nat = DesignKit.NATIONAL[dsCountry()];
  const builtin = cfg.builtin.map((t) => (t.cat === 'national' ? { ...t, flag: nat ? nat[1] : '🏳️' } : t));
  return [...remote, ...builtin];
}
const dsOcc = (id) => dsCfg().occasions.find((o) => o.id === id);
const dsSeasonal = () => dsCfg().occasions.filter((o) => DesignKit.inSeason(o.season, { country: dsCountry() })).map((o) => o.id);
/* مقترح اليوم: قالب الإدارة المميّز ← قالب المناسبة الحالية ← قالب ثابت لليوم */
function dsFeatured() {
  const all = dsAll().filter((t) => !t.premium || dsPremium());
  if (!all.length) return null;
  const cfg = dsCfg();
  const fixed = cfg.featured && all.find((t) => String(t.rid) === String(cfg.featured) || t.id === String(cfg.featured));
  if (fixed) return fixed;
  const seas = dsSeasonal();
  const pool = all.filter((t) => seas.includes(t.cat));
  const day = Math.floor(Date.now() / 864e5);
  const list = pool.length ? pool : all;
  return list[day % list.length];
}
const dsPremium = () => typeof Pro === 'undefined' || Pro.has('designs.premium');

async function loadDesigns(force) {
  if (!DS.list) { const c = dsCache(); if (c) { DS.list = c.items || []; DS.meta = c.meta || {}; } }
  renderDesigns();
  if (!Cloud.enabled || DS.loading || (!force && Date.now() - DS.at < 45e3)) return;
  DS.loading = true;
  try {
    const r = await Cloud.designsList();
    if (r) { DS.list = r.items || []; DS.meta = r.meta || {}; dsCache({ items: DS.list, meta: DS.meta }); DS.thumbs.clear(); }
    DS.at = Date.now();
  } catch { /* نستخدم المحفوظ */ }
  DS.loading = false;
  if (S.tab === 'designs') renderDesigns();
}

function dsThumb(t, m = null) {
  const box = h('div', { class: 'ds-th', style: { aspectRatio: (DesignKit.SIZES[t.size] || DesignKit.SIZES.post).slice(0, 2).join('/') } });
  const key = t.id + ':' + (t.updated || '');
  const put = (url) => RC(box, h('img', { src: url, alt: t.title || '', loading: 'lazy' }));
  if (DS.thumbs.has(key)) put(DS.thumbs.get(key));
  else DesignKit.render(t, {}, { width: 360, sign: dsSign() }).then((cv) => { try { const u = cv.toDataURL('image/jpeg', 0.82); DS.thumbs.set(key, u); put(u); } catch { /* صورة بدون CORS */ } });
  return box;
}

function renderDesigns() {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  const root = $('#ds-root');
  if (!root || !S.vault) return;
  const cfg = dsCfg();
  const seas = dsSeasonal();
  const occs = [...cfg.occasions].sort((a, b) => seas.includes(b.id) - seas.includes(a.id));
  const all = dsAll();
  const list = DS.cat === 'mine' ? null : DS.cat ? all.filter((t) => t.cat === DS.cat) : all;
  const fe = dsFeatured();
  const mine = dsMine();
  const chip = (k, txt, hot) => h('button', { type: 'button', class: `chip${DS.cat === k ? ' on' : ''}`, onclick: () => { DS.cat = k; renderDesigns(); } }, txt, hot ? h('i', { class: 'ds-hot', text: 'الحين' }) : null);
  // «🎨 قوالب» أو «🎬 استوديو» (1.16)
  if (DS.mode == null) { try { DS.mode = localStorage.getItem('nw:ds-mode') || 'tpl'; } catch { DS.mode = 'tpl'; } }
  const hasStudio = typeof Studio !== 'undefined' && cfg.studio !== false;
  const modes = hasStudio ? h('div', { class: 'ds-modes' }, ...[['tpl', '🎨 قوالب'], ['studio', '🎬 استوديو']].map(([k, l]) => h('button', { type: 'button', class: DS.mode === k ? 'on' : '', onclick: () => { DS.mode = k; try { localStorage.setItem('nw:ds-mode', k); } catch { /* لا شيء */ } renderDesigns(); } }, l, k === 'studio' ? h('em', { text: 'جديد' }) : null))) : null;
  const top = h('div', { class: 'ds-top' }, h('div', {}, h('h1', { class: 'view-title', text: DS.mode === 'studio' && hasStudio ? 'استوديو NOBLE' : cfg.title }), h('small', { text: DS.mode === 'studio' && hasStudio ? 'حرّك وصمّم بحرية كاملة — صورة أو فيديو' : cfg.sub })));
  if (hasStudio && DS.mode === 'studio') { RC(root, top, modes); Studio.renderHome(root); UI.digitize(root); return; }
  RC(root, 
    top, modes,
    dsNewsBar(),
    cfg.greet !== false && typeof openGreeting === 'function' && !DS.cat ? dsGreetHero() : null,
    fe && !DS.cat ? h('button', { type: 'button', class: 'ds-hero', onclick: () => openDesign(fe) }, dsThumb(fe),
      h('div', { class: 'ds-hero-t' }, h('span', { class: 'ds-badge', text: seas.includes(fe.cat) ? `${dsOcc(fe.cat)?.ic || '✨'} مناسبة الحين` : '✨ مقترح اليوم' }),
        h('b', { text: fe.title || dsOcc(fe.cat)?.name || 'تصميم' }), h('small', { text: 'اضغط واكتب اسمك — جاهز للمشاركة' }))) : null,
    h('nav', { class: 'chips ds-chips' }, chip('', '✨ الكل'), mine.length ? chip('mine', `🗂 تصاميمي (${UI.n(mine.length)})`) : null,
      ...occs.filter((o) => all.some((t) => t.cat === o.id)).map((o) => chip(o.id, `${o.id === 'national' ? (DesignKit.NATIONAL[dsCountry()]?.[1] || o.ic) : o.ic} ${o.name}`, seas.includes(o.id)))),
    DS.cat === 'mine'
      ? dsMineGrid(all)
      : list.length ? h('div', { class: 'ds-grid' }, ...list.map((t) => h('button', { type: 'button', class: 'ds-card', onclick: () => openDesign(t) }, dsThumb(t),
        t.premium ? h('span', { class: 'ds-pro', text: '★' }) : null,
        h('span', { class: 'ds-cap', text: t.title || dsOcc(t.cat)?.name || '' }))))
        : h('div', { class: 'empty' }, h('b', { text: 'ما فيه قوالب هنا بعد' }), h('small', { text: 'ارجع قريب — نضيف تصاميم جديدة باستمرار.' })));
  UI.digitize(root);
}

/* «💌 بطاقة تهنئة بخطوات» (1.17) */
function dsGreetHero() {
  const cv = h('canvas', { width: 330, height: 412 });
  requestAnimationFrame(() => { try { const big = document.createElement('canvas'); const seas = dsSeasonal(); const occ = seas.find((x) => dsOcc(x)) || 'eidf';
    grDraw(big, { ...grDefaults(occ), size: 'post' }, { thumb: true }); cv.getContext('2d').drawImage(big, 0, 0, 330, 412); } catch { /* لا شيء */ } });
  return h('button', { type: 'button', class: 'ds-greet', onclick: () => openGreeting() }, h('span', { class: 'new', text: 'جديد' }),
    h('div', {}, h('b', { text: '💌 بطاقة تهنئة بخطوات' }), h('small', { text: 'اختر المخطوطة والخلفية والإطار، اكتب كلمتك… وجاهزة للمشاركة خلال دقيقة' }), h('span', { class: 'pill', text: 'ابدأ الآن ←' })), cv);
}

/* ---------- تصاميمي: ترجع لأي تصميم وتعدّله (الإعدادات مشفّرة في الخزنة، والصورة على جهازك فقط) ---------- */
const dsMine = () => (Array.isArray(S.vault?.designsMine) ? S.vault.designsMine : []);
const DSDB = {
  db: null,
  open() {
    if (this.db) return this.db;
    this.db = new Promise((res, rej) => { try { const r = indexedDB.open('noble-designs-local', 1); r.onupgradeneeded = () => r.result.createObjectStore('photos'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); } catch (e) { rej(e); } });
    return this.db;
  },
  async run(mode, fn) { const db = await this.open(); return new Promise((res, rej) => { const tx = db.transaction('photos', mode); const q = fn(tx.objectStore('photos')); tx.oncomplete = () => res(q?.result); tx.onerror = () => rej(tx.error); }); },
  get(id) { return this.run('readonly', (st) => st.get(id)).catch(() => null); },
  put(id, v) { return this.run('readwrite', (st) => st.put(v, id)).catch(() => null); },
  del(id) { return this.run('readwrite', (st) => st.delete(id)).catch(() => null); },
};
async function dsRemember(t, values, style, ed = {}) {
  const id = ed.id || (ed.id = 'd' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5));
  const layers = (ed.layers || []).filter((L) => /^https?:|^img\//.test(L.url || ''));
  const libPhoto = ed.photo && (ed.photo.lib || /^https?:/.test(ed.photo.url || ''));
  const photo = ed.photo ? { ...ed.photo, url: libPhoto ? ed.photo.url : undefined } : null;
  if (ed.photo?.url && !libPhoto) await DSDB.put(id, ed.photo.url); else await DSDB.del(id);
  // صور العناصر الإضافية (شعار/صورتك) تبقى على الجهاز فقط
  const extras = (ed.extras || []).map((E) => (E.url && /^data:|^blob:/.test(E.url) ? { ...E, url: undefined, local: true } : { ...E }));
  for (const E of ed.extras || []) if (E.url && /^data:|^blob:/.test(E.url)) await DSDB.put(id + ':e:' + E.id, E.url);
  await commit((v) => {
    const list = Array.isArray(v.designsMine) ? v.designsMine : [];
    const item = { id, tpl: t.id, size: ed.size || t.size, values, style, layers, photo, overlay: ed.overlay || null, extras, grad: ed.grad || null, deco: ed.deco || null, noSign: !!ed.noSign, noWm: !!ed.noWm, azkar: !!ed.azkar, motion: !!ed.motion, bgAnim: ed.bgAnim, dur: ed.dur, q: ed.q, sound: ed.sound?.url ? { id: ed.sound.id, url: ed.sound.url, title: ed.sound.title, vol: ed.sound.vol, react: ed.sound.react, premium: ed.sound.premium } : null, at: Date.now() };
    v.designsMine = [item, ...list.filter((x) => x.id !== id)].slice(0, 40);
  });
  DS.thumbs.forEach((_, k) => k.includes(':m' + id) && DS.thumbs.delete(k));
  return id;
}
async function dsExtrasLoad(m) { return Promise.all((m.extras || []).map(async (E) => (E.local ? { ...E, url: await DSDB.get(m.id + ':e:' + E.id) } : E))).then((a) => a.filter((E) => E.type === 'text' || E.url)); }
async function dsForget(id) {
  const m = (dsMine() || []).find((x) => x.id === id);
  for (const E of m?.extras || []) if (E.local) await DSDB.del(id + ':e:' + E.id);
  await DSDB.del(id);
  await commit((v) => { v.designsMine = (v.designsMine || []).filter((x) => x.id !== id); });
}
/* مصغّرة «تصاميمي» بنفس تعديلات المستخدم */
function dsMineThumb(t, m) {
  const size = m.size || t.size;
  const box = h('div', { class: 'ds-th', style: { aspectRatio: (DesignKit.SIZES[size] || DesignKit.SIZES.post).slice(0, 2).join('/') } });
  const key = t.id + ':m' + (m.id || m.at) + ':' + m.at;
  const put = (url) => RC(box, h('img', { src: url, alt: '', loading: 'lazy' }));
  if (DS.thumbs.has(key)) { put(DS.thumbs.get(key)); return box; }
  (async () => {
    const url = m.photo?.url || (m.photo && m.id ? await DSDB.get(m.id) : null);
    const cv = await DesignKit.render({ ...t, size }, m.values || {}, { width: 360, style: m.style || {}, layers: m.layers || [], photo: m.photo && url ? { ...m.photo, url } : null, overlay: m.overlay, sign: dsSign(m.noSign), extras: await dsExtrasLoad(m), grad: m.grad, deco: m.deco });
    try { const u = cv.toDataURL('image/jpeg', 0.82); DS.thumbs.set(key, u); put(u); } catch { /* لا شيء */ }
  })();
  return box;
}
function dsMineGrid(all) {
  const mine = dsMine();
  if (!mine.length) return h('div', { class: 'empty' }, h('b', { text: 'ما عندك تصاميم محفوظة' }), h('small', { text: 'افتح أي قالب واضغط «احفظ للتعديل» — ترجع له وقت ما تبي.' }));
  return h('div', { class: 'ds-grid' }, ...mine.map((m) => {
    const t = all.find((x) => x.id === m.tpl);
    if (!t) return null;
    return h('div', { class: 'ds-card ds-mine', role: 'button', tabindex: 0, onclick: () => dsOpenMine(t, m) }, dsMineThumb(t, m),
      h('span', { class: 'ds-cap', text: m.values?.main || t.title || 'تصميم' }),
      h('small', { class: 'ds-when', text: UI.relTime(m.at) }),
      h('button', { type: 'button', class: 'ds-del', 'aria-label': 'حذف', onclick: async (e) => { e.stopPropagation(); if (!confirm('حذف هذا التصميم من «تصاميمي»؟')) return; await dsForget(m.id); renderDesigns(); } }, '✕'));
  }).filter(Boolean));
}
async function dsOpenMine(t, m) {
  const url = m.photo?.url || (m.photo && m.id ? await DSDB.get(m.id) : null);
  openDesign(t, m.values, m.style, { ...m, photo: m.photo && url ? { ...m.photo, url } : null, extras: await dsExtrasLoad(m) });
}
/* المحرّر في designs-editor.js */

/* نافذة «جديد في التصاميم» من الإدارة — مرة وحدة لكل إعلان */
async function dsNewsCheck() {
  if (typeof loadDesigns !== 'function') return;
  if (!DS.list) { const c = dsCache(); if (c) { DS.list = c.items || []; DS.meta = c.meta || {}; } }
  try { if (Cloud.enabled && Date.now() - DS.at > 45e3) { const r = await Cloud.designsList(); if (r) { DS.list = r.items || []; DS.meta = r.meta || {}; dsCache({ items: DS.list, meta: DS.meta }); DS.at = Date.now(); } } } catch { /* لا شيء */ }
  const n = DS.meta?.news;
  if (!n || !n.id || n.mode === 'off' || (typeof blockedTabs === 'function' && blockedTabs().has('designs'))) return;
  let seen = []; try { seen = JSON.parse(localStorage.getItem('nw:dsnews') || '[]'); } catch { /* لا شيء */ }
  if (seen.includes(n.id)) return;
  if (n.mode === 'banner') return; // يظهر داخل القسم
  // لا نزاحم نافذة ثانية: ننتظر لين تنقفل
  if (document.querySelector('.promo-pop')) { dsNewsCheck._n = (dsNewsCheck._n || 0) + 1; if (dsNewsCheck._n < 40) setTimeout(dsNewsCheck, 3000); return; }
  try { localStorage.setItem('nw:dsnews', JSON.stringify([...seen, n.id].slice(-30))); } catch { /* لا شيء */ }
  const box = h('div', { class: 'promo-pop dsn-pop', role: 'dialog' }, h('div', { class: 'promo-c' },
    n.image ? h('img', { src: n.image, alt: '' }) : h('div', { class: 'promo-ic', text: '✨' }),
    h('h3', { text: n.title || 'جديد في التصاميم' }), h('p', { text: n.text || '' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: () => { box.remove(); setTab('designs'); } }, 'شوفها الحين 🎨'),
    h('button', { type: 'button', class: 'btn ghost', onclick: () => box.remove() }, 'لاحقاً')));
  box.addEventListener('click', (e) => { if (e.target === box) box.remove(); });
  document.body.append(box);
}
function dsNewsBar() {
  const n = DS.meta?.news;
  if (!n || n.mode !== 'banner') return null;
  let seen = []; try { seen = JSON.parse(localStorage.getItem('nw:dsnews') || '[]'); } catch { /* لا شيء */ }
  if (seen.includes(n.id)) return null;
  const bar = h('div', { class: 'dsn-bar' }, h('span', { text: '✨' }), h('b', { text: `${n.title}${n.text ? ' — ' + n.text : ''}` }),
    h('button', { type: 'button', 'aria-label': 'إخفاء', onclick: () => { try { localStorage.setItem('nw:dsnews', JSON.stringify([...seen, n.id])); } catch { /* لا شيء */ } bar.remove(); } }, '✕'));
  return bar;
}
