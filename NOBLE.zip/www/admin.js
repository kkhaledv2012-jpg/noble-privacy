/* NOBLE — لوحة الإدارة (أدوار وصلاحيات) */
'use strict';
const { h, icon, toast } = UI;
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];

const A = { me: null, role: 'user', perm: new Set(), users: [], stats: null, q: '', chip: 'all', sheets: [], tab: '', logs: [], logFilter: '', msgs: [] };
const can = (p) => A.perm.has(p);

const ROLES = {
  owner: { name: 'المالك', rank: 100, desc: 'كل الصلاحيات' },
  admin: { name: 'أدمن', rank: 80, desc: 'إدارة كاملة عدا المالك' },
  moderator: { name: 'مشرف', rank: 60, desc: 'إيقاف وتفعيل، رسائل، السجل' },
  editor: { name: 'محرر', rank: 40, desc: 'محتوى التطبيق والإعلانات' },
  support: { name: 'دعم', rank: 30, desc: 'عرض المستخدمين ومراسلتهم' },
  user: { name: 'مستخدم', rank: 0, desc: 'بدون صلاحيات إدارية' },
};
const roleOf = (u) => ROLES[u.role] ? u.role : 'user';
const GAME_LABELS = { xo: 'إكس أو', flame: 'مغامرة اللهب', chase: 'المطاردة', word: 'كلمة اليوم', daily: 'تحدي اليوم', tasks: 'المهام' };
const SECTIONS = [['tasks', 'المهام', 'checkSquare'], ['today', 'يومي', 'sun'], ['news', 'الأخبار', 'bolt'], ['finance', 'المالية', 'wallet'], ['games', 'الألعاب', 'gamepad'], ['designs', 'التصاميم', 'image'], ['azkar', 'أذكاري', 'moon'], ['discover', 'اكتشف', 'play']];
const TABS = [
  ['users', 'المستخدمون', 'users', () => can('users.view')],
  ['messages', 'الرسائل', 'mail', () => can('messages.send') || can('messages.broadcast')],
  ['support', 'الدعم', 'inbox', () => can('messages.send')],
  ['sections', 'الأقسام', 'grid', () => can('sections.manage')],
  ['activity', 'النشاط', 'clock', () => can('logs.view') || can('stats.view')],
  ['news', 'الأخبار', 'bolt', () => can('news.manage')],
  ['ainews', 'NOBLE عاجل', 'spark', () => can('news.manage')],
  ['games', 'الألعاب', 'gamepad', () => can('games.manage')],
  ['designs', 'التصاميم', 'image', () => can('content.edit') || can('apps.manage')],
  ['azkar', 'الأذكار', 'moon', () => can('content.edit')],
  ['feed', 'اكتشف', 'play', () => can('content.edit')],
  ['apps', 'التطبيقات', 'phone', () => can('apps.manage')],
  ['store', 'وضع المتجر', 'lock', () => can('apps.manage')],
  ['ui', 'الواجهة', 'sun', () => can('apps.manage')],
  ['voice', 'الصوت', 'mic', () => can('apps.manage')],
  ['billing', 'الاشتراكات', 'wallet', () => can('billing.manage')],
  ['content', 'المحتوى', 'edit', () => can('content.edit')],
];
const LOG_LABEL = {
  signup: ['تسجيل جديد', 'plus'], suspend: ['إيقاف حساب', 'lock'], activate: ['تفعيل حساب', 'unlock'], role: ['تغيير دور', 'shield'],
  rename: ['تعديل اسم', 'edit'], games: ['إعدادات الألعاب', 'gamepad'], notice: ['رسالة إجبارية', 'bell'], player: ['تعديل لاعب', 'trophy'], reset_scores: ['تصفير نقاط', 'repeat'], grant: ['هدية لاعب', 'tag'], delete: ['حذف مستخدم', 'trash'], sections: ['أقسام مستخدم', 'grid'], content: ['نشر محتوى', 'edit'], message: ['رسالة', 'mail'],
  market: ['الأسعار والإعلانات', 'tag'], trial: ['فترة تجربة مستخدم', 'clock'], codes: ['توليد أكواد تفعيل', 'lock'], redeem: ['تفعيل كود', 'unlock'], payment: ['قرار طلب دفع', 'wallet'], pro: ['تفعيل Pro يدوي', 'bolt'], news: ['خبر', 'bolt'], news_key: ['مفتاح Gemini', 'lock'], design: ['قالب تصميم', 'image'],
};

document.addEventListener('DOMContentLoaded', async () => {
  Themes.apply({ themeId: Content.get('defaultTheme'), customColor: Content.get('defaultColor') });
  document.querySelectorAll('.brand, .a-center').forEach((el) => Brand.apply(null, el));
  $('#a-refresh').append(icon('repeat', { size: 20 }));
  $('#a-back').append(icon('grid', { size: 20 }));
  $('#a-logout').append(icon('lock', { size: 20 }));
  $('#a-add').append(icon('plus', { size: 18, stroke: 2.2 }), 'إضافة مستخدم');
  $('.search-ic').append(icon('search', { size: 20 }));
  $$('[data-close]').forEach((b) => b.classList.contains('icon-btn') && b.append(icon('x', { size: 20 })));
  bind();
  bindExtra();

  if (!Cloud.enabled) return show('a-noconfig');
  if (await Cloud.user()) return enter();
  show('a-login');
});

function show(id) {
  ['a-noconfig', 'a-login', 'a-app'].forEach((x) => ($('#' + x).hidden = x !== id));
}

async function enter() {
  try {
    const me = await Cloud.profile();
    const pm = await Cloud.permissions();
    if (!me || me.status !== 'active' || !(pm.perms || []).length) {
      show('a-login');
      $('#a-error').textContent = 'هذا الحساب ليست له صلاحيات إدارية.';
      return;
    }
    A.me = me; A.role = pm.role; A.perm = new Set(pm.perms);
    $('#a-me').textContent = me.display_name || me.email;
    $('#a-role').textContent = ROLES[A.role]?.name || A.role;
    show('a-app');
    renderTabs();
    // 1.21.26: من إشعار «📝 مسودة جاهزة» ← admin.html#ainews:ID يفتح المسودة مباشرة
    const hm = /^#ainews(?::(\d+))?/.exec(location.hash || '');
    if (hm && TABS.some((t) => t[0] === 'ainews' && t[3]())) { if (typeof AIA !== 'undefined') AIA.want = hm[1] ? Number(hm[1]) : 'drafts'; setTab('ainews'); }
    else setTab(TABS.find((t) => t[3]())[0]);
    if (typeof supaCounts === 'function') supaCounts().catch(() => {});
    if (typeof aiaDraftCount === 'function') aiaDraftCount().catch(() => {});
    await load();
    if (can('content.edit')) await loadContent();
  } catch (e) {
    show('a-login');
    $('#a-error').textContent = Cloud.msg(e);
  }
}

/* 1.19: ترتيب تبويبات اللوحة وإخفاؤها (يتحفظ على هذا الجهاز) */
const ATAB_K = 'nw:a-tabs';
const aTabPref = () => { try { const o = JSON.parse(localStorage.getItem(ATAB_K) || '{}') || {}; return { order: Array.isArray(o.order) ? o.order : [], hidden: Array.isArray(o.hidden) ? o.hidden : [] }; } catch { return { order: [], hidden: [] }; } };
const aTabSave = (o) => { try { localStorage.setItem(ATAB_K, JSON.stringify(o)); } catch { /* لا شيء */ } };
function aTabsOrdered() {
  const p = aTabPref(), mine = TABS.filter((t) => t[3]());
  const ids = [...p.order.filter((id) => mine.some((t) => t[0] === id)), ...mine.map((t) => t[0]).filter((id) => !p.order.includes(id))];
  return ids.map((id) => mine.find((t) => t[0] === id));
}
function renderTabs() {
  const p = aTabPref(), all = aTabsOrdered();
  const shown = all.filter((t) => !p.hidden.includes(t[0]) || t[0] === A.tab), hid = all.filter((t) => p.hidden.includes(t[0]) && t[0] !== A.tab);
  const chip = ([id, label, ic]) => h('button', { type: 'button', class: `chip${A.tab === id ? ' on' : ''}`, dataset: { tab: id }, onclick: () => setTab(id) }, icon(ic, { size: 16 }), label,
    id === 'support' && typeof SUPA !== 'undefined' && SUPA.counts?.new > 0 ? h('em', { class: 'supa-badge num', text: UI.n(SUPA.counts.new) }) : null,
    id === 'ainews' && A.aiDrafts > 0 ? h('em', { class: 'supa-badge num aia-dbadge', title: 'مسودات تنتظر مراجعتك', text: '📝' + UI.n(A.aiDrafts) }) : null);
  $('#a-tabs').replaceChildren(...shown.map(chip),
    hid.length ? h('button', { type: 'button', class: 'chip a-tab-more', onclick: () => pickSheet('التبويبات المخفية', 'تقدر ترجعها من «⚙️ ترتيب»', hid.map(([id, label, ic]) => h('button', { type: 'button', class: 'pick-item', onclick: () => { closeSheet(); setTab(id); } }, icon(ic, { size: 18 }), h('span', { text: label })))) }, `⋯ ${UI.n(hid.length)}`) : null,
    h('button', { type: 'button', class: 'chip a-tab-set', 'aria-label': 'ترتيب التبويبات', title: 'ترتيب التبويبات', onclick: aTabsSheet }, '⚙️ ترتيب'));
}
function aTabsSheet() {
  const box = h('div', { class: 'atab-list' });
  const paint = () => {
    const p = aTabPref(), list = aTabsOrdered();
    box.replaceChildren(...list.map(([id, label, ic], k) => {
      const on = !p.hidden.includes(id);
      const mv = (d) => { const ids = list.map((t) => t[0]); [ids[k], ids[k + d]] = [ids[k + d], ids[k]]; aTabSave({ ...p, order: ids }); paint(); renderTabs(); };
      const sw = h('input', { type: 'checkbox', checked: on });
      sw.addEventListener('change', () => { const q = aTabPref(); q.hidden = sw.checked ? q.hidden.filter((x) => x !== id) : [...q.hidden, id]; aTabSave(q); paint(); renderTabs(); });
      return h('div', { class: `atab-row${on ? '' : ' off'}` },
        h('span', { class: 'atab-n num', text: UI.n(k + 1) }), icon(ic, { size: 18 }), h('b', { text: label }),
        h('span', { class: 'sto-mv' },
          h('button', { type: 'button', 'aria-label': 'قبل', disabled: k === 0, onclick: () => mv(-1) }, '▲'),
          h('button', { type: 'button', 'aria-label': 'بعد', disabled: k === list.length - 1, onclick: () => mv(1) }, '▼')),
        h('label', { class: 'switch' }, sw, h('span', { class: 'track' })));
    }));
  };
  paint();
  pickSheet('⚙️ ترتيب تبويبات اللوحة', 'الأسهم ترتّب، والمفتاح يظهر أو يخفي التبويب. يتحفظ على هذا الجهاز.', [box,
    h('button', { type: 'button', class: 'btn btn-block', onclick: () => { aTabSave({ order: [], hidden: [] }); paint(); renderTabs(); toast('رجع الترتيب الافتراضي ✓'); } }, '↺ الترتيب الافتراضي')]);
}
function setTab(id) {
  A.tab = id;
  ['users', 'messages', 'support', 'sections', 'activity', 'news', 'ainews', 'games', 'designs', 'azkar', 'feed', 'apps', 'store', 'ui', 'voice', 'billing', 'content'].forEach((t) => { const el = $('#a-' + t); if (el) el.hidden = t !== id; });
  if (id === 'apps' && typeof openAppsAdmin === 'function') openAppsAdmin();
  if (id === 'store' && typeof openStoreAdmin === 'function') openStoreAdmin();
  if (id === 'billing' && typeof openBillingAdmin === 'function') openBillingAdmin();
  if (id === 'games' && typeof openGamesAdmin === 'function') openGamesAdmin();
  if (id === 'news' && typeof openNewsAdmin === 'function') openNewsAdmin();
  if (id === 'ainews' && typeof openAiNewsAdmin === 'function') openAiNewsAdmin();
  if (id !== 'ainews' && typeof AIA !== 'undefined') { cancelAnimationFrame(AIA.raf); AISlides.sync(null, [], false); }
  if (id === 'designs' && typeof openDesignsAdmin === 'function') openDesignsAdmin();
  if (id === 'azkar' && typeof openAzkarAdmin === 'function') openAzkarAdmin();
  if (id === 'feed' && typeof openFeedAdmin === 'function') openFeedAdmin();
  if (id === 'support' && typeof openSupportAdmin === 'function') openSupportAdmin(true);
  if (id === 'ui' && typeof openUiAdmin === 'function') openUiAdmin();
  if (id === 'voice' && typeof openVoiceAdmin === 'function') openVoiceAdmin();
  renderTabs();
  if (id === 'messages') loadMessages();
  if (id === 'activity') loadActivity();
  if (id === 'sections') renderSections();
}

async function load() {
  try {
    const jobs = [can('users.view') ? Cloud.admin.list() : [], can('stats.view') ? Cloud.admin.stats() : null];
    [A.users, A.stats] = await Promise.all(jobs);
    await loadUserStats();
    render();
    if (A.tab === 'sections') renderSections();
    if (A.tab === 'activity') renderActivity();
  } catch (e) {
    toast('تعذّر التحميل: ' + Cloud.msg(e), { type: 'error' });
  }
}

/* ---------- المستخدمون ---------- */
const isOnline = (u) => u.last_seen_at && Date.now() - new Date(u.last_seen_at) < 5 * 60000;
const ts = (d) => (d ? new Date(d).getTime() : 0);
const hueOf = (s) => { let x = 0; for (const c of String(s)) x = (x * 31 + c.codePointAt(0)) % 360; return x; };
const nameOf = (u) => (u.guest && typeof guestName === 'function' ? guestName(u) : u.display_name || (u.email || '').split('@')[0] || '—');
/* يمكنني إدارته؟ (نفس منطق الخادم) */
const canManage = (u) => u.id !== A.me.id && (A.role === 'owner' || ROLES[A.role].rank > ROLES[roleOf(u)].rank);

function filtered() {
  const q = UI.normAr(A.q.trim());
  return A.users.filter((u) => {
    if (A.chip === 'active' && u.status !== 'active') return false;
    if (A.chip === 'suspended' && u.status !== 'suspended') return false;
    if (A.chip === 'staff' && roleOf(u) === 'user') return false;
    if (A.chip === 'online' && !isOnline(u)) return false;
    if (A.chip === 'guest' && !u.guest) return false;
    if (A.chip === 'reg' && u.guest) return false;
    if (q && !UI.normAr(`${u.display_name} ${u.email} ${u.nickname || ''} ${typeof devLabel === 'function' ? devLabel(devOf(u)) : ''}`).includes(q)) return false;
    return true;
  });
}

function statCards(host) {
  const s = A.stats || {};
  const stat = (cls, label, value, ic, icCls, sub, chip) =>
    h('button', { type: 'button', class: `stat ${cls}${A.chip === chip && chip !== 'all' ? ' active' : ''}`, onclick: () => chip && setChip(chip) },
      h('span', { class: `stat-ic ${icCls}` }, ic), h('span', { class: 'stat-value num', text: value }),
      h('span', { class: 'stat-label', text: label }), sub ? h('span', { class: 'stat-sub', text: sub }) : null);
  host.replaceChildren(
    stat('stat-hero', 'إجمالي المستخدمين', s.users ?? A.users.length, icon('users', { size: 18 }), '', `${s.admins ?? 0} من الفريق`, 'all'),
    stat('', 'نشطون هذا الأسبوع', s.active_7d ?? 0, icon('clock', { size: 16 }), 'i-review', null, 'online'),
    stat('', 'جدد هذا الأسبوع', s.new_7d ?? 0, icon('plus', { size: 16 }), 'i-fav', null, 'all'),
    stat('', 'موقوفون', s.suspended ?? 0, icon('lock', { size: 16 }), 'i-high', null, 'suspended'),
    stat('', 'مباريات لُعبت', s.games_played ?? 0, icon('gamepad', { size: 16 }), 'i-rate', null, null));
  // 1.20: 📱 الأجهزة والضيوف
  if (can('users.view') && typeof openDevices === 'function') host.append(h('button', { type: 'button', class: 'stat stat-dev', onclick: openDevices },
    h('span', { class: 'stat-ic i-review' }, icon('phone', { size: 16 })), h('span', { class: 'stat-value num', text: A.users.filter((u) => u.guest).length }),
    h('span', { class: 'stat-label', text: 'بدون حساب' }), h('span', { class: 'stat-sub', text: '📱 الأجهزة ←' })));
}

function render() {
  $('#a-add').hidden = !can('users.manage');
  statCards($('#a-stats'));
  $('#a-stats').hidden = !can('stats.view');
  const chip = (id, label) => h('button', { type: 'button', class: `chip${A.chip === id ? ' on' : ''}`, onclick: () => setChip(id) }, label);
  $('#a-chips').replaceChildren(chip('all', 'الكل'), chip('online', 'متصل الآن'), chip('active', 'نشط'), chip('suspended', 'موقوف'), chip('staff', 'الفريق'), chip('guest', '👤 بدون حساب'), chip('reg', '✉️ بحساب'));
  const list = filtered();
  $('#a-count').textContent = `${list.length} مستخدم`;
  $('#a-list').replaceChildren(...list.map(card));
  const empty = $('#a-empty');
  empty.hidden = list.length > 0;
  if (!list.length) empty.replaceChildren(icon('search', { size: 36 }), h('h3', { text: A.users.length ? 'لا نتائج' : 'لا يوجد مستخدمون بعد' }),
    h('p', { text: A.users.length ? 'غيّر البحث أو التصفية.' : 'أضف أول مستخدم، أو شارك التطبيق ليسجّلوا بأنفسهم.' }));
}

function setChip(id) { A.chip = A.chip === id ? 'all' : id; render(); }

function card(u) {
  const you = u.id === A.me.id;
  const name = nameOf(u);
  const r = roleOf(u);
  const off = u.disabled_sections || [];
  const c = h('article', { class: ['u-card', u.status === 'suspended' && 'is-suspended', r !== 'user' && 'is-admin'].filter(Boolean).join(' ') });
  c.append(h('div', { class: 'u-top' },
    h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: name.charAt(0).toUpperCase() }),
    h('div', { class: 'u-id' }, h('span', { class: 'u-name', text: name }), h('span', { class: 'u-email', text: u.guest && typeof guestSub === 'function' ? guestSub(u) : u.email })),
    you ? null : h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إجراءات', onclick: () => openUser(u) }, icon('more', { size: 18 }))));
  c.append(h('div', { class: 'u-badges' },
    you ? h('span', { class: 'pill you', text: 'أنت' }) : null,
    r !== 'user' ? h('span', { class: `pill role-${r}`, text: ROLES[r].name }) : null,
    h('span', { class: `pill ${u.status}`, text: u.status === 'active' ? 'نشط' : 'موقوف' }),
    u.nickname ? h('span', { class: 'pill nick', text: '🎮 ' + u.nickname }) : null,
    off.length ? h('span', { class: 'pill off', text: `${off.length} قسم موقوف` }) : null));
  c.append(h('div', { class: 'u-meta' },
    h('div', {}, h('b', { class: 'num', text: u.items_count ?? 0 }), h('small', { text: 'موقع محفوظ' })),
    h('div', {}, h('b', {}, isOnline(u) ? h('i', { class: 'online' }) : null, isOnline(u) ? 'الآن' : UI.relTime(ts(u.last_seen_at))), h('small', { text: 'آخر ظهور' })),
    h('div', {}, h('b', { text: UI.relTime(ts(u.created_at)) }), h('small', { text: u.guest ? 'أول فتح' : 'تاريخ التسجيل' }))));
  const st = A.ustats?.[u.id];
  if (can('users.view')) {
    const ds = deviceState(st);
    const g = st?.stats?.games || {};
    c.append(h('button', { type: 'button', class: 'u-progress', onclick: () => openUserActivity(u) },
      h('span', { class: `ua-dot ${ds.cls}`, text: ds.text }),
      st ? h('span', { class: 'u-prog-t' }, `v${st.version || '—'} · ${g.points ?? 0} نقطة · ${Object.keys(g.flame?.stars || {}).length} مرحلة`) : null,
      h('span', { class: 'u-prog-go' }, 'التقدّم والنشاط', icon('arrowLeft', { size: 14 }))));
  }
  return c;
}

/* ---------- إجراءات المستخدم ---------- */
function openUser(u) {
  const name = nameOf(u);
  const mng = canManage(u);
  $('#user-head').replaceChildren(h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: name.charAt(0).toUpperCase() }),
    h('div', {}, h('b', { text: name }), h('small', { text: `${u.guest && typeof guestSub === 'function' ? guestSub(u) : u.email} · ${ROLES[roleOf(u)].name}` })));
  const act = (ic, label, fn, cls = '') => h('button', { type: 'button', class: `action ${cls}`, onclick: () => { closeSheet(); fn(); } }, icon(ic, { size: 20 }), label);
  const list = [];
  if (mng && can('users.manage')) {
    list.push(act('edit', 'تعديل الاسم', () => rename(u)));
    list.push(u.status === 'active'
      ? act('lock', 'إيقاف الحساب', () => run(() => Cloud.admin.setStatus(u.id, 'suspended'), `تم إيقاف ${name}`))
      : act('unlock', 'تفعيل الحساب', () => run(() => Cloud.admin.setStatus(u.id, 'active'), `تم تفعيل ${name}`)));
  }
  if (mng && can('roles.manage')) list.push(act('shield', 'تغيير الدور والصلاحيات', () => pickRole(u)));
  if (can('users.view')) list.push(act('trendUp', 'التقدّم والنشاط', () => openUserActivity(u)));
  if (can('billing.manage')) list.push(act('bolt', '★ الأقسام والتجربة', () => setTimeout(() => grantProSheet(u), 230)));
  if (can('games.manage')) list.push(act('tag', '🎁 مكافأة في الألعاب', () => giftPlayer(u.id, name)));
  if (can('messages.send')) list.push(act('mail', 'إرسال رسالة خاصة', () => { setTab('messages'); setMsgTarget(u.id); }));
  if (can('sections.manage')) list.push(act('grid', 'الأقسام المتاحة له', () => pickSections(u)));
  if (can('apps.manage') && typeof toggleTester === 'function') { const isT = (MK.data?.testers || Market.get().testers || []).some((t) => t.id === u.id); list.push(act('flag', isT ? '🧪 إلغاء «مختبر»' : '🧪 اجعله مختبر (يشوف الأقسام التجريبية)', () => toggleTester(u))); }
  list.push(act('copy', 'نسخ الإيميل', () => navigator.clipboard?.writeText(u.email).then(() => toast('تم النسخ', { type: 'success', duration: 1500 }))));
  if (mng && can('users.delete')) list.push(act('trash', 'حذف المستخدم نهائياً', async () => {
    const ok = await confirmSheet({ title: `حذف ${name}؟`, text: 'يُحذف الحساب وخزنته المشفّرة نهائياً ولا يمكن التراجع.', ok: 'حذف نهائي', typeToConfirm: 'حذف' });
    if (ok) run(() => Cloud.admin.remove(u.id), `تم حذف ${name}`);
  }, 'danger'));
  if (!mng) list.push(h('p', { class: 'hint pick-hint', text: 'لا يمكنك تعديل حساب بدور مساوٍ لك أو أعلى.' }));
  $('#user-actions').replaceChildren(...list);
  openSheet('#user-sheet');
}

/* أدوار يمكنني منحها */
const grantable = () => Object.entries(ROLES).filter(([k, v]) => k !== 'owner' && (A.role === 'owner' || v.rank < ROLES[A.role].rank));

function pickSheet(title, hint, items) {
  $('#pick-title').textContent = title;
  $('#pick-hint').textContent = hint || '';
  $('#pick-hint').hidden = !hint;
  $('#pick-list').replaceChildren(...items);
  openSheet('#pick-sheet');
  $('#pick-sheet').scrollTop = 0;
}
function pickRole(u) {
  const cur = roleOf(u);
  pickSheet(`دور ${nameOf(u)}`, 'تحدد الصلاحيات التي يملكها داخل لوحة الإدارة.', grantable().map(([k, v]) =>
    h('button', { type: 'button', class: `action role-opt${k === cur ? ' selected' : ''}`, onclick: () => { closeSheet(); if (k !== cur) run(() => Cloud.admin.setRole(u.id, k), `أصبح ${nameOf(u)}: ${v.name}`); } },
      icon(k === cur ? 'check' : 'shield', { size: 20 }), h('span', { class: 'ro-t' }, h('b', { text: v.name }), h('small', { text: v.desc })))));
}
function pickSections(u) {
  const off = new Set(u.disabled_sections || []);
  const rows = SECTIONS.map(([id, label, ic]) => {
    const sw = h('input', { type: 'checkbox', checked: !off.has(id) });
    sw.addEventListener('change', () => { if (sw.checked) off.delete(id); else off.add(id); });
    return h('label', { class: 'switch-row' }, h('span', { class: 'sec-lbl' }, icon(ic, { size: 18 }), label), h('span', { class: 'switch' }, sw, h('span', { class: 'track' })));
  });
  pickSheet(`أقسام ${nameOf(u)}`, 'المفعّل يظهر له. الإيقاف يخفي القسم من تطبيقه عند المزامنة التالية.', [
    h('div', { class: 'pick-body' }, ...rows,
      h('button', { type: 'button', class: 'btn btn-primary', onclick: () => { closeSheet(); run(() => Cloud.admin.setSections(u.id, [...off]), 'تم حفظ الأقسام'); } }, 'حفظ'))]);
}

async function rename(u) {
  const ok = await confirmSheet({ title: 'تعديل الاسم', text: u.email, ok: 'حفظ', input: u.display_name || '' });
  if (ok !== false) run(() => Cloud.admin.setName(u.id, ok), 'تم الحفظ');
}

async function run(fn, done) {
  try { await fn(); toast(done, { type: 'success' }); await load(); }
  catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}

function genPassword() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789@#%';
  const v = crypto.getRandomValues(new Uint32Array(12));
  return [...v].map((x) => chars[x % chars.length]).join('');
}

function bind() {
  $('#a-login-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    $('#a-error').textContent = '';
    try { await Cloud.signIn($('#a-email').value, $('#a-pw').value); $('#a-pw').value = ''; await enter(); }
    catch (ex) { $('#a-error').textContent = Cloud.msg(ex); }
  });
  $('#a-logout').addEventListener('click', async () => { await Core.lock(); await Cloud.signOut(); show('a-login'); });
  $('#a-refresh').addEventListener('click', async () => {
    await load();
    if (A.tab === 'messages') await loadMessages();
    if (A.tab === 'activity') await loadActivity();
    toast('تم التحديث', { type: 'success', duration: 1200 });
  });
  $('#a-search').addEventListener('input', (e) => { A.q = e.target.value; render(); });
  $('#a-add').addEventListener('click', () => {
    $('#add-form').reset();
    $('#add-form').elements.password.value = genPassword();
    $('#add-error').textContent = '';
    $('#add-role-wrap').hidden = !can('roles.manage');
    $('#add-role').replaceChildren(...[['user', ROLES.user], ...grantable().filter(([k]) => k !== 'user')].map(([k, v]) => h('option', { value: k, text: v.name })));
    openSheet('#add-sheet');
  });
  $('#gen-pw').addEventListener('click', () => ($('#add-form').elements.password.value = genPassword()));
  $('#add-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target.elements, err = $('#add-error');
    const email = f.email.value.trim(), pw = f.password.value;
    if (!/^\S+@\S+\.\S+$/.test(email)) return (err.textContent = 'أدخل بريداً صحيحاً');
    if (pw.length < 6) return (err.textContent = 'كلمة المرور ٦ أحرف على الأقل');
    $('#add-submit').disabled = true;
    try {
      const u = await Cloud.admin.create(email, pw, f.name.value.trim());
      if (f.role.value && f.role.value !== 'user' && can('roles.manage')) await Cloud.admin.setRole(u.id, f.role.value).catch(() => {});
      closeSheet();
      toast(`تم إنشاء حساب ${email}`, { type: 'success', duration: 5000 });
      await load();
    } catch (ex) { err.textContent = Cloud.msg(ex); }
    finally { $('#add-submit').disabled = false; }
  });
  $('#backdrop').addEventListener('click', () => closeSheet());
  $$('[data-close]').forEach((b) => b.addEventListener('click', () => closeSheet()));
}

/* ---------- الرسائل: في admin-messages.js ---------- */

/* ---------- الأقسام ---------- */
async function renderSections() {
  const conf = await Cloud.getConfig().catch(() => null) || {};
  const off = new Set(Array.isArray(conf.sectionsOff) ? conf.sectionsOff : []);
  const canGlobal = can('content.edit');
  $('#sec-global').replaceChildren(...[h('strong', { text: 'لكل المستخدمين' }),
    ...SECTIONS.map(([id, label, ic]) => {
      const sw = h('input', { type: 'checkbox', checked: !off.has(id), disabled: !canGlobal });
      sw.addEventListener('change', async () => {
        if (sw.checked) off.delete(id); else off.add(id);
        try {
          const cur = { ...Content.DEFAULTS, ...((await Cloud.getConfig()) || {}) };
          delete cur._updated;
          delete cur._games;
          cur.sectionsOff = [...off];
          await Cloud.admin.setConfig(cur);
          if (typeof C !== 'undefined') C.data.sectionsOff = cur.sectionsOff;
          $('#s-status').textContent = 'حُفظ ✓';
          toast(sw.checked ? `تم تفعيل ${label}` : `تم إيقاف ${label} للجميع`, { type: 'success' });
          renderSections();
        } catch (e) { sw.checked = !sw.checked; toast(Cloud.msg(e), { type: 'error' }); }
      });
      return h('label', { class: 'switch-row' }, h('span', { class: 'sec-lbl' }, icon(ic, { size: 18 }), label, h('small', { text: off.has(id) ? 'موقوف للجميع' : 'متاح' })), h('span', { class: 'switch' }, sw, h('span', { class: 'track' })));
    }),
    canGlobal ? null : h('p', { class: 'hint', text: 'الإيقاف للجميع يحتاج صلاحية تعديل المحتوى.' })].filter(Boolean));
  const users = A.users.filter((u) => (u.disabled_sections || []).length);
  $('#sec-users').replaceChildren(...(users.length ? users.map((u) => h('article', { class: 'u-card sec-u' },
    h('div', { class: 'u-top' }, h('span', { class: 'u-av', style: { '--h': hueOf(u.email) }, text: nameOf(u).charAt(0).toUpperCase() }),
      h('div', { class: 'u-id' }, h('span', { class: 'u-name', text: nameOf(u) }), h('span', { class: 'u-email', text: (u.disabled_sections || []).map((x) => SECTIONS.find((s) => s[0] === x)?.[1] || x).join('، ') + ' موقوف' })),
      h('button', { type: 'button', class: 'btn sm', onclick: () => pickSections(u) }, 'تعديل'))))
    : [h('p', { class: 'hint', text: 'لا يوجد — افتح إجراءات أي مستخدم واختر «الأقسام المتاحة له».' })]));
}

/* ---------- النشاط ---------- */
async function loadActivity() {
  if (can('logs.view')) { try { A.logs = (await Cloud.admin.logs(150)) || []; } catch { A.logs = []; } }
  renderActivity();
}
function chart(host, series, color, kind) {
  const W = 600, H = 170, P = 22;
  const data = series || [];
  const max = Math.max(1, ...data.map((x) => x.n));
  const bw = (W - P * 2) / Math.max(1, data.length);
  const X = (i) => P + i * bw + bw / 2, Y = (n) => H - P - (n / max) * (H - P * 2);
  let body = '';
  [0, 0.5, 1].forEach((t) => { const y = Y(max * t); body += `<line x1="${P}" x2="${W - P}" y1="${y}" y2="${y}" stroke="currentColor" opacity=".12"/><text x="${W - 4}" y="${y + 4}" font-size="11" fill="currentColor" opacity=".5" text-anchor="end" direction="ltr">${Math.round(max * t)}</text>`; });
  if (kind === 'bar') data.forEach((x, i) => { const y = Y(x.n); body += `<rect x="${X(i) - bw * 0.32}" y="${y}" width="${bw * 0.64}" height="${Math.max(0, H - P - y)}" rx="3" fill="${color}"><title>${x.d}: ${x.n}</title></rect>`; });
  else {
    const pts = data.map((x, i) => `${X(i)},${Y(x.n)}`).join(' ');
    body += `<polygon points="${P},${H - P} ${pts} ${W - P},${H - P}" fill="${color}" opacity=".18"/><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="3" stroke-linejoin="round"/>`;
    data.forEach((x, i) => { if (x.n) body += `<circle cx="${X(i)}" cy="${Y(x.n)}" r="3.5" fill="${color}"><title>${x.d}: ${x.n}</title></circle>`; });
  }
  data.forEach((x, i) => { if ((i % 7 === 0 && data.length - 1 - i >= 4) || i === data.length - 1) body += `<text x="${X(i)}" y="${H - 4}" font-size="11" fill="currentColor" opacity=".55" text-anchor="middle">${String(x.d).slice(5).replace('-', '/')}</text>`; });
  const t = document.createElement('template');
  t.innerHTML = `<svg viewBox="0 0 ${W} ${H}" width="100%" preserveAspectRatio="none" style="height:190px;direction:ltr" direction="ltr">${body}</svg>`;
  host.replaceChildren(t.content.firstChild);
}
function renderActivity() {
  if (A.tab !== 'activity') return;
  if (typeof renderHot === 'function') renderHot();
  statCards($('#act-stats'));
  $('#act-stats').hidden = !can('stats.view');
  const s = A.stats || {};
  const sum = (a) => (a || []).reduce((x, y) => x + y.n, 0);
  $('.charts').hidden = !can('stats.view');
  chart($('#ch-signups'), s.signups, '#F0922F', 'bar');
  chart($('#ch-active'), s.active, '#56C8FF', 'line');
  $('#ch-signups-t').textContent = `${sum(s.signups)} خلال ٣٠ يوماً`;
  $('#ch-active-t').textContent = `ذروة ${Math.max(0, ...(s.active || []).map((x) => x.n))} يومياً`;
  const kinds = [...new Set(A.logs.map((l) => l.action))];
  $('#log-chips').hidden = !can('logs.view');
  $('#log-chips').replaceChildren(h('button', { type: 'button', class: `chip${!A.logFilter ? ' on' : ''}`, onclick: () => { A.logFilter = ''; renderActivity(); } }, 'الكل'),
    ...kinds.map((k) => h('button', { type: 'button', class: `chip${A.logFilter === k ? ' on' : ''}`, onclick: () => { A.logFilter = A.logFilter === k ? '' : k; renderActivity(); } }, LOG_LABEL[k]?.[0] || k)));
  const logs = A.logs.filter((l) => !A.logFilter || l.action === A.logFilter);
  const detail = (l) => {
    const m = l.meta || {};
    if (l.action === 'role') return `← ${ROLES[m.role]?.name || m.role}`;
    if (l.action === 'rename') return `← ${m.name}`;
    if (l.action === 'message') return `«${m.title}»`;
    if (l.action === 'notice') return `«${m.title}» · ${m.level === 'bar' ? 'شريط' : 'شاشة'}`;
    if (l.action === 'grant') return m.kind === 'beans' ? `${m.value?.n} حبة بن` : m.kind === 'unlock' ? 'فتح كل المراحل' : `${m.value?.cat || ''} ${m.value?.id || ''}`;
    if (l.action === 'reset_scores') return `${m.game ? GAME_LABELS[m.game] || m.game : 'كل الألعاب'} · ${m.rows ?? 0} سجل`;
    if (l.action === 'player') return [m.nickname && `اسم: ${m.nickname}`, m.banned === true && 'حظر', m.banned === false && 'رفع حظر', m.show === false && 'إخفاء'].filter(Boolean).join(' · ');
    if (l.action === 'sections') return (m.off || []).length ? 'أوقف: ' + m.off.map((x) => SECTIONS.find((s2) => s2[0] === x)?.[1] || x).join('، ') : 'كل الأقسام مفعّلة';
    return '';
  };
  $('#log-list').replaceChildren(...(!can('logs.view') ? [] : logs.length ? logs.map((l) => {
    const [label, ic] = LOG_LABEL[l.action] || [l.action, 'info'];
    const self = l.action === 'signup';
    return h('div', { class: `log-row la-${l.action}` },
      h('span', { class: 'log-ic' }, icon(ic, { size: 16 })),
      h('div', { class: 'log-t' },
        h('b', { text: label }),
        h('small', { text: self ? (l.actor_email || '') : `${l.actor_email || 'النظام'}${l.target_email ? ' ← ' + l.target_email : ''} ${detail(l)}` })),
      h('small', { class: 'n-time', text: UI.relTime(ts(l.at)) }));
  }) : [h('p', { class: 'hint', text: 'لا توجد إجراءات مسجّلة بعد.' })]));
}

function bindExtra() { bindMessages(); }

/* ---------- الأوراق ---------- */
function openSheet(sel) {
  const el = $(sel);
  if (!A.sheets.includes(el)) A.sheets.push(el);
  $('#backdrop').hidden = false; el.hidden = false;
}
function closeSheet(el = A.sheets[A.sheets.length - 1]) {
  if (!el) return;
  A.sheets = A.sheets.filter((s) => s !== el);
  el.classList.add('closing');
  setTimeout(() => { el.hidden = true; el.classList.remove('closing'); el.dispatchEvent(new Event('closed')); }, 190);
  if (!A.sheets.length) $('#backdrop').hidden = true;
}
/* تأكيد؛ مع input يعيد النص أو false */
function confirmSheet({ title, text, ok = 'تأكيد', typeToConfirm = '', input = null }) {
  $('#confirm-title').textContent = title;
  $('#confirm-text').textContent = text;
  const okBtn = $('#confirm-ok'), inp = $('#confirm-type');
  okBtn.textContent = ok;
  okBtn.className = input !== null ? 'btn btn-primary' : 'btn btn-danger';
  inp.hidden = !typeToConfirm && input === null;
  inp.value = input ?? '';
  inp.placeholder = typeToConfirm ? `اكتب «${typeToConfirm}» للتأكيد` : '';
  okBtn.disabled = !!typeToConfirm;
  inp.oninput = () => { if (typeToConfirm) okBtn.disabled = inp.value.trim() !== typeToConfirm; };
  openSheet('#confirm-sheet');
  return new Promise((resolve) => {
    let result = false;
    const sheet = $('#confirm-sheet');
    okBtn.onclick = () => { result = input !== null ? inp.value.trim() : true; closeSheet(sheet); };
    $('#confirm-cancel').onclick = () => closeSheet(sheet);
    sheet.addEventListener('closed', () => resolve(result), { once: true });
  });
}


/* ================= محتوى التطبيق ================= */
const TEXT_KEYS = ['appName', 'tagline', 'authTagline', 'welcomeTitle', 'announceText', 'announceLink', 'emptySitesTitle', 'emptySitesText',
  'emptyTasksTitle', 'emptyTasksText', 'website', 'instagram', 'whatsapp', 'minVersion', 'updateUrl', 'updateText',
  'exSiteName', 'exSiteTags', 'exProject', 'exNickname', 'exAccount', 'exInvoiceItem', 'exRecurring', 'exGoal', 'exQuick', 'exQuickList',
  'qaTitle', 'qaWhere', 'qaAuto', 'qaTask', 'qaExpense', 'qaIncome', 'qaSite', 'qaPhTask', 'qaPhExpense', 'qaPhIncome', 'qaPhSite', 'qaBtn', 'qaBusy', 'qaGot', 'qaFail', 'qaNote', 'gnTitle', 'gnText', 'gnPh', 'gnSkip', 'gnSave', 'gnEditTitle'];
const C = { data: {}, dirty: false };

async function loadContent() {
  try {
    const remote = await Cloud.getConfig();
    C.data = { ...Content.DEFAULTS, ...(remote || {}) };
    delete C.data._updated;
    delete C.data._games;
    C.orig = JSON.parse(JSON.stringify(C.data)); // 1.19.2: نحفظ بس اللي تغيّر (ما نمسح إعدادات حفظتها تبويبات ثانية مثل وضع المتجر)
    $('#c-status').textContent = remote?._updated ? `آخر نشر ${UI.relTime(new Date(remote._updated).getTime())}` : 'لم يُنشر بعد';
  } catch (e) {
    C.data = { ...Content.DEFAULTS };
    $('#c-status').textContent = 'تعذّر التحميل: ' + Cloud.msg(e);
  }
  fillContentForm();
}

function fillContentForm() {
  const f = $('#c-form').elements;
  TEXT_KEYS.forEach((k) => { if (f[k]) f[k].value = C.data[k] ?? ''; });
  f.announceOn.checked = !!C.data.announceOn;
  $('#c-cur-ver').textContent = Cloud.VERSION;
  renderContentThemes();
  renderBrandCtl();
  previewContent();
}

/* ---------- الهوية والشعار ---------- */
function renderBrandCtl() {
  const d = C.data;
  const c = Brand.cfg(d);
  const box = $('#c-brand');
  const color = (label, key, val) => {
    const i = h('input', { type: 'color', value: val });
    i.addEventListener('input', () => { d[key] = i.value.toUpperCase(); changed(); });
    return h('label', { class: 'br-col' }, i, h('small', { text: label }));
  };
  const seg = (opts, cur, key) => h('div', { class: 'seg3 br-seg' }, ...Object.entries(opts).map(([v, l]) =>
    h('button', { type: 'button', class: v === cur ? 'on' : '', onclick: () => { d[key] = v; changed(); renderBrandCtl(); } }, l)));
  const file = h('input', { type: 'file', accept: 'image/png,image/webp,image/svg+xml,image/jpeg', hidden: true });
  file.addEventListener('change', async () => {
    const f = file.files[0]; if (!f) return;
    try { d.brandLogo = await Brand.shrink(f); changed(); renderBrandCtl(); toast('تم رفع الشعار — اضغط «نشر التعديلات» ليظهر للجميع', { type: 'success' }); }
    catch (e) { toast(e.message, { type: 'error' }); }
  });
  const hue = h('input', { type: 'range', min: -180, max: 180, step: 5, value: c.hue, class: 'br-hue' });
  hue.addEventListener('input', () => { d.brandHue = Number(hue.value); changed(); });
  box.replaceChildren(
    h('div', { class: 'br-logo' },
      h('span', { class: 'br-logo-art' }, h('img', { 'data-brand-logo': '', src: Brand.logo(d), alt: '' })),
      h('div', { class: 'br-logo-t' }, h('b', { text: 'الشعار' }), h('small', { class: 'hint', text: 'PNG أو WebP بخلفية شفافة — يُصغَّر تلقائياً. يظهر في البداية والدخول والأعلى والرسائل.' }),
        h('div', { class: 'br-btns' }, h('button', { type: 'button', class: 'btn sm', onclick: () => file.click() }, icon('upload', { size: 15 }), 'رفع شعار'),
          d.brandLogo ? h('button', { type: 'button', class: 'link-btn', onclick: () => { d.brandLogo = ''; changed(); renderBrandCtl(); } }, 'الشعار الأصلي') : null)), file),
    h('div', { class: 'field' }, h('span', { text: 'لون اللهب في الشعار' }), h('div', { class: 'br-hue-row' }, hue,
      h('button', { type: 'button', class: 'link-btn', onclick: () => { d.brandHue = 0; changed(); renderBrandCtl(); } }, 'الأصلي'))),
    h('div', { class: 'field' }, h('span', { text: 'ألوان اسم التطبيق' }),
      h('div', { class: 'br-presets' }, ...Object.entries(Brand.PRESETS).map(([k, [l, a, b, cc, e]]) =>
        h('button', { type: 'button', class: 'br-preset', title: l, style: { background: `linear-gradient(110deg, ${a}, ${b}, ${cc}, ${e})` }, onclick: () => { Object.assign(d, { brandC1: a, brandC2: b, brandC3: cc, brandC4: e }); changed(); renderBrandCtl(); } }, h('span', { text: l })))),
      h('div', { class: 'br-cols' }, color('١', 'brandC1', c.c1), color('٢', 'brandC2', c.c2), color('٣', 'brandC3', c.c3), color('٤', 'brandC4', c.c4), color('التوهج', 'brandGlow', c.glow))),
    h('div', { class: 'field' }, h('span', { text: 'شكل الاسم' }), seg(Brand.STYLES, c.style, 'brandStyle')),
    h('div', { class: 'field' }, h('span', { text: 'حركة الواجهة' }), seg(Brand.MOTIONS, c.motion, 'motion'),
      h('small', { class: 'hint', text: 'حيوي: شاشة بداية متحركة، انتقالات بين الأقسام، خلفية تتنفس، وأزرار حيّة. المستخدم يقدر يوقف الحركة من إعداداته.' })));
  UI.digitize(box);
}

function renderContentThemes() {
  const cur = C.data.defaultTheme || 'midnight';
  $('#c-themes').replaceChildren(...Themes.LIST.map((t) =>
    h('button', { type: 'button', class: `theme-opt${t.id === cur ? ' on' : ''}`, onclick: () => { C.data.defaultTheme = t.id; C.data.defaultColor = ''; changed(); renderContentThemes(); } },
      h('span', { class: 'theme-dot' }, h('i', { style: { background: t.night } }), h('i', { style: { background: `linear-gradient(135deg, ${t.priLight}, ${t.priDeep})` } }), h('i', { style: { background: t.flame } })),
      t.name)));
  $('#c-color').value = C.data.defaultColor || Themes.LIST.find((t) => t.id === cur).pri;
  const sw = $('#a-content .color-swatch span');
  if (sw) sw.style.setProperty('--custom', C.data.defaultColor || 'transparent');
  $('#c-color-clear').hidden = !C.data.defaultColor;
}

function readContentForm() {
  const f = $('#c-form').elements;
  TEXT_KEYS.forEach((k) => { if (f[k]) C.data[k] = f[k].value.trim(); });
  C.data.announceOn = f.announceOn.checked;
}

function previewContent() {
  const d = C.data;
  const get = (k) => d[k] || Content.DEFAULTS[k];
  const words = get('appName').split(/\s+/);
  $('#pv-name').replaceChildren(words.length > 1 ? words.slice(0, -1).join(' ') + ' ' : '', h('b', { text: words[words.length - 1] }));
  $('#pv-tag').textContent = get('tagline');
  const ann = $('#pv-announce');
  ann.hidden = !(d.announceOn && d.announceText);
  ann.replaceChildren(icon('info', { size: 16 }), h('span', { text: d.announceText || '' }));
  const pv = $('.c-preview');
  if (pv && typeof Brand !== 'undefined') {
    const st = Brand.cfg(d).style;
    Object.keys(Brand.STYLES).forEach((s) => pv.classList.toggle('wm-' + s, s === st));
    Brand.apply(d, pv);
    Brand.apply(d, $('#c-brand'));
    $('#pv-authtag').textContent = get('authTagline');
  }
  $('#pv-empty-t').textContent = get('emptySitesTitle');
  $('#pv-empty-p').textContent = get('emptySitesText');
  Themes.apply({ themeId: d.defaultTheme, customColor: d.defaultColor });
}

function changed() {
  C.dirty = true;
  $('#c-status').textContent = 'تعديلات غير منشورة';
  previewContent();
}

function bindContent() {
  $('#c-form').addEventListener('input', () => { readContentForm(); changed(); });
  $('#c-form').addEventListener('change', () => { readContentForm(); changed(); });
  $('#c-color').addEventListener('input', (e) => { C.data.defaultColor = e.target.value.toUpperCase(); changed(); renderContentThemes(); });
  $('#pv-replay').addEventListener('click', () => { const w = $('#pv-splash [data-wordmark]'); Brand.wordmark(w, { animate: true, text: Brand.name(C.data), over: C.data }); const r = $('#pv-splash .splash-ring'); r.classList.remove('go'); void r.offsetWidth; r.classList.add('go'); });
  $('#c-color-clear').addEventListener('click', () => { C.data.defaultColor = ''; changed(); renderContentThemes(); });
  $('#c-reset').addEventListener('click', async () => {
    const ok = await confirmSheet({ title: 'استعادة الافتراضي؟', text: 'تعود كل النصوص والإعدادات هنا إلى قيمها الأصلية (لن تُنشر حتى تضغط «نشر التعديلات»).', ok: 'استعادة' });
    if (!ok) return;
    C.data = { ...Content.DEFAULTS };
    fillContentForm();
    changed();
  });
  $('#c-save').addEventListener('click', async () => {
    readContentForm();
    for (const k of ['announceLink', 'website', 'updateUrl']) {
      if (C.data[k] && !/^https?:\/\//i.test(C.data[k])) C.data[k] = 'https://' + C.data[k].replace(/^\/+/, '');
    }
    if (C.data.minVersion && !/^\d+(\.\d+){0,2}$/.test(C.data.minVersion)) return toast('رقم الإصدار بصيغة مثل 1.1.0', { type: 'error' });
    $('#c-save').disabled = true;
    try {
      // ندمج مع آخر نسخة في السيرفر: نكتب بس الحقول اللي عدّلتها هنا
      const remote = { ...Content.DEFAULTS, ...((await Cloud.getConfig()) || {}) };
      delete remote._updated; delete remote._games; delete remote._market;
      const orig = C.orig || {};
      for (const k of Object.keys(C.data)) if (JSON.stringify(C.data[k]) !== JSON.stringify(orig[k])) remote[k] = C.data[k];
      C.data = remote; C.orig = JSON.parse(JSON.stringify(remote));
      await Cloud.admin.setConfig(C.data);
      Content.set(C.data);
      C.dirty = false;
      $('#c-status').textContent = 'نُشر الآن ✓';
      toast('نُشرت التعديلات — تظهر للمستخدمين عند فتح التطبيق', { type: 'success', duration: 5000 });
    } catch (e) {
      toast('تعذّر النشر: ' + Cloud.msg(e), { type: 'error' });
    } finally {
      $('#c-save').disabled = false;
    }
  });
  window.addEventListener('beforeunload', (e) => { if (C.dirty) { e.preventDefault(); e.returnValue = ''; } });
}
document.addEventListener('DOMContentLoaded', bindContent);
