/* NOBLE — الإعدادات السحابية
 * اتركها فارغة = التطبيق يعمل محلياً فقط (بدون حسابات).
 * بعد إنشاء مشروع Supabase المجاني: الصق الرابط والمفتاح العام (anon public) هنا.
 * (Supabase → Project Settings → API)
 */
window.NOBLE_CONFIG = {
  supabaseUrl: 'https://nvonsdlmpyzjeccewuat.supabase.co',
  supabaseAnonKey: 'sb_publishable_9986Dz1wClRTiXj7JmtDXg_6nGMsgMA',
};
