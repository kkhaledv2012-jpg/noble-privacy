/* NOBLE — المالية: حسابات، حركات، فواتير، اشتراكات، ميزانيات، أهداف، تقارير
 * كل البيانات داخل الخزنة المشفّرة (v.fin) — لا تراها الإدارة ولا الخادم.
 */
'use strict';

const FIN = { sub: 'home', scope: 'all', month: '', unlocked: false, hide: false, q: '', txType: 'all', period: 'month' };
const FIN_COLORS = ['#2E5BFF', '#F0922F', '#8B45F0', '#1FC7A0', '#C8509C', '#56C8FF', '#FFB43D', '#E0555F', '#4CC93C', '#7A86A8', '#B07CFF', '#FF8A5B'];
const ACC_TYPES = { cash: ['نقدي', 'wallet'], bank: ['بنك', 'layers'], card: ['بطاقة', 'receipt'], wallet: ['محفظة إلكترونية', 'phone'] };
const SCOPES = { personal: 'شخصي', work: 'عمل' };
const EVERY = { weekly: 'أسبوعياً', monthly: 'شهرياً', yearly: 'سنوياً' };

/* إضافة عناصر مع تجاهل الفارغ (null) */
const fclean = (k) => k.flat().filter((x) => x != null && x !== false);
const fput = (el, ...k) => el.append(...fclean(k));
const frep = (el, ...k) => el.replaceChildren(...fclean(k));

/* ---------- البيانات ---------- */
const uid = () => crypto.randomUUID();
const fymd = (d = new Date()) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const ymOf = (s) => String(s).slice(0, 7);
const addMonths = (ym, n) => { const [y, m] = ym.split('-').map(Number); const d = new Date(y, m - 1 + n, 1); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
function defaultFin() {
  const cat = (name, kind, scope, i) => ({ id: uid(), name, kind, scope, color: FIN_COLORS[i % FIN_COLORS.length] });
  return {
    accounts: [
      { id: uid(), name: 'نقدي', type: 'cash', opening: 0, color: FIN_COLORS[3] },
      { id: uid(), name: 'الحساب البنكي', type: 'bank', opening: 0, color: FIN_COLORS[0] },
    ],
    cats: [
      ...['تصميم وهوية', 'تصوير', 'صناعة محتوى', 'إدارة حسابات', 'راتب', 'دخل آخر'].map((n, i) => cat(n, 'income', 'both', i)),
      ...['اشتراكات أدوات وAI', 'معدات', 'إعلانات', 'مستقلين', 'طباعة', 'تنقل عمل'].map((n, i) => cat(n, 'expense', 'work', i + 2)),
      ...['سكن', 'سيارة ووقود', 'أكل ومطاعم', 'فواتير واتصالات', 'تسوق', 'صحة', 'ترفيه', 'عائلة', 'أخرى'].map((n, i) => cat(n, 'expense', 'personal', i + 5)),
    ],
    tx: [], clients: [], invoices: [], recurring: [], budgets: {}, goals: [],
    settings: { currency: 'ر.س', vatRate: 15, invPrefix: 'INV-', nextInv: 1, bizName: '', bizVat: '', lock: true },
  };
}
function normFin(f) {
  if (!f || !Array.isArray(f.accounts)) f = defaultFin();
  const d = defaultFin();
  ['tx', 'clients', 'invoices', 'recurring', 'goals'].forEach((k) => { if (!Array.isArray(f[k])) f[k] = []; });
  if (!f.budgets || typeof f.budgets !== 'object') f.budgets = {};
  f.settings = { ...d.settings, ...(f.settings || {}) };
  if (!Array.isArray(f.cats) || !f.cats.length) f.cats = d.cats;
  return f;
}
const fin = () => normFin(S.vault?.fin);
async function fsave(mut) {
  return commit((v) => { v.fin = normFin(v.fin); return mut(v.fin); });
}

/* ---------- التنسيق ---------- */
function money(n, opt = {}) {
  if (FIN.hide && !opt.show) return '••••';
  const v = Math.round((Number(n) || 0) * 100) / 100;
  const s = new Intl.NumberFormat(UI.loc(), { minimumFractionDigits: 0, maximumFractionDigits: 2 }).format(Math.abs(v));
  const sign = opt.sign ? (v > 0 ? '+' : v < 0 ? '−' : '') : v < 0 ? '−' : '';
  return `${sign}${s}${opt.bare ? '' : ' ' + fin().settings.currency}`;
}
const shortDate = (s) => new Date(s + 'T12:00').toLocaleDateString(UI.loc(), { day: 'numeric', month: 'short' });
const longDay = (s) => new Date(s + 'T12:00').toLocaleDateString(UI.loc(), { weekday: 'long', day: 'numeric', month: 'long' });
const monthName = (ym) => new Date(ym + '-15T12:00').toLocaleDateString(UI.loc(), { month: 'long', year: 'numeric' });
const monthShort = (ym) => new Date(ym + '-15T12:00').toLocaleDateString(UI.loc(), { month: 'short' });
const catOf = (f, id) => f.cats.find((c) => c.id === id);
const accOf = (f, id) => f.accounts.find((a) => a.id === id);
const clientOf = (f, id) => f.clients.find((c) => c.id === id);

/* ---------- الحسابات ---------- */
function balances(f) {
  const m = {};
  f.accounts.forEach((a) => (m[a.id] = Number(a.opening) || 0));
  for (const t of f.tx) {
    if (t.type === 'income' && t.acc in m) m[t.acc] += t.amount;
    else if (t.type === 'expense' && t.acc in m) m[t.acc] -= t.amount;
    else if (t.type === 'transfer') { if (t.acc in m) m[t.acc] -= t.amount; if (t.to in m) m[t.to] += t.amount; }
  }
  return m;
}
const inScope = (t) => FIN.scope === 'all' || t.type === 'transfer' || t.scope === FIN.scope;
function sums(txs) {
  let inc = 0, exp = 0;
  txs.forEach((t) => { if (t.type === 'income') inc += t.amount; else if (t.type === 'expense') exp += t.amount; });
  return { inc, exp, net: inc - exp };
}
const invTotals = (f, inv) => {
  const sub = (inv.items || []).reduce((s, it) => s + (Number(it.qty) || 0) * (Number(it.price) || 0), 0);
  const vat = inv.vat ? sub * (Number(f.settings.vatRate) || 0) / 100 : 0;
  return { sub, vat, total: sub + vat };
};
const invState = (inv) => (inv.status === 'paid' ? 'paid' : inv.status === 'sent' && inv.due && inv.due < fymd() ? 'late' : inv.status);
const INV_ST = { draft: 'مسودة', sent: 'مرسلة', paid: 'مدفوعة', late: 'متأخرة' };
const invNo = (f, n) => `${f.settings.invPrefix}${String(n).padStart(4, '0')}`;

/* ================= الواجهة الرئيسية ================= */
/* مزايا Pro في المالية — البيانات الموجودة تبقى متاحة، والإنشاء الجديد يحتاج Pro */
const proOk = (feat, count) => typeof Pro === 'undefined' || Pro.gate(feat, count);
/* 1.20: شكل رئيسية المالية — يتحكم فيه المالك من لوحة التحكم ← الواجهة ← «💳 شكل المالية» */
const FUI = () => ({ style: 'card', card: true, quick: true, limit: true, week: true, months: true, recent: true, ...((typeof Market !== 'undefined' && Market.get().finui) || {}) });
function finBankCard(f, total, m, scopeSeg) {
  // التغيّر من بداية الشهر (كل الحسابات): الرصيد قبل حركات هالشهر
  const cur = ymOf(fymd()), all = sums(f.tx.filter((t) => ymOf(t.date) === cur));
  const start = total - all.net, pct = start > 0 ? (all.net / start) * 100 : 0;
  const chip = svgNode('<svg class="fb-emv" viewBox="0 0 40 30" width="40" height="30"><rect x="1" y="1" width="38" height="28" rx="6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M1 11h11M1 19h11M28 11h11M28 19h11M12 1v28M28 1v28M12 15h16" fill="none" stroke="currentColor" stroke-width="1.2"/></svg>');
  const nfc = svgNode('<svg class="fb-nfc" viewBox="0 0 24 24" width="22" height="22"><path d="M8.5 8.5a5 5 0 0 1 0 7M12 6a8.5 8.5 0 0 1 0 12M15.5 3.5a12 12 0 0 1 0 17" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>');
  return h('section', { class: 'f-hero f-bank' },
    h('div', { class: 'fb-row' }, h('span', { class: 'fb-brand', text: (typeof Content !== 'undefined' && Content.get('appName')) || 'NOBLE' }), nfc),
    h('div', { class: 'f-hero-top' }, h('small', { text: 'الرصيد الإجمالي' }), scopeSeg),
    h('div', { class: 'fb-total' }, h('b', { class: 'f-total num', text: money(total) }),
      start > 0 && Math.abs(pct) >= 0.01 && !FIN.hide ? h('span', { class: `fb-pct num ${pct < 0 ? 'neg' : ''}`, text: `${pct > 0 ? '▲' : '▼'} ${UI.n(Math.abs(pct) >= 10 ? Math.round(Math.abs(pct)) : Math.abs(pct).toFixed(1))}٪` }) : null),
    h('div', { class: 'fb-row fb-foot' }, chip, h('small', { class: 'num', text: `${UI.n(f.accounts.filter((a) => !a.archived).length)} حسابات` })),
    h('div', { class: 'f-month' },
      h('div', {}, h('span', { class: 'f-dot in' }), h('small', { text: 'دخل الشهر' }), h('b', { class: 'num', text: money(m.inc) })),
      h('div', {}, h('span', { class: 'f-dot out' }), h('small', { text: 'مصروف الشهر' }), h('b', { class: 'num', text: money(m.exp) })),
      h('div', {}, h('span', { class: 'f-dot net' }), h('small', { text: 'الصافي' }), h('b', { class: `num ${m.net < 0 ? 'neg' : ''}`, text: money(m.net, { sign: true }) }))));
}
/* حد الصرف الشهري: صرفت كذا من ميزانيتك */
function finLimitCard(f) {
  const curM = ymOf(fymd()), spent = catSpend(f, curM, 'all');
  const ids = Object.keys(f.budgets).filter((id) => f.budgets[id] > 0 && catOf(f, id));
  const totB = ids.reduce((s, id) => s + f.budgets[id], 0), totS = ids.reduce((s, id) => s + (spent[id] || 0), 0);
  if (!totB) return h('button', { type: 'button', class: 'f-card f-limit empty-lim', onclick: openBudgetSheet }, h('b', { text: '🎯 حدد سقف مصروفك الشهري' }), h('small', { text: 'ونقول لك كم باقي لك تصرف كل يوم' }));
  const p = totS / totB, d = new Date(), left = new Date(d.getFullYear(), d.getMonth() + 1, 0).getDate() - d.getDate() + 1;
  const perDay = Math.max(0, totB - totS) / left;
  return h('button', { type: 'button', class: `f-card f-limit${p >= 1 ? ' over' : p >= 0.8 ? ' warn' : ''}`, onclick: () => { FIN.sub = 'plan'; renderFinance(); } },
    h('div', { class: 'fl-h' }, h('small', { text: 'حد الصرف الشهري' }), h('span', { class: 'fl-dots', text: '⋮' })),
    h('div', { class: 'fl-v' }, h('b', { class: 'num', text: money(totS) }), h('small', { class: 'num', text: `صرفت من ${money(totB)}` })),
    h('div', { class: 'fl-bar' }, h('i', { style: { width: `${Math.min(100, p * 100)}%` } }), h('em', { class: 'num', text: `${UI.n(Math.round(p * 100))}٪` })),
    h('small', { class: 'fl-sub num', text: p >= 1 ? `تجاوزت السقف بـ ${money(totS - totB)}` : `باقي لك ${money(totB - totS)} — تقريباً ${money(Math.floor(perDay))} باليوم` }));
}
/* نشاط الأسبوع: مصروف آخر ٧ أيام واليوم يتوهج */
function finWeekCard(f) {
  const today = fymd(), days = Array.from({ length: 7 }, (_, i) => fAddDays(today, i - 6));
  const vals = days.map((d) => f.tx.filter((t) => t.type === 'expense' && t.date === d && inScope(t)).reduce((s, t) => s + t.amount, 0));
  const max = Math.max(1, ...vals), sum = vals.reduce((a, b) => a + b, 0);
  return h('div', { class: 'f-card f-week' },
    h('div', { class: 'f-sec in-card' }, h('b', { text: 'نشاطك هالأسبوع' }), h('small', { class: 'num hint', text: `${money(sum)} مصروف` })),
    h('div', { class: 'fw-cols' }, ...days.map((d, i) => h('div', { class: `fw-col${d === today ? ' on' : ''}`, title: `${longDay(d)}: ${money(vals[i])}` },
      h('span', { class: 'fw-track' }, h('i', { style: { height: `${vals[i] ? Math.max(6, (vals[i] / max) * 100) : 0}%` } })),
      h('small', { text: new Date(d + 'T12:00').toLocaleDateString(UI.loc(), { weekday: 'short' }) })))));
}
function renderFinance() {
  if (typeof updateNavBack === 'function') setTimeout(updateNavBack, 0);
  const root = $('#f-root');
  if (!root || !S.vault) return;
  if (!FIN.month) FIN.month = ymOf(fymd());
  const f = fin();
  if (f.settings.lock && !FIN.unlocked) return renderFinLock(root);
  const bal = balances(f);
  const total = f.accounts.filter((a) => !a.archived).reduce((s, a) => s + (bal[a.id] || 0), 0);
  const cur = ymOf(fymd());
  const mtx = f.tx.filter((t) => ymOf(t.date) === cur && inScope(t));
  const m = sums(mtx);

  const scopeSeg = h('div', { class: 'seg seg-3 seg-mini f-scope' }, ...[['all', 'الكل'], ['personal', 'شخصي'], ['work', 'عمل']].map(([k, l]) =>
    h('label', {}, h('input', { type: 'radio', name: 'fscope', value: k, checked: FIN.scope === k, onchange: () => { FIN.scope = k; renderFinance(); } }), h('span', { text: l }))));
  const SUB_FEAT = { home: 'finance.home', tx: 'finance.tx', inv: 'finance.invoices', plan: 'finance.plan', rep: 'finance.reports' };
  const P = typeof Pro !== 'undefined' ? Pro : null;
  const subs = [['home', 'الرئيسية', 'wallet'], ['tx', 'الحركات', 'swap'], ['inv', 'الفواتير', 'receipt'], ['plan', 'الخطط', 'target'], ['rep', 'التقارير', 'pie']]
    .filter(([k]) => !P || P.visible(SUB_FEAT[k]));
  // قسم فرعي مقفل تماماً (مدفوع وبدون حد مجاني) — يفتح ورقة الاشتراك
  const subOpen = (k) => !P || P.has(SUB_FEAT[k]) || (Market.feat(SUB_FEAT[k])?.limit > 0);
  if (!subs.some(([k]) => k === FIN.sub) || !subOpen(FIN.sub)) FIN.sub = (subs.find(([k]) => subOpen(k)) || subs[0] || ['home'])[0];

  frep(root, 
    h('div', { class: 'f-head' },
      h('h1', { class: 'view-title', text: 'المالية' }),
      h('div', { class: 'f-head-act' },
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': FIN.hide ? 'إظهار المبالغ' : 'إخفاء المبالغ', onclick: () => { FIN.hide = !FIN.hide; renderFinance(); } }, icon(FIN.hide ? 'eyeOff' : 'eye', { size: 19 })),
        h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إعدادات المالية', onclick: openFinSettings }, icon('settings', { size: 19 })),
        f.settings.lock ? h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'قفل المالية', onclick: () => { FIN.unlocked = false; renderFinance(); } }, icon('lock', { size: 19 })) : null)),
    FUI().style === 'card' ? finBankCard(f, total, m, scopeSeg) : h('section', { class: 'f-hero' },
      h('div', { class: 'f-hero-top' }, h('small', { text: 'الرصيد الإجمالي' }), scopeSeg),
      h('b', { class: 'f-total num', text: money(total) }),
      h('div', { class: 'f-month' },
        h('div', {}, h('span', { class: 'f-dot in' }), h('small', { text: 'دخل الشهر' }), h('b', { class: 'num', text: money(m.inc) })),
        h('div', {}, h('span', { class: 'f-dot out' }), h('small', { text: 'مصروف الشهر' }), h('b', { class: 'num', text: money(m.exp) })),
        h('div', {}, h('span', { class: 'f-dot net' }), h('small', { text: 'الصافي' }), h('b', { class: `num ${m.net < 0 ? 'neg' : ''}`, text: money(m.net, { sign: true }) })))),
    typeof AccessUI !== 'undefined' ? AccessUI.banner('finance') : null,
    h('nav', { class: 'f-subs' }, ...subs.map(([k, l, ic]) => h('button', { type: 'button', class: FIN.sub === k ? 'on' : '', onclick: () => { if (!subOpen(k)) return P.gate(SUB_FEAT[k]); FIN.sub = k; renderFinance(); window.scrollTo({ top: 0 }); } }, icon(ic, { size: 17 }), h('span', { text: l }), P && !P.has(SUB_FEAT[k]) ? h('i', { class: 'f-star', text: '★' }) : null))),
    h('div', { id: 'f-body', class: 'f-body' }));
  const body = $('#f-body');
  root.classList.toggle('f-v2', FUI().style === 'card');
  ({ home: finHome, tx: finTx, inv: finInvoices, plan: finPlans, rep: finReports })[FIN.sub](body, f, bal);
  if (FIN.sub === 'tx' && typeof Ads !== 'undefined') Ads.inject(body.querySelector('.f-days'), 2);
  UI.digitize(root);
}

function renderFinLock(root) {
  frep(root, h('div', { class: 'f-lock' },
    h('span', { class: 'f-lock-ic' }, icon('wallet', { size: 34 })),
    h('h2', { text: 'المالية مقفلة' }),
    h('p', { text: document.documentElement.classList.contains('anon') ? 'أرقامك المالية محمية بقفل إضافي — افتحها ببصمة جوالك.' : 'أرقامك المالية محمية بقفل إضافي. افتحها ببصمتك أو بكلمة مرور الخزنة.' }),
    h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: unlockFinance }, icon('finger', { size: 20 }), 'فتح المالية')));
}
async function unlockFinance() {
  // 🏪 الحساب الخفي (بدون كلمة مرور): بصمة الجوال لو موجودة، وإلا يفتح مباشرة — ما فيه كلمة مرور يكتبها
  const anon = document.documentElement.classList.contains('anon');
  if (anon && !(Platform.isNative && (await Bio.available()))) { FIN.unlocked = true; buzz('success'); renderFinance(); return; }
  if (Platform.isNative && (await Bio.available())) {
    try { await Platform.plugin('NativeBiometric').verifyIdentity({ reason: 'افتح المالية', title: 'المالية', subtitle: 'تأكيد هويتك', negativeButtonText: 'إلغاء', allowedBiometryTypes: Bio.types() }); }
    catch { return; }
  } else {
    const pw = await askPassword({ title: 'فتح المالية', text: 'أدخل كلمة مرور الخزنة.' });
    if (!pw) return;
  }
  FIN.unlocked = true;
  buzz('success');
  renderFinance();
}
document.addEventListener('visibilitychange', () => { if (document.hidden) FIN.unlocked = false; });

/* ---------- الرئيسية ---------- */
function finHome(body, f, bal) {
  const today = fymd();
  const quick = (ic, label, cls, fn) => h('button', { type: 'button', class: `f-q ${cls}`, onclick: fn }, h('span', {}, icon(ic, { size: 20 })), label);
  const accs = f.accounts.filter((a) => !a.archived);
  const due = f.recurring.filter((r) => r.active !== false && r.next <= fAddDays(today, 7)).sort((a, b) => a.next.localeCompare(b.next));
  const curM = ymOf(today);
  const spentBy = catSpend(f, curM);
  const alerts = Object.entries(f.budgets).filter(([id, b]) => b > 0 && (spentBy[id] || 0) >= b * 0.8 && catOf(f, id));
  const recent = f.tx.filter(inScope).sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt).slice(0, 6);
  const months = Array.from({ length: 6 }, (_, i) => addMonths(curM, i - 5));

  const U = FUI();
  fput(body, 
    !U.quick ? null : h('div', { class: 'f-quick' },
      quick('minus', 'مصروف', 'q-out', () => openTxSheet({ type: 'expense' })),
      quick('plus', 'دخل', 'q-in', () => openTxSheet({ type: 'income' })),
      quick('swap', 'تحويل', 'q-tr', () => openTxSheet({ type: 'transfer' })),
      quick('receipt', 'فاتورة', 'q-inv', () => openInvoiceSheet())),
    h('div', { class: 'f-sec' }, h('b', { text: 'الحسابات' }), h('button', { type: 'button', class: 'link-btn', onclick: () => openAccountSheet() }, '+ حساب')),
    h('div', { class: 'f-accs' }, ...accs.map((a) => h('button', { type: 'button', class: 'f-acc', style: { '--ac': a.color || FIN_COLORS[0] }, onclick: () => openAccountSheet(a) },
      h('span', { class: 'f-acc-ic' }, icon(ACC_TYPES[a.type]?.[1] || 'wallet', { size: 17 })),
      h('small', { text: a.name }),
      h('b', { class: `num ${(bal[a.id] || 0) < 0 ? 'neg' : ''}`, text: money(bal[a.id]) })))),
    alerts.length ? h('div', { class: 'f-alerts' }, ...alerts.map(([id, b]) => {
      const c = catOf(f, id), s = spentBy[id] || 0, over = s > b;
      return h('div', { class: `f-alert${over ? ' over' : ''}` }, icon('alert', { size: 16 }),
        h('span', {}, over ? `تجاوزت ميزانية «${c.name}»` : `اقتربت من ميزانية «${c.name}»`), h('b', { class: 'num', text: `${Math.round((s / b) * 100)}٪` }));
    })) : null,
    due.length ? h('div', { class: 'f-sec' }, h('b', { text: 'مدفوعات قادمة' }), h('button', { type: 'button', class: 'link-btn', onclick: () => { FIN.sub = 'plan'; renderFinance(); } }, 'الكل')) : null,
    due.length ? h('div', { class: 'f-list' }, ...due.slice(0, 4).map((r) => recurRow(f, r))) : null,
    U.limit ? finLimitCard(f) : null,
    U.week ? finWeekCard(f) : null,
    !U.months ? null : h('div', { class: 'f-card' },
      h('div', { class: 'f-sec in-card' }, h('b', { text: 'آخر ٦ أشهر' }), h('span', { class: 'f-legend' }, h('i', { class: 'in' }), 'دخل', h('i', { class: 'out' }), 'مصروف')),
      barChart(months.map((ym) => { const s = sums(f.tx.filter((t) => ymOf(t.date) === ym && inScope(t))); return { label: monthShort(ym), a: s.inc, b: s.exp }; }))),
    !U.recent ? null : h('div', { class: 'f-sec' }, h('b', { text: 'آخر الحركات' }), h('button', { type: 'button', class: 'link-btn', onclick: () => { FIN.sub = 'tx'; renderFinance(); } }, 'الكل')),
    !U.recent ? null : recent.length ? h('div', { class: 'f-list' }, ...recent.map((t) => txRow(f, t)))
      : h('div', { class: 'empty f-empty' }, icon('wallet', { size: 36 }), h('h3', { text: 'ابدأ بتسجيل أول حركة' }), h('p', { text: 'اضغط «مصروف» أو «دخل» أعلاه، أو زر + في الأسفل.' })));
}
const fAddDays = (s, n) => { const d = new Date(s + 'T12:00'); d.setDate(d.getDate() + n); return fymd(d); };
function catSpend(f, ym, scope = FIN.scope) {
  const m = {};
  f.tx.forEach((t) => { if (t.type === 'expense' && ymOf(t.date) === ym && (scope === 'all' || t.scope === scope)) m[t.cat] = (m[t.cat] || 0) + t.amount; });
  return m;
}

function txRow(f, t) {
  const c = catOf(f, t.cat);
  const tr = t.type === 'transfer';
  const title = tr ? `تحويل: ${accOf(f, t.acc)?.name || '—'} ← ${accOf(f, t.to)?.name || '—'}` : c?.name || 'بدون تصنيف';
  const sub = [tr ? null : accOf(f, t.acc)?.name, t.scope && !tr ? SCOPES[t.scope] : null, t.note, t.client ? clientOf(f, t.client)?.name : null].filter(Boolean).join(' · ');
  return h('button', { type: 'button', class: 'f-row', onclick: () => openTxSheet(t) },
    h('span', { class: `f-row-ic ${t.type}`, style: { '--cc': c?.color || '#7A86A8' } }, icon(tr ? 'swap' : t.type === 'income' ? 'trendUp' : 'trendDown', { size: 17 })),
    h('span', { class: 'f-row-t' }, h('b', { text: title }), sub ? h('small', { text: sub }) : null),
    h('span', { class: 'f-row-v' }, h('b', { class: `num ${t.type}`, text: tr ? money(t.amount) : money(t.type === 'income' ? t.amount : -t.amount, { sign: true }) }), h('small', { class: 'num', text: shortDate(t.date) })));
}

/* ---------- الحركات ---------- */
function finTx(body, f) {
  const list = f.tx.filter((t) => ymOf(t.date) === FIN.month && inScope(t) && (FIN.txType === 'all' || t.type === FIN.txType))
    .filter((t) => { const q = UI.normAr(FIN.q.trim()); if (!q) return true; return UI.normAr(`${catOf(f, t.cat)?.name || ''} ${t.note || ''} ${accOf(f, t.acc)?.name || ''} ${t.amount}`).includes(q); })
    .sort((a, b) => b.date.localeCompare(a.date) || b.createdAt - a.createdAt);
  const s = sums(list);
  const groups = new Map();
  list.forEach((t) => { if (!groups.has(t.date)) groups.set(t.date, []); groups.get(t.date).push(t); });
  const chip = (k, l) => h('button', { type: 'button', class: `chip${FIN.txType === k ? ' on' : ''}`, onclick: () => { FIN.txType = k; renderFinance(); } }, l);
  const search = h('input', { class: 'input', type: 'search', placeholder: 'ابحث في الحركات…', value: FIN.q, autocomplete: 'off' });
  let tm; search.addEventListener('input', () => { clearTimeout(tm); tm = setTimeout(() => { FIN.q = search.value; renderFinance(); $('#f-body input[type=search]')?.focus(); }, 250); });
  fput(body, 
    h('div', { class: 'f-monthnav' },
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'الشهر السابق', onclick: () => { FIN.month = addMonths(FIN.month, -1); renderFinance(); } }, icon('chevR', { size: 18 })),
      h('b', { text: monthName(FIN.month) }),
      h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'الشهر التالي', onclick: () => { FIN.month = addMonths(FIN.month, 1); renderFinance(); } }, icon('chevL', { size: 18 }))),
    h('div', { class: 'f-mini' },
      h('div', {}, h('small', { text: 'دخل' }), h('b', { class: 'num income', text: money(s.inc) })),
      h('div', {}, h('small', { text: 'مصروف' }), h('b', { class: 'num expense', text: money(s.exp) })),
      h('div', {}, h('small', { text: 'الصافي' }), h('b', { class: `num ${s.net < 0 ? 'neg' : ''}`, text: money(s.net, { sign: true }) }))),
    (() => { const sb = h('div', { class: 'search f-search' }, h('span', { class: 'search-ic' }, icon('search', { size: 20 })), search); if (typeof Voice !== 'undefined') Voice.attach(search, 'finance'); return sb; })(),
    h('nav', { class: 'chips' }, chip('all', 'الكل'), chip('expense', 'مصروف'), chip('income', 'دخل'), chip('transfer', 'تحويل'),
      h('button', { type: 'button', class: 'chip', onclick: exportFinCSV }, icon('download', { size: 14 }), 'تصدير Excel')),
    list.length ? h('div', { class: 'f-days' }, ...[...groups.entries()].map(([d, ts]) => {
      const ds = sums(ts);
      return h('div', { class: 'f-day' }, h('div', { class: 'f-day-h' }, h('span', { text: longDay(d) }), h('small', { class: 'num', text: money(ds.net, { sign: true }) })), h('div', { class: 'f-list' }, ...ts.map((t) => txRow(f, t))));
    })) : h('div', { class: 'empty f-empty' }, icon('swap', { size: 34 }), h('p', { text: 'لا توجد حركات في هذا الشهر.' })));
}

/* ---------- نموذج الحركة ---------- */
let finSheetEl = null;
function finSheet(title, bodyKids, footKids, cls = '') {
  if (!finSheetEl) { finSheetEl = h('section', { class: 'sheet', id: 'fin-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(finSheetEl); }
  finSheetEl.className = 'sheet ' + cls;
  frep(finSheetEl, h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(finSheetEl) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body' }, ...bodyKids.filter(Boolean)),
    footKids ? h('footer', { class: 'sheet-foot' }, ...footKids.filter(Boolean)) : null);
  if (!S.sheets.includes(finSheetEl)) openSheet('#fin-sheet');
  finSheetEl.scrollTop = 0;
  UI.digitize(finSheetEl);
  return finSheetEl;
}
const segRadio = (name, opts, cur, onPick) => h('div', { class: `seg seg-${opts.length}` }, ...opts.map(([v, l, cls]) =>
  h('label', {}, h('input', { type: 'radio', name, value: v, checked: v === cur, onchange: () => onPick(v) }), h('span', { class: cls || '', text: l }))));
const selectOf = (opts, cur, onPick) => { const s = h('select', { class: 'input select' }, ...opts.map(([v, l]) => h('option', { value: v, text: l, selected: v === cur }))); s.addEventListener('change', () => onPick(s.value)); return s; };

function openTxSheet(src = {}) {
  if (fin().settings.lock && !FIN.unlocked) return unlockFinance();
  const f = fin();
  const editing = src.id ? src : null;
  const accs = f.accounts.filter((a) => !a.archived || a.id === src.acc || a.id === src.to);
  const d = { type: 'expense', amount: '', acc: accs[0]?.id, to: accs[1]?.id || accs[0]?.id, cat: '', scope: FIN.scope === 'work' ? 'work' : 'personal', date: fymd(), note: '', client: '', vat: false, ...JSON.parse(JSON.stringify(src)) };
  const amount = h('input', { class: 'input f-amount num', inputmode: 'decimal', placeholder: '0', value: d.amount || '', autocomplete: 'off' });
  const err = h('p', { class: 'error-text' });
  const catBox = h('div', { class: 'f-cats' });
  const paintCats = () => {
    const cats = f.cats.filter((c) => c.kind === (d.type === 'income' ? 'income' : 'expense') && (d.type === 'income' || c.scope === d.scope || c.scope === 'both'));
    if (!cats.some((c) => c.id === d.cat)) d.cat = cats[0]?.id || '';
    const add = h('input', { class: 'input f-newcat', placeholder: '+ تصنيف جديد', maxlength: 30 });
    add.addEventListener('keydown', async (e) => {
      if (e.key !== 'Enter' || !add.value.trim()) return;
      e.preventDefault();
      const c = { id: uid(), name: add.value.trim(), kind: d.type === 'income' ? 'income' : 'expense', scope: d.type === 'income' ? 'both' : d.scope, color: FIN_COLORS[f.cats.length % FIN_COLORS.length] };
      f.cats.push(c); d.cat = c.id;
      await fsave((x) => { x.cats.push(c); });
      paintCats();
    });
    frep(catBox, ...cats.map((c) => h('button', { type: 'button', class: `f-cat${d.cat === c.id ? ' on' : ''}`, style: { '--cc': c.color }, onclick: () => { d.cat = c.id; paintCats(); } }, h('i'), c.name)), add);
  };
  const extra = h('div', { class: 'f-extra' });
  const paint = () => {
    finSheetEl?.classList.toggle('t-in', d.type === 'income');
    const tr = d.type === 'transfer';
    frep(extra, ...[
      h('div', { class: 'row-2' },
        h('label', { class: 'field' }, h('span', { text: tr ? 'من حساب' : 'الحساب' }), selectOf(accs.map((a) => [a.id, a.name]), d.acc, (v) => (d.acc = v))),
        tr ? h('label', { class: 'field' }, h('span', { text: 'إلى حساب' }), selectOf(accs.map((a) => [a.id, a.name]), d.to, (v) => (d.to = v)))
          : h('label', { class: 'field' }, h('span', { text: 'التاريخ' }), dateIn())),
      tr ? h('label', { class: 'field' }, h('span', { text: 'التاريخ' }), dateIn()) : null,
      tr ? null : h('div', { class: 'field' }, h('span', { text: 'النوع' }), segRadio('fscope2', [['personal', 'شخصي'], ['work', 'عمل']], d.scope, (v) => { d.scope = v; paintCats(); paint(); })),
      tr ? null : h('div', { class: 'field' }, h('span', { text: 'التصنيف' }), catBox),
      d.type === 'income' && f.clients.length ? h('label', { class: 'field' }, h('span', { text: 'العميل (اختياري)' }), selectOf([['', '—'], ...f.clients.map((c) => [c.id, c.name])], d.client, (v) => (d.client = v))) : null,
      d.type === 'expense' && d.scope === 'work' ? (() => { const sw = h('input', { type: 'checkbox', checked: !!d.vat }); sw.addEventListener('change', () => (d.vat = sw.checked)); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: `المبلغ شامل ضريبة ${UI.n(f.settings.vatRate)}٪` }), h('small', { text: 'تُحسب في ملخص الضريبة كضريبة مدفوعة' })), h('span', { class: 'switch' }, sw, h('span', { class: 'track' }))); })() : null,
      (() => { const n = h('input', { class: 'input', placeholder: 'ملاحظة (اختياري)', maxlength: 200, value: d.note || '' }); n.addEventListener('input', () => (d.note = n.value)); const w = h('span', { class: 'vc-wrap' }, n); if (typeof Voice !== 'undefined') Voice.attach(n, 'finance', { replace: false }); return w; })(),
    ].filter(Boolean));
    if (!tr) paintCats();
    UI.digitize(extra);
  };
  function dateIn() { const i = h('input', { class: 'input', type: 'date', value: d.date }); i.addEventListener('change', () => (d.date = i.value || fymd())); return i; }
  const save = async () => {
    const v = Math.round(parseFloat(String(amount.value).replace(/[٠-٩]/g, (x) => '٠١٢٣٤٥٦٧٨٩'.indexOf(x)).replace(/[٫,]/g, '.')) * 100) / 100;
    if (!(v > 0)) { err.textContent = 'أدخل المبلغ'; amount.focus(); return; }
    if (!d.acc) { err.textContent = 'أضف حساباً أولاً'; return; }
    if (d.type === 'transfer' && d.acc === d.to) { err.textContent = 'اختر حسابين مختلفين'; return; }
    const t = { id: editing?.id || uid(), type: d.type, amount: v, acc: d.acc, date: d.date || fymd(), note: (d.note || '').trim(), createdAt: editing?.createdAt || Date.now(), updatedAt: Date.now() };
    if (d.type === 'transfer') t.to = d.to; else { t.cat = d.cat; t.scope = d.scope; }
    if (d.type === 'income' && d.client) t.client = d.client;
    if (d.type === 'expense' && d.vat && d.scope === 'work') t.vat = true;
    if (editing?.invoice) t.invoice = editing.invoice;
    await fsave((x) => { const i = x.tx.findIndex((y) => y.id === t.id); if (i >= 0) x.tx[i] = t; else x.tx.push(t); });
    closeSheet(finSheetEl);
    buzz('success');
    if (!editing && typeof markActive === 'function') markActive('tx');
    toast(editing ? 'تم الحفظ' : d.type === 'income' ? `أُضيف دخل ${money(v, { show: true })}` : d.type === 'expense' ? `سُجّل مصروف ${money(v, { show: true })}` : 'تم التحويل', { type: 'success' });
  };
  finSheet(editing ? 'تعديل الحركة' : 'حركة جديدة', [
    segRadio('ftype', [['expense', 'مصروف', 'p-high'], ['income', 'دخل', 'f-in'], ['transfer', 'تحويل']], d.type, (v) => { d.type = v; paint(); }),
    h('div', { class: 'f-amount-wrap' }, amount, h('span', { text: f.settings.currency })),
    extra, err,
  ], [
    editing ? h('button', { type: 'button', class: 'btn btn-danger-ghost', onclick: async () => {
      const copy = { ...editing };
      closeSheet(finSheetEl);
      await commit((v) => { v.fin = normFin(v.fin); Trash.put(v, 'tx', copy); v.fin.tx = v.fin.tx.filter((y) => y.id !== editing.id); });
      toast('🗑️ الحركة انتقلت لسلة المحذوفات', { action: { label: 'تراجع', run: () => Trash.undo('tx', copy.id) }, duration: 6000 });
    } }, icon('trash', { size: 17 }), 'حذف') : null,
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: save }, 'حفظ'),
  ], 'f-sheet');
  paint();
  if (!editing) setTimeout(() => amount.focus(), 280);
  amount.addEventListener('keydown', (e) => { if (e.key === 'Enter') save(); });
}

/* ---------- الحسابات (إضافة/تعديل) ---------- */
function openAccountSheet(a = null) {
  const f = fin();
  if (!a && !proOk('finance.accounts', f.accounts.filter((x) => !x.archived).length)) return;
  const d = { name: '', type: 'bank', opening: 0, color: FIN_COLORS[f.accounts.length % FIN_COLORS.length], ...(a || {}) };
  const name = h('input', { class: 'input', value: d.name, placeholder: Content.get('exAccount'), maxlength: 40 });
  const open = h('input', { class: 'input num', inputmode: 'decimal', value: d.opening || '', placeholder: '0' });
  const used = a && f.tx.some((t) => t.acc === a.id || t.to === a.id);
  const colors = h('div', { class: 'f-colors' });
  const paintColors = () => frep(colors, ...FIN_COLORS.slice(0, 8).map((c) => h('button', { type: 'button', class: `f-color${d.color === c ? ' on' : ''}`, style: { background: c }, 'aria-label': 'لون', onclick: () => { d.color = c; paintColors(); } })));
  paintColors();
  finSheet(a ? 'تعديل الحساب' : 'حساب جديد', [
    h('label', { class: 'field' }, h('span', { text: 'اسم الحساب' }), name),
    h('div', { class: 'field' }, h('span', { text: 'النوع' }), segRadio('facct', Object.entries(ACC_TYPES).map(([k, [l]]) => [k, l]), d.type, (v) => (d.type = v))),
    h('label', { class: 'field' }, h('span', { text: 'الرصيد الافتتاحي' }), open),
    h('div', { class: 'field' }, h('span', { text: 'اللون' }), colors),
  ], [
    a ? h('button', { type: 'button', class: 'btn btn-danger-ghost', onclick: async () => {
      closeSheet(finSheetEl);
      await fsave((x) => { const i = x.accounts.findIndex((y) => y.id === a.id); if (used) x.accounts[i].archived = true; else x.accounts.splice(i, 1); });
      toast(used ? 'أُرشف الحساب (له حركات مسجّلة)' : 'حُذف الحساب');
    } }, icon('trash', { size: 17 }), used ? 'أرشفة' : 'حذف') : null,
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      if (!name.value.trim()) return name.focus();
      const acc = { id: a?.id || uid(), name: name.value.trim(), type: d.type, opening: parseFloat(open.value) || 0, color: d.color, archived: false };
      await fsave((x) => { const i = x.accounts.findIndex((y) => y.id === acc.id); if (i >= 0) x.accounts[i] = acc; else x.accounts.push(acc); });
      closeSheet(finSheetEl);
      toast('تم حفظ الحساب', { type: 'success' });
    } }, 'حفظ'),
  ]);
}

/* ================= الفواتير ================= */
function finInvoices(body, f) {
  const list = [...f.invoices].sort((a, b) => b.no - a.no);
  const outstanding = list.filter((i) => i.status !== 'paid').reduce((s, i) => s + invTotals(f, i).total, 0);
  const late = list.filter((i) => invState(i) === 'late');
  const paidM = list.filter((i) => i.status === 'paid' && ymOf(i.paidAt || '') === ymOf(fymd())).reduce((s, i) => s + invTotals(f, i).total, 0);
  fput(body, 
    h('div', { class: 'f-mini' },
      h('div', {}, h('small', { text: 'مستحقات' }), h('b', { class: 'num', text: money(outstanding) })),
      h('div', {}, h('small', { text: 'متأخرة' }), h('b', { class: `num ${late.length ? 'neg' : ''}`, text: UI.n(late.length) })),
      h('div', {}, h('small', { text: 'حُصّل هذا الشهر' }), h('b', { class: 'num income', text: money(paidM) }))),
    h('div', { class: 'f-sec' }, h('b', { text: 'الفواتير' }),
      h('div', { class: 'f-sec-act' }, h('button', { type: 'button', class: 'link-btn', onclick: openClientsSheet }, 'العملاء'), h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => openInvoiceSheet() }, icon('plus', { size: 15 }), 'فاتورة'))),
    list.length ? h('div', { class: 'f-list' }, ...list.map((inv) => {
      const st = invState(inv), t = invTotals(f, inv);
      return h('button', { type: 'button', class: 'f-row', onclick: () => openInvoiceView(inv) },
        h('span', { class: `f-row-ic inv st-${st}` }, icon('receipt', { size: 17 })),
        h('span', { class: 'f-row-t' }, h('b', { text: clientOf(f, inv.client)?.name || 'بدون عميل' }), h('small', { class: 'num', text: `${invNo(f, inv.no)} · ${shortDate(inv.date)}${inv.due ? ' · تستحق ' + shortDate(inv.due) : ''}` })),
        h('span', { class: 'f-row-v' }, h('b', { class: 'num', text: money(t.total) }), h('span', { class: `f-st st-${st}`, text: INV_ST[st] })));
    })) : h('div', { class: 'empty f-empty' }, icon('receipt', { size: 34 }), h('h3', { text: 'أول فاتورة لعميلك' }), h('p', { text: 'أنشئ فاتورة ببنود وضريبة، وشاركها معه، وسجّلها كدخل عند الدفع.' })));
}

function openClientsSheet() {
  const f = fin();
  const name = h('input', { class: 'input', placeholder: 'اسم العميل أو الجهة', maxlength: 60 });
  const phone = h('input', { class: 'input ltr', placeholder: 'الجوال (اختياري)', inputmode: 'tel', maxlength: 20 });
  const bal = (id) => f.invoices.filter((i) => i.client === id && i.status !== 'paid').reduce((s, i) => s + invTotals(f, i).total, 0);
  const earned = (id) => f.tx.filter((t) => t.client === id && t.type === 'income').reduce((s, t) => s + t.amount, 0);
  finSheet('العملاء', [
    f.clients.length ? h('div', { class: 'f-list' }, ...f.clients.map((c) => h('div', { class: 'f-row static' },
      h('span', { class: 'f-row-ic', style: { '--cc': FIN_COLORS[c.name.length % FIN_COLORS.length] } }, h('b', { text: c.name.charAt(0) })),
      h('span', { class: 'f-row-t' }, h('b', { text: c.name }), h('small', { class: 'num', text: `دخل ${money(earned(c.id))} · مستحق ${money(bal(c.id))}` })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => {
        if (f.invoices.some((i) => i.client === c.id)) return toast('للعميل فواتير — لا يمكن حذفه');
        await commit((v) => { v.fin = normFin(v.fin); Trash.put(v, 'client', c); v.fin.clients = v.fin.clients.filter((y) => y.id !== c.id); });
        toast(`🗑️ «${c.name}» انتقل لسلة المحذوفات`, { action: { label: 'تراجع', run: () => Trash.undo('client', c.id).then(openClientsSheet) }, duration: 6000 });
        openClientsSheet();
      } }, icon('trash', { size: 15 }))))) : h('p', { class: 'hint', text: 'لا يوجد عملاء بعد.' }),
    h('div', { class: 'set-card' }, h('strong', { text: 'عميل جديد' }), name, phone,
      h('button', { type: 'button', class: 'btn', onclick: async () => {
        if (!name.value.trim()) return name.focus();
        await fsave((x) => { x.clients.push({ id: uid(), name: name.value.trim(), phone: phone.value.trim() }); });
        openClientsSheet();
      } }, 'إضافة')),
  ]);
}

function openInvoiceSheet(src = null) {
  if (fin().settings.lock && !FIN.unlocked) return unlockFinance();
  if (!src && !proOk('finance.invoices', fin().invoices.length)) return;
  const f = fin();
  const d = src ? JSON.parse(JSON.stringify(src)) : { client: f.clients[0]?.id || '', date: fymd(), due: fAddDays(fymd(), 14), items: [{ desc: '', qty: 1, price: '' }], vat: false, note: '', status: 'draft' };
  const err = h('p', { class: 'error-text' });
  const itemsBox = h('div', { class: 'f-items' });
  const totals = h('div', { class: 'f-totals' });
  const paintTotals = () => {
    const t = invTotals(f, d);
    frep(totals, 
      h('div', {}, h('span', { text: 'المجموع' }), h('b', { class: 'num', text: money(t.sub, { show: true }) })),
      d.vat ? h('div', {}, h('span', { text: `ضريبة القيمة المضافة ${UI.n(f.settings.vatRate)}٪` }), h('b', { class: 'num', text: money(t.vat, { show: true }) })) : null,
      h('div', { class: 'grand' }, h('span', { text: 'الإجمالي' }), h('b', { class: 'num', text: money(t.total, { show: true }) })));
    UI.digitize(totals);
  };
  const paintItems = () => {
    frep(itemsBox, ...d.items.map((it, i) => {
      const desc = h('input', { class: 'input', placeholder: Content.get('exInvoiceItem'), value: it.desc, maxlength: 120 });
      const qty = h('input', { class: 'input num', inputmode: 'decimal', value: it.qty, 'aria-label': 'الكمية' });
      const price = h('input', { class: 'input num', inputmode: 'decimal', value: it.price, placeholder: 'السعر', 'aria-label': 'السعر' });
      desc.addEventListener('input', () => (it.desc = desc.value));
      qty.addEventListener('input', () => { it.qty = parseFloat(qty.value) || 0; paintTotals(); });
      price.addEventListener('input', () => { it.price = parseFloat(price.value) || 0; paintTotals(); });
      return h('div', { class: 'f-item' }, desc, h('div', { class: 'f-item-n' }, qty, h('span', { text: '×' }), price,
        d.items.length > 1 ? h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف البند', onclick: () => { d.items.splice(i, 1); paintItems(); } }, icon('x', { size: 14 })) : null));
    }), h('button', { type: 'button', class: 'b-add', onclick: () => { d.items.push({ desc: '', qty: 1, price: '' }); paintItems(); } }, icon('plus', { size: 15 }), 'بند آخر'));
    paintTotals();
  };
  const newClient = h('input', { class: 'input', placeholder: 'أو اكتب اسم عميل جديد', maxlength: 60 });
  const vatSw = h('input', { type: 'checkbox', checked: !!d.vat });
  vatSw.addEventListener('change', () => { d.vat = vatSw.checked; paintTotals(); });
  const date = h('input', { class: 'input', type: 'date', value: d.date });
  const due = h('input', { class: 'input', type: 'date', value: d.due || '' });
  const note = h('textarea', { class: 'input textarea', rows: 2, placeholder: 'ملاحظة تظهر في الفاتورة (اختياري)', maxlength: 400 });
  note.value = d.note || '';
  finSheet(src ? `تعديل ${invNo(f, src.no)}` : 'فاتورة جديدة', [
    h('label', { class: 'field' }, h('span', { text: 'العميل' }), f.clients.length ? selectOf([['', '— اختر —'], ...f.clients.map((c) => [c.id, c.name])], d.client, (v) => (d.client = v)) : null, newClient),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'التاريخ' }), date), h('label', { class: 'field' }, h('span', { text: 'تاريخ الاستحقاق' }), due)),
    h('div', { class: 'field' }, h('span', { text: 'البنود' }), itemsBox),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: `إضافة ضريبة القيمة المضافة ${UI.n(f.settings.vatRate)}٪` })), h('span', { class: 'switch' }, vatSw, h('span', { class: 'track' }))),
    totals, note, err,
  ], [
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      d.items = d.items.filter((it) => String(it.desc).trim() || Number(it.price));
      if (!d.items.length) { d.items = [{ desc: '', qty: 1, price: '' }]; paintItems(); err.textContent = 'أضف بنداً واحداً على الأقل'; return; }
      let cid = d.client;
      const nc = newClient.value.trim();
      if (nc) cid = uid();
      if (!cid) { err.textContent = 'اختر العميل أو اكتب اسمه'; return; }
      const inv = { ...d, client: cid, date: date.value || fymd(), due: due.value || '', note: note.value.trim() };
      let saved;
      await fsave((x) => {
        if (nc) x.clients.push({ id: cid, name: nc });
        if (src) { const i = x.invoices.findIndex((y) => y.id === src.id); x.invoices[i] = { ...x.invoices[i], ...inv }; saved = x.invoices[i]; }
        else { saved = { ...inv, id: uid(), no: x.settings.nextInv, status: 'draft', createdAt: Date.now() }; x.settings.nextInv++; x.invoices.push(saved); }
      });
      closeSheet(finSheetEl);
      setTimeout(() => openInvoiceView(fin().invoices.find((y) => y.id === saved.id)), 230);
    } }, 'حفظ الفاتورة'),
  ], 'f-sheet');
  paintItems();
}

function openInvoiceView(inv) {
  const f = fin();
  inv = f.invoices.find((y) => y.id === inv.id) || inv;
  const st = invState(inv), t = invTotals(f, inv), c = clientOf(f, inv.client);
  const payAcc = h('select', { class: 'input select' }, ...f.accounts.filter((a) => !a.archived).map((a) => h('option', { value: a.id, text: a.name })));
  const payCat = h('select', { class: 'input select' }, ...f.cats.filter((x) => x.kind === 'income').map((x) => h('option', { value: x.id, text: x.name })));
  const setStatus = async (status) => { await fsave((x) => { const i = x.invoices.find((y) => y.id === inv.id); i.status = status; }); openInvoiceView(inv); };
  finSheet(invNo(f, inv.no), [
    h('div', { class: 'f-invhead' },
      h('div', {}, h('small', { text: 'العميل' }), h('b', { text: c?.name || '—' })),
      h('span', { class: `f-st big st-${st}`, text: INV_ST[st] })),
    h('div', { class: 'f-mini' },
      h('div', {}, h('small', { text: 'التاريخ' }), h('b', { class: 'num', text: shortDate(inv.date) })),
      h('div', {}, h('small', { text: 'الاستحقاق' }), h('b', { class: 'num', text: inv.due ? shortDate(inv.due) : '—' })),
      h('div', {}, h('small', { text: 'الإجمالي' }), h('b', { class: 'num', text: money(t.total, { show: true }) }))),
    h('div', { class: 'f-invitems' }, ...inv.items.map((it) => h('div', {}, h('span', { text: it.desc || 'بند' }), h('small', { class: 'num', text: `${UI.n(it.qty)} × ${money(it.price, { show: true, bare: true })}` }), h('b', { class: 'num', text: money((Number(it.qty) || 0) * (Number(it.price) || 0), { show: true, bare: true }) }))),
      inv.vat ? h('div', { class: 'vat' }, h('span', { text: `الضريبة ${UI.n(f.settings.vatRate)}٪` }), h('small'), h('b', { class: 'num', text: money(t.vat, { show: true, bare: true }) })) : null),
    inv.note ? h('p', { class: 'hint', text: inv.note }) : null,
    st !== 'paid' ? h('div', { class: 'set-card' }, h('strong', { text: 'تسجيل الدفع' }), h('p', { class: 'hint', text: 'يُضاف المبلغ كدخل «عمل» في الحساب المختار.' }),
      h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'استُلم في' }), payAcc), h('label', { class: 'field' }, h('span', { text: 'التصنيف' }), payCat)),
      h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
        await fsave((x) => {
          const i = x.invoices.find((y) => y.id === inv.id);
          const tx = { id: uid(), type: 'income', amount: Math.round(t.total * 100) / 100, acc: payAcc.value, cat: payCat.value, scope: 'work', date: fymd(), note: `فاتورة ${invNo(x, i.no)}`, client: i.client, invoice: i.id, createdAt: Date.now() };
          x.tx.push(tx);
          i.status = 'paid'; i.paidAt = fymd(); i.paidTx = tx.id;
        });
        buzz('success'); toast('تم تسجيل الدفع كدخل ✓', { type: 'success' });
        openInvoiceView(inv);
      } }, icon('check', { size: 17 }), 'تم الدفع')) : h('p', { class: 'ok-text', text: `دُفعت في ${shortDate(inv.paidAt)} وسُجّلت كدخل.` }),
  ], [
    h('button', { type: 'button', class: 'btn btn-danger-ghost', onclick: async () => {
      closeSheet(finSheetEl);
      const ok = await confirmSheet({ title: `حذف ${invNo(f, inv.no)}؟`, text: (inv.status === 'paid' ? 'ستبقى حركة الدخل المسجّلة. ' : '') + 'تنتقل لسلة المحذوفات وتقدر ترجّعها خلال ٣٠ يوم.', ok: 'حذف' });
      if (ok) {
        await commit((v) => { v.fin = normFin(v.fin); Trash.put(v, 'invoice', { ...inv, clientName: (f.clients.find((c) => c.id === inv.client) || {}).name || '' }); v.fin.invoices = v.fin.invoices.filter((y) => y.id !== inv.id); });
        toast('🗑️ الفاتورة انتقلت لسلة المحذوفات', { action: { label: 'تراجع', run: () => Trash.undo('invoice', inv.id) }, duration: 6000 });
      }
    } }, icon('trash', { size: 16 })),
    st !== 'paid' ? h('button', { type: 'button', class: 'btn', onclick: () => openInvoiceSheet(inv) }, icon('edit', { size: 16 }), 'تعديل') : null,
    h('div', { class: 'spacer' }),
    st === 'draft' ? h('button', { type: 'button', class: 'btn', onclick: () => setStatus('sent') }, 'تحديد كمرسلة') : null,
    h('button', { type: 'button', class: 'btn btn-primary', onclick: () => shareInvoice(inv) }, icon('share', { size: 16 }), 'مشاركة'),
  ], 'f-sheet');
}

function invoiceHTML(f, inv) {
  const t = invTotals(f, inv), c = clientOf(f, inv.client) || {};
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (x) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[x]));
  const fmt = (n) => new Intl.NumberFormat('ar-SA-u-nu-latn', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(n);
  const rows = inv.items.map((it, i) => `<tr><td>${i + 1}</td><td>${esc(it.desc)}</td><td>${esc(it.qty)}</td><td>${fmt(+it.price || 0)}</td><td>${fmt((+it.qty || 0) * (+it.price || 0))}</td></tr>`).join('');
  const biz = esc(f.settings.bizName || S.profile?.display_name || 'Noble Designer');
  return `<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${invNo(f, inv.no)}</title>
<style>body{font-family:system-ui,Tahoma,sans-serif;background:#f4f6fb;margin:0;padding:24px;color:#101733}.p{max-width:720px;margin:auto;background:#fff;border-radius:18px;padding:32px;box-shadow:0 10px 40px rgba(16,23,51,.08)}
.h{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;border-bottom:3px solid #F0922F;padding-bottom:18px}.h h1{margin:0;font-size:26px}.muted{color:#6b7493;font-size:14px}
table{width:100%;border-collapse:collapse;margin:22px 0}th{background:#101733;color:#fff;font-weight:600;padding:10px;text-align:right}td{padding:10px;border-bottom:1px solid #e6e9f2}
.t{margin-right:auto;max-width:300px}.t div{display:flex;justify-content:space-between;padding:6px 0}.t .g{font-size:20px;font-weight:700;border-top:2px solid #101733;margin-top:6px;padding-top:10px}
.b{display:inline-block;padding:4px 12px;border-radius:99px;background:${inv.status === 'paid' ? '#e3f8ea;color:#1f9d55' : '#fff4e6;color:#c77a12'};font-weight:700;font-size:13px}@media print{body{background:#fff;padding:0}.p{box-shadow:none}}</style></head>
<body><div class="p"><div class="h"><div><h1>فاتورة ${f.settings.bizVat && inv.vat ? 'ضريبية' : ''}</h1><div class="muted">${invNo(f, inv.no)}</div><div style="margin-top:8px"><span class="b">${INV_ST[invState(inv)]}</span></div></div>
<div style="text-align:left"><b style="font-size:18px">${biz}</b>${f.settings.bizVat ? `<div class="muted">الرقم الضريبي: ${esc(f.settings.bizVat)}</div>` : ''}</div></div>
<div style="display:flex;gap:40px;flex-wrap:wrap;margin-top:18px"><div><div class="muted">إلى</div><b>${esc(c.name || '—')}</b>${c.phone ? `<div class="muted" dir="ltr">${esc(c.phone)}</div>` : ''}</div>
<div><div class="muted">التاريخ</div><b>${inv.date}</b></div>${inv.due ? `<div><div class="muted">تاريخ الاستحقاق</div><b>${inv.due}</b></div>` : ''}</div>
<table><thead><tr><th>#</th><th>البند</th><th>الكمية</th><th>السعر</th><th>المجموع</th></tr></thead><tbody>${rows}</tbody></table>
<div class="t"><div><span>المجموع</span><b>${fmt(t.sub)}</b></div>${inv.vat ? `<div><span>ضريبة القيمة المضافة ${f.settings.vatRate}٪</span><b>${fmt(t.vat)}</b></div>` : ''}<div class="g"><span>الإجمالي</span><span>${fmt(t.total)} ${esc(f.settings.currency)}</span></div></div>
${inv.note ? `<p class="muted" style="margin-top:22px">${esc(inv.note)}</p>` : ''}<p class="muted" style="text-align:center;margin-top:30px;font-size:12px">أُنشئت عبر NOBLE</p></div></body></html>`;
}
async function shareInvoice(inv) {
  const f = fin();
  const t = invTotals(f, inv), c = clientOf(f, inv.client);
  if (inv.status === 'draft') await fsave((x) => { x.invoices.find((y) => y.id === inv.id).status = 'sent'; });
  try { await saveFile(`${invNo(f, inv.no)}.html`, invoiceHTML(f, inv), 'text/html'); }
  catch {
    const text = `فاتورة ${invNo(f, inv.no)}\nإلى: ${c?.name || ''}\nالإجمالي: ${money(t.total, { show: true })}${inv.due ? `\nتستحق: ${inv.due}` : ''}`;
    try { await navigator.clipboard.writeText(text); toast('نُسخت تفاصيل الفاتورة', { type: 'success' }); } catch { /* لا شيء */ }
  }
}

/* ================= الخطط: اشتراكات، ميزانيات، أهداف ================= */
function recurRow(f, r) {
  const today = fymd(), due = r.next <= today;
  const c = catOf(f, r.cat);
  return h('div', { class: `f-row static${due ? ' due' : ''}` },
    h('span', { class: `f-row-ic ${r.type}`, style: { '--cc': c?.color || '#7A86A8' } }, icon('repeat', { size: 16 })),
    h('span', { class: 'f-row-t', onclick: () => openRecurSheet(r) }, h('b', { text: r.name }), h('small', { class: 'num', text: `${EVERY[r.every]} · ${due ? 'مستحق ' : 'القادم '}${shortDate(r.next)}` })),
    h('span', { class: 'f-row-v' }, h('b', { class: `num ${r.type}`, text: money(r.type === 'income' ? r.amount : -r.amount, { sign: true }) }),
      due ? h('button', { type: 'button', class: 'btn sm btn-primary f-post', onclick: () => postRecurring(r.id) }, 'سجّل') : null));
}
const nextDate = (s, every) => { const d = new Date(s + 'T12:00'); if (every === 'weekly') d.setDate(d.getDate() + 7); else if (every === 'yearly') d.setFullYear(d.getFullYear() + 1); else d.setMonth(d.getMonth() + 1); return fymd(d); };
async function postRecurring(id) {
  await fsave((x) => {
    const r = x.recurring.find((y) => y.id === id);
    if (!r) return;
    x.tx.push({ id: uid(), type: r.type, amount: r.amount, acc: r.acc, cat: r.cat, scope: r.scope, date: r.next <= fymd() ? r.next : fymd(), note: r.name, recur: r.id, createdAt: Date.now() });
    r.next = nextDate(r.next, r.every);
  });
  buzz('success'); toast('سُجّلت الدفعة ✓', { type: 'success' });
  scheduleFinReminders();
}
function openRecurSheet(r = null) {
  if (!r && !proOk('finance.recurring', fin().recurring.length)) return;
  const f = fin();
  const accs = f.accounts.filter((a) => !a.archived);
  const d = { name: '', type: 'expense', amount: '', acc: accs[0]?.id, cat: '', scope: 'work', every: 'monthly', next: fymd(), remind: true, active: true, ...(r || {}) };
  const name = h('input', { class: 'input', value: d.name, placeholder: Content.get('exRecurring'), maxlength: 60 });
  const amount = h('input', { class: 'input num', inputmode: 'decimal', value: d.amount, placeholder: 'المبلغ' });
  const next = h('input', { class: 'input', type: 'date', value: d.next });
  const catSel = h('div');
  const paintCat = () => {
    const cats = f.cats.filter((c) => c.kind === d.type && (d.type === 'income' || c.scope === d.scope || c.scope === 'both'));
    if (!cats.some((c) => c.id === d.cat)) d.cat = cats[0]?.id;
    frep(catSel, selectOf(cats.map((c) => [c.id, c.name]), d.cat, (v) => (d.cat = v)));
  };
  const rem = h('input', { type: 'checkbox', checked: d.remind !== false });
  finSheet(r ? 'تعديل الدفعة المتكررة' : 'اشتراك / دفعة متكررة', [
    segRadio('frtype', [['expense', 'مصروف', 'p-high'], ['income', 'دخل', 'f-in']], d.type, (v) => { d.type = v; paintCat(); }),
    h('label', { class: 'field' }, h('span', { text: 'الاسم' }), name),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'المبلغ' }), amount), h('label', { class: 'field' }, h('span', { text: 'التكرار' }), selectOf(Object.entries(EVERY), d.every, (v) => (d.every = v)))),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'الموعد القادم' }), next), h('label', { class: 'field' }, h('span', { text: 'الحساب' }), selectOf(accs.map((a) => [a.id, a.name]), d.acc, (v) => (d.acc = v)))),
    h('div', { class: 'field' }, h('span', { text: 'النوع' }), segRadio('frscope', [['personal', 'شخصي'], ['work', 'عمل']], d.scope, (v) => { d.scope = v; paintCat(); })),
    h('label', { class: 'field' }, h('span', { text: 'التصنيف' }), catSel),
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'تنبيه يوم الاستحقاق' }), h('small', { text: 'إشعار الساعة ٩ صباحاً' })), h('span', { class: 'switch' }, rem, h('span', { class: 'track' }))),
  ], [
    r ? h('button', { type: 'button', class: 'btn btn-danger-ghost', onclick: async () => { closeSheet(finSheetEl); await fsave((x) => { x.recurring = x.recurring.filter((y) => y.id !== r.id); }); scheduleFinReminders(); } }, icon('trash', { size: 16 })) : null,
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      const v = parseFloat(amount.value);
      if (!name.value.trim()) return name.focus();
      if (!(v > 0)) return amount.focus();
      const rec = { id: r?.id || uid(), name: name.value.trim(), type: d.type, amount: v, acc: d.acc, cat: d.cat, scope: d.scope, every: d.every, next: next.value || fymd(), remind: rem.checked, active: true };
      await fsave((x) => { const i = x.recurring.findIndex((y) => y.id === rec.id); if (i >= 0) x.recurring[i] = rec; else x.recurring.push(rec); });
      closeSheet(finSheetEl);
      scheduleFinReminders();
      toast('تم الحفظ', { type: 'success' });
    } }, 'حفظ'),
  ]);
  buzz("success"); toast("تم التسجيل ✓", { type: "success" });
}

function finPlans(body, f) {
  const curM = ymOf(fymd());
  const spent = catSpend(f, curM, 'all');
  const exCats = f.cats.filter((c) => c.kind === 'expense');
  const budgeted = exCats.filter((c) => f.budgets[c.id] > 0);
  const totB = budgeted.reduce((s, c) => s + f.budgets[c.id], 0), totS = budgeted.reduce((s, c) => s + (spent[c.id] || 0), 0);
  const monthlyRec = f.recurring.filter((r) => r.type === 'expense' && r.active !== false).reduce((s, r) => s + (r.every === 'weekly' ? r.amount * 52 / 12 : r.every === 'yearly' ? r.amount / 12 : r.amount), 0);
  fput(body, 
    h('div', { class: 'f-sec' }, h('b', { text: 'الاشتراكات والمدفوعات المتكررة' }), h('button', { type: 'button', class: 'btn sm', onclick: () => openRecurSheet() }, icon('plus', { size: 15 }), 'إضافة')),
    f.recurring.length ? h('p', { class: 'hint f-hint num', text: `تكلفتها الشهرية التقريبية ${money(monthlyRec)}` }) : null,
    f.recurring.length ? h('div', { class: 'f-list' }, ...[...f.recurring].sort((a, b) => a.next.localeCompare(b.next)).map((r) => recurRow(f, r)))
      : h('p', { class: 'hint f-hint', text: 'أضف اشتراكاتك مثل Adobe و ChatGPT والإيجار، ويذكّرك التطبيق قبل موعدها.' }),
    h('div', { class: 'f-sec' }, h('b', { text: `ميزانية ${monthName(curM)}` }), h('button', { type: 'button', class: 'btn sm', onclick: openBudgetSheet }, icon('edit', { size: 14 }), 'تعديل')),
    budgeted.length ? h('div', { class: 'f-card' },
      h('div', { class: 'f-budget total' }, h('div', { class: 'fb-t' }, h('b', { text: 'الإجمالي' }), h('small', { class: 'num', text: `${money(totS)} من ${money(totB)}` })), progress(totS, totB)),
      ...budgeted.map((c) => h('div', { class: 'f-budget' }, h('div', { class: 'fb-t' }, h('span', { class: 'f-cdot', style: { background: c.color } }), h('b', { text: c.name }), h('small', { class: 'num', text: `${money(spent[c.id] || 0)} / ${money(f.budgets[c.id])}` })), progress(spent[c.id] || 0, f.budgets[c.id]))))
      : h('p', { class: 'hint f-hint', text: 'حدّد سقفاً شهرياً لكل تصنيف، وينبّهك التطبيق عند ٨٠٪.' }),
    h('div', { class: 'f-sec' }, h('b', { text: 'أهداف الادخار' }), h('button', { type: 'button', class: 'btn sm', onclick: () => openGoalSheet() }, icon('plus', { size: 15 }), 'هدف')),
    f.goals.length ? h('div', { class: 'f-goals' }, ...f.goals.map((g) => {
      const pct = Math.min(100, Math.round((g.saved / g.target) * 100) || 0);
      return h('button', { type: 'button', class: 'f-goal', style: { '--gc': g.color || FIN_COLORS[2] }, onclick: () => openGoalSheet(g) },
        ring(pct), h('b', { text: g.name }), h('small', { class: 'num', text: `${money(g.saved)} / ${money(g.target)}` }),
        g.deadline ? h('small', { class: 'num', text: `قبل ${shortDate(g.deadline)}` }) : null);
    })) : h('p', { class: 'hint f-hint', text: 'مثال: كاميرا جديدة، طوارئ، سفر — وتابع تقدّمك بالنسبة.' }));
}
function progress(v, max) {
  const p = max > 0 ? v / max : 0;
  return h('div', { class: `f-prog${p >= 1 ? ' over' : p >= 0.8 ? ' warn' : ''}` }, h('i', { style: { width: Math.min(100, p * 100) + '%' } }));
}
function ring(pct) {
  const R = 26, C = 2 * Math.PI * R;
  const n = svgNode(`<svg class="f-ring" viewBox="0 0 64 64" width="64" height="64"><circle cx="32" cy="32" r="${R}" class="rb"/><circle cx="32" cy="32" r="${R}" class="rf" stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - pct / 100)}"/><text x="32" y="37" text-anchor="middle">${UI.n(pct)}٪</text></svg>`);
  return n;
}
function openBudgetSheet() {
  const f = fin();
  if (!Object.values(f.budgets || {}).some((b) => b > 0) && !proOk('finance.plan')) return;
  const vals = { ...f.budgets };
  const spent = catSpend(f, ymOf(fymd()), 'all');
  const rows = f.cats.filter((c) => c.kind === 'expense').map((c) => {
    const i = h('input', { class: 'input num fb-in', inputmode: 'decimal', value: vals[c.id] || '', placeholder: '—' });
    i.addEventListener('input', () => (vals[c.id] = parseFloat(i.value) || 0));
    return h('div', { class: 'fb-row' }, h('span', { class: 'f-cdot', style: { background: c.color } }), h('span', { class: 'fb-n' }, h('b', { text: c.name }), h('small', { class: 'num', text: `${SCOPES[c.scope] || ''} · صُرف ${money(spent[c.id] || 0, { show: true })}` })), i);
  });
  finSheet('الميزانية الشهرية', [h('p', { class: 'hint', text: 'اكتب السقف الشهري لكل تصنيف (اتركه فارغاً بدون ميزانية).' }), ...rows], [
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      await fsave((x) => { x.budgets = Object.fromEntries(Object.entries(vals).filter(([, v]) => v > 0)); });
      closeSheet(finSheetEl); toast('حُفظت الميزانية', { type: 'success' });
    } }, 'حفظ'),
  ]);
}
function openGoalSheet(g = null) {
  if (!g && !proOk('finance.plan')) return;
  const d = { name: '', target: '', saved: 0, deadline: '', color: FIN_COLORS[2], ...(g || {}) };
  const name = h('input', { class: 'input', value: d.name, placeholder: Content.get('exGoal'), maxlength: 40 });
  const target = h('input', { class: 'input num', inputmode: 'decimal', value: d.target, placeholder: 'المبلغ المستهدف' });
  const dl = h('input', { class: 'input', type: 'date', value: d.deadline || '' });
  const add = h('input', { class: 'input num', inputmode: 'decimal', placeholder: 'أضف مبلغاً' });
  finSheet(g ? g.name : 'هدف ادخار جديد', [
    g ? h('div', { class: 'f-goal big', style: { '--gc': d.color } }, ring(Math.min(100, Math.round((d.saved / d.target) * 100) || 0)), h('b', { class: 'num', text: `${money(d.saved, { show: true })} من ${money(d.target, { show: true })}` })) : null,
    g ? h('div', { class: 'f-addgoal' }, add, h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      const v = parseFloat(add.value); if (!v) return add.focus();
      await fsave((x) => { const y = x.goals.find((z) => z.id === g.id); y.saved = Math.max(0, (y.saved || 0) + v); });
      buzz('success'); openGoalSheet(fin().goals.find((z) => z.id === g.id));
    } }, '+ ادخار')) : null,
    h('label', { class: 'field' }, h('span', { text: 'اسم الهدف' }), name),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'المستهدف' }), target), h('label', { class: 'field' }, h('span', { text: 'الموعد (اختياري)' }), dl)),
  ], [
    g ? h('button', { type: 'button', class: 'btn btn-danger-ghost', onclick: async () => { closeSheet(finSheetEl); await fsave((x) => { x.goals = x.goals.filter((y) => y.id !== g.id); }); } }, icon('trash', { size: 16 })) : null,
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      const t = parseFloat(target.value);
      if (!name.value.trim()) return name.focus();
      if (!(t > 0)) return target.focus();
      const goal = { id: g?.id || uid(), name: name.value.trim(), target: t, saved: d.saved || 0, deadline: dl.value, color: d.color || FIN_COLORS[fin().goals.length % FIN_COLORS.length] };
      await fsave((x) => { const i = x.goals.findIndex((y) => y.id === goal.id); if (i >= 0) x.goals[i] = goal; else x.goals.push(goal); });
      closeSheet(finSheetEl);
    } }, 'حفظ'),
  ]);
}

/* ================= التقارير ================= */
function periodRange(p) {
  const now = new Date(), cur = ymOf(fymd());
  if (p === 'month') return { from: cur + '-01', to: cur + '-31', label: monthName(cur), months: [cur] };
  if (p === 'last') { const l = addMonths(cur, -1); return { from: l + '-01', to: l + '-31', label: monthName(l), months: [l] }; }
  if (p === 'year') { const y = now.getFullYear(); return { from: `${y}-01-01`, to: `${y}-12-31`, label: `سنة ${UI.n(y)}`, months: Array.from({ length: now.getMonth() + 1 }, (_, i) => `${y}-${String(i + 1).padStart(2, '0')}`) }; }
  return { from: '0000', to: '9999', label: 'كل الفترات', months: Array.from({ length: 12 }, (_, i) => addMonths(cur, i - 11)) };
}
function finReports(body, f) {
  const P = periodRange(FIN.period);
  const txs = f.tx.filter((t) => t.date >= P.from && t.date <= P.to && inScope(t));
  const s = sums(txs);
  const rate = s.inc > 0 ? Math.round((s.net / s.inc) * 100) : 0;
  const byCat = {};
  txs.filter((t) => t.type === 'expense').forEach((t) => (byCat[t.cat] = (byCat[t.cat] || 0) + t.amount));
  const slices = Object.entries(byCat).sort((a, b) => b[1] - a[1]).map(([id, v]) => ({ label: catOf(f, id)?.name || 'أخرى', value: v, color: catOf(f, id)?.color || '#7A86A8' }));
  const incCat = {};
  txs.filter((t) => t.type === 'income').forEach((t) => (incCat[t.cat] = (incCat[t.cat] || 0) + t.amount));
  const allP = f.tx.filter((t) => t.date >= P.from && t.date <= P.to);
  const pers = sums(allP.filter((t) => t.scope === 'personal')), work = sums(allP.filter((t) => t.scope === 'work'));
  const clientsInc = {};
  txs.filter((t) => t.type === 'income' && t.client).forEach((t) => (clientsInc[t.client] = (clientsInc[t.client] || 0) + t.amount));
  const vatOut = f.invoices.filter((i) => i.status === 'paid' && i.vat && i.paidAt >= P.from && i.paidAt <= P.to).reduce((a, i) => a + invTotals(f, i).vat, 0);
  const vr = Number(f.settings.vatRate) || 0;
  const vatIn = f.tx.filter((t) => t.vat && t.type === 'expense' && t.date >= P.from && t.date <= P.to).reduce((a, t) => a + t.amount * vr / (100 + vr), 0);
  const recv = f.invoices.filter((i) => i.status !== 'paid').reduce((a, i) => a + invTotals(f, i).total, 0);
  // التدفق النقدي: رصيد تراكمي نهاية كل شهر
  let run = f.accounts.reduce((a, x) => a + (Number(x.opening) || 0), 0);
  const firstM = P.months[0];
  f.tx.forEach((t) => { if (ymOf(t.date) < firstM) run += t.type === 'income' ? t.amount : t.type === 'expense' ? -t.amount : 0; });
  const flow = P.months.map((ym) => { const ms = sums(f.tx.filter((t) => ymOf(t.date) === ym)); run += ms.net; return { label: monthShort(ym), v: run }; });

  fput(body, 
    h('div', { class: 'seg seg-4 f-period' }, ...[['month', 'هذا الشهر'], ['last', 'الماضي'], ['year', 'هذه السنة'], ['all', '١٢ شهر']].map(([k, l]) =>
      h('label', {}, h('input', { type: 'radio', name: 'fper', value: k, checked: FIN.period === k, onchange: () => { FIN.period = k; renderFinance(); } }), h('span', { text: l })))),
    h('div', { class: 'f-card f-pl' },
      h('div', { class: 'f-sec in-card' }, h('b', { text: 'قائمة الدخل' }), h('small', { class: 'hint', text: P.label })),
      h('div', { class: 'pl-row' }, h('span', { text: 'الإيرادات' }), h('b', { class: 'num income', text: money(s.inc) })),
      ...Object.entries(incCat).sort((a, b) => b[1] - a[1]).map(([id, v]) => h('div', { class: 'pl-row sub' }, h('span', { text: catOf(f, id)?.name || 'أخرى' }), h('span', { class: 'num', text: money(v) }))),
      h('div', { class: 'pl-row' }, h('span', { text: 'المصروفات' }), h('b', { class: 'num expense', text: money(-s.exp) })),
      h('div', { class: 'pl-row total' }, h('span', { text: s.net >= 0 ? 'صافي الربح' : 'صافي الخسارة' }), h('b', { class: `num ${s.net < 0 ? 'neg' : 'income'}`, text: money(s.net, { sign: true }) })),
      h('div', { class: 'pl-kpis' }, h('div', {}, h('small', { text: 'نسبة الادخار' }), h('b', { class: 'num', text: `${UI.n(rate)}٪` })), h('div', {}, h('small', { text: 'مستحقات العملاء' }), h('b', { class: 'num', text: money(recv) })))),
    h('div', { class: 'f-card' },
      h('div', { class: 'f-sec in-card' }, h('b', { text: 'الدخل مقابل المصروف' }), h('span', { class: 'f-legend' }, h('i', { class: 'in' }), 'دخل', h('i', { class: 'out' }), 'مصروف')),
      barChart(P.months.slice(-12).map((ym) => { const ms = sums(f.tx.filter((t) => ymOf(t.date) === ym && inScope(t))); return { label: monthShort(ym), a: ms.inc, b: ms.exp }; }))),
    h('div', { class: 'f-card' }, h('div', { class: 'f-sec in-card' }, h('b', { text: 'توزيع المصروفات' })),
      slices.length ? donut(slices, s.exp) : h('p', { class: 'hint', text: 'لا مصروفات في هذه الفترة.' })),
    h('div', { class: 'f-card' }, h('div', { class: 'f-sec in-card' }, h('b', { text: 'الشخصي مقابل العمل' })),
      splitBar('الدخل', work.inc, pers.inc), splitBar('المصروف', work.exp, pers.exp),
      h('div', { class: 'f-legend' }, h('i', { class: 'work' }), 'عمل', h('i', { class: 'pers' }), 'شخصي')),
    FIN.period !== 'month' && FIN.period !== 'last' ? h('div', { class: 'f-card' }, h('div', { class: 'f-sec in-card' }, h('b', { text: 'التدفق النقدي (الرصيد نهاية كل شهر)' })), lineChart(flow)) : null,
    Object.keys(clientsInc).length ? h('div', { class: 'f-card' }, h('div', { class: 'f-sec in-card' }, h('b', { text: 'أعلى العملاء دخلاً' })),
      ...Object.entries(clientsInc).sort((a, b) => b[1] - a[1]).slice(0, 5).map(([id, v], i, arr) => h('div', { class: 'f-hbar' }, h('span', { text: clientOf(f, id)?.name || '—' }), h('div', {}, h('i', { style: { width: (v / arr[0][1]) * 100 + '%' } })), h('b', { class: 'num', text: money(v) })))) : null,
    h('div', { class: 'f-card' }, h('div', { class: 'f-sec in-card' }, h('b', { text: `ملخص ضريبة القيمة المضافة ${UI.n(vr)}٪` })),
      h('div', { class: 'pl-row' }, h('span', { text: 'ضريبة محصّلة (فواتير مدفوعة)' }), h('span', { class: 'num', text: money(vatOut) })),
      h('div', { class: 'pl-row' }, h('span', { text: 'ضريبة مدفوعة (مصروفات عمل)' }), h('span', { class: 'num', text: money(-vatIn) })),
      h('div', { class: 'pl-row total' }, h('span', { text: vatOut - vatIn >= 0 ? 'صافي المستحق للهيئة' : 'صافي المسترد' }), h('b', { class: 'num', text: money(Math.abs(vatOut - vatIn)) })),
      h('p', { class: 'hint', text: 'تقدير للمتابعة فقط — راجع محاسبك قبل تقديم الإقرار.' })),
    h('button', { type: 'button', class: 'btn btn-block', onclick: exportFinCSV }, icon('download', { size: 17 }), 'تصدير الحركات Excel'));
}

/* ---------- الرسوم البيانية (SVG) ---------- */
const svgT = (s) => s.replace(/[&<>]/g, (x) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[x]));
function niceMax(v) { if (v <= 0) return 1; const p = 10 ** Math.floor(Math.log10(v)); const n = v / p; return (n <= 1 ? 1 : n <= 2 ? 2 : n <= 5 ? 5 : 10) * p; }
const kfmt = (v) => UI.n(v >= 1e6 ? (v / 1e6).toFixed(1).replace(/\.0$/, '') + 'م' : v >= 1e3 ? (v / 1e3).toFixed(1).replace(/\.0$/, '') + 'ك' : Math.round(v));
function barChart(data) {
  const W = 340, H = 170, L = 34, B = 24, T = 10;
  const max = niceMax(Math.max(1, ...data.map((d) => Math.max(d.a, d.b))));
  const gw = (W - L - 6) / Math.max(1, data.length), bw = Math.min(16, gw * 0.32);
  const Y = (v) => T + (H - T - B) * (1 - v / max);
  let s = '';
  [0, 0.5, 1].forEach((k) => { const y = Y(max * k); s += `<line x1="${L}" x2="${W}" y1="${y}" y2="${y}" class="g"/><text x="${L - 6}" y="${y + 4}" text-anchor="end" class="ax">${FIN.hide ? '' : kfmt(max * k)}</text>`; });
  data.forEach((d, i) => {
    const cx = L + gw * i + gw / 2;
    s += `<rect x="${cx - bw - 1}" y="${Y(d.a)}" width="${bw}" height="${Math.max(0, H - B - Y(d.a))}" rx="3" class="in"/>`;
    s += `<rect x="${cx + 1}" y="${Y(d.b)}" width="${bw}" height="${Math.max(0, H - B - Y(d.b))}" rx="3" class="out"/>`;
    s += `<text x="${cx}" y="${H - 6}" text-anchor="middle" class="ax">${svgT(d.label)}</text>`;
  });
  return svgNode(`<svg class="f-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="رسم الدخل والمصروف">${s}</svg>`);
}
function lineChart(data) {
  const W = 340, H = 160, L = 34, B = 24, T = 12;
  const vals = data.map((d) => d.v);
  const lo = Math.min(0, ...vals), hi = niceMax(Math.max(1, ...vals));
  const X = (i) => L + ((W - L - 10) * i) / Math.max(1, data.length - 1), Y = (v) => T + (H - T - B) * (1 - (v - lo) / (hi - lo || 1));
  const pts = data.map((d, i) => `${X(i)},${Y(d.v)}`).join(' ');
  let s = `<line x1="${L}" x2="${W}" y1="${Y(0)}" y2="${Y(0)}" class="g"/><text x="${L - 6}" y="${Y(hi) + 4}" text-anchor="end" class="ax">${FIN.hide ? '' : kfmt(hi)}</text><text x="${L - 6}" y="${Y(0) + 4}" text-anchor="end" class="ax">${UI.n(0)}</text>`;
  s += `<polygon points="${L},${Y(lo)} ${pts} ${X(data.length - 1)},${Y(lo)}" class="area"/><polyline points="${pts}" class="line"/>`;
  data.forEach((d, i) => { if (i === data.length - 1 || i % 2 === 0) s += `<text x="${X(i)}" y="${H - 6}" text-anchor="middle" class="ax">${svgT(d.label)}</text>`; });
  s += `<circle cx="${X(data.length - 1)}" cy="${Y(vals[vals.length - 1])}" r="4.5" class="end"/>`;
  return svgNode(`<svg class="f-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="التدفق النقدي">${s}</svg>`);
}
function donut(slices, total) {
  const R = 54, C = 2 * Math.PI * R;
  let off = 0, s = '';
  const top = slices.slice(0, 7);
  const rest = slices.slice(7).reduce((a, x) => a + x.value, 0);
  if (rest) top.push({ label: 'أخرى', value: rest, color: '#7A86A8' });
  top.forEach((x) => { const len = (x.value / total) * C; s += `<circle cx="70" cy="70" r="${R}" fill="none" stroke="${x.color}" stroke-width="20" stroke-dasharray="${len} ${C - len}" stroke-dashoffset="${-off}" transform="rotate(-90 70 70)"/>`; off += len; });
  s += `<text x="70" y="66" text-anchor="middle" class="dl">المصروف</text><text x="70" y="86" text-anchor="middle" class="dv">${FIN.hide ? '••••' : kfmt(total)}</text>`;
  return h('div', { class: 'f-donut' }, svgNode(`<svg viewBox="0 0 140 140" width="150" height="150">${s}</svg>`),
    h('div', { class: 'f-dlist' }, ...top.map((x) => h('div', {}, h('span', { class: 'f-cdot', style: { background: x.color } }), h('span', { text: x.label }), h('b', { class: 'num', text: `${UI.n(Math.round((x.value / total) * 100))}٪` })))));
}
function splitBar(label, work, pers) {
  const t = work + pers || 1;
  return h('div', { class: 'f-split' }, h('div', { class: 'fs-t' }, h('b', { text: label }), h('small', { class: 'num', text: `${money(work)} عمل · ${money(pers)} شخصي` })),
    h('div', { class: 'fs-bar' }, h('i', { class: 'work', style: { width: (work / t) * 100 + '%' } }), h('i', { class: 'pers', style: { width: (pers / t) * 100 + '%' } })));
}

/* ---------- الإعدادات والتصدير ---------- */
function openFinSettings() {
  const f = fin();
  const st = { ...f.settings };
  const inp = (label, key, opt = {}) => { const i = h('input', { class: `input${opt.ltr ? ' ltr' : ''}`, value: st[key] ?? '', maxlength: opt.max || 40, inputmode: opt.num ? 'decimal' : 'text', placeholder: opt.ph || '' }); i.addEventListener('input', () => (st[key] = opt.num ? parseFloat(i.value) || 0 : i.value)); return h('label', { class: 'field' }, h('span', { text: label }), i); };
  const lock = h('input', { type: 'checkbox', checked: !!st.lock });
  lock.addEventListener('change', () => (st.lock = lock.checked));
  finSheet('إعدادات المالية', [
    h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'قفل المالية' }), h('small', { text: 'تُفتح ببصمة أو كلمة مرور عند كل دخول' })), h('span', { class: 'switch' }, lock, h('span', { class: 'track' }))),
    h('div', { class: 'row-2' }, inp('العملة', 'currency', { max: 8 }), inp('نسبة الضريبة ٪', 'vatRate', { num: true })),
    h('div', { class: 'set-card' }, h('strong', { text: 'بيانات الفواتير' }), inp('اسم النشاط', 'bizName', { ph: 'Noble Designer' }), inp('الرقم الضريبي (اختياري)', 'bizVat', { ltr: true, max: 20 }), inp('بادئة رقم الفاتورة', 'invPrefix', { ltr: true, max: 10 })),
    h('div', { class: 'set-card' }, h('strong', { text: 'التصنيفات' }), h('div', { class: 'f-catlist' }, ...f.cats.map((c) => h('span', { class: 'f-cat', style: { '--cc': c.color } }, h('i'), `${c.name}`, h('small', { text: c.kind === 'income' ? 'دخل' : SCOPES[c.scope] || '' }),
      f.tx.some((t) => t.cat === c.id) ? null : h('button', { type: 'button', class: 'f-catx', 'aria-label': 'حذف', onclick: async () => { await fsave((x) => { x.cats = x.cats.filter((y) => y.id !== c.id); delete x.budgets[c.id]; }); openFinSettings(); } }, '×'))))),
    h('button', { type: 'button', class: 'btn', onclick: exportFinCSV }, icon('download', { size: 16 }), 'تصدير كل الحركات Excel'),
  ], [
    h('div', { class: 'spacer' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      await fsave((x) => { x.settings = { ...x.settings, ...st, vatRate: Math.max(0, Math.min(50, Number(st.vatRate) || 0)) }; });
      if (st.lock) FIN.unlocked = true;
      closeSheet(finSheetEl); toast('حُفظت الإعدادات', { type: 'success' });
    } }, 'حفظ'),
  ]);
}
async function exportFinCSV() {
  if (!proOk('finance.export')) return;
  const f = fin();
  const T = { income: 'دخل', expense: 'مصروف', transfer: 'تحويل' };
  const rows = [['التاريخ', 'النوع', 'المبلغ', 'الحساب', 'إلى حساب', 'التصنيف', 'شخصي/عمل', 'العميل', 'ملاحظة']];
  [...f.tx].sort((a, b) => a.date.localeCompare(b.date)).forEach((t) => rows.push([t.date, T[t.type], t.amount, accOf(f, t.acc)?.name || '', accOf(f, t.to)?.name || '', catOf(f, t.cat)?.name || '', SCOPES[t.scope] || '', clientOf(f, t.client)?.name || '', t.note || '']));
  try { await saveFile(`noble-finance-${fymd()}.csv`, '﻿' + rows.map((r) => r.map(csvCell).join(',')).join('\r\n'), 'text/csv'); }
  catch (e) { toast('تعذّر التصدير: ' + e.message, { type: 'error' }); }
}

/* ---------- تنبيهات الاشتراكات ---------- */
async function scheduleFinReminders() {
  if (!Platform.isNative || !S.vault) return;
  const LN = Platform.plugin('LocalNotifications');
  const hid = (s) => { let x = 7; for (const ch of s) x = (x * 31 + ch.charCodeAt(0)) | 0; return Math.abs(x) % 900000000 + 100000000; };
  try {
    const f = fin();
    const pend = await LN.getPending();
    const mine = (pend.notifications || []).filter((n) => n.extra?.fin);
    if (mine.length) await LN.cancel({ notifications: mine.map((n) => ({ id: n.id })) });
    const list = f.recurring.filter((r) => r.active !== false && r.remind !== false).map((r) => {
      const at = new Date(r.next + 'T09:00');
      if (at < new Date()) return null;
      return { id: hid('fin' + r.id + r.next), title: r.type === 'income' ? 'دخل متوقع اليوم' : 'دفعة مستحقة اليوم', body: `${r.name} · ${money(r.amount, { show: true })}`, schedule: { at }, extra: { fin: true }, smallIcon: 'ic_stat_nobleweb' };
    }).filter(Boolean);
    if (list.length) await LN.schedule({ notifications: list });
  } catch { /* لا شيء */ }
}
