/* NOBLE — لعبة المطاردة: طرق اليمن، الشرطة خلفك، لوحات يمنية، كراج وسائقون
 * محرك طريق ثلاثي الأبعاد (Pseudo-3D) على canvas — مراحل لا تنتهي وتصعب مع المسافة.
 */
'use strict';
var Chase = (() => {
  const CFG = () => GCfg.get().chase || {};
  /* ---------------- البيانات ---------------- */
  const CARS = {
    falcon: { name: 'صقر GT', body: 'gt', cls: 'B', color: '#E5484D', top: 290, accel: 0.55, grip: 0.62, nitro: 0.6, hp: 3 },
    barq: { name: 'برق', body: 'gt', cls: 'B+', color: '#2E5BFF', top: 305, accel: 0.62, grip: 0.7, nitro: 0.62, hp: 3 },
    dunes: { name: 'كثبان 4x4', body: 'suv', cls: 'A', color: '#B8661E', top: 270, accel: 0.5, grip: 0.82, nitro: 0.55, hp: 5 },
    nimr: { name: 'نمر R', body: 'muscle', cls: 'A', color: '#FFD66B', top: 330, accel: 0.72, grip: 0.66, nitro: 0.7, hp: 4 },
    zil: { name: 'ظل', body: 'super', cls: 'S', color: '#111827', top: 360, accel: 0.85, grip: 0.86, nitro: 0.85, hp: 4 },
  };
  const COLORS = ['#E5484D', '#2E5BFF', '#1FC7A0', '#FFD66B', '#111827', '#F3F6FF', '#8B45F0', '#F0922F'];
  const UPS = { engine: ['المحرك', '⚙️'], nitro: ['النيترو', '🔵'], tires: ['الإطارات', '🛞'], armor: ['الهيكل', '🛡️'] };
  const DRIVERS = {
    lahhoub: { ab: 'نيترو أطول ٢٠٪', nitro: 1.2 },
    band: { ab: 'يصمد أمام ضربة إضافية', hp: 1 },
    limbs: { ab: 'انعطاف أسرع', grip: 1.15 },
    round: { ab: '+١٥٪ عملات', coins: 1.15 },
    noon: { ab: 'الشرطة أبطأ قليلاً', police: 0.92 },
    pixel: { ab: 'رادار للإشارات والعوائق', radar: true },
    logo: { ab: 'المطاردة تهدأ أسرع', heat: 0.8 },
  };
  const WORLDS = {
    sanaa: { name: 'صنعاء القديمة ليلاً', desc: 'بيوت برجية وقمريات مضيئة — باب اليمن', sky: ['#070B24', '#2A1650', '#7A2E6E'], ground: ['#18121a', '#130e15'], road: ['#2b2e3b', '#272a36'], rumble: ['#C8102E', '#EDE2CC'], lane: '#EDE2CC', fog: '#1d1532', night: true, curvy: 0.6, hilly: 0.35, limit: 80, signs: [['باب اليمن ⬆', 'شارع الزبيري'], ['التحرير ⬆', 'السبعين'], ['الصافية ⬆', 'حدّة'], ['سوق الملح ⬆', 'الجامع الكبير']], bg: 'linear-gradient(120deg,#0B1030,#3a2418 55%,#C8509C)' },
    aden: { name: 'عدن — كورنيش خور مكسر', desc: 'بحر وميناء وجبل شمسان', sky: ['#0b2a4a', '#3a6ea5', '#f0a868'], ground: ['#d9c8a0', '#cfbd92'], road: ['#3a3d48', '#353843'], rumble: ['#1F6FEB', '#ffffff'], lane: '#ffffff', fog: '#9cbfdc', night: false, curvy: 0.5, hilly: 0.15, sea: true, limit: 100, signs: [['كريتر ⬆', 'المعلا'], ['خور مكسر ⬆', 'الشيخ عثمان'], ['جولد مور ⬆', 'البريقة']], bg: 'linear-gradient(120deg,#08243a,#1F6FEB 55%,#9FD8FF)' },
    socotra: { name: 'سقطرى', desc: 'أشجار دم الأخوين ورمال بيضاء', sky: ['#3fa9e6', '#8fd3f5', '#e8f7ff'], ground: ['#efe6d2', '#e7dcc6'], road: ['#4a4d55', '#45484f'], rumble: ['#0FA3A3', '#ffffff'], lane: '#ffffff', fog: '#d6eef9', night: false, curvy: 0.75, hilly: 0.6, limit: 80, signs: [['حديبو ⬆', 'قلنسية'], ['دكسم ⬆', 'نوجد']], bg: 'linear-gradient(120deg,#062a2a,#0FA3A3 55%,#B6F0D8)' },
    shibam: { name: 'حضرموت — شبام', desc: 'ناطحات الطين ووادي حضرموت', sky: ['#3b1c0a', '#c2622a', '#f6c27a'], ground: ['#c99a5b', '#c09152'], road: ['#4a3f38', '#453a33'], rumble: ['#B8661E', '#ffffff'], lane: '#f5e6c8', fog: '#e8b47a', night: false, curvy: 0.4, hilly: 0.25, limit: 100, signs: [['شبام ⬆', 'سيئون'], ['تريم ⬆', 'المكلا']], bg: 'linear-gradient(120deg,#2a1406,#B8661E 55%,#FFD08A)' },
    mountains: { name: 'إب وتعز — الطرق الجبلية', desc: 'منعطفات خضراء وضباب وجبل صبر', sky: ['#5d7a7a', '#9db8b0', '#d6e4dc'], ground: ['#2f6b3a', '#2a6034'], road: ['#3b3f45', '#363a40'], rumble: ['#2E8B3D', '#ffffff'], lane: '#ffffff', fog: '#c9d8d2', fogDense: true, night: false, curvy: 1, hilly: 1, limit: 60, signs: [['إب ⬆', 'جبل بعدان'], ['تعز ⬆', 'جبل صبر']], bg: 'linear-gradient(120deg,#0a2412,#2E8B3D 55%,#CFE8B0)' },
  };
  const MODES = { chase: ['🚨', 'مطاردة'], time: ['⏱', 'ضد الوقت'], coins: ['🪙', 'جمع العملات'] };

  /* ---------------- حالة اللاعب ---------------- */
  const st = () => {
    const c = gstate().chase || {};
    return {
      coins: c.coins || 0, best: c.best || 0, runs: c.runs || 0, km: c.km || 0,
      owned: c.owned?.length ? c.owned : ['falcon'], car: c.car || 'falcon', colors: c.colors || {}, ups: c.ups || {},
      plates: c.plates || [], plate: c.plate || '', gov: c.gov || 'صنعاء', driver: c.driver || '', world: c.world || 'sanaa', mode: c.mode || 'chase',
      ctrl: c.ctrl || 'wheel', autoGas: !!c.autoGas, music: c.music !== false, mute: !!c.mute,
    };
  };
  const save = (mut) => gsave((g) => { g.chase = { ...st(), ...(g.chase || {}) }; mut(g.chase); });
  const plateOf = (s) => ({ n: s.plate || '۰۰۰'.replace(/./g, '0'), gov: s.gov });
  const carCfg = (id) => ({ price: 0, on: true, unlock: 0, ...(CFG().cars?.[id] || {}) });
  const worldCfg = (id) => ({ on: true, unlock: 0, music: '', ...(CFG().worlds?.[id] || {}) });
  const driverOf = (s) => DRIVERS[s.driver || myHero()] || {};
  function statsOf(id, s = st()) {
    const c = CARS[id], u = s.ups[id] || {};
    return {
      top: c.top + (u.engine || 0) * 8, accel: Math.min(1, c.accel + (u.engine || 0) * 0.03), grip: Math.min(1, c.grip + (u.tires || 0) * 0.04),
      nitro: Math.min(1, c.nitro + (u.nitro || 0) * 0.06), hp: c.hp + Math.floor((u.armor || 0) / 2),
    };
  }
  const upCost = (lvl) => Math.round((CFG().ups?.base || 400) * Math.pow(CFG().ups?.step || 1.6, lvl));
  const worldOpen = (id, s = st()) => worldCfg(id).on !== false && s.best >= (worldCfg(id).unlock || 0);
  const carGold = (id) => !!carCfg(id).pro;

  /* ---------------- الواجهة: الكراج والسائق والطرق ---------------- */
  const UI2 = { tab: 'garage', view: '' };
  function open() {
    withHero(() => openScreen((el) => paintMenu(el), { onBack: () => closeScreen(), cls: 'ch-menu-screen' }));
  }
  function paintMenu(el = GS.screen) {
    if (!el) return;
    const s = st();
    if (!s.plate) { s.plate = String(100 + Math.floor(Math.random() * 900)); save((c) => { if (!c.plate) c.plate = s.plate; }); }
    const tabs = [['garage', 'الكراج'], ['driver', 'السائق'], ['road', 'الطريق']];
    el.replaceChildren(h('div', { class: 'g-wrap ch-wrap' },
      gHead(CFG().name || 'المطاردة', h('span', { class: 'ch-coins num' }, '🪙 ', UI.n(s.coins)), () => closeScreen()),
      h('nav', { class: 'ch-tabs' }, ...tabs.map(([k, l]) => h('button', { type: 'button', class: UI2.tab === k ? 'on' : '', onclick: () => { UI2.tab = k; paintMenu(); } }, l))),
      h('div', { class: 'ch-body' }, ...({ garage: garageView, driver: driverView, road: roadView })[UI2.tab](s)),
      h('div', { class: 'ch-start' },
        h('div', { class: 'ch-sum' }, h('b', { text: `${CARS[s.car].name} · ${WORLDS[s.world].name}` }), h('small', { text: `${MODES[s.mode][1]} · أفضل مسافة ${UI.n(s.best.toFixed(1))} كم` })),
        h('button', { type: 'button', class: 'btn btn-primary ch-go', onclick: () => race() }, '🏁 ابدأ'))));
    UI.digitize(el);
  }
  const svgEl = (svg, w) => { const d = h('div', { class: 'ch-svg' }); d.innerHTML = svg; const sv = d.firstElementChild; if (sv && w) { sv.setAttribute('width', w); sv.setAttribute('height', Math.round(w * 140 / 220)); } return d; };
  function garageView(s) {
    const id = UI2.view && CARS[UI2.view] ? UI2.view : s.car;
    const c = CARS[id], owned = s.owned.includes(id), cfg = carCfg(id), color = s.colors[id] || c.color;
    const stt = statsOf(id, s), u = s.ups[id] || {};
    const bar = (l, v, max, txt) => h('div', { class: 'ch-stat' }, h('span', { text: l }), h('i', {}, h('b', { style: { width: Math.round(Math.min(1, v / max) * 100) + '%' } })), h('span', { class: 'num', text: txt }));
    const govSel = h('select', { class: 'input select ch-gov' }, ...Object.keys(ChaseArt.GOVS).map((g) => h('option', { value: g, text: g, selected: g === s.gov })));
    govSel.addEventListener('change', () => save((x) => { x.gov = govSel.value; }).then(() => paintMenu()));
    const premium = Object.entries(CFG().plates || {});
    const buy = async (cost, mut, okMsg) => {
      if (st().coins < cost) return toast(`تحتاج ${UI.n(cost - st().coins)} عملة إضافية — اجمعها في المطاردة 🪙`);
      const ok = await confirmSheet({ title: 'تأكيد الشراء', text: `سيُخصم ${UI.n(cost)} عملة من رصيدك (${UI.n(st().coins)}).`, ok: 'شراء', tone: 'primary' });
      if (!ok) return;
      await save((x) => { x.coins -= cost; mut(x); });
      buzz('success'); toast(okMsg, { type: 'success' }); paintMenu();
    };
    const carBtn = (k) => {
      const ck = carCfg(k);
      if (ck.on === false) return null;
      const own = s.owned.includes(k), lockKm = ck.unlock > s.best, gold = carGold(k) && typeof Pro !== 'undefined' && !Pro.has('games.gold');
      return h('button', { type: 'button', class: `ch-th ${k === id ? 'on' : ''} ${!own ? 'lk' : ''}`, onclick: () => { UI2.view = k; if (own) save((x) => { x.car = k; }).then(() => paintMenu()); else paintMenu(); } },
        svgEl(ChaseArt.carSVG(s.colors[k] || CARS[k].color, { body: CARS[k].body, plate: plateOf(s) }), 84),
        h('small', { text: CARS[k].name }), !own ? h('i', { text: gold ? '★' : lockKm ? `🔒 ${ck.unlock}كم` : `🪙${UI.n(ck.price)}` }) : null);
    };
    return [
      h('div', { class: 'ch-show' }, h('span', { class: 'ch-cls', text: c.cls }), h('div', { class: 'ch-name' }, h('small', { text: 'STREET' }), h('b', { text: c.name })),
        svgEl(ChaseArt.carSVG(color, { body: c.body, plate: plateOf(s) }), 300)),
      h('div', { class: 'ch-colors' }, ...COLORS.map((col) => h('button', { type: 'button', class: col === color ? 'on' : '', style: { background: col }, 'aria-label': 'لون', onclick: () => save((x) => { x.colors = { ...x.colors, [id]: col }; }).then(() => paintMenu()) }))),
      h('div', { class: 'ch-stats' },
        bar('السرعة', stt.top, 380, `${stt.top}`), bar('التسارع', stt.accel, 1, `${(5.5 - stt.accel * 3).toFixed(1)}ث`), bar('التحكم', stt.grip, 1, ['C', 'B', 'B+', 'A', 'A+', 'S'][Math.min(5, Math.floor(stt.grip * 6))]),
        bar('النيترو', stt.nitro, 1, `×${(1.3 + stt.nitro * 0.5).toFixed(1)}`), bar('المتانة', stt.hp, 6, `${stt.hp} ❤`)),
      owned ? h('div', { class: 'ch-ups' }, ...Object.entries(UPS).map(([k, [l, ic]]) => {
        const lv = u[k] || 0, max = lv >= 5;
        return h('button', { type: 'button', class: 'ch-up', disabled: max, onclick: () => buy(upCost(lv), (x) => { x.ups = { ...x.ups, [id]: { ...(x.ups[id] || {}), [k]: lv + 1 } }; }, `تمت ترقية ${l} ✓`) },
          h('span', { text: `${ic} ${l}` }), h('small', { text: '●'.repeat(lv) + '○'.repeat(5 - lv) }), h('b', { text: max ? 'كامل' : `🪙 ${UI.n(upCost(lv))}` }));
      })) : h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => {
        if (carGold(id) && typeof Pro !== 'undefined' && !Pro.has('games.gold')) return Pro.gate('games.gold', `«${c.name}» سيارة ذهبية`);
        if (cfg.unlock > s.best) return toast(`تُفتح بعد ما تقطع ${cfg.unlock} كم في مطاردة واحدة`);
        buy(cfg.price, (x) => { x.owned = [...new Set([...x.owned, id])]; x.car = id; }, `صارت لك «${c.name}» 🎉`);
      } }, carGold(id) ? '★ سيارة ذهبية' : cfg.unlock > s.best ? `🔒 تُفتح عند ${cfg.unlock} كم` : `اشترِ بـ 🪙 ${UI.n(cfg.price)}`),
      h('div', { class: 'ch-plate' },
        h('div', { class: 'ch-plate-v' }, svgPlate(plateOf(s))),
        h('div', { class: 'ch-plate-t' }, h('b', { text: 'لوحتك' }), h('small', { text: '٣ أرقام + المحافظة' }), govSel,
          h('div', { class: 'ch-nums' },
            ...[...new Set([s.plate, ...s.plates])].filter(Boolean).map((n) => h('button', { type: 'button', class: n === s.plate ? 'on' : '', onclick: () => save((x) => { x.plate = n; }).then(() => paintMenu()) }, n)),
            h('button', { type: 'button', onclick: () => save((x) => { x.plate = String(100 + Math.floor(Math.random() * 900)); }).then(() => paintMenu()) }, '🎲 رقم عادي'),
            ...premium.filter(([n]) => !s.plates.includes(n)).map(([n, cost]) => h('button', { type: 'button', class: 'prem', onclick: () => buy(Number(cost) || 0, (x) => { x.plates = [...new Set([...x.plates, n])]; x.plate = n; }, `صارت لوحتك ${n} ✨`) }, `🔒 ${n} · 🪙${UI.n(cost)}`))))),
      h('div', { class: 'ch-cars' }, ...Object.keys(CARS).map(carBtn).filter(Boolean)),
    ];
  }
  function svgPlate(p) { const d = h('div', {}); d.innerHTML = `<svg width="132" height="50" viewBox="78 92 64 24" style="direction:ltr">${ChaseArt.plate(p)}</svg>`; return d.firstElementChild; }
  function driverView(s) {
    const cur = s.driver || myHero();
    return [h('p', { class: 'hint', text: 'كل سائق له قدرة خاصة في المطاردة.' }),
      h('div', { class: 'ch-drv' }, ...availHeroes().map((x) => h('button', { type: 'button', class: `ch-dv ${x.id === cur ? 'on' : ''}`, onclick: () => save((c) => { c.driver = x.id; }).then(() => paintMenu()) },
        heroNode(x.id, 66, 'stand', myLook()), h('b', { text: GCfg.get().heroes?.names?.[x.id] || x.name }), h('small', { text: DRIVERS[x.id]?.ab || '—' }))))];
  }
  function roadView(s) {
    const tr = typeof ChaseMusic !== 'undefined' ? ChaseMusic.TRACKS : {};
    const seg = (name, opts, cur, pick) => h('div', { class: 'seg seg-' + opts.length }, ...opts.map(([v, l]) => h('label', {}, h('input', { type: 'radio', name, checked: v === cur, onchange: () => pick(v) }), h('span', { text: l }))));
    return [
      h('b', { class: 'ch-h', text: 'طرق اليمن — لكل طريق موسيقاه' }),
      h('div', { class: 'ch-worlds' }, ...Object.entries(WORLDS).filter(([k]) => worldCfg(k).on !== false).map(([k, w]) => {
        const ok = worldOpen(k, s), cfg = worldCfg(k);
        return h('button', { type: 'button', class: `ch-wd ${k === s.world ? 'on' : ''} ${ok ? '' : 'lk'}`, style: { background: w.bg }, onclick: () => (ok ? save((c) => { c.world = k; }).then(() => paintMenu()) : toast(`يُفتح عند ${cfg.unlock} كم في مطاردة واحدة`)) },
          h('span', { class: 'lv', text: `${ok ? (cfg.unlock ? cfg.unlock + ' كم' : '∞') : '🔒 ' + cfg.unlock + ' كم'} · 🎵 ${tr[k]?.name || ''}` }),
          h('div', {}, h('b', { text: w.name }), h('small', { text: w.desc })));
      })),
      h('b', { class: 'ch-h', text: 'الطور' }),
      h('div', { class: 'ch-modes' }, ...Object.entries(MODES).map(([k, [ic, l]]) => h('button', { type: 'button', class: k === s.mode ? 'on' : '', onclick: () => save((c) => { c.mode = k; }).then(() => paintMenu()) }, h('b', { text: ic }), l))),
      h('b', { class: 'ch-h', text: 'التحكم والصوت' }),
      seg('chctrl', [['wheel', 'دركسون'], ['buttons', 'أزرار'], ['tilt', 'إمالة الجوال']], s.ctrl, (v) => save((c) => { c.ctrl = v; })),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'بنزين تلقائي' }), h('small', { text: 'السيارة تمشي لحالها، وأنت تفرمل وتوجّه' })), h('span', { class: 'switch' }, (() => { const i = h('input', { type: 'checkbox', checked: s.autoGas }); i.addEventListener('change', () => save((c) => { c.autoGas = i.checked; })); return i; })(), h('span', { class: 'track' }))),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: 'الموسيقى' }), h('small', { text: 'موسيقى خاصة لكل طريق' })), h('span', { class: 'switch' }, (() => { const i = h('input', { type: 'checkbox', checked: s.music }); i.addEventListener('change', () => save((c) => { c.music = i.checked; })); return i; })(), h('span', { class: 'track' }))),
    ];
  }

  /* ---------------- المحرك ---------------- */
  const SEG = 200, ROAD = 2000, LANES = 3, FOV = 100, CAMH = 1400, DRAW = 170, RUMBLE = 3;
  const CDEPTH = 1 / Math.tan(((FOV / 2) * Math.PI) / 180);
  const PLAYERZ = CAMH * CDEPTH;
  const UNIT_KMH = 40; // سرعة المحرك ÷ 40 = كم/س
  const ease = { in: (a, b, p) => a + (b - a) * p * p, out: (a, b, p) => a + (b - a) * (1 - (1 - p) * (1 - p)), io: (a, b, p) => a + (b - a) * (-Math.cos(p * Math.PI) / 2 + 0.5) };
  const lim = (v, a, b) => Math.max(a, Math.min(b, v));
  const overlap = (x1, w1, x2, w2, pct = 1) => { const h1 = (w1 * pct) / 2, h2 = (w2 * pct) / 2; return !(x1 + h1 < x2 - h2 || x1 - h1 > x2 + h2); };

  async function lockOrientation() { if (!Platform.isNative) return; try { await Platform.plugin('ScreenOrientation').lock({ orientation: 'landscape' }); } catch { /* لا شيء */ } }
  function unlockOrientation() { if (!Platform.isNative) return; setTimeout(() => Platform.plugin('ScreenOrientation').unlock().catch(() => {}), 300); }

  async function race(opts = {}) {
    const s = st();
    const W0 = WORLDS[s.world] && worldOpen(s.world, s) ? s.world : 'sanaa';
    const world = WORLDS[W0];
    const car = CARS[s.car] || CARS.falcon, stt = statsOf(s.car, s), drv = driverOf(s);
    const cfg = CFG();
    const mode = s.mode;
    const freeLimit = () => typeof Pro !== 'undefined' && !Pro.has('games.chase');

    /* الصور */
    const A = ChaseArt;
    const IM = {
      player: A.img(`p:${s.car}:${s.colors[s.car] || car.color}:${s.plate}:${s.gov}`, A.carSVG(s.colors[s.car] || car.color, { body: car.body, plate: plateOf(s) })),
      police: A.img('police', A.carSVG('#fff', { police: true, plate: { n: '999', gov: '' } })),
      traffic: ['#2E5BFF', '#1FC7A0', '#FFD66B', '#8B45F0', '#F3F6FF', '#6b7280', '#C8102E'].map((c, i) => A.img('t' + i, A.carSVG(c, { body: ['gt', 'suv', 'muscle'][i % 3], plate: { n: String(200 + i * 97), gov: Object.keys(A.GOVS)[i % 12] } }))),
      lamp: A.img('lamp', A.lamp()), coin: A.img('coin', A.coin()), n2o: A.img('n2o', A.nitroCan()), barrier: A.img('barrier', A.barrier()),
      light: { red: A.img('tl-r', A.trafficLight('red')), yellow: A.img('tl-y', A.trafficLight('yellow')), green: A.img('tl-g', A.trafficLight('green')) },
      speed: A.img('sp' + world.limit, A.speedSign(world.limit)),
      houses: [1, 2, 3, 4, 5, 6].map((k) => A.img('sh' + k + world.night, A.sanaaHouse(k, world.night))),
      shibam: [1, 2, 3, 4].map((k) => A.img('sb' + k, A.shibamHouse(k))),
      palm: A.img('palm', A.palm()), dragon: A.img('dragon', A.dragonTree()), pine: A.img('pine', A.pine()), rock: A.img('rock', A.rock()), minaret: A.img('minaret', A.minaret()),
      signs: world.signs.map((p, i) => A.img(`gs:${W0}:${i}`, A.guideSign(p[0], p[1]))),
    };
    await A.ready([IM.player, IM.police, ...IM.traffic, IM.lamp, IM.coin, IM.light.red, IM.light.green, IM.light.yellow, IM.speed, ...IM.houses, ...IM.shibam, IM.palm, IM.dragon, IM.pine, IM.rock, IM.minaret, ...IM.signs, IM.n2o, IM.barrier]);

    /* الطريق: يُبنى بلا نهاية */
    const segs = [];
    let built = 0;
    const lastY = () => (built ? segs[built - 1].p2.world.y : 0);
    function addSeg(curve, y) {
      const y0 = lastY(), i = built;
      segs[i] = { index: i, curve, sprites: [], coins: [], light: null, color: Math.floor(i / RUMBLE) % 2,
        p1: { world: { y: y0, z: i * SEG }, camera: {}, screen: {} }, p2: { world: { y, z: (i + 1) * SEG }, camera: {}, screen: {} } };
      built++;
    }
    function addRoad(enter, hold, leave, curve, hill) {
      const y0 = lastY(), y1 = y0 + hill * SEG, total = enter + hold + leave;
      for (let n = 0; n < enter; n++) addSeg(ease.in(0, curve, n / enter), ease.io(y0, y1, n / total));
      for (let n = 0; n < hold; n++) addSeg(curve, ease.io(y0, y1, (enter + n) / total));
      for (let n = 0; n < leave; n++) addSeg(ease.io(curve, 0, n / leave), ease.io(y0, y1, (enter + hold + n) / total));
    }
    const R = Math.random;
    function decorate(from) {
      for (let i = from; i < built; i++) {
        const sg = segs[i];
        if (i < 12) continue;
        // جوانب الطريق حسب العالم
        if (W0 === 'sanaa') {
          if (i % 6 === 0) sg.sprites.push({ im: IM.houses[(i / 6) % 6 | 0], x: -1.9 - R() * 0.8, w: 1500 });
          if (i % 6 === 3) sg.sprites.push({ im: IM.houses[((i / 6) | 0) % 6], x: 1.9 + R() * 0.8, w: 1500 });
          if (i % 97 === 50) sg.sprites.push({ im: IM.minaret, x: -3.2, w: 520 });
        } else if (W0 === 'shibam') {
          if (i % 5 === 0) sg.sprites.push({ im: IM.shibam[(i / 5) % 4 | 0], x: (i % 10 ? 1 : -1) * (2 + R() * 0.8), w: 1100 });
          if (i % 9 === 4) sg.sprites.push({ im: IM.palm, x: (R() < 0.5 ? -1 : 1) * (1.5 + R()), w: 700 });
        } else if (W0 === 'aden') {
          if (i % 4 === 0) sg.sprites.push({ im: IM.palm, x: -1.45, w: 760 });
          if (i % 11 === 5) sg.sprites.push({ im: IM.houses[i % 6], x: 2.2 + R(), w: 1300 });
        } else if (W0 === 'socotra') {
          if (i % 7 === 0) sg.sprites.push({ im: IM.dragon, x: (R() < 0.5 ? -1 : 1) * (1.8 + R() * 1.4), w: 1400 });
          if (i % 9 === 4) sg.sprites.push({ im: IM.rock, x: (R() < 0.5 ? -1 : 1) * (1.4 + R()), w: 900 });
        } else {
          if (i % 3 === 0) sg.sprites.push({ im: IM.pine, x: (R() < 0.5 ? -1 : 1) * (1.4 + R() * 1.6), w: 800 });
          if (i % 13 === 6) sg.sprites.push({ im: IM.rock, x: -1.6, w: 1000 });
        }
        if (world.night && i % 8 === 0) { sg.sprites.push({ im: IM.lamp, x: -1.15, w: 340 }); sg.sprites.push({ im: IM.lamp, x: 1.15, w: 340, flip: true }); }
        // لوحات إرشادية وحد السرعة
        if (i % 61 === 30) sg.sprites.push({ im: IM.signs[(i / 61 | 0) % IM.signs.length], x: 1.35, w: 1100 });
        if (cfg.speedCam !== false && i % 83 === 70) { sg.sprites.push({ im: IM.speed, x: -1.25, w: 360 }); sg.cam = true; }
        // إشارة مرور
        if (cfg.redLight !== false && i % 67 === 40) { sg.light = { off: R() * 7 }; }
        // عملات ونيترو
        if (i % 23 === 11) { const lane = [-2 / 3, 0, 2 / 3][(R() * 3) | 0]; for (let k = 0; k < 5; k++) if (segs[i + k * 2]) segs[i + k * 2].coins.push({ x: lane, n2o: false }); }
        if (i % 140 === 90) sg.coins.push({ x: [-2 / 3, 0, 2 / 3][(R() * 3) | 0], n2o: true });
      }
    }
    function extend() {
      const from = built;
      const k = world.curvy, hl = world.hilly;
      for (let n = 0; n < 6; n++) {
        const r = R();
        const len = [12, 25, 50][(R() * 3) | 0];
        const curve = r < 0.3 ? 0 : (R() < 0.5 ? -1 : 1) * [2, 4, 6][(R() * 3) | 0] * k;
        const hill = (R() - 0.5) * 60 * hl;
        addRoad(len, len, len, curve, hill);
      }
      decorate(from);
    }
    addRoad(30, 30, 30, 0, 0);
    extend(); extend();

    /* الحالة */
    const maxSpeed = stt.top * UNIT_KMH;
    const P = {
      x: 0, z: 0, speed: 0, steer: 0, gas: false, brake: false, hand: false, nitroOn: false, nitro: 0.6, hp: stt.hp + (drv.hp || 0), hpMax: stt.hp + (drv.hp || 0),
      km: 0, coins: 0, heat: mode === 'chase' ? 1 : 0, bust: 0, escapes: 0, time: mode === 'time' ? 45 : mode === 'coins' ? 90 : 0, nextCk: 1, inv: 0, revived: false, drift: 0, crashT: 0,
    };
    const accel = maxSpeed * (0.16 + stt.accel * 0.22), brakeF = -maxSpeed * 1.1, decel = -maxSpeed / 6, offLimit = maxSpeed / 4, offDecel = -maxSpeed / 2.2;
    const cars = [];
    const cops = [];
    let state = 'ready', paused = false, alive = true, raf = 0, last = 0, hudT = 0, lightsPassed = new Set(), camsPassed = new Set(), msgT = 0, flash = 0, sky = 0, hill = 0, shake = 0;
    let bgCache = null, tAll = 0;
    const MUTE = { on: !!s.mute };
    const sfx = makeSfx();
    let musicName = '';

    /* المرور */
    /* المسارات: كل سيارة لها مسار وتمشي فيه بنظام — ما تتداخل مع غيرها ولا تركب على المتسابق */
    const LX = [-2 / 3, 0, 2 / 3];
    const laneOf = (x) => (x < -1 / 3 ? 0 : x > 1 / 3 ? 2 : 1);
    const all = () => [...cars, ...cops];
    /* هل المسار مشغول بين z-behind و z+ahead (غير السيارة نفسها) */
    const busy = (lane, z, ahead, behind, self) => all().some((o) => o !== self && (o.lane ?? laneOf(o.x)) === lane && o.z > z - behind && o.z < z + ahead)
      || (Math.abs(LX[lane] - P.x) < 0.45 && P.z + PLAYERZ > z - behind && P.z + PLAYERZ < z + ahead);
    function spawnTraffic() {
      const ahead = P.z + PLAYERZ + SEG * (40 + R() * 120);
      const lane = (R() * 3) | 0;
      if (busy(lane, ahead, SEG * 8, SEG * 8)) return;
      const base = maxSpeed * (0.25 + R() * 0.3);
      cars.push({ z: ahead, lane, x: LX[lane], speed: base, base, im: IM.traffic[(R() * IM.traffic.length) | 0], w: 0.3 });
    }
    function spawnCop() {
      const z = P.z + PLAYERZ - SEG * (25 + R() * 20);
      const order = [0, 1, 2].sort(() => R() - 0.5);
      const lane = order.find((l) => !busy(l, z, SEG * 6, SEG * 6));
      if (lane === undefined) return;
      cops.push({ z, lane, x: LX[lane], speed: P.speed, im: IM.police, w: 0.32, cop: true, block: false, siren: R() * 6, laneT: 0 });
    }
    function roadblock() {
      const z = P.z + SEG * 110;
      const free = (R() * 3) | 0;
      LX.forEach((lx, k) => { if (k !== free) cops.push({ z, lane: k, x: lx, speed: 0, im: k % 2 ? IM.police : IM.barrier, w: 0.36, cop: true, block: true }); });
      say('🚧 حاجز تفتيش أمامك — ابحث عن الفتحة!');
    }

    /* ---------- الشاشة ---------- */
    let cv, cx, W = 0, H = 0, dpr = 1;
    const hud = {};
    openScreen((el) => {
      el.classList.add('ch-race', world.night ? 'night' : 'day');
      cv = h('canvas', { class: 'ch-cv' });
      hud.dist = h('span', { class: 'ch-pill', text: '0.00 كم' });
      hud.coins = h('span', { class: 'ch-pill gold', text: '🪙 0' });
      hud.wanted = h('span', { class: 'ch-pill wanted' });
      hud.time = h('span', { class: 'ch-pill', hidden: mode === 'chase' });
      hud.hp = h('span', { class: 'ch-pill' });
      hud.mute = h('button', { type: 'button', class: 'ch-pill btn-p', 'aria-label': 'كتم الصوت', onclick: () => toggleMute() }, MUTE.on ? '🔇' : '🔊');
      hud.msg = h('div', { class: 'ch-msg', hidden: true });
      hud.music = h('span', { class: 'ch-pill mus', hidden: true });
      hud.speed = h('div', { class: 'ch-speed' }, h('b', { class: 'num', text: '0' }), h('small', { text: 'كم/س' }));
      hud.nitro = h('div', { class: 'ch-nbar' }, h('i'));
      hud.bust = h('div', { class: 'ch-bust', hidden: true }, h('small', { text: 'القبض عليك' }), h('i', {}, h('b')));
      hud.siren = h('div', { class: 'ch-siren' });
      hud.flash = h('div', { class: 'ch-flash' });
      hud.radar = h('div', { class: 'ch-radar', hidden: !drv.radar });
      hud.over = h('div', { class: 'ch-over', hidden: true });
      const ctrl = buildCtrls();
      el.append(cv, hud.siren, hud.flash,
        h('div', { class: 'ch-top' }, h('button', { type: 'button', class: 'ch-pill btn-p', 'aria-label': 'إيقاف', onclick: () => pause(true) }, '⏸'), hud.mute, hud.dist, hud.coins, hud.wanted, hud.time, hud.hp),
        hud.music, hud.msg, hud.speed, hud.nitro, hud.bust, hud.radar, ctrl, hud.over);
      cx = cv.getContext('2d', { alpha: false });
      resize();
    }, {
      onBack: () => (state === 'play' && !paused ? pause(true) : exit()),
      cleanup: () => { alive = false; cancelAnimationFrame(raf); ChaseMusic.stop(); sfx.stop(); window.removeEventListener('resize', resize); window.removeEventListener('keydown', key); window.removeEventListener('keyup', key); window.removeEventListener('deviceorientation', tilt); document.removeEventListener('visibilitychange', vis); unlockOrientation(); },
      cls: 'g-full',
    });
    lockOrientation();
    window.addEventListener('resize', resize);
    window.addEventListener('keydown', key); window.addEventListener('keyup', key);
    document.addEventListener('visibilitychange', vis);
    if (s.ctrl === 'tilt') window.addEventListener('deviceorientation', tilt);
    function vis() { if (document.hidden && state === 'play') pause(true); }
    function resize() {
      if (!cv) return;
      dpr = Math.min(window.devicePixelRatio || 1, 1.6);
      W = cv.clientWidth || window.innerWidth; H = cv.clientHeight || window.innerHeight;
      cv.width = Math.round(W * dpr); cv.height = Math.round(H * dpr);
      cx.setTransform(dpr, 0, 0, dpr, 0, 0);
      bgCache = null;
    }

    /* ---------- التحكم ---------- */
    function buildCtrls() {
      const wrap = h('div', { class: `ch-ctrl c-${s.ctrl}` });
      const hold = (el2, on, off) => {
        const d = (e) => { e.preventDefault(); el2.classList.add('on'); on(); ChaseMusic.ctx()?.resume?.(); };
        const u = (e) => { e.preventDefault(); el2.classList.remove('on'); off(); };
        el2.addEventListener('pointerdown', d); el2.addEventListener('pointerup', u); el2.addEventListener('pointercancel', u); el2.addEventListener('pointerleave', u);
        return el2;
      };
      if (s.ctrl === 'wheel') {
        const wheel = h('div', { class: 'ch-wheel' });
        wheel.innerHTML = '<svg viewBox="0 0 100 100"><circle cx="50" cy="50" r="44" fill="none" stroke="rgba(255,255,255,.8)" stroke-width="9"/><circle cx="50" cy="50" r="10" fill="rgba(255,255,255,.85)"/><path d="M8 52 L40 50 M60 50 L92 52 M50 60 L50 92" stroke="rgba(255,255,255,.8)" stroke-width="8" stroke-linecap="round"/><circle cx="50" cy="12" r="5" fill="#F0922F"/></svg>';
        let x0 = null;
        const mv = (e) => { if (x0 == null) return; P.steer = lim((e.clientX - x0) / 70, -1, 1); wheel.style.transform = `rotate(${P.steer * 100}deg)`; };
        wheel.addEventListener('pointerdown', (e) => { x0 = e.clientX; wheel.setPointerCapture(e.pointerId); ChaseMusic.ctx()?.resume?.(); });
        wheel.addEventListener('pointermove', mv);
        const up = () => { x0 = null; P.steer = 0; wheel.style.transform = ''; };
        wheel.addEventListener('pointerup', up); wheel.addEventListener('pointercancel', up);
        wrap.append(wheel);
      } else if (s.ctrl === 'buttons') {
        wrap.append(hold(h('button', { type: 'button', class: 'ch-btn left', 'aria-label': 'يسار' }, '◀'), () => (P.steer = -1), () => (P.steer = 0)),
          hold(h('button', { type: 'button', class: 'ch-btn right', 'aria-label': 'يمين' }, '▶'), () => (P.steer = 1), () => (P.steer = 0)));
      } else wrap.append(h('div', { class: 'ch-tilt', text: '📱 أمِل الجوال للتوجيه' }));
      wrap.append(
        hold(h('button', { type: 'button', class: 'ch-nitro', 'aria-label': 'نيترو' }, 'NITRO'), () => (P.nitroOn = true), () => (P.nitroOn = false)),
        hold(h('button', { type: 'button', class: 'ch-hb', 'aria-label': 'تفحيط' }, '🅿️ تفحيط'), () => (P.hand = true), () => (P.hand = false)),
        hold(h('button', { type: 'button', class: 'ch-pedal brake', 'aria-label': 'فرامل' }, 'فرامل'), () => (P.brake = true), () => (P.brake = false)),
        s.autoGas ? null : hold(h('button', { type: 'button', class: 'ch-pedal gas', 'aria-label': 'بنزين' }, 'بنزين'), () => (P.gas = true), () => (P.gas = false)));
      return wrap;
    }
    function tilt(e) {
      const ang = (screen.orientation?.angle ?? window.orientation ?? 90);
      const b = e.beta || 0;
      P.steer = lim((ang === 270 || ang === -90 ? -b : b) / 22, -1, 1);
    }
    function key(e) {
      const d = e.type === 'keydown';
      if (['ArrowLeft', 'a'].includes(e.key)) P.steer = d ? -1 : 0;
      else if (['ArrowRight', 'd'].includes(e.key)) P.steer = d ? 1 : 0;
      else if (['ArrowUp', 'w'].includes(e.key)) P.gas = d;
      else if (['ArrowDown', 's'].includes(e.key)) P.brake = d;
      else if (e.key === ' ') P.nitroOn = d;
      else if (e.key === 'Shift') P.hand = d;
      else if (e.key === 'Escape' && d) pause(state === 'play' && !paused);
      else return;
      e.preventDefault();
    }

    /* ---------- الصوت ---------- */
    function makeSfx() {
      let ac = null, eng = null, siren = null, gEng = null, gSir = null, f = null;
      const on = () => gstate().sound !== false && !MUTE.on;
      function start() {
        if (!on()) return;
        try {
          ac = ChaseMusic.ctx();
          eng = ac.createOscillator(); gEng = ac.createGain(); f = ac.createBiquadFilter();
          eng.type = 'sawtooth'; f.type = 'lowpass'; f.frequency.value = 600; gEng.gain.value = 0.0;
          eng.connect(f).connect(gEng).connect(ac.destination); eng.start();
          siren = ac.createOscillator(); gSir = ac.createGain(); siren.type = 'square'; gSir.gain.value = 0;
          siren.connect(gSir).connect(ac.destination); siren.start();
        } catch { ac = null; }
      }
      function update(spd, copNear, t) {
        if (!ac || !eng) return;
        if (!on()) { gEng.gain.setTargetAtTime(0, ac.currentTime, 0.05); gSir.gain.setTargetAtTime(0, ac.currentTime, 0.05); return; }
        eng.frequency.setTargetAtTime(48 + spd * 150, ac.currentTime, 0.05);
        gEng.gain.setTargetAtTime(paused ? 0 : 0.035 + spd * 0.03, ac.currentTime, 0.1);
        siren.frequency.setTargetAtTime((t * 1.6) % 1 < 0.5 ? 650 : 900, ac.currentTime, 0.02);
        gSir.gain.setTargetAtTime(paused ? 0 : copNear * 0.03, ac.currentTime, 0.1);
      }
      function blip(kind) {
        if (!ac || !on()) return;
        const t = ac.currentTime, o = ac.createOscillator(), g = ac.createGain();
        const P2 = { coin: [1320, 1760, 0.09, 'sine', 0.08], crash: [180, 40, 0.35, 'sawtooth', 0.16], n2o: [300, 1400, 0.4, 'triangle', 0.09], cam: [2000, 2000, 0.08, 'square', 0.05], ck: [880, 1320, 0.18, 'sine', 0.08] }[kind];
        if (!P2) return;
        o.type = P2[3]; o.frequency.setValueAtTime(P2[0], t); o.frequency.exponentialRampToValueAtTime(P2[1], t + P2[2]);
        g.gain.setValueAtTime(P2[4], t); g.gain.exponentialRampToValueAtTime(0.001, t + P2[2] + 0.05);
        o.connect(g).connect(ac.destination); o.start(t); o.stop(t + P2[2] + 0.1);
      }
      function stop() { try { eng?.stop(); siren?.stop(); } catch { /* لا شيء */ } eng = siren = null; }
      return { start, update, blip, stop };
    }

    /* ---------- رسائل ---------- */
    function say(t, ms = 2200) { hud.msg.textContent = t; hud.msg.hidden = false; msgT = ms / 1000; }

    /* ---------- التحديث ---------- */
    const segAt = (z) => { const i = Math.floor(z / SEG); while (i + DRAW + 5 > built) extend(); return segs[Math.max(0, i)]; };
    function lightState(sg, t) { const c = (t + sg.light.off) % 7; return c < 3.5 ? 'green' : c < 4.5 ? 'yellow' : 'red'; }
    function update(dt) {
      tAll += dt;
      const pseg = segAt(P.z + PLAYERZ);
      const spct = P.speed / maxSpeed;
      const grip = stt.grip * (drv.grip || 1) * (P.hand ? 0.75 : 1);
      const dx = dt * 2 * spct * (0.7 + grip * 0.6) * (P.hand ? 1.35 : 1);
      // التوجيه + قوة الطرد في المنعطفات
      P.x += dx * P.steer;
      P.x -= dx * spct * pseg.curve * 0.3 * (1.15 - grip * 0.4);
      P.drift = P.hand && Math.abs(P.steer) > 0.3 && spct > 0.4 ? Math.min(1, P.drift + dt * 3) : Math.max(0, P.drift - dt * 2);
      // السرعة
      const gas = s.autoGas ? !P.brake : P.gas;
      const nitroActive = P.nitroOn && P.nitro > 0.02;
      const top = maxSpeed * (nitroActive ? 1.3 + stt.nitro * 0.5 : 1);
      if (P.brake) P.speed += brakeF * dt;
      else if (gas || nitroActive) P.speed += accel * (nitroActive ? 1.8 : 1) * dt;
      else P.speed += decel * dt;
      if (P.hand) P.speed += decel * 1.4 * dt;
      if (nitroActive) P.nitro = Math.max(0, P.nitro - dt * 0.32 / (drv.nitro || 1));
      else P.nitro = Math.min(1, P.nitro + dt * 0.018);
      if (Math.abs(P.x) > 1 && P.speed > offLimit) { P.speed += offDecel * dt; shake = 0.25; }
      P.x = lim(P.x, -2.2, 2.2);
      P.speed = lim(P.speed, 0, top);
      if (!nitroActive && P.speed > maxSpeed) P.speed -= maxSpeed * 0.5 * dt;
      P.z += P.speed * dt;
      P.km += (P.speed / UNIT_KMH) / 3600 * dt;
      sky += 0.0006 * pseg.curve * spct;
      hill = pseg.p1.world.y;
      if (P.inv > 0) P.inv -= dt;

      // اصطدام بجوانب الطريق (مبانٍ/أشجار)
      if (Math.abs(P.x) > 1.05) for (const sp of pseg.sprites) {
        const sw = sp.w / ROAD * 0.5;
        if (overlap(P.x, 0.3, sp.x, sw, 0.8)) { crash(0.2, 'اصطدمت بالرصيف!'); P.x = sp.x > 0 ? sp.x - sw - 0.2 : sp.x + sw + 0.2; break; }
      }
      // عملات ونيترو
      for (const c of pseg.coins) if (!c.got && overlap(P.x, 0.3, c.x, 0.15, 1)) {
        c.got = true;
        if (c.n2o) { P.nitro = Math.min(1, P.nitro + 0.45); sfx.blip('n2o'); say('🔵 نيترو!'); }
        else { P.coins += Math.round((mode === 'coins' ? 2 : 1) * (drv.coins || 1) * (cfg.coinsMult || 1) * 10) / 10; sfx.blip('coin'); }
      }
      // إشارة المرور والرادار
      if (pseg.light && !lightsPassed.has(pseg.index)) {
        lightsPassed.add(pseg.index);
        if (lightState(pseg, tAll) === 'red' && P.speed > maxSpeed * 0.1) { P.heat += 1; say('⚠️ قطعت الإشارة الحمراء — المطاردة اشتدّت!'); if (mode === 'time') P.time -= 3; }
      }
      if (pseg.cam && !camsPassed.has(pseg.index)) {
        camsPassed.add(pseg.index);
        const kmh = P.speed / UNIT_KMH;
        if (kmh > world.limit + 20) { flash = 1; sfx.blip('cam'); P.heat += 0.5; say(`📸 رادار: ${Math.round(kmh)} كم/س — الحد ${world.limit}`); if (mode === 'time') P.time -= 2; }
      }
      // المرور — كل سيارة في مسارها، تلحق اللي قدامها بدون ما تتداخل، وتغيّر المسار إذا الطريق فاضي
      if (cars.length < 9 + Math.min(10, P.km * 1.5) && R() < dt * 2.5) spawnTraffic();
      const pz = P.z + PLAYERZ;
      function drive(c, want, canChange) {
        let lead = null, gap = Infinity;
        for (const o of cars) if (o !== c && o.lane === c.lane && o.z > c.z && o.z - c.z < gap) { gap = o.z - c.z; lead = o; }
        for (const o of cops) if (o !== c && (o.lane ?? laneOf(o.x)) === c.lane && o.z > c.z && o.z - c.z < gap) { gap = o.z - c.z; lead = o; }
        // الأولوية للمتسابق: ما أحد يركب عليك من ورا
        if (Math.abs(LX[c.lane] - P.x) < 0.5 && pz > c.z && pz - c.z < gap) { gap = pz - c.z; lead = { z: pz, speed: P.speed, player: true }; }
        let v = want;
        if (lead && gap < SEG * 7) {
          if (canChange && c.laneT <= 0 && gap < SEG * 5 && lead.speed < want * 0.92) {
            const opts = [c.lane - 1, c.lane + 1].filter((l) => l >= 0 && l <= 2 && !busy(l, c.z, SEG * 6, SEG * 3, c));
            if (opts.length) { c.lane = opts[(R() * opts.length) | 0]; c.laneT = 2.2 + R() * 2; }
          }
          if (lead && (c.lane === (lead.lane ?? (lead.player ? laneOf(P.x) : laneOf(lead.x))) || lead.player)) {
            const safe = SEG * 1.4;
            v = gap < safe ? Math.min(v, lead.speed * 0.92) : Math.min(v, lead.speed + ((gap - safe) / (SEG * 5)) * Math.max(0, want - lead.speed));
          }
        }
        c.speed += (v - c.speed) * Math.min(1, dt * 2.5);
        c.laneT = (c.laneT || 0) - dt;
        c.x += (LX[c.lane] - c.x) * Math.min(1, dt * 2.2);
        c.z += c.speed * dt;
        if (lead && c.z > lead.z - SEG * 1.0 && Math.abs(c.x - (lead.player ? P.x : lead.x)) < 0.4) { c.z = lead.z - SEG * 1.0; c.speed = Math.min(c.speed, lead.speed); }
      }
      for (let i = cars.length - 1; i >= 0; i--) {
        const c = cars[i];
        drive(c, c.base, true);
        if (c.z < P.z - SEG * 10 || c.z > P.z + SEG * (DRAW + 40)) { cars.splice(i, 1); continue; }
        const dz = c.z - pz;
        if (Math.abs(dz) < SEG * 0.7 && overlap(P.x, 0.3, c.x, c.w, 0.82)) {
          if (P.speed > c.speed && dz > 0) { crash(0.3, 'اصطدام!'); P.speed = c.speed * 0.5; P.z = c.z - PLAYERZ - SEG * 0.8; }
          else P.x += P.x > c.x ? 0.05 : -0.05; // احتكاك جانبي
        } else if (dz < 0 && dz > -SEG * 0.6 && !c.near && Math.abs(c.x - P.x) < 0.55) { c.near = true; P.nitro = Math.min(1, P.nitro + 0.06); }
      }
      // الشرطة — تلحقك في المسارات، تحاول تحاصرك من الجنب أو من ورا، ولا تركب عليك
      if (mode === 'chase') {
        P.heat += dt * (cfg.heatPerKm ?? 0.35) * (P.speed / UNIT_KMH) / 3600;
        const wanted = lim(Math.ceil(P.heat), 0, 5);
        const target = Math.min(4, wanted);
        if (cops.filter((c) => !c.block).length < target && R() < dt * 0.6) spawnCop();
        if (wanted >= 3 && R() < dt * 0.012) roadblock();
        const pmax = maxSpeed * (cfg.police || 1) * (drv.police || 1) * (0.9 + 0.03 * wanted);
        const pl = laneOf(P.x);
        let near = 0, press = 0;
        for (let i = cops.length - 1; i >= 0; i--) {
          const c = cops[i];
          let dz = c.z - pz;
          if (!c.block) {
            // يختار مساراً جنبك إذا قرب
            if (dz < 0 && dz > -SEG * 10 && c.laneT <= 0 && Math.abs(c.lane - pl) !== 1) {
              const side = [pl - 1, pl + 1].filter((l) => l >= 0 && l <= 2 && !busy(l, c.z, SEG * 3, SEG * 2, c));
              if (side.length) { c.lane = side.sort((a, b) => Math.abs(a - c.lane) - Math.abs(b - c.lane))[0]; c.laneT = 1.6; }
            }
            const want = dz < -SEG * 2 ? pmax : dz > SEG * 1.5 ? P.speed * 0.85 : Math.min(pmax, P.speed + (-dz / SEG) * maxSpeed * 0.05);
            drive(c, Math.max(0, want), true);
          } else c.z += c.speed * dt;
          dz = c.z - pz;
          if (dz < -SEG * 140 || dz > SEG * (DRAW + 60)) {
            cops.splice(i, 1);
            if (!c.block) { P.escapes++; P.heat = Math.max(0, P.heat - 0.6 * (drv.heat || 1)); P.coins += 15; say('😎 هربت من دورية! +١٥ 🪙'); }
            continue;
          }
          if (dz < 0 && dz > -SEG * 25) near = Math.max(near, 1 + dz / (SEG * 25));
          if (!c.block && Math.abs(dz) < SEG * 1.4 && Math.abs(c.x - P.x) < 0.8) press += 1;
          if (Math.abs(dz) < SEG * 0.6 && overlap(P.x, 0.3, c.x, c.w, 0.8) && P.inv <= 0) { crash(0.35, c.block ? 'اصطدمت بالحاجز!' : 'صدمت سيارة الشرطة!'); if (c.block) { P.speed *= 0.2; } else { P.speed *= 0.6; P.x += c.x < P.x ? 0.3 : -0.3; } }
        }
        P.bust = lim(P.bust + (press ? press * 0.45 : -0.25) * dt * (P.speed < maxSpeed * 0.35 ? 1.6 : 1), 0, 1);
        if (P.bust >= 1) return end('busted');
        P.heat = Math.max(wanted > 0 && cops.length ? 0.5 : 0, P.heat - (near ? 0 : dt * 0.01 * (drv.heat ? 1.3 : 1)));
        sfx.update(spct, near, tAll);
      } else sfx.update(spct, 0, tAll);
      // الوقت
      if (mode !== 'chase') {
        P.time -= dt;
        if (mode === 'time' && P.km >= P.nextCk) { P.nextCk++; P.time += 12; sfx.blip('ck'); say('⏱ نقطة تفتيش +١٢ ثانية'); }
        if (P.time <= 0) return end('time');
      }
      // حد المسافة المجانية
      if (freeLimit() && !Pro.allows('games.chase', P.km)) return end('limit');
      if (msgT > 0 && (msgT -= dt) <= 0) hud.msg.hidden = true;
      if (flash > 0) flash -= dt * 2.5;
      if (shake > 0) shake -= dt;
      if (P.crashT > 0) P.crashT -= dt;
    }
    function crash(sev, txt) {
      if (P.inv > 0) return;
      P.hp--; P.inv = 1.2; P.crashT = 0.5; shake = 0.5; sfx.blip('crash'); buzz('heavy');
      if (mode === 'chase') P.heat += sev;
      say(`💥 ${txt}`);
      if (P.hp <= 0) end('wrecked');
    }

    /* ---------- الرسم ---------- */
    function makeBg() {
      const c = document.createElement('canvas'); c.width = Math.round(W * 2); c.height = Math.round(H * 0.62);
      const g = c.getContext('2d'), h0 = c.height;
      const sky0 = g.createLinearGradient(0, 0, 0, h0); world.sky.forEach((col, i) => sky0.addColorStop(i / (world.sky.length - 1), col));
      g.fillStyle = sky0; g.fillRect(0, 0, c.width, h0);
      if (world.night) { for (let i = 0; i < 90; i++) { g.fillStyle = `rgba(255,255,255,${0.3 + Math.random() * 0.6})`; g.fillRect(Math.random() * c.width, Math.random() * h0 * 0.6, 1.5, 1.5); } g.fillStyle = '#FFF4DA'; g.beginPath(); g.arc(c.width * 0.62, h0 * 0.45, 14, 0, 7); g.fill(); }
      else { g.fillStyle = 'rgba(255,240,200,.85)'; g.beginPath(); g.arc(c.width * 0.3, h0 * 0.42, 22, 0, 7); g.fill(); }
      const ridge = (col, base, amp, seed) => { g.fillStyle = col; g.beginPath(); g.moveTo(0, h0); for (let x = 0; x <= c.width; x += 8) g.lineTo(x, base - amp * (0.5 + 0.5 * Math.sin(x / 90 + seed) * Math.cos(x / 37 + seed * 2))); g.lineTo(c.width, h0); g.fill(); };
      if (W0 === 'sanaa') { ridge('#1a1230', h0 * 0.72, h0 * 0.22, 1); for (let x = 0; x < c.width; x += 26 + Math.random() * 30) { const bh = h0 * (0.08 + Math.random() * 0.16), bw = 18 + Math.random() * 22; g.fillStyle = '#24182a'; g.fillRect(x, h0 - bh, bw, bh); for (let y = h0 - bh + 6; y < h0 - 6; y += 9) for (let xx = x + 3; xx < x + bw - 4; xx += 7) if (Math.random() > 0.55) { g.fillStyle = ['#FFB43D', '#56C8FF', '#FF4D5E', '#1FC7A0'][(Math.random() * 4) | 0]; g.fillRect(xx, y, 3, 4); } } }
      else if (W0 === 'aden') { ridge('#5a4a5e', h0 * 0.62, h0 * 0.35, 2); g.fillStyle = '#1F6FEB'; g.globalAlpha = 0.55; g.fillRect(0, h0 * 0.86, c.width, h0 * 0.14); g.globalAlpha = 1; }
      else if (W0 === 'socotra') { ridge('#8fb7a8', h0 * 0.75, h0 * 0.25, 3); ridge('#6f9a8b', h0 * 0.88, h0 * 0.15, 5); }
      else if (W0 === 'shibam') { ridge('#a0582a', h0 * 0.66, h0 * 0.18, 4); for (let x = c.width * 0.35; x < c.width * 0.65; x += 14) { const bh = h0 * (0.18 + Math.random() * 0.1); g.fillStyle = '#b98652'; g.fillRect(x, h0 - bh, 12, bh); } }
      else { ridge('#4f6e66', h0 * 0.55, h0 * 0.35, 6); ridge('#3d6a4a', h0 * 0.75, h0 * 0.3, 7); ridge('#2f5a3a', h0 * 0.9, h0 * 0.2, 8); }
      return c;
    }
    function project(p, camX, camY, camZ) {
      p.camera.x = -camX; p.camera.y = p.world.y - camY; p.camera.z = p.world.z - camZ;
      p.screen.scale = CDEPTH / p.camera.z;
      p.screen.x = Math.round(W / 2 + p.screen.scale * p.camera.x * W / 2);
      p.screen.y = Math.round(H / 2 - p.screen.scale * p.camera.y * H / 2);
      p.screen.w = Math.round(p.screen.scale * ROAD * W / 2);
    }
    const poly = (x1, y1, x2, y2, x3, y3, x4, y4, col) => { cx.fillStyle = col; cx.beginPath(); cx.moveTo(x1, y1); cx.lineTo(x2, y2); cx.lineTo(x3, y3); cx.lineTo(x4, y4); cx.closePath(); cx.fill(); };
    function render() {
      if (!W) return;
      if (!bgCache) bgCache = makeBg();
      const shx = shake > 0 ? (R() - 0.5) * 8 : 0, shy = shake > 0 ? (R() - 0.5) * 6 : 0;
      cx.save(); cx.translate(shx, shy);
      // السماء والخلفية (حركة مع المنعطفات)
      const bw = bgCache.width, off = ((sky * W * 4) % bw + bw) % bw;
      cx.fillStyle = world.ground[0]; cx.fillRect(0, 0, W, H);
      const bgy = Math.round(H * 0.5 - bgCache.height + 8 - hill * 0.0006 * H);
      cx.drawImage(bgCache, -off, bgy, bw, bgCache.height); cx.drawImage(bgCache, bw - off, bgy, bw, bgCache.height);
      cx.fillStyle = world.sky[0]; if (bgy > 0) cx.fillRect(0, 0, W, bgy);
      const base = segAt(P.z), bp = (P.z % SEG) / SEG;
      const pseg = segAt(P.z + PLAYERZ), pp = ((P.z + PLAYERZ) % SEG) / SEG;
      const py = pseg.p1.world.y + (pseg.p2.world.y - pseg.p1.world.y) * pp;
      let maxy = H, x = 0, dx = -(base.curve * bp);
      const list = [];
      for (let n = 0; n < DRAW; n++) {
        const sg = segs[base.index + n];
        if (!sg) break;
        project(sg.p1, P.x * ROAD - x, py + CAMH, P.z);
        project(sg.p2, P.x * ROAD - x - dx, py + CAMH, P.z);
        x += dx; dx += sg.curve;
        sg.clip = maxy;
        list.push(sg);
        if (sg.p1.camera.z <= CDEPTH || sg.p2.screen.y >= sg.p1.screen.y || sg.p2.screen.y >= maxy) continue;
        const a = sg.p1.screen, b = sg.p2.screen, light = sg.color;
        const fog = 1 / Math.pow(Math.E, (n / DRAW) * (n / DRAW) * (world.fogDense ? 7 : 4));
        cx.fillStyle = world.ground[light]; cx.fillRect(0, b.y, W, a.y - b.y);
        const r1 = a.w / 6, r2 = b.w / 6;
        poly(a.x - a.w - r1, a.y + 1, a.x - a.w, a.y + 1, b.x - b.w, b.y, b.x - b.w - r2, b.y, world.rumble[light]);
        poly(a.x + a.w + r1, a.y + 1, a.x + a.w, a.y + 1, b.x + b.w, b.y, b.x + b.w + r2, b.y, world.rumble[light]);
        poly(a.x - a.w, a.y + 1, a.x + a.w, a.y + 1, b.x + b.w, b.y, b.x - b.w, b.y, world.road[light]);
        if (light) {
          const l1 = a.w / 40, l2 = b.w / 40;
          for (let ln = 1; ln < LANES; ln++) {
            const lx1 = a.x - a.w + (a.w * 2 * ln) / LANES, lx2 = b.x - b.w + (b.w * 2 * ln) / LANES;
            poly(lx1 - l1 / 2, a.y, lx1 + l1 / 2, a.y, lx2 + l2 / 2, b.y, lx2 - l2 / 2, b.y, world.lane);
          }
        }
        if (sg.light) { // خط التوقف وممر المشاة
          poly(a.x - a.w, a.y, a.x + a.w, a.y, b.x + b.w, b.y, b.x - b.w, b.y, 'rgba(255,255,255,.85)');
        }
        if (fog < 1) { cx.globalAlpha = 1 - fog; cx.fillStyle = world.fog; cx.fillRect(0, b.y, W, a.y - b.y); cx.globalAlpha = 1; }
        maxy = b.y;
      }
      // الأجسام من البعيد للقريب
      const all = [...cars, ...cops];
      const byIdx = new Map();
      for (const c of all) { const i = Math.floor(c.z / SEG); if (!byIdx.has(i)) byIdx.set(i, []); byIdx.get(i).push(c); }
      for (let n = list.length - 1; n > 0; n--) {
        const sg = list[n];
        const sc = sg.p1.screen.scale;
        if (!sc || sg.p1.camera.z <= CDEPTH) continue;
        for (const sp of sg.sprites) {
          const sx = sg.p1.screen.x + sc * sp.x * ROAD * W / 2;
          drawSprite(sp.im, sp.w, sc, sx, sg.p1.screen.y, sp.x < 0 ? -1 : 0, sg.clip, sp.flip);
        }
        if (sg.light) {
          const im = IM.light[lightState(sg, tAll)];
          drawSprite(im, 300, sc, sg.p1.screen.x + sc * -1.18 * ROAD * W / 2, sg.p1.screen.y, -1, sg.clip);
          drawSprite(im, 300, sc, sg.p1.screen.x + sc * 1.18 * ROAD * W / 2, sg.p1.screen.y, 0, sg.clip);
        }
        for (const c of sg.coins) if (!c.got) drawSprite(c.n2o ? IM.n2o : IM.coin, c.n2o ? 160 : 150, sc, sg.p1.screen.x + sc * c.x * ROAD * W / 2, sg.p1.screen.y - sc * 180 * H / 2, -0.5, sg.clip);
        const cs = byIdx.get(sg.index);
        if (cs) for (const c of cs) {
          const pc = (c.z % SEG) / SEG;
          const csc = sg.p1.screen.scale + (sg.p2.screen.scale - sg.p1.screen.scale) * pc;
          const cxx = sg.p1.screen.x + (sg.p2.screen.x - sg.p1.screen.x) * pc + csc * c.x * ROAD * W / 2;
          const cyy = sg.p1.screen.y + (sg.p2.screen.y - sg.p1.screen.y) * pc;
          drawSprite(c.im, c.w * ROAD * 1.0, csc, cxx, cyy, -0.5, sg.clip);
          if (c.cop && c.im === IM.police && !c.block) { const on = Math.floor(tAll * 6 + c.siren) % 2; const r = Math.max(4, c.w * ROAD * csc * W / 2 * 0.16); cx.fillStyle = on ? 'rgba(255,46,68,.4)' : 'rgba(46,123,255,.4)'; cx.beginPath(); cx.arc(cxx + (on ? -r : r), cyy - r * 4.4, r * 0.9, 0, 7); cx.fill(); }
        }
      }
      // سيارة اللاعب
      const pw = Math.min((0.3 * ROAD / CAMH) * W / 2 * (H > W ? 1.25 : 1), H * 0.5);
      const bounce = P.speed > 0 ? Math.sin(tAll * 22) * (P.speed / maxSpeed) * 1.5 : 0;
      const tilt2 = P.steer * 0.04 + (P.drift ? P.steer * 0.08 : 0);
      if (world.night) { const g = cx.createRadialGradient(W / 2, H * 0.72, 10, W / 2, H * 0.6, W * 0.42); g.addColorStop(0, 'rgba(255,240,200,.18)'); g.addColorStop(1, 'rgba(255,240,200,0)'); cx.fillStyle = g; cx.fillRect(0, H * 0.35, W, H * 0.65); }
      cx.save();
      cx.translate(W / 2, H - pw * 0.64 * 0.5 - (H > W ? 200 : 6) + bounce);
      cx.rotate(tilt2);
      if (P.inv > 0 && Math.floor(tAll * 14) % 2) cx.globalAlpha = 0.5;
      if (P.nitroOn && P.nitro > 0.02) { for (const sx of [-0.17, 0.17]) { cx.fillStyle = `rgba(86,200,255,${0.5 + R() * 0.4})`; cx.beginPath(); cx.ellipse(sx * pw, pw * 0.3, pw * 0.03, pw * (0.08 + R() * 0.07), 0, 0, 7); cx.fill(); } }
      if (P.drift > 0.3) { cx.fillStyle = `rgba(220,220,230,${0.25 * P.drift})`; for (let i = 0; i < 6; i++) { cx.beginPath(); cx.arc((R() - 0.5) * pw * 0.9, pw * 0.28 + R() * 10, 8 + R() * 18, 0, 7); cx.fill(); } }
      cx.drawImage(IM.player, -pw / 2, -pw * 0.64 * 0.5, pw, pw * 0.64);
      cx.restore();
      cx.restore();
      if (flash > 0) hud.flash.style.opacity = Math.max(0, flash).toFixed(2); else if (hud.flash.style.opacity !== '0') hud.flash.style.opacity = '0';
    }
    function drawSprite(im, worldW, scale, x, y, ox, clipY, flip) {
      if (!im || !im.naturalWidth) return;
      const dw = worldW * scale * W / 2, dh = dw * (im.naturalHeight / im.naturalWidth);
      if (dw < 1 || dw > W * 3) return;
      const dx = x + dw * ox, dy = y - dh;
      const clipH = clipY ? Math.max(0, dy + dh - clipY) : 0;
      if (clipH >= dh) return;
      if (flip) { cx.save(); cx.translate(dx + dw, 0); cx.scale(-1, 1); cx.drawImage(im, 0, 0, im.naturalWidth, im.naturalHeight - (im.naturalHeight * clipH) / dh, 0, dy, dw, dh - clipH); cx.restore(); }
      else cx.drawImage(im, 0, 0, im.naturalWidth, im.naturalHeight - (im.naturalHeight * clipH) / dh, dx, dy, dw, dh - clipH);
    }

    /* ---------- HUD ---------- */
    function paintHud() {
      hud.dist.textContent = `📍 ${P.km.toFixed(2)} كم`;
      hud.coins.textContent = `🪙 ${Math.floor(P.coins)}`;
      const wn = mode === 'chase' ? lim(Math.ceil(P.heat), 0, 5) : 0;
      hud.wanted.hidden = mode !== 'chase';
      hud.wanted.replaceChildren(h('b', { text: '★'.repeat(wn) }), h('i', { text: '★'.repeat(5 - wn) }));
      hud.time.textContent = `⏱ ${Math.max(0, Math.ceil(P.time))}`;
      hud.hp.textContent = '❤'.repeat(Math.max(0, P.hp)) + '🤍'.repeat(Math.max(0, P.hpMax - P.hp));
      hud.speed.firstChild.textContent = Math.round(P.speed / UNIT_KMH);
      hud.nitro.firstChild.style.width = Math.round(P.nitro * 100) + '%';
      hud.bust.hidden = P.bust < 0.05;
      hud.bust.querySelector('b').style.width = Math.round(P.bust * 100) + '%';
      const near = cops.some((c) => !c.block && c.z < P.z + PLAYERZ && c.z > P.z - SEG * 25);
      hud.siren.classList.toggle('on', near);
      if (drv.radar) {
        const nx = segs.slice(Math.floor((P.z + PLAYERZ) / SEG), Math.floor((P.z + PLAYERZ) / SEG) + 60).find((x) => x && (x.light || x.cam));
        hud.radar.textContent = nx ? (nx.light ? `🚦 إشارة ${{ red: 'حمراء', yellow: 'صفراء', green: 'خضراء' }[lightState(nx, tAll)]}` : `📸 رادار ${world.limit}`) : '📡 الطريق آمن';
      }
    }

    /* ---------- الحلقة ---------- */
    function loop(now) {
      if (!alive) return;
      raf = requestAnimationFrame(loop);
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now;
      if (state === 'play' && !paused) update(dt);
      render();
      if ((hudT += dt) > 0.1) { hudT = 0; paintHud(); }
    }
    function toggleMute() {
      MUTE.on = !MUTE.on;
      hud.mute.textContent = MUTE.on ? '🔇' : '🔊';
      save((c) => { c.mute = MUTE.on; });
      if (MUTE.on) ChaseMusic.stop();
      else if (s.music && state === 'play' && !paused) ChaseMusic.play(W0, worldCfg(W0).music || '');
      toast(MUTE.on ? 'كتمت الصوت 🔇' : 'رجع الصوت 🔊');
    }
    function music() { if (alive && s.music && !MUTE.on) return ChaseMusic.play(W0, worldCfg(W0).music || ''); return ''; }
    function startPlay() {
      if (!alive) return;
      state = 'play'; last = performance.now();
      sfx.start();
      if (s.music && !MUTE.on) { musicName = music(); if (musicName) { hud.music.textContent = `🎵 ${musicName}`; hud.music.hidden = false; setTimeout(() => (hud.music.hidden = true), 4500); } }
      say(mode === 'chase' ? '🚨 الشرطة خلفك — اهرب!' : mode === 'time' ? '⏱ وصل نقاط التفتيش قبل ما يخلص الوقت' : '🪙 اجمع أكبر عدد من العملات', 2600);
    }
    // عدّ تنازلي
    hud.over.hidden = false;
    let cnt = 3;
    const countdown = () => { if (!alive) return; hud.over.replaceChildren(h('div', { class: 'ch-count', text: cnt ? String(cnt) : 'انطلق!' })); UI.digitize(hud.over); if (cnt-- < 0) { hud.over.hidden = true; startPlay(); return; } setTimeout(countdown, 700); };
    countdown();
    raf = requestAnimationFrame(loop);

    function pause(on) {
      if (state !== 'play') return;
      paused = on;
      ChaseMusic.pause(on);
      P.gas = P.brake = P.nitroOn = P.hand = false; P.steer = 0;
      if (!on) { hud.over.hidden = true; last = performance.now(); return; }
      hud.over.hidden = false;
      hud.over.replaceChildren(h('div', { class: 'ch-card' }, h('h2', { text: 'استراحة' }),
        h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => pause(false) }, 'متابعة'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => { exit(true); race(); } }, 'من البداية'),
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => exit() }, 'الكراج')));
    }
    function exit(silent) {
      alive = false;
      closeScreen();
      if (!silent) open();
    }
    async function end(why) {
      if (state === 'over') return;
      state = 'over';
      ChaseMusic.stop(); sfx.update(0, 0, 0);
      const km = P.km;
      const earned = Math.floor(P.coins + km * 5);
      const rate = Math.max(1, Number(cfg.ptsPerKm) || 25);
      const pts = Math.round(km * rate * (mode === 'chase' ? 1 : 0.6) + P.escapes * 15);
      const prevBest = st().best;
      Sync.event('chase_run', { km: +km.toFixed(2), world: W0, mode, why, coins: earned, escapes: P.escapes });
      const gain = await addPoints('chase', pts, { mut: (g) => {
        const c = { ...st(), ...(g.chase || {}) };
        c.coins = (c.coins || 0) + earned; c.best = Math.max(c.best || 0, +km.toFixed(2)); c.runs = (c.runs || 0) + 1; c.km = +((c.km || 0) + km).toFixed(2);
        g.chase = c;
      } });
      const T = { busted: ['🚔', 'قبضت عليك الشرطة!'], wrecked: ['💥', 'تحطّمت السيارة!'], time: ['⏱', 'انتهى الوقت!'], limit: ['🔒', `قطعت ${km.toFixed(1)} كم مجاناً`] }[why];
      const canRevive = !P.revived && (why === 'busted' || why === 'wrecked') && ((typeof Pro !== 'undefined' && Pro.has('games.bonus')) || (typeof Ads !== 'undefined' && Ads.rewardAvailable()));
      const proRev = typeof Pro !== 'undefined' && Pro.has('games.bonus');
      const revive = () => { P.revived = true; P.hp = P.hpMax; P.bust = 0; P.inv = 2.5; P.heat = Math.max(1, P.heat - 2); cops.length = 0; state = 'play'; hud.over.hidden = true; last = performance.now(); music(); buzz('success'); };
      hud.over.hidden = false;
      hud.over.replaceChildren(h('div', { class: 'ch-card' },
        h('div', { class: 'ch-big', text: T[0] }), h('h2', { text: T[1] }),
        h('div', { class: 'ch-res' },
          h('div', {}, h('b', { class: 'num', text: km.toFixed(2) }), h('small', { text: 'كم' })),
          h('div', {}, h('b', { class: 'num', text: `+${earned}` }), h('small', { text: 'عملة' })),
          h('div', {}, h('b', { class: 'num', text: P.escapes }), h('small', { text: 'هروب' }))),
        h('p', { class: 'ch-gain', text: `+${gain} نقطة للصدارة${km > prevBest ? ' — رقم قياسي جديد! 🏆' : ''}` }),
        why === 'limit' ? h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { exit(); setTimeout(() => Pro.gate('games.chase', km), 300); } }, '★ افتح المطاردة كاملة') : null,
        canRevive ? h('button', { type: 'button', class: 'ad-reward', onclick: async () => { if (proRev) return revive(); if (await Ads.reward()) revive(); } },
          h('span', { text: '🔧' }), h('div', {}, h('b', { text: 'كمّل المطاردة — تصليح كامل' }), h('small', { text: proRev ? 'ميزة الاشتراك ★' : 'شاهد إعلاناً قصيراً — اختياري' })), h('span', { class: 'go', text: proRev ? 'كمّل' : '🎬 شاهد' })) : null,
        why !== 'limit' ? h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: () => { exit(true); typeof Ads !== 'undefined' ? Ads.inter(() => race()) : race(); } }, 'مرة ثانية') : null,
        h('button', { type: 'button', class: 'btn btn-block', onclick: () => exit() }, 'الكراج')));
      UI.digitize(hud.over);
    }
    Chase.DBG = { P, cars, cops, segs, end, get state() { return state; }, set state(v) { state = v; } };
  }

  return { open, race, CARS, WORLDS, DRIVERS, MODES, st, DBG: null };
})();
