/* NOBLE — لوحة الإدارة: تقدّم ونشاط كل مستخدم (يصل حتى ما حدث وهو بدون نت) */
'use strict';

const EV_LABEL = {
  app_open: ['فتح التطبيق', 'phone'],
  version_change: ['حدّث التطبيق', 'download'],
  level_complete: ['أنهى مرحلة في اللهب', 'flag'],
  level_fail: ['خسر مرحلة في اللهب', 'alert'],
  xo_game: ['لعب إكس أو', 'gamepad'],
  chase_run: ['لعب المطاردة', 'flag'],
  badge: ['حصل على وسام', 'trophy'],
  notice_read: ['قرأ رسالة', 'check'],
  back_online: ['رجع للاتصال', 'wifi'],
  shop_buy: ['اشترى من المتجر', 'tag'],
  daily: ['أنهى التحدّي اليومي', 'bolt'],
  grant: ['استلم هدية من الإدارة', 'tag'],
};
const BADGE_NAMES = { first_win: '🏅 أول فوز', xo_10: '🎯 ١٠ انتصارات', unbeatable: '🛡️ صمد أمام المستحيل', online_win: '🌐 بطل أونلاين', sanaa: '🏰 حامي المدينة', three_stars: '⭐ ثلاث نجوم', beans_100: '☕ ١٠٠ حبة بن', streak_7: '🔥 أسبوع متواصل', tasks_20: '✅ منجز', guardian: '🏮 هازم الحارس' };
const XO_RES = { win: 'فوز', draw: 'تعادل', loss: 'خسارة' };
const XO_MODE = { ai: 'ضد الجوال', local: 'مع صديق', online: 'أونلاين' };
const XO_LVL = { easy: 'سهل', medium: 'متوسط', hard: 'مستحيل' };

async function loadUserStats() {
  A.ustats = {};
  if (!can('users.view')) return;
  try { for (const r of await Cloud.admin.userStats()) A.ustats[r.user_id] = r; } catch { /* قبل تحديث 1.7 */ }
}

/* حالة الجهاز من آخر مزامنة */
function deviceState(st) {
  if (!st) return { cls: 'none', text: 'لم يزامن بعد' };
  const mins = (Date.now() - ts(st.last_sync)) / 60000;
  if (mins < 10) return { cls: 'on', text: 'متصل الآن' };
  return { cls: 'off', text: `آخر مزامنة ${UI.relTime(ts(st.last_sync))}` };
}

function evDetail(e) {
  const d = e.data || {};
  switch (e.type) {
    case 'level_complete': return `المرحلة ${d.id} · ${'★'.repeat(d.stars || 0)}${'☆'.repeat(3 - (d.stars || 0))} · ${d.score ?? 0} نقطة`;
    case 'level_fail': return `المرحلة ${d.id} · جمع ${d.beans ?? 0} حبة`;
    case 'xo_game': return [XO_MODE[d.mode], d.level && XO_LVL[d.level], XO_RES[d.result]].filter(Boolean).join(' · ');
    case 'badge': return BADGE_NAMES[d.id] || d.id;
    case 'version_change': return `${d.from} ← ${d.to}`;
    case 'back_online': return `بعد ${d.minutes} دقيقة بدون نت`;
    case 'app_open': return `إصدار ${d.v || ''}${d.net === false ? ' · بدون نت' : ''}`;
    case 'notice_read': return d.level === 'bar' ? 'شريط' : d.level === 'screen' ? 'شاشة كاملة' : '';
    case 'shop_buy': return `${d.name || d.id} · ${d.price ?? 0} حبة`;
    case 'grant': return d.kind === 'beans' ? `${d.value?.n} حبة بن` : d.kind === 'unlock' ? 'فتح كل المراحل' : `${d.value?.cat}: ${d.value?.id}`;
    case 'daily': return `المرحلة ${d.id}`;
    default: return '';
  }
}

async function openUserActivity(u) {
  const st = A.ustats?.[u.id];
  const s = st?.stats || {};
  const g = s.games || {};
  const us = s.usage || {};
  const dv = s.device || {};
  const ds = deviceState(st);
  const tile = (v, l) => h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: v ?? '—' }), h('small', { text: l }));
  const stars = g.flame?.stars || {};
  const lvIds = Object.keys(stars).sort();
  const box = h('div', { class: 'ua' },
    // 1.20: نوع الجوال والنظام والمنطقة وأول فتح
    typeof deviceCard === 'function' ? deviceCard(u) : null,
    // 1.21.6: حالته، الاشتراك، الإشعارات، الأخبار، رحلته، تفضيلاته، الأعطال، ملاحظاتك
    ...(typeof insCards === 'function' ? insCards(u) : []),
    // الجهاز
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('phone', { size: 16 }), h('b', { text: 'حالة الجهاز' }), h('span', { class: `ua-dot ${ds.cls}`, text: ds.text })),
      h('div', { class: 'ua-grid' },
        tile(st?.version || u.app_version || '—', 'الإصدار المثبّت'),
        tile(st?.platform === 'android' ? 'أندرويد' : st?.platform ? 'متصفح' : '—', 'المنصّة'),
        tile(dv.pending ?? 0, 'بانتظار الرفع'),
        tile(st?.events_7d ?? 0, 'نشاط آخر ٧ أيام'))),
    // الألعاب
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('gamepad', { size: 16 }), h('b', { text: 'تقدّم الألعاب' })),
      h('div', { class: 'ua-grid' },
        tile(g.points ?? 0, 'النقاط'), tile(g.level ?? 1, 'المستوى'), tile(g.streak ?? 0, 'أيام متتالية'), tile((g.badges || []).length, 'أوسمة')),
      g.xo ? h('p', { class: 'ua-line' }, h('b', { text: 'إكس أو: ' }), `${g.xo.w} فوز · ${g.xo.d} تعادل · ${g.xo.l} خسارة`) : null,
      h('p', { class: 'ua-line' }, h('b', { text: 'اللهب: ' }), lvIds.length ? `أنهى ${lvIds.length} مرحلة · ${Object.values(stars).reduce((a, b) => a + b, 0)} نجمة${g.flame?.beans ? ` · ${g.flame.beans} حبة بن` : ''}` : 'لم يلعب بعد'),
      g.cosmetics ? h('p', { class: 'ua-line' }, h('b', { text: 'المظهر: ' }), [HERO_COLORS[g.cosmetics.color]?.name, g.cosmetics.acc && HERO_ACC[g.cosmetics.acc]?.name, g.cosmetics.trail && g.cosmetics.trail !== 'none' && `أثر ${g.cosmetics.trail}`, (g.cosmetics.monsters || []).map((id) => monsterById(id).name).join('، ')].filter(Boolean).join(' · ')) : null,
      g.wallet != null ? h('p', { class: 'ua-line' }, h('b', { text: 'رصيد البن: ' }), `${g.wallet} حبة${g.unlockedAll ? ' · كل المراحل مفتوحة' : ''}`) : null,
      lvIds.length ? h('div', { class: 'ua-levels' }, ...lvIds.map((id) => h('span', { class: 'ua-lv' }, h('b', { class: 'num', text: id }), h('i', { text: '★'.repeat(stars[id]) + '☆'.repeat(3 - stars[id]) })))) : null),
    // الاستخدام
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('pie', { size: 16 }), h('b', { text: 'أرقام الاستخدام' }), h('small', { class: 'hint', text: 'أرقام فقط — المحتوى مشفّر' })),
      h('div', { class: 'ua-grid' }, tile(us.items ?? u.items_count ?? 0, 'موقع'), tile(us.tasks ?? 0, 'مهمة'), tile(us.tasksDone ?? 0, 'مهمة منجزة'), tile(us.categories ?? 0, 'تصنيف'))),
    // 1.19: الوقت والأقسام والجلسات واللي أرسله
    h('div', { id: 'ua-more' }, h('section', { class: 'ua-card' }, h('p', { class: 'hint', text: 'جارٍ تحميل النشاط التفصيلي…' }))),
    // السجل
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('clock', { size: 16 }), h('b', { text: 'سجل النشاط' })),
      h('div', { class: 'ua-tl', id: 'ua-tl' }, h('p', { class: 'hint', text: 'جارٍ التحميل…' }))));
  pickSheet(nameOf(u), u.guest && typeof guestSub === 'function' ? guestSub(u) : `${u.email || ''}`, [box]);
  uaMore(u);
  if (typeof insLoad === 'function') insLoad(u);
  let evs = [];
  try { evs = await Cloud.admin.userEvents(u.id, 150); } catch (e) {
    $('#ua-tl')?.replaceChildren(h('p', { class: 'hint', text: /function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.7.sql لتفعيل السجل' : Cloud.msg(e) }));
    return;
  }
  const tl = $('#ua-tl');
  if (!tl) return;
  if (!evs.length) return tl.replaceChildren(h('p', { class: 'hint', text: 'لا يوجد نشاط مسجّل بعد.' }));
  // تجميع حسب اليوم
  const days = {};
  for (const e of evs) { const k = new Date(e.at).toLocaleDateString('ar', { weekday: 'long', day: 'numeric', month: 'long' }); (days[k] = days[k] || []).push(e); }
  tl.replaceChildren(...Object.entries(days).map(([day, list]) => h('div', { class: 'ua-day' },
    h('span', { class: 'ua-day-t', text: day }),
    ...list.map((e) => {
      const [label, ic] = EV_LABEL[e.type] || [e.type, 'info'];
      const late = e.offline || (ts(e.received_at) - ts(e.at) > 10 * 60000);
      return h('div', { class: `ua-ev ev-${e.type}` },
        h('span', { class: 'ua-ev-ic' }, icon(ic, { size: 14 })),
        h('div', { class: 'ua-ev-t' }, h('b', { text: label }), evDetail(e) ? h('small', { text: evDetail(e) }) : null),
        h('div', { class: 'ua-ev-time' }, h('small', { text: new Date(e.at).toLocaleTimeString('ar', { hour: 'numeric', minute: '2-digit' }) }),
          late ? h('span', { class: 'ua-off', title: `وصل ${UI.relTime(ts(e.received_at))}`, text: 'بدون نت' }) : null));
    }))));
}

/* ===== 1.19 — 📊 النشاط التفصيلي (أرقام فقط — محتوى الخزنة مشفّر وما يوصل لنا) ===== */
const UA_TABS = { sites: '🔗 المواقع', tasks: '✅ المهام', today: '☀️ يومي', finance: '💰 المالية', news: '📰 الأخبار', games: '🎮 الألعاب', designs: '🎨 التصاميم', azkar: '🤍 أذكاري', discover: '▶️ اكتشف' };
const uaDur = (s) => { s = Math.round(s || 0); if (s < 60) return `${UI.n(s)} ث`; const m = Math.round(s / 60); if (m < 60) return `${UI.n(m)} د`; return `${UI.n(Math.floor(m / 60))} س ${m % 60 ? UI.n(m % 60) + ' د' : ''}`; };
const uaTime = (t) => new Date(t).toLocaleTimeString('ar', { hour: 'numeric', minute: '2-digit' });
const uaDate = (t) => new Date(t).toLocaleDateString('ar', { weekday: 'short', day: 'numeric', month: 'short' });
const UA_ST = { pending: '⏳ ينتظر', approved: '✅ مقبول', rejected: '✕ مرفوض', new: '🆕 جديدة', open: '💬 مفتوحة', done: '✅ منتهية' };
async function uaMore(u) {
  let d;
  try { d = await Cloud.admin.userActivity(u.id); } catch (e) {
    $('#ua-more')?.replaceChildren(h('section', { class: 'ua-card' }, h('p', { class: 'hint', text: /function|schema/i.test(e.message || '') ? 'شغّل ملف update-1.19.sql في Supabase لتفعيل النشاط التفصيلي' : Cloud.msg(e) })));
    return;
  }
  const box = $('#ua-more'); if (!box) return;
  const days = d.days || [], tile = (v, l) => h('div', { class: 'ua-tile' }, h('b', { class: 'num', text: v }), h('small', { text: l }));
  const tot = days.reduce((a, x) => ({ secs: a.secs + (x.secs || 0), opens: a.opens + (x.opens || 0), links: a.links + (x.links || 0) }), { secs: 0, opens: 0, links: 0 });
  const tabs = {}; days.forEach((x) => Object.entries(x.tabs || {}).forEach(([k, v]) => { tabs[k] = (tabs[k] || 0) + v; }));
  const tabSum = Object.values(tabs).reduce((a, b) => a + b, 0) || 1;
  const top = Object.entries(tabs).filter(([, v]) => v >= 1).sort((a, b) => b[1] - a[1]);
  // آخر ١٤ يوم
  const map = Object.fromEntries(days.map((x) => [x.day, x]));
  const last14 = Array.from({ length: 14 }, (_, i) => { const t = new Date(Date.now() - (13 - i) * 864e5); const k = t.toLocaleDateString('en-CA'); return { k, t, s: map[k]?.secs || 0 }; });
  const mx = Math.max(60, ...last14.map((x) => x.s));
  const ses = days.flatMap((x) => (x.sessions || []).map((s) => ({ at: s[0], secs: s[1] || 0 }))).sort((a, b) => ts(b.at) - ts(a.at)).slice(0, 12);
  const list = (title, items, row, empty) => h('div', { class: 'ua-sub' }, h('b', { text: title }), items?.length ? h('div', { class: 'ua-rows' }, ...items.map(row)) : h('small', { class: 'hint', text: empty }));
  box.replaceChildren(
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('clock', { size: 16 }), h('b', { text: 'الوقت في التطبيق' }), h('small', { class: 'hint', text: 'آخر ٣٠ يوم' })),
      h('div', { class: 'ua-grid' },
        tile(d.joined ? new Date(d.joined).toLocaleDateString('ar', { day: 'numeric', month: 'short', year: 'numeric' }) : '—', 'انضم'),
        tile(d.last_seen ? UI.relTime(ts(d.last_seen)) : '—', 'آخر ظهور'),
        tile(uaDur(tot.secs), 'إجمالي الوقت'),
        tile(days.length ? uaDur(tot.secs / days.length) : '—', 'متوسط اليوم'),
        tile(UI.n(tot.opens), 'مرات الفتح'),
        tile(UI.n(tot.links), 'روابط فتحها')),
      days.length ? h('div', { class: 'ua-bars', title: 'الدقائق في آخر ١٤ يوم' }, ...last14.map((x) => h('div', { class: 'ua-bar' }, h('i', { style: { height: Math.max(x.s ? 6 : 2, Math.round((x.s / mx) * 100)) + '%' }, title: `${uaDate(x.t)} · ${uaDur(x.s)}` }), h('small', { text: UI.n(x.t.getDate()) })))) :
        h('p', { class: 'hint', text: 'ما وصلت أرقام للحين — تبدأ تتجمع من إصدار 1.19 (ولو المستخدم موقف «مشاركة الإحصائيات» ما توصل).' })),
    top.length ? h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('grid', { size: 16 }), h('b', { text: 'أكثر الأقسام اللي يقعد فيها' })),
      h('div', { class: 'ua-tabs' }, ...top.map(([k, v]) => { const p = Math.round((v / tabSum) * 100); return h('div', { class: 'ua-tabrow' }, h('span', { text: UA_TABS[k] || k }), h('div', { class: 'ua-tabbar' }, h('i', { style: { width: Math.max(2, p) + '%' } })), h('small', { class: 'num', text: `${UI.n(p)}٪ · ${uaDur(v)}` })); }))) : null,
    ses.length ? h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('phone', { size: 16 }), h('b', { text: 'الدخول والخروج' }), h('small', { class: 'hint', text: 'آخر ١٢ مرة' })),
      h('div', { class: 'ua-rows' }, ...ses.map((s) => h('div', { class: 'ua-row' },
        h('span', { text: uaDate(s.at) }), h('span', { class: 'num', text: `${uaTime(s.at)} ← ${s.secs ? uaTime(ts(s.at) + s.secs * 1000) : 'شغّال'}` }), h('b', { class: 'num', text: s.secs ? uaDur(s.secs) : '—' }))))) : null,
    h('section', { class: 'ua-card' },
      h('div', { class: 'ua-h' }, icon('upload', { size: 16 }), h('b', { text: 'اللي أرسله ونشره' })),
      h('p', { class: 'hint', text: '🔒 مواقعه ومهامه وماليته مشفّرة على جواله وما نقدر نشوفها — هذا اللي يحمي التطبيق في سياسة قوقل. هنا بس اللي أرسله لك بنفسه.' }),
      list('💬 تعليقاته في «اكتشف»', d.comments, (c) => h('div', { class: 'ua-row' }, h('span', { class: 'ua-txt', text: c.body }), h('small', { text: `${UA_ST[c.status] || c.status} · ${uaDate(c.created_at)}` })), 'ما علّق'),
      list('🛟 طلبات الدعم', d.tickets, (t) => h('div', { class: 'ua-row' }, h('span', { class: 'ua-txt', text: t.body }), h('small', { text: `${UA_ST[t.status] || t.status}${t.files ? ` · 📎 ${UI.n(t.files)}` : ''} · ${uaDate(t.created_at)}` })), 'ما أرسل طلبات'),
      list('🧾 طلبات الدفع والإيصالات', d.payments, (p) => h('div', { class: 'ua-row' }, h('span', { text: `${p.plan} · ${UI.n(p.amount)} ر.س` }), h('small', { text: `${UA_ST[p.status] || p.status} · ${uaDate(p.created_at)}` })), 'ما فيه'),
      list('🔔 الإشعارات اللي وصلته', d.pushes, (p) => h('div', { class: 'ua-row' }, h('span', { class: 'ua-txt', text: p.title }), h('small', { text: p.opened_at ? `✓ ضغطه ${uaDate(p.opened_at)}` : `وصل ${uaDate(p.got_at)}` })), 'ما وصله إشعار للحين')));
  UI.digitize?.(box);
}
