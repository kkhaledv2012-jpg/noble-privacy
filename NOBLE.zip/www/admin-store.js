/* NOBLE — لوحة «🏪 وضع المتجر» (1.18)
 * زر واحد يجهّز التطبيق لمراجعة Google Play: يخفي الاشتراكات وتسجيل الدخول والإعلانات والدفع اليدوي والأكواد،
 * ويحدد ٣–٤ أقسام بس تظهر لكل المستخدمين والمشتركين. يتطبّق على كل الأجهزة أول ما تفتح التطبيق (والإعداد ينحفظ على الجهاز).
 */
'use strict';
const STO = { cfg: null, hub: false, busy: false };
const STO_SECS = [['sites', 'المواقع', '🔗'], ['tasks', 'المهام', '✅'], ['today', 'يومي', '☀️'], ['finance', 'المالية', '💰'], ['news', 'الأخبار (+ عاجل + اكتشف لو مدموج)', '📰'],
  ['games', 'الألعاب', '🎮'], ['designs', 'التصاميم', '🎨'], ['azkar', 'أذكاري', '🤍'], ['discover', 'اكتشف', '▶️']];
const STO_SHOW = { login: 'تظهر واجهة الدخول (إيميل وكلمة مرور) أول ما يفتح التطبيق', subs: 'يظهر زر Pro والأسعار وأقفال الأقسام المدفوعة', ads: 'تظهر الإعلانات', pay: 'يظهر الدفع اليدوي ورفع الإيصال', codes: 'تظهر العروض وخانة «عندي كود»' };
const STO_HIDE = [['login', '🔐 واجهة تسجيل الدخول', 'مخفية: حساب خفي تلقائي بدون إيميل وكلمة مرور — اللي عنده حساب على جواله يكمل فيه عادي'],
  ['subs', '💎 الاشتراكات', 'مخفية: لا Pro ولا أسعار ولا أقفال — كل الأقسام الظاهرة تصير مفتوحة للكل'],
  ['ads', '📢 الإعلانات', 'مخفية: ولا إعلان في التطبيق'],
  ['pay', '🧾 الدفع اليدوي والإيصالات', 'مخفي — قوقل ما تسمح بالدفع برّا Google Play للمحتوى الرقمي'],
  ['codes', '🎟️ أكواد التفعيل والعروض', 'مخفية: نافذة العروض وخانة «عندي كود»']];

async function openStoreAdmin() {
  const box = $('#a-store');
  if (!box) return;
  box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  try {
    const d = (await Cloud.getConfig()) || {};
    STO.cfg = { ...Store.DEF, ...(d.store || {}) };
    STO.hub = d.discoverInNews === true;
  } catch (e) { box.replaceChildren(h('p', { class: 'note-box', text: 'تعذّر التحميل: ' + Cloud.msg(e) })); return; }
  stoPaint();
}
function stoPaint() {
  const c = STO.cfg, box = $('#a-store');
  // tag='label' لما المفتاح مو داخل label (عشان الضغط على المفتاح نفسه يشغّله — كان ما يستجيب في الأقسام)
  const sw = (on, onChange, tag = 'span') => { const i = h('input', { type: 'checkbox', checked: !!on }); i.addEventListener('change', () => onChange(i.checked)); return h(tag, { class: 'switch' }, i, h('span', { class: 'track' })); };
  const order = c.sections.filter((x) => STO_SECS.some((s) => s[0] === x));
  const secRow = ([id, name, ic]) => {
    const k = order.indexOf(id), on = k >= 0;
    return h('div', { class: `sto-sec${on ? ' on' : ''}` },
      h('span', { class: 'sto-n num', text: on ? UI.n(k + 1) : '' }), h('span', { class: 'sto-ic', text: ic }), h('b', { text: name }),
      on ? h('span', { class: 'sto-mv' },
        h('button', { type: 'button', 'aria-label': 'قبل', disabled: k === 0, onclick: () => { [order[k - 1], order[k]] = [order[k], order[k - 1]]; c.sections = order; stoPaint(); } }, '▲'),
        h('button', { type: 'button', 'aria-label': 'بعد', disabled: k === order.length - 1, onclick: () => { [order[k + 1], order[k]] = [order[k], order[k + 1]]; c.sections = order; stoPaint(); } }, '▼')) : null,
      sw(on, (v) => {
        if (!v && order.length <= 1) { toast('لازم قسم واحد على الأقل'); return stoPaint(); }
        c.sections = v ? [...order, id] : order.filter((x) => x !== id); stoPaint();
      }, 'label'));
  };
  box.replaceChildren(
    h('section', { class: `a-hero sto-hero${c.on ? ' live' : ''}` },
      h('div', {}, h('h2', { text: '🏪 وضع المتجر' }),
        h('p', { class: 'hint', text: 'للرفع على Google Play: تختار الأقسام اللي تظهر (أي عدد)، وتتحكم في واجهة الدخول والاشتراكات تظهر أو تختفي — للكل (مستخدمين ومشتركين).' })),
      h('label', { class: 'switch-row sto-main' }, h('span', {}, h('b', { text: c.on ? '● وضع المتجر شغّال' : '○ وضع المتجر موقوف' }), h('small', { text: c.on ? 'كل الأجهزة تشوف النسخة المختصرة' : 'التطبيق يشتغل بكل أقسامه واشتراكاته' })),
        sw(c.on, (v) => { c.on = v; stoPaint(); }))),
    h('div', { class: 'set-card' }, h('strong', { text: `الأقسام الظاهرة (${UI.n(order.length)} من ${UI.n(STO_SECS.length)})` }),
      h('p', { class: 'hint', text: 'شغّل أي عدد من الأقسام — اللي تطفيه يختفي للكل، وبياناته تبقى محفوظة وترجع لما تشغّله. الترتيب = ترتيب الشريط السفلي.' }),
      h('div', { class: 'sto-all' },
        h('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => { c.sections = [...order, ...STO_SECS.map((s) => s[0]).filter((x) => !order.includes(x))]; stoPaint(); } }, '✓ أظهر الكل'),
        h('button', { type: 'button', class: 'btn btn-ghost btn-sm', onclick: () => { c.sections = Store.DEF.sections.slice(); stoPaint(); } }, '↺ الأساسية (المهام · يومي · الأخبار)')),
      h('div', { class: 'sto-secs' }, ...STO_SECS.map(secRow))),
    h('div', { class: 'set-card' }, h('strong', { text: '🧭 دمج «اكتشف» داخل الأخبار' }),
      h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: STO.hub ? 'مدموج: الأخبار · ⚡ عاجل · 🧭 اكتشف' : 'اكتشف قسم لحاله' }),
        h('small', { text: 'لما تدمجه: قسم «الأخبار» يصير فيه دوائر الستوري فوق و٣ تبويبات، و«اكتشف» يختفي من الشريط. يشتغل في الوضع العادي ووضع المتجر.' })),
        sw(STO.hub, (v) => { STO.hub = v; stoPaint(); }))),
    h('div', { class: 'set-card' }, h('strong', { text: '👁️ وش يظهر للمستخدم' }),
      h('p', { class: 'hint', text: 'مفتاح شغّال = يظهر · مطفي = يختفي. الأقسام تشتغل طبيعي في الحالتين.' }),
      ...STO_HIDE.map(([k, name, sub]) => { const vis = c[k] === false; return h('label', { class: `switch-row sto-vis${vis ? ' shown' : ''}` }, h('span', {}, h('b', {}, name, h('em', { class: 'sto-tag', text: vis ? 'يظهر' : 'مخفي' })), h('small', { text: vis ? STO_SHOW[k] : sub })), sw(vis, (v) => { c[k] = !v; stoPaint(); })); })),
    c.login !== false ? h('p', { class: 'note-box', text: '⚠️ الدخول المخفي يحتاج خطوة وحدة في Supabase: Authentication ← Sign In / Providers ← فعّل «Allow anonymous sign-ins». بدونها التطبيق يشتغل على الجهاز بس (الأخبار واكتشف ما تتحمّل).' }) : null,
    h('div', { class: 'set-card sto-check' }, h('strong', { text: '✅ قبل ما ترفع' }),
      ...['حذف الحساب: موجود في الإعدادات ← حسابي «🗑️ حذف حسابي وبياناتي» (قوقل تشترطه).',
        'سياسة الخصوصية: رابط صفحة عامة تحطه في Play Console.',
        'لقطات الشاشة: صوّرها وأنت في وضع المتجر عشان تطابق اللي يشوفه المراجع.',
        'نموذج «أمان البيانات» في Play Console: نجهّزه مع بعض حسب الأقسام اللي اخترتها.'].map((t) => h('p', { class: 'hint', text: '• ' + t }))),
    h('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: STO.busy, onclick: stoSave }, STO.busy ? 'جارٍ الحفظ…' : '💾 حفظ وتطبيق على كل الأجهزة'));
  UI.digitize(box);
}
async function stoSave() {
  STO.busy = true; stoPaint();
  try {
    const cur = { ...Content.DEFAULTS, ...((await Cloud.getConfig()) || {}) };
    delete cur._updated; delete cur._games; delete cur._market;
    cur.store = { ...STO.cfg, sections: STO.cfg.sections.filter((x, i, a) => a.indexOf(x) === i) };
    cur.discoverInNews = !!STO.hub;
    await Cloud.admin.setConfig(cur);
    Content.set({ ...Content.all(), store: cur.store, discoverInNews: cur.discoverInNews });
    toast(`${STO.cfg.on ? '🏪 وضع المتجر شغّال' : 'وضع المتجر موقوف'}${STO.hub ? ' · اكتشف داخل الأخبار' : ''} ✓`, { type: 'success' });
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  STO.busy = false; stoPaint();
}
