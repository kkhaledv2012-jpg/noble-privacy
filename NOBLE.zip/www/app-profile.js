/* NOBLE — ملف التطبيق: يُكتب تلقائياً عند البناء (scripts/build-app.js) لكل تطبيق */
window.NOBLE_APP = {"id":"nobleweb","pro":"all","name":"NOBLE","sections":null};
