/* NOBLE — لوحة التحكم ← «🎨 الواجهة» (1.16)
 * شاشة الدخول والقفل: ثيمات، خلفية فيديو (يتكرر ويتحفظ في الجوال)، موشن الشعار، الترحيب، الأزرار، البصمة، المواسم.
 * محفوظة في إعدادات السوق (Market.login) — «نشر التعديلات» يوصلها لكل المستخدمين فوراً.
 */
'use strict';
const UIA = { pv: null, t: 0, vstat: '' };
const uiaL = () => MK.data.login;
const uiaN = (n) => UI.n(n);

async function openUiAdmin() {
  const box = $('#a-ui');
  if (!MK.data) box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  await loadMarket();
  MK.data.login = LoginUI.cfg(MK.data.login || {});
  delete MK.data.login.season;
  renderUiAdmin();
}
const uiaCh = (re) => { mkChanged(); clearTimeout(UIA.t); UIA.t = setTimeout(() => (re ? renderUiAdmin() : uiaPreview()), re ? 0 : 160); };
function uiaPreview() {
  const scr = $('#uia-scr'); if (!scr) return;
  UIA.pv?.destroy();
  const L = uiaL();
  UIA.pv = LoginUI.preview(scr, LoginUI.cfg(L), { onStatus: (k) => { UIA.vstat = k; uiaStat(); } });
}
function uiaStat() {
  const e = $('#uia-vstat'); if (!e) return;
  const M = { ok: ['ok', '▶ الفيديو شغّال ويتكرر'], loading: ['wait', '⏳ يحمّل الفيديو…'], blocked: ['bad', '⚠️ المتصفح هنا منع التشغيل التلقائي — اضغط ⏯ أو جرّب في التطبيق'] }[UIA.vstat] || ['wait', '⏳ يجهّز المعاينة…'];
  e.className = 'uia-vstat ' + M[0]; e.textContent = M[1];
}
const uiaChips = (map, cur, set, re) => h('div', { class: 'chips uia-chips' }, ...Object.entries(map).map(([k, l]) => h('button', { type: 'button', class: `chip${cur() === k ? ' on' : ''}`, onclick: (e) => { set(k); e.currentTarget.parentNode.querySelectorAll('.chip').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); uiaCh(re); } }, l)));
const uiaSl = (label, val, min, max, step, on, fmt) => { const r = h('input', { type: 'range', min, max, step, value: val() }), o = h('em', { class: 'num', text: fmt(+r.value) }); r.addEventListener('input', () => { on(+r.value); o.textContent = fmt(+r.value); uiaCh(); }); return h('label', { class: 'uia-sl' }, h('span', { text: label }), r, o); };
const uiaCols = (list, cur, set) => { const box = h('div', { class: 'uia-sws' }); const paint = () => box.replaceChildren(...list.map((c) => h('button', { type: 'button', class: `uia-sw${String(cur()).toLowerCase() === c.toLowerCase() ? ' on' : ''}`, style: { background: c }, 'aria-label': c, onclick: () => { set(c); paint(); uiaCh(); } })), h('label', { class: 'uia-sw pick' }, (() => { const i = h('input', { type: 'color', value: /^#[0-9a-f]{6}$/i.test(cur()) ? cur() : '#ffffff' }); i.addEventListener('input', () => { set(i.value); uiaCh(); }); return i; })())); paint(); return box; };
const uiaTog = (title, sub, cur, set, re) => { const c = h('input', { type: 'checkbox', checked: !!cur() }); c.addEventListener('change', () => { set(c.checked); uiaCh(re); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, c, h('span', { class: 'track' }))); };
const uiaCard = (title, sub, open, ...kids) => h('details', { class: 'set-card uia-card', open: open || null }, h('summary', {}, h('b', { text: title }), sub ? h('small', { text: sub }) : null), h('div', { class: 'uia-cb' }, ...kids.filter(Boolean)));
const uiaLi = (html) => { const e = h('li'); e.innerHTML = html; return e; };
const uiaMB = (b) => (b / 1048576).toFixed(1);

function renderUiAdmin() {
  const box = $('#a-ui'), L = uiaL();
  const open = [...box.querySelectorAll('details.uia-card')].map((d) => d.open);
  UIA.pv?.destroy(); UIA.pv = null;
  const phone = h('div', { class: 'uia-phone' }, h('div', { class: 'uia-scr', id: 'uia-scr' }));
  // في الجوال: المعاينة نافذة صغيرة عائمة (ما تغطي الإعدادات) — تكبّرها أو تخفيها أو تنقلها للجهة الثانية
  const pvCol = h('div', { class: `uia-pvcol ${uiaPvMode()}` }, h('div', { class: 'uia-pvbox' }, phone),
    h('div', { class: 'uia-mini' },
      h('button', { type: 'button', 'aria-label': 'تكبير المعاينة', title: 'تكبير', onclick: () => uiaPvSet('max') }, '⤢'),
      h('button', { type: 'button', 'aria-label': 'نقل للجهة الثانية', title: 'نقل', onclick: () => uiaPvSide() }, '⇆'),
      h('button', { type: 'button', 'aria-label': 'إخفاء المعاينة', title: 'إخفاء', onclick: () => uiaPvSet('hide') }, '✕')),
    h('button', { type: 'button', class: 'uia-pill', onclick: () => uiaPvSet('mini') }, '👁 المعاينة'),
    h('div', { class: 'uia-pvacts' }, h('button', { type: 'button', class: 'btn sm', onclick: () => UIA.pv?.restart() }, '↻ حركة الشعار'),
      h('button', { type: 'button', class: 'btn sm uia-dk', onclick: () => phone.classList.toggle('big') }, '⤢ تكبير'),
      h('button', { type: 'button', class: 'btn sm uia-mb', onclick: () => uiaPvSet('mini') }, '↙ صغّرها وكمّل التعديل')),
    !L.enabled ? h('p', { class: 'note-box uia-off', text: 'الواجهة الجديدة مطفية — المستخدمين يشوفون الشكل الحالي. فعّلها من فوق ثم «نشر التعديلات».' }) : null);
  box.replaceChildren(
    mkHero('🎨 الواجهة', 'شاشة الدخول والقفل: خلفية فيديو، موشن الشعار، الترحيب والأزرار — التعديل يوصل للكل فوراً بعد النشر.'),
    h('div', { class: 'uia-wrap' }, pvCol, h('div', { class: 'uia-col' },
      h('div', { class: 'set-card uia-en' }, uiaTog('✅ تفعيل الواجهة الجديدة', 'لو مطفية يبقى شكل الدخول الحالي', () => L.enabled, (v) => { L.enabled = v; }, true)),
      uiaIntro(), uiaAppThemes(), uiaFonts(), uiaTabbar(), uiaHdr(), uiaBell(), uiaFinUi(), uiaThemes(), uiaBg(), uiaLogo(), uiaWel(), uiaBtns(), uiaSeasons())));
  box.querySelectorAll('details.uia-card').forEach((d, i) => { if (open[i] != null) d.open = open[i]; });
  UI.digitize(box);
  requestAnimationFrame(() => { uiaPvFit(); uiaPreview(); });
}
/* وضع المعاينة في الجوال: mini (عائمة صغيرة) · max (ملء الشاشة) · hide (زر صغير) */
function uiaPvMode() { let m = 'mini', side = ''; try { m = localStorage.getItem('nw:uia-pv') || 'mini'; side = localStorage.getItem('nw:uia-side') || ''; } catch { /* افتراضي */ } return `${m === 'max' ? 'mini' : m}${side ? ' ' + side : ''}`; }
function uiaPvSet(m) {
  const c = $('.uia-pvcol'); if (!c) return;
  c.classList.remove('mini', 'max', 'hide'); c.classList.add(m);
  if (m !== 'max') { try { localStorage.setItem('nw:uia-pv', m); } catch { /* لا شيء */ } }
  uiaPvFit();
}
function uiaPvSide() { const c = $('.uia-pvcol'); if (!c) return; c.classList.toggle('right'); try { localStorage.setItem('nw:uia-side', c.classList.contains('right') ? 'right' : ''); } catch { /* لا شيء */ } }
function uiaPvFit() {
  const c = $('.uia-pvcol'); if (!c) return;
  const k = Math.max(0.3, Math.min(1, (innerHeight - 130) / 656, (innerWidth - 32) / 320));
  c.style.setProperty('--pvk', k.toFixed(3));
}
addEventListener('resize', () => uiaPvFit());

/* 🔤 1.21.24: الخطوط والأرقام — كل الخطوط OFL وداخل التطبيق. التغيير يبان فوراً على اللوحة نفسها (نفس خط التطبيق) */
function uiaFonts() {
  if (typeof FontKit === 'undefined') return null;
  const d = MK.data; d.fonts = FontKit.cfg(d.fonts || {});
  const C = d.fonts, re = () => { FontKit.apply(C); mkChanged(); renderUiAdmin(); };
  FontKit.apply(C);
  const pickRow = (cur, set, withSame) => h('div', { class: 'fk-list' },
    withSame ? h('button', { type: 'button', class: `fk-opt${!cur ? ' on' : ''}`, onclick: () => { set(''); re(); } }, h('b', { text: 'نفس خط التطبيق' }), h('small', { text: 'الافتراضي' })) : null,
    ...FontKit.LIST.map((f) => h('button', { type: 'button', class: `fk-opt${cur === f.id ? ' on' : ''}`, onclick: () => { set(f.id); re(); } },
      h('b', { style: { fontFamily: `"${f.name}"` }, text: 'رفيقك اليومي 12' }), h('small', { text: `${f.name} — ${f.note}` }))));
  const dm = C.lockDigits ? C.digits : 'user';
  return uiaCard('🔤 الخطوط والأرقام', `${FontKit.fam(C.main)}${C.head ? ' + ' + FontKit.fam(C.head) + ' للعناوين' : ''} · أرقام ${dm === 'user' ? 'يختارها المستخدم' : dm === 'arab' ? 'عربية ١٢' : 'English 12'}`, false,
    h('p', { class: 'hint', text: 'كل الخطوط مرخّصة OFL (مجانية للتطبيق والتسويق) وموجودة داخل التطبيق — تشتغل بدون نت. اللي تختاره ينطبق على الواجهة كلها وسلايدات «عاجل» وصور الإشعارات، ويبان على هاللوحة فوراً.' }),
    h('div', { class: 'fk-sec' }, h('b', { text: '١. خط التطبيق (للكل)' }), pickRow(C.main, (v) => (C.main = v), false)),
    h('details', { class: 'fk-adv', open: !!C.head }, h('summary', { text: '٢. خط مختلف للعناوين (اختياري)' }),
      h('p', { class: 'hint', text: 'يطبّق على العناوين الكبيرة بس (مثل «مساء النور» وعناوين الصفحات). باقي الكلام — العادي والعريض — بخط التطبيق.' }), pickRow(C.head, (v) => (C.head = v), true)),
    h('div', { class: 'fk-sec' }, h('b', { text: '٣. خط الأذكار' }),
      h('div', { class: 'chips' }, ...[['amiri', 'Amiri (نسخ — أوضح مع التشكيل)'], ['app', 'نفس خط التطبيق']].map(([k, l]) => h('button', { type: 'button', class: `chip${C.zikr === k ? ' on' : ''}`, onclick: () => { C.zikr = k; re(); } }, l))),
      h('p', { class: 'fk-zk', style: { fontFamily: C.zikr === 'amiri' ? "'NobleZikr'" : 'inherit' }, text: 'اللَّهُمَّ بِكَ أَصْبَحْنَا وَبِكَ أَمْسَيْنَا، وَبِكَ نَحْيَا وَبِكَ نَمُوتُ' })),
    h('div', { class: 'fk-sec' }, h('b', { text: '٤. الأرقام' }),
      h('div', { class: 'chips' }, ...[['latn', 'English 12 للكل'], ['arab', 'عربي ١٢ للكل'], ['user', 'المستخدم يختار']].map(([k, l]) => h('button', { type: 'button', class: `chip${dm === k ? ' on' : ''}`, onclick: () => { if (k === 'user') C.lockDigits = false; else { C.lockDigits = true; C.digits = k; } re(); } }, l))),
      h('p', { class: 'hint', text: dm === 'user' ? 'يطلع للمستخدم خيار «الأرقام» في إعداداته (الافتراضي English).' : 'مقفولة على الكل — خيار «الأرقام» يختفي من إعدادات المستخدم.' })),
    h('div', { class: 'fk-sec' }, h('b', { text: 'سماكة النص العادي' }), h('div', { class: 'chips' }, ...[[500, 'متوسط (أوضح) ✓'], [400, 'عادي (أنحف)']].map(([v, l]) => h('button', { type: 'button', class: `chip${(C.wt || 500) === v ? ' on' : ''}`, onclick: (e) => { C.wt = v; [...e.currentTarget.parentNode.children].forEach((b) => b.classList.toggle('on', b === e.currentTarget)); FontKit.apply(C); mkChanged(); } }, l)))),
    h('div', { class: 'fk-sec' }, (() => { const lb = h('b', { text: `٥. ارتفاع السطر — ${C.lh}` }), r = h('input', { type: 'range', min: 1.3, max: 2, step: 0.05, value: C.lh });
      r.addEventListener('input', () => { C.lh = +r.value; lb.textContent = `٥. ارتفاع السطر — ${C.lh}`; FontKit.apply(C); mkChanged(); }); return h('label', { class: 'field' }, lb, r); })(),
      h('p', { class: 'hint', text: 'المسافة بين سطور الكلام العادي. حجم الخط يتحكم فيه كل مستخدم من إعداداته (حجم الخط).' })),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { d.fonts = { ...FontKit.DEF }; FontKit.apply(d.fonts); mkChanged(); renderUiAdmin(); } }, '↺ رجّع الافتراضي (Cairo)'));
}
function uiaThemes() {
  const L = uiaL(), v0 = (L.videos || [])[0];
  return uiaCard('🎭 الثيمات', 'اختر ثيم وعدّل عليه', true,
    h('div', { class: 'uia-themes' }, ...Object.entries(LoginUI.THEMES).map(([k, th]) => h('button', { type: 'button', class: `uia-th${L.theme === k ? ' on' : ''}`, onclick: () => {
      const keep = { videos: L.videos, video: L.video, enabled: L.enabled, wel: { ...L.wel, ...th.wel }, tag: L.tag, bio: L.bio, seasons: L.seasons };
      MK.data.login = { ...L, ...JSON.parse(JSON.stringify(th)), ...keep, theme: k };
      delete MK.data.login.name;
      if (th.bg.type === 'video' && !(keep.videos || []).length) toast('ارفع فيديو من «الخلفية» — لين ترفعه تشتغل جزيئات متحركة', { duration: 4500 });
      uiaCh(true);
    } }, th.bg.type === 'video' && v0?.poster ? h('img', { src: v0.poster, alt: '' }) : h('i', { style: { background: `linear-gradient(160deg, ${(th.bg.grad || LoginUI.GRADS[0]).join(',')})` } }),
      th.bg.type === 'video' ? h('em', { text: '🎬 فيديو' }) : null, h('b', { text: th.name })))),
    h('p', { class: 'hint', text: 'كل ثيم = خلفية + حركة شعار + ترحيب + ألوان. اختياره ما يمسح فيديوهاتك ولا نصوصك.' }));
}

function uiaBg() {
  const L = uiaL(), B = L.bg;
  const kids = [uiaChips({ video: '🎬 فيديو', gradient: '🌈 تدرّج', stars: '✨ نجوم', particles: '💫 جزيئات', image: '🖼 صورة' }, () => B.type, (k) => { B.type = k; }, true)];
  if (B.type === 'video') {
    const file = h('input', { type: 'file', accept: 'video/mp4,video/webm,video/*', hidden: true });
    file.addEventListener('change', () => { const f = file.files[0]; file.value = ''; if (f) uiaUpload(f); });
    kids.push(h('div', { class: 'uia-vids' }, ...(L.videos || []).map((v) => h('div', { class: `uia-vid${L.video === v.url || (!L.video && v === L.videos[0]) ? ' on' : ''}` },
      h('button', { type: 'button', class: 'uia-vid-p', onclick: () => { L.video = v.url; uiaCh(true); } }, v.poster ? h('img', { src: v.poster, alt: '' }) : h('span', { text: '🎬' })),
      h('span', { class: 'uia-vid-n', text: `${v.name || 'فيديو'} · ${uiaN(v.size || '?')}MB` }),
      h('button', { type: 'button', class: 'uia-vid-x', 'aria-label': 'حذف', onclick: async () => {
        if (!(await confirmSheet({ title: 'حذف الفيديو؟', text: 'ينحذف من المكتبة ومن السيرفر بعد النشر.', ok: 'حذف' }))) return;
        L.videos = L.videos.filter((x) => x !== v); if (L.video === v.url) L.video = L.videos[0]?.url || '';
        try { await Cloud.admin.storageRemove([v.url, v.poster].filter(Boolean)); } catch { /* لا شيء */ }
        uiaCh(true);
      } }, '✕'))),
      h('button', { type: 'button', class: 'uia-vid add', onclick: () => file.click() }, h('b', { text: '＋' }), 'ارفع فيديو')), file,
      h('div', { id: 'uia-vstat', class: 'uia-vstat wait', text: '⏳ يجهّز المعاينة…' }),
      !(L.videos || []).length ? h('p', { class: 'hint', text: 'ما فيه فيديو للحين — لين ترفع، تشتغل خلفية بديلة متحركة:' }) : null,
      !(L.videos || []).length ? uiaChips({ particles: '💫 جزيئات', stars: '✨ نجوم', gradient: '🌈 تدرّج' }, () => B.fx || 'particles', (k) => { B.fx = k; }) : null,
      uiaTog('🔁 تكرار مستمر (Loop)', 'يرجع من أوله تلقائياً بدون توقف', () => B.loop !== false, (v) => { B.loop = v; }),
      h('div', { class: 'chips' }, h('button', { type: 'button', class: 'chip', onclick: () => { const ve = UIA.pv?.video; if (!ve) return; if (ve.paused) ve.play().catch(() => {}); else ve.pause(); } }, '⏯ إيقاف / تشغيل'), h('button', { type: 'button', class: 'chip', onclick: () => { const ve = UIA.pv?.video; if (ve) { ve.currentTime = 0; ve.play().catch(() => {}); } } }, '⏮ من البداية')),
      uiaSl('السرعة', () => B.speed, 0.25, 1.5, 0.05, (v) => { B.speed = v; }, (v) => uiaN(v.toFixed(2)) + '×'),
      uiaSl('موضع الفيديو ↕', () => B.pos ?? 50, 0, 100, 1, (v) => { B.pos = v; }, (v) => uiaN(v) + '٪'));
  }
  if (['gradient', 'stars', 'particles'].includes(B.type) || (B.type === 'video' && !(L.videos || []).length)) kids.push(h('small', { class: 'hint', text: 'الألوان' }), h('div', { class: 'uia-sws' }, ...LoginUI.GRADS.map((g) => h('button', { type: 'button', class: `uia-sw big${(B.grad || []).join() === g.join() ? ' on' : ''}`, style: { background: `linear-gradient(160deg, ${g.join(',')})` }, onclick: () => { B.grad = g; uiaCh(true); } }))));
  if (B.type === 'image') {
    const f = h('input', { type: 'file', accept: 'image/*', hidden: true });
    f.addEventListener('change', async () => { const x = f.files[0]; f.value = ''; if (!x) return; toast('يرفع الصورة…'); try { B.img = await Cloud.admin.designUpload(x, 'ui'); uiaCh(true); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } });
    kids.push(f, h('button', { type: 'button', class: 'btn sm', onclick: () => f.click() }, B.img ? '🔁 غيّر الصورة' : '📷 ارفع صورة'));
  }
  kids.push(uiaSl('التعتيم', () => B.dim, 0, 0.8, 0.01, (v) => { B.dim = v; }, (v) => uiaN(Math.round(v * 100)) + '٪'),
    uiaSl('الضبابية', () => B.blur, 0, 12, 0.5, (v) => { B.blur = v; }, (v) => uiaN(v)),
    h('small', { class: 'hint', text: 'طبقة لون فوق الخلفية' }), uiaCols(['#000000', '#0a0420', '#00102a', '#2a0018', '#001a10'], () => B.tint, (c) => { B.tint = c; }),
    uiaSl('قوة الطبقة', () => B.tintOp, 0, 0.8, 0.01, (v) => { B.tintOp = v; }, (v) => uiaN(Math.round(v * 100)) + '٪'),
    uiaTips());
  return uiaCard('🌌 الخلفية', B.type === 'video' ? `فيديو · ${uiaN((L.videos || []).length)} في المكتبة` : '', true, ...kids);
}
function uiaTips() {
  return h('div', { class: 'uia-tips' }, h('b', { text: '💡 نصايح الفيديو — عشان يكون خفيف وسريع' }), h('ul', {},
    uiaLi('<strong>قصير ومتكرر:</strong> من ٥ إلى ١٥ ثانية، وآخره يركب على أوله (Loop) بدون قفزة.'),
    uiaLi('<strong>طولي ٩:١٦</strong> بجودة <strong>720p</strong> تكفي وزيادة على الجوال.'),
    uiaLi('<strong>MP4</strong> وحجمه <strong>أقل من ٥ ميجا</strong> — كل ما خف، اشتغل أسرع عند المستخدم.'),
    uiaLi('<strong>هادي وغامق:</strong> الحركة البطيئة أفخم، والخلفية الغامقة توضّح الشعار والكلام.'),
    uiaLi('<strong>بدون كلام أو شعارات ثانية</strong> في الفيديو — الواجهة تحط شعار NOBLE فوقه.'),
    uiaLi('<strong>استخدم فيديو حقك</strong> أو مرخّص — مصمم بنفسك أو من مكتبة بترخيص تجاري.'),
    uiaLi('الصوت ينشال، والفيديو يتحمّل مرة وينحفظ في جوال المستخدم — يشتغل بعدها حتى بدون نت.')));
}
/* رفع فيديو: فحص + صورة غلاف + رفع للسيرفر */
async function uiaUpload(f) {
  const url = URL.createObjectURL(f), v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = url;
  const meta = await new Promise((res) => { v.onloadedmetadata = () => res(true); v.onerror = () => res(false); setTimeout(() => res(false), 8000); });
  const d = meta ? v.duration : 0, w = v.videoWidth, hh = v.videoHeight, sz = f.size;
  const chk = [];
  if (meta) {
    chk.push(d <= 15 ? ['ok', `⏱ ${uiaN(d.toFixed(1))} ث`] : d <= 30 ? ['warn', `⏱ ${uiaN(Math.round(d))} ث — الأفضل أقصر`] : ['bad', `⏱ ${uiaN(Math.round(d))} ث — طويل`]);
    chk.push(hh >= w ? ['ok', `📐 طولي ${uiaN(w)}×${uiaN(hh)}`] : ['warn', `📐 عرضي — ينقص من الجوانب`]);
  }
  chk.push(sz <= 5 * 1048576 ? ['ok', `💾 ${uiaN(uiaMB(sz))} ميجا`] : sz <= 12 * 1048576 ? ['warn', `💾 ${uiaN(uiaMB(sz))} ميجا — ثقيل شوي`] : ['bad', `💾 ${uiaN(uiaMB(sz))} ميجا — ثقيل`]);
  const bad = sz > 25 * 1048576;
  const go = h('button', { type: 'button', class: 'btn btn-primary', disabled: bad }, bad ? 'الفيديو أكبر من ٢٥ ميجا — صغّره أول' : '⬆️ ارفع واستخدمه');
  mkSheet('🎬 فيديو جديد للخلفية', [
    h('video', { class: 'uia-up-pv', src: url, muted: true, autoplay: true, loop: true, playsinline: true }),
    h('div', { class: 'uia-chk' }, ...chk.map(([c, t]) => h('span', { class: c, text: t }))),
    h('p', { class: 'hint', text: 'الأخضر ممتاز، الأصفر يشتغل بس الأفضل تعدّله، الأحمر يثقل على المستخدمين.' })], [go]);
  go.onclick = async () => {
    go.disabled = true;
    try {
      let poster = '';
      if (meta) {
        go.textContent = 'يجهّز صورة الغلاف…';
        try { v.currentTime = Math.min(0.6, d / 2); await new Promise((r) => { v.onseeked = r; setTimeout(r, 2500); }); const c = document.createElement('canvas'); const k = Math.min(1, 540 / Math.max(1, w)); c.width = Math.round(w * k); c.height = Math.round(hh * k); c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); const pb = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.8)); if (pb) { go.textContent = 'يرفع الغلاف…'; poster = await Cloud.admin.designUpload(new File([pb], 'poster.jpg', { type: 'image/jpeg' }), 'ui'); } } catch { /* بدون غلاف */ }
      }
      go.textContent = `يرفع الفيديو (${uiaN(uiaMB(sz))} ميجا)…`;
      const vurl = await Cloud.admin.designUpload(f, 'ui');
      const L = uiaL(); L.videos = [...(L.videos || []), { url: vurl, poster, name: f.name.replace(/\.[^.]+$/, '').slice(0, 16) || 'فيديو', size: uiaMB(sz), dur: Math.round(d * 10) / 10, w, h: hh }];
      L.video = vurl; L.bg.type = 'video';
      closeSheet($('#mk-sheet')); URL.revokeObjectURL(url);
      toast('انرفع الفيديو ✓ — اضغط «نشر التعديلات» عشان يوصل للكل', { type: 'success', duration: 4500 });
      uiaCh(true);
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); go.disabled = false; go.textContent = '⬆️ ارفع واستخدمه'; }
  };
}

function uiaLogo() {
  const G = uiaL().logo;
  return uiaCard('✨ موشن الشعار', LoginUI.ANIMS[G.anim], false,
    uiaChips(LoginUI.ANIMS, () => G.anim, (k) => { G.anim = k; }),
    uiaSl('الحجم', () => G.size, 12, 44, 1, (v) => { G.size = v; }, (v) => uiaN(v)),
    uiaSl('السرعة', () => G.speed, 0.3, 2.5, 0.05, (v) => { G.speed = v; }, (v) => uiaN(v.toFixed(2)) + '×'),
    h('small', { class: 'hint', text: 'لون التوهّج' }), uiaCols(['#56C8FF', '#8B9CFF', '#8B45F0', '#FF4D9D', '#FF8A3D', '#FFD66B', '#1FC7A0', '#FFFFFF'], () => G.glow, (c) => { G.glow = c; }),
    uiaTog('🔁 الحركة مستمرة', 'لو مطفي: تشتغل مرة وحدة وقت الدخول', () => G.loop, (v) => { G.loop = v; }),
    h('small', { class: 'hint', text: 'اسم التطبيق تحت الشعار' }), uiaChips({ brand: 'ستايل الهوية', white: 'أبيض', gold: 'ذهبي', none: 'بدون' }, () => G.word || 'brand', (k) => { G.word = k; }),
    h('p', { class: 'hint', text: 'الشعار نفسه وألوان الاسم من «المحتوى ← الهوية».' }));
}
function uiaWel() {
  const W = uiaL().wel, T = uiaL().tag;
  const inp = h('input', { class: 'input', value: W.text || '', maxlength: 40, placeholder: 'أهلاً بعودتك يا {الاسم}' }); inp.addEventListener('input', () => { W.text = inp.value; uiaCh(); });
  const sub = h('input', { class: 'input', value: W.sub || '', maxlength: 60, placeholder: 'سطر صغير تحت الترحيب (اختياري)' }); sub.addEventListener('input', () => { W.sub = sub.value; uiaCh(); });
  const tg = h('input', { class: 'input', value: T.text || '', maxlength: 60, placeholder: 'فاضي = الجملة الحالية من «المحتوى»' }); tg.addEventListener('input', () => { T.text = tg.value; uiaCh(); });
  return uiaCard('📝 الترحيب والنصوص', LoginUI.WSTYLE[W.style], false,
    uiaTog('🕐 ترحيب حسب الوقت', 'صباح الخير / مساء النور / مساء الخير + اسم المستخدم', () => W.time, (v) => { W.time = v; }),
    mkField('نص الترحيب (لو حسب الوقت مطفي) — {الاسم} = اسم المستخدم', inp), sub,
    h('small', { class: 'hint', text: 'شكل الترحيب' }), uiaChips(LoginUI.WSTYLE, () => W.style, (k) => { W.style = k; }),
    uiaSl('الحجم', () => W.size, 4, 10, 0.1, (v) => { W.size = v; }, (v) => uiaN(v.toFixed(1))),
    mkField('الجملة تحت الشعار', tg), uiaTog('إظهار الجملة', '', () => T.show, (v) => { T.show = v; }));
}
function uiaBtns() {
  const U = uiaL().ui, B = uiaL().bio;
  return uiaCard('🔘 الأزرار والبصمة', '', false,
    h('small', { class: 'hint', text: 'لون الزر' }), uiaCols(['#2E5BFF', '#8B45F0', '#FF4D9D', '#FF6A3D', '#FFB43D', '#1FC7A0', '#56C8FF', '#E5484D'], () => U.acc, (c) => { U.acc = c; }),
    uiaSl('دوران الحواف', () => (U.rad >= 50 ? 8 : U.rad), 0, 8, 0.5, (v) => { U.rad = v >= 8 ? 99 : v; }, (v) => (v >= 8 ? 'كبسولة' : uiaN(v))),
    uiaTog('خانة زجاجية', 'تشوف الخلفية من وراها بشكل ضبابي', () => U.glass, (v) => { U.glass = v; }),
    uiaTog('🔐 زر البصمة', 'يطلع للي فعّل البصمة من إعداداته', () => B.show, (v) => { B.show = v; }),
    h('small', { class: 'hint', text: 'أيقونة الزر' }), uiaChips({ fp: '☝️ بصمة الإصبع', face: '🙂 بصمة الوجه' }, () => (B.face ? 'face' : 'fp'), (k) => { B.face = k === 'face'; }));
}
function uiaSeasons() {
  const L = uiaL(); L.seasons = L.seasons || [];
  const today = new Date().toISOString().slice(0, 10);
  const row = (s, i) => {
    const th = h('select', { class: 'input' }, ...Object.entries(LoginUI.THEMES).map(([k, t]) => h('option', { value: k, text: t.name }))); th.value = s.theme || 'night'; th.addEventListener('change', () => { s.theme = th.value; uiaCh(); });
    const vd = h('select', { class: 'input' }, h('option', { value: '', text: 'فيديو الثيم الأساسي' }), ...(L.videos || []).map((v) => h('option', { value: v.url, text: '🎬 ' + (v.name || 'فيديو') }))); vd.value = s.video || ''; vd.addEventListener('change', () => { s.video = vd.value; uiaCh(); });
    const nm = h('input', { class: 'input', value: s.name || '', maxlength: 20, placeholder: 'اسم الموسم' }); nm.addEventListener('input', () => { s.name = nm.value; mkChanged(); });
    const ic = h('input', { class: 'input uia-ic', value: s.ic || '🌙', maxlength: 4 }); ic.addEventListener('input', () => { s.ic = ic.value; mkChanged(); });
    const fr = h('input', { class: 'input ltr', type: 'date', value: s.from || '' }); fr.addEventListener('change', () => { s.from = fr.value; mkChanged(); });
    const to = h('input', { class: 'input ltr', type: 'date', value: s.to || '' }); to.addEventListener('change', () => { s.to = to.value; mkChanged(); });
    const wl = h('input', { class: 'input', value: s.wel || '', maxlength: 40, placeholder: 'ترحيب خاص (اختياري) — مثل: رمضان كريم يا {الاسم} 🌙' }); wl.addEventListener('input', () => { s.wel = wl.value; mkChanged(); });
    const live = s.on && s.from && s.to && s.from <= today && today <= s.to;
    return h('div', { class: `uia-sea${live ? ' live' : ''}` },
      h('div', { class: 'uia-sea-h' }, ic, nm, live ? h('em', { text: 'شغّال الحين' }) : null, mkSwitch(s, 'on', null, null, () => uiaCh(true)), h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => { L.seasons.splice(i, 1); uiaCh(true); } }, '✕')),
      h('div', { class: 'row-2' }, mkField('من', fr), mkField('إلى', to)), h('div', { class: 'row-2' }, mkField('الثيم', th), mkField('الفيديو', vd)), wl);
  };
  return uiaCard('🗓 ثيمات المواسم', `${uiaN(L.seasons.length)} موسم`, false,
    ...L.seasons.map(row),
    h('div', { class: 'chips' }, ...[['🌙', 'رمضان', 'night'], ['🎉', 'العيد', 'flame'], ['🇸🇦', 'اليوم الوطني', 'classic'], ['✨', 'موسم جديد', 'ring']].map(([ic, n, t]) => h('button', { type: 'button', class: 'chip', onclick: () => { L.seasons.push({ id: Date.now().toString(36), ic, name: n === 'موسم جديد' ? '' : n, theme: t, from: today, to: today, on: true, video: '', wel: '' }); uiaCh(true); } }, `＋ ${ic} ${n}`))),
    h('p', { class: 'hint', text: 'بين التاريخين يشتغل ثيم الموسم لحاله، وبعدها يرجع الثيم الأساسي.' }));
}

/* ===== 🎬 فيديو الافتتاح (1.18.3) — يشتغل حتى لو الواجهة الجديدة مطفية ===== */
const UIA_WHEN = { first: '1️⃣ أول مرة بس', daily: '☀️ مرة في اليوم', always: '🔁 كل فتحة' };
function uiaIntro() {
  const L = uiaL(); L.intro = { ...Intro.DEF, ...(L.intro || {}) }; const I = L.intro;
  const file = h('input', { type: 'file', accept: 'video/mp4,video/webm,video/*', hidden: true });
  file.addEventListener('change', () => { const f = file.files[0]; file.value = ''; if (f) uiaIntroUpload(f); });
  const sub = I.on && I.url ? `شغّال · ${UIA_WHEN[I.when]}` : I.url ? 'مطفي' : 'ما فيه فيديو';
  return uiaCard('🎬 فيديو الافتتاح', sub, true,
    h('p', { class: 'hint', text: 'فيديو قصير يطلع قبل ما يفتح التطبيق. ينزل مرة وحدة وينحفظ في الجوال — وبدون نت تطلع شاشة الشعار العادية.' }),
    uiaTog('تشغيل فيديو الافتتاح', I.url ? '' : 'ارفع فيديو أول', () => I.on && !!I.url, (v) => { I.on = v && !!I.url; if (v && !I.url) toast('ارفع فيديو أول'); }, true),
    file,
    I.url ? h('div', { class: 'uia-intro' },
      h('div', { class: 'uia-intro-th' }, I.poster ? h('img', { src: I.poster, alt: '' }) : h('span', { text: '🎬' })),
      h('div', {}, h('b', { text: I.name || 'فيديو الافتتاح' }), h('small', { class: 'hint', text: [I.dur ? `${uiaN(I.dur)} ث` : '', I.size ? `${uiaN(I.size)} ميجا` : ''].filter(Boolean).join(' · ') }),
        h('div', { class: 'chips' },
          h('button', { type: 'button', class: 'chip', onclick: () => Intro.run({ force: true, over: I }) }, '▶ جرّبه الحين'),
          h('button', { type: 'button', class: 'chip', onclick: () => file.click() }, '🔁 غيّره'),
          h('button', { type: 'button', class: 'chip', onclick: async () => {
            if (!(await confirmSheet({ title: 'حذف فيديو الافتتاح؟', text: 'يرجع التطبيق لشاشة الشعار العادية بعد النشر.', ok: 'حذف' }))) return;
            try { await Cloud.admin.storageRemove([I.url, I.poster].filter(Boolean)); } catch { /* لا شيء */ }
            L.intro = { ...Intro.DEF }; uiaCh(true);
          } }, '🗑 حذف'))))
      : h('button', { type: 'button', class: 'btn btn-block', onclick: () => file.click() }, '⬆️ ارفع فيديو الافتتاح (طولي ٩:١٦ · ٣–٦ ثواني)'),
    h('small', { class: 'hint', text: 'متى يطلع' }), uiaChips(UIA_WHEN, () => I.when, (k) => { I.when = k; }, true),
    uiaSl('زر «تخطّي» يطلع بعد', () => I.skip, 0, 5, 1, (v) => { I.skip = v; }, (v) => v ? uiaN(v) + ' ث' : 'فوراً'),
    uiaSl('أقصى مدة', () => I.max, 3, 10, 1, (v) => { I.max = v; }, (v) => uiaN(v) + ' ث'),
    uiaTog('🔊 بالصوت', 'لو مطفي: صامت، والمستخدم يقدر يشغّل الصوت من الزر', () => I.sound, (v) => { I.sound = v; }),
    h('small', { class: 'hint', text: 'بعد الفيديو' }), uiaChips({ direct: '➡️ يدخل التطبيق مباشرة', start: '🔘 زر «ابدأ»' }, () => I.end, (k) => { I.end = k; }),
    h('p', { class: 'hint', text: '💡 النصيحة: ٣–٦ ثواني، «مرة في اليوم»، صامت، وتخطّي بعد ثانيتين. لا تنسى «نشر التعديلات».' }));
}
async function uiaIntroUpload(f) {
  const url = URL.createObjectURL(f), v = document.createElement('video'); v.muted = true; v.preload = 'auto'; v.playsInline = true; v.src = url;
  const meta = await new Promise((res) => { v.onloadedmetadata = () => res(true); v.onerror = () => res(false); setTimeout(() => res(false), 8000); });
  const d = meta ? v.duration : 0, w = v.videoWidth, hh = v.videoHeight, sz = f.size, chk = [];
  if (meta) {
    chk.push(d <= 6.5 ? ['ok', `⏱ ${uiaN(d.toFixed(1))} ث`] : d <= 10 ? ['warn', `⏱ ${uiaN(d.toFixed(1))} ث — يتقطع عند «أقصى مدة»`] : ['bad', `⏱ ${uiaN(Math.round(d))} ث — طويل، قصّه`]);
    chk.push(hh >= w ? ['ok', `📐 طولي ${uiaN(w)}×${uiaN(hh)}`] : ['warn', '📐 عرضي — ينقص من الجوانب']);
  }
  chk.push(sz <= 4 * 1048576 ? ['ok', `💾 ${uiaN(uiaMB(sz))} ميجا`] : sz <= 10 * 1048576 ? ['warn', `💾 ${uiaN(uiaMB(sz))} ميجا — ثقيل شوي`] : ['bad', `💾 ${uiaN(uiaMB(sz))} ميجا — ثقيل`]);
  const bad = sz > 25 * 1048576;
  const go = h('button', { type: 'button', class: 'btn btn-primary', disabled: bad }, bad ? 'الفيديو أكبر من ٢٥ ميجا — صغّره أول' : '⬆️ ارفع واستخدمه');
  mkSheet('🎬 فيديو الافتتاح', [
    h('video', { class: 'uia-up-pv', src: url, muted: true, autoplay: true, loop: true, playsinline: true }),
    h('div', { class: 'uia-chk' }, ...chk.map(([c, t]) => h('span', { class: c, text: t }))),
    h('p', { class: 'hint', text: 'الأخضر ممتاز، الأصفر يشتغل، الأحمر يثقل على المستخدمين. ارفع بس فيديو عندك حقه.' })], [go]);
  go.onclick = async () => {
    go.disabled = true;
    try {
      let poster = '';
      if (meta) {
        go.textContent = 'يجهّز صورة الغلاف…';
        try { v.currentTime = Math.min(0.1, d / 2); await new Promise((r) => { v.onseeked = r; setTimeout(r, 2500); }); const c = document.createElement('canvas'); const k = Math.min(1, 540 / Math.max(1, w)); c.width = Math.round(w * k); c.height = Math.round(hh * k); c.getContext('2d').drawImage(v, 0, 0, c.width, c.height); const pb = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.8)); if (pb) poster = await Cloud.admin.designUpload(new File([pb], 'poster.jpg', { type: 'image/jpeg' }), 'ui'); } catch { /* بدون غلاف */ }
      }
      go.textContent = `يرفع الفيديو (${uiaN(uiaMB(sz))} ميجا)…`;
      const vurl = await Cloud.admin.designUpload(f, 'ui');
      const L = uiaL(), old = L.intro || {};
      if (old.url) Cloud.admin.storageRemove([old.url, old.poster].filter(Boolean)).catch(() => {});
      L.intro = { ...Intro.DEF, ...old, on: true, url: vurl, poster, name: f.name.replace(/\.[^.]+$/, '').slice(0, 20) || 'فيديو', size: uiaMB(sz), dur: Math.round(d * 10) / 10 };
      closeSheet($('#mk-sheet')); URL.revokeObjectURL(url);
      toast('انرفع فيديو الافتتاح ✓ — اضغط «نشر التعديلات» عشان يوصل للكل', { type: 'success', duration: 4500 });
      uiaCh(true);
    } catch (e) { toast(Cloud.msg(e), { type: 'error' }); go.disabled = false; go.textContent = '⬆️ ارفع واستخدمه'; }
  };
}

/* 1.20 — «🧭 شريط التنقل» (انتقل من الاشتراكات): اضغط على الشكل يظهر/يختفي عند المستخدم */
function uiaTabbar() {
  if (typeof TabStyles === 'undefined') return null;
  const d = MK.data;
  d.tabbar = { ...TabStyles.DEF, ...(d.tabbar || {}), access: { ...((d.tabbar || {}).access || {}) } };
  const T = d.tabbar;
  const accOf = (id) => T.access[id] || (TabStyles.STYLES.find((s) => s[0] === id) || [])[3] || 'free';
  const ACC = [['free', 'مجاني'], ['trial', 'تجربة'], ['pro', '★ مدفوع']];
  const shown = () => TabStyles.STYLES.filter(([id]) => accOf(id) !== 'off').length;
  const count = h('small', { class: 'uia-tb-n' });
  const grid = h('div', { class: 'uia-tbgrid' });
  const paint = () => {
    count.textContent = `يظهر للمستخدم ${UI.n(shown())} من ${UI.n(TabStyles.STYLES.length)}`;
    grid.replaceChildren(...TabStyles.STYLES.map(([id, name, desc, defAcc]) => {
      const a = accOf(id), on = a !== 'off', def = T.def === id;
      const toggle = () => {
        if (def && on) return toast('هذا الشكل الافتراضي — اختر افتراضي ثاني قبل لا تخفيه', { type: 'error' });
        if (on) { if (shown() <= 1) return toast('لازم يبقى شكل واحد على الأقل'); T.access[id] = 'off'; } else T.access[id] = defAcc === 'off' ? 'free' : (T.access[`_${id}`] || defAcc);
        if (on) T.access[`_${id}`] = a; // نتذكر نوعه لو رجّعته
        mkChanged(); paint();
      };
      const type = h('select', { class: 'input sm', 'aria-label': 'النوع', disabled: !on || null }, ...ACC.map(([v, l]) => h('option', { value: v, text: l })));
      type.value = on ? a : 'free';
      type.addEventListener('change', () => { T.access[id] = type.value; mkChanged(); });
      return h('div', { class: `uia-tb${on ? '' : ' off'}${def ? ' def' : ''}` },
        h('button', { type: 'button', class: 'uia-tb-pv', title: on ? 'اضغط تخفيه' : 'اضغط تظهره', onclick: toggle }, TabStyles.mini(id),
          h('span', { class: `uia-tb-tag ${on ? 'on' : 'off'}`, text: on ? '👁 يظهر' : '🚫 مخفي' }),
          def ? h('span', { class: 'uia-tb-def', text: '⭐ الافتراضي' }) : null),
        h('div', { class: 'uia-tb-info' }, h('b', { text: name }), h('small', { text: desc })),
        h('div', { class: 'uia-tb-acts' }, type,
          h('button', { type: 'button', class: `btn sm uia-tb-star${def ? ' btn-primary' : ''}`, title: def ? 'الشكل الافتراضي' : 'اجعله الافتراضي', 'aria-label': 'اجعله الافتراضي', disabled: !on || def || null, onclick: () => { T.def = id; mkChanged(); paint(); } }, def ? '⭐' : '☆')));
    }));
    setTimeout(() => UI.digitize(grid), 60);
  };
  paint();
  const all = (fn) => () => { TabStyles.STYLES.forEach(([id, , , defAcc]) => fn(id, defAcc)); if (accOf(T.def) === 'off') T.access[T.def] = 'free'; mkChanged(); paint(); };
  const sel = (val, opts, on) => { const x = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: String(v), text: l }))); x.value = String(val); x.addEventListener('change', () => { on(x.value); mkChanged(); }); return x; };
  return uiaCard('🧭 شريط التنقل', 'اضغط على الشكل يظهر أو يختفي عند المستخدم', false,
    h('div', { class: 'uia-tb-top' }, count, h('span', { class: 'spacer' }),
      h('button', { type: 'button', class: 'btn sm', onclick: all((id, defAcc) => { if (accOf(id) === 'off') T.access[id] = T.access[`_${id}`] || (defAcc === 'off' ? 'free' : defAcc); }) }, '✓ أظهر الكل'),
      h('button', { type: 'button', class: 'btn sm', onclick: all((id) => { if (id !== T.def && accOf(id) === 'pro') { T.access[`_${id}`] = 'pro'; T.access[id] = 'off'; } }) }, '🚫 اخفِ المدفوعة')),
    grid,
    h('p', { class: 'hint', text: '«تجربة»: المستخدم يجرّبه أيام وبعدها يرجع للافتراضي إلا لو اشترك. في «وضع المتجر» مع إخفاء الاشتراكات تظهر له المجانية بس.' }),
    h('div', { class: 'row-2' },
      mkField('أيام التجربة لكل شكل', mkInput(T, 'trialDays', { type: 'number', min: 1, cls: 'mk-num' })),
      mkField('لون الشريط', sel(T.color || '', Object.entries(TabStyles.COLORS || {}).map(([k, v]) => [k, v[0]]), (v) => { T.color = v; }))),
    h('div', { class: 'row-2' },
      mkField('حركة الأيقونة', sel(T.motion || '', [['', 'حسب الشكل'], ...Object.entries(TabStyles.MOTIONS)], (v) => { T.motion = v; })),
      mkField('نَفَس الحركة', sel(T.ease, Object.entries(TabStyles.EASES).map(([k, v]) => [k, v[0]]), (v) => { T.ease = v; }))),
    mkField('أسماء الأزرار', sel(T.labels === false ? '0' : '1', [['1', 'ظاهرة'], ['0', 'أيقونات فقط']], (v) => { T.labels = v === '1'; })),
    mkSwitch(T, 'allowPick', 'المستخدم يختار شكله', 'عند الإيقاف يشوف الجميع الشكل الافتراضي فقط'));
}

/* 1.20 — «🎨 ثيمات التطبيق والألوان»: وش يظهر للمستخدم */
function uiaAppThemes() {
  if (typeof ThemeCtl === 'undefined') return null;
  const d = MK.data;
  d.themes = { ...ThemeCtl.DEF, ...(d.themes || {}), modes: { ...ThemeCtl.DEF.modes, ...((d.themes || {}).modes || {}) }, access: { ...((d.themes || {}).access || {}) } };
  const T = d.themes;
  if (!T.def) T.def = (typeof Content !== 'undefined' && Content.get('defaultTheme')) || 'midnight';
  const accOf = (id) => T.access[id] || ThemeCtl.DEF_ACC[id] || 'free';
  const shown = () => Themes.LIST.filter((t) => accOf(t.id) !== 'off').length;
  const count = h('small', { class: 'uia-tb-n' });
  const grid = h('div', { class: 'uia-thgrid' });
  const paint = () => {
    count.textContent = `يظهر للمستخدم ${UI.n(shown())} من ${UI.n(Themes.LIST.length)}`;
    grid.replaceChildren(...Themes.LIST.map((t) => {
      const a = accOf(t.id), on = a !== 'off', def = T.def === t.id;
      const toggle = () => {
        if (def && on) return toast('هذا الثيم الافتراضي — اختر افتراضي ثاني قبل لا تخفيه', { type: 'error' });
        if (on) { if (shown() <= 1) return toast('لازم يبقى ثيم واحد على الأقل'); T.access[`_${t.id}`] = a; T.access[t.id] = 'off'; } else T.access[t.id] = T.access[`_${t.id}`] || ThemeCtl.DEF_ACC[t.id] || 'free';
        mkChanged(); paint();
      };
      const type = h('select', { class: 'input sm', 'aria-label': 'النوع', disabled: !on || null }, h('option', { value: 'free', text: 'مجاني' }), h('option', { value: 'pro', text: '★ مدفوع' }));
      type.value = on ? a : 'free';
      type.addEventListener('change', () => { T.access[t.id] = type.value; mkChanged(); });
      return h('div', { class: `uia-tb uia-ath${on ? '' : ' off'}${def ? ' def' : ''}` },
        h('button', { type: 'button', class: 'uia-tb-pv uia-ath-pv', title: on ? 'اضغط تخفيه' : 'اضغط تظهره', onclick: toggle, style: { '--n': t.night, '--s': `rgb(${t.s1})`, '--p': t.pri, '--g': t.flame, '--k': t.ink2 } },
          h('span', { class: 'th-glow' }), h('span', { class: 'th-card' }, h('i'), h('b'), h('em')), h('span', { class: 'th-btn' }),
          h('span', { class: `uia-tb-tag ${on ? 'on' : 'off'}`, text: on ? '👁 يظهر' : '🚫 مخفي' }),
          def ? h('span', { class: 'uia-tb-def', text: '⭐ الافتراضي' }) : null),
        h('div', { class: 'uia-tb-info' }, h('b', { text: t.name })),
        h('div', { class: 'uia-tb-acts' }, type,
          h('button', { type: 'button', class: `btn sm uia-tb-star${def ? ' btn-primary' : ''}`, title: def ? 'الثيم الافتراضي' : 'اجعله الافتراضي', disabled: !on || def || null, onclick: () => { T.def = t.id; mkChanged(); paint(); } }, def ? '⭐' : '☆')));
    }));
  };
  paint();
  const modeSw = (k, l) => { const i = h('input', { type: 'checkbox', checked: !!T.modes[k] }); i.addEventListener('change', () => { T.modes[k] = i.checked; if (!Object.values(T.modes).some(Boolean)) { T.modes.dark = true; toast('لازم وضع واحد على الأقل'); renderUiAdmin(); return; } mkChanged(); }); return h('label', { class: 'uia-chk' }, i, h('span', { text: l })); };
  const dm = h('select', { class: 'input' }, ...[['dark', 'داكن'], ['light', 'فاتح'], ['system', 'حسب الجهاز']].map(([v, l]) => h('option', { value: v, text: l })));
  dm.value = T.defMode || 'dark'; dm.addEventListener('change', () => { T.defMode = dm.value; mkChanged(); });
  return uiaCard('🎨 ثيمات التطبيق والألوان', 'وش يشوف المستخدم في الإعدادات ← المظهر', false,
    h('div', { class: 'uia-tb-top' }, count, h('span', { class: 'spacer' }),
      h('button', { type: 'button', class: 'btn sm', onclick: () => { Themes.LIST.forEach((t) => { if (accOf(t.id) === 'off') T.access[t.id] = T.access[`_${t.id}`] || ThemeCtl.DEF_ACC[t.id] || 'free'; }); mkChanged(); paint(); } }, '✓ أظهر الكل')),
    grid,
    mkSwitch(T, 'allowPick', 'المستخدم يختار ثيمه', 'لو طفيته الكل يشوف الثيم الافتراضي بس، وتختفي الثيمات من إعداداته'),
    h('div', { class: 'field' }, h('span', { text: '🎨 اللون المخصص (يختار لون الأزرار بنفسه)' }),
      mkSeg([['free', 'مجاني'], ['pro', '★ مشتركين'], ['off', 'مقفل']], T.custom || 'pro', (v) => { T.custom = v; mkChanged(); renderUiAdmin(); })),
    h('div', { class: 'field' }, h('span', { text: '🌗 الأوضاع اللي يقدر يختارها' }), h('div', { class: 'uia-chks' }, modeSw('dark', 'داكن'), modeSw('light', 'فاتح'), modeSw('system', 'حسب الجهاز'))),
    mkField('الوضع الافتراضي', dm, 'يتطبّق على اللي ما اختار وضع، أو لو وضعه صار مقفل'),
    h('p', { class: 'hint', text: 'في «وضع المتجر» مع إخفاء الاشتراكات، ثيمات «★ مشتركين» تنفتح للكل.' }));
}

/* 1.20 — «💳 شكل المالية»: وش يظهر في رئيسية المالية */
function uiaFinUi() {
  const d = MK.data;
  d.finui = { style: 'card', card: true, quick: true, limit: true, week: true, months: true, recent: true, ...(d.finui || {}) };
  const F = d.finui;
  const tog = (k, l, sub) => mkSwitch(F, k, l, sub);
  return uiaCard('💳 شكل المالية', 'بطاقة الرصيد، حد الصرف، نشاط الأسبوع — وش يظهر للمستخدم', false,
    h('div', { class: 'field' }, h('span', { text: 'شكل الرصيد' }),
      mkSeg([['card', '💳 بطاقة زجاجية'], ['classic', 'الكلاسيكي']], F.style, (v) => { F.style = v; mkChanged(); renderUiAdmin(); })),
    tog('quick', 'اختصارات دائرية', 'مصروف · دخل · تحويل · فاتورة'),
    tog('limit', 'حد الصرف الشهري', 'صرفت كذا من ميزانيتك + كم باقي لك يومياً'),
    tog('week', 'نشاط الأسبوع', 'أعمدة مصروف آخر ٧ أيام واليوم يتوهج'),
    tog('months', 'آخر ٦ أشهر', 'رسم الدخل والمصروف'),
    tog('recent', 'آخر الحركات', null));
}

/* 1.21.2 — «🔔 جرس عاجل»: أيقونة فوق جنب رسائل الدعم تنبّه المستخدم إن فيه عدد جديد نزل */
function uiaBell() {
  const d = MK.data;
  d.ainBell = { on: true, mode: 'new', open: 'hub', pulse: true, ...(d.ainBell || {}) };
  const B = d.ainBell;
  B.kinds = { urgent: true, daily: true, weekly: true, monthly: true, ...(B.kinds || {}) };
  const re = () => { mkChanged(); renderUiAdmin(); };
  const K = [['urgent', '⚡ عاجل'], ['daily', 'اليومي'], ['weekly', 'الأسبوعي'], ['monthly', 'الشهري']];
  return uiaCard('🔔 جرس عاجل', B.on ? (B.mode === 'new' ? 'يظهر بس لما ينزل جديد' : 'ظاهر دايماً') : 'مخفي', false,
    h('div', { class: 'uia-bell-pv' },
      h('span', { class: 'uia-bell-ic' + (B.on ? '' : ' off') }, icon('bell', { size: 20 }), B.on ? h('i', { text: '2' }) : null),
      h('span', { class: 'uia-bell-ic' }, icon('inbox', { size: 20 })),
      h('small', { class: 'hint', text: 'فوق جنب رسائل الدعم — الرقم = كم عدد جديد ما شافه' })),
    mkSwitch(B, 'on', 'إظهار الجرس', 'لو قفلته يختفي من فوق عند الكل', re),
    h('div', { class: 'field' }, h('span', { text: 'متى يظهر' }),
      mkSeg([['new', 'بس لما فيه جديد'], ['always', 'دايماً']], B.mode, (v) => { B.mode = v; re(); })),
    h('div', { class: 'field' }, h('span', { text: 'لما يضغط عليه' }),
      mkSeg([['hub', 'يفتح صفحة عاجل'], ['issue', 'يشغّل آخر عدد على طول']], B.open, (v) => { B.open = v; re(); })),
    mkSwitch(B, 'pulse', 'الجرس يهتز لما فيه جديد', null),
    h('div', { class: 'field' }, h('span', { text: 'وش ينبّه عليه' }),
      h('div', { class: 'uia-chips' }, ...K.map(([k, l]) => h('button', { type: 'button', class: 'chip' + (B.kinds[k] !== false ? ' on' : ''),
        onclick: () => { B.kinds[k] = B.kinds[k] === false; re(); } }, l)))));
}

/* 1.21.5 — «🔝 أيقونات الرأس»: الشكل + إظهار/إخفاء + الترتيب + الإشعار + الحجم */
function uiaHdr() {
  const d = MK.data, K = HdrKit; K.defs();
  d.hdr = K.cfg(d.hdr || {});
  const C = d.hdr, re = () => { mkChanged(); renderUiAdmin(); };
  const IC = { sync: 'repeat', acct: 'user', bell: 'bell', inbox: 'inbox', settings: 'settings', lock: 'lock' };
  // معاينة حيّة بنفس كلاسات التطبيق
  const pvBtns = C.order.filter((k) => C.show[k] && !(C.style === 'menu' && C.menu.includes(k) && k !== 'bell' && k !== 'inbox' && k !== 'acct')).map((k) => k === 'pro'
    ? h('span', { class: 'pro-btn', text: 'Pro ★' })
    : h('span', { class: `icon-btn${k === 'bell' ? ' ain-bell pulse' : ''}` }, icon(IC[k], { size: 20 }), k === 'bell' ? h('i', { class: 'ain-bell-n num', text: '2' }) : k === 'inbox' ? h('i', { class: 'dot' }) : null));
  if (C.style === 'menu') pvBtns.push(h('span', { class: 'icon-btn' }, icon('more', { size: 20 })));
  const pv = h('div', { class: 'uia-hdr-pv top' },
    h('div', { class: 'brand' }, h('img', { class: 'brand-mark', src: 'img/mark.png', alt: '' }), h('div', {}, h('div', { class: 'brand-name' }, h('b', { text: 'NOBLE' })), h('div', { class: 'brand-sub', text: 'رفيقك اليومي ✨' }))),
    h('div', { class: `top-actions hk-${C.style}${C.size === 'sm' ? ' hk-sm' : ''}${C.badge === 'dot' ? ' hk-dot' : ''}` }, ...pvBtns));
  const mv = (k, dir) => { const a = C.order, i = a.indexOf(k), j = i + dir; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; re(); };
  const rows = C.order.map((k, i) => h('div', { class: 'uia-hdr-row' },
    h('span', { class: 'uia-hdr-ic' }, k === 'pro' ? h('b', { text: '★' }) : icon(IC[k], { size: 18 })),
    h('b', { text: K.NAME[k] }),
    C.style === 'menu' && !['bell', 'inbox', 'acct'].includes(k) ? h('button', { type: 'button', class: 'chip sm' + (C.menu.includes(k) ? ' on' : ''), onclick: () => { C.menu = C.menu.includes(k) ? C.menu.filter((x) => x !== k) : [...C.menu, k]; re(); } }, 'داخل ⋯') : null,
    h('span', { class: 'spacer' }),
    h('button', { type: 'button', class: 'icon-btn sm', disabled: i === 0, 'aria-label': 'قدّم', onclick: () => mv(k, -1) }, '↑'),
    h('button', { type: 'button', class: 'icon-btn sm', disabled: i === C.order.length - 1, 'aria-label': 'أخّر', onclick: () => mv(k, 1) }, '↓'),
    mkSwitch(C.show, k, null, null, re, { def: false })));
  return uiaCard('🔝 أيقونات الرأس', K.STYLES.find(([v]) => v === C.style)?.[1] || '', false,
    pv,
    h('p', { class: 'hint', text: 'المعاينة نفس اللي يشوفه المستخدم فوق جنب الشعار. الجرس والرسائل وPro يطلعون بس لما يكون لهم سبب (جديد، رسالة، مو مشترك)، و👤 حساب الضيف يطلع بس للي داخل كضيف (احفظ حسابك / عندي حساب).' }),
    h('div', { class: 'field' }, h('span', { text: 'الشكل' }), mkSeg(K.STYLES, C.style, (v) => { C.style = v; re(); })),
    h('div', { class: 'field' }, h('span', { text: 'الأيقونات والترتيب' }), h('div', { class: 'uia-hdr-list' }, ...rows)),
    h('div', { class: 'field' }, h('span', { text: 'الحجم' }), mkSeg([['md', 'عادي'], ['sm', 'صغير']], C.size, (v) => { C.size = v; re(); })),
    h('div', { class: 'field' }, h('span', { text: 'إشعار الجرس' }), mkSeg([['num', 'رقم (٢)'], ['dot', 'نقطة بس']], C.badge, (v) => { C.badge = v; re(); })),
    mkSwitch(C, 'motion', 'الحركة', 'الجرس يهتز لما فيه جديد، والمزامنة تلف وهي شغّالة', re),
    h('button', { type: 'button', class: 'btn sm', onclick: () => { d.hdr = K.cfg({}); re(); } }, '↺ رجّع الافتراضي'));
}
