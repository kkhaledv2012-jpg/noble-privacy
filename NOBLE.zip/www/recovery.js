/* NOBLE — استرجاع الحساب إذا نسي المستخدم كلمة المرور (1.9)
 * ١) كود من ٦ أرقام يصل على الإيميل ← ٢) كلمة مرور جديدة ← ٣) نرجّع البيانات المشفّرة:
 *    • استرجاع تلقائي (الافتراضي): مفتاح الخزنة محفوظ في حسابه.
 *    • كود استرجاع خاص: المفتاح مشفّر بكود يحتفظ به المستخدم — خصوصية كاملة.
 */
'use strict';

const Keys = {
  /* الوضع محفوظ داخل الخزنة نفسها (يتزامن بين الأجهزة) */
  mode: () => (S.vault?._rk ? 'code' : 'auto'),
  /* كود من ١٦ حرفاً بدون الحروف المتشابهة */
  genCode() {
    const A = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
    const v = crypto.getRandomValues(new Uint8Array(16));
    const s = [...v].map((x) => A[x % A.length]).join('');
    return s.match(/.{4}/g).join('-');
  },
  /* يحدّث مفتاح الاسترجاع في الحساب إذا تغيّرت كلمة المرور أو الوضع */
  busy: false,
  async sync() {
    if (this.busy || !Cloud.enabled || !S.unlocked || !S.vault) return;
    this.busy = true;
    try {
      if (!(await Cloud.user())) return;
      const raw = await Core.rawKey();
      const salt = await Core.authSalt();
      if (!raw || !salt) return;
      const mode = this.mode();
      const cur = await Cloud.myKey().catch(() => null);
      if (cur && cur.salt === salt && cur.mode === mode && (mode === 'code' ? cur.ck === S.vault._rkSalt : !!cur.k)) return;
      if (mode === 'auto') await Cloud.setMyKey({ v: 1, mode: 'auto', salt, k: raw, at: Date.now() });
      else await Cloud.setMyKey({ v: 1, mode: 'code', salt, ck: S.vault._rkSalt, wrap: await Core.wrapRaw(S.vault._rk, raw), at: Date.now() });
    } catch { /* نحاول لاحقاً */ } finally { this.busy = false; }
  },
  async useCode() {
    const code = this.genCode();
    const { key, salt } = await Core.codeKey(code);
    await commit((v) => { v._rk = key; v._rkSalt = salt; });
    await this.sync();
    showRecoveryCode(code);
    renderRecoveryPrefs();
  },
  async useAuto() {
    const ok = await confirmSheet({ title: 'الاسترجاع التلقائي؟', text: 'مفتاح بياناتك يُحفظ في حسابك، فترجع بياناتك كاملة بكود الإيميل فقط. كود الاسترجاع الحالي يتوقف.', ok: 'تفعيل التلقائي', tone: 'primary' });
    if (!ok) return renderRecoveryPrefs();
    await commit((v) => { delete v._rk; delete v._rkSalt; });
    await this.sync();
    toast('تم — الاسترجاع التلقائي مفعّل', { type: 'success' });
    renderRecoveryPrefs();
  },
};

/* يعرض كود الاسترجاع مرة واحدة */
function showRecoveryCode(code) {
  let sheet = $('#rcode-sheet');
  if (!sheet) { sheet = h('section', { class: 'sheet sheet-sm', id: 'rcode-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(sheet); }
  const done = h('button', { type: 'button', class: 'btn btn-primary btn-block', disabled: true, onclick: () => closeSheet(sheet) }, 'حفظته في مكان آمن');
  const chk = h('input', { type: 'checkbox' });
  chk.addEventListener('change', () => (done.disabled = !chk.checked));
  sheet.replaceChildren(h('div', { class: 'grab' }),
    h('div', { class: 'confirm-body rc-body' },
      h('h2', { text: 'كود الاسترجاع الخاص بك' }),
      h('p', { text: 'إذا نسيت كلمة المرور تحتاج هذا الكود مع الإيميل لترجع بياناتك. لا أحد غيرك يقدر يفك بياناتك — ولا حتى الإدارة.' }),
      h('div', { class: 'rc-code ltr', text: code }),
      h('div', { class: 'btn-grid' },
        h('button', { type: 'button', class: 'btn', onclick: () => copyText(code) }, icon('copy', { size: 16 }), 'نسخ'),
        h('button', { type: 'button', class: 'btn', onclick: () => saveFile(`NOBLE-recovery-code.txt`, `كود استرجاع NOBLE\n${code}\n\nاحفظه في مكان آمن. تحتاجه مع إيميلك إذا نسيت كلمة المرور.`, 'text/plain') }, icon('download', { size: 16 }), 'حفظ كملف')),
      h('label', { class: 'remember-row' }, chk, h('span', { class: 'rm-box' }), h('span', { text: 'فهمت: إذا ضيّعت الكود ونسيت كلمة المرور تضيع بياناتي' })),
      done));
  openSheet('#rcode-sheet');
}

/* خيار الاسترجاع في إعدادات الأمان */
function renderRecoveryPrefs() {
  const box = $('#recovery-box');
  if (!box) return;
  box.hidden = !Cloud.enabled;
  if (!Cloud.enabled) return;
  const mode = Keys.mode();
  const seg = h('div', { class: 'seg seg-2' }, ...[['auto', 'استرجاع تلقائي'], ['code', 'كود استرجاع خاص بي']].map(([v, l]) =>
    h('label', {}, h('input', { type: 'radio', name: 'rcmode', value: v, checked: mode === v, onchange: () => (v === 'code' ? Keys.useCode() : Keys.useAuto()) }), h('span', { text: l }))));
  box.replaceChildren(
    h('div', { class: 'set-row' }, h('div', {}, h('strong', { text: 'إذا نسيت كلمة المرور' }), h('p', { class: 'hint', text: 'يوصلك كود على إيميلك، وتختار كلمة مرور جديدة.' }))),
    seg,
    h('p', { class: 'hint', text: mode === 'auto' ? 'التلقائي: ترجع بياناتك كاملة بكود الإيميل فقط (مفتاحها محفوظ في حسابك).' : 'الكود الخاص: خصوصية كاملة — تحتاج الكود مع الإيميل. بدونه لا يمكن فك بياناتك.' }),
    mode === 'code' ? h('button', { type: 'button', class: 'btn sm', onclick: async () => { const ok = await confirmSheet({ title: 'كود جديد؟', text: 'الكود القديم يتوقف عن العمل.', ok: 'إنشاء كود جديد', tone: 'primary' }); if (ok) Keys.useCode(); } }, 'إنشاء كود جديد') : null);
}

/* ================= تدفّق «نسيت كلمة المرور» ================= */
const Rec = { email: '', step: 1, sentAt: 0, timer: 0 };
function recSheet(title, kids) {
  let sheet = $('#rec-sheet');
  if (!sheet) { sheet = h('section', { class: 'sheet', id: 'rec-sheet', hidden: true, role: 'dialog', 'aria-modal': 'true' }); document.body.append(sheet); }
  sheet.replaceChildren(h('div', { class: 'grab' }),
    h('header', { class: 'sheet-head' }, h('h2', { text: title }), h('button', { type: 'button', class: 'icon-btn', 'aria-label': 'إغلاق', onclick: () => closeSheet(sheet) }, icon('x', { size: 20 }))),
    h('div', { class: 'sheet-body rec-body' }, ...kids.filter(Boolean)));
  if (!S.sheets.includes(sheet)) openSheet('#rec-sheet');
  return sheet;
}
const recSteps = (n) => h('div', { class: 'rec-steps' }, ...['إيميلك', 'الكود', 'كلمة جديدة'].map((l, i) => h('span', { class: i + 1 < n ? 'done' : i + 1 === n ? 'on' : '' }, h('b', { text: i + 1 < n ? '✓' : String(i + 1) }), l)));
const maskEmail = (e) => e.replace(/^(.{2})[^@]*(@.*)$/, '$1***$2');

async function forgotCloud() {
  if (!Cloud.enabled) return;
  Rec.email = ($('#c-email')?.value || '').trim() || Acc.list()[0]?.email || '';
  recEmailStep();
}
function recEmailStep() {
  const inp = h('input', { class: 'input ltr', type: 'email', inputmode: 'email', placeholder: 'البريد الإلكتروني', value: Rec.email, autocomplete: 'email' });
  const err = h('p', { class: 'error-text' });
  const btn = h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
    const e = inp.value.trim();
    if (!/^\S+@\S+\.\S+$/.test(e)) return (err.textContent = 'أدخل بريداً إلكترونياً صحيحاً');
    if (!navigator.onLine) return (err.textContent = 'تحتاج اتصال بالإنترنت');
    btn.disabled = true; err.textContent = '';
    try { await Cloud.resetPassword(e); Rec.email = e; Rec.sentAt = Date.now(); recCodeStep(); }
    catch (ex) { err.textContent = Cloud.msg(ex); btn.disabled = false; }
  } }, 'أرسل الكود');
  recSheet('نسيت كلمة المرور', [recSteps(1), h('p', { class: 'hint', text: 'نرسل لك كوداً من ٦ أرقام على إيميلك.' }), inp, err, btn]);
  setTimeout(() => inp.focus(), 250);
}
function recCodeStep() {
  const boxes = Array.from({ length: 6 }, () => h('input', { class: 'otp-in', inputmode: 'numeric', maxlength: 1, autocomplete: 'one-time-code' }));
  const err = h('p', { class: 'error-text' });
  const code = () => boxes.map((b) => b.value).join('');
  const verify = async () => {
    if (code().length < 6) return;
    boxes.forEach((b) => (b.disabled = true)); err.textContent = '';
    try {
      await Cloud.verifyRecovery(Rec.email, code());
      recPasswordStep();
    } catch (ex) { err.textContent = Cloud.msg(ex); boxes.forEach((b) => { b.disabled = false; b.value = ''; }); boxes[0].focus(); }
  };
  boxes.forEach((b, i) => {
    b.addEventListener('input', () => {
      const d = b.value.replace(/\D/g, '');
      if (d.length > 1) { d.slice(0, 6).split('').forEach((c, j) => { if (boxes[j]) boxes[j].value = c; }); boxes[Math.min(5, d.length - 1)].focus(); return verify(); }
      b.value = d;
      if (d && boxes[i + 1]) boxes[i + 1].focus();
      verify();
    });
    b.addEventListener('keydown', (e) => { if (e.key === 'Backspace' && !b.value && boxes[i - 1]) boxes[i - 1].focus(); });
  });
  const resend = h('button', { type: 'button', class: 'link-btn', disabled: true });
  const tick = () => {
    const left = Math.max(0, 60 - Math.floor((Date.now() - Rec.sentAt) / 1000));
    resend.disabled = left > 0;
    resend.textContent = left > 0 ? `ما وصلك؟ إعادة الإرسال بعد ${UI.n(left)} ث` : 'إعادة إرسال الكود';
    if (!left) clearInterval(Rec.timer);
  };
  resend.onclick = async () => { try { await Cloud.resetPassword(Rec.email); Rec.sentAt = Date.now(); clearInterval(Rec.timer); Rec.timer = setInterval(tick, 1000); tick(); toast('أرسلنا كوداً جديداً'); } catch (ex) { toast(Cloud.msg(ex), { type: 'error' }); } };
  clearInterval(Rec.timer); Rec.timer = setInterval(tick, 1000); tick();
  recSheet('نسيت كلمة المرور', [recSteps(2),
    h('p', { class: 'hint', text: `أرسلنا كوداً إلى ${maskEmail(Rec.email)} — تأكد من مجلد «الرسائل غير المرغوبة» إذا ما وصلك.` }),
    h('div', { class: 'otp-row ltr' }, ...boxes), err, resend,
    h('button', { type: 'button', class: 'link-btn', onclick: recEmailStep }, 'تغيير الإيميل')]);
  setTimeout(() => boxes[0].focus(), 250);
}
function recPasswordStep() {
  clearInterval(Rec.timer);
  const p1 = h('input', { class: 'input', type: 'password', placeholder: 'كلمة المرور الجديدة', autocomplete: 'new-password' });
  const p2 = h('input', { class: 'input', type: 'password', placeholder: 'تأكيد كلمة المرور', autocomplete: 'new-password' });
  const err = h('p', { class: 'error-text' });
  const btn = h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
    if (p1.value.length < 6) return (err.textContent = 'كلمة المرور ٦ أحرف على الأقل');
    if (p1.value !== p2.value) return (err.textContent = 'كلمتا المرور غير متطابقتين');
    btn.disabled = true; err.textContent = '';
    try { await recRestore(p1.value, null, err); } catch (ex) { err.textContent = Cloud.msg(ex); }
    btn.disabled = false;
  } }, 'حفظ وفتح حسابي');
  recSheet('كلمة مرور جديدة', [recSteps(3), h('p', { class: 'hint', text: 'بعدها ترجع مواقعك ومهامك وماليتك كما هي.' }), p1, p2, err, btn]);
  setTimeout(() => p1.focus(), 250);
}
/* إعادة تشفير البيانات بكلمة المرور الجديدة ثم فتح الحساب */
async function recRestore(pw, recoveryCode, errEl) {
  const user = await Cloud.user();
  if (!user) throw new Error('انتهت الجلسة — اطلب كوداً جديداً');
  const remote = await Cloud.pullVault();
  if (remote) {
    const esc = await Cloud.myKey().catch(() => null);
    let raw = null;
    if (esc?.mode === 'auto') raw = esc.k;
    else if (esc?.mode === 'code') {
      if (!recoveryCode) return recAskCode(pw);
      try { const { key } = await Core.codeKey(recoveryCode, esc.ck); raw = await Core.unwrapRaw(key, esc.wrap); }
      catch { throw new Error('كود الاسترجاع غير صحيح'); }
    }
    try {
      if (!raw) throw new Error('no-key');
      await Core.rekey(raw, remote, pw);
    } catch (e) {
      if (/كود الاسترجاع/.test(e.message)) throw e;
      return recNoKey(pw);
    }
  }
  await Cloud.updatePassword(pw).catch((e) => { if (!/different from the old/i.test(e.message || '')) throw e; });
  await finishRecovery(user, pw, !remote);
}
async function finishRecovery(user, pw, fresh) {
  await browser.storage.local.set({ meta: await Core.metaWith({ owner: user.id, project: Cloud.REF, email: Acc.norm(user.email) }) });
  closeAllSheets();
  await openCloudVault(pw, user, null, fresh);
  if (pref('biometric')) await Bio.refresh(pw);
  Acc.remember(user.email, {});
  Keys.sync();
  buzz('success');
  toast(fresh ? 'تم — حسابك جاهز بكلمة المرور الجديدة' : 'تم — رجعت بياناتك كاملة بكلمة المرور الجديدة ✓', { type: 'success', duration: 6000 });
}
function recAskCode(pw) {
  const inp = h('input', { class: 'input ltr rc-in', placeholder: 'XXXX-XXXX-XXXX-XXXX', autocapitalize: 'characters', autocomplete: 'off' });
  const err = h('p', { class: 'error-text' });
  const btn = h('button', { type: 'button', class: 'btn btn-primary btn-block', onclick: async () => {
    btn.disabled = true; err.textContent = '';
    try { await recRestore(pw, inp.value, err); } catch (ex) { err.textContent = Cloud.msg(ex); }
    btn.disabled = false;
  } }, 'استرجاع بياناتي');
  recSheet('كود الاسترجاع', [recSteps(3), h('p', { class: 'hint', text: 'اخترت «كود استرجاع خاص» — اكتب الكود اللي حفظته حتى نفك بياناتك.' }), inp, err, btn,
    h('button', { type: 'button', class: 'link-btn danger', onclick: () => recNoKey(pw, true) }, 'ضيّعت الكود')]);
  setTimeout(() => inp.focus(), 250);
}
async function recNoKey(pw, lostCode) {
  recSheet('ما قدرنا نفك بياناتك', [
    h('div', { class: 'note-box', text: lostCode ? 'بدون كود الاسترجاع لا يمكن فك بياناتك المشفّرة — هذا ما يحمي خصوصيتك.' : 'ما لقينا مفتاح استرجاع لبياناتك (فُعّل الاسترجاع بعد آخر تغيير لكلمة المرور).' }),
    h('p', { class: 'hint', text: 'إذا تذكّرت كلمة المرور القديمة ادخل بها. أو ابدأ من جديد: حسابك واشتراكاتك ونقاطك تبقى، لكن المواقع والمهام والمالية تبدأ فارغة.' }),
    h('button', { type: 'button', class: 'btn btn-block', onclick: () => { closeAllSheets(); } }, 'رجوع — أتذكّر كلمة المرور'),
    h('button', { type: 'button', class: 'btn btn-danger-ghost btn-block', onclick: async () => {
      const ok = await confirmSheet({ title: 'البدء من جديد؟', text: 'المواقع والمهام والمالية القديمة تُحذف نهائياً من الحساب.', ok: 'ابدأ من جديد', typeToConfirm: 'ابدأ' });
      if (!ok) return;
      try {
        const user = await Cloud.user();
        await Cloud.updatePassword(pw).catch((e) => { if (!/different from the old/i.test(e.message || '')) throw e; });
        await browser.storage.local.remove(['auth', 'vault', 'meta']);
        await finishRecovery(user, pw, true);
      } catch (ex) { toast(Cloud.msg(ex), { type: 'error' }); }
    } }, 'ابدأ من جديد'),
  ]);
}
