/* NOBLE — لوحة التحكم ← «📩 الدعم» (1.16)
 * رسائل المستخدمين للإدارة مع مرفقاتها (صور/فيديو) + الرد + الحالة + حذف المرفقات بقرارك
 * + تشغيل/إيقاف الزر للكل أو إخفاؤه عن مستخدمين محددين.
 */
'use strict';
const SUPA = { list: null, st: 'new', counts: {}, set: null, urls: new Map() };
const SUPA_CAT = { issue: ['🛠', 'مشكلة'], idea: ['💡', 'اقتراح'], billing: ['💳', 'الاشتراك'], question: ['❓', 'سؤال'], other: ['💬', 'غيره'] };
const SUPA_ST = { new: ['🆕', 'جديدة'], open: ['🔧', 'نشتغل عليها'], done: ['✅', 'انحلّت'] };

async function supaCounts() {
  if (!can('messages.send')) return;
  SUPA.counts = await Cloud.admin.supportCounts();
  const b = document.querySelector('#a-tabs [data-tab="support"]');
  if (b) { b.querySelector('.supa-badge')?.remove(); if (SUPA.counts.new > 0) b.append(h('em', { class: 'supa-badge num', text: UI.n(SUPA.counts.new) })); }
}
async function openSupportAdmin(force) {
  const box = $('#a-support');
  if (!box) return;
  if (!SUPA.list || force) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      [SUPA.list, SUPA.set] = await Promise.all([Cloud.admin.support(SUPA.st), Cloud.admin.supportSettings()]);
      await supaCounts();
    } catch (e) {
      const m = Cloud.msg(e);
      box.replaceChildren(h('p', { class: 'note-box', text: /function|schema|relation/i.test(m) ? 'شغّل ملف supabase/update-all.sql (كامل) في Supabase ← SQL Editor أولاً حتى يشتغل قسم الدعم.' : 'تعذّر التحميل: ' + m }));
      return;
    }
  }
  const S0 = SUPA.set || { enabled: true, blocked: [], max_day: 5 };
  const sw = h('input', { type: 'checkbox', checked: !!S0.enabled });
  sw.addEventListener('change', async () => { try { await Cloud.admin.supportSettingsSave({ ...S0, enabled: sw.checked, blocked: S0.blocked.map((b) => b.id) }); S0.enabled = sw.checked; toast(sw.checked ? 'زر «راسل الإدارة» ظاهر للمستخدمين ✓' : 'انخفى الزر عن الكل', { type: 'success' }); openSupportAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); sw.checked = !sw.checked; } });
  const ctl = h('div', { class: 'set-card supa-ctl' },
    h('div', { class: 'set-row' }, h('span', {}, h('strong', { text: '📩 زر «راسل الإدارة» في التطبيق' }), h('p', { class: 'hint', text: S0.enabled ? 'ظاهر في الرسائل والإعدادات' : 'مخفي عن كل المستخدمين' })), h('label', { class: 'switch' }, sw, h('span', { class: 'track' }))),
    h('div', { class: 'set-row supa-bl' }, h('span', {}, h('strong', { text: '🚫 مخفي عن' }), h('p', { class: 'hint', text: S0.blocked.length ? `${UI.n(S0.blocked.length)} مستخدم` : 'ولا أحد' })),
      h('button', { type: 'button', class: 'btn sm', onclick: () => supaBlockPick() }, '＋ اختر مستخدم')),
    S0.blocked.length ? h('div', { class: 'chips supa-blocked' }, ...S0.blocked.map((u) => h('span', { class: 'chip on' }, u.name || u.email, h('button', { type: 'button', class: 'supa-unb', 'aria-label': 'رجّعه', onclick: () => supaBlock(u.id, false) }, '✕')))) : null,
    h('div', { class: 'set-row' }, h('span', {}, h('strong', { text: '⏱ حد الرسائل لكل مستخدم باليوم' })), mkSeg([['3', '٣'], ['5', '٥'], ['10', '١٠'], ['20', '٢٠']], String(S0.max_day || 5), async (v) => { try { await Cloud.admin.supportSettingsSave({ ...S0, max_day: Number(v), blocked: S0.blocked.map((b) => b.id) }); S0.max_day = Number(v); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } })));
  const C = SUPA.counts || {};
  const chips = h('nav', { class: 'chips supa-f' }, ...[['new', 'جديدة', C.new], ['open', 'نشتغل عليها', C.open], ['done', 'انحلّت', C.done], ['all', 'الكل', C.all]].map(([k, l, n]) =>
    h('button', { type: 'button', class: `chip${SUPA.st === k ? ' on' : ''}`, onclick: () => { SUPA.st = k; openSupportAdmin(true); } }, l, n ? h('span', { class: 'count num', text: UI.n(n) }) : null)));
  const list = SUPA.list || [];
  box.replaceChildren(
    h('div', { class: 'set-row supa-h' }, h('h3', { class: 'set-title', text: '📩 رسائل المستخدمين' }), h('button', { type: 'button', class: 'btn sm', onclick: () => openSupportAdmin(true) }, '↻ تحديث')),
    ctl, chips,
    list.length ? h('div', { class: 'supa-list' }, ...list.map((t) => supaCard(t))) : h('div', { class: 'empty' }, h('b', { text: SUPA.st === 'new' ? 'ما فيه رسائل جديدة 🎉' : 'ما فيه رسائل هنا' }), h('small', { text: 'لما يرسل مستخدم مشكلة أو اقتراح تطلع لك هنا.' })));
  UI.digitize(box);
}
function supaCard(t) {
  const [ci, cl] = SUPA_CAT[t.cat] || SUPA_CAT.other, [si, sl] = SUPA_ST[t.status] || SUPA_ST.new;
  const nf = (t.files || []).length;
  return h('button', { type: 'button', class: `supa-card st-${t.status}`, onclick: () => supaOpen(t) },
    h('div', { class: 'supa-ch' }, h('b', { text: t.name || 'مستخدم' }), h('em', { class: `supa-st ${t.status}`, text: `${si} ${sl}` })),
    h('p', { text: t.body }),
    h('div', { class: 'supa-cf' }, h('span', { text: `${ci} ${cl}` }), nf ? h('span', { text: `📎 ${UI.n(nf)}` }) : t.files_deleted ? h('span', { class: 'supa-del', text: '📎 انحذفت' }) : null,
      t.meta?.version ? h('span', { class: 'ltr', text: 'v' + t.meta.version }) : null, t.reply ? h('span', { text: '💬 تم الرد' }) : null,
      h('small', { text: UI.relTime(new Date(t.created_at).getTime()) })));
}
async function supaUrl(path) {
  if (SUPA.urls.has(path)) return SUPA.urls.get(path);
  const u = await Cloud.admin.supportFile(path);
  SUPA.urls.set(path, u);
  return u;
}
function supaOpen(t) {
  const [ci, cl] = SUPA_CAT[t.cat] || SUPA_CAT.other;
  const M = t.meta || {};
  const metaRows = [['التطبيق', M.app], ['النسخة', M.version], ['النظام', M.platform === 'android' ? 'تطبيق أندرويد' : M.platform === 'web' ? 'متصفح' : M.platform], ['الإصدار', M.os], ['الجهاز', M.device], ['الشاشة', M.screen], ['القسم وقتها', M.tab], ['متصل بالنت', M.online === false ? 'لا' : M.online ? 'نعم' : '']].filter(([, v]) => v);
  const files = h('div', { class: 'supa-files' });
  (t.files || []).forEach((f) => {
    const cell = h('div', { class: 'supa-file' }, h('small', { text: 'يحمّل…' }));
    files.append(cell);
    supaUrl(f.path).then((u) => {
      cell.replaceChildren(f.kind === 'video' ? h('video', { src: u, controls: '', playsinline: '', preload: 'metadata' }) : h('img', { src: u, alt: '', onclick: () => window.open(u, '_blank', 'noopener') }),
        h('a', { class: 'supa-dl', href: u, target: '_blank', rel: 'noopener', download: f.name || '' }, '⬇'));
    }).catch((e) => cell.replaceChildren(h('small', { class: 'supa-err', text: 'تعذّر: ' + Cloud.msg(e) })));
  });
  const reply = h('textarea', { class: 'input textarea', rows: 3, maxlength: 2000, placeholder: 'ردّك يوصله في الرسائل مع إشعار…' });
  const setSt = async (st) => { try { await Cloud.admin.supportSet(t.id, st); t.status = st; toast('انحفظ ✓', { type: 'success' }); supaOpen(t); openSupportAdmin(true); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } };
  mkSheet(`${ci} ${cl} — ${t.name || 'مستخدم'}`, [
    h('div', { class: 'supa-who' }, h('b', { text: t.name || 'مستخدم' }), h('small', { class: 'ltr', text: t.email || '' }), h('small', { text: `${UI.n(t.count || 1)} رسالة منه · ${new Date(t.created_at).toLocaleString('ar-SA')}` })),
    h('div', { class: 'supa-body' }, h('p', { text: t.body })),
    (t.files || []).length ? h('div', {}, h('small', { class: 'hint', text: `📎 المرفقات (${UI.n(t.files.length)}) — خاصة، ما يشوفها إلا فريق الإدارة` }), files)
      : t.files_deleted ? h('p', { class: 'hint', text: '📎 المرفقات انحذفت من السيرفر' }) : null,
    metaRows.length ? h('details', { class: 'supa-meta' }, h('summary', { text: '📱 معلومات الجهاز' }), ...metaRows.map(([k, v]) => h('div', { class: 'supa-mr' }, h('small', { text: k }), h('b', { class: 'ltr', text: String(v) })))) : null,
    h('div', { class: 'field' }, h('span', { text: 'الحالة' }), h('div', { class: 'chips' }, ...Object.entries(SUPA_ST).map(([k, [i, l]]) => h('button', { type: 'button', class: `chip${t.status === k ? ' on' : ''}`, onclick: () => setSt(k) }, `${i} ${l}`)))),
    t.reply ? h('div', { class: 'supa-reply' }, h('small', { text: `💬 ردّك (${UI.relTime(new Date(t.replied_at).getTime())})` }), h('p', { text: t.reply })) : null,
    h('div', { class: 'field' }, h('span', { text: t.reply ? 'رد جديد' : 'ردّ على المستخدم' }), reply),
    h('div', { class: 'supa-danger' },
      (t.files || []).length ? h('button', { type: 'button', class: 'btn sm', onclick: async (e) => {
        if (!confirm('حذف المرفقات من السيرفر نهائياً؟ الرسالة تبقى.')) return;
        e.currentTarget.disabled = true;
        try { const n = await Cloud.admin.supportDelete(t.id, true); t.files = []; t.files_deleted = true; toast(`انحذف ${UI.n(n)} مرفق ✓`, { type: 'success' }); supaOpen(t); openSupportAdmin(true); } catch (er) { toast(Cloud.msg(er), { type: 'error' }); }
      } }, '🗑 احذف المرفقات') : null,
      h('button', { type: 'button', class: 'btn sm', onclick: () => supaBlock(t.user_id, true, t.name) }, '🚫 أخفِ الزر عنه'),
      h('button', { type: 'button', class: 'btn sm danger', onclick: async () => {
        if (!confirm('حذف الرسالة ومرفقاتها نهائياً؟')) return;
        try { await Cloud.admin.supportDelete(t.id, false); closeSheet($('#mk-sheet')); toast('انحذفت ✓', { type: 'success' }); openSupportAdmin(true); } catch (er) { toast(Cloud.msg(er), { type: 'error' }); }
      } }, '🗑 احذف الرسالة')),
  ], [h('button', { type: 'button', class: 'btn btn-primary', onclick: async (e) => {
    const txt = reply.value.trim();
    if (txt.length < 2) return toast('اكتب ردّك');
    const b = e.currentTarget; b.disabled = true;
    try {
      await Cloud.admin.supportSet(t.id, t.status === 'new' ? 'open' : null, txt);
      try { await Cloud.admin.sendMessage(t.user_id, '💬 رد الإدارة على رسالتك', txt, 'noble:support', 'افتح المحادثة', { icon: '💬' }); } catch { /* الرد محفوظ حتى لو فشل الإشعار */ }
      t.reply = txt; t.replied_at = new Date().toISOString(); if (t.status === 'new') t.status = 'open';
      toast('وصل ردّك ✓', { type: 'success' }); supaOpen(t); openSupportAdmin(true);
    } catch (er) { toast(Cloud.msg(er), { type: 'error' }); b.disabled = false; }
  } }, 'أرسل الرد ✈️')]);
}
async function supaBlock(id, on, name) {
  const S0 = SUPA.set || { enabled: true, blocked: [], max_day: 5 };
  const ids = new Set(S0.blocked.map((b) => b.id));
  if (on) { if (!confirm(`إخفاء زر «راسل الإدارة» عن ${name || 'هذا المستخدم'}؟`)) return; ids.add(id); } else ids.delete(id);
  try {
    await Cloud.admin.supportSettingsSave({ enabled: S0.enabled, max_day: S0.max_day, blocked: [...ids] });
    SUPA.set = await Cloud.admin.supportSettings();
    toast(on ? 'انخفى الزر عنه ✓' : 'رجع له الزر ✓', { type: 'success' });
    openSupportAdmin();
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
async function supaBlockPick() {
  try { if (!A.users?.length && typeof loadUsers === 'function') await loadUsers(); } catch { /* لا شيء */ }
  const q = h('input', { class: 'input', placeholder: 'ابحث بالاسم أو الإيميل…' });
  const out = h('div', { class: 'supa-pick' });
  const blocked = new Set((SUPA.set?.blocked || []).map((b) => b.id));
  const paint = () => {
    const s = q.value.trim().toLowerCase();
    const rows = (A.users || []).filter((u) => u.id !== A.me?.id && !blocked.has(u.id) && (!s || nameOf(u).toLowerCase().includes(s) || (u.email || '').toLowerCase().includes(s))).slice(0, 30);
    RC(out, ...(rows.length ? rows.map((u) => h('button', { type: 'button', class: 'supa-pr', onclick: () => { closeSheet($('#mk-sheet')); supaBlock(u.id, true, nameOf(u)); } }, h('b', { text: nameOf(u) }), h('small', { class: 'ltr', text: u.email || '' }))) : [h('p', { class: 'hint', text: 'ما لقيت أحد' })]));
  };
  q.addEventListener('input', paint);
  mkSheet('🚫 أخفِ الزر عن مستخدم', [q, out]);
  paint();
}
var RC = typeof RC === 'function' ? RC : (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
