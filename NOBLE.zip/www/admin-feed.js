/* NOBLE — لوحة التحكم ← اكتشف (1.15): الستوري والمنشورات والتعليقات
 * الستوري: صورة أو فيديو بمدة (٢٤ ساعة، ٣ أيام، أسبوع، تاريخ) — بعدها تنحذف تلقائياً من السيرفر. «المميزة» دائمة.
 * المنشورات: صور كاروسيل، فيديو، استفتاء، نص. التعليقات ما تظهر إلا بعد موافقتك.
 */
'use strict';
const FA = { items: null, meta: {}, pending: 0, sub: 'stories', cst: 'pending', comments: null };
const FA_DUR = [['24h', '٢٤ ساعة', 1], ['3d', '٣ أيام', 3], ['7d', 'أسبوع', 7], ['date', 'تاريخ معيّن', 0], ['hl', '⭐ مميزة دائمة', 0]];
const faUntil = (it) => it.highlight ? '⭐ مميزة دائمة' : !it.expires_at ? 'دائم' : new Date(it.expires_at) <= new Date() ? '⛔ منتهية' : `تنتهي ${UI.relTime(new Date(it.expires_at).getTime())}`;
/* مفتاح تشغيل بدون ما يأثر على «تعديلات غير منشورة» في السوق */
function faSw(obj, key, label, sub, onChange) {
  const i = h('input', { type: 'checkbox', checked: obj[key] !== false });
  i.addEventListener('change', () => { obj[key] = i.checked; onChange?.(i.checked); });
  return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, i, h('span', { class: 'track' })));
}
/* حقل بعنوان — div مو label (الأزرار داخل label تنضغط غلط) */
const faFld = (label, el, hint) => h('div', { class: 'field' }, h('span', { text: label }), el, hint ? h('small', { class: 'hint', text: hint }) : null);
const faThumb = (it) => { const m = it.data?.media?.[0]; return m?.thumb || (m?.kind === 'image' ? m.url : ''); };

async function openFeedAdmin(force) {
  const box = $('#a-feed');
  if (!FA.items || force) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      await faCleanup();
      const r = await Cloud.admin.feed();
      FA.items = r.items || []; FA.meta = r.meta || {}; FA.pending = Number(r.pending) || 0;
    } catch (e) {
      const msg = Cloud.msg(e);
      box.replaceChildren(h('div', { class: 'note-box' }, h('b', { text: /function|schema|relation/i.test(msg) ? 'قاعدة البيانات تحتاج تحديث حتى يشتغل «اكتشف»' : 'تعذّر التحميل' }),
        h('p', { text: /function|schema|relation/i.test(msg) ? 'افتح Supabase ← SQL Editor ← الصق محتوى ملف supabase/update-all.sql كامل ← Run. الملف آمن لو تشغّله أكثر من مرة ويحدّث كل الأقسام.' : msg }),
        h('small', { class: 'hint', dir: 'ltr', text: msg })));
      return;
    }
  }
  renderFeedAdmin();
}
/* الستوري المنتهية: نحذف ملفاتها من Storage ثم نحذفها (ما تتراكم على السيرفر) */
async function faCleanup() {
  try {
    const old = await Cloud.admin.feedExpired();
    if (!old.length) return;
    let files = 0;
    for (const it of old) {
      const urls = (it.data?.media || []).flatMap((m) => [m.url, m.thumb]).filter(Boolean);
      try { files += await Cloud.admin.storageRemove(urls); } catch { /* نكمل */ }
      await Cloud.admin.feedDelete(it.id);
    }
    toast(`🧹 انحذفت ${UI.n(old.length)} ستوري منتهية${files ? ` (${UI.n(files)} ملف من السيرفر)` : ''}`, { type: 'success', duration: 4500 });
  } catch { /* قبل 1.15 */ }
}

function renderFeedAdmin() {
  const box = $('#a-feed');
  const st = FA.items.filter((x) => x.kind === 'story'), po = FA.items.filter((x) => x.kind === 'post');
  const nav = h('nav', { class: 'chips ga-nav' }, ...[['stories', `📸 الستوري ${UI.n(st.length)}`], ['posts', `🗂️ المنشورات ${UI.n(po.length)}`], ['comments', `💬 التعليقات${FA.pending ? ` · ${UI.n(FA.pending)} تنتظر` : ''}`], ['settings', '⚙️ الإعدادات']]
    .map(([id, l]) => h('button', { type: 'button', class: `chip${FA.sub === id ? ' on' : ''}`, onclick: () => { FA.sub = id; renderFeedAdmin(); } }, l)));
  const body = h('div', { class: 'fa-body' });
  box.replaceChildren(
    h('section', { class: 'a-hero' }, h('div', {}, h('h2', { text: '📱 اكتشف والستوري' }),
      h('p', { text: 'ستوري تظهر أعلى «يومي» و«اكتشف» بمدة تختارها وبعدها تنحذف من السيرفر، ومنشورات تفاعلية (صور، فيديو، استفتاء). التعليقات ما تظهر إلا بعد موافقتك.' }))),
    nav, body);
  if (FA.sub === 'stories') faList(body, st, 'story');
  else if (FA.sub === 'posts') faList(body, po, 'post');
  else if (FA.sub === 'comments') faComments(body);
  else faSettings(body);
  UI.digitize(box);
}

function faList(body, list, kind) {
  const add = h('button', { type: 'button', class: 'btn btn-primary', onclick: () => faEdit(null, kind) }, icon('plus', { size: 16 }), kind === 'story' ? 'ستوري جديدة' : 'منشور جديد');
  const row = (it) => {
    const d = it.data || {}, th = faThumb(it);
    const tally = Object.values(it.tally || {}).reduce((a, b) => a + Number(b), 0);
    const sw = h('input', { type: 'checkbox', checked: it.active });
    sw.addEventListener('change', async () => { try { await Cloud.admin.feedSave({ ...it, active: sw.checked }); it.active = sw.checked; toast(sw.checked ? 'ظاهر ✓' : 'مخفي', { type: 'success' }); } catch (e) { sw.checked = !sw.checked; toast(Cloud.msg(e), { type: 'error' }); } });
    return h('div', { class: `fa-row${it.active ? '' : ' off'}` },
      h('span', { class: 'fa-th', style: th ? { backgroundImage: `url("${th}")` } : null }, th ? null : h('b', { text: { video: '🎬', poll: '📊', text: '✍️', carousel: '🖼️', image: '🖼️' }[d.type] || '•' })),
      h('div', { class: 'fa-c' }, h('b', { text: d.caption || d.poll?.q || (d.type === 'video' ? 'فيديو' : 'بدون وصف') }),
        h('small', { text: [faUntil(it), `👁 ${UI.n(it.views || 0)}`, `♥ ${UI.n(it.likes || 0)}`, kind === 'post' ? `💬 ${UI.n(it.comments || 0)}${it.pending ? ` (+${UI.n(it.pending)} تنتظر)` : ''}` : '', d.type === 'poll' ? `📊 ${UI.n(tally)} صوت` : ''].filter(Boolean).join(' · ') })),
      h('label', { class: 'switch' }, sw, h('span', { class: 'track' })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'تعديل', onclick: () => faEdit(it, kind) }, icon('edit', { size: 16 })),
      h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: async () => {
        if (!(await confirmSheet({ title: 'حذف نهائي؟', text: 'ينحذف من التطبيق ومن السيرفر (الصور والفيديو).', ok: 'حذف' }))) return;
        try { const dd = await Cloud.admin.feedDelete(it.id); await Cloud.admin.storageRemove((dd?.media || []).flatMap((m) => [m.url, m.thumb])).catch(() => 0); toast('انحذف ✓', { type: 'success' }); openFeedAdmin(true); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
      } }, icon('trash', { size: 16 })));
  };
  body.replaceChildren(h('div', { class: 'fa-top' }, add, h('small', { class: 'hint', text: kind === 'story' ? 'الستوري العادية تنعرض كلها في دائرة NOBLE بالترتيب، و«المميزة» كل وحدة في دائرة دائمة.' : 'المنشورات تظهر في قسم «اكتشف» من الأحدث.' })),
    list.length ? h('div', { class: 'fa-list' }, ...list.map(row)) : h('p', { class: 'hint', text: kind === 'story' ? 'ما فيه ستوري — أضف أول وحدة 👆' : 'ما فيه منشورات للحين.' }));
}

/* ضغط الفيديو على الجهاز قبل الرفع (٧٢٠ بكسل) — يوفّر مساحة السيرفر والتحميل */
async function faCompress(file, onP) {
  if (!file.type.startsWith('video/') || typeof MediaRecorder === 'undefined') return file;
  const url = URL.createObjectURL(file);
  const v = h('video', { src: url, playsinline: true, preload: 'auto' });
  v.muted = true;
  await new Promise((res, rej) => { v.onloadedmetadata = res; v.onerror = rej; });
  const max = 1280, sc = Math.min(1, max / Math.max(v.videoWidth, v.videoHeight));
  const cv = h('canvas'); cv.width = Math.round(v.videoWidth * sc / 2) * 2; cv.height = Math.round(v.videoHeight * sc / 2) * 2;
  const c = cv.getContext('2d');
  const stream = cv.captureStream(30);
  try { const a = v.captureStream ? v.captureStream() : v.mozCaptureStream?.(); a?.getAudioTracks().forEach((t) => stream.addTrack(t)); v.muted = false; v.volume = 0.0001; } catch { /* بدون صوت */ }
  const type = ['video/mp4;codecs=avc1', 'video/webm;codecs=vp9,opus', 'video/webm'].find((t) => MediaRecorder.isTypeSupported(t)) || '';
  const rec = new MediaRecorder(stream, { mimeType: type, videoBitsPerSecond: 2.2e6, audioBitsPerSecond: 96000 });
  const chunks = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const done = new Promise((res) => { rec.onstop = res; });
  rec.start(500);
  await v.play();
  const draw = () => { c.drawImage(v, 0, 0, cv.width, cv.height); onP?.(v.currentTime / (v.duration || 1)); if (!v.ended && !v.paused) requestAnimationFrame(draw); else rec.stop(); };
  draw();
  v.onended = () => { if (rec.state !== 'inactive') rec.stop(); };
  await done;
  URL.revokeObjectURL(url);
  const out = new Blob(chunks, { type: (type || 'video/webm').split(';')[0] });
  return out.size && out.size < file.size ? new File([out], file.name.replace(/\.\w+$/, '') + (/mp4/.test(type) ? '.mp4' : '.webm'), { type: out.type }) : file;
}
/* لقطة من الفيديو كصورة مصغّرة للدائرة */
async function faVideoThumb(file) {
  try {
    const url = URL.createObjectURL(file);
    const v = h('video', { src: url, muted: true, playsinline: true, preload: 'auto' });
    await new Promise((res, rej) => { v.onloadeddata = res; v.onerror = rej; });
    v.currentTime = Math.min(1, (v.duration || 2) / 3);
    await new Promise((res) => { v.onseeked = res; setTimeout(res, 1500); });
    const sc = Math.min(1, 360 / Math.max(v.videoWidth, v.videoHeight));
    const cv = h('canvas'); cv.width = Math.round(v.videoWidth * sc); cv.height = Math.round(v.videoHeight * sc);
    cv.getContext('2d').drawImage(v, 0, 0, cv.width, cv.height);
    URL.revokeObjectURL(url);
    const b = await new Promise((res) => cv.toBlob(res, 'image/jpeg', 0.8));
    return b ? new File([b], 'thumb.jpg', { type: 'image/jpeg' }) : null;
  } catch { return null; }
}

function faEdit(it, kind) {
  const d = JSON.parse(JSON.stringify(it?.data || { type: kind === 'story' ? 'image' : 'carousel', media: [], caption: '', link: { url: '', label: '' } }));
  d.link = d.link || { url: '', label: '' };
  const o = { id: it?.id || null, kind, highlight: !!it?.highlight, expires_at: it?.expires_at || null, active: it?.active !== false, sort: it?.sort || 0 };
  let dur = it ? (o.highlight ? 'hl' : o.expires_at ? 'date' : kind === 'story' ? '24h' : 'none') : kind === 'story' ? '24h' : 'none';
  let compress = true, busy = false;
  const box = h('div', { class: 'fa-ed' });
  const paint = () => {
    const types = kind === 'story' ? [['image', '🖼️ صورة'], ['video', '🎬 فيديو'], ['text', '✍️ نص']] : [['carousel', '🖼️ صور'], ['video', '🎬 فيديو'], ['poll', '📊 استفتاء'], ['text', '✍️ نص']];
    const typeSeg = mkSeg(types, d.type, (v) => { d.type = v; if (v === 'poll' && !d.poll) d.poll = { q: '', options: ['', ''] }; paint(); });
    const file = h('input', { type: 'file', accept: d.type === 'video' ? 'video/*' : 'image/*', multiple: d.type === 'carousel', hidden: true });
    file.addEventListener('change', async () => {
      const files = [...file.files].slice(0, d.type === 'carousel' ? 10 : 1);
      if (!files.length) return;
      busy = true; const st = box.querySelector('.fa-up-st');
      try {
        if (d.type !== 'carousel') d.media = [];
        for (const [k, f0] of files.entries()) {
          let f = f0;
          if (f.type.startsWith('video/') && compress && f.size > 3e6) { st.textContent = '⚙️ يضغط الفيديو… ٠٪'; f = await faCompress(f, (p) => { st.textContent = `⚙️ يضغط الفيديو… ${UI.n(Math.round(p * 100))}٪`; }); }
          if (f.size > 45e6) throw new Error('الملف أكبر من ٤٥ ميجا — قصّره أو فعّل الضغط');
          st.textContent = `⬆️ يرفع ${files.length > 1 ? `${UI.n(k + 1)}/${UI.n(files.length)}` : ''}… (${(f.size / 1e6).toFixed(1)} ميجا)`;
          const url = await Cloud.admin.designUpload(f, 'feed');
          const m = { url, kind: f.type.startsWith('video/') ? 'video' : 'image' };
          if (m.kind === 'video') { const th = await faVideoThumb(f0); if (th) m.thumb = await Cloud.admin.designUpload(th, 'feed'); }
          d.media.push(m);
        }
        st.textContent = '✓ انرفع';
      } catch (e) { st.textContent = '✕ ' + (Cloud.msg?.(e) || e.message); }
      busy = false; paint();
    });
    const durSeg = mkSeg(kind === 'story' ? FA_DUR.map(([k, l]) => [k, l]) : [['none', 'دائم'], ['3d', '٣ أيام'], ['7d', 'أسبوع'], ['date', 'تاريخ معيّن']], dur, (v) => { dur = v; paint(); });
    const dt = h('input', { type: 'datetime-local', class: 'input ltr', value: o.expires_at ? toLocalDT(o.expires_at) : toLocalDT(new Date(Date.now() + 2 * 864e5).toISOString()) });
    dt.addEventListener('change', () => { o.expires_at = new Date(dt.value).toISOString(); });
    const cap = h('textarea', { class: 'input textarea', rows: 3, maxlength: 1200, placeholder: d.type === 'text' ? 'النص اللي يظهر' : 'وصف (اختياري)' });
    cap.value = d.caption || ''; cap.addEventListener('input', () => { d.caption = cap.value; });
    const lu = h('input', { class: 'input ltr', placeholder: 'https://… أو noble:offer?code=X', value: d.link.url || '' }); lu.addEventListener('input', () => { d.link.url = lu.value.trim(); });
    const ll = h('input', { class: 'input', placeholder: 'اعرف أكثر', maxlength: 24, value: d.link.label || '' }); ll.addEventListener('input', () => { d.link.label = ll.value.trim(); });
    const ring = h('input', { class: 'input', placeholder: 'اسم الدائرة (مثلاً: عروضنا)', maxlength: 14, value: d.ring || '' }); ring.addEventListener('input', () => { d.ring = ring.value.trim(); });
    const pollBox = d.type === 'poll' ? (() => {
      const q = h('input', { class: 'input', placeholder: 'السؤال', maxlength: 120, value: d.poll.q || '' }); q.addEventListener('input', () => { d.poll.q = q.value; });
      return h('div', { class: 'fa-poll' }, q, ...d.poll.options.map((op, k) => { const i = h('input', { class: 'input', placeholder: `خيار ${UI.n(k + 1)}`, maxlength: 60, value: op }); i.addEventListener('input', () => { d.poll.options[k] = i.value; }); return h('div', { class: 'fa-opt' }, i, d.poll.options.length > 2 ? h('button', { type: 'button', class: 'icon-btn sm-ic', onclick: () => { d.poll.options.splice(k, 1); paint(); } }, '✕') : null); }),
        d.poll.options.length < 6 ? h('button', { type: 'button', class: 'btn sm', onclick: () => { d.poll.options.push(''); paint(); } }, '＋ خيار') : null);
    })() : null;
    const BGS = ['linear-gradient(160deg,#0E1B55,#2E5BFF 60%,#8B45F0)', 'linear-gradient(160deg,#200a12,#E5484D 60%,#FFB43D)', 'linear-gradient(160deg,#062a2a,#0FA3A3 55%,#B6F0D8)', 'linear-gradient(160deg,#1a0b33,#8B45F0 55%,#C8509C)', 'linear-gradient(160deg,#0b2a12,#16A34A 55%,#FDE047)', '#111827'];
    box.replaceChildren(...[
      faFld('النوع', typeSeg),
      ['image', 'video', 'carousel'].includes(d.type) ? h('div', { class: 'fa-up' },
        h('div', { class: 'fa-media' }, ...d.media.map((m, k) => h('span', { class: 'fa-mi', style: { backgroundImage: `url("${m.thumb || (m.kind === 'image' ? m.url : '')}")` } }, m.kind === 'video' && !m.thumb ? '🎬' : null,
          h('button', { type: 'button', class: 'fa-mx', 'aria-label': 'شيل', onclick: () => { d.media.splice(k, 1); paint(); } }, '✕')))),
        h('button', { type: 'button', class: 'btn', disabled: busy, onclick: () => file.click() }, d.type === 'video' ? '🎬 اختر فيديو' : d.type === 'carousel' ? '🖼️ اختر صور (حتى ١٠)' : '🖼️ اختر صورة'),
        d.type === 'video' ? faSw({ c: compress }, 'c', 'ضغط الفيديو قبل الرفع (أنصح فيه)', '٧٢٠p — حجم أقل بكثير ويوفّر سعة السيرفر', (v) => { compress = v; }) : null,
        h('small', { class: 'fa-up-st hint' }), file) : null,
      d.type === 'text' ? faFld('الخلفية', h('div', { class: 'fa-bgs' }, ...BGS.map((bg) => h('button', { type: 'button', class: `fa-bg${(d.bg || BGS[0]) === bg ? ' on' : ''}`, style: { background: bg }, onclick: () => { d.bg = bg; paint(); } })))) : null,
      pollBox,
      faFld(d.type === 'text' ? 'النص' : 'الوصف', cap),
      h('div', { class: 'row-2' }, faFld('رابط زر (اختياري)', lu), faFld('نص الزر', ll)),
      faFld(kind === 'story' ? 'مدة الظهور — وبعدها تنحذف من السيرفر' : 'مدة الظهور', durSeg),
      dur === 'date' ? faFld('ينتهي في', dt) : null,
      dur === 'hl' ? faFld('اسم الدائرة المميزة', ring) : null].filter(Boolean));
    UI.digitize(box);
  };
  paint();
  const save = async (e) => {
    if (busy) return toast('انتظر يخلص الرفع');
    if (['image', 'video', 'carousel'].includes(d.type) && !d.media.length) return toast('اختر صورة أو فيديو');
    if (d.type === 'text' && !d.caption?.trim()) return toast('اكتب النص');
    if (d.type === 'poll' && (!d.poll.q?.trim() || d.poll.options.filter((x) => x.trim()).length < 2)) return toast('اكتب السؤال وخيارين على الأقل');
    if (d.type === 'poll') d.poll.options = d.poll.options.map((x) => x.trim()).filter(Boolean);
    const days = { '24h': 1, '3d': 3, '7d': 7 }[dur];
    o.highlight = dur === 'hl';
    o.expires_at = days ? new Date(Date.now() + days * 864e5).toISOString() : dur === 'date' ? (o.expires_at || new Date(Date.now() + 2 * 864e5).toISOString()) : null;
    if (it && days && it.expires_at && it.created_at) o.expires_at = new Date(new Date(it.created_at).getTime() + days * 864e5).toISOString();
    const b = e.currentTarget; b.disabled = true;
    try { await Cloud.admin.feedSave({ ...o, data: d }); closeSheet($('#mk-sheet')); toast(it ? 'حُفظ ✓' : kind === 'story' ? 'نُشرت الستوري ✓ — توصل للكل مباشرة' : 'نُشر المنشور ✓', { type: 'success' }); openFeedAdmin(true); }
    catch (er) { toast(Cloud.msg(er), { type: 'error' }); b.disabled = false; }
  };
  mkSheet(it ? 'تعديل' : kind === 'story' ? '📸 ستوري جديدة' : '🗂️ منشور جديد', [box], [h('button', { type: 'button', class: 'btn btn-primary', onclick: save }, it ? 'حفظ' : 'نشر')]);
}

async function faComments(body) {
  body.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
  let rows = [];
  try { rows = await Cloud.admin.feedComments(FA.cst); } catch (e) { body.replaceChildren(h('p', { class: 'note-box', text: Cloud.msg(e) })); return; }
  const set = async (c, st) => {
    try { await Cloud.admin.feedCommentSet(c.id, st); if (FA.cst === 'pending' && st !== 'pending') FA.pending = Math.max(0, FA.pending - 1); faComments(body); toast({ approved: 'ظهر للكل ✓', rejected: 'انرفض', delete: 'انحذف' }[st] || 'تم', { type: 'success' }); renderFeedNavCount(); }
    catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
  };
  body.replaceChildren(
    h('div', { class: 'fa-top' }, mkSeg([['pending', '⏳ تنتظر'], ['approved', '✓ ظاهرة'], ['rejected', '✕ مرفوضة']], FA.cst, (v) => { FA.cst = v; faComments(body); }),
      FA.cst === 'pending' && rows.length > 1 ? h('button', { type: 'button', class: 'btn sm', onclick: async () => { for (const c of rows) await Cloud.admin.feedCommentSet(c.id, 'approved').catch(() => {}); FA.pending = 0; toast('ظهرت كلها ✓', { type: 'success' }); faComments(body); } }, `✓ وافق على الكل (${UI.n(rows.length)})`) : null),
    rows.length ? h('div', { class: 'fa-list' }, ...rows.map((c) => h('div', { class: 'fa-cm' },
      h('div', { class: 'fa-c' }, h('b', { text: c.name || 'مستخدم' }), h('p', { text: c.body }), h('small', { text: `على: ${c.caption || 'منشور'} · ${UI.relTime(new Date(c.created_at).getTime())}` })),
      h('div', { class: 'fa-cma' },
        c.status !== 'approved' ? h('button', { type: 'button', class: 'btn sm btn-primary', onclick: () => set(c, 'approved') }, '✓ إظهار') : null,
        c.status !== 'rejected' ? h('button', { type: 'button', class: 'btn sm', onclick: () => set(c, 'rejected') }, 'رفض') : null,
        h('button', { type: 'button', class: 'icon-btn sm-ic', 'aria-label': 'حذف', onclick: () => set(c, 'delete') }, icon('trash', { size: 15 })))))) : h('p', { class: 'hint', text: FA.cst === 'pending' ? 'ما فيه تعليقات تنتظر 👌' : 'لا يوجد.' }));
  UI.digitize(body);
}
function renderFeedNavCount() { const c = [...document.querySelectorAll('#a-feed .ga-nav .chip')][2]; if (c) c.textContent = `💬 التعليقات${FA.pending ? ` · ${UI.n(FA.pending)} تنتظر` : ''}`; }

function faSettings(body) {
  const m = { title: 'اكتشف', sub: 'جديد NOBLE وأفكار تهمك', author: 'NOBLE', storiesTitle: 'NOBLE', comments: true, storiesOn: true, storiesToday: true, ...(FA.meta || {}) };
  const inp = (k, ph, max = 60) => { const i = h('input', { class: 'input', value: m[k] || '', placeholder: ph, maxlength: max }); i.addEventListener('input', () => { m[k] = i.value.trim(); }); return i; };
  body.replaceChildren(h('div', { class: 'set-card mk-card' },
    h('div', { class: 'row-2' }, faFld('عنوان القسم', inp('title', 'اكتشف', 24)), faFld('السطر تحت العنوان', inp('sub', 'جديد NOBLE وأفكار تهمك'))),
    h('div', { class: 'row-2' }, faFld('اسم الناشر على المنشورات', inp('author', 'NOBLE', 24)), faFld('اسم دائرة الستوري اليومية', inp('storiesTitle', 'NOBLE', 14))),
    faSw(m, 'storiesOn', 'الستوري ظاهرة', 'إيقافها يخفي كل الدوائر'),
    faSw(m, 'storiesToday', 'دوائر الستوري أعلى «يومي»', 'أول شي يشوفه المستخدم لما يفتح التطبيق'),
    faSw(m, 'comments', 'التعليقات مفتوحة', 'كل تعليق ينتظر موافقتك قبل ما يظهر'),
    h('p', { class: 'hint', text: 'قسم «اكتشف» تقدر ترتّبه أو تخفيه من التطبيقات ← الأقسام: الترتيب والظهور.' }),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => { try { await Cloud.admin.feedMeta(m); FA.meta = m; toast('حُفظ ✓ — يوصل للكل مباشرة', { type: 'success' }); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, 'حفظ')));
}
