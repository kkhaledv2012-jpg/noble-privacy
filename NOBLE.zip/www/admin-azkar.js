/* NOBLE — لوحة التحكم ← الأذكار (1.14)
 * إضافة وتعديل الأذكار والأدعية بمصادرها، التصنيف، التثبيت لتواريخ (رمضان، الجمعة…)، إعدادات الذكر عند الفتح والتذكير.
 */
'use strict';
var RC = (el, ...k) => el.replaceChildren(...k.filter((x) => x != null && x !== false));
const AZA = { items: null, meta: null, dirty: false, q: '', cat: '', sub: 'content' };
async function openAzkarAdmin(force) {
  const box = $('#a-azkar');
  if (!AZA.items || force) {
    box.replaceChildren(h('p', { class: 'hint', text: 'جارٍ التحميل…' }));
    try {
      const [items, pub] = await Promise.all([Cloud.admin.azkar(), Cloud.azkarList()]);
      AZA.items = items || []; AZA.meta = (pub && pub.meta) || {};
    } catch (e) {
      const msg = Cloud.msg(e);
      box.replaceChildren(h('p', { class: 'note-box', text: /function|schema|relation/i.test(msg) ? 'شغّل ملف supabase/update-all.sql (كامل) في Supabase ← SQL Editor أولاً حتى يشتغل قسم الأذكار.' : 'تعذّر التحميل: ' + msg }));
      return;
    }
  }
  renderAzkarAdmin();
}
const azaChanged = () => { AZA.dirty = true; const b = $('#aza-save'); if (b) b.disabled = false; };
function renderAzkarAdmin() {
  const m = (AZA.meta = AzkarKit.cfg(AZA.meta || {}));
  const T = m.toast, R = m.remind;
  const sel = (val, opts, on) => { const s = h('select', { class: 'input' }, ...opts.map(([v, l]) => h('option', { value: String(v), text: l }))); s.value = String(val); s.addEventListener('change', () => { on(s.value); azaChanged(); }); return s; };
  const sw = (checked, on, label, sub) => { const i = h('input', { type: 'checkbox', checked: !!checked }); i.addEventListener('change', () => { on(i.checked); azaChanged(); }); return h('label', { class: 'switch-row' }, h('span', {}, h('b', { text: label }), sub ? h('small', { text: sub }) : null), h('span', { class: 'switch' }, i, h('span', { class: 'track' }))); };
  const fld = (label, el, hint) => h('label', { class: 'field' }, h('span', { text: label }), el, hint ? h('small', { class: 'hint', text: hint }) : null);
  const items = AZA.items || [];
  const shown = items.filter((x) => (!AZA.cat || x.data?.cat === AZA.cat) && (!AZA.q || (x.data?.text || '').includes(AZA.q) || (x.data?.source || '').includes(AZA.q)));
  const search = h('input', { class: 'input', placeholder: '🔎 ابحث في الأذكار…', value: AZA.q });
  search.addEventListener('input', () => { AZA.q = search.value.trim(); paintList(); });
  const listBox = h('div', { class: 'aza-list' });
  function paintList() {
    const arr = items.filter((x) => (!AZA.cat || x.data?.cat === AZA.cat) && (!AZA.q || (x.data?.text || '').includes(AZA.q) || (x.data?.source || '').includes(AZA.q)));
    RC(listBox, ...(arr.length ? arr.map((it) => {
      const d = it.data || {};
      return h('div', { class: `aza-row${it.active ? '' : ' off'}` },
        h('div', { class: 'aza-c' },
          h('b', { text: d.text }),
          h('small', { text: [`${AzkarKit.catIcon(d.cat)} ${d.cat || ''}`, d.source, d.count > 1 ? `×${d.count}` : '', d.pin?.from ? `📌 ${new Date(d.pin.from).toLocaleDateString('ar-SA-u-nu-latn')} ← ${new Date(d.pin.to).toLocaleDateString('ar-SA-u-nu-latn')}` : ''].filter(Boolean).join(' · ') }),
          d.virtue ? h('small', { class: 'aza-vir', text: d.virtue }) : null),
        h('div', { class: 'aza-a' },
          (() => { const i = h('input', { type: 'checkbox', checked: !!it.active }); i.addEventListener('change', async () => { try { await Cloud.admin.azkarSave(it.id, null, null, i.checked); it.active = i.checked; paintList(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } }); return h('label', { class: 'switch' }, i, h('span', { class: 'track' })); })(),
          h('button', { type: 'button', class: 'icon-btn', title: 'تعديل', onclick: () => editZikr(it) }, icon('edit', { size: 15 })),
          h('button', { type: 'button', class: 'icon-btn danger', title: 'حذف', onclick: async () => { if (!confirm('حذف هذا الذكر؟')) return; try { await Cloud.admin.azkarDelete(it.id); AZA.items = AZA.items.filter((x) => x.id !== it.id); renderAzkarAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, icon('trash', { size: 15 }))));
    }) : [h('div', { class: 'empty' }, h('b', { text: items.length ? 'ما فيه نتائج' : 'ما أضفت أذكار بعد' }), h('small', { text: items.length ? 'جرّب بحث ثاني.' : `التطبيق يعرض ${UI.n(AzkarKit.BUILTIN.length)} ذكر جاهز بمصادرها — تقدر تستوردها هنا وتعدّل عليها، أو تضيف من عندك.` }))]));
    UI.digitize(listBox);
  }
  paintList();
  const prev = () => { if (typeof azkarToast === 'function') return; const z = AzkarKit.pick(AzkarKit.list(items.filter((x) => x.active).map((x) => ({ id: x.id, ...x.data })), m), T.mode); if (z) toast(`${z.text}`, { duration: (Number(T.auto) || 6) * 1000 }); };
  RC($('#a-azkar'),
    h('section', { class: 'a-hero' },
      h('div', {}, h('h1', {}, h('span', { class: 'title-pill', text: 'الأذكار' })),
        h('p', { class: 'lead', text: 'أذكار وأدعية مجانية لكل المستخدمين: ذكر لطيف ينزل عند فتح التطبيق، وقسم «أذكاري» بالمسبحة والتذكير، و«صمّمها حالة» تحوّل أي ذكر لتصميم متحرك. كل تعديل يوصل فوراً بدون تحديث.' })),
      h('div', { class: 'a-save' },
        h('button', { type: 'button', class: 'btn', onclick: () => editZikr({}) }, icon('plus', { size: 16 }), 'أضف ذكر أو دعاء'),
        h('button', { type: 'button', class: 'btn btn-primary', id: 'aza-save', disabled: !AZA.dirty, onclick: async () => { try { await Cloud.admin.azkarMeta(AZA.meta); AZA.dirty = false; toast('حُفظت إعدادات الأذكار ✓', { type: 'success' }); renderAzkarAdmin(); } catch (e) { toast(Cloud.msg(e), { type: 'error' }); } } }, icon('check', { size: 16 }), 'احفظ الإعدادات'))),
    h('nav', { class: 'chips aza-subs' }, ...[['content', '📚 المحتوى والإعدادات'], ['icons', '🎨 الأيقونات'], ['ctl', '🎛️ التحكم في القسم']].map(([k, l]) => h('button', { type: 'button', class: `chip${(AZA.sub || 'content') === k ? ' on' : ''}`, onclick: () => { AZA.sub = k; renderAzkarAdmin(); } }, l))),
    AZA.sub && AZA.sub !== 'content' ? h('div', { id: 'aza-x' }) : null,
    AZA.sub && AZA.sub !== 'content' ? null : h('div', { class: 'an-stats' }, ...[[items.length, 'ذكر من عندك'], [items.filter((x) => x.active).length, 'ظاهر'], [m.builtin === false ? 0 : AzkarKit.BUILTIN.length, 'ذكر جاهز ظاهر'], [items.filter((x) => x.data?.pin?.from).length, 'مثبّت لتاريخ']].map(([n, l]) => h('div', {}, h('b', { class: 'num', text: UI.n(n) }), h('small', { text: l })))),
    AZA.sub && AZA.sub !== 'content' ? null : h('div', { class: 'aza-grid' },
      h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '🔔 الذكر عند فتح التطبيق' }),
        sw(T.on, (v) => (T.on = v), 'تشغيل', 'ينزل ذكر قصير بشكل لطيف مثل الإشعار'),
        (() => { // 1.20: ليش ما يطلع؟
          const v = AzkarKit.visible(m, 'g_toast', { pro: false, tester: false }), act = items.filter((x) => x.active).length + (m.builtin === false ? 0 : AzkarKit.BUILTIN.length);
          const why = !T.on ? '⛔ مطفي — شغّله من فوق واحفظ' : v === 'none' ? '⛔ مخفي من «🎛️ التحكم في القسم» ← عام ← «نافذة الذكر» — خلّه «للكل»' : v === 'soon' ? '⏳ معلّم «قريباً» في التحكم في القسم' : v === 'lock' ? '🔒 مقفل لغير المشتركين من «🎛️ التحكم في القسم» — خلّه «للكل» عشان يطلع للضيوف' : !act ? '⚠️ ما فيه ولا ذكر ظاهر' : '';
          return h('p', { class: `hint aza-why${why ? ' bad' : ' ok'}`, text: why || '✅ شغّال — يطلع للكل عند فتح التطبيق (بعد فيديو الافتتاح لو مفعّل)' });
        })(),
        h('div', { class: 'row-2' },
          fld('الشكل', sel(T.style, [['green', '🟢 أخضر'], ['gold', '🟡 ذهبي'], ['night', '🌙 ليلي'], ['light', '⚪ فاتح']], (v) => (T.style = v))),
          fld('المكان', sel(T.pos, [['top', 'من فوق'], ['center', 'بالوسط'], ['bottom', 'من تحت']], (v) => (T.pos = v)))),
        h('div', { class: 'row-2' },
          fld('كم مرة يظهر', sel(T.freq, [['open', 'كل فتح'], ['hour', 'كل ساعة'], ['3h', 'كل ٣ ساعات'], ['day', 'مرة باليوم']], (v) => (T.freq = v))),
          fld('يختفي بعد', sel(T.auto, [[5, '٥ ثواني'], [8, '٨ ثواني'], [12, '١٢ ثانية'], [0, 'يدوي (لين يقفله)']], (v) => (T.auto = Number(v))))),
        fld('طريقة الاختيار', sel(T.mode, [['random', 'عشوائي (يراعي الصباح والمساء)'], ['order', 'بالترتيب'], ['daily', 'ذكر اليوم (نفسه طول اليوم)']], (v) => (T.mode = v)))),
      h('div', { class: 'set-card ga-card' }, h('strong', { class: 'ga-ct', text: '⚙️ القسم والتذكير' }),
        fld('اسم القسم', (() => { const i = h('input', { class: 'input', value: m.title || 'أذكاري', maxlength: 24 }); i.addEventListener('input', () => { m.title = i.value; azaChanged(); }); return i; })()),
        sw(m.builtin !== false, (v) => (m.builtin = v), 'إظهار الأذكار الجاهزة', `${UI.n(AzkarKit.BUILTIN.length)} ذكر من القرآن والصحيحين والسنن مع المصدر`),
        sw(R.on, (v) => (R.on = v), 'تذكير أذكار الصباح والمساء', 'إشعار يومي يفعّله المستخدم من القسم'),
        h('div', { class: 'row-2' },
          fld('ساعة الصباح', sel(R.morning, [4, 5, 6, 7, 8, 9].map((x) => [x, `${x}:٠٠ ص`]), (v) => (R.morning = Number(v)))),
          fld('ساعة المساء', sel(R.evening, [15, 16, 17, 18, 19, 20].map((x) => [x, `${x - 12}:٠٠ م`]), (v) => (R.evening = Number(v))))))),
    AZA.sub && AZA.sub !== 'content' ? null : h('div', { class: 'set-card ga-card' },
      h('div', { class: 'aza-tools' }, h('strong', { class: 'ga-ct', text: '📚 الأذكار والأدعية' }), search,
        h('select', { class: 'input aza-cat', onchange: (e) => { AZA.cat = e.target.value; paintList(); } }, h('option', { value: '', text: 'كل التصنيفات' }), ...AzkarKit.CATS.map(([c, ic]) => { const o = h('option', { value: c, text: `${ic} ${c}` }); if (AZA.cat === c) o.selected = true; return o; })),
        h('button', { type: 'button', class: 'btn', onclick: importBuiltin }, '⬇️ استورد الأذكار الجاهزة')),
      h('p', { class: 'hint', text: 'تنبيه: الأذكار محتوى ديني — اكتب المصدر بدقة (الآية أو الكتاب ودرجة الحديث)، ويفضّل مراجعتها من شخص موثوق قبل النشر.' }),
      listBox));
  if (AZA.sub === 'icons') renderAzIcons($('#aza-x'));
  if (AZA.sub === 'ctl') renderAzCtl($('#aza-x'));
  UI.digitize($('#a-azkar'));
  void shown; void prev;
}
async function importBuiltin() {
  const have = new Set((AZA.items || []).map((x) => x.data?.text));
  const add = AzkarKit.BUILTIN.filter((z) => !have.has(z.text));
  if (!add.length) return toast('كل الأذكار الجاهزة موجودة عندك ✓');
  if (!confirm(`استيراد ${add.length} ذكر جاهز لقائمتك (تقدر تعدّلها بعدين)؟ ويتوقف عرض النسخة الجاهزة عشان ما تتكرر.`)) return;
  try {
    for (const z of add) await Cloud.admin.azkarSave(null, { text: z.text, source: z.source, cat: z.cat, virtue: z.virtue || '', count: z.count || 1 });
    AZA.meta.builtin = false; await Cloud.admin.azkarMeta(AZA.meta);
    toast(`استوردنا ${add.length} ذكر ✓`, { type: 'success' });
    openAzkarAdmin(true);
  } catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
}
function editZikr(it) {
  const d = JSON.parse(JSON.stringify(it.data || { text: '', source: '', cat: 'ذكر', virtue: '', count: 1 }));
  const ta = (key, ph, rows = 3, max = 1200) => { const t = h('textarea', { class: 'input textarea', rows, maxlength: max, placeholder: ph }); t.value = d[key] || ''; t.addEventListener('input', () => (d[key] = t.value)); return t; };
  const inp = (key, ph, max = 120) => { const i = h('input', { class: 'input', placeholder: ph, maxlength: max }); i.value = d[key] || ''; i.addEventListener('input', () => (d[key] = i.value)); return i; };
  const cat = h('select', { class: 'input' }, ...AzkarKit.CATS.map(([c, ic]) => h('option', { value: c, text: `${ic} ${c}` }))); cat.value = d.cat || 'ذكر'; cat.addEventListener('change', () => (d.cat = cat.value));
  const count = h('input', { class: 'input num', type: 'number', min: 1, max: 1000, value: d.count || 1 }); count.addEventListener('input', () => (d.count = Math.max(1, Number(count.value) || 1)));
  const pin = d.pin || { from: '', to: '' };
  const dt = (key) => { const i = h('input', { class: 'input ltr', type: 'date', value: pin[key] ? pin[key].slice(0, 10) : '' }); i.addEventListener('change', () => { pin[key] = i.value ? new Date(i.value + 'T00:00').toISOString() : ''; }); return i; };
  const preview = h('div', { class: 'aza-pv' });
  const paintPv = () => RC(preview, h('small', { text: `${AzkarKit.catIcon(d.cat)} ${d.cat || ''}` }), h('b', { text: d.text || 'نص الذكر يظهر هنا' }), d.virtue ? h('p', { text: d.virtue }) : null, h('em', { text: d.source || '' }));
  const form = h('div', { class: 'ad-form', oninput: paintPv, onchange: paintPv },
    preview,
    h('label', { class: 'field' }, h('span', { text: 'نص الذكر أو الدعاء (بالتشكيل أفضل)' }), ta('text', 'سُبْحَانَ اللهِ وَبِحَمْدِهِ…', 3)),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'المصدر' }), inp('source', 'رواه مسلم / البقرة ٢٠١')), h('label', { class: 'field' }, h('span', { text: 'التصنيف' }), cat)),
    h('label', { class: 'field' }, h('span', { text: 'الفضل (اختياري)' }), ta('virtue', '«كنز من كنوز الجنة»', 2, 400)),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'عدد التكرار' }), count), h('div', {})),
    h('strong', { class: 'ga-ct', text: '📌 تثبيت لتاريخ (اختياري)' }),
    h('p', { class: 'hint', text: 'خلال الفترة يصير هذا الذكر «ذكر اليوم» ويظهر عند الفتح — مثل أدعية رمضان أو عشر ذي الحجة.' }),
    h('div', { class: 'row-2' }, h('label', { class: 'field' }, h('span', { text: 'من' }), dt('from')), h('label', { class: 'field' }, h('span', { text: 'إلى' }), dt('to'))));
  paintPv();
  mkSheet(it.id ? 'تعديل الذكر' : 'ذكر جديد', [form], [
    h('button', { type: 'button', class: 'btn', onclick: () => closeSheet($('#mk-sheet')) }, 'إلغاء'),
    h('button', { type: 'button', class: 'btn btn-primary', onclick: async () => {
      d.text = (d.text || '').trim();
      if (d.text.length < 3) return toast('اكتب نص الذكر');
      if (!(d.source || '').trim()) return toast('اكتب المصدر — مهم للتوثيق');
      d.pin = pin.from && pin.to ? pin : null;
      try { await Cloud.admin.azkarSave(it.id || null, d); toast('حُفظ ✓ — وصل للمستخدمين الحين', { type: 'success' }); closeSheet($('#mk-sheet')); openAzkarAdmin(true); }
      catch (e) { toast(Cloud.msg(e), { type: 'error' }); }
    } }, 'احفظ')]);
}
