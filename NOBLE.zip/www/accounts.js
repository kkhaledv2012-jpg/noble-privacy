/* NOBLE — «تذكّرني»: حسابات محفوظة على الجهاز + دخول الحساب بالبصمة */
'use strict';

const Acc = {
  KEY: 'nw:accounts',
  norm: (e) => String(e || '').trim().toLowerCase(),
  list() {
    try {
      const l = JSON.parse(localStorage.getItem(this.KEY) || '[]');
      return Array.isArray(l) ? l.filter((a) => a && a.email) : [];
    } catch { return []; }
  },
  write(l) { try { localStorage.setItem(this.KEY, JSON.stringify(l.slice(0, 4))); } catch { /* لا شيء */ } },
  get(email) { const e = this.norm(email); return this.list().find((a) => a.email === e) || null; },
  remember(email, patch = {}) {
    const e = this.norm(email);
    if (!e) return;
    const l = this.list();
    const old = l.find((a) => a.email === e) || {};
    this.write([{ ...old, ...patch, email: e, at: Date.now() }, ...l.filter((a) => a.email !== e)]);
    try { localStorage.setItem('nw:last-email', e); } catch { /* لا شيء */ }
  },
  async forget(email) {
    const e = this.norm(email);
    await this.bioDel(e);
    this.write(this.list().filter((a) => a.email !== e));
    try { if (localStorage.getItem('nw:last-email') === e) localStorage.removeItem('nw:last-email'); } catch { /* لا شيء */ }
  },
  /* بيانات الدخول في مخزن الجوال الآمن (Keystore) — لا تُحفظ في التطبيق نفسه */
  server: (e) => `${Bio.SERVER}.acc.${e}`,
  async bioSet(email, pw) {
    const e = this.norm(email);
    await Bio.put(this.server(e), e, pw);
    this.remember(e, { bio: true });
  },
  async bioDel(email) {
    const e = this.norm(email);
    await Bio.del(this.server(e));
    if (this.get(e)?.bio) this.remember(e, { bio: false });
  },
  async bioGet(email) {
    const e = this.norm(email);
    return Bio.take(this.server(e), e);
  },
};

/* ---------- واجهة الحسابات المحفوظة في شاشة الدخول ---------- */
const AccUI = { picked: '', autoTried: false };

function paintSavedAccounts() {
  const box = $('#c-saved');
  const list = cloudMode === 'signin' ? Acc.list() : [];
  const emailIn = $('#c-email');
  if (!list.length) {
    box.hidden = true; box.replaceChildren();
    AccUI.picked = '';
    emailIn.hidden = false;
    return;
  }
  if (AccUI.picked && !list.some((a) => a.email === AccUI.picked)) AccUI.picked = '';
  box.hidden = false;
  const bioOk = Platform.isNative;
  const card = (a) => {
    const name = a.name || a.email.split('@')[0];
    const on = AccUI.picked === a.email;
    return h('div', { class: `acc-card${on ? ' on' : ''}`, onclick: () => pickAccount(a.email) },
      h('span', { class: 'acc-av', text: name.charAt(0).toUpperCase() }),
      h('div', { class: 'acc-t' }, h('b', { text: name }), h('small', { class: 'ltr', text: a.email })),
      a.bio && bioOk ? h('button', { type: 'button', class: 'acc-bio', 'aria-label': 'الدخول بالبصمة', onclick: (e) => { e.stopPropagation(); bioSignIn(a.email); } }, icon('finger', { size: 24 })) : null,
      h('button', { type: 'button', class: 'acc-x', 'aria-label': 'إزالة من الجهاز', onclick: (e) => { e.stopPropagation(); forgetAccount(a.email); } }, icon('x', { size: 15 })));
  };
  box.replaceChildren(
    h('p', { class: 'acc-head', text: list.length > 1 ? 'اختر حسابك' : 'حسابك المحفوظ' }),
    ...list.map(card),
    AccUI.picked ? h('button', { type: 'button', class: 'link-btn acc-other', onclick: () => pickAccount('') }, 'الدخول بحساب آخر') : null);
  emailIn.hidden = !!AccUI.picked;
}

function pickAccount(email) {
  AccUI.picked = email;
  $('#c-email').value = email;
  $('#c-error').textContent = '';
  paintSavedAccounts();
  if (!email) return $('#c-email').focus();
  const a = Acc.get(email);
  if (a?.bio && Platform.isNative) return bioSignIn(email);
  $('#c-pw').focus();
}

async function forgetAccount(email) {
  const ok = await confirmSheet({ title: 'إزالة الحساب من الجهاز؟', text: `سيُحذف ${email} من الحسابات المحفوظة وتُلغى بصمته على هذا الجوال. حسابك وبياناتك تبقى كما هي.`, ok: 'إزالة' });
  if (!ok) return;
  await Acc.forget(email);
  if ($('#c-email').value === email) $('#c-email').value = '';
  paintSavedAccounts();
  toast('تمت إزالة الحساب من الجهاز');
}

/* يُستدعى عند فتح شاشة الدخول: يختار الحساب المحفوظ ويطلب البصمة تلقائياً */
function initSavedAccounts(email) {
  const list = Acc.list();
  const want = Acc.norm(email) || list[0]?.email || '';
  AccUI.picked = list.some((a) => a.email === want) ? want : '';
  if (AccUI.picked) $('#c-email').value = AccUI.picked;
  $('#c-remember').checked = true;
  paintSavedAccounts();
  const a = AccUI.picked && Acc.get(AccUI.picked);
  try { if (sessionStorage.getItem('nw:no-auto')) AccUI.autoTried = true; } catch { /* لا شيء */ }
  if (a?.bio && Platform.isNative && !AccUI.autoTried && !document.hidden) {
    AccUI.autoTried = true;
    setTimeout(() => { if (!S.unlocked && !$('#cloud-form').hidden && AccUI.picked === a.email) bioSignIn(a.email); }, 500);
  }
}

let bioBusy = false;
async function bioSignIn(email) {
  if (bioBusy) return;
  bioBusy = true;
  const err = $('#c-error');
  err.textContent = '';
  let pw;
  try {
    pw = await Acc.bioGet(email);
  } catch (e) {
    bioBusy = false;
    if (String(e?.code) === '21' || /No protected credentials|not found/i.test(e?.message || '')) {
      await Acc.bioDel(email);
      paintSavedAccounts();
      err.textContent = 'تغيّرت بصمات الجهاز — ادخل بكلمة المرور وسنعيد تفعيل البصمة.';
    }
    $('#c-pw').focus();
    return;
  }
  const btn = $('#c-submit');
  btn.disabled = true;
  try {
    await cloudSignIn(email, pw, { remember: true, viaBio: true });
  } catch (ex) {
    if (/invalid|credentials|غير صحيحة/i.test(ex?.message || '') || ex?.status === 400) {
      await Acc.bioDel(email);
      paintSavedAccounts();
      err.textContent = 'تغيّرت كلمة المرور — أدخل الجديدة وسنحدّث البصمة.';
    } else err.textContent = Cloud.msg(ex);
  } finally {
    btn.disabled = false;
    bioBusy = false;
  }
}

/* الدخول الفعلي (من النموذج أو من البصمة) */
async function cloudSignIn(email, pw, { remember = true, viaBio = false } = {}) {
  const u = await Cloud.signIn(email, pw);
  const prof = await Cloud.profile();
  if (prof?.status === 'suspended') {
    await Cloud.signOut();
    await Acc.forget(email);
    throw new Error('هذا الحساب موقوف — تواصل مع الإدارة');
  }
  await openCloudVault(pw, u, await Cloud.pullVault());
  afterSignedIn(u.email || email, pw, prof, remember, viaBio);
}

/* بعد نجاح الدخول/إنشاء الحساب: نحفظ الحساب ونعرض تفعيل البصمة مرة واحدة */
function afterSignedIn(email, pw, prof, remember, viaBio) {
  try { sessionStorage.removeItem('nw:no-auto'); } catch { /* لا شيء */ }
  if (!remember) { Acc.forget(email); return; }
  Acc.remember(email, { name: prof?.display_name || prof?.nickname || '' });
  if (pref('biometric') && pref('bioEmail') && pref('bioEmail') !== Acc.norm(email)) Bio.off();
  if (viaBio) {
    // دخل ببصمة الحساب: نعيد ربط بصمة فتح الخزنة بنفس الحساب
    if (!pref('biometric') || pref('bioEmail') !== Acc.norm(email)) {
      Bio.store(pw).then(() => setPref({ biometric: true, bioEmail: Acc.norm(email) })).catch(() => {});
    }
    return;
  }
  if (!Platform.isNative || Acc.get(email)?.bio) return;
  setTimeout(async () => {
    if (!(await Bio.available())) return;
    const ok = await confirmSheet({ title: 'الدخول بالبصمة', text: 'فعّل البصمة لتدخل حسابك وتفتح خزنتك بلمسة واحدة، بدون كتابة البريد وكلمة المرور كل مرة.', ok: 'تفعيل البصمة', tone: 'primary' });
    if (!ok) return;
    try {
      await Acc.bioSet(email, pw);
      await Bio.store(pw);
      await setPref({ biometric: true, bioEmail: Acc.norm(email) });
      buzz('success');
      toast('تم تفعيل الدخول بالبصمة', { type: 'success' });
    } catch { toast('لم يتم التفعيل', { type: 'error' }); }
  }, 900);
}

/* يبقي بصمة الحساب متوافقة مع إعداد البصمة في التطبيق */
async function syncAccountBio(pw, on) {
  const u = Cloud.enabled && (await Cloud.user());
  if (!u?.email) return;
  if (on) { try { await Acc.bioSet(u.email, pw); await setPref({ bioEmail: Acc.norm(u.email) }); } catch { /* لا شيء */ } }
  else await Acc.bioDel(u.email);
}
