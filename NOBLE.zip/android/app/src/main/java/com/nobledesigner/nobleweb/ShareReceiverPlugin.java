package com.nobledesigner.nobleweb;

import android.content.Intent;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

/**
 * يستقبل الروابط المُشارَكة من التطبيقات الأخرى (زر «مشاركة» في أندرويد)
 * ويسلّمها للواجهة لتفتح نموذج «إضافة موقع» معبأً.
 */
@CapacitorPlugin(name = "ShareReceiver")
public class ShareReceiverPlugin extends Plugin {

    private static JSObject pending;

    static void store(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String type = intent.getType();
        if (type == null || !type.startsWith("text/")) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text == null || text.isEmpty()) return;
        JSObject data = new JSObject();
        data.put("text", text);
        String subject = intent.getStringExtra(Intent.EXTRA_SUBJECT);
        data.put("subject", subject != null ? subject : "");
        pending = data;
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        store(intent);
        if (pending != null) {
            notifyListeners("shared", new JSObject(), true);
        }
    }

    @PluginMethod
    public void getShared(PluginCall call) {
        JSObject result = pending != null ? pending : new JSObject();
        pending = null;
        call.resolve(result);
    }
}
