package com.nobledesigner.nobleweb;

import android.os.Bundle;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(ShareReceiverPlugin.class);
        super.onCreate(savedInstanceState);
        // فتح التطبيق مباشرة من زر «مشاركة»
        ShareReceiverPlugin.store(getIntent());
    }
}
