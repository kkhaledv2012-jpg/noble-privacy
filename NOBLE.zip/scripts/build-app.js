/* يجهّز المشروع لبناء تطبيق معيّن: node scripts/build-app.js <nobleweb|vault|tasks|finance|games>
 * نفس الكود ونفس الحساب — يتغيّر فقط: معرّف الحزمة، الاسم، الأيقونة، والأقسام الظاهرة. */
'use strict';
const fs = require('fs');
const path = require('path');
const ROOT = path.join(__dirname, '..');
const id = process.argv[2] || 'nobleweb';
const apps = JSON.parse(fs.readFileSync(path.join(ROOT, 'apps/apps.json'), 'utf8'));
const a = apps[id];
if (!a) { console.error(`تطبيق غير معروف: ${id} — المتاح: ${Object.keys(apps).join(', ')}`); process.exit(1); }
const rw = (f, fn) => { const p = path.join(ROOT, f); fs.writeFileSync(p, fn(fs.readFileSync(p, 'utf8'))); };
const xml = (s) => s.replace(/&/g, '&amp;').replace(/</g, '&lt;');

// ١) ملف التطبيق داخل الواجهة
fs.writeFileSync(path.join(ROOT, 'www/app-profile.js'),
  `/* NOBLE — ملف التطبيق: يُكتب تلقائياً عند البناء (scripts/build-app.js) لكل تطبيق */\nwindow.NOBLE_APP = ${JSON.stringify({ id, pro: a.pro, name: a.name, sections: a.sections, ...(process.env.PLAY === '1' ? { play: true } : {}) })};\n`);
// ٢) Capacitor
rw('capacitor.config.json', (s) => { const c = JSON.parse(s); c.appId = a.appId; c.appName = a.name; return JSON.stringify(c, null, 2) + '\n'; });
// ٣) أندرويد: معرّف الحزمة (namespace يبقى كما هو لأن كود Java عليه)
rw('android/app/build.gradle', (s) => s.replace(/applicationId\s+"[^"]+"/, `applicationId "${a.appId}"`));
rw('android/app/src/main/res/values/strings.xml', (s) => s
  .replace(/(<string name="app_name">)[^<]*(<\/string>)/, `$1${xml(a.name)}$2`)
  .replace(/(<string name="title_activity_main">)[^<]*(<\/string>)/, `$1${xml(a.name)}$2`)
  .replace(/(<string name="package_name">)[^<]*(<\/string>)/, `$1${a.appId}$2`)
  .replace(/(<string name="custom_url_scheme">)[^<]*(<\/string>)/, `$1${a.appId}$2`));
// ٤) الأيقونات
const src = path.join(ROOT, 'apps', id, 'res');
if (fs.existsSync(src)) {
  for (const d of fs.readdirSync(src)) {
    const to = path.join(ROOT, 'android/app/src/main/res', d);
    fs.mkdirSync(to, { recursive: true });
    for (const f of fs.readdirSync(path.join(src, d))) fs.copyFileSync(path.join(src, d, f), path.join(to, f));
  }
}
// ٥) 1.21.8: Firebase — google-services.json من جذر المستودع (لو انرفع جنب NOBLE.zip) يروح لمكانه في أندرويد
for (const n of ['google-services.json', 'google-services.json.json', 'android/app/google-services.json']) {
  const p = path.join(ROOT, n);
  if (fs.existsSync(p)) {
    const j = JSON.parse(fs.readFileSync(p, 'utf8'));
    if (!(j.client || []).some((c) => c.client_info?.android_client_info?.package_name === a.appId)) { console.warn(`⚠️ ${a.appId} مو مضاف في Firebase — الإشعارات الفورية ما بتشتغل لهذا التطبيق`); break; }
    if (n !== 'android/app/google-services.json') fs.copyFileSync(p, path.join(ROOT, 'android/app/google-services.json'));
    console.log('✓ Firebase: google-services.json جاهز'); break;
  }
}
if (process.env.GITHUB_ENV) fs.appendFileSync(process.env.GITHUB_ENV, `APP_FILE=${a.file}\nAPP_NAME=${a.name}\n`);
console.log(`✓ جاهز لبناء ${a.name} (${a.appId})${process.env.PLAY === '1' ? ' — نسخة Google Play (بدون دفع داخل التطبيق)' : ''}`);
