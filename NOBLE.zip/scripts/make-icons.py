"""يولّد أيقونات كل تطبيق (خلفية بلون التطبيق + شعار NOBLE) في apps/<id>/res — شغّله مرة عند تغيير الألوان."""
import os, shutil
from PIL import Image, ImageDraw, ImageFilter
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'android/app/src/main/res')
APPS = {'vault': (46, 91, 255), 'tasks': (31, 199, 160), 'finance': (240, 146, 47), 'games': (200, 80, 156), 'azkar': (11, 92, 68)}
DPI = {'mdpi': (48, 108), 'hdpi': (72, 162), 'xhdpi': (96, 216), 'xxhdpi': (144, 324), 'xxxhdpi': (192, 432)}
NIGHT = (5, 10, 26)

def background(color, n=432):
    img = Image.new('RGB', (n, n), NIGHT)
    glow = Image.new('RGB', (n, n), NIGHT)
    d = ImageDraw.Draw(glow)
    d.ellipse((int(n * .25), int(-n * .55), int(n * 1.55), int(n * .75)), fill=color)
    d.ellipse((int(-n * .6), int(n * .7), int(n * .45), int(n * 1.6)), fill=tuple(int(c * .55) for c in color))
    glow = glow.filter(ImageFilter.GaussianBlur(n * .16))
    return Image.blend(img, glow, .85)

def main():
    fg_src = Image.open(os.path.join(RES, 'mipmap-xxxhdpi/ic_launcher_foreground.png')).convert('RGBA')
    # نسخة التطبيق الشامل كما هي
    for d in DPI:
        dst = os.path.join(ROOT, 'apps/nobleweb/res', 'mipmap-' + d); os.makedirs(dst, exist_ok=True)
        for f in ['ic_launcher.png', 'ic_launcher_round.png', 'ic_launcher_background.png', 'ic_launcher_foreground.png']:
            shutil.copy(os.path.join(RES, 'mipmap-' + d, f), dst)
    for app, color in APPS.items():
        big_bg = background(color)
        for d, (leg, ad) in DPI.items():
            dst = os.path.join(ROOT, 'apps', app, 'res', 'mipmap-' + d); os.makedirs(dst, exist_ok=True)
            big_bg.resize((ad, ad), Image.LANCZOS).save(os.path.join(dst, 'ic_launcher_background.png'))
            fg_src.resize((ad, ad), Image.LANCZOS).save(os.path.join(dst, 'ic_launcher_foreground.png'))
            comp = big_bg.convert('RGBA'); comp.alpha_composite(fg_src)
            c = int(432 * 18 / 108); comp = comp.crop((c, c, 432 - c, 432 - c)).resize((leg * 4, leg * 4), Image.LANCZOS)
            for name, shape in [('ic_launcher.png', 'rr'), ('ic_launcher_round.png', 'circle')]:
                m = Image.new('L', comp.size, 0); dr = ImageDraw.Draw(m)
                if shape == 'rr': dr.rounded_rectangle((0, 0, comp.size[0] - 1, comp.size[1] - 1), radius=int(comp.size[0] * .22), fill=255)
                else: dr.ellipse((0, 0, comp.size[0] - 1, comp.size[1] - 1), fill=255)
                out = Image.new('RGBA', comp.size, (0, 0, 0, 0)); out.paste(comp, (0, 0), m)
                out.resize((leg, leg), Image.LANCZOS).save(os.path.join(dst, name))
    print('icons ok')
main()
