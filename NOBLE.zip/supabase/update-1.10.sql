-- ============================================================
-- NOBLE 1.10 — أخبار الذكاء الاصطناعي (نبض AI)
--  • مصادر RSS تُسحب تلقائياً وتُترجَم وتُلخَّص بالعربي (Gemini) ثم تنتظر موافقتك
--  • تكتب أخبارك بنفسك، تثبّت، تعدّل، ترفض — من لوحة التحكم ← الأخبار
--  • مفتاح Gemini محفوظ في السيرفر فقط ولا يطلع لأي مستخدم
-- شغّله مرة واحدة في SQL Editor بعد update-1.9.sql (آمن لو تكرر)
-- ============================================================

-- ---------- صلاحية جديدة: إدارة الأخبار ----------
create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage','news.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage','news.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view','apps.manage','news.manage']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

-- ---------- الجداول ----------
create table if not exists public.news_sources (
  id         bigserial primary key,
  name       text not null,
  url        text not null unique,
  cat        text not null default 'general',
  lang       text not null default 'en',
  active     boolean not null default true,
  last_fetch timestamptz,
  last_error text,
  created_at timestamptz not null default now()
);

create table if not exists public.news_items (
  id           bigserial primary key,
  source_id    bigint references public.news_sources(id) on delete set null,
  guid         text unique,
  url          text not null default '',
  src_name     text not null default '',
  src_title    text not null default '',
  src_text     text not null default '',
  image        text not null default '',
  cat          text not null default 'general',
  title        text not null default '',
  summary      text not null default '',
  body         text not null default '',
  why          text not null default '',
  status       text not null default 'draft' check (status in ('draft', 'published', 'rejected')),
  pinned       boolean not null default false,
  ai           boolean not null default false,
  pub_at       timestamptz,
  published_at timestamptz,
  views        integer not null default 0,
  saves        integer not null default 0,
  created_by   uuid,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists news_items_feed on public.news_items (status, pinned desc, published_at desc);

-- الإعدادات (عامة للوحة) + الأسرار (للسيرفر فقط)
create table if not exists public.news_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.news_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.news_secret (
  id          int primary key default 1 check (id = 1),
  gemini_key  text not null default '',
  cron_secret text not null default replace(gen_random_uuid()::text, '-', ''),
  updated_at  timestamptz not null default now()
);
insert into public.news_secret (id) values (1) on conflict (id) do nothing;

alter table public.news_sources  enable row level security;
alter table public.news_items    enable row level security;
alter table public.news_settings enable row level security;
alter table public.news_secret   enable row level security;  -- بدون سياسات = لا أحد يقرأها إلا السيرفر
drop policy if exists "news: published" on public.news_items;
create policy "news: published" on public.news_items for select using (status = 'published' or public.has_perm('news.manage'));
drop policy if exists "news src: staff" on public.news_sources;
create policy "news src: staff" on public.news_sources for select using (public.has_perm('news.manage'));

-- ---------- للمستخدمين ----------
create or replace function public.news_feed(p_cat text default null, p_before timestamptz default null, p_limit int default 30)
returns setof json language sql stable security definer set search_path = public as $$
  select json_build_object('id', n.id, 'url', n.url, 'src', n.src_name, 'image', n.image, 'cat', n.cat, 'title', n.title,
    'summary', n.summary, 'body', n.body, 'why', n.why, 'pinned', n.pinned, 'ai', n.ai, 'at', n.published_at)
  from news_items n
  where n.status = 'published' and auth.uid() is not null
    and (p_cat is null or p_cat = '' or n.cat = p_cat)
    and (p_before is null or n.published_at < p_before)
  order by (p_before is null and n.pinned) desc, n.published_at desc
  limit least(greatest(coalesce(p_limit, 30), 1), 60);
$$;

-- اسم القسم ووقت الموجز (الجزء العام من الإعدادات فقط)
create or replace function public.news_meta()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object('title', coalesce(nullif(data->>'title', ''), 'نبض AI'), 'sub', coalesce(data->>'sub', ''),
    'hour', coalesce((data->>'hour')::int, 8), 'digest', coalesce((data->>'digest')::boolean, true))
  from news_settings where id = 1 and auth.uid() is not null;
$$;

-- قراءة / حفظ (عدّاد)
create or replace function public.news_hit(p_id bigint, p_kind text default 'view')
returns void language sql security definer set search_path = public as $$
  update news_items set views = views + (case when p_kind = 'view' then 1 else 0 end),
                        saves = greatest(0, saves + (case when p_kind = 'save' then 1 when p_kind = 'unsave' then -1 else 0 end))
  where id = p_id and status = 'published' and auth.uid() is not null;
$$;

-- ---------- لوحة التحكم ----------
create or replace function public.admin_news_list(p_status text default 'draft', p_limit int default 100)
returns setof news_items language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return query select * from news_items where p_status is null or status = p_status
    order by case when p_status = 'published' then published_at else created_at end desc nulls last
    limit least(greatest(coalesce(p_limit, 100), 1), 300);
end $$;

-- حفظ خبر (جديد يدوي أو تعديل) — p_item: {id?, title, summary, body, why, cat, image, url, src_name, status?, pinned?}
create or replace function public.admin_news_save(p_item jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; st text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_item->>'title', '')) < 3 then raise exception 'title required'; end if;
  st := coalesce(nullif(p_item->>'status', ''), 'draft');
  if (p_item->>'id') is null then
    insert into news_items (title, summary, body, why, cat, image, url, src_name, status, pinned, created_by, published_at, guid)
    values (left(p_item->>'title', 220), left(coalesce(p_item->>'summary', ''), 600), left(coalesce(p_item->>'body', ''), 6000),
      left(coalesce(p_item->>'why', ''), 600), coalesce(nullif(p_item->>'cat', ''), 'general'), left(coalesce(p_item->>'image', ''), 600),
      left(coalesce(p_item->>'url', ''), 600), left(coalesce(nullif(p_item->>'src_name', ''), 'فريق NOBLE'), 60), st,
      coalesce((p_item->>'pinned')::boolean, false), auth.uid(), case when st = 'published' then now() end, 'manual:' || gen_random_uuid())
    returning id into nid;
  else
    nid := (p_item->>'id')::bigint;
    update news_items set
      title = left(p_item->>'title', 220), summary = left(coalesce(p_item->>'summary', ''), 600), body = left(coalesce(p_item->>'body', ''), 6000),
      why = left(coalesce(p_item->>'why', ''), 600), cat = coalesce(nullif(p_item->>'cat', ''), cat), image = left(coalesce(p_item->>'image', image), 600),
      url = left(coalesce(p_item->>'url', url), 600), src_name = left(coalesce(nullif(p_item->>'src_name', ''), src_name), 60),
      status = st, pinned = coalesce((p_item->>'pinned')::boolean, pinned),
      published_at = case when st = 'published' then coalesce(published_at, now()) else published_at end, updated_at = now()
    where id = nid;
  end if;
  perform public.log_action('news', null, json_build_object('id', nid, 'status', st)::jsonb);
  return nid;
end $$;

-- نشر / رفض / تثبيت
create or replace function public.admin_news_set(p_id bigint, p_status text default null, p_pinned boolean default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_items set
    status = coalesce(p_status, status), pinned = coalesce(p_pinned, pinned),
    published_at = case when coalesce(p_status, status) = 'published' then coalesce(published_at, now()) else published_at end,
    updated_at = now()
  where id = p_id;
end $$;

create or replace function public.admin_news_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  delete from news_items where id = p_id;
end $$;

-- المصادر
create or replace function public.admin_news_sources()
returns setof news_sources language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return query select * from news_sources order by id;
end $$;

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
  if (p_src->>'id') is null then
    insert into news_sources (name, url, cat, active) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'general'), coalesce((p_src->>'active')::boolean, true))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, active = excluded.active
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), active = coalesce((p_src->>'active')::boolean, active) where id = sid;
  end if;
  return sid;
end $$;

create or replace function public.admin_news_source_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  delete from news_sources where id = p_id;
end $$;

-- الإعدادات (المفتاح لا يُرجَع أبداً — فقط هل هو موجود)
create or replace function public.admin_news_settings()
returns json language plpgsql stable security definer set search_path = public as $$
declare d jsonb; k text; job boolean := false;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  select data into d from news_settings where id = 1;
  select gemini_key into k from news_secret where id = 1;
  begin
    execute 'select exists (select 1 from cron.job where jobname = ''noble-news'')' into job;
  exception when others then job := null;  -- pg_cron غير مفعّل
  end;
  return json_build_object('data', coalesce(d, '{}'::jsonb), 'has_key', coalesce(k, '') <> '',
    'key_hint', case when coalesce(k, '') <> '' then '••••' || right(k, 4) else '' end, 'cron', job);
end $$;

create or replace function public.admin_news_set_settings(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update news_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

create or replace function public.admin_news_set_key(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_secret set gemini_key = trim(coalesce(p_key, '')), updated_at = now() where id = 1;
  perform public.log_action('news_key');
end $$;

-- السحب التلقائي كل X ساعات (يحتاج pg_cron و pg_net — مجانية في Supabase)
create or replace function public.admin_news_schedule(p_url text, p_anon text, p_hours int)
returns text language plpgsql security definer set search_path = public, extensions as $$
declare sec text; cmd text; h int := least(greatest(coalesce(p_hours, 0), 0), 24);
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_url, '') !~ '^https://' then raise exception 'invalid url'; end if;
  select cron_secret into sec from news_secret where id = 1;
  begin
    execute 'select cron.unschedule(''noble-news'')';
  exception when others then null;
  end;
  if h = 0 then return 'off'; end if;
  cmd := format('select net.http_post(url := %L, headers := %L::jsonb, body := %L::jsonb, timeout_milliseconds := 120000)',
    p_url, json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || coalesce(p_anon, ''), 'x-news-secret', sec)::text, '{"action":"fetch"}');
  begin
    execute format('select cron.schedule(%L, %L, %L)', 'noble-news', '7 */' || h || ' * * *', cmd);
  exception when others then
    raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة';
  end;
  return 'on';
end $$;

create or replace function public.admin_news_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'draft', (select count(*) from news_items where status = 'draft'),
    'today', (select count(*) from news_items where status = 'published' and published_at >= date_trunc('day', now())),
    'published', (select count(*) from news_items where status = 'published'),
    'views', (select coalesce(sum(views), 0) from news_items where published_at >= now() - interval '7 days'),
    'saves', (select coalesce(sum(saves), 0) from news_items where published_at >= now() - interval '7 days'));
end $$;

-- محاولة تفعيل الإضافات (تُتجاهل لو ما كانت متاحة)
do $$ begin
  begin create extension if not exists pg_cron; exception when others then null; end;
  begin create extension if not exists pg_net with schema extensions; exception when others then null; end;
end $$;

-- مصادر افتراضية (تقدر تعدّلها أو توقفها من اللوحة)
insert into public.news_sources (name, url, cat) values
  ('The Verge AI', 'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml', 'general'),
  ('TechCrunch AI', 'https://techcrunch.com/category/artificial-intelligence/feed/', 'companies'),
  ('OpenAI', 'https://openai.com/news/rss.xml', 'companies'),
  ('Google AI', 'https://blog.google/technology/ai/rss/', 'companies'),
  ('Hugging Face', 'https://huggingface.co/blog/feed.xml', 'tools')
on conflict (url) do nothing;

do $$
declare f text;
begin
  foreach f in array array['public.news_feed(text, timestamptz, int)', 'public.news_meta()', 'public.news_hit(bigint, text)',
    'public.admin_news_list(text, int)', 'public.admin_news_save(jsonb)', 'public.admin_news_set(bigint, text, boolean)', 'public.admin_news_delete(bigint)',
    'public.admin_news_sources()', 'public.admin_news_source_save(jsonb)', 'public.admin_news_source_delete(bigint)',
    'public.admin_news_settings()', 'public.admin_news_set_settings(jsonb)', 'public.admin_news_set_key(text)',
    'public.admin_news_schedule(text, text, int)', 'public.admin_news_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
