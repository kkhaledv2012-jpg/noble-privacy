-- =====================================================================
--  NOBLE — تحديث قاعدة البيانات للإصدار 1.17
--  صلاحيات الأقسام: ناس محددين بالاسم أو الإيميل أو نطاق الإيميل أو المجموعات، مع مدة، واستثناءات لكل مستخدم.
--  الصق الملف كاملاً في: Supabase → SQL Editor → New query → Run   (آمن للتشغيل أكثر من مرة)
-- =====================================================================

-- المجموعات (العائلة، عملاء، فريق…)
create table if not exists public.section_groups (
  id         text primary key,
  name       text not null default '',
  color      text not null default '#56C8FF',
  users      uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
-- صلاحيات كل قسم «👥 محددين»: allow = فقط هؤلاء · deny = الكل إلا هؤلاء
create table if not exists public.section_perms (
  sec        text primary key,
  mode       text not null default 'allow' check (mode in ('allow', 'deny')),
  users      uuid[] not null default '{}',
  groups     text[] not null default '{}',
  domains    text[] not null default '{}',
  until      jsonb  not null default '{}'::jsonb,   -- { "<user uuid>": "YYYY-MM-DD" } صلاحية لمدة
  updated_at timestamptz not null default now()
);
-- استثناء خاص لمستخدم: show = أظهره له · hide = أخفِه عنه
create table if not exists public.section_overrides (
  user_id uuid not null references auth.users(id) on delete cascade,
  sec     text not null,
  mode    text not null check (mode in ('show', 'hide')),
  primary key (user_id, sec)
);
alter table public.section_groups    enable row level security;
alter table public.section_perms     enable row level security;
alter table public.section_overrides enable row level security;
-- ما فيه سياسات = ما أحد يقرأها مباشرة؛ كل شي عبر الدوال تحت (ما تنكشف الإيميلات للمستخدمين)

-- ---------- للمستخدم: وش الأقسام المسموحة/الممنوعة له؟ ----------
create or replace function public.my_section_access()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  em  text;
  dom text;
  ok  text[] := '{}';
  no  text[] := '{}';
  r   record;
  hit boolean;
  exp text;
begin
  if uid is null then return json_build_object('ok', '[]'::json, 'no', '[]'::json, 'show', '[]'::json, 'hide', '[]'::json); end if;
  select lower(coalesce(email, '')) into em from profiles where id = uid;
  dom := split_part(coalesce(em, ''), '@', 2);
  for r in select * from section_perms loop
    hit := uid = any(r.users)
        or exists (select 1 from section_groups g where g.id = any(r.groups) and uid = any(g.users))
        or (dom <> '' and dom = any(r.domains));
    exp := r.until ->> uid::text;
    if hit and exp is not null and exp <> '' and exp::date < current_date then hit := false; end if;
    if (r.mode = 'allow' and hit) or (r.mode = 'deny' and not hit) then ok := ok || r.sec; else no := no || r.sec; end if;
  end loop;
  return json_build_object('ok', to_json(ok), 'no', to_json(no),
    'show', coalesce((select json_agg(sec) from section_overrides where user_id = uid and mode = 'show'), '[]'::json),
    'hide', coalesce((select json_agg(sec) from section_overrides where user_id = uid and mode = 'hide'), '[]'::json));
end $$;

-- ---------- للإدارة ----------
create or replace function public.admin_sections_get()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'perms', coalesce((select json_agg(row_to_json(p)) from section_perms p), '[]'::json),
    'groups', coalesce((select json_agg(row_to_json(g) order by g.created_at) from section_groups g), '[]'::json),
    'overrides', coalesce((select json_agg(row_to_json(o)) from section_overrides o), '[]'::json));
end $$;

create or replace function public.admin_section_perm_save(p_sec text, p_mode text, p_users uuid[], p_groups text[], p_domains text[], p_until jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  if p_sec is null or length(p_sec) > 30 then raise exception 'bad section'; end if;
  insert into section_perms (sec, mode, users, groups, domains, until, updated_at)
  values (p_sec, coalesce(nullif(p_mode, ''), 'allow'), coalesce(p_users, '{}'), coalesce(p_groups, '{}'),
          (select coalesce(array_agg(distinct lower(trim(d))), '{}') from unnest(coalesce(p_domains, '{}')) d where trim(d) <> ''), coalesce(p_until, '{}'::jsonb), now())
  on conflict (sec) do update set mode = excluded.mode, users = excluded.users, groups = excluded.groups, domains = excluded.domains, until = excluded.until, updated_at = now();
end $$;

create or replace function public.admin_section_perm_delete(p_sec text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  delete from section_perms where sec = p_sec;
end $$;

create or replace function public.admin_section_group_save(p_id text, p_name text, p_color text, p_users uuid[])
returns text language plpgsql security definer set search_path = public as $$
declare gid text := coalesce(nullif(p_id, ''), 'g' || substr(md5(random()::text || clock_timestamp()::text), 1, 10));
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  insert into section_groups (id, name, color, users) values (gid, left(coalesce(p_name, ''), 40), left(coalesce(p_color, '#56C8FF'), 20), coalesce(p_users, '{}'))
  on conflict (id) do update set name = excluded.name, color = excluded.color, users = excluded.users;
  return gid;
end $$;

create or replace function public.admin_section_group_delete(p_id text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  delete from section_groups where id = p_id;
  update section_perms set groups = array_remove(groups, p_id) where p_id = any(groups);
end $$;

create or replace function public.admin_section_override_set(p_user uuid, p_sec text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_mode, '') = '' then delete from section_overrides where user_id = p_user and sec = p_sec;
  else insert into section_overrides (user_id, sec, mode) values (p_user, p_sec, p_mode)
       on conflict (user_id, sec) do update set mode = excluded.mode; end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.my_section_access()', 'public.admin_sections_get()', 'public.admin_section_perm_save(text, text, uuid[], text[], text[], jsonb)', 'public.admin_section_perm_delete(text)',
    'public.admin_section_group_save(text, text, text, uuid[])', 'public.admin_section_group_delete(text)', 'public.admin_section_override_set(uuid, text, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
