-- =====================================================================
--  NOBLE — تحديث قاعدة البيانات للإصدار 1.2
--  الأدوار والصلاحيات، الرسائل، سجل النشاط، الألعاب ولوحة الصدارة
--  الصق الملف كاملاً في: Supabase → SQL Editor → New query → Run
--  (آمن للتشغيل أكثر من مرة)
-- =====================================================================

-- ---------- أعمدة جديدة في ملف المستخدم ----------
alter table public.profiles add column if not exists nickname text;
alter table public.profiles add column if not exists show_on_board boolean not null default true;
alter table public.profiles add column if not exists disabled_sections text[] not null default '{}';

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('owner', 'admin', 'moderator', 'editor', 'support', 'user'));

-- صاحب إيميل الأدمن يصبح «المالك»
update public.profiles set role = 'owner' where lower(email) = lower(public.admin_email());

-- ---------- الصلاحيات ----------
-- رتبة كل دور (الأعلى يتحكم فيمن تحته فقط)
create or replace function public.role_rank(p_role text) returns int
language sql immutable as $$
  select case p_role when 'owner' then 100 when 'admin' then 80 when 'moderator' then 60
                     when 'editor' then 40 when 'support' then 30 else 0 end;
$$;

create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid() and status = 'active';
$$;

create or replace function public.has_perm(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(p = any(public.role_perms(public.my_role())), false);
$$;

-- للتوافق مع الإصدار السابق: «أدمن» = من يملك إدارة المستخدمين أو رؤيتهم
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_perm('users.view');
$$;

create or replace function public.my_permissions() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object('role', coalesce(public.my_role(), 'user'), 'perms', public.role_perms(public.my_role()));
$$;

-- يمنع التحكم في من هو أعلى أو مساوٍ لك (إلا المالك)
create or replace function public.can_manage(p_uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select p_uid <> auth.uid() and (
    public.my_role() = 'owner' or
    public.role_rank(public.my_role()) > (select public.role_rank(role) from profiles where id = p_uid)
  );
$$;

-- ---------- سجل النشاط ----------
create table if not exists public.activity_log (
  id          bigserial primary key,
  actor       uuid,
  actor_email text,
  action      text not null,
  target      uuid,
  target_email text,
  meta        jsonb not null default '{}'::jsonb,
  at          timestamptz not null default now()
);
alter table public.activity_log enable row level security;
drop policy if exists "log: staff read" on public.activity_log;
create policy "log: staff read" on public.activity_log for select using (public.has_perm('logs.view'));

create or replace function public.log_action(p_action text, p_target uuid default null, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into activity_log (actor, actor_email, action, target, target_email, meta)
  values (auth.uid(), (select email from profiles where id = auth.uid()), p_action, p_target,
          (select email from profiles where id = p_target), coalesce(p_meta, '{}'::jsonb));
end $$;

-- نشاط يومي (يوم واحد لكل مستخدم) للرسوم البيانية
create table if not exists public.activity_daily (
  user_id uuid references auth.users(id) on delete cascade,
  day     date not null default current_date,
  primary key (user_id, day)
);
alter table public.activity_daily enable row level security;

-- ---------- تحديث دوال المستخدم ----------
create or replace function public.touch_profile(p_items integer, p_version text default null)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set last_seen_at = now(), items_count = greatest(0, coalesce(p_items, items_count)),
         app_version = coalesce(p_version, app_version)
   where id = auth.uid() returning * into r;
  insert into activity_daily (user_id) values (auth.uid()) on conflict do nothing;
  return r;
end $$;

create or replace function public.update_my_profile(p_name text, p_nickname text, p_show boolean)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set display_name = left(coalesce(p_name, ''), 80),
         nickname = nullif(left(trim(coalesce(p_nickname, '')), 24), ''),
         show_on_board = coalesce(p_show, true)
   where id = auth.uid() returning * into r;
  return r;
end $$;

-- مزامنة الإيميل عند تغييره من الحساب
create or replace function public.handle_user_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email is distinct from old.email then
    update profiles set email = new.email where id = new.id;
  end if;
  return new;
end $$;
drop trigger if exists on_auth_user_updated on auth.users;
create trigger on_auth_user_updated after update on auth.users
  for each row execute function public.handle_user_update();

-- المستخدم الجديد: المالك حسب الإيميل، وتسجيل الحدث
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', ''),
          case when lower(new.email) = lower(public.admin_email()) then 'owner' else 'user' end)
  on conflict (id) do nothing;
  insert into activity_log (actor, actor_email, action, target, target_email)
  values (new.id, new.email, 'signup', new.id, new.email);
  return new;
end $$;

-- ---------- دوال الإدارة بالصلاحيات ----------
create or replace function public.admin_set_status(p_uid uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  update profiles set status = p_status where id = p_uid;
  perform public.log_action(case when p_status = 'suspended' then 'suspend' else 'activate' end, p_uid);
end $$;

create or replace function public.admin_set_role(p_uid uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('roles.manage') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  if p_role = 'owner' or (public.my_role() <> 'owner' and public.role_rank(p_role) >= public.role_rank(public.my_role())) then
    raise exception 'not allowed';
  end if;
  update profiles set role = p_role where id = p_uid;
  perform public.log_action('role', p_uid, json_build_object('role', p_role)::jsonb);
end $$;

create or replace function public.admin_set_name(p_uid uuid, p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') then raise exception 'not allowed'; end if;
  update profiles set display_name = left(coalesce(p_name, ''), 80) where id = p_uid;
  perform public.log_action('rename', p_uid, json_build_object('name', p_name)::jsonb);
end $$;

create or replace function public.admin_delete_user(p_uid uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.has_perm('users.delete') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  perform public.log_action('delete', p_uid);
  delete from auth.users where id = p_uid;
end $$;

create or replace function public.admin_set_sections(p_uid uuid, p_sections text[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  update profiles set disabled_sections = coalesce(p_sections, '{}') where id = p_uid;
  perform public.log_action('sections', p_uid, json_build_object('off', p_sections)::jsonb);
end $$;

create or replace function public.admin_set_config(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  update app_config set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('content');
end $$;

create or replace function public.admin_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('stats.view') then raise exception 'not allowed'; end if;
  return json_build_object(
    'users',       (select count(*) from profiles),
    'active_7d',   (select count(*) from profiles where last_seen_at > now() - interval '7 days'),
    'new_7d',      (select count(*) from profiles where created_at  > now() - interval '7 days'),
    'suspended',   (select count(*) from profiles where status = 'suspended'),
    'admins',      (select count(*) from profiles where role <> 'user'),
    'total_items', (select coalesce(sum(items_count), 0) from profiles),
    'games_played',(select count(*) from game_scores),
    'signups', (select coalesce(json_agg(json_build_object('d', d, 'n', n) order by d), '[]'::json) from (
        select g::date d, (select count(*) from profiles where created_at::date = g::date) n
        from generate_series(current_date - 29, current_date, '1 day') g) s),
    'active', (select coalesce(json_agg(json_build_object('d', d, 'n', n) order by d), '[]'::json) from (
        select g::date d, (select count(*) from activity_daily where day = g::date) n
        from generate_series(current_date - 29, current_date, '1 day') g) s)
  );
end $$;

-- ---------- الرسائل ----------
create table if not exists public.messages (
  id         bigserial primary key,
  sender     uuid,
  target     uuid references auth.users(id) on delete cascade,  -- null = للجميع
  title      text not null,
  body       text not null default '',
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
drop policy if exists "messages: mine or broadcast" on public.messages;
create policy "messages: mine or broadcast" on public.messages for select
  using (target = auth.uid() or target is null or public.has_perm('messages.send') or public.has_perm('messages.broadcast'));

create or replace function public.admin_send_message(p_target uuid, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_target is null and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if p_target is not null and not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  insert into messages (sender, target, title, body) values (auth.uid(), p_target, left(p_title, 120), left(coalesce(p_body, ''), 2000));
  perform public.log_action('message', p_target, json_build_object('title', p_title)::jsonb);
end $$;

create or replace function public.admin_delete_message(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('messages.broadcast') or public.has_perm('messages.send')) then raise exception 'not allowed'; end if;
  delete from messages where id = p_id;
end $$;

-- ---------- الألعاب ولوحة الصدارة ----------
create table if not exists public.game_scores (
  id         bigserial primary key,
  user_id    uuid references auth.users(id) on delete cascade,
  game       text not null,
  score      integer not null check (score >= 0),
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists game_scores_time on public.game_scores (created_at);
alter table public.game_scores enable row level security;
drop policy if exists "scores: own read" on public.game_scores;
create policy "scores: own read" on public.game_scores for select using (user_id = auth.uid());

create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'tasks' then 50 else 1000 end;
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- لوحة الصدارة: اسم مستعار ونقاط فقط — بدون إيميلات أو معرّفات
create or replace function public.leaderboard(p_period text default 'week', p_limit integer default 50)
returns table (rank bigint, nickname text, points bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  with s as (
    select g.user_id, sum(g.score) pts
      from game_scores g
     where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                          when 'month' then now() - interval '30 days'
                                          else '-infinity'::timestamptz end
     group by g.user_id
  )
  select rank() over (order by s.pts desc),
         case when p.show_on_board then coalesce(nullif(p.nickname, ''), 'لاعب ' || upper(left(p.id::text, 4))) else 'لاعب مخفي' end,
         s.pts, s.user_id = auth.uid()
    from s join profiles p on p.id = s.user_id
   where p.status = 'active' and (p.show_on_board or s.user_id = auth.uid())
   order by s.pts desc
   limit least(p_limit, 100);
$$;

-- ---------- الصلاحيات على الدوال ----------
do $$
declare f text;
begin
  foreach f in array array[
    'public.my_permissions()', 'public.update_my_profile(text, text, boolean)', 'public.admin_set_sections(uuid, text[])',
    'public.admin_send_message(uuid, text, text)', 'public.admin_delete_message(bigint)', 'public.submit_score(text, integer, jsonb)',
    'public.leaderboard(text, integer)', 'public.touch_profile(integer, text)', 'public.admin_set_status(uuid, text)',
    'public.admin_set_role(uuid, text)', 'public.admin_set_name(uuid, text)', 'public.admin_delete_user(uuid)',
    'public.admin_set_config(jsonb)', 'public.admin_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
