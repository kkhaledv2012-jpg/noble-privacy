-- ============================================================
-- NOBLE 1.14 — التصاميم (قوالب، خلفيات صور/فيديو، خطوط، أصوات، مخطوطات) + كلمة اليوم + الأذكار
--  • قوالب ترفعها الإدارة (صورة + أماكن النصوص) — والمستخدم يكتب عليها ويحفظها أو يشاركها
--  • المناسبات والنصوص المقترحة والمواسم من لوحة التحكم ← التصاميم
--  • صور القوالب في Storage (مجلد designs عام للقراءة، والرفع للإدارة فقط)
-- شغّله مرة واحدة في SQL Editor بعد update-1.13.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.designs (
  id         bigserial primary key,
  data       jsonb not null default '{}'::jsonb,   -- {title, cat, size, image, slots[], premium, season{from,to}, tags}
  sort       integer not null default 0,
  active     boolean not null default true,
  uses       integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists designs_sort on public.designs (active, sort, id);

create table if not exists public.design_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {occasions[], texts{cat:[...]}, title, featured}
  updated_at timestamptz not null default now()
);
insert into public.design_settings (id) values (1) on conflict (id) do nothing;

alter table public.designs enable row level security;
alter table public.design_settings enable row level security;

-- للمستخدمين: القوالب المفعّلة + الإعدادات العامة
create or replace function public.designs_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from design_settings where id = 1),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'sort', d.sort) || d.data order by d.sort, d.id)
                       from designs d where d.active), '[]'::jsonb))
  where auth.uid() is not null;
$$;

-- عدّاد الاستخدام (كم مرة انحفظ/انشارك القالب)
create or replace function public.design_used(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update designs set uses = uses + 1 where id = p_id and active and auth.uid() is not null;
$$;

-- لوحة التحكم
create or replace function public.admin_designs()
returns setof designs language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  return query select * from designs order by sort, id;
end $$;

create or replace function public.admin_design_save(p_id bigint, p_data jsonb, p_sort integer default null, p_active boolean default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 30000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into designs (data, sort, active) values (coalesce(p_data, '{}'::jsonb), coalesce(p_sort, (select coalesce(max(sort), 0) + 1 from designs)), coalesce(p_active, true))
    returning id into nid;
  else
    update designs set data = coalesce(p_data, data), sort = coalesce(p_sort, sort), active = coalesce(p_active, active), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  perform public.log_action('design', null, json_build_object('id', nid)::jsonb);
  return nid;
end $$;

create or replace function public.admin_design_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  delete from designs where id = p_id;
end $$;

create or replace function public.admin_design_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 40000 then raise exception 'too large'; end if;
  update design_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

-- إحصائية بسيطة للوحة
create or replace function public.admin_design_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  return json_build_object('count', (select count(*) from designs), 'active', (select count(*) from designs where active),
    'uses', (select coalesce(sum(uses), 0) from designs));
end $$;

-- مجلد الصور (Storage): قراءة للجميع، والرفع والحذف للإدارة فقط
do $$ begin
  begin
    insert into storage.buckets (id, name, public) values ('designs', 'designs', true) on conflict (id) do update set public = true;
    execute 'drop policy if exists "designs: read" on storage.objects';
    execute 'create policy "designs: read" on storage.objects for select using (bucket_id = ''designs'')';
    execute 'drop policy if exists "designs: staff write" on storage.objects';
    execute 'create policy "designs: staff write" on storage.objects for insert with check (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
    execute 'drop policy if exists "designs: staff update" on storage.objects';
    execute 'create policy "designs: staff update" on storage.objects for update using (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
    execute 'drop policy if exists "designs: staff delete" on storage.objects';
    execute 'create policy "designs: staff delete" on storage.objects for delete using (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
  exception when others then
    raise notice 'Storage غير متاح هنا — أنشئ مجلد designs من Supabase ← Storage يدوياً (Public)';
  end;
end $$;

-- ---------- لعبة «كلمة اليوم»: نقاطها في الصدارة (حد أعلى ٦٠ للمحاولة) ----------
create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame', 'chase', 'word') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'chase' then 3000 when 'tasks' then 50 when 'word' then 120 when 'daily' then 100 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- ============================================================
-- الأذكار والأدعية (مجانية للجميع) — الإدارة تضيف وتعدّل، والتطبيق يعرضها عند الفتح وفي قسم «أذكاري»
-- ============================================================
create table if not exists public.azkar (
  id         bigserial primary key,
  data       jsonb not null default '{}'::jsonb,   -- {text, virtue, source, cat, count, pin{from,to}}
  sort       integer not null default 0,
  active     boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists azkar_sort on public.azkar (active, sort, id);
create table if not exists public.azkar_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {toast{on,style,pos,auto,freq,mode}, remind{on,morning,evening}, title, builtin}
  updated_at timestamptz not null default now()
);
insert into public.azkar_settings (id) values (1) on conflict (id) do nothing;
alter table public.azkar enable row level security;
alter table public.azkar_settings enable row level security;

create or replace function public.azkar_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from azkar_settings where id = 1),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', z.id, 'sort', z.sort) || z.data order by z.sort, z.id) from azkar z where z.active), '[]'::jsonb))
  where auth.uid() is not null;
$$;
create or replace function public.admin_azkar()
returns setof azkar language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return query select * from azkar order by sort, id;
end $$;
create or replace function public.admin_azkar_save(p_id bigint, p_data jsonb, p_sort integer default null, p_active boolean default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 8000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into azkar (data, sort, active) values (coalesce(p_data, '{}'::jsonb), coalesce(p_sort, (select coalesce(max(sort), 0) + 1 from azkar)), coalesce(p_active, true)) returning id into nid;
  else
    update azkar set data = coalesce(p_data, data), sort = coalesce(p_sort, sort), active = coalesce(p_active, active), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  return nid;
end $$;
create or replace function public.admin_azkar_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  delete from azkar where id = p_id;
end $$;
create or replace function public.admin_azkar_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update azkar_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.designs_list()', 'public.design_used(bigint)', 'public.admin_designs()', 'public.admin_design_save(bigint, jsonb, integer, boolean)',
    'public.admin_design_delete(bigint)', 'public.admin_design_meta(jsonb)', 'public.admin_design_stats()',
    'public.azkar_list()', 'public.admin_azkar()', 'public.admin_azkar_save(bigint, jsonb, integer, boolean)', 'public.admin_azkar_delete(bigint)', 'public.admin_azkar_meta(jsonb)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ---------- الأخبار: مصادر عربية موثوقة بدون ترجمة (1.14) ----------
-- المصدر العربي يُنشر من عنوانه ونبذته مباشرة (بدون Gemini ولا يستهلك الحد المجاني)،
-- إلا لو فعّلت له «صياغة AI» من لوحة التحكم ← الأخبار ← المصادر.
alter table public.news_sources add column if not exists lang text not null default 'en';
alter table public.news_sources add column if not exists rewrite boolean not null default false;

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, topic, country, active, lang, rewrite) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true),
      case when p_src->>'lang' = 'ar' then 'ar' else 'en' end, coalesce((p_src->>'rewrite')::boolean, false))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, topic = excluded.topic, country = excluded.country, active = excluded.active,
      lang = excluded.lang, rewrite = excluded.rewrite
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active),
      lang = case when p_src ? 'lang' then (case when p_src->>'lang' = 'ar' then 'ar' else 'en' end) else lang end,
      rewrite = coalesce((p_src->>'rewrite')::boolean, rewrite) where id = sid;
  end if;
  return sid;
end $$;
revoke all on function public.admin_news_source_save(jsonb) from anon, public;
grant execute on function public.admin_news_source_save(jsonb) to authenticated;

-- مجال «أخبار عامة» — يُضاف لقائمة المجالات لو كانت معدّلة من اللوحة (الافتراضي فيه أصلاً)
update public.news_settings
   set data = jsonb_set(data, '{domains}', jsonb_build_array(jsonb_build_object('id', 'news', 'ic', '📰', 'name', 'أخبار عامة', 'on', true,
     'subs', jsonb_build_array(jsonb_build_array('saudi', 'السعودية'), jsonb_build_array('gulf', 'الخليج'), jsonb_build_array('arab', 'العالم العربي'), jsonb_build_array('world', 'العالم'))))
     || (data->'domains'))
 where id = 1 and jsonb_typeof(data->'domains') = 'array' and jsonb_array_length(data->'domains') > 0
   and not exists (select 1 from jsonb_array_elements(data->'domains') d where d->>'id' = 'news');

-- مصادر عربية موثوقة (لو الرابط تغيّر عند المصدر يظهر «خطأ» جنبه في اللوحة وتقدر توقفه أو تعدّله)
insert into public.news_sources (name, url, cat, topic, country, lang, rewrite) values
  ('الجزيرة نت', 'https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9', 'news', '', '', 'ar', false),
  ('BBC عربي', 'https://feeds.bbci.co.uk/arabic/rss.xml', 'news', '', '', 'ar', false),
  ('سكاي نيوز عربية', 'https://www.skynewsarabia.com/rss.xml', 'news', '', '', 'ar', false),
  ('فرانس 24 عربي', 'https://www.france24.com/ar/rss', 'news', 'world', '', 'ar', false),
  ('DW عربية', 'https://rss.dw.com/rdf/rss-ar-all', 'news', 'world', '', 'ar', false),
  ('عكاظ', 'https://www.okaz.com.sa/rssFeed/0', 'news', 'saudi', 'sa', 'ar', false),
  ('البوابة العربية للأخبار التقنية', 'https://aitnews.com/feed/', 'tech', '', '', 'ar', false),
  ('عالم التقنية', 'https://www.tech-wd.com/wd/feed/', 'tech', '', '', 'ar', false)
on conflict (url) do nothing;
