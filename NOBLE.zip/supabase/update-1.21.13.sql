-- NOBLE 1.21.13 — ⏰ جدولة نشر أعداد «عاجل»: تجهّز العدد وتختار الوقت، وينتشر لحاله (كل ٥ دقايق نشيّك) + إشعار اختياري
-- الصق هذا مرة وحدة في Supabase ← SQL Editor ← Run  (يحتاج pg_cron و pg_net مفعّلين — نفس اللي يستخدمها سحب الأخبار)
alter table public.ai_issues add column if not exists publish_at timestamptz;
alter table public.ai_issues add column if not exists sched jsonb not null default '{}'::jsonb;  -- {pin, discover, notify}
create index if not exists ai_issues_due on public.ai_issues (publish_at) where status = 'draft' and publish_at is not null;

create table if not exists public.ai_sched_cfg (id int primary key default 1 check (id = 1), push_url text not null default '', anon text not null default '', updated_at timestamptz not null default now());
alter table public.ai_sched_cfg enable row level security;  -- ما أحد يقراه إلا الدوال

-- النشر نفسه (بدون فحص الصلاحية — تناديه الدوال اللي تفحص)
create or replace function public._ai_publish(p_id bigint, p_pin_days int, p_discover boolean)
returns void language plpgsql security definer set search_path = public as $$
declare i ai_issues; fid bigint;
begin
  select * into i from ai_issues where id = p_id; if i.id is null then return; end if;
  update ai_issues set status = 'published', published_at = now(), updated_at = now(), publish_at = null,
    pinned_until = case when p_pin_days is null then pinned_until when p_pin_days <= 0 then null else now() + make_interval(days => p_pin_days) end
  where id = p_id;
  if coalesce(p_discover, true) then
    if i.feed_id is not null and exists(select 1 from feed_items where id = i.feed_id) then
      update feed_items set active = true, data = data || jsonb_build_object('caption', i.title, 'media', jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image'))), updated_at = now() where id = i.feed_id;
    else
      insert into feed_items (kind, data) values ('post', jsonb_build_object('type', 'ai_issue', 'issue', i.id, 'caption', i.title,
        'media', case when i.cover_url <> '' then jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image')) else '[]'::jsonb end))
      returning id into fid;
      update ai_issues set feed_id = fid where id = p_id;
    end if;
  end if;
end $$;
revoke all on function public._ai_publish(bigint, int, boolean) from public, anon, authenticated;

-- جدولة / إلغاء (p_at = null يلغي)
create or replace function public.admin_ai_schedule_pub(p_id bigint, p_at timestamptz, p_pin int, p_discover boolean, p_notify boolean, p_push_url text, p_anon text)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare sec text; cmd text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if p_at is not null and p_at < now() - interval '2 minutes' then raise exception 'الوقت اللي اخترته راح — اختر وقت جاي'; end if;
  update ai_issues set publish_at = p_at, sched = jsonb_build_object('pin', p_pin, 'discover', coalesce(p_discover, true), 'notify', coalesce(p_notify, true)), updated_at = now()
    where id = p_id and status = 'draft';
  if not found then raise exception 'العدد منشور أو مو موجود'; end if;
  if p_at is not null then
    if coalesce(p_push_url, '') ~ '^https://' then
      insert into ai_sched_cfg (id, push_url, anon) values (1, p_push_url, coalesce(p_anon, '')) on conflict (id) do update set push_url = excluded.push_url, anon = excluded.anon, updated_at = now();
    end if;
    -- المهمة المتكررة (مرة وحدة تكفي): كل ٥ دقايق
    begin
      perform 1 from cron.job where jobname = 'noble-ai-pub';
      if not found then perform cron.schedule('noble-ai-pub', '*/5 * * * *', 'select public.ai_publish_due()'); end if;
    exception when others then raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة'; end;
  end if;
  return (select row_to_json(x) from (select id, status, publish_at, sched from ai_issues where id = p_id) x);
end $$;
revoke all on function public.admin_ai_schedule_pub(bigint, timestamptz, int, boolean, boolean, text, text) from public, anon;
grant execute on function public.admin_ai_schedule_pub(bigint, timestamptz, int, boolean, boolean, text, text) to authenticated;

-- اللي يشغّله الـcron: ينشر اللي جا وقته، ويطلب إشعار لو مفعّل
create or replace function public.ai_publish_due()
returns int language plpgsql security definer set search_path = public, extensions as $$
declare r record; n int := 0; c ai_sched_cfg; sec text;
begin
  select * into c from ai_sched_cfg where id = 1; select cron_secret into sec from news_secret where id = 1;
  for r in select id, sched from ai_issues where status = 'draft' and publish_at is not null and publish_at <= now() order by publish_at limit 10 loop
    perform public._ai_publish(r.id, nullif(r.sched->>'pin', '')::int, coalesce((r.sched->>'discover')::boolean, true));
    n := n + 1;
    if coalesce((r.sched->>'notify')::boolean, true) and c.push_url <> '' then
      begin
        perform net.http_post(url := c.push_url, headers := json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || c.anon, 'x-news-secret', coalesce(sec, ''))::jsonb,
          body := json_build_object('kind', 'issue', 'id', r.id)::jsonb, timeout_milliseconds := 30000);
      exception when others then null; end;
    end if;
  end loop;
  return n;
end $$;
revoke all on function public.ai_publish_due() from public, anon, authenticated;

-- لو نشرته بيدك قبل الموعد: نلغي الجدولة تلقائياً
create or replace function public._ai_unsched() returns trigger language plpgsql as $$
begin if new.status = 'published' then new.publish_at := null; end if; return new; end $$;
drop trigger if exists ai_issues_unsched on public.ai_issues;
create trigger ai_issues_unsched before update on public.ai_issues for each row execute function public._ai_unsched();
