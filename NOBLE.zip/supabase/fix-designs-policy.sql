-- NOBLE — إصلاح تنبيه Supabase: «Clients can list all files in this bucket» (مجلد designs)
-- الصور والفيديوهات تنقرأ بالرابط العام (المجلد Public) وما تحتاج هذي الصلاحية،
-- فنخلي «عرض قائمة الملفات» للإدارة بس (تحتاجها لحذف الملفات القديمة من اللوحة).
drop policy if exists "designs: read" on storage.objects;
drop policy if exists "designs: staff read" on storage.objects;
create policy "designs: staff read" on storage.objects for select
  using (bucket_id = 'designs' and (public.has_perm('content.edit') or public.has_perm('apps.manage') or public.has_perm('news.manage')));
