-- ============================================================
-- NOBLE 1.8 — الاشتراكات المدفوعة، الإعلانات، والتطبيقات المتعددة
--  • أسعار وعروض وأكواد خصم وأكواد تفعيل وطلبات دفع (تحويل بنكي / STC Pay)
--  • اشتراكات لكل تطبيق أو الباقة الكاملة
--  • إعلاناتك الخاصة مع إحصاءات المشاهدات والنقرات
-- شغّله مرة واحدة في SQL Editor بعد update-1.7.sql (آمن لو تكرر)
-- ============================================================

-- ---------- صلاحيات جديدة: الاشتراكات والتطبيقات ----------
create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view','apps.manage']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

-- ---------- إعدادات السوق: الأسعار والعروض والإعلانات والتطبيقات ----------
alter table public.app_config add column if not exists market jsonb not null default '{}'::jsonb;

create or replace function public.admin_set_market(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('billing.manage') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 200000 then raise exception 'too large'; end if;
  update app_config set market = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('market');
end $$;

-- ---------- الاشتراكات الفعّالة ----------
create table if not exists public.entitlements (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  app        text not null,                         -- vault | tasks | finance | games | all
  plan       text not null default 'y',             -- m | y | l | custom
  until      timestamptz,                           -- null = مدى الحياة
  source     text not null default 'admin',         -- code | payment | admin | gateway
  ref        text not null default '',
  amount     numeric not null default 0,
  revoked    boolean not null default false,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists entitlements_user on public.entitlements (user_id);
alter table public.entitlements enable row level security;
drop policy if exists "ent: mine or staff" on public.entitlements;
create policy "ent: mine or staff" on public.entitlements for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

create or replace function public.plan_until(p_plan text, p_from timestamptz default now())
returns timestamptz language sql immutable as $$
  select case p_plan when 'm' then p_from + interval '1 month' when 'y' then p_from + interval '1 year' when 'l' then null else p_from + interval '1 month' end;
$$;

-- يمدّد الاشتراك إن كان فعّالاً لنفس التطبيق (لا يضيع وقت متبقٍ)
create or replace function public.grant_entitlement(p_uid uuid, p_app text, p_plan text, p_source text, p_ref text, p_amount numeric)
returns bigint language plpgsql security definer set search_path = public as $$
declare base timestamptz; cur timestamptz; eid bigint;
begin
  select max(until) into cur from entitlements where user_id = p_uid and app = p_app and not revoked and until is not null and until > now();
  base := coalesce(cur, now());
  insert into entitlements (user_id, app, plan, until, source, ref, amount, created_by)
  values (p_uid, p_app, p_plan, public.plan_until(p_plan, base), p_source, left(coalesce(p_ref, ''), 80), coalesce(p_amount, 0), auth.uid())
  returning id into eid;
  return eid;
end $$;
revoke all on function public.grant_entitlement(uuid, text, text, text, text, numeric) from anon, public, authenticated;

create or replace function public.my_entitlements()
returns table (id bigint, app text, plan text, until timestamptz, source text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select e.id, e.app, e.plan, e.until, e.source, e.created_at from entitlements e
   where e.user_id = auth.uid() and not e.revoked and (e.until is null or e.until > now())
   order by e.id desc;
$$;

-- ---------- أكواد التفعيل ----------
create table if not exists public.activation_codes (
  code       text primary key,
  app        text not null,
  plan       text not null,
  price      numeric not null default 0,
  note       text not null default '',
  status     text not null default 'new' check (status in ('new', 'used', 'revoked')),
  used_by    uuid references auth.users(id) on delete set null,
  used_at    timestamptz,
  created_by uuid,
  created_at timestamptz not null default now()
);
alter table public.activation_codes enable row level security;
drop policy if exists "codes: staff" on public.activation_codes;
create policy "codes: staff" on public.activation_codes for select using (public.has_perm('billing.manage'));

create or replace function public.admin_generate_codes(p_n integer, p_app text, p_plan text, p_price numeric default 0, p_note text default '')
returns setof text language plpgsql security definer set search_path = public as $$
declare i integer; c text; chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  if p_n < 1 or p_n > 100 then raise exception 'invalid count'; end if;
  for i in 1..p_n loop
    loop
      c := 'NOBLE-' || (select string_agg(substr(chars, 1 + floor(random() * length(chars))::int, 1), '') from generate_series(1, 4))
                || '-' || (select string_agg(substr(chars, 1 + floor(random() * length(chars))::int, 1), '') from generate_series(1, 4));
      exit when not exists (select 1 from activation_codes where code = c);
    end loop;
    insert into activation_codes (code, app, plan, price, note, created_by) values (c, p_app, p_plan, coalesce(p_price, 0), left(coalesce(p_note, ''), 120), auth.uid());
    return next c;
  end loop;
  perform public.log_action('codes', null, json_build_object('n', p_n, 'app', p_app, 'plan', p_plan)::jsonb);
end $$;

create or replace function public.redeem_code(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare r activation_codes; eid bigint;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  select * into r from activation_codes where code = upper(trim(p_code)) for update;
  if not found then raise exception 'invalid code'; end if;
  if r.status = 'used' then raise exception 'code used'; end if;
  if r.status = 'revoked' then raise exception 'code revoked'; end if;
  eid := public.grant_entitlement(auth.uid(), r.app, r.plan, 'code', r.code, r.price);
  update activation_codes set status = 'used', used_by = auth.uid(), used_at = now() where code = r.code;
  perform public.log_action('redeem', auth.uid(), json_build_object('code', r.code, 'app', r.app, 'plan', r.plan)::jsonb);
  return json_build_object('app', r.app, 'plan', r.plan);
end $$;

create or replace function public.admin_codes(p_limit integer default 200)
returns table (code text, app text, plan text, price numeric, note text, status text, used_email text, used_at timestamptz, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select c.code, c.app, c.plan, c.price, c.note, c.status, p.email, c.used_at, c.created_at
    from activation_codes c left join profiles p on p.id = c.used_by order by c.created_at desc limit least(p_limit, 500);
end $$;

create or replace function public.admin_revoke_code(p_code text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update activation_codes set status = 'revoked' where code = p_code and status = 'new';
end $$;

-- ---------- أكواد الخصم ----------
create table if not exists public.discount_codes (
  code       text primary key,
  pct        integer not null check (pct between 1 and 100),
  apps       text[],                 -- null = كل التطبيقات
  plans      text[],                 -- null = كل الخطط
  max_uses   integer,                -- null = بلا حد
  used       integer not null default 0,
  until      timestamptz,
  active     boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.discount_codes enable row level security;
drop policy if exists "disc: staff" on public.discount_codes;
create policy "disc: staff" on public.discount_codes for select using (public.has_perm('billing.manage'));

create or replace function public.check_discount(p_code text, p_app text, p_plan text)
returns integer language plpgsql stable security definer set search_path = public as $$
declare d discount_codes;
begin
  select * into d from discount_codes where code = upper(trim(p_code));
  if not found or not d.active then raise exception 'invalid discount'; end if;
  if d.until is not null and d.until < now() then raise exception 'discount expired'; end if;
  if d.max_uses is not null and d.used >= d.max_uses then raise exception 'discount used up'; end if;
  if d.apps is not null and not (p_app = any(d.apps)) then raise exception 'discount not for this'; end if;
  if d.plans is not null and not (p_plan = any(d.plans)) then raise exception 'discount not for this'; end if;
  return d.pct;
end $$;

create or replace function public.admin_set_discount(p_code text, p_pct integer, p_apps text[], p_plans text[], p_max integer, p_until timestamptz, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  insert into discount_codes (code, pct, apps, plans, max_uses, until, active)
  values (upper(trim(p_code)), p_pct, nullif(p_apps, '{}'), nullif(p_plans, '{}'), p_max, p_until, coalesce(p_active, true))
  on conflict (code) do update set pct = excluded.pct, apps = excluded.apps, plans = excluded.plans, max_uses = excluded.max_uses, until = excluded.until, active = excluded.active;
end $$;

create or replace function public.admin_delete_discount(p_code text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  delete from discount_codes where code = p_code;
end $$;

create or replace function public.admin_discounts()
returns setof public.discount_codes language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select * from discount_codes order by created_at desc;
end $$;

-- ---------- طلبات الدفع (تحويل بنكي / STC Pay) ----------
create table if not exists public.payment_requests (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  app        text not null,
  plan       text not null,
  amount     numeric not null default 0,
  discount   text not null default '',
  method     text not null default 'bank',
  ref        text not null default '',
  note       text not null default '',
  status     text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  decided_by uuid,
  decided_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists payreq_status on public.payment_requests (status, created_at desc);
alter table public.payment_requests enable row level security;
drop policy if exists "pay: mine or staff" on public.payment_requests;
create policy "pay: mine or staff" on public.payment_requests for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

create or replace function public.submit_payment(p_app text, p_plan text, p_amount numeric, p_discount text, p_method text, p_ref text, p_note text)
returns bigint language plpgsql security definer set search_path = public as $$
declare pid bigint;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if (select count(*) from payment_requests where user_id = auth.uid() and status = 'pending') >= 3 then raise exception 'too many pending'; end if;
  insert into payment_requests (user_id, app, plan, amount, discount, method, ref, note)
  values (auth.uid(), left(p_app, 20), left(p_plan, 4), greatest(0, coalesce(p_amount, 0)), upper(left(coalesce(p_discount, ''), 30)), left(coalesce(p_method, 'bank'), 20), left(coalesce(p_ref, ''), 80), left(coalesce(p_note, ''), 300))
  returning id into pid;
  return pid;
end $$;

create or replace function public.my_payments()
returns table (id bigint, app text, plan text, amount numeric, status text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select id, app, plan, amount, status, created_at from payment_requests where user_id = auth.uid() order by id desc limit 10;
$$;

create or replace function public.admin_payments(p_status text default null)
returns table (id bigint, user_id uuid, email text, name text, app text, plan text, amount numeric, discount text, method text, ref text, note text, status text, created_at timestamptz, decided_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select r.id, r.user_id, p.email, p.display_name, r.app, r.plan, r.amount, r.discount, r.method, r.ref, r.note, r.status, r.created_at, r.decided_at
    from payment_requests r left join profiles p on p.id = r.user_id
   where p_status is null or r.status = p_status order by r.id desc limit 300;
end $$;

create or replace function public.admin_decide_payment(p_id bigint, p_ok boolean)
returns void language plpgsql security definer set search_path = public as $$
declare r payment_requests;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  select * into r from payment_requests where id = p_id for update;
  if not found or r.status <> 'pending' then raise exception 'not pending'; end if;
  update payment_requests set status = case when p_ok then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_at = now() where id = p_id;
  if p_ok then
    perform public.grant_entitlement(r.user_id, r.app, r.plan, 'payment', 'pay#' || r.id, r.amount);
    if r.discount <> '' then update discount_codes set used = used + 1 where code = r.discount; end if;
  end if;
  perform public.log_action('payment', r.user_id, json_build_object('ok', p_ok, 'app', r.app, 'plan', r.plan, 'amount', r.amount)::jsonb);
end $$;

-- ---------- تفعيل يدوي من اللوحة ----------
create or replace function public.admin_grant_pro(p_uid uuid, p_app text, p_plan text, p_amount numeric default 0, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare eid bigint;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  eid := public.grant_entitlement(p_uid, p_app, p_plan, 'admin', p_note, p_amount);
  perform public.log_action('pro', p_uid, json_build_object('app', p_app, 'plan', p_plan)::jsonb);
  return eid;
end $$;

create or replace function public.admin_revoke_entitlement(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update entitlements set revoked = true where id = p_id;
end $$;

create or replace function public.admin_subscribers()
returns table (id bigint, user_id uuid, email text, name text, app text, plan text, until timestamptz, source text, amount numeric, revoked boolean, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select e.id, e.user_id, p.email, p.display_name, e.app, e.plan, e.until, e.source, e.amount, e.revoked, e.created_at
    from entitlements e left join profiles p on p.id = e.user_id order by e.id desc limit 500;
end $$;

create or replace function public.admin_billing_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'revenue_month', (select coalesce(sum(amount), 0) from entitlements where not revoked and created_at >= date_trunc('month', now())),
    'revenue_total', (select coalesce(sum(amount), 0) from entitlements where not revoked),
    'active', (select count(distinct user_id) from entitlements where not revoked and (until is null or until > now())),
    'expiring', (select count(*) from entitlements where not revoked and until between now() and now() + interval '7 days'),
    'pending', (select count(*) from payment_requests where status = 'pending'),
    'by_app', (select coalesce(json_object_agg(app, n), '{}'::json) from (select app, count(distinct user_id) n from entitlements where not revoked and (until is null or until > now()) group by app) t)
  );
end $$;

-- ---------- إحصاءات إعلاناتك ----------
create table if not exists public.ad_stats (
  ad_id  text not null,
  day    date not null default current_date,
  app    text not null default '',
  views  integer not null default 0,
  clicks integer not null default 0,
  primary key (ad_id, day, app)
);
alter table public.ad_stats enable row level security;
drop policy if exists "ads: staff" on public.ad_stats;
create policy "ads: staff" on public.ad_stats for select using (public.has_perm('apps.manage') or public.has_perm('billing.manage'));

create or replace function public.ad_event(p_ad text, p_kind text, p_app text default '')
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into ad_stats (ad_id, day, app, views, clicks)
  values (left(p_ad, 40), current_date, left(coalesce(p_app, ''), 20), case when p_kind = 'v' then 1 else 0 end, case when p_kind = 'c' then 1 else 0 end)
  on conflict (ad_id, day, app) do update set views = ad_stats.views + excluded.views, clicks = ad_stats.clicks + excluded.clicks;
end $$;

create or replace function public.admin_ad_stats(p_days integer default 30)
returns table (ad_id text, views bigint, clicks bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('apps.manage') or public.has_perm('billing.manage')) then raise exception 'not allowed'; end if;
  return query select s.ad_id, sum(s.views)::bigint, sum(s.clicks)::bigint from ad_stats s where s.day > current_date - p_days group by s.ad_id;
end $$;

-- المزامنة الفورية لاشتراكات المستخدم (يتفعل Pro عنده لحظة الموافقة)
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'entitlements') then
    execute 'alter publication supabase_realtime add table public.entitlements';
  end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_set_market(jsonb)', 'public.my_entitlements()', 'public.admin_generate_codes(integer, text, text, numeric, text)',
    'public.redeem_code(text)', 'public.admin_codes(integer)', 'public.admin_revoke_code(text)', 'public.check_discount(text, text, text)',
    'public.admin_set_discount(text, integer, text[], text[], integer, timestamptz, boolean)', 'public.admin_delete_discount(text)', 'public.admin_discounts()',
    'public.submit_payment(text, text, numeric, text, text, text, text)', 'public.my_payments()', 'public.admin_payments(text)', 'public.admin_decide_payment(bigint, boolean)',
    'public.admin_grant_pro(uuid, text, text, numeric, text)', 'public.admin_revoke_entitlement(bigint)', 'public.admin_subscribers()', 'public.admin_billing_stats()',
    'public.ad_event(text, text, text)', 'public.admin_ad_stats(integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
