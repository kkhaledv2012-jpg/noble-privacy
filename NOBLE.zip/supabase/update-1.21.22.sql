-- =====================================================================
-- NOBLE 1.21.22 — 🖼️ إشعارات بالصورة الكبيرة + إشعارات اللوحة توصل حتى والتطبيق مسكّر
-- الصقه في Supabase ← SQL Editor ← Run (آمن تعيده أكثر من مرة)
-- =====================================================================
alter table public.push_notes add column if not exists fcm boolean not null default false;   -- انرسل عن طريق Firebase
alter table public.push_notes add column if not exists image text not null default '';       -- 'def' = الافتراضية / رابط / '' بدون

create or replace function public.admin_push_save(p jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_t uuid[];
begin
  v_t := coalesce((select array_agg(x::uuid) from jsonb_array_elements_text(coalesce(p->'targets', '[]'::jsonb)) x), '{}');
  if cardinality(v_t) = 0 and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if cardinality(v_t) > 0 and not (public.has_perm('messages.send') or public.has_perm('messages.broadcast')) then raise exception 'not allowed'; end if;
  if coalesce(trim(p->>'title'), '') = '' then raise exception 'العنوان مطلوب'; end if;
  if (p->>'id') is not null then
    update push_notes set title = left(p->>'title', 80), body = left(coalesce(p->>'body', ''), 240), tab = coalesce(p->>'tab', ''),
      link = coalesce(p->>'link', ''), send_at = coalesce((p->>'send_at')::timestamptz, send_at), targets = v_t,
      icon = coalesce(nullif(p->>'icon', ''), 'noble'),
      fcm = coalesce((p->>'fcm')::boolean, fcm), image = left(coalesce(p->>'image', image), 600)
     where id = (p->>'id')::bigint returning id into v_id;
  else
    insert into push_notes (title, body, tab, link, send_at, targets, icon, fcm, image)
    values (left(p->>'title', 80), left(coalesce(p->>'body', ''), 240), coalesce(p->>'tab', ''), coalesce(p->>'link', ''),
            coalesce((p->>'send_at')::timestamptz, now()), v_t, coalesce(nullif(p->>'icon', ''), 'noble'),
            coalesce((p->>'fcm')::boolean, false), left(coalesce(p->>'image', ''), 600)) returning id into v_id;
  end if;
  return v_id;
end $$;

-- اللي انرسل بـ Firebase ما يطلع مرة ثانية لما يفتح المستخدم التطبيق
create or replace function public.my_push_notes()
returns table (id bigint, title text, body text, tab text, link text, send_at timestamptz, icon text)
language sql stable security definer set search_path = public as $$
  select n.id, n.title, n.body, n.tab, n.link, n.send_at, n.icon from push_notes n
   where auth.uid() is not null and n.active and not n.fcm
     and (cardinality(n.targets) = 0 or auth.uid() = any(n.targets))
     and n.send_at > now() - interval '2 days' and n.send_at < now() + interval '14 days'
   order by n.send_at limit 30;
$$;

revoke all on function public.my_push_notes(), public.admin_push_save(jsonb) from public, anon;
grant execute on function public.my_push_notes(), public.admin_push_save(jsonb) to authenticated;
