-- ============================================================
-- NOBLE 1.9 — الأقسام بالاشتراك وفترة التجربة، منح الأقسام، واسترجاع الحساب بالإيميل
--  • فترة تجربة لكل مستخدم تبدأ من أول فتح للتحديث (لا تتصفّر بحذف التطبيق)
--  • منح قسم لأي مستخدم لتاريخ تحدده
--  • مفتاح استرجاع البيانات (تلقائي أو بكود خاص) — للمستخدم نفسه فقط
-- شغّله مرة واحدة في SQL Editor بعد update-1.8.sql (آمن لو تكرر)
-- ============================================================

-- ---------- فترة التجربة لكل مستخدم ----------
create table if not exists public.user_access (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  trial_from  timestamptz not null default now(),
  trial_until timestamptz,                 -- تحديد يدوي من الإدارة (يتقدّم على الحساب التلقائي)
  updated_at  timestamptz not null default now()
);
alter table public.user_access enable row level security;
drop policy if exists "access: mine or staff" on public.user_access;
create policy "access: mine or staff" on public.user_access for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

-- يرجع بداية التجربة (وينشئها أول مرة) + وقت السيرفر
create or replace function public.my_access()
returns json language plpgsql security definer set search_path = public as $$
declare r user_access;
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  insert into user_access (user_id) values (auth.uid()) on conflict (user_id) do nothing;
  select * into r from user_access where user_id = auth.uid();
  return json_build_object('trial_from', r.trial_from, 'trial_until', r.trial_until, 'now', now());
end $$;

create or replace function public.admin_user_access(p_uid uuid)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'access', (select row_to_json(a) from user_access a where a.user_id = p_uid),
    'ents', coalesce((select json_agg(row_to_json(e) order by e.id desc) from entitlements e where e.user_id = p_uid and not e.revoked), '[]'::json));
end $$;

create or replace function public.admin_access_list()
returns table (user_id uuid, trial_from timestamptz, trial_until timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select a.user_id, a.trial_from, a.trial_until from user_access a;
end $$;

-- تحديد نهاية التجربة لمستخدم (null = حسب الإعداد العام)
create or replace function public.admin_set_trial(p_uid uuid, p_until timestamptz)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  insert into user_access (user_id, trial_until, updated_at) values (p_uid, p_until, now())
  on conflict (user_id) do update set trial_until = excluded.trial_until, updated_at = now();
  perform public.log_action('trial', p_uid, json_build_object('until', p_until)::jsonb);
end $$;

-- منح قسم لمستخدم حتى تاريخ معيّن (null = بدون نهاية)
create or replace function public.admin_grant_section(p_uid uuid, p_app text, p_until timestamptz, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare eid bigint;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  -- منح جديد يستبدل المنح اليدوي السابق لنفس القسم
  update entitlements set revoked = true where user_id = p_uid and app = p_app and source = 'admin' and not revoked;
  insert into entitlements (user_id, app, plan, until, source, ref, amount, created_by)
  values (p_uid, left(p_app, 20), 'custom', p_until, 'admin', left(coalesce(p_note, ''), 80), 0, auth.uid())
  returning id into eid;
  perform public.log_action('pro', p_uid, json_build_object('app', p_app, 'until', p_until)::jsonb);
  return eid;
end $$;

-- إيقاف كل اشتراكات قسم لمستخدم (يقفل القسم)
create or replace function public.admin_lock_section(p_uid uuid, p_app text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update entitlements set revoked = true where user_id = p_uid and app = p_app and not revoked;
end $$;

-- ---------- مفتاح استرجاع البيانات (للمستخدم نفسه فقط) ----------
create table if not exists public.user_keys (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_keys enable row level security;
drop policy if exists "keys: mine" on public.user_keys;
create policy "keys: mine" on public.user_keys for select using (user_id = auth.uid());

create or replace function public.set_my_key(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 4000 then raise exception 'too large'; end if;
  insert into user_keys (user_id, data, updated_at) values (auth.uid(), coalesce(p_data, '{}'::jsonb), now())
  on conflict (user_id) do update set data = excluded.data, updated_at = now();
end $$;

create or replace function public.my_key()
returns jsonb language sql stable security definer set search_path = public as $$
  select data from user_keys where user_id = auth.uid();
$$;

-- ---------- لعبة المطاردة: نقاطها في الصدارة ----------
create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame', 'chase') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'chase' then 3000 when 'tasks' then 50 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.my_access()', 'public.admin_user_access(uuid)', 'public.admin_access_list()', 'public.admin_set_trial(uuid, timestamptz)',
    'public.admin_grant_section(uuid, text, timestamptz, text)', 'public.admin_lock_section(uuid, text)',
    'public.set_my_key(jsonb)', 'public.my_key()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
