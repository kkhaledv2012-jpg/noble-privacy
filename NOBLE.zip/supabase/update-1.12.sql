-- ============================================================
-- NOBLE 1.12 — «يومي» والإضافة السريعة بالذكاء الاصطناعي وتقاريري
--  • حد يومي لكل مستخدم للإضافة السريعة (يحمي حصة Gemini المجانية)
-- شغّله مرة واحدة في SQL Editor بعد update-1.10.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day     date not null default current_date,
  n       integer not null default 0,
  primary key (user_id, day)
);
alter table public.ai_usage enable row level security;  -- بدون سياسات: الوصول عبر الدالة فقط

-- يحجز استخداماً واحداً لليوم إن كان ضمن الحد — يرجّع {ok, used}
create or replace function public.ai_use(p_max integer default 40)
returns json language plpgsql security definer set search_path = public as $$
declare c integer; lim integer := least(greatest(coalesce(p_max, 40), 1), 500);
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  insert into ai_usage (user_id, day, n) values (auth.uid(), current_date, 1)
  on conflict (user_id, day) do update set n = ai_usage.n + 1
  returning n into c;
  if c > lim then
    update ai_usage set n = n - 1 where user_id = auth.uid() and day = current_date;
    return json_build_object('ok', false, 'used', c - 1, 'max', lim);
  end if;
  if random() < 0.02 then delete from ai_usage where day < current_date - 60; end if;
  return json_build_object('ok', true, 'used', c, 'max', lim);
end $$;

-- إحصائية للوحة التحكم: استخدام الإضافة السريعة
create or replace function public.admin_ai_usage(p_days integer default 14)
returns table (day date, users bigint, uses bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('news.manage') or public.has_perm('stats.view')) then raise exception 'not allowed'; end if;
  return query select a.day, count(*)::bigint, coalesce(sum(a.n), 0)::bigint from ai_usage a
    where a.day >= current_date - least(greatest(coalesce(p_days, 14), 1), 60) group by a.day order by a.day;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.ai_use(integer)', 'public.admin_ai_usage(integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
