-- NOBLE 1.21.8 — 🔔 إشعارات فورية (Firebase) — الصقه مرة وحدة: Supabase ← SQL Editor ← New query ← الصق ← Run
-- رموز الأجهزة (token) اللي يعطيها Firebase لكل جوال — بدون أي معلومة شخصية، وتنحذف مع الحساب
create table if not exists public.push_tokens (
  token      text primary key,
  user_id    uuid references auth.users(id) on delete cascade,
  app        text not null default 'nobleweb',
  platform   text not null default 'android',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists push_tokens_user on public.push_tokens (user_id);
alter table public.push_tokens enable row level security; -- الوصول عبر الدوال فقط

-- سجل الإشعارات اللي انرسلت (للحد اليومي ودمج الدفعات)
create table if not exists public.push_log (
  id      bigserial primary key,
  kind    text not null,             -- news_batch | news_one | test
  title   text not null default '',
  body    text not null default '',
  n       int not null default 1,     -- كم خبر في الدفعة
  sent    int not null default 0,     -- كم جهاز وصله
  failed  int not null default 0,
  at      timestamptz not null default now()
);
alter table public.push_log enable row level security;

create or replace function public.push_token_save(p_token text, p_app text default 'nobleweb', p_platform text default 'android')
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or length(coalesce(p_token, '')) < 20 then return; end if;
  insert into push_tokens (token, user_id, app, platform, updated_at)
  values (left(p_token, 400), auth.uid(), left(coalesce(p_app, 'nobleweb'), 20), left(coalesce(p_platform, 'android'), 20), now())
  on conflict (token) do update set user_id = auth.uid(), app = excluded.app, platform = excluded.platform, updated_at = now();
end $$;

create or replace function public.push_token_drop(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from push_tokens where token = p_token and (user_id = auth.uid() or auth.uid() is null);
end $$;

-- للوحة: كم جهاز مسجّل + آخر الإشعارات
create or replace function public.admin_push_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'devices', (select count(*) from push_tokens),
    'users', (select count(distinct user_id) from push_tokens),
    'today', (select count(*) from push_log where kind = 'news_batch' and at > date_trunc('day', now() at time zone 'Asia/Riyadh') at time zone 'Asia/Riyadh'),
    'log', coalesce((select json_agg(row_to_json(l) order by l.id desc) from (select * from push_log order by id desc limit 15) l), '[]'::json));
end $$;

revoke all on function public.push_token_save(text, text, text) from public, anon;
revoke all on function public.push_token_drop(text) from public, anon;
revoke all on function public.admin_push_stats() from public, anon;
grant execute on function public.push_token_save(text, text, text) to authenticated;
grant execute on function public.push_token_drop(text) to authenticated;
grant execute on function public.admin_push_stats() to authenticated;
