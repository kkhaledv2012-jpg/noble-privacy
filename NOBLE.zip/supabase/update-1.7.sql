-- ============================================================
-- NOBLE 1.7 — العمل بدون نت + متابعة المستخدمين في لوحة التحكم
--  • التطبيق يسجّل ما يحدث (حتى بدون نت) ويرفعه عند رجوع الاتصال بوقته الحقيقي
--  • ملخص لكل مستخدم: تقدّم الألعاب، أرقام الاستخدام (بدون محتوى)، حالة الجهاز
-- شغّله مرة واحدة في SQL Editor بعد update-1.5.sql (آمن لو تكرر)
-- ============================================================

-- ---------- سجل الأحداث ----------
create table if not exists public.user_events (
  id          bigserial primary key,
  user_id     uuid not null references auth.users(id) on delete cascade,
  type        text not null,
  data        jsonb not null default '{}'::jsonb,
  at          timestamptz not null,               -- وقت حدوثه على الجهاز
  offline     boolean not null default false,     -- حدث وهو بدون نت
  received_at timestamptz not null default now()
);
create index if not exists user_events_user_at on public.user_events (user_id, at desc);
alter table public.user_events enable row level security;
drop policy if exists "events: staff read" on public.user_events;
create policy "events: staff read" on public.user_events for select using (public.has_perm('users.view'));

-- ---------- ملخص المستخدم ----------
create table if not exists public.user_stats (
  user_id      uuid primary key references auth.users(id) on delete cascade,
  stats        jsonb not null default '{}'::jsonb,
  version      text not null default '',
  platform     text not null default '',
  last_sync    timestamptz not null default now(),
  offline_from timestamptz,
  updated_at   timestamptz not null default now()
);
alter table public.user_stats enable row level security;
drop policy if exists "stats: staff read" on public.user_stats;
create policy "stats: staff read" on public.user_stats for select using (public.has_perm('users.view') or user_id = auth.uid());

-- يرفع دفعة أحداث (حتى 200) — الوقت يُضبط ضمن حدود معقولة
create or replace function public.track_events(p_events jsonb)
returns integer language plpgsql security definer set search_path = public as $$
declare n integer := 0; e jsonb; t timestamptz;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if jsonb_typeof(p_events) <> 'array' then return 0; end if;
  for e in select * from jsonb_array_elements(p_events) limit 200 loop
    begin t := (e->>'at')::timestamptz; exception when others then t := now(); end;
    if t is null or t > now() + interval '10 minutes' then t := now(); end if;
    if t < now() - interval '120 days' then t := now() - interval '120 days'; end if;
    insert into user_events (user_id, type, data, at, offline)
    values (auth.uid(), left(coalesce(e->>'type', 'event'), 40),
            case when jsonb_typeof(e->'data') = 'object' and length((e->'data')::text) < 2000 then e->'data' else '{}'::jsonb end,
            t, coalesce((e->>'offline')::boolean, false));
    n := n + 1;
  end loop;
  -- تنظيف: نحتفظ بآخر 120 يوماً فقط
  delete from user_events where user_id = auth.uid() and at < now() - interval '120 days';
  return n;
end $$;

-- يحدّث ملخص المستخدم
create or replace function public.sync_user_stats(p_stats jsonb, p_version text, p_platform text, p_offline_from timestamptz default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if length(coalesce(p_stats, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  insert into user_stats (user_id, stats, version, platform, last_sync, offline_from, updated_at)
  values (auth.uid(), coalesce(p_stats, '{}'::jsonb), left(coalesce(p_version, ''), 20), left(coalesce(p_platform, ''), 20), now(), p_offline_from, now())
  on conflict (user_id) do update set stats = excluded.stats, version = excluded.version, platform = excluded.platform,
    last_sync = now(), offline_from = excluded.offline_from, updated_at = now();
end $$;

-- ---------- للإدارة ----------
create or replace function public.admin_user_stats()
returns table (user_id uuid, stats jsonb, version text, platform text, last_sync timestamptz, offline_from timestamptz, events_7d bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query
  select s.user_id, s.stats, s.version, s.platform, s.last_sync, s.offline_from,
         (select count(*) from user_events e where e.user_id = s.user_id and e.at > now() - interval '7 days')
    from user_stats s;
end $$;

create or replace function public.admin_user_events(p_uid uuid, p_limit integer default 100, p_before timestamptz default null)
returns table (id bigint, type text, data jsonb, at timestamptz, offline boolean, received_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query
  select e.id, e.type, e.data, e.at, e.offline, e.received_at from user_events e
   where e.user_id = p_uid and (p_before is null or e.at < p_before)
   order by e.at desc limit least(coalesce(p_limit, 100), 300);
end $$;


-- ---------- هدايا الإدارة للاعبين (حبوب بن، فتح المراحل، أشكال) ----------
create table if not exists public.player_grants (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       text not null check (kind in ('beans', 'unlock', 'item')),
  value      jsonb not null default '{}'::jsonb,
  note       text not null default '',
  created_by uuid,
  created_at timestamptz not null default now(),
  claimed_at timestamptz
);
create index if not exists player_grants_user on public.player_grants (user_id) where claimed_at is null;
alter table public.player_grants enable row level security;
drop policy if exists "grants: mine or staff" on public.player_grants;
create policy "grants: mine or staff" on public.player_grants for select using (user_id = auth.uid() or public.has_perm('games.manage'));

create or replace function public.admin_grant(p_uid uuid, p_kind text, p_value jsonb, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare gid bigint;
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  if p_kind = 'beans' and coalesce((p_value->>'n')::int, 0) not between 1 and 100000 then raise exception 'invalid amount'; end if;
  insert into player_grants (user_id, kind, value, note, created_by)
  values (p_uid, p_kind, coalesce(p_value, '{}'::jsonb), left(coalesce(p_note, ''), 120), auth.uid())
  returning id into gid;
  perform public.log_action('grant', p_uid, json_build_object('kind', p_kind, 'value', p_value)::jsonb);
  return gid;
end $$;

create or replace function public.my_grants()
returns setof public.player_grants language sql stable security definer set search_path = public as $$
  select * from player_grants where user_id = auth.uid() and claimed_at is null order by id;
$$;

create or replace function public.claim_grants(p_ids bigint[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  update player_grants set claimed_at = now() where user_id = auth.uid() and id = any(p_ids) and claimed_at is null;
end $$;

create or replace function public.admin_grants(p_uid uuid)
returns setof public.player_grants language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  return query select * from player_grants where user_id = p_uid order by id desc limit 50;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.track_events(jsonb)', 'public.sync_user_stats(jsonb, text, text, timestamptz)',
    'public.admin_user_stats()', 'public.admin_user_events(uuid, integer, timestamptz)',
    'public.admin_grant(uuid, text, jsonb, text)', 'public.my_grants()', 'public.claim_grants(bigint[])', 'public.admin_grants(uuid)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
