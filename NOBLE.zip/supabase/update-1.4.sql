-- ============================================================
-- NOBLE 1.4 — الرسائل الإجبارية + المزامنة الفورية
-- شغّله مرة واحدة في SQL Editor بعد update-1.3-games.sql (آمن لو تكرر)
-- ============================================================

-- ---------- الرسائل الإجبارية (إعلانات يجب قراءتها) ----------
create table if not exists public.notices (
  id         bigserial primary key,
  title      text not null,
  body       text not null default '',
  image_url  text not null default '',
  link       text not null default '',
  level      text not null default 'screen' check (level in ('screen', 'bar')),
  active     boolean not null default true,
  created_by uuid,
  created_at timestamptz not null default now()
);
create table if not exists public.notice_reads (
  notice_id bigint references public.notices(id) on delete cascade,
  user_id   uuid references auth.users(id) on delete cascade,
  read_at   timestamptz not null default now(),
  primary key (notice_id, user_id)
);
alter table public.notices enable row level security;
alter table public.notice_reads enable row level security;

drop policy if exists "notices: read active" on public.notices;
create policy "notices: read active" on public.notices for select
  using (active or public.has_perm('messages.broadcast'));
drop policy if exists "reads: mine" on public.notice_reads;
create policy "reads: mine" on public.notice_reads for select
  using (user_id = auth.uid() or public.has_perm('messages.broadcast'));

create or replace function public.admin_create_notice(p_title text, p_body text, p_image text, p_link text, p_level text)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  insert into notices (title, body, image_url, link, level, created_by)
  values (left(p_title, 120), left(coalesce(p_body, ''), 3000), left(coalesce(p_image, ''), 600), left(coalesce(p_link, ''), 600),
          case when p_level = 'bar' then 'bar' else 'screen' end, auth.uid())
  returning id into nid;
  perform public.log_action('notice', null, json_build_object('title', p_title, 'level', p_level)::jsonb);
  return nid;
end $$;

create or replace function public.admin_set_notice(p_id bigint, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  update notices set active = p_active where id = p_id;
end $$;

create or replace function public.admin_delete_notice(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  delete from notices where id = p_id;
end $$;

-- الإعلانات مع عدد من قرأها من إجمالي المستخدمين النشطين
drop function if exists public.admin_notices();
create or replace function public.admin_notices()
returns table (id bigint, title text, body text, image_url text, link text, level text, active boolean, created_at timestamptz, reads bigint, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select n.id, n.title, n.body, n.image_url, n.link, n.level, n.active, n.created_at,
         (select count(*) from notice_reads r where r.notice_id = n.id),
         (select count(*) from profiles where status = 'active')
    from notices n order by n.id desc;
end $$;

-- من قرأ ومن لم يقرأ
create or replace function public.admin_notice_readers(p_id bigint)
returns table (user_id uuid, email text, name text, read_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select p.id, p.email, p.display_name, r.read_at
    from profiles p left join notice_reads r on r.user_id = p.id and r.notice_id = p_id
   where p.status = 'active'
   order by r.read_at desc nulls last;
end $$;

-- إعلاناتي غير المقروءة
create or replace function public.my_notices()
returns setof public.notices language sql stable security definer set search_path = public as $$
  select n.* from notices n
   where n.active and not exists (select 1 from notice_reads r where r.notice_id = n.id and r.user_id = auth.uid())
   order by n.id;
$$;

create or replace function public.mark_notice_read(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  insert into notice_reads (notice_id, user_id) values (p_id, auth.uid()) on conflict do nothing;
end $$;

-- ---------- المزامنة الفورية (Supabase Realtime) ----------
-- أي تعديل من لوحة الإدارة يصل للتطبيقات المفتوحة فوراً
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['app_config', 'notices', 'messages', 'profiles'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_create_notice(text, text, text, text, text)', 'public.admin_set_notice(bigint, boolean)',
    'public.admin_delete_notice(bigint)', 'public.admin_notices()', 'public.admin_notice_readers(bigint)',
    'public.my_notices()', 'public.mark_notice_read(bigint)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
