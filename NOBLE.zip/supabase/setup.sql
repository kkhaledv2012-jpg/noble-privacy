-- =====================================================================
--  NOBLE — إعداد قاعدة البيانات على Supabase (الخطة المجانية)
--  الصق هذا الملف كاملاً في: Supabase → SQL Editor → New query → Run
--
--  ⚠️ غيّر الإيميل في السطر التالي إلى إيميلك — أول حساب يسجّل به يصبح «أدمن».
-- =====================================================================
create or replace function public.admin_email() returns text
language sql immutable as $$ select 'kkhaledv2012@gmail.com'::text $$;

-- ---------- الجداول ----------
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text,
  display_name  text default '',
  role          text not null default 'user'   check (role in ('user','admin')),
  status        text not null default 'active' check (status in ('active','suspended')),
  items_count   integer not null default 0,
  app_version   text,
  created_at    timestamptz not null default now(),
  last_seen_at  timestamptz
);

-- الخزنة: كتلة مشفّرة بكلمة مرور المستخدم (AES-256-GCM) — لا يمكن لأحد قراءتها، ولا حتى الأدمن.
create table if not exists public.vaults (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  data        jsonb not null,
  updated_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.vaults   enable row level security;

-- ---------- دوال مساعدة ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and status = 'active');
$$;

create or replace function public.is_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'active');
$$;

-- ---------- الصلاحيات (RLS) ----------
drop policy if exists "profiles: self or admin can read" on public.profiles;
create policy "profiles: self or admin can read" on public.profiles
  for select using (id = auth.uid() or public.is_admin());

drop policy if exists "vaults: owner read"   on public.vaults;
drop policy if exists "vaults: owner insert" on public.vaults;
drop policy if exists "vaults: owner update" on public.vaults;
create policy "vaults: owner read"   on public.vaults for select using (user_id = auth.uid() and public.is_active());
create policy "vaults: owner insert" on public.vaults for insert with check (user_id = auth.uid() and public.is_active());
create policy "vaults: owner update" on public.vaults for update using (user_id = auth.uid() and public.is_active()) with check (user_id = auth.uid());
-- لا توجد سياسة تسمح للأدمن بقراءة الخزائن — عن قصد.

-- ---------- إنشاء ملف المستخدم تلقائياً عند التسجيل ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', ''),
    case when lower(new.email) = lower(public.admin_email()) then 'admin' else 'user' end
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- دوال التطبيق ----------
-- يسجّل آخر ظهور وعدد المواقع (رقم فقط، بدون محتوى)
create or replace function public.touch_profile(p_items integer, p_version text default null)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set last_seen_at = now(), items_count = greatest(0, coalesce(p_items, items_count)),
         app_version = coalesce(p_version, app_version)
   where id = auth.uid() returning * into r;
  return r;
end $$;

-- ---------- دوال الأدمن ----------
create or replace function public.admin_set_status(p_uid uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot change your own status'; end if;
  update profiles set status = p_status where id = p_uid;
end $$;

create or replace function public.admin_set_role(p_uid uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot change your own role'; end if;
  update profiles set role = p_role where id = p_uid;
end $$;

create or replace function public.admin_set_name(p_uid uuid, p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  update profiles set display_name = left(coalesce(p_name, ''), 80) where id = p_uid;
end $$;

-- حذف المستخدم نهائياً (الحساب + خزنته المشفّرة)
create or replace function public.admin_delete_user(p_uid uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot delete yourself'; end if;
  delete from auth.users where id = p_uid;
end $$;

create or replace function public.admin_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  return json_build_object(
    'users',       (select count(*) from profiles),
    'active_7d',   (select count(*) from profiles where last_seen_at > now() - interval '7 days'),
    'new_7d',      (select count(*) from profiles where created_at  > now() - interval '7 days'),
    'suspended',   (select count(*) from profiles where status = 'suspended'),
    'admins',      (select count(*) from profiles where role = 'admin'),
    'total_items', (select coalesce(sum(items_count), 0) from profiles)
  );
end $$;

revoke all on function public.touch_profile(integer, text), public.admin_set_status(uuid, text), public.admin_set_role(uuid, text),
  public.admin_set_name(uuid, text), public.admin_delete_user(uuid), public.admin_stats() from anon, public;
grant execute on function public.touch_profile(integer, text), public.admin_set_status(uuid, text), public.admin_set_role(uuid, text),
  public.admin_set_name(uuid, text), public.admin_delete_user(uuid), public.admin_stats() to authenticated;

-- إن كنت سجّلت حسابك قبل تشغيل هذا الملف، هذا السطر يجعله أدمن:
insert into public.profiles (id, email, role)
  select id, email, 'admin' from auth.users where lower(email) = lower(public.admin_email())
  on conflict (id) do update set role = 'admin';

-- =====================================================================
--  محتوى التطبيق (نصوص، إعلان، ثيم افتراضي، روابط، إشعار تحديث)
--  يقرؤه الجميع، ويعدّله الأدمن فقط من لوحة التحكم.
-- =====================================================================
create table if not exists public.app_config (
  id          integer primary key default 1 check (id = 1),
  data        jsonb not null default '{}'::jsonb,
  updated_at  timestamptz not null default now()
);
insert into public.app_config (id) values (1) on conflict (id) do nothing;
alter table public.app_config enable row level security;
drop policy if exists "config: anyone can read" on public.app_config;
create policy "config: anyone can read" on public.app_config for select using (true);

create or replace function public.admin_set_config(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  update app_config set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;
revoke all on function public.admin_set_config(jsonb) from anon, public;
grant execute on function public.admin_set_config(jsonb) to authenticated;
