-- ============================================================
-- NOBLE 1.13 — الأخبار: مجالات واهتمامات ودول
--  • كل خبر له مجال (cat) واهتمام فرعي (topic) ودولة (country — فارغ = عام)
--  • المصادر لها مجال ودولة افتراضية، وGemini يختار الاهتمام الفرعي
--  • المستخدم يختار دولته ومجالاته المفضلة، والخلاصة تنزل له حسب اختياره
--  • المجالات والدول والحدود والاشتراك تُدار من لوحة التحكم ← الأخبار ← المجالات والدول
-- شغّله مرة واحدة في SQL Editor بعد update-1.12.sql (آمن لو تكرر)
-- ============================================================

alter table public.news_items   add column if not exists topic   text not null default '';
alter table public.news_items   add column if not exists country text not null default '';
alter table public.news_sources add column if not exists topic   text not null default '';
alter table public.news_sources add column if not exists country text not null default '';
create index if not exists news_items_feed2 on public.news_items (status, cat, country, published_at desc);

-- تحويل تصنيفات «نبض AI» القديمة إلى مجال «الذكاء الاصطناعي» واهتماماته
update public.news_items set topic = case when cat = 'general' then '' else cat end, cat = 'ai'
  where cat in ('design', 'tools', 'media', 'companies', 'learn', 'general');
update public.news_sources set topic = case when cat = 'general' then '' else cat end, cat = 'ai'
  where cat in ('design', 'tools', 'media', 'companies', 'learn', 'general');

-- الخلاصة حسب اختيار المستخدم
--  p_cats: مجالاته المفضلة · p_countries: دوله (الخبر العام يوصل للكل) · p_topics: 'مجال/اهتمام' (لو حدّد اهتمامات داخل مجال)
create or replace function public.news_feed2(p_cats text[] default null, p_countries text[] default null, p_topics text[] default null,
  p_before timestamptz default null, p_limit int default 40)
returns setof json language sql stable security definer set search_path = public as $$
  select json_build_object('id', n.id, 'url', n.url, 'src', n.src_name, 'image', n.image, 'cat', n.cat, 'topic', n.topic, 'country', n.country,
    'title', n.title, 'summary', n.summary, 'body', n.body, 'why', n.why, 'pinned', n.pinned, 'ai', n.ai, 'at', n.published_at)
  from news_items n
  where n.status = 'published' and auth.uid() is not null
    and (coalesce(cardinality(p_cats), 0) = 0 or n.cat = any(p_cats))
    and (n.country = '' or n.country = any(coalesce(p_countries, array[]::text[])))
    and (coalesce(cardinality(p_topics), 0) = 0
         or not exists (select 1 from unnest(p_topics) t where split_part(t, '/', 1) = n.cat)
         or (n.cat || '/' || n.topic) = any(p_topics))
    and (p_before is null or n.published_at < p_before)
  order by (p_before is null and n.pinned) desc, n.published_at desc
  limit least(greatest(coalesce(p_limit, 40), 1), 80);
$$;

-- إعدادات القسم العامة للتطبيق: الاسم، الموجز، المجالات، الدول، الحدود، الاشتراك اللي يفتح مزايا التحكم
create or replace function public.news_meta()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object('title', coalesce(nullif(data->>'title', ''), 'الأخبار'), 'sub', coalesce(data->>'sub', ''),
    'hour', coalesce((data->>'hour')::int, 8), 'digest', coalesce((data->>'digest')::boolean, true),
    'domains', data->'domains', 'countries', data->'countries', 'limits', data->'limits', 'premium', data->'premium',
    'ask', coalesce((data->>'ask')::boolean, true))
  from news_settings where id = 1 and auth.uid() is not null;
$$;

-- حفظ خبر: يدعم المجال والاهتمام والدولة
create or replace function public.admin_news_save(p_item jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; st text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_item->>'title', '')) < 3 then raise exception 'title required'; end if;
  st := coalesce(nullif(p_item->>'status', ''), 'draft');
  if (p_item->>'id') is null then
    insert into news_items (title, summary, body, why, cat, topic, country, image, url, src_name, status, pinned, created_by, published_at, guid)
    values (left(p_item->>'title', 220), left(coalesce(p_item->>'summary', ''), 600), left(coalesce(p_item->>'body', ''), 6000),
      left(coalesce(p_item->>'why', ''), 600), coalesce(nullif(p_item->>'cat', ''), 'ai'), left(coalesce(p_item->>'topic', ''), 40),
      left(coalesce(p_item->>'country', ''), 8), left(coalesce(p_item->>'image', ''), 600),
      left(coalesce(p_item->>'url', ''), 600), left(coalesce(nullif(p_item->>'src_name', ''), 'فريق NOBLE'), 60), st,
      coalesce((p_item->>'pinned')::boolean, false), auth.uid(), case when st = 'published' then now() end, 'manual:' || gen_random_uuid())
    returning id into nid;
  else
    nid := (p_item->>'id')::bigint;
    update news_items set
      title = left(p_item->>'title', 220), summary = left(coalesce(p_item->>'summary', ''), 600), body = left(coalesce(p_item->>'body', ''), 6000),
      why = left(coalesce(p_item->>'why', ''), 600), cat = coalesce(nullif(p_item->>'cat', ''), cat),
      topic = left(coalesce(p_item->>'topic', topic), 40), country = left(coalesce(p_item->>'country', country), 8),
      image = left(coalesce(p_item->>'image', image), 600),
      url = left(coalesce(p_item->>'url', url), 600), src_name = left(coalesce(nullif(p_item->>'src_name', ''), src_name), 60),
      status = st, pinned = coalesce((p_item->>'pinned')::boolean, pinned),
      published_at = case when st = 'published' then coalesce(published_at, now()) else published_at end, updated_at = now()
    where id = nid;
  end if;
  perform public.log_action('news', null, json_build_object('id', nid, 'status', st)::jsonb);
  return nid;
end $$;

-- المصادر: مجال + اهتمام + دولة
create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, topic, country, active) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, topic = excluded.topic, country = excluded.country, active = excluded.active
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active) where id = sid;
  end if;
  return sid;
end $$;

-- إحصائية: كم مستخدم اختار كل مجال/دولة (تُرسل من التطبيق كأحداث مجمّعة — بدون بيانات شخصية)
create or replace function public.admin_news_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'draft', (select count(*) from news_items where status = 'draft'),
    'today', (select count(*) from news_items where status = 'published' and published_at >= date_trunc('day', now())),
    'published', (select count(*) from news_items where status = 'published'),
    'views', (select coalesce(sum(views), 0) from news_items where published_at >= now() - interval '7 days'),
    'saves', (select coalesce(sum(saves), 0) from news_items where published_at >= now() - interval '7 days'),
    'by_cat', (select coalesce(json_object_agg(cat, n), '{}'::json) from (select cat, count(*) n from news_items where status = 'published' group by cat) x));
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.news_feed2(text[], text[], text[], timestamptz, int)', 'public.news_meta()',
    'public.admin_news_save(jsonb)', 'public.admin_news_source_save(jsonb)', 'public.admin_news_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ---------- كود خصم 100٪: تفعيل مباشر بدون طلب دفع ----------
-- يتحقق من الكود (فعّال، ما انتهى، باقي له استخدامات، مسموح لهذا القسم والمدة) ومن إنه 100٪،
-- وما يسمح لنفس الشخص يستخدم نفس الكود مرتين، ويزيد عدّاد الاستخدام.
create or replace function public.claim_free_discount(p_code text, p_app text, p_plan text)
returns json language plpgsql security definer set search_path = public as $$
declare d discount_codes; eid bigint; u timestamptz;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if p_app not in ('vault', 'tasks', 'today', 'news', 'finance', 'games', 'all') or p_plan not in ('m', 'y', 'l') then raise exception 'discount not for this'; end if;
  select * into d from discount_codes where code = upper(trim(p_code)) for update;
  if not found or not d.active then raise exception 'invalid discount'; end if;
  if d.until is not null and d.until < now() then raise exception 'discount expired'; end if;
  if d.max_uses is not null and d.used >= d.max_uses then raise exception 'discount used up'; end if;
  if d.apps is not null and not (p_app = any(d.apps)) then raise exception 'discount not for this'; end if;
  if d.plans is not null and not (p_plan = any(d.plans)) then raise exception 'discount not for this'; end if;
  if d.pct < 100 then raise exception 'discount not free'; end if;
  if exists (select 1 from entitlements where user_id = auth.uid() and source = 'discount' and ref = d.code) then raise exception 'discount already claimed'; end if;
  eid := public.grant_entitlement(auth.uid(), p_app, p_plan, 'discount', d.code, 0);
  update discount_codes set used = used + 1 where code = d.code;
  select until into u from entitlements where id = eid;
  perform public.log_action('discount_free', auth.uid(), json_build_object('code', d.code, 'app', p_app, 'plan', p_plan)::jsonb);
  return json_build_object('app', p_app, 'plan', p_plan, 'until', u);
end $$;
revoke all on function public.claim_free_discount(text, text, text) from anon, public;
grant execute on function public.claim_free_discount(text, text, text) to authenticated;
