-- NOBLE 1.21.26 — 🔔 تنبيهات المسودات للمشرف + 💬 تعليقات العدد
-- شغّله مرة وحدة في Supabase ← SQL Editor (آمن لو انعاد)

-- ===== 1) تذكير المسودات =====
alter table public.ai_issues add column if not exists reminded jsonb not null default '{}'::jsonb;  -- {ready, late, soon} وقت كل تنبيه انرسل
alter table public.ai_sched_cfg add column if not exists remind jsonb not null default '{"on": true, "ready": true, "late": 60, "soon": 15}'::jsonb;
insert into public.ai_sched_cfg (id) values (1) on conflict (id) do nothing;

-- المشرفين اللي عندهم صلاحية الأخبار (للإشعارات) — للسيرفر بس
create or replace function public.news_admin_ids() returns setof uuid
language sql stable security definer set search_path = public as $$
  select id from profiles where status = 'active' and 'news.manage' = any(public.role_perms(role));
$$;
revoke all on function public.news_admin_ids() from public, anon, authenticated;

-- اللوحة: قراءة/حفظ إعدادات التذكير (+ يتأكد إن مهمة الـcron شغّالة)
create or replace function public.admin_ai_remind(p jsonb default null, p_push_url text default null, p_anon text default null)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare r jsonb;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_push_url, '') ~ '^https://' then
    update ai_sched_cfg set push_url = p_push_url, anon = coalesce(p_anon, anon), updated_at = now() where id = 1;
  end if;
  if p is not null then
    update ai_sched_cfg set remind = jsonb_build_object(
      'on', coalesce((p->>'on')::boolean, true), 'ready', coalesce((p->>'ready')::boolean, true),
      'late', greatest(0, least(720, coalesce((p->>'late')::int, 60))), 'soon', greatest(0, least(180, coalesce((p->>'soon')::int, 15)))), updated_at = now() where id = 1;
    begin
      perform 1 from cron.job where jobname = 'noble-ai-pub';
      if not found then perform cron.schedule('noble-ai-pub', '*/5 * * * *', 'select public.ai_publish_due()'); end if;
    exception when others then raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة'; end;
  end if;
  select remind into r from ai_sched_cfg where id = 1;
  return json_build_object('remind', r, 'ready', (select push_url <> '' from ai_sched_cfg where id = 1));
end $$;
revoke all on function public.admin_ai_remind(jsonb, text, text) from public, anon;
grant execute on function public.admin_ai_remind(jsonb, text, text) to authenticated;

-- الـcron (كل ٥ دقايق): ينشر المجدول + يرسل تنبيهات المسودات للمشرف
create or replace function public.ai_publish_due()
returns int language plpgsql security definer set search_path = public, extensions as $$
declare r record; n int := 0; c ai_sched_cfg; sec text; rc jsonb;
begin
  select * into c from ai_sched_cfg where id = 1; select cron_secret into sec from news_secret where id = 1;
  for r in select id, sched from ai_issues where status = 'draft' and publish_at is not null and publish_at <= now() order by publish_at limit 10 loop
    perform public._ai_publish(r.id, nullif(r.sched->>'pin', '')::int, coalesce((r.sched->>'discover')::boolean, true));
    n := n + 1;
    if coalesce((r.sched->>'notify')::boolean, true) and c.push_url <> '' then
      begin
        perform net.http_post(url := c.push_url, headers := json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || c.anon, 'x-news-secret', coalesce(sec, ''))::jsonb,
          body := json_build_object('kind', 'issue', 'id', r.id)::jsonb, timeout_milliseconds := 30000);
      exception when others then null; end;
    end if;
  end loop;

  -- 🔔 تنبيهات المشرف (1.21.26)
  rc := coalesce(c.remind, '{}'::jsonb);
  if c.push_url <> '' and coalesce((rc->>'on')::boolean, true) then
    for r in
      select id, 'ready' as what from ai_issues
        where status = 'draft' and ai and coalesce((rc->>'ready')::boolean, true) and reminded->>'ready' is null and created_at > now() - interval '30 minutes'
      union all
      select id, 'late' from ai_issues
        where status = 'draft' and ai and publish_at is null and coalesce((rc->>'late')::int, 60) > 0 and reminded->>'late' is null
          and created_at <= now() - make_interval(mins => coalesce((rc->>'late')::int, 60)) and created_at > now() - interval '1 day'
      union all
      select id, 'soon' from ai_issues
        where status = 'draft' and publish_at is not null and coalesce((rc->>'soon')::int, 15) > 0 and reminded->>'soon' is null
          and publish_at > now() and publish_at <= now() + make_interval(mins => coalesce((rc->>'soon')::int, 15))
      limit 10
    loop
      update ai_issues set reminded = reminded || jsonb_build_object(r.what, now()) where id = r.id;
      begin
        perform net.http_post(url := c.push_url, headers := json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || c.anon, 'x-news-secret', coalesce(sec, ''))::jsonb,
          body := json_build_object('kind', 'remind', 'id', r.id, 'what', r.what)::jsonb, timeout_milliseconds := 30000);
      exception when others then null; end;
    end loop;
  end if;
  return n;
end $$;
revoke all on function public.ai_publish_due() from public, anon, authenticated;

-- المسودات القديمة (قبل التحديث) ما تطلع لها تنبيهات «جاهز» دفعة وحدة
update public.ai_issues set reminded = reminded || jsonb_build_object('ready', now(), 'late', now()) where status = 'draft' and created_at < now() - interval '2 hours' and reminded = '{}'::jsonb;

-- تأكد إن مهمة الـcron موجودة
do $$ begin
  perform 1 from cron.job where jobname = 'noble-ai-pub';
  if not found then perform cron.schedule('noble-ai-pub', '*/5 * * * *', 'select public.ai_publish_due()'); end if;
exception when others then raise notice 'pg_cron غير مفعّل — فعّل pg_cron و pg_net من Database ← Extensions'; end $$;

-- ===== 2) 💬 تعليقات العدد =====
-- كل عدد منشور له «محادثة» — نفس منشوره في اكتشف، ولو ما انعرض في اكتشف نسوي له منشور مخفي للتعليقات بس
create or replace function public.ai_issue_thread(p_issue bigint)
returns json language plpgsql security definer set search_path = public as $$
declare i ai_issues; fid bigint; n int;
begin
  select * into i from ai_issues where id = p_issue and status = 'published';
  if i.id is null then return null; end if;
  if coalesce((i.look->>'cmt')::boolean, true) = false then return json_build_object('off', true); end if;
  fid := i.feed_id;
  if fid is null or not exists(select 1 from feed_items where id = fid) then
    insert into feed_items (kind, data, active) values ('post', jsonb_build_object('type', 'ai_issue', 'issue', i.id, 'caption', i.title, 'thread', true, 'media', '[]'::jsonb), false)
    returning id into fid;
    update ai_issues set feed_id = fid where id = i.id;
  end if;
  select count(*) into n from feed_comments where item_id = fid and status = 'approved';
  return json_build_object('id', fid, 'n', n);
end $$;
grant execute on function public.ai_issue_thread(bigint) to anon, authenticated;

-- التعليق يقبل منشور العدد حتى لو مخفي من اكتشف
create or replace function public.feed_comment(p_id bigint, p_body text)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; b text := btrim(coalesce(p_body, ''));
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if length(b) < 1 then raise exception 'empty'; end if;
  if length(b) > 500 then b := left(b, 500); end if;
  if coalesce((select (data->>'comments')::boolean from feed_settings where id = 1), true) = false then raise exception 'comments off'; end if;
  if (select count(*) from feed_comments where user_id = auth.uid() and created_at > now() - interval '1 day') >= 30 then raise exception 'limit'; end if;
  insert into feed_comments (item_id, user_id, body) select p_id, auth.uid(), b
    where exists(select 1 from feed_items where id = p_id and (active or data->>'type' = 'ai_issue'))
  returning id into nid;
  return nid;
end $$;

-- 📊 أي خبر شدّ الناس: عدّ التعليقات اللي فيها «📌 الخبر N»
create or replace function public.admin_ai_cmt_stats(p_issue bigint)
returns json language plpgsql stable security definer set search_path = public as $$
declare fid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  select feed_id into fid from ai_issues where id = p_issue;
  if fid is null then return json_build_object('total', 0, 'by', '{}'::json); end if;
  return json_build_object(
    'total', (select count(*) from feed_comments where item_id = fid and status <> 'rejected'),
    'pending', (select count(*) from feed_comments where item_id = fid and status = 'pending'),
    'by', coalesce((select json_object_agg(k, c) from (select substring(body from '^📌 الخبر ([0-9]+)') k, count(*) c from feed_comments
             where item_id = fid and status <> 'rejected' and body ~ '^📌 الخبر [0-9]+' group by 1) x), '{}'::json));
end $$;
revoke all on function public.admin_ai_cmt_stats(bigint) from public, anon;
grant execute on function public.admin_ai_cmt_stats(bigint) to authenticated;

select 'NOBLE 1.21.26 ✓' as done;
