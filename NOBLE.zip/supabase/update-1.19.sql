-- NOBLE 1.19 — 🔔 الإشعارات الخاصة + 📊 نشاط المستخدم التفصيلي
-- يتشغّل أكثر من مرة بأمان.

-- =====================================================================
-- 🔔 الإشعارات الخاصة (المرحلة ١ — بدون Firebase)
-- التطبيق يسحبها لما ينفتح ويجدولها كإشعار على الجوال في وقتها بالضبط (حتى لو التطبيق مسكّر بعدها).
-- =====================================================================
create table if not exists public.push_notes (
  id         bigserial primary key,
  title      text not null,
  body       text not null default '',
  tab        text not null default '',          -- القسم اللي ينفتح لما يضغط الإشعار
  link       text not null default '',
  send_at    timestamptz not null default now(),
  targets    uuid[] not null default '{}',       -- فاضي = للجميع
  active     boolean not null default true,
  created_by uuid default auth.uid(),
  created_at timestamptz not null default now()
);
create index if not exists push_notes_live on public.push_notes (active, send_at);
alter table public.push_notes add column if not exists icon text not null default 'noble';  -- أيقونة الإشعار (من مجموعة داخل التطبيق)
alter table public.push_notes enable row level security;  -- الوصول عبر الدوال فقط

create table if not exists public.push_hits (
  note_id   bigint not null references public.push_notes(id) on delete cascade,
  user_id   uuid not null references auth.users(id) on delete cascade,
  got_at    timestamptz not null default now(),
  opened_at timestamptz,
  primary key (note_id, user_id)
);
alter table public.push_hits enable row level security;

-- للمستخدم: الإشعارات اللي تخصّه (من يومين لين أسبوعين قدام)
drop function if exists public.my_push_notes();
create or replace function public.my_push_notes()
returns table (id bigint, title text, body text, tab text, link text, send_at timestamptz, icon text)
language sql stable security definer set search_path = public as $$
  select n.id, n.title, n.body, n.tab, n.link, n.send_at, n.icon from push_notes n
   where auth.uid() is not null and n.active
     and (cardinality(n.targets) = 0 or auth.uid() = any(n.targets))
     and n.send_at > now() - interval '2 days' and n.send_at < now() + interval '14 days'
   order by n.send_at limit 30;
$$;

-- وصل للجوال (got) أو ضغطه (open)
create or replace function public.push_hit(p_id bigint, p_open boolean default false)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into push_hits (note_id, user_id, opened_at) values (p_id, auth.uid(), case when p_open then now() end)
  on conflict (note_id, user_id) do update set opened_at = coalesce(push_hits.opened_at, excluded.opened_at);
exception when foreign_key_violation then null;
end $$;

-- للإدارة
create or replace function public.admin_push_save(p jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare v_id bigint; v_t uuid[];
begin
  v_t := coalesce((select array_agg(x::uuid) from jsonb_array_elements_text(coalesce(p->'targets', '[]'::jsonb)) x), '{}');
  if cardinality(v_t) = 0 and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if cardinality(v_t) > 0 and not (public.has_perm('messages.send') or public.has_perm('messages.broadcast')) then raise exception 'not allowed'; end if;
  if coalesce(trim(p->>'title'), '') = '' then raise exception 'العنوان مطلوب'; end if;
  if (p->>'id') is not null then
    update push_notes set title = left(p->>'title', 80), body = left(coalesce(p->>'body', ''), 240), tab = coalesce(p->>'tab', ''),
      link = coalesce(p->>'link', ''), send_at = coalesce((p->>'send_at')::timestamptz, send_at), targets = v_t,
      icon = coalesce(nullif(p->>'icon', ''), 'noble')
     where id = (p->>'id')::bigint returning id into v_id;
  else
    insert into push_notes (title, body, tab, link, send_at, targets, icon)
    values (left(p->>'title', 80), left(coalesce(p->>'body', ''), 240), coalesce(p->>'tab', ''), coalesce(p->>'link', ''),
            coalesce((p->>'send_at')::timestamptz, now()), v_t, coalesce(nullif(p->>'icon', ''), 'noble')) returning id into v_id;
  end if;
  return v_id;
end $$;

drop function if exists public.admin_push_list();
create or replace function public.admin_push_list()
returns table (id bigint, title text, body text, tab text, link text, send_at timestamptz, targets uuid[], active boolean,
               created_at timestamptz, got bigint, opened bigint, audience bigint, icon text)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('messages.send') or public.has_perm('messages.broadcast')) then raise exception 'not allowed'; end if;
  return query
  select n.id, n.title, n.body, n.tab, n.link, n.send_at, n.targets, n.active, n.created_at,
         (select count(*) from push_hits h where h.note_id = n.id),
         (select count(*) from push_hits h where h.note_id = n.id and h.opened_at is not null),
         case when cardinality(n.targets) > 0 then cardinality(n.targets)::bigint else (select count(*) from profiles) end, n.icon
    from push_notes n order by n.send_at desc limit 100;
end $$;

create or replace function public.admin_push_set(p_id bigint, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('messages.send') or public.has_perm('messages.broadcast')) then raise exception 'not allowed'; end if;
  update push_notes set active = p_active where id = p_id;
end $$;

create or replace function public.admin_push_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('messages.send') or public.has_perm('messages.broadcast')) then raise exception 'not allowed'; end if;
  delete from push_notes where id = p_id;
end $$;

-- =====================================================================
-- 📊 نشاط المستخدم التفصيلي — أرقام فقط (بدون محتوى الخزنة ولا الروابط نفسها)
-- الجوال يجمّع اليوم محلياً ويرسل الملخص؛ يُحذف تلقائياً بعد ٩٠ يوم.
-- =====================================================================
create table if not exists public.usage_daily (
  user_id    uuid not null references auth.users(id) on delete cascade,
  day        date not null,
  opens      integer not null default 0,
  secs       integer not null default 0,
  links      integer not null default 0,
  tabs       jsonb not null default '{}'::jsonb,   -- {tasks: ثواني, news: ثواني, …}
  sessions   jsonb not null default '[]'::jsonb,   -- [[وقت الدخول, ثواني], …] آخر ٣٠
  updated_at timestamptz not null default now(),
  primary key (user_id, day)
);
alter table public.usage_daily enable row level security;  -- الوصول عبر الدوال فقط

create or replace function public.usage_push(p_day date, p_opens integer, p_secs integer, p_links integer, p_tabs jsonb, p_sessions jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or p_day is null or p_day > current_date + 1 or p_day < current_date - 30 then return; end if;
  insert into usage_daily (user_id, day, opens, secs, links, tabs, sessions, updated_at)
  values (auth.uid(), p_day, least(greatest(coalesce(p_opens, 0), 0), 1000), least(greatest(coalesce(p_secs, 0), 0), 86400),
          least(greatest(coalesce(p_links, 0), 0), 5000),
          case when jsonb_typeof(p_tabs) = 'object' and length(p_tabs::text) < 2000 then p_tabs else '{}'::jsonb end,
          case when jsonb_typeof(p_sessions) = 'array' and length(p_sessions::text) < 4000 then p_sessions else '[]'::jsonb end, now())
  on conflict (user_id, day) do update set
    opens = greatest(usage_daily.opens, excluded.opens), secs = greatest(usage_daily.secs, excluded.secs),
    links = greatest(usage_daily.links, excluded.links), tabs = excluded.tabs, sessions = excluded.sessions, updated_at = now();
  if random() < 0.05 then delete from usage_daily where day < current_date - 90; end if;
end $$;

create or replace function public.admin_user_activity(p_uid uuid)
returns jsonb language plpgsql stable security definer set search_path = public as $$
declare r jsonb;
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  select jsonb_build_object(
    'days', coalesce((select jsonb_agg(jsonb_build_object('day', d.day, 'opens', d.opens, 'secs', d.secs, 'links', d.links, 'tabs', d.tabs, 'sessions', d.sessions) order by d.day desc)
                        from (select * from usage_daily where user_id = p_uid and day >= current_date - 30 order by day desc) d), '[]'::jsonb),
    'joined', (select created_at from auth.users where id = p_uid),
    'last_seen', (select last_seen_at from profiles where id = p_uid),
    -- اللي أرسله للإدارة أو نشره (مو محتوى خزنته)
    'comments', coalesce((select jsonb_agg(x) from (select c.body, c.status, c.created_at, c.item_id from feed_comments c where c.user_id = p_uid order by c.created_at desc limit 20) x), '[]'::jsonb),
    'tickets', coalesce((select jsonb_agg(x) from (select t.id, t.cat, left(t.body, 160) as body, t.status, jsonb_array_length(t.files) as files, t.created_at from support_tickets t where t.user_id = p_uid order by t.created_at desc limit 20) x), '[]'::jsonb),
    'payments', coalesce((select jsonb_agg(x) from (select p.id, p.plan, p.amount, p.method, p.status, p.created_at from payment_requests p where p.user_id = p_uid order by p.created_at desc limit 20) x), '[]'::jsonb),
    'pushes', coalesce((select jsonb_agg(x) from (select n.title, h.got_at, h.opened_at from push_hits h join push_notes n on n.id = h.note_id where h.user_id = p_uid order by h.got_at desc limit 20) x), '[]'::jsonb)
  ) into r;
  return r;
exception when undefined_table then
  return coalesce(r, '{}'::jsonb);
end $$;

revoke all on function public.my_push_notes(), public.push_hit(bigint, boolean), public.admin_push_save(jsonb), public.admin_push_list(),
  public.admin_push_set(bigint, boolean), public.admin_push_delete(bigint), public.usage_push(date, integer, integer, integer, jsonb, jsonb),
  public.admin_user_activity(uuid) from public, anon;
grant execute on function public.my_push_notes(), public.push_hit(bigint, boolean), public.admin_push_save(jsonb), public.admin_push_list(),
  public.admin_push_set(bigint, boolean), public.admin_push_delete(bigint), public.usage_push(date, integer, integer, integer, jsonb, jsonb),
  public.admin_user_activity(uuid) to authenticated;

-- =====================================================================
-- 🎯 الأخبار: «⭐ مميز» (Gemini يعلّم الخبر المهم) — الفلتر والأولويات نفسها في news_settings.data.filter
-- =====================================================================
alter table public.news_items add column if not exists featured boolean not null default false;
create or replace function public.news_feed2(p_cats text[] default null, p_countries text[] default null, p_topics text[] default null,
  p_before timestamptz default null, p_limit int default 40)
returns setof json language sql stable security definer set search_path = public as $$
  select json_build_object('id', n.id, 'url', n.url, 'src', n.src_name, 'image', n.image, 'cat', n.cat, 'topic', n.topic, 'country', n.country,
    'title', n.title, 'summary', n.summary, 'body', n.body, 'why', n.why, 'pinned', n.pinned, 'ai', n.ai, 'at', n.published_at, 'featured', n.featured)
  from news_items n
  where n.status = 'published' and auth.uid() is not null
    and (coalesce(cardinality(p_cats), 0) = 0 or n.cat = any(p_cats))
    and (n.country = '' or n.country = any(coalesce(p_countries, array[]::text[])))
    and (coalesce(cardinality(p_topics), 0) = 0
         or not exists (select 1 from unnest(p_topics) t where split_part(t, '/', 1) = n.cat)
         or (n.cat || '/' || n.topic) = any(p_topics))
    and (p_before is null or n.published_at < p_before)
  order by (p_before is null and n.pinned) desc, n.published_at desc
  limit least(greatest(coalesce(p_limit, 40), 1), 80);
$$;

-- NOBLE — إصلاح تنبيه Supabase: «Clients can list all files in this bucket» (مجلد designs)
-- الصور والفيديوهات تنقرأ بالرابط العام (المجلد Public) وما تحتاج هذي الصلاحية،
-- فنخلي «عرض قائمة الملفات» للإدارة بس (تحتاجها لحذف الملفات القديمة من اللوحة).
drop policy if exists "designs: read" on storage.objects;
drop policy if exists "designs: staff read" on storage.objects;
create policy "designs: staff read" on storage.objects for select
  using (bucket_id = 'designs' and (public.has_perm('content.edit') or public.has_perm('apps.manage') or public.has_perm('news.manage')));
