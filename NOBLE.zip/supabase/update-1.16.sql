-- ============================================================
-- NOBLE 1.16 — «راسل الإدارة» (الدعم)
--  • المستخدم يرسل مشكلته أو اقتراحه مع صور أو فيديو (حتى ٤ مرفقات)
--  • المرفقات في مخزن خاص «support» — ما يشوفها إلا المالك وفريقه، وما تنحذف إلا بقرارك
--  • تقدر توقف الزر عن الكل أو تخفيه عن مستخدمين محددين
-- شغّله مرة واحدة في SQL Editor بعد update-1.15.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.support_tickets (
  id            bigserial primary key,
  user_id       uuid not null references auth.users(id) on delete cascade,
  cat           text not null default 'issue' check (cat in ('issue', 'idea', 'billing', 'question', 'other')),
  body          text not null,
  files         jsonb not null default '[]'::jsonb,   -- [{path, kind: image|video, size, name}]
  meta          jsonb not null default '{}'::jsonb,   -- {app, version, platform, device, screen, tab, lang}
  status        text not null default 'new' check (status in ('new', 'open', 'done')),
  reply         text,
  replied_at    timestamptz,
  files_deleted boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists support_tickets_user_idx on public.support_tickets (user_id, created_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets (status, created_at desc);
alter table public.support_tickets enable row level security;   -- الوصول عبر الدوال فقط

create table if not exists public.support_settings (
  id         integer primary key default 1 check (id = 1),
  enabled    boolean not null default true,
  blocked    uuid[] not null default '{}',
  max_day    integer not null default 5,
  updated_at timestamptz not null default now()
);
insert into public.support_settings (id) values (1) on conflict (id) do nothing;
alter table public.support_settings enable row level security;

-- ---------- مخزن المرفقات (خاص) ----------
insert into storage.buckets (id, name, public, file_size_limit)
values ('support', 'support', false, 31457280)
on conflict (id) do update set public = false, file_size_limit = 31457280;

drop policy if exists "support: user uploads own folder" on storage.objects;
create policy "support: user uploads own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'support' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "support: staff read" on storage.objects;
create policy "support: staff read" on storage.objects for select to authenticated
  using (bucket_id = 'support' and public.has_perm('messages.send'));
drop policy if exists "support: staff delete" on storage.objects;
create policy "support: staff delete" on storage.objects for delete to authenticated
  using (bucket_id = 'support' and public.has_perm('messages.send'));

-- ---------- المستخدم ----------
create or replace function public.support_status()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'on', s.enabled and not (auth.uid() = any(s.blocked)),
    'max_day', s.max_day,
    'used', (select count(*) from support_tickets t where t.user_id = auth.uid() and t.created_at > now() - interval '1 day'),
    'unread', (select count(*) from support_tickets t where t.user_id = auth.uid() and t.reply is not null and t.replied_at > coalesce((t.meta->>'seen_at')::timestamptz, 'epoch')))
  from support_settings s where s.id = 1 and auth.uid() is not null;
$$;

create or replace function public.support_send(p_cat text, p_body text, p_files jsonb default '[]'::jsonb, p_meta jsonb default '{}'::jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare s support_settings; v_id bigint; f jsonb;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and status = 'active') then raise exception 'account suspended'; end if;
  select * into s from support_settings where id = 1;
  if not s.enabled or auth.uid() = any(s.blocked) then raise exception 'support closed'; end if;
  if length(trim(coalesce(p_body, ''))) < 3 then raise exception 'message too short'; end if;
  if (select count(*) from support_tickets where user_id = auth.uid() and created_at > now() - interval '1 day') >= s.max_day then raise exception 'daily limit'; end if;
  if jsonb_typeof(coalesce(p_files, '[]'::jsonb)) <> 'array' or jsonb_array_length(coalesce(p_files, '[]'::jsonb)) > 4 then raise exception 'too many files'; end if;
  for f in select * from jsonb_array_elements(coalesce(p_files, '[]'::jsonb)) loop
    if split_part(f->>'path', '/', 1) <> auth.uid()::text then raise exception 'bad file path'; end if;
  end loop;
  insert into support_tickets (user_id, cat, body, files, meta)
  values (auth.uid(), case when p_cat in ('issue', 'idea', 'billing', 'question', 'other') then p_cat else 'other' end,
          left(trim(p_body), 2000), coalesce(p_files, '[]'::jsonb), coalesce(p_meta, '{}'::jsonb) - 'seen_at')
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.support_mine()
returns json language sql stable security definer set search_path = public as $$
  select coalesce(json_agg(json_build_object('id', t.id, 'cat', t.cat, 'body', t.body, 'status', t.status, 'reply', t.reply,
    'replied_at', t.replied_at, 'created_at', t.created_at, 'nfiles', jsonb_array_length(t.files)) order by t.created_at desc), '[]'::json)
  from (select * from support_tickets where user_id = auth.uid() order by created_at desc limit 30) t;
$$;

create or replace function public.support_seen()
returns void language sql security definer set search_path = public as $$
  update support_tickets set meta = meta || jsonb_build_object('seen_at', now()) where user_id = auth.uid() and reply is not null;
$$;

-- ---------- لوحة المالك ----------
create or replace function public.admin_support_list(p_status text default null)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  return coalesce((select json_agg(json_build_object('id', t.id, 'user_id', t.user_id, 'cat', t.cat, 'body', t.body, 'files', t.files, 'meta', t.meta - 'seen_at',
      'status', t.status, 'reply', t.reply, 'replied_at', t.replied_at, 'files_deleted', t.files_deleted, 'created_at', t.created_at,
      'name', coalesce(nullif(p.display_name, ''), p.email, 'مستخدم'), 'email', p.email,
      'count', (select count(*) from support_tickets x where x.user_id = t.user_id)) order by t.created_at desc)
    from (select * from support_tickets where p_status is null or p_status = 'all' or status = p_status order by created_at desc limit 300) t
    left join profiles p on p.id = t.user_id), '[]'::json);
end $$;

create or replace function public.admin_support_counts()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then return json_build_object('new', 0, 'open', 0); end if;
  return (select json_build_object('new', count(*) filter (where status = 'new'), 'open', count(*) filter (where status = 'open'),
    'done', count(*) filter (where status = 'done'), 'all', count(*)) from support_tickets);
end $$;

create or replace function public.admin_support_set(p_id bigint, p_status text default null, p_reply text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  if p_status is not null and p_status not in ('new', 'open', 'done') then raise exception 'bad status'; end if;
  update support_tickets set
    status = coalesce(p_status, status),
    reply = case when p_reply is not null and length(trim(p_reply)) > 0 then left(trim(p_reply), 2000) else reply end,
    replied_at = case when p_reply is not null and length(trim(p_reply)) > 0 then now() else replied_at end,
    updated_at = now()
  where id = p_id;
end $$;

-- يرجّع مسارات المرفقات عشان اللوحة تحذفها من المخزن
create or replace function public.admin_support_delete(p_id bigint, p_files_only boolean default false)
returns json language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  select files into v from support_tickets where id = p_id;
  if p_files_only then update support_tickets set files = '[]'::jsonb, files_deleted = true, updated_at = now() where id = p_id;
  else delete from support_tickets where id = p_id; end if;
  return coalesce((select json_agg(x->>'path') from jsonb_array_elements(coalesce(v, '[]'::jsonb)) x), '[]'::json);
end $$;

create or replace function public.admin_support_settings()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  return (select json_build_object('enabled', s.enabled, 'max_day', s.max_day,
    'blocked', coalesce((select json_agg(json_build_object('id', p.id, 'name', coalesce(nullif(p.display_name, ''), p.email, 'مستخدم'), 'email', p.email))
                         from profiles p where p.id = any(s.blocked)), '[]'::json))
    from support_settings s where s.id = 1);
end $$;

create or replace function public.admin_support_settings_save(p_enabled boolean, p_blocked uuid[], p_max_day integer)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  update support_settings set enabled = coalesce(p_enabled, enabled), blocked = coalesce(p_blocked, blocked),
    max_day = greatest(1, least(50, coalesce(p_max_day, max_day))), updated_at = now() where id = 1;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.support_status()', 'public.support_send(text, text, jsonb, jsonb)', 'public.support_mine()', 'public.support_seen()',
    'public.admin_support_list(text)', 'public.admin_support_counts()', 'public.admin_support_set(bigint, text, text)',
    'public.admin_support_delete(bigint, boolean)', 'public.admin_support_settings()', 'public.admin_support_settings_save(boolean, uuid[], integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- 1.16 — إيصال التحويل: المشترك يرفق صورة الإيصال قبل ما يأكد طلب الدفع
-- ============================================================
alter table public.payment_requests add column if not exists receipt text not null default '';

insert into storage.buckets (id, name, public, file_size_limit)
values ('receipts', 'receipts', false, 10485760)
on conflict (id) do update set public = false, file_size_limit = 10485760;

drop policy if exists "receipts: user uploads own folder" on storage.objects;
create policy "receipts: user uploads own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'receipts' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "receipts: billing read" on storage.objects;
create policy "receipts: billing read" on storage.objects for select to authenticated
  using (bucket_id = 'receipts' and public.has_perm('billing.manage'));
drop policy if exists "receipts: billing delete" on storage.objects;
create policy "receipts: billing delete" on storage.objects for delete to authenticated
  using (bucket_id = 'receipts' and public.has_perm('billing.manage'));

-- يربط الإيصال بطلب الدفع (صاحب الطلب فقط، والطلب لسا بانتظار المراجعة)
create or replace function public.payment_receipt_set(p_id bigint, p_path text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if split_part(coalesce(p_path, ''), '/', 1) <> auth.uid()::text then raise exception 'bad path'; end if;
  update payment_requests set receipt = left(p_path, 200)
   where id = p_id and user_id = auth.uid() and status = 'pending';
end $$;

-- الإيصالات لطلبات الدفع (للوحة التحكم)
create or replace function public.admin_payment_receipts()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return coalesce((select json_object_agg(id, receipt) from (select id, receipt from payment_requests where receipt <> '' order by id desc limit 300) r), '{}'::json);
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.payment_receipt_set(bigint, text)', 'public.admin_payment_receipts()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
