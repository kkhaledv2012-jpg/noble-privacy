-- NOBLE 1.21.10 — المصدر الواحد يقدر يغذّي أكثر من مجال (تختار كذا مجال، وGemini يحط كل خبر في الأنسب منها)
-- الصق هذا مرة وحدة في Supabase ← SQL Editor ← Run
alter table public.news_sources add column if not exists cats text[] not null default '{}';

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint; t text := case when p_src->>'tier' in ('official', 'secondary', 'video') then p_src->>'tier' else '' end;
  cs text[] := case when jsonb_typeof(p_src->'cats') = 'array' then (select coalesce(array_agg(left(x, 20)), '{}') from (select jsonb_array_elements_text(p_src->'cats') x limit 20) q) else null end;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, cats, topic, country, active, lang, rewrite, tier) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), coalesce(cs, '{}'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true),
      case when p_src->>'lang' = 'ar' then 'ar' else 'en' end, coalesce((p_src->>'rewrite')::boolean, false), t)
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, cats = excluded.cats, topic = excluded.topic, country = excluded.country, active = excluded.active,
      lang = excluded.lang, rewrite = excluded.rewrite, tier = excluded.tier
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), cats = coalesce(cs, cats), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active),
      lang = case when p_src ? 'lang' then (case when p_src->>'lang' = 'ar' then 'ar' else 'en' end) else lang end,
      rewrite = coalesce((p_src->>'rewrite')::boolean, rewrite),
      tier = case when p_src ? 'tier' then t else tier end where id = sid;
  end if;
  return sid;
end $$;
revoke all on function public.admin_news_source_save(jsonb) from anon, public;
grant execute on function public.admin_news_source_save(jsonb) to authenticated;
