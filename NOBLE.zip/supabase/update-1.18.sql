-- =====================================================================
--  NOBLE — تحديث قاعدة البيانات للإصدار 1.18
--  «⚡ NOBLE عاجل» (داخل قسم الأخبار): ملخص الذكاء الاصطناعي — يومي أو أسبوعي أو شهري (وعاجل) — كسلايدات فيديو بهوية NOBLE
--   • مصادر الذكاء الاصطناعي بثلاث طبقات: رسمية · ثانوية · قنوات يوتيوب الرسمية
--   • ai_issues: الأعداد (غلاف + سلايدات) — مسودة ← منشور، وتنزل في «اكتشف» تلقائياً
--   • هويتك (الشعار + شريط التوقيع) محفوظة في news_settings.data.aikit
--  الصق الملف كاملاً في: Supabase → SQL Editor → New query → Run   (آمن للتشغيل أكثر من مرة)
-- =====================================================================

-- ---------- طبقة المصدر ----------
-- '' = مصدر أخبار عادي · official = رسمي من الشركة · secondary = موقع تقني (مصدر ثانوي) · video = قناة يوتيوب رسمية
alter table public.news_sources add column if not exists tier text not null default '';
alter table public.news_items   add column if not exists tier text not null default '';

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint; t text := case when p_src->>'tier' in ('official', 'secondary', 'video') then p_src->>'tier' else '' end;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, topic, country, active, lang, rewrite, tier) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true),
      case when p_src->>'lang' = 'ar' then 'ar' else 'en' end, coalesce((p_src->>'rewrite')::boolean, false), t)
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, topic = excluded.topic, country = excluded.country, active = excluded.active,
      lang = excluded.lang, rewrite = excluded.rewrite, tier = excluded.tier
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active),
      lang = case when p_src ? 'lang' then (case when p_src->>'lang' = 'ar' then 'ar' else 'en' end) else lang end,
      rewrite = coalesce((p_src->>'rewrite')::boolean, rewrite),
      tier = case when p_src ? 'tier' then t else tier end where id = sid;
  end if;
  return sid;
end $$;
revoke all on function public.admin_news_source_save(jsonb) from anon, public;
grant execute on function public.admin_news_source_save(jsonb) to authenticated;

-- مصادر الذكاء الاصطناعي (لو تغيّر رابط عند المصدر يظهر «خطأ» جنبه في اللوحة وتعدّله أو توقفه)
-- قنوات يوتيوب: يكفي رابط القناة @ والسيرفر يحوّله لرابط RSS تلقائياً أول مرة
insert into public.news_sources (name, url, cat, topic, lang, tier) values
  ('OpenAI',                'https://openai.com/news/rss.xml',                                 'ai', 'companies', 'en', 'official'),
  ('Google AI',             'https://blog.google/innovation-and-ai/technology/ai/rss/',        'ai', 'companies', 'en', 'official'),
  ('Google DeepMind',       'https://deepmind.google/blog/feed',                               'ai', 'companies', 'en', 'official'),
  ('Google Research',       'https://research.google/blog/rss/',                               'ai', 'companies', 'en', 'official'),
  ('NVIDIA',                'https://blogs.nvidia.com/feed/',                                  'ai', 'companies', 'en', 'official'),
  ('Hugging Face',          'https://huggingface.co/blog/feed.xml',                            'ai', 'tools',     'en', 'official'),
  ('Mistral AI',            'https://mistral.ai/news/rss',                                     'ai', 'companies', 'en', 'official'),
  ('TechCrunch AI',         'https://techcrunch.com/category/artificial-intelligence/feed/',   'ai', '',          'en', 'secondary'),
  ('The Verge AI',          'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml','ai', '',         'en', 'secondary'),
  ('MIT Technology Review', 'https://www.technologyreview.com/topic/artificial-intelligence/feed','ai', '',       'en', 'secondary'),
  ('OpenAI · يوتيوب',        'https://www.youtube.com/@OpenAI',                                 'ai', 'media',     'en', 'video'),
  ('Google DeepMind · يوتيوب','https://www.youtube.com/@googledeepmind',                         'ai', 'media',     'en', 'video'),
  ('Anthropic · يوتيوب',     'https://www.youtube.com/@anthropic-ai',                           'ai', 'media',     'en', 'video')
on conflict (url) do update set tier = excluded.tier;

-- ---------- الأعداد ----------
create table if not exists public.ai_issues (
  id           bigserial primary key,
  kind         text not null default 'weekly',  -- daily · weekly · monthly · urgent
  week         integer not null default 0,
  title        text not null default '',
  kicker       text not null default '',
  date_label   text not null default '',
  look         jsonb not null default '{}'::jsonb,  -- {style, theme, cover:{url,kind}}
  slides       jsonb not null default '[]'::jsonb,  -- [{company, initial, logo, head, body, source, url, tier, news_id, media:{url,kind,poster}, trim:[a,b], rights}]
  cover_url    text not null default '',            -- صورة الغلاف (تنعرض في «اكتشف» وللنسخ القديمة)
  status       text not null default 'draft' check (status in ('draft', 'published')),
  pinned_until timestamptz,                          -- مثبّت كمهم في الرئيسية لين هالوقت
  feed_id      bigint,                               -- منشوره في «اكتشف»
  views        integer not null default 0,
  ai           boolean not null default false,       -- جهّزه Gemini
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  published_at timestamptz
);
create index if not exists ai_issues_feed on public.ai_issues (status, published_at desc);
alter table public.ai_issues drop constraint if exists ai_issues_kind_check;
alter table public.ai_issues add constraint ai_issues_kind_check check (kind in ('daily', 'weekly', 'monthly', 'urgent'));
alter table public.ai_issues enable row level security;  -- القراءة عبر الدوال فقط

-- ---------- للمستخدمين ----------
create or replace function public.ai_feed(p_limit int default 12)
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'kit', (select case when coalesce((data->'aikit'->'sig'->>'inApp')::boolean, false) then data->'aikit' else (data->'aikit') - 'sig' end from news_settings where id = 1),
    'items', coalesce((select json_agg(x order by x.published_at desc) from (
      select id, kind, week, title, kicker, date_label, look, slides, cover_url, pinned_until, feed_id, views, published_at
      from ai_issues where status = 'published' order by published_at desc limit least(greatest(coalesce(p_limit, 12), 1), 40)) x), '[]'::json))
  where auth.uid() is not null;
$$;
create or replace function public.ai_hit(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update ai_issues set views = views + 1 where id = p_id and status = 'published' and auth.uid() is not null;
$$;

-- ---------- للوحة التحكم ----------
create or replace function public.admin_ai_list()
returns json language plpgsql stable security definer set search_path = public as $$
declare job boolean := false;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  begin execute 'select exists (select 1 from cron.job where jobname = ''noble-ai-issue'')' into job; exception when others then job := null; end;
  return json_build_object(
    'kit', (select data->'aikit' from news_settings where id = 1),
    'ai', (select data->'ai' from news_settings where id = 1),
    'has_key', (select coalesce(gemini_key, '') <> '' from news_secret where id = 1),
    'cron', job,
    'items', coalesce((select json_agg(x order by x.created_at desc) from (select * from ai_issues order by created_at desc limit 60) x), '[]'::json));
end $$;

create or replace function public.admin_ai_save(p_issue jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_issue, '{}'::jsonb)::text) > 60000 then raise exception 'too large'; end if;
  if (p_issue->>'id') is null then
    insert into ai_issues (kind, week, title, kicker, date_label, look, slides, cover_url, ai)
    values (case when p_issue->>'kind' in ('daily', 'monthly', 'urgent') then p_issue->>'kind' else 'weekly' end, coalesce((p_issue->>'week')::int, 0),
      left(coalesce(p_issue->>'title', ''), 160), left(coalesce(p_issue->>'kicker', ''), 60), left(coalesce(p_issue->>'date_label', ''), 60),
      coalesce(p_issue->'look', '{}'::jsonb), coalesce(p_issue->'slides', '[]'::jsonb), left(coalesce(p_issue->>'cover_url', ''), 600), coalesce((p_issue->>'ai')::boolean, false))
    returning id into nid;
  else
    nid := (p_issue->>'id')::bigint;
    update ai_issues set
      kind = case when p_issue ? 'kind' then (case when p_issue->>'kind' in ('daily', 'monthly', 'urgent') then p_issue->>'kind' else 'weekly' end) else kind end,
      week = coalesce((p_issue->>'week')::int, week), title = left(coalesce(p_issue->>'title', title), 160),
      kicker = left(coalesce(p_issue->>'kicker', kicker), 60), date_label = left(coalesce(p_issue->>'date_label', date_label), 60),
      look = coalesce(p_issue->'look', look), slides = coalesce(p_issue->'slides', slides),
      cover_url = left(coalesce(p_issue->>'cover_url', cover_url), 600), updated_at = now()
    where id = nid;
  end if;
  -- لو منشور: نحدّث منشوره في «اكتشف»
  update feed_items f set data = f.data || jsonb_build_object('caption', i.title, 'media', jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image'))), updated_at = now()
    from ai_issues i where i.id = nid and i.status = 'published' and f.id = i.feed_id and i.cover_url <> '';
  return nid;
end $$;

-- النشر / الإخفاء / التثبيت — p_discover: ينزل منشور في «اكتشف»
create or replace function public.admin_ai_set(p_id bigint, p_status text, p_pin_days int default null, p_discover boolean default true)
returns json language plpgsql security definer set search_path = public as $$
declare i ai_issues; fid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  select * into i from ai_issues where id = p_id;
  if i.id is null then raise exception 'not found'; end if;
  if p_status = 'published' then
    update ai_issues set status = 'published', published_at = coalesce(published_at, now()), updated_at = now(),
      pinned_until = case when p_pin_days is null then pinned_until when p_pin_days <= 0 then null else now() + make_interval(days => p_pin_days) end
    where id = p_id;
    if coalesce(p_discover, true) then
      if i.feed_id is not null and exists(select 1 from feed_items where id = i.feed_id) then
        update feed_items set active = true, data = data || jsonb_build_object('caption', i.title, 'media', jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image'))), updated_at = now() where id = i.feed_id;
      else
        insert into feed_items (kind, data) values ('post', jsonb_build_object('type', 'ai_issue', 'issue', i.id, 'caption', i.title,
          'media', case when i.cover_url <> '' then jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image')) else '[]'::jsonb end))
        returning id into fid;
        update ai_issues set feed_id = fid where id = p_id;
      end if;
    elsif i.feed_id is not null then
      update feed_items set active = false where id = i.feed_id;
    end if;
  else
    update ai_issues set status = 'draft', pinned_until = null, updated_at = now() where id = p_id;
    if i.feed_id is not null then update feed_items set active = false where id = i.feed_id; end if;
  end if;
  return (select row_to_json(x) from (select id, status, pinned_until, feed_id, published_at from ai_issues where id = p_id) x);
end $$;

create or replace function public.admin_ai_delete(p_id bigint)
returns json language plpgsql security definer set search_path = public as $$
declare i ai_issues;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  select * into i from ai_issues where id = p_id;
  if i.feed_id is not null then delete from feed_items where id = i.feed_id; end if;
  delete from ai_issues where id = p_id;
  return json_build_object('cover', i.cover_url, 'slides', i.slides, 'look', i.look);  -- عشان اللوحة تحذف الملفات من التخزين
end $$;

-- هويتك: الشعار وشريط التوقيع (صورتك، اسمك، حسابك…)
create or replace function public.admin_ai_kit_set(p_kit jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_kit, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update news_settings set data = jsonb_set(coalesce(data, '{}'::jsonb), '{aikit}', coalesce(p_kit, '{}'::jsonb)), updated_at = now() where id = 1;
end $$;


-- إعدادات العدد (عدد الأخبار، الأيام، الشكل الافتراضي) في news_settings.data.ai
create or replace function public.admin_ai_config_set(p_ai jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_ai, '{}'::jsonb)::text) > 4000 then raise exception 'too large'; end if;
  update news_settings set data = jsonb_set(coalesce(data, '{}'::jsonb), '{ai}', coalesce(p_ai, '{}'::jsonb)), updated_at = now() where id = 1;
end $$;

-- حفظ إعدادات الأخبار ما يمسح هويتك وإعدادات «عاجل» لو ما كانت ضمن البيانات المرسلة
create or replace function public.admin_news_set_settings(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 30000 then raise exception 'too large'; end if;
  update news_settings set data = coalesce(p_data, '{}'::jsonb)
      || (case when data ? 'aikit' and not coalesce(p_data, '{}'::jsonb) ? 'aikit' then jsonb_build_object('aikit', data->'aikit') else '{}'::jsonb end)
      || (case when data ? 'ai' and not coalesce(p_data, '{}'::jsonb) ? 'ai' then jsonb_build_object('ai', data->'ai') else '{}'::jsonb end),
    updated_at = now() where id = 1;
end $$;

-- تجهيز العدد تلقائياً (pg_cron) — p_on=false يوقفه
-- p_period: daily (كل يوم) · weekly (يوم p_dow: 0 الأحد … 6 السبت) · monthly (يوم p_dom من الشهر) — الساعة p_hour بتوقيت UTC
drop function if exists public.admin_ai_schedule(text, text, integer, integer, boolean);
create or replace function public.admin_ai_schedule(p_url text, p_anon text, p_period text, p_dow int, p_dom int, p_hour int, p_on boolean)
returns text language plpgsql security definer set search_path = public, extensions as $$
declare sec text; cmd text; hr int := least(greatest(coalesce(p_hour, 15), 0), 23);
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_url, '') !~ '^https://' then raise exception 'invalid url'; end if;
  select cron_secret into sec from news_secret where id = 1;
  begin execute 'select cron.unschedule(''noble-ai-issue'')'; exception when others then null; end;
  if not coalesce(p_on, false) then return 'off'; end if;
  cmd := format('select net.http_post(url := %L, headers := %L::jsonb, body := %L::jsonb, timeout_milliseconds := 120000)',
    p_url, json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || coalesce(p_anon, ''), 'x-news-secret', sec)::text, '{"action":"ai_issue"}');
  begin
    execute format('select cron.schedule(%L, %L, %L)', 'noble-ai-issue',
      case p_period
        when 'daily' then '17 ' || hr || ' * * *'
        when 'monthly' then '17 ' || hr || ' ' || least(greatest(coalesce(p_dom, 1), 1), 28) || ' * *'
        else '17 ' || hr || ' * * ' || least(greatest(coalesce(p_dow, 4), 0), 6) end, cmd);
  exception when others then
    raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة';
  end;
  return 'on';
end $$;

-- ---------- التخزين: مسؤول الأخبار يرفع مقاطع السلايدات في designs/ai/ ----------
do $$ begin
  if exists (select 1 from storage.buckets where id = 'designs') then
    begin execute 'drop policy if exists "designs: ai write" on storage.objects'; exception when others then null; end;
    begin execute 'drop policy if exists "designs: ai delete" on storage.objects'; exception when others then null; end;
    execute 'create policy "designs: ai write" on storage.objects for insert with check (bucket_id = ''designs'' and (storage.foldername(name))[1] = ''ai'' and public.has_perm(''news.manage''))';
    execute 'create policy "designs: ai delete" on storage.objects for delete using (bucket_id = ''designs'' and (storage.foldername(name))[1] = ''ai'' and public.has_perm(''news.manage''))';
  end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.ai_feed(integer)', 'public.ai_hit(bigint)', 'public.admin_ai_list()', 'public.admin_ai_save(jsonb)',
    'public.admin_ai_set(bigint, text, integer, boolean)', 'public.admin_ai_delete(bigint)', 'public.admin_ai_kit_set(jsonb)', 'public.admin_ai_config_set(jsonb)', 'public.admin_news_set_settings(jsonb)',
    'public.admin_ai_schedule(text, text, text, integer, integer, integer, boolean)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- =====================================================================
--  🏪 وضع المتجر (Google Play) + حذف الحساب من داخل التطبيق
--  • وضع المتجر نفسه إعداد في app_config.data.store (من لوحة التحكم ← وضع المتجر)
--  • الدخول المخفي يستخدم «Anonymous sign-ins» — فعّلها من: Authentication ← Sign In / Providers ← Allow anonymous sign-ins
-- =====================================================================
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public, auth as $$
declare me uuid := auth.uid();
begin
  if me is null then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles p where p.id = me and lower(coalesce(p.email, '')) = lower(public.admin_email())) then
    raise exception 'حساب المالك ما ينحذف من التطبيق';
  end if;
  delete from auth.users where id = me;  -- كل الجداول المرتبطة تنحذف معه (cascade)
end $$;
revoke all on function public.delete_my_account() from anon, public;
grant execute on function public.delete_my_account() to authenticated;
