-- NOBLE 1.21.6 — «⬇️ انشر تحت»: ينشر الخبر بس يطلع بعد أخبار اليوم الجديدة (وقت نشره يرجع للخلف كم ساعة)
-- الصقه مرة وحدة: Supabase ← SQL Editor ← New query ← الصق ← Run
create or replace function public.admin_news_publish_back(p_id bigint, p_hours int default 24)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_items set
    status = 'published',
    published_at = now() - make_interval(hours => least(greatest(coalesce(p_hours, 24), 1), 168)),
    updated_at = now()
  where id = p_id;
end $$;
revoke all on function public.admin_news_publish_back(bigint, int) from public, anon;
grant execute on function public.admin_news_publish_back(bigint, int) to authenticated;
