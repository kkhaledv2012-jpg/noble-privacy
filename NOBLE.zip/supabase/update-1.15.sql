-- ============================================================
-- NOBLE 1.15 — «اشتراكي» + الستوري وقسم «اكتشف»
--  • my_subscription(): تاريخ اشتراكات المستخدم كامل (حتى المنتهية) لصفحة «اشتراكي»
--  • feed_items: الستوري والمنشورات (فيديو، صور كاروسيل، استفتاء) — لكل ستوري مدة تنتهي بعدها وتنحذف
--  • إعجاب + استفتاء + مشاهدات + تعليقات (التعليق ما يظهر إلا بعد موافقة الإدارة)
-- شغّله مرة واحدة في SQL Editor بعد update-1.14.sql (آمن لو تكرر)
-- ============================================================

-- ---------- «اشتراكي»: كل الاشتراكات (الفعّالة والمنتهية) ----------
create or replace function public.my_subscription()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'ents', coalesce((select json_agg(json_build_object('id', e.id, 'app', e.app, 'plan', e.plan, 'until', e.until, 'source', e.source,
                        'amount', e.amount, 'revoked', e.revoked, 'created_at', e.created_at) order by e.created_at desc)
                      from entitlements e where e.user_id = auth.uid()), '[]'::json),
    'pays', coalesce((select json_agg(json_build_object('id', p.id, 'app', p.app, 'plan', p.plan, 'amount', p.amount, 'discount', p.discount,
                        'method', p.method, 'status', p.status, 'created_at', p.created_at, 'decided_at', p.decided_at) order by p.created_at desc)
                      from payment_requests p where p.user_id = auth.uid()), '[]'::json))
  where auth.uid() is not null;
$$;

-- ---------- الستوري والمنشورات ----------
create table if not exists public.feed_items (
  id         bigserial primary key,
  kind       text not null default 'post' check (kind in ('story', 'post')),
  data       jsonb not null default '{}'::jsonb,   -- {type: image|video|carousel|poll|text, media:[{url,kind,path}], caption, link:{url,label}, poll:{q, options[]}, ring}
  highlight  boolean not null default false,       -- ستوري «مميزة» دائمة
  expires_at timestamptz,                          -- null = دائم
  active     boolean not null default true,
  sort       integer not null default 0,
  views      integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists feed_items_live on public.feed_items (kind, active, expires_at);

create table if not exists public.feed_likes (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (item_id, user_id)
);
create table if not exists public.feed_votes (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  opt     integer not null,
  created_at timestamptz not null default now(),
  primary key (item_id, user_id)
);
create table if not exists public.feed_seen (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (item_id, user_id)
);
create table if not exists public.feed_comments (
  id         bigserial primary key,
  item_id    bigint not null references public.feed_items(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  body       text not null,
  status     text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now(),
  decided_at timestamptz
);
create index if not exists feed_comments_item on public.feed_comments (item_id, status);
create index if not exists feed_comments_status on public.feed_comments (status, created_at);

create table if not exists public.feed_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {title, sub, comments, storiesOn, discoverOn}
  updated_at timestamptz not null default now()
);
insert into public.feed_settings (id) values (1) on conflict (id) do nothing;

alter table public.feed_items enable row level security;
alter table public.feed_likes enable row level security;
alter table public.feed_votes enable row level security;
alter table public.feed_seen enable row level security;
alter table public.feed_comments enable row level security;
alter table public.feed_settings enable row level security;

-- للمستخدم: الستوري والمنشورات الحية (المنتهية ما تطلع) + تفاعله
create or replace function public.feed_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from feed_settings where id = 1),
    'items', coalesce((select json_agg(x order by x.highlight desc, x.sort, x.created_at desc) from (
      select f.id, f.kind, f.data, f.highlight, f.expires_at, f.sort, f.created_at, f.views,
        (select count(*) from feed_likes l where l.item_id = f.id) as likes,
        exists(select 1 from feed_likes l where l.item_id = f.id and l.user_id = auth.uid()) as liked,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'approved') as comments,
        (select v.opt from feed_votes v where v.item_id = f.id and v.user_id = auth.uid()) as voted,
        (select coalesce(json_object_agg(opt, n), '{}'::json) from (select v.opt, count(*) n from feed_votes v where v.item_id = f.id group by v.opt) t) as tally
      from feed_items f
      where f.active and (f.expires_at is null or f.expires_at > now())) x), '[]'::json))
  where auth.uid() is not null;
$$;

create or replace function public.feed_like(p_id bigint)
returns json language plpgsql security definer set search_path = public as $$
declare on_ boolean;
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if exists(select 1 from feed_likes where item_id = p_id and user_id = auth.uid()) then
    delete from feed_likes where item_id = p_id and user_id = auth.uid(); on_ := false;
  else
    insert into feed_likes (item_id, user_id) select p_id, auth.uid() where exists(select 1 from feed_items where id = p_id and active); on_ := true;
  end if;
  return json_build_object('liked', on_, 'likes', (select count(*) from feed_likes where item_id = p_id));
end $$;

create or replace function public.feed_vote(p_id bigint, p_opt integer)
returns json language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if p_opt < 0 or p_opt > 9 then raise exception 'bad option'; end if;
  insert into feed_votes (item_id, user_id, opt) select p_id, auth.uid(), p_opt where exists(select 1 from feed_items where id = p_id and active)
  on conflict (item_id, user_id) do update set opt = excluded.opt, created_at = now();
  return (select coalesce(json_object_agg(opt, n), '{}'::json) from (select opt, count(*) n from feed_votes where item_id = p_id group by opt) t);
end $$;

create or replace function public.feed_seen_mark(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into feed_seen (item_id, user_id) values (p_id, auth.uid()) on conflict do nothing;
  if found then update feed_items set views = views + 1 where id = p_id; end if;
end $$;

-- التعليقات: الموافق عليها + تعليقاتي اللي تنتظر
create or replace function public.feed_comments_list(p_id bigint)
returns json language sql stable security definer set search_path = public as $$
  select coalesce(json_agg(json_build_object('id', c.id, 'body', c.body, 'status', c.status, 'mine', c.user_id = auth.uid(), 'created_at', c.created_at,
           'name', coalesce(nullif(split_part(p.display_name, ' ', 1), ''), 'مستخدم')) order by c.created_at), '[]'::json)
  from feed_comments c left join profiles p on p.id = c.user_id
  where auth.uid() is not null and c.item_id = p_id and (c.status = 'approved' or c.user_id = auth.uid());
$$;

create or replace function public.feed_comment(p_id bigint, p_body text)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; b text := btrim(coalesce(p_body, ''));
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if length(b) < 1 then raise exception 'empty'; end if;
  if length(b) > 500 then b := left(b, 500); end if;
  if coalesce((select (data->>'comments')::boolean from feed_settings where id = 1), true) = false then raise exception 'comments off'; end if;
  if (select count(*) from feed_comments where user_id = auth.uid() and created_at > now() - interval '1 day') >= 30 then raise exception 'limit'; end if;
  insert into feed_comments (item_id, user_id, body) select p_id, auth.uid(), b where exists(select 1 from feed_items where id = p_id and active)
  returning id into nid;
  return nid;
end $$;

-- ---------- لوحة التحكم ----------
create or replace function public.admin_feed()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return json_build_object(
    'meta', (select data from feed_settings where id = 1),
    'items', coalesce((select json_agg(x order by x.kind, x.highlight desc, x.sort, x.created_at desc) from (
      select f.*, (select count(*) from feed_likes l where l.item_id = f.id) as likes,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'approved') as comments,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'pending') as pending,
        (select coalesce(json_object_agg(opt, n), '{}'::json) from (select v.opt, count(*) n from feed_votes v where v.item_id = f.id group by v.opt) t) as tally
      from feed_items f) x), '[]'::json),
    'pending', (select count(*) from feed_comments where status = 'pending'));
end $$;

create or replace function public.admin_feed_save(p_id bigint, p_kind text, p_data jsonb, p_expires timestamptz, p_highlight boolean, p_active boolean, p_sort integer)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 30000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into feed_items (kind, data, expires_at, highlight, active, sort)
    values (case when p_kind = 'story' then 'story' else 'post' end, coalesce(p_data, '{}'::jsonb), p_expires, coalesce(p_highlight, false), coalesce(p_active, true), coalesce(p_sort, 0))
    returning id into nid;
  else
    update feed_items set data = coalesce(p_data, data), expires_at = p_expires, highlight = coalesce(p_highlight, highlight),
      active = coalesce(p_active, active), sort = coalesce(p_sort, sort), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  return nid;
end $$;

create or replace function public.admin_feed_delete(p_id bigint)
returns jsonb language plpgsql security definer set search_path = public as $$
declare d jsonb;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  delete from feed_items where id = p_id returning data into d;
  return d; -- اللوحة تحذف ملفاته من Storage
end $$;

-- المنتهية (غير المميزة): اللوحة تحذف ملفاتها من Storage ثم تحذفها من الجدول
create or replace function public.admin_feed_expired()
returns setof feed_items language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return query select * from feed_items where not highlight and expires_at is not null and expires_at <= now();
end $$;

create or replace function public.admin_feed_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update feed_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

create or replace function public.admin_feed_comments(p_status text default 'pending')
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return coalesce((select json_agg(json_build_object('id', c.id, 'item_id', c.item_id, 'body', c.body, 'status', c.status, 'created_at', c.created_at,
      'name', coalesce(p.display_name, p.email, 'مستخدم'), 'email', p.email, 'caption', left(coalesce(f.data->>'caption', ''), 80)) order by c.created_at desc)
    from (select * from feed_comments where status = coalesce(p_status, 'pending') order by created_at desc limit 300) c
    left join profiles p on p.id = c.user_id left join feed_items f on f.id = c.item_id), '[]'::json);
end $$;

create or replace function public.admin_feed_comment_set(p_id bigint, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if p_status = 'delete' then delete from feed_comments where id = p_id; return; end if;
  if p_status not in ('approved', 'rejected', 'pending') then raise exception 'bad status'; end if;
  update feed_comments set status = p_status, decided_at = now() where id = p_id;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.my_subscription()', 'public.feed_list()', 'public.feed_like(bigint)', 'public.feed_vote(bigint, integer)',
    'public.feed_seen_mark(bigint)', 'public.feed_comments_list(bigint)', 'public.feed_comment(bigint, text)',
    'public.admin_feed()', 'public.admin_feed_save(bigint, text, jsonb, timestamptz, boolean, boolean, integer)', 'public.admin_feed_delete(bigint)',
    'public.admin_feed_expired()', 'public.admin_feed_meta(jsonb)', 'public.admin_feed_comments(text)', 'public.admin_feed_comment_set(bigint, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
