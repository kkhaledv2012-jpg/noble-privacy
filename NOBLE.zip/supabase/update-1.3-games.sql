-- ============================================================
-- NOBLE 1.3 — لوحة تحكم الألعاب
-- شغّله مرة واحدة في SQL Editor بعد update-1.2.sql (آمن لو تكرر)
-- ============================================================

-- إعدادات الألعاب (الأسماء، العروض، النقاط، الأبطال، المراحل، الصدارة)
alter table public.app_config add column if not exists games jsonb not null default '{}'::jsonb;
-- حظر لاعب من الصدارة
alter table public.profiles add column if not exists game_banned boolean not null default false;

create or replace function public.admin_set_games(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  update app_config set games = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('games');
end $$;

-- مضاعف النقاط الحالي (عرض فعّال على هذه اللعبة)
create or replace function public.game_multiplier(p_game text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((
    select least(greatest((g->'event'->>'mult')::numeric, 1), 5)
      from (select games g from app_config where id = 1) c
     where (g->'event'->>'on')::boolean is true
       and (coalesce(g->'event'->>'until', '') = '' or (g->'event'->>'until')::timestamptz > now())
       and (g->'event'->'games' is null or g->'event'->'games' ? p_game)
  ), 1);
$$;

create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'tasks' then 50 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- الصدارة العامة: تستبعد المحظورين
create or replace function public.leaderboard(p_period text default 'week', p_limit integer default 50)
returns table (rank bigint, nickname text, points bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  with s as (
    select g.user_id, sum(g.score) pts
      from game_scores g
     where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                          when 'month' then now() - interval '30 days'
                                          else '-infinity'::timestamptz end
     group by g.user_id
  )
  select rank() over (order by s.pts desc),
         case when p.show_on_board then coalesce(nullif(p.nickname, ''), 'لاعب ' || upper(left(p.id::text, 4))) else 'لاعب مخفي' end,
         s.pts, s.user_id = auth.uid()
    from s join profiles p on p.id = s.user_id
   where p.status = 'active' and not p.game_banned and (p.show_on_board or s.user_id = auth.uid())
   order by s.pts desc
   limit least(p_limit, 100);
$$;

-- صدارة الإدارة: مع البريد وحالة الإخفاء والحظر
create or replace function public.admin_leaderboard(p_period text default 'all', p_limit integer default 100)
returns table (user_id uuid, email text, nickname text, show_on_board boolean, game_banned boolean, points bigint, plays bigint, last_play timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  return query
  select p.id, p.email, p.nickname, p.show_on_board, p.game_banned, sum(g.score)::bigint, count(*)::bigint, max(g.created_at)
    from game_scores g join profiles p on p.id = g.user_id
   where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                        when 'month' then now() - interval '30 days'
                                        else '-infinity'::timestamptz end
   group by p.id
   order by 6 desc
   limit least(p_limit, 500);
end $$;

create or replace function public.admin_set_player(p_uid uuid, p_nickname text, p_show boolean, p_banned boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  update profiles set nickname = nullif(left(trim(coalesce(p_nickname, '')), 20), ''),
                      show_on_board = coalesce(p_show, show_on_board),
                      game_banned = coalesce(p_banned, game_banned)
   where id = p_uid;
  perform public.log_action('player', p_uid, json_build_object('nickname', p_nickname, 'show', p_show, 'banned', p_banned)::jsonb);
end $$;

-- تصفير النقاط: للاعب محدد أو للجميع (موسم جديد)، ولكل الألعاب أو لعبة واحدة
create or replace function public.admin_reset_scores(p_uid uuid default null, p_game text default null)
returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  delete from game_scores where (p_uid is null or user_id = p_uid) and (p_game is null or game = p_game);
  get diagnostics n = row_count;
  perform public.log_action('reset_scores', p_uid, json_build_object('game', p_game, 'rows', n)::jsonb);
  return n;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_set_games(jsonb)', 'public.game_multiplier(text)', 'public.submit_score(text, integer, jsonb)',
    'public.leaderboard(text, integer)', 'public.admin_leaderboard(text, integer)',
    'public.admin_set_player(uuid, text, boolean, boolean)', 'public.admin_reset_scores(uuid, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
