-- NOBLE — الإعداد الكامل لقاعدة البيانات (الأساس + 1.2 + 1.3 + 1.4 + 1.5 + 1.7 + 1.8 + 1.9 + 1.10 + 1.12 + 1.13) في ملف واحد
-- شغّله مرة واحدة كاملاً في SQL Editor. آمن لو تكرر، ولا يحذف بياناتك.

-- =====================================================================
--  NOBLE — إعداد قاعدة البيانات على Supabase (الخطة المجانية)
--  الصق هذا الملف كاملاً في: Supabase → SQL Editor → New query → Run
--
--  ⚠️ غيّر الإيميل في السطر التالي إلى إيميلك — أول حساب يسجّل به يصبح «أدمن».
-- =====================================================================
create or replace function public.admin_email() returns text
language sql immutable as $$ select 'kkhaledv2012@gmail.com'::text $$;

-- ---------- الجداول ----------
create table if not exists public.profiles (
  id            uuid primary key references auth.users(id) on delete cascade,
  email         text,
  display_name  text default '',
  role          text not null default 'user'   check (role in ('user','admin')),
  status        text not null default 'active' check (status in ('active','suspended')),
  items_count   integer not null default 0,
  app_version   text,
  created_at    timestamptz not null default now(),
  last_seen_at  timestamptz
);

-- الخزنة: كتلة مشفّرة بكلمة مرور المستخدم (AES-256-GCM) — لا يمكن لأحد قراءتها، ولا حتى الأدمن.
create table if not exists public.vaults (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  data        jsonb not null,
  updated_at  timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.vaults   enable row level security;

-- ---------- دوال مساعدة ----------
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and role = 'admin' and status = 'active');
$$;

create or replace function public.is_active() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from profiles where id = auth.uid() and status = 'active');
$$;

-- ---------- الصلاحيات (RLS) ----------
drop policy if exists "profiles: self or admin can read" on public.profiles;
create policy "profiles: self or admin can read" on public.profiles
  for select using (id = auth.uid() or public.is_admin());

drop policy if exists "vaults: owner read"   on public.vaults;
drop policy if exists "vaults: owner insert" on public.vaults;
drop policy if exists "vaults: owner update" on public.vaults;
create policy "vaults: owner read"   on public.vaults for select using (user_id = auth.uid() and public.is_active());
create policy "vaults: owner insert" on public.vaults for insert with check (user_id = auth.uid() and public.is_active());
create policy "vaults: owner update" on public.vaults for update using (user_id = auth.uid() and public.is_active()) with check (user_id = auth.uid());
-- لا توجد سياسة تسمح للأدمن بقراءة الخزائن — عن قصد.

-- ---------- إنشاء ملف المستخدم تلقائياً عند التسجيل ----------
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name, role)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'display_name', ''),
    case when lower(new.email) = lower(public.admin_email()) then 'admin' else 'user' end
  )
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------- دوال التطبيق ----------
-- يسجّل آخر ظهور وعدد المواقع (رقم فقط، بدون محتوى)
create or replace function public.touch_profile(p_items integer, p_version text default null)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set last_seen_at = now(), items_count = greatest(0, coalesce(p_items, items_count)),
         app_version = coalesce(p_version, app_version)
   where id = auth.uid() returning * into r;
  return r;
end $$;

-- ---------- دوال الأدمن ----------
create or replace function public.admin_set_status(p_uid uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot change your own status'; end if;
  update profiles set status = p_status where id = p_uid;
end $$;

create or replace function public.admin_set_role(p_uid uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot change your own role'; end if;
  update profiles set role = p_role where id = p_uid;
end $$;

create or replace function public.admin_set_name(p_uid uuid, p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  update profiles set display_name = left(coalesce(p_name, ''), 80) where id = p_uid;
end $$;

-- حذف المستخدم نهائياً (الحساب + خزنته المشفّرة)
create or replace function public.admin_delete_user(p_uid uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  if p_uid = auth.uid() then raise exception 'cannot delete yourself'; end if;
  delete from auth.users where id = p_uid;
end $$;

create or replace function public.admin_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  return json_build_object(
    'users',       (select count(*) from profiles),
    'active_7d',   (select count(*) from profiles where last_seen_at > now() - interval '7 days'),
    'new_7d',      (select count(*) from profiles where created_at  > now() - interval '7 days'),
    'suspended',   (select count(*) from profiles where status = 'suspended'),
    'admins',      (select count(*) from profiles where role = 'admin'),
    'total_items', (select coalesce(sum(items_count), 0) from profiles)
  );
end $$;

revoke all on function public.touch_profile(integer, text), public.admin_set_status(uuid, text), public.admin_set_role(uuid, text),
  public.admin_set_name(uuid, text), public.admin_delete_user(uuid), public.admin_stats() from anon, public;
grant execute on function public.touch_profile(integer, text), public.admin_set_status(uuid, text), public.admin_set_role(uuid, text),
  public.admin_set_name(uuid, text), public.admin_delete_user(uuid), public.admin_stats() to authenticated;

-- إن كنت سجّلت حسابك قبل تشغيل هذا الملف، هذا السطر يجعله أدمن:
insert into public.profiles (id, email, role)
  select id, email, 'admin' from auth.users where lower(email) = lower(public.admin_email())
  on conflict (id) do update set role = 'admin';

-- =====================================================================
--  محتوى التطبيق (نصوص، إعلان، ثيم افتراضي، روابط، إشعار تحديث)
--  يقرؤه الجميع، ويعدّله الأدمن فقط من لوحة التحكم.
-- =====================================================================
create table if not exists public.app_config (
  id          integer primary key default 1 check (id = 1),
  data        jsonb not null default '{}'::jsonb,
  updated_at  timestamptz not null default now()
);
insert into public.app_config (id) values (1) on conflict (id) do nothing;
alter table public.app_config enable row level security;
drop policy if exists "config: anyone can read" on public.app_config;
create policy "config: anyone can read" on public.app_config for select using (true);

create or replace function public.admin_set_config(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not allowed'; end if;
  update app_config set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;
revoke all on function public.admin_set_config(jsonb) from anon, public;
grant execute on function public.admin_set_config(jsonb) to authenticated;

-- NOBLE — كل التحديثات (1.2 + 1.3 + 1.4) في ملف واحد. شغّله مرة واحدة كاملاً (آمن لو تكرر)
-- =====================================================================
--  NOBLE — تحديث قاعدة البيانات للإصدار 1.2
--  الأدوار والصلاحيات، الرسائل، سجل النشاط، الألعاب ولوحة الصدارة
--  الصق الملف كاملاً في: Supabase → SQL Editor → New query → Run
--  (آمن للتشغيل أكثر من مرة)
-- =====================================================================

-- ---------- أعمدة جديدة في ملف المستخدم ----------
alter table public.profiles add column if not exists nickname text;
alter table public.profiles add column if not exists show_on_board boolean not null default true;
alter table public.profiles add column if not exists disabled_sections text[] not null default '{}';

alter table public.profiles drop constraint if exists profiles_role_check;
alter table public.profiles add constraint profiles_role_check
  check (role in ('owner', 'admin', 'moderator', 'editor', 'support', 'user'));

-- صاحب إيميل الأدمن يصبح «المالك»
update public.profiles set role = 'owner' where lower(email) = lower(public.admin_email());

-- ---------- الصلاحيات ----------
-- رتبة كل دور (الأعلى يتحكم فيمن تحته فقط)
create or replace function public.role_rank(p_role text) returns int
language sql immutable as $$
  select case p_role when 'owner' then 100 when 'admin' then 80 when 'moderator' then 60
                     when 'editor' then 40 when 'support' then 30 else 0 end;
$$;

create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

create or replace function public.my_role() returns text
language sql stable security definer set search_path = public as $$
  select role from profiles where id = auth.uid() and status = 'active';
$$;

create or replace function public.has_perm(p text) returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(p = any(public.role_perms(public.my_role())), false);
$$;

-- للتوافق مع الإصدار السابق: «أدمن» = من يملك إدارة المستخدمين أو رؤيتهم
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_perm('users.view');
$$;

create or replace function public.my_permissions() returns json
language sql stable security definer set search_path = public as $$
  select json_build_object('role', coalesce(public.my_role(), 'user'), 'perms', public.role_perms(public.my_role()));
$$;

-- يمنع التحكم في من هو أعلى أو مساوٍ لك (إلا المالك)
create or replace function public.can_manage(p_uid uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select p_uid <> auth.uid() and (
    public.my_role() = 'owner' or
    public.role_rank(public.my_role()) > (select public.role_rank(role) from profiles where id = p_uid)
  );
$$;

-- ---------- سجل النشاط ----------
create table if not exists public.activity_log (
  id          bigserial primary key,
  actor       uuid,
  actor_email text,
  action      text not null,
  target      uuid,
  target_email text,
  meta        jsonb not null default '{}'::jsonb,
  at          timestamptz not null default now()
);
alter table public.activity_log enable row level security;
drop policy if exists "log: staff read" on public.activity_log;
create policy "log: staff read" on public.activity_log for select using (public.has_perm('logs.view'));

create or replace function public.log_action(p_action text, p_target uuid default null, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  insert into activity_log (actor, actor_email, action, target, target_email, meta)
  values (auth.uid(), (select email from profiles where id = auth.uid()), p_action, p_target,
          (select email from profiles where id = p_target), coalesce(p_meta, '{}'::jsonb));
end $$;

-- نشاط يومي (يوم واحد لكل مستخدم) للرسوم البيانية
create table if not exists public.activity_daily (
  user_id uuid references auth.users(id) on delete cascade,
  day     date not null default current_date,
  primary key (user_id, day)
);
alter table public.activity_daily enable row level security;

-- ---------- تحديث دوال المستخدم ----------
create or replace function public.touch_profile(p_items integer, p_version text default null)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set last_seen_at = now(), items_count = greatest(0, coalesce(p_items, items_count)),
         app_version = coalesce(p_version, app_version)
   where id = auth.uid() returning * into r;
  insert into activity_daily (user_id) values (auth.uid()) on conflict do nothing;
  return r;
end $$;

create or replace function public.update_my_profile(p_name text, p_nickname text, p_show boolean)
returns public.profiles language plpgsql security definer set search_path = public as $$
declare r public.profiles;
begin
  update profiles set display_name = left(coalesce(p_name, ''), 80),
         nickname = nullif(left(trim(coalesce(p_nickname, '')), 24), ''),
         show_on_board = coalesce(p_show, true)
   where id = auth.uid() returning * into r;
  return r;
end $$;

-- مزامنة الإيميل عند تغييره من الحساب
create or replace function public.handle_user_update() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.email is distinct from old.email then
    update profiles set email = new.email where id = new.id;
  end if;
  return new;
end $$;
drop trigger if exists on_auth_user_updated on auth.users;
create trigger on_auth_user_updated after update on auth.users
  for each row execute function public.handle_user_update();

-- المستخدم الجديد: المالك حسب الإيميل، وتسجيل الحدث
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, display_name, role)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'display_name', ''),
          case when lower(new.email) = lower(public.admin_email()) then 'owner' else 'user' end)
  on conflict (id) do nothing;
  insert into activity_log (actor, actor_email, action, target, target_email)
  values (new.id, new.email, 'signup', new.id, new.email);
  return new;
end $$;

-- ---------- دوال الإدارة بالصلاحيات ----------
create or replace function public.admin_set_status(p_uid uuid, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  update profiles set status = p_status where id = p_uid;
  perform public.log_action(case when p_status = 'suspended' then 'suspend' else 'activate' end, p_uid);
end $$;

create or replace function public.admin_set_role(p_uid uuid, p_role text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('roles.manage') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  if p_role = 'owner' or (public.my_role() <> 'owner' and public.role_rank(p_role) >= public.role_rank(public.my_role())) then
    raise exception 'not allowed';
  end if;
  update profiles set role = p_role where id = p_uid;
  perform public.log_action('role', p_uid, json_build_object('role', p_role)::jsonb);
end $$;

create or replace function public.admin_set_name(p_uid uuid, p_name text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') then raise exception 'not allowed'; end if;
  update profiles set display_name = left(coalesce(p_name, ''), 80) where id = p_uid;
  perform public.log_action('rename', p_uid, json_build_object('name', p_name)::jsonb);
end $$;

create or replace function public.admin_delete_user(p_uid uuid)
returns void language plpgsql security definer set search_path = public, auth as $$
begin
  if not public.has_perm('users.delete') or not public.can_manage(p_uid) then raise exception 'not allowed'; end if;
  perform public.log_action('delete', p_uid);
  delete from auth.users where id = p_uid;
end $$;

create or replace function public.admin_set_sections(p_uid uuid, p_sections text[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  update profiles set disabled_sections = coalesce(p_sections, '{}') where id = p_uid;
  perform public.log_action('sections', p_uid, json_build_object('off', p_sections)::jsonb);
end $$;

create or replace function public.admin_set_config(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  update app_config set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('content');
end $$;

create or replace function public.admin_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('stats.view') then raise exception 'not allowed'; end if;
  return json_build_object(
    'users',       (select count(*) from profiles),
    'active_7d',   (select count(*) from profiles where last_seen_at > now() - interval '7 days'),
    'new_7d',      (select count(*) from profiles where created_at  > now() - interval '7 days'),
    'suspended',   (select count(*) from profiles where status = 'suspended'),
    'admins',      (select count(*) from profiles where role <> 'user'),
    'total_items', (select coalesce(sum(items_count), 0) from profiles),
    'games_played',(select count(*) from game_scores),
    'signups', (select coalesce(json_agg(json_build_object('d', d, 'n', n) order by d), '[]'::json) from (
        select g::date d, (select count(*) from profiles where created_at::date = g::date) n
        from generate_series(current_date - 29, current_date, '1 day') g) s),
    'active', (select coalesce(json_agg(json_build_object('d', d, 'n', n) order by d), '[]'::json) from (
        select g::date d, (select count(*) from activity_daily where day = g::date) n
        from generate_series(current_date - 29, current_date, '1 day') g) s)
  );
end $$;

-- ---------- الرسائل ----------
create table if not exists public.messages (
  id         bigserial primary key,
  sender     uuid,
  target     uuid references auth.users(id) on delete cascade,  -- null = للجميع
  title      text not null,
  body       text not null default '',
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
drop policy if exists "messages: mine or broadcast" on public.messages;
create policy "messages: mine or broadcast" on public.messages for select
  using (target = auth.uid() or target is null or public.has_perm('messages.send') or public.has_perm('messages.broadcast'));

create or replace function public.admin_send_message(p_target uuid, p_title text, p_body text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_target is null and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if p_target is not null and not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  insert into messages (sender, target, title, body) values (auth.uid(), p_target, left(p_title, 120), left(coalesce(p_body, ''), 2000));
  perform public.log_action('message', p_target, json_build_object('title', p_title)::jsonb);
end $$;

create or replace function public.admin_delete_message(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('messages.broadcast') or public.has_perm('messages.send')) then raise exception 'not allowed'; end if;
  delete from messages where id = p_id;
end $$;

-- ---------- الألعاب ولوحة الصدارة ----------
create table if not exists public.game_scores (
  id         bigserial primary key,
  user_id    uuid references auth.users(id) on delete cascade,
  game       text not null,
  score      integer not null check (score >= 0),
  meta       jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists game_scores_time on public.game_scores (created_at);
alter table public.game_scores enable row level security;
drop policy if exists "scores: own read" on public.game_scores;
create policy "scores: own read" on public.game_scores for select using (user_id = auth.uid());

create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'tasks' then 50 else 1000 end;
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- لوحة الصدارة: اسم مستعار ونقاط فقط — بدون إيميلات أو معرّفات
create or replace function public.leaderboard(p_period text default 'week', p_limit integer default 50)
returns table (rank bigint, nickname text, points bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  with s as (
    select g.user_id, sum(g.score) pts
      from game_scores g
     where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                          when 'month' then now() - interval '30 days'
                                          else '-infinity'::timestamptz end
     group by g.user_id
  )
  select rank() over (order by s.pts desc),
         case when p.show_on_board then coalesce(nullif(p.nickname, ''), 'لاعب ' || upper(left(p.id::text, 4))) else 'لاعب مخفي' end,
         s.pts, s.user_id = auth.uid()
    from s join profiles p on p.id = s.user_id
   where p.status = 'active' and (p.show_on_board or s.user_id = auth.uid())
   order by s.pts desc
   limit least(p_limit, 100);
$$;

-- ---------- الصلاحيات على الدوال ----------
do $$
declare f text;
begin
  foreach f in array array[
    'public.my_permissions()', 'public.update_my_profile(text, text, boolean)', 'public.admin_set_sections(uuid, text[])',
    'public.admin_send_message(uuid, text, text)', 'public.admin_delete_message(bigint)', 'public.submit_score(text, integer, jsonb)',
    'public.leaderboard(text, integer)', 'public.touch_profile(integer, text)', 'public.admin_set_status(uuid, text)',
    'public.admin_set_role(uuid, text)', 'public.admin_set_name(uuid, text)', 'public.admin_delete_user(uuid)',
    'public.admin_set_config(jsonb)', 'public.admin_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.3 — لوحة تحكم الألعاب
-- شغّله مرة واحدة في SQL Editor بعد update-1.2.sql (آمن لو تكرر)
-- ============================================================

-- إعدادات الألعاب (الأسماء، العروض، النقاط، الأبطال، المراحل، الصدارة)
alter table public.app_config add column if not exists games jsonb not null default '{}'::jsonb;
-- حظر لاعب من الصدارة
alter table public.profiles add column if not exists game_banned boolean not null default false;

create or replace function public.admin_set_games(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  update app_config set games = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('games');
end $$;

-- مضاعف النقاط الحالي (عرض فعّال على هذه اللعبة)
create or replace function public.game_multiplier(p_game text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((
    select least(greatest((g->'event'->>'mult')::numeric, 1), 5)
      from (select games g from app_config where id = 1) c
     where (g->'event'->>'on')::boolean is true
       and (coalesce(g->'event'->>'until', '') = '' or (g->'event'->>'until')::timestamptz > now())
       and (g->'event'->'games' is null or g->'event'->'games' ? p_game)
  ), 1);
$$;

create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'tasks' then 50 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- الصدارة العامة: تستبعد المحظورين
create or replace function public.leaderboard(p_period text default 'week', p_limit integer default 50)
returns table (rank bigint, nickname text, points bigint, is_me boolean)
language sql stable security definer set search_path = public as $$
  with s as (
    select g.user_id, sum(g.score) pts
      from game_scores g
     where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                          when 'month' then now() - interval '30 days'
                                          else '-infinity'::timestamptz end
     group by g.user_id
  )
  select rank() over (order by s.pts desc),
         case when p.show_on_board then coalesce(nullif(p.nickname, ''), 'لاعب ' || upper(left(p.id::text, 4))) else 'لاعب مخفي' end,
         s.pts, s.user_id = auth.uid()
    from s join profiles p on p.id = s.user_id
   where p.status = 'active' and not p.game_banned and (p.show_on_board or s.user_id = auth.uid())
   order by s.pts desc
   limit least(p_limit, 100);
$$;

-- صدارة الإدارة: مع البريد وحالة الإخفاء والحظر
create or replace function public.admin_leaderboard(p_period text default 'all', p_limit integer default 100)
returns table (user_id uuid, email text, nickname text, show_on_board boolean, game_banned boolean, points bigint, plays bigint, last_play timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  return query
  select p.id, p.email, p.nickname, p.show_on_board, p.game_banned, sum(g.score)::bigint, count(*)::bigint, max(g.created_at)
    from game_scores g join profiles p on p.id = g.user_id
   where g.created_at > case p_period when 'week' then now() - interval '7 days'
                                        when 'month' then now() - interval '30 days'
                                        else '-infinity'::timestamptz end
   group by p.id
   order by 6 desc
   limit least(p_limit, 500);
end $$;

create or replace function public.admin_set_player(p_uid uuid, p_nickname text, p_show boolean, p_banned boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  update profiles set nickname = nullif(left(trim(coalesce(p_nickname, '')), 20), ''),
                      show_on_board = coalesce(p_show, show_on_board),
                      game_banned = coalesce(p_banned, game_banned)
   where id = p_uid;
  perform public.log_action('player', p_uid, json_build_object('nickname', p_nickname, 'show', p_show, 'banned', p_banned)::jsonb);
end $$;

-- تصفير النقاط: للاعب محدد أو للجميع (موسم جديد)، ولكل الألعاب أو لعبة واحدة
create or replace function public.admin_reset_scores(p_uid uuid default null, p_game text default null)
returns integer language plpgsql security definer set search_path = public as $$
declare n integer;
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  delete from game_scores where (p_uid is null or user_id = p_uid) and (p_game is null or game = p_game);
  get diagnostics n = row_count;
  perform public.log_action('reset_scores', p_uid, json_build_object('game', p_game, 'rows', n)::jsonb);
  return n;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_set_games(jsonb)', 'public.game_multiplier(text)', 'public.submit_score(text, integer, jsonb)',
    'public.leaderboard(text, integer)', 'public.admin_leaderboard(text, integer)',
    'public.admin_set_player(uuid, text, boolean, boolean)', 'public.admin_reset_scores(uuid, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.4 — الرسائل الإجبارية + المزامنة الفورية
-- شغّله مرة واحدة في SQL Editor بعد update-1.3-games.sql (آمن لو تكرر)
-- ============================================================

-- ---------- الرسائل الإجبارية (إعلانات يجب قراءتها) ----------
create table if not exists public.notices (
  id         bigserial primary key,
  title      text not null,
  body       text not null default '',
  image_url  text not null default '',
  link       text not null default '',
  level      text not null default 'screen' check (level in ('screen', 'bar')),
  active     boolean not null default true,
  created_by uuid,
  created_at timestamptz not null default now()
);
create table if not exists public.notice_reads (
  notice_id bigint references public.notices(id) on delete cascade,
  user_id   uuid references auth.users(id) on delete cascade,
  read_at   timestamptz not null default now(),
  primary key (notice_id, user_id)
);
alter table public.notices enable row level security;
alter table public.notice_reads enable row level security;

drop policy if exists "notices: read active" on public.notices;
create policy "notices: read active" on public.notices for select
  using (active or public.has_perm('messages.broadcast'));
drop policy if exists "reads: mine" on public.notice_reads;
create policy "reads: mine" on public.notice_reads for select
  using (user_id = auth.uid() or public.has_perm('messages.broadcast'));

create or replace function public.admin_create_notice(p_title text, p_body text, p_image text, p_link text, p_level text)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  insert into notices (title, body, image_url, link, level, created_by)
  values (left(p_title, 120), left(coalesce(p_body, ''), 3000), left(coalesce(p_image, ''), 600), left(coalesce(p_link, ''), 600),
          case when p_level = 'bar' then 'bar' else 'screen' end, auth.uid())
  returning id into nid;
  perform public.log_action('notice', null, json_build_object('title', p_title, 'level', p_level)::jsonb);
  return nid;
end $$;

create or replace function public.admin_set_notice(p_id bigint, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  update notices set active = p_active where id = p_id;
end $$;

create or replace function public.admin_delete_notice(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  delete from notices where id = p_id;
end $$;

-- الإعلانات مع عدد من قرأها من إجمالي المستخدمين النشطين
drop function if exists public.admin_notices();
create or replace function public.admin_notices()
returns table (id bigint, title text, body text, image_url text, link text, level text, active boolean, created_at timestamptz, reads bigint, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select n.id, n.title, n.body, n.image_url, n.link, n.level, n.active, n.created_at,
         (select count(*) from notice_reads r where r.notice_id = n.id),
         (select count(*) from profiles where status = 'active')
    from notices n order by n.id desc;
end $$;

-- من قرأ ومن لم يقرأ
create or replace function public.admin_notice_readers(p_id bigint)
returns table (user_id uuid, email text, name text, read_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select p.id, p.email, p.display_name, r.read_at
    from profiles p left join notice_reads r on r.user_id = p.id and r.notice_id = p_id
   where p.status = 'active'
   order by r.read_at desc nulls last;
end $$;

-- إعلاناتي غير المقروءة
create or replace function public.my_notices()
returns setof public.notices language sql stable security definer set search_path = public as $$
  select n.* from notices n
   where n.active and not exists (select 1 from notice_reads r where r.notice_id = n.id and r.user_id = auth.uid())
   order by n.id;
$$;

create or replace function public.mark_notice_read(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  insert into notice_reads (notice_id, user_id) values (p_id, auth.uid()) on conflict do nothing;
end $$;

-- ---------- المزامنة الفورية (Supabase Realtime) ----------
-- أي تعديل من لوحة الإدارة يصل للتطبيقات المفتوحة فوراً
do $$
declare t text;
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime') then
    foreach t in array array['app_config', 'notices', 'messages', 'profiles'] loop
      if not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = t) then
        execute format('alter publication supabase_realtime add table public.%I', t);
      end if;
    end loop;
  end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_create_notice(text, text, text, text, text)', 'public.admin_set_notice(bigint, boolean)',
    'public.admin_delete_notice(bigint)', 'public.admin_notices()', 'public.admin_notice_readers(bigint)',
    'public.my_notices()', 'public.mark_notice_read(bigint)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.5 — تطوير الرسائل
--  • روابط الرسائل كأزرار (مثل «اضغط هنا للتحديث»)
--  • رسائل إجبارية خاصة لمستخدمين محددين أو عامة للجميع
--  • شكل الشريط والشاشة (لون، شكل، حركة، مكان، أيقونة متحركة / GIF) + مدة انتهاء + تعديل مباشر
-- شغّله مرة واحدة في SQL Editor (آمن لو تكرر)
-- ============================================================

-- ---------- صندوق الرسائل ----------
alter table public.messages add column if not exists link       text  not null default '';
alter table public.messages add column if not exists link_label text  not null default '';
alter table public.messages add column if not exists style      jsonb not null default '{}'::jsonb;

drop function if exists public.admin_send_message(uuid, text, text);
drop function if exists public.admin_send_message(uuid, text, text, text, text);
create or replace function public.admin_send_message(p_target uuid, p_title text, p_body text, p_link text default '', p_label text default '', p_style jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_target is null and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if p_target is not null and not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  insert into messages (sender, target, title, body, link, link_label, style)
  values (auth.uid(), p_target, left(p_title, 120), left(coalesce(p_body, ''), 2000), left(coalesce(p_link, ''), 600),
          left(coalesce(p_label, ''), 40), coalesce(p_style, '{}'::jsonb));
  perform public.log_action('message', p_target, json_build_object('title', p_title)::jsonb);
end $$;

-- ---------- الرسائل الإجبارية ----------
alter table public.notices add column if not exists link_label text        not null default '';
alter table public.notices add column if not exists style      jsonb       not null default '{}'::jsonb;
alter table public.notices add column if not exists targets    uuid[];                 -- null = للجميع
alter table public.notices add column if not exists expires_at timestamptz;            -- null = بلا انتهاء
alter table public.notices add column if not exists updated_at timestamptz not null default now();

-- الخاصة لا يراها إلا أصحابها
drop policy if exists "notices: read active" on public.notices;
create policy "notices: read active" on public.notices for select
  using ((active and (targets is null or auth.uid() = any(targets))) or public.has_perm('messages.broadcast'));

drop function if exists public.admin_create_notice(text, text, text, text, text);
drop function if exists public.admin_create_notice(text, text, text, text, text, text);
create or replace function public.admin_create_notice(p_title text, p_body text, p_image text, p_link text, p_level text,
  p_label text default '', p_style jsonb default '{}'::jsonb, p_targets uuid[] default null, p_expires timestamptz default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  insert into notices (title, body, image_url, link, link_label, level, style, targets, expires_at, created_by)
  values (left(p_title, 120), left(coalesce(p_body, ''), 3000), left(coalesce(p_image, ''), 600), left(coalesce(p_link, ''), 600),
          left(coalesce(p_label, ''), 40), case when p_level = 'bar' then 'bar' else 'screen' end, coalesce(p_style, '{}'::jsonb),
          case when coalesce(array_length(p_targets, 1), 0) = 0 then null else p_targets end, p_expires, auth.uid())
  returning id into nid;
  perform public.log_action('notice', null, json_build_object('title', p_title, 'level', p_level, 'private', p_targets is not null)::jsonb);
  return nid;
end $$;

-- تعديل رسالة منشورة (يصل التعديل فوراً لمن لم يقرأها)
create or replace function public.admin_update_notice(p_id bigint, p_title text, p_body text, p_image text, p_link text, p_level text,
  p_label text default '', p_style jsonb default '{}'::jsonb, p_targets uuid[] default null, p_expires timestamptz default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  update notices set title = left(p_title, 120), body = left(coalesce(p_body, ''), 3000), image_url = left(coalesce(p_image, ''), 600),
         link = left(coalesce(p_link, ''), 600), link_label = left(coalesce(p_label, ''), 40),
         level = case when p_level = 'bar' then 'bar' else 'screen' end, style = coalesce(p_style, '{}'::jsonb),
         targets = case when coalesce(array_length(p_targets, 1), 0) = 0 then null else p_targets end,
         expires_at = p_expires, updated_at = now()
   where id = p_id;
end $$;

drop function if exists public.admin_notices();
create or replace function public.admin_notices()
returns table (id bigint, title text, body text, image_url text, link text, link_label text, level text, style jsonb,
               targets uuid[], expires_at timestamptz, active boolean, created_at timestamptz, reads bigint, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select n.id, n.title, n.body, n.image_url, n.link, n.link_label, n.level, n.style, n.targets, n.expires_at, n.active, n.created_at,
         (select count(*) from notice_reads r where r.notice_id = n.id),
         case when n.targets is null then (select count(*) from profiles where status = 'active')
              else (select count(*) from profiles where status = 'active' and profiles.id = any(n.targets)) end
    from notices n order by n.id desc;
end $$;

-- من قرأ ومن لم يقرأ (للخاصة: أصحابها فقط)
create or replace function public.admin_notice_readers(p_id bigint)
returns table (user_id uuid, email text, name text, read_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare t uuid[];
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  select targets into t from notices where id = p_id;
  return query
  select p.id, p.email, p.display_name, r.read_at
    from profiles p left join notice_reads r on r.user_id = p.id and r.notice_id = p_id
   where p.status = 'active' and (t is null or p.id = any(t))
   order by r.read_at desc nulls last;
end $$;

-- رسائلي غير المقروءة: العامة + الخاصة بي، غير المنتهية
create or replace function public.my_notices()
returns setof public.notices language sql stable security definer set search_path = public as $$
  select n.* from notices n
   where n.active
     and (n.targets is null or auth.uid() = any(n.targets))
     and (n.expires_at is null or n.expires_at > now())
     and not exists (select 1 from notice_reads r where r.notice_id = n.id and r.user_id = auth.uid())
   order by n.id;
$$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_send_message(uuid, text, text, text, text, jsonb)',
    'public.admin_create_notice(text, text, text, text, text, text, jsonb, uuid[], timestamptz)',
    'public.admin_update_notice(bigint, text, text, text, text, text, text, jsonb, uuid[], timestamptz)',
    'public.admin_notices()', 'public.admin_notice_readers(bigint)', 'public.my_notices()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.7 — العمل بدون نت + متابعة المستخدمين في لوحة التحكم
--  • التطبيق يسجّل ما يحدث (حتى بدون نت) ويرفعه عند رجوع الاتصال بوقته الحقيقي
--  • ملخص لكل مستخدم: تقدّم الألعاب، أرقام الاستخدام (بدون محتوى)، حالة الجهاز
-- شغّله مرة واحدة في SQL Editor بعد update-1.5.sql (آمن لو تكرر)
-- ============================================================

-- ---------- سجل الأحداث ----------
create table if not exists public.user_events (
  id          bigserial primary key,
  user_id     uuid not null references auth.users(id) on delete cascade,
  type        text not null,
  data        jsonb not null default '{}'::jsonb,
  at          timestamptz not null,               -- وقت حدوثه على الجهاز
  offline     boolean not null default false,     -- حدث وهو بدون نت
  received_at timestamptz not null default now()
);
create index if not exists user_events_user_at on public.user_events (user_id, at desc);
alter table public.user_events enable row level security;
drop policy if exists "events: staff read" on public.user_events;
create policy "events: staff read" on public.user_events for select using (public.has_perm('users.view'));

-- ---------- ملخص المستخدم ----------
create table if not exists public.user_stats (
  user_id      uuid primary key references auth.users(id) on delete cascade,
  stats        jsonb not null default '{}'::jsonb,
  version      text not null default '',
  platform     text not null default '',
  last_sync    timestamptz not null default now(),
  offline_from timestamptz,
  updated_at   timestamptz not null default now()
);
alter table public.user_stats enable row level security;
drop policy if exists "stats: staff read" on public.user_stats;
create policy "stats: staff read" on public.user_stats for select using (public.has_perm('users.view') or user_id = auth.uid());

-- يرفع دفعة أحداث (حتى 200) — الوقت يُضبط ضمن حدود معقولة
create or replace function public.track_events(p_events jsonb)
returns integer language plpgsql security definer set search_path = public as $$
declare n integer := 0; e jsonb; t timestamptz;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if jsonb_typeof(p_events) <> 'array' then return 0; end if;
  for e in select * from jsonb_array_elements(p_events) limit 200 loop
    begin t := (e->>'at')::timestamptz; exception when others then t := now(); end;
    if t is null or t > now() + interval '10 minutes' then t := now(); end if;
    if t < now() - interval '120 days' then t := now() - interval '120 days'; end if;
    insert into user_events (user_id, type, data, at, offline)
    values (auth.uid(), left(coalesce(e->>'type', 'event'), 40),
            case when jsonb_typeof(e->'data') = 'object' and length((e->'data')::text) < 2000 then e->'data' else '{}'::jsonb end,
            t, coalesce((e->>'offline')::boolean, false));
    n := n + 1;
  end loop;
  -- تنظيف: نحتفظ بآخر 120 يوماً فقط
  delete from user_events where user_id = auth.uid() and at < now() - interval '120 days';
  return n;
end $$;

-- يحدّث ملخص المستخدم
create or replace function public.sync_user_stats(p_stats jsonb, p_version text, p_platform text, p_offline_from timestamptz default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if length(coalesce(p_stats, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  insert into user_stats (user_id, stats, version, platform, last_sync, offline_from, updated_at)
  values (auth.uid(), coalesce(p_stats, '{}'::jsonb), left(coalesce(p_version, ''), 20), left(coalesce(p_platform, ''), 20), now(), p_offline_from, now())
  on conflict (user_id) do update set stats = excluded.stats, version = excluded.version, platform = excluded.platform,
    last_sync = now(), offline_from = excluded.offline_from, updated_at = now();
end $$;

-- ---------- للإدارة ----------
create or replace function public.admin_user_stats()
returns table (user_id uuid, stats jsonb, version text, platform text, last_sync timestamptz, offline_from timestamptz, events_7d bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query
  select s.user_id, s.stats, s.version, s.platform, s.last_sync, s.offline_from,
         (select count(*) from user_events e where e.user_id = s.user_id and e.at > now() - interval '7 days')
    from user_stats s;
end $$;

create or replace function public.admin_user_events(p_uid uuid, p_limit integer default 100, p_before timestamptz default null)
returns table (id bigint, type text, data jsonb, at timestamptz, offline boolean, received_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query
  select e.id, e.type, e.data, e.at, e.offline, e.received_at from user_events e
   where e.user_id = p_uid and (p_before is null or e.at < p_before)
   order by e.at desc limit least(coalesce(p_limit, 100), 300);
end $$;


-- ---------- هدايا الإدارة للاعبين (حبوب بن، فتح المراحل، أشكال) ----------
create table if not exists public.player_grants (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  kind       text not null check (kind in ('beans', 'unlock', 'item')),
  value      jsonb not null default '{}'::jsonb,
  note       text not null default '',
  created_by uuid,
  created_at timestamptz not null default now(),
  claimed_at timestamptz
);
create index if not exists player_grants_user on public.player_grants (user_id) where claimed_at is null;
alter table public.player_grants enable row level security;
drop policy if exists "grants: mine or staff" on public.player_grants;
create policy "grants: mine or staff" on public.player_grants for select using (user_id = auth.uid() or public.has_perm('games.manage'));

create or replace function public.admin_grant(p_uid uuid, p_kind text, p_value jsonb, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare gid bigint;
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  if p_kind = 'beans' and coalesce((p_value->>'n')::int, 0) not between 1 and 100000 then raise exception 'invalid amount'; end if;
  insert into player_grants (user_id, kind, value, note, created_by)
  values (p_uid, p_kind, coalesce(p_value, '{}'::jsonb), left(coalesce(p_note, ''), 120), auth.uid())
  returning id into gid;
  perform public.log_action('grant', p_uid, json_build_object('kind', p_kind, 'value', p_value)::jsonb);
  return gid;
end $$;

create or replace function public.my_grants()
returns setof public.player_grants language sql stable security definer set search_path = public as $$
  select * from player_grants where user_id = auth.uid() and claimed_at is null order by id;
$$;

create or replace function public.claim_grants(p_ids bigint[])
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  update player_grants set claimed_at = now() where user_id = auth.uid() and id = any(p_ids) and claimed_at is null;
end $$;

create or replace function public.admin_grants(p_uid uuid)
returns setof public.player_grants language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('games.manage') then raise exception 'not allowed'; end if;
  return query select * from player_grants where user_id = p_uid order by id desc limit 50;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.track_events(jsonb)', 'public.sync_user_stats(jsonb, text, text, timestamptz)',
    'public.admin_user_stats()', 'public.admin_user_events(uuid, integer, timestamptz)',
    'public.admin_grant(uuid, text, jsonb, text)', 'public.my_grants()', 'public.claim_grants(bigint[])', 'public.admin_grants(uuid)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.8 — الاشتراكات المدفوعة، الإعلانات، والتطبيقات المتعددة
--  • أسعار وعروض وأكواد خصم وأكواد تفعيل وطلبات دفع (تحويل بنكي / STC Pay)
--  • اشتراكات لكل تطبيق أو الباقة الكاملة
--  • إعلاناتك الخاصة مع إحصاءات المشاهدات والنقرات
-- شغّله مرة واحدة في SQL Editor بعد update-1.7.sql (آمن لو تكرر)
-- ============================================================

-- ---------- صلاحيات جديدة: الاشتراكات والتطبيقات ----------
create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view','apps.manage']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

-- ---------- إعدادات السوق: الأسعار والعروض والإعلانات والتطبيقات ----------
alter table public.app_config add column if not exists market jsonb not null default '{}'::jsonb;

create or replace function public.admin_set_market(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('billing.manage') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 200000 then raise exception 'too large'; end if;
  update app_config set market = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
  perform public.log_action('market');
end $$;

-- ---------- الاشتراكات الفعّالة ----------
create table if not exists public.entitlements (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  app        text not null,                         -- vault | tasks | finance | games | all
  plan       text not null default 'y',             -- m | y | l | custom
  until      timestamptz,                           -- null = مدى الحياة
  source     text not null default 'admin',         -- code | payment | admin | gateway
  ref        text not null default '',
  amount     numeric not null default 0,
  revoked    boolean not null default false,
  created_by uuid,
  created_at timestamptz not null default now()
);
create index if not exists entitlements_user on public.entitlements (user_id);
alter table public.entitlements enable row level security;
drop policy if exists "ent: mine or staff" on public.entitlements;
create policy "ent: mine or staff" on public.entitlements for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

create or replace function public.plan_until(p_plan text, p_from timestamptz default now())
returns timestamptz language sql immutable as $$
  select case p_plan when 'm' then p_from + interval '1 month' when 'y' then p_from + interval '1 year' when 'l' then null else p_from + interval '1 month' end;
$$;

-- يمدّد الاشتراك إن كان فعّالاً لنفس التطبيق (لا يضيع وقت متبقٍ)
create or replace function public.grant_entitlement(p_uid uuid, p_app text, p_plan text, p_source text, p_ref text, p_amount numeric)
returns bigint language plpgsql security definer set search_path = public as $$
declare base timestamptz; cur timestamptz; eid bigint;
begin
  select max(until) into cur from entitlements where user_id = p_uid and app = p_app and not revoked and until is not null and until > now();
  base := coalesce(cur, now());
  insert into entitlements (user_id, app, plan, until, source, ref, amount, created_by)
  values (p_uid, p_app, p_plan, public.plan_until(p_plan, base), p_source, left(coalesce(p_ref, ''), 80), coalesce(p_amount, 0), auth.uid())
  returning id into eid;
  return eid;
end $$;
revoke all on function public.grant_entitlement(uuid, text, text, text, text, numeric) from anon, public, authenticated;

create or replace function public.my_entitlements()
returns table (id bigint, app text, plan text, until timestamptz, source text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select e.id, e.app, e.plan, e.until, e.source, e.created_at from entitlements e
   where e.user_id = auth.uid() and not e.revoked and (e.until is null or e.until > now())
   order by e.id desc;
$$;

-- ---------- أكواد التفعيل ----------
create table if not exists public.activation_codes (
  code       text primary key,
  app        text not null,
  plan       text not null,
  price      numeric not null default 0,
  note       text not null default '',
  status     text not null default 'new' check (status in ('new', 'used', 'revoked')),
  used_by    uuid references auth.users(id) on delete set null,
  used_at    timestamptz,
  created_by uuid,
  created_at timestamptz not null default now()
);
alter table public.activation_codes enable row level security;
drop policy if exists "codes: staff" on public.activation_codes;
create policy "codes: staff" on public.activation_codes for select using (public.has_perm('billing.manage'));

create or replace function public.admin_generate_codes(p_n integer, p_app text, p_plan text, p_price numeric default 0, p_note text default '')
returns setof text language plpgsql security definer set search_path = public as $$
declare i integer; c text; chars text := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  if p_n < 1 or p_n > 100 then raise exception 'invalid count'; end if;
  for i in 1..p_n loop
    loop
      c := 'NOBLE-' || (select string_agg(substr(chars, 1 + floor(random() * length(chars))::int, 1), '') from generate_series(1, 4))
                || '-' || (select string_agg(substr(chars, 1 + floor(random() * length(chars))::int, 1), '') from generate_series(1, 4));
      exit when not exists (select 1 from activation_codes where code = c);
    end loop;
    insert into activation_codes (code, app, plan, price, note, created_by) values (c, p_app, p_plan, coalesce(p_price, 0), left(coalesce(p_note, ''), 120), auth.uid());
    return next c;
  end loop;
  perform public.log_action('codes', null, json_build_object('n', p_n, 'app', p_app, 'plan', p_plan)::jsonb);
end $$;

create or replace function public.redeem_code(p_code text)
returns json language plpgsql security definer set search_path = public as $$
declare r activation_codes; eid bigint;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  select * into r from activation_codes where code = upper(trim(p_code)) for update;
  if not found then raise exception 'invalid code'; end if;
  if r.status = 'used' then raise exception 'code used'; end if;
  if r.status = 'revoked' then raise exception 'code revoked'; end if;
  eid := public.grant_entitlement(auth.uid(), r.app, r.plan, 'code', r.code, r.price);
  update activation_codes set status = 'used', used_by = auth.uid(), used_at = now() where code = r.code;
  perform public.log_action('redeem', auth.uid(), json_build_object('code', r.code, 'app', r.app, 'plan', r.plan)::jsonb);
  return json_build_object('app', r.app, 'plan', r.plan);
end $$;

create or replace function public.admin_codes(p_limit integer default 200)
returns table (code text, app text, plan text, price numeric, note text, status text, used_email text, used_at timestamptz, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select c.code, c.app, c.plan, c.price, c.note, c.status, p.email, c.used_at, c.created_at
    from activation_codes c left join profiles p on p.id = c.used_by order by c.created_at desc limit least(p_limit, 500);
end $$;

create or replace function public.admin_revoke_code(p_code text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update activation_codes set status = 'revoked' where code = p_code and status = 'new';
end $$;

-- ---------- أكواد الخصم ----------
create table if not exists public.discount_codes (
  code       text primary key,
  pct        integer not null check (pct between 1 and 100),
  apps       text[],                 -- null = كل التطبيقات
  plans      text[],                 -- null = كل الخطط
  max_uses   integer,                -- null = بلا حد
  used       integer not null default 0,
  until      timestamptz,
  active     boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.discount_codes enable row level security;
drop policy if exists "disc: staff" on public.discount_codes;
create policy "disc: staff" on public.discount_codes for select using (public.has_perm('billing.manage'));

create or replace function public.check_discount(p_code text, p_app text, p_plan text)
returns integer language plpgsql stable security definer set search_path = public as $$
declare d discount_codes;
begin
  select * into d from discount_codes where code = upper(trim(p_code));
  if not found or not d.active then raise exception 'invalid discount'; end if;
  if d.until is not null and d.until < now() then raise exception 'discount expired'; end if;
  if d.max_uses is not null and d.used >= d.max_uses then raise exception 'discount used up'; end if;
  if d.apps is not null and not (p_app = any(d.apps)) then raise exception 'discount not for this'; end if;
  if d.plans is not null and not (p_plan = any(d.plans)) then raise exception 'discount not for this'; end if;
  return d.pct;
end $$;

create or replace function public.admin_set_discount(p_code text, p_pct integer, p_apps text[], p_plans text[], p_max integer, p_until timestamptz, p_active boolean)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  insert into discount_codes (code, pct, apps, plans, max_uses, until, active)
  values (upper(trim(p_code)), p_pct, nullif(p_apps, '{}'), nullif(p_plans, '{}'), p_max, p_until, coalesce(p_active, true))
  on conflict (code) do update set pct = excluded.pct, apps = excluded.apps, plans = excluded.plans, max_uses = excluded.max_uses, until = excluded.until, active = excluded.active;
end $$;

create or replace function public.admin_delete_discount(p_code text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  delete from discount_codes where code = p_code;
end $$;

create or replace function public.admin_discounts()
returns setof public.discount_codes language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select * from discount_codes order by created_at desc;
end $$;

-- ---------- طلبات الدفع (تحويل بنكي / STC Pay) ----------
create table if not exists public.payment_requests (
  id         bigserial primary key,
  user_id    uuid not null references auth.users(id) on delete cascade,
  app        text not null,
  plan       text not null,
  amount     numeric not null default 0,
  discount   text not null default '',
  method     text not null default 'bank',
  ref        text not null default '',
  note       text not null default '',
  status     text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  decided_by uuid,
  decided_at timestamptz,
  created_at timestamptz not null default now()
);
create index if not exists payreq_status on public.payment_requests (status, created_at desc);
alter table public.payment_requests enable row level security;
drop policy if exists "pay: mine or staff" on public.payment_requests;
create policy "pay: mine or staff" on public.payment_requests for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

create or replace function public.submit_payment(p_app text, p_plan text, p_amount numeric, p_discount text, p_method text, p_ref text, p_note text)
returns bigint language plpgsql security definer set search_path = public as $$
declare pid bigint;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if (select count(*) from payment_requests where user_id = auth.uid() and status = 'pending') >= 3 then raise exception 'too many pending'; end if;
  insert into payment_requests (user_id, app, plan, amount, discount, method, ref, note)
  values (auth.uid(), left(p_app, 20), left(p_plan, 4), greatest(0, coalesce(p_amount, 0)), upper(left(coalesce(p_discount, ''), 30)), left(coalesce(p_method, 'bank'), 20), left(coalesce(p_ref, ''), 80), left(coalesce(p_note, ''), 300))
  returning id into pid;
  return pid;
end $$;

create or replace function public.my_payments()
returns table (id bigint, app text, plan text, amount numeric, status text, created_at timestamptz)
language sql stable security definer set search_path = public as $$
  select id, app, plan, amount, status, created_at from payment_requests where user_id = auth.uid() order by id desc limit 10;
$$;

create or replace function public.admin_payments(p_status text default null)
returns table (id bigint, user_id uuid, email text, name text, app text, plan text, amount numeric, discount text, method text, ref text, note text, status text, created_at timestamptz, decided_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select r.id, r.user_id, p.email, p.display_name, r.app, r.plan, r.amount, r.discount, r.method, r.ref, r.note, r.status, r.created_at, r.decided_at
    from payment_requests r left join profiles p on p.id = r.user_id
   where p_status is null or r.status = p_status order by r.id desc limit 300;
end $$;

create or replace function public.admin_decide_payment(p_id bigint, p_ok boolean)
returns void language plpgsql security definer set search_path = public as $$
declare r payment_requests;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  select * into r from payment_requests where id = p_id for update;
  if not found or r.status <> 'pending' then raise exception 'not pending'; end if;
  update payment_requests set status = case when p_ok then 'approved' else 'rejected' end, decided_by = auth.uid(), decided_at = now() where id = p_id;
  if p_ok then
    perform public.grant_entitlement(r.user_id, r.app, r.plan, 'payment', 'pay#' || r.id, r.amount);
    if r.discount <> '' then update discount_codes set used = used + 1 where code = r.discount; end if;
  end if;
  perform public.log_action('payment', r.user_id, json_build_object('ok', p_ok, 'app', r.app, 'plan', r.plan, 'amount', r.amount)::jsonb);
end $$;

-- ---------- تفعيل يدوي من اللوحة ----------
create or replace function public.admin_grant_pro(p_uid uuid, p_app text, p_plan text, p_amount numeric default 0, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare eid bigint;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  eid := public.grant_entitlement(p_uid, p_app, p_plan, 'admin', p_note, p_amount);
  perform public.log_action('pro', p_uid, json_build_object('app', p_app, 'plan', p_plan)::jsonb);
  return eid;
end $$;

create or replace function public.admin_revoke_entitlement(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update entitlements set revoked = true where id = p_id;
end $$;

create or replace function public.admin_subscribers()
returns table (id bigint, user_id uuid, email text, name text, app text, plan text, until timestamptz, source text, amount numeric, revoked boolean, created_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select e.id, e.user_id, p.email, p.display_name, e.app, e.plan, e.until, e.source, e.amount, e.revoked, e.created_at
    from entitlements e left join profiles p on p.id = e.user_id order by e.id desc limit 500;
end $$;

create or replace function public.admin_billing_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'revenue_month', (select coalesce(sum(amount), 0) from entitlements where not revoked and created_at >= date_trunc('month', now())),
    'revenue_total', (select coalesce(sum(amount), 0) from entitlements where not revoked),
    'active', (select count(distinct user_id) from entitlements where not revoked and (until is null or until > now())),
    'expiring', (select count(*) from entitlements where not revoked and until between now() and now() + interval '7 days'),
    'pending', (select count(*) from payment_requests where status = 'pending'),
    'by_app', (select coalesce(json_object_agg(app, n), '{}'::json) from (select app, count(distinct user_id) n from entitlements where not revoked and (until is null or until > now()) group by app) t)
  );
end $$;

-- ---------- إحصاءات إعلاناتك ----------
create table if not exists public.ad_stats (
  ad_id  text not null,
  day    date not null default current_date,
  app    text not null default '',
  views  integer not null default 0,
  clicks integer not null default 0,
  primary key (ad_id, day, app)
);
alter table public.ad_stats enable row level security;
drop policy if exists "ads: staff" on public.ad_stats;
create policy "ads: staff" on public.ad_stats for select using (public.has_perm('apps.manage') or public.has_perm('billing.manage'));

create or replace function public.ad_event(p_ad text, p_kind text, p_app text default '')
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into ad_stats (ad_id, day, app, views, clicks)
  values (left(p_ad, 40), current_date, left(coalesce(p_app, ''), 20), case when p_kind = 'v' then 1 else 0 end, case when p_kind = 'c' then 1 else 0 end)
  on conflict (ad_id, day, app) do update set views = ad_stats.views + excluded.views, clicks = ad_stats.clicks + excluded.clicks;
end $$;

create or replace function public.admin_ad_stats(p_days integer default 30)
returns table (ad_id text, views bigint, clicks bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('apps.manage') or public.has_perm('billing.manage')) then raise exception 'not allowed'; end if;
  return query select s.ad_id, sum(s.views)::bigint, sum(s.clicks)::bigint from ad_stats s where s.day > current_date - p_days group by s.ad_id;
end $$;

-- المزامنة الفورية لاشتراكات المستخدم (يتفعل Pro عنده لحظة الموافقة)
do $$
begin
  if exists (select 1 from pg_publication where pubname = 'supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname = 'supabase_realtime' and schemaname = 'public' and tablename = 'entitlements') then
    execute 'alter publication supabase_realtime add table public.entitlements';
  end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_set_market(jsonb)', 'public.my_entitlements()', 'public.admin_generate_codes(integer, text, text, numeric, text)',
    'public.redeem_code(text)', 'public.admin_codes(integer)', 'public.admin_revoke_code(text)', 'public.check_discount(text, text, text)',
    'public.admin_set_discount(text, integer, text[], text[], integer, timestamptz, boolean)', 'public.admin_delete_discount(text)', 'public.admin_discounts()',
    'public.submit_payment(text, text, numeric, text, text, text, text)', 'public.my_payments()', 'public.admin_payments(text)', 'public.admin_decide_payment(bigint, boolean)',
    'public.admin_grant_pro(uuid, text, text, numeric, text)', 'public.admin_revoke_entitlement(bigint)', 'public.admin_subscribers()', 'public.admin_billing_stats()',
    'public.ad_event(text, text, text)', 'public.admin_ad_stats(integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;


-- ============================================================
-- NOBLE 1.9 — الأقسام بالاشتراك وفترة التجربة، منح الأقسام، واسترجاع الحساب بالإيميل
--  • فترة تجربة لكل مستخدم تبدأ من أول فتح للتحديث (لا تتصفّر بحذف التطبيق)
--  • منح قسم لأي مستخدم لتاريخ تحدده
--  • مفتاح استرجاع البيانات (تلقائي أو بكود خاص) — للمستخدم نفسه فقط
-- شغّله مرة واحدة في SQL Editor بعد update-1.8.sql (آمن لو تكرر)
-- ============================================================

-- ---------- فترة التجربة لكل مستخدم ----------
create table if not exists public.user_access (
  user_id     uuid primary key references auth.users(id) on delete cascade,
  trial_from  timestamptz not null default now(),
  trial_until timestamptz,                 -- تحديد يدوي من الإدارة (يتقدّم على الحساب التلقائي)
  updated_at  timestamptz not null default now()
);
alter table public.user_access enable row level security;
drop policy if exists "access: mine or staff" on public.user_access;
create policy "access: mine or staff" on public.user_access for select using (user_id = auth.uid() or public.has_perm('billing.manage'));

-- يرجع بداية التجربة (وينشئها أول مرة) + وقت السيرفر
create or replace function public.my_access()
returns json language plpgsql security definer set search_path = public as $$
declare r user_access;
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  insert into user_access (user_id) values (auth.uid()) on conflict (user_id) do nothing;
  select * into r from user_access where user_id = auth.uid();
  return json_build_object('trial_from', r.trial_from, 'trial_until', r.trial_until, 'now', now());
end $$;

create or replace function public.admin_user_access(p_uid uuid)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'access', (select row_to_json(a) from user_access a where a.user_id = p_uid),
    'ents', coalesce((select json_agg(row_to_json(e) order by e.id desc) from entitlements e where e.user_id = p_uid and not e.revoked), '[]'::json));
end $$;

create or replace function public.admin_access_list()
returns table (user_id uuid, trial_from timestamptz, trial_until timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return query select a.user_id, a.trial_from, a.trial_until from user_access a;
end $$;

-- تحديد نهاية التجربة لمستخدم (null = حسب الإعداد العام)
create or replace function public.admin_set_trial(p_uid uuid, p_until timestamptz)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  insert into user_access (user_id, trial_until, updated_at) values (p_uid, p_until, now())
  on conflict (user_id) do update set trial_until = excluded.trial_until, updated_at = now();
  perform public.log_action('trial', p_uid, json_build_object('until', p_until)::jsonb);
end $$;

-- منح قسم لمستخدم حتى تاريخ معيّن (null = بدون نهاية)
create or replace function public.admin_grant_section(p_uid uuid, p_app text, p_until timestamptz, p_note text default '')
returns bigint language plpgsql security definer set search_path = public as $$
declare eid bigint;
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  -- منح جديد يستبدل المنح اليدوي السابق لنفس القسم
  update entitlements set revoked = true where user_id = p_uid and app = p_app and source = 'admin' and not revoked;
  insert into entitlements (user_id, app, plan, until, source, ref, amount, created_by)
  values (p_uid, left(p_app, 20), 'custom', p_until, 'admin', left(coalesce(p_note, ''), 80), 0, auth.uid())
  returning id into eid;
  perform public.log_action('pro', p_uid, json_build_object('app', p_app, 'until', p_until)::jsonb);
  return eid;
end $$;

-- إيقاف كل اشتراكات قسم لمستخدم (يقفل القسم)
create or replace function public.admin_lock_section(p_uid uuid, p_app text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  update entitlements set revoked = true where user_id = p_uid and app = p_app and not revoked;
end $$;

-- ---------- مفتاح استرجاع البيانات (للمستخدم نفسه فقط) ----------
create table if not exists public.user_keys (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
alter table public.user_keys enable row level security;
drop policy if exists "keys: mine" on public.user_keys;
create policy "keys: mine" on public.user_keys for select using (user_id = auth.uid());

create or replace function public.set_my_key(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 4000 then raise exception 'too large'; end if;
  insert into user_keys (user_id, data, updated_at) values (auth.uid(), coalesce(p_data, '{}'::jsonb), now())
  on conflict (user_id) do update set data = excluded.data, updated_at = now();
end $$;

create or replace function public.my_key()
returns jsonb language sql stable security definer set search_path = public as $$
  select data from user_keys where user_id = auth.uid();
$$;

-- ---------- لعبة المطاردة: نقاطها في الصدارة ----------
create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame', 'chase') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'chase' then 3000 when 'tasks' then 50 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.my_access()', 'public.admin_user_access(uuid)', 'public.admin_access_list()', 'public.admin_set_trial(uuid, timestamptz)',
    'public.admin_grant_section(uuid, text, timestamptz, text)', 'public.admin_lock_section(uuid, text)',
    'public.set_my_key(jsonb)', 'public.my_key()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.10 — أخبار الذكاء الاصطناعي (نبض AI)
--  • مصادر RSS تُسحب تلقائياً وتُترجَم وتُلخَّص بالعربي (Gemini) ثم تنتظر موافقتك
--  • تكتب أخبارك بنفسك، تثبّت، تعدّل، ترفض — من لوحة التحكم ← الأخبار
--  • مفتاح Gemini محفوظ في السيرفر فقط ولا يطلع لأي مستخدم
-- شغّله مرة واحدة في SQL Editor بعد update-1.9.sql (آمن لو تكرر)
-- ============================================================

-- ---------- صلاحية جديدة: إدارة الأخبار ----------
create or replace function public.role_perms(p_role text) returns text[]
language sql immutable as $$
  select case p_role
    when 'owner'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage','news.manage']
    when 'admin'     then array['users.view','users.manage','users.delete','roles.manage','content.edit','messages.send','messages.broadcast','sections.manage','logs.view','stats.view','games.manage','billing.manage','apps.manage','news.manage']
    when 'moderator' then array['users.view','users.manage','messages.send','messages.broadcast','logs.view','stats.view']
    when 'editor'    then array['users.view','content.edit','messages.broadcast','stats.view','apps.manage','news.manage']
    when 'support'   then array['users.view','messages.send']
    else array[]::text[] end;
$$;

-- ---------- الجداول ----------
create table if not exists public.news_sources (
  id         bigserial primary key,
  name       text not null,
  url        text not null unique,
  cat        text not null default 'general',
  lang       text not null default 'en',
  active     boolean not null default true,
  last_fetch timestamptz,
  last_error text,
  created_at timestamptz not null default now()
);

create table if not exists public.news_items (
  id           bigserial primary key,
  source_id    bigint references public.news_sources(id) on delete set null,
  guid         text unique,
  url          text not null default '',
  src_name     text not null default '',
  src_title    text not null default '',
  src_text     text not null default '',
  image        text not null default '',
  cat          text not null default 'general',
  title        text not null default '',
  summary      text not null default '',
  body         text not null default '',
  why          text not null default '',
  status       text not null default 'draft' check (status in ('draft', 'published', 'rejected')),
  pinned       boolean not null default false,
  ai           boolean not null default false,
  pub_at       timestamptz,
  published_at timestamptz,
  views        integer not null default 0,
  saves        integer not null default 0,
  created_by   uuid,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);
create index if not exists news_items_feed on public.news_items (status, pinned desc, published_at desc);

-- الإعدادات (عامة للوحة) + الأسرار (للسيرفر فقط)
create table if not exists public.news_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
insert into public.news_settings (id) values (1) on conflict (id) do nothing;

create table if not exists public.news_secret (
  id          int primary key default 1 check (id = 1),
  gemini_key  text not null default '',
  cron_secret text not null default replace(gen_random_uuid()::text, '-', ''),
  updated_at  timestamptz not null default now()
);
insert into public.news_secret (id) values (1) on conflict (id) do nothing;

alter table public.news_sources  enable row level security;
alter table public.news_items    enable row level security;
alter table public.news_settings enable row level security;
alter table public.news_secret   enable row level security;  -- بدون سياسات = لا أحد يقرأها إلا السيرفر
drop policy if exists "news: published" on public.news_items;
create policy "news: published" on public.news_items for select using (status = 'published' or public.has_perm('news.manage'));
drop policy if exists "news src: staff" on public.news_sources;
create policy "news src: staff" on public.news_sources for select using (public.has_perm('news.manage'));

-- ---------- للمستخدمين ----------
create or replace function public.news_feed(p_cat text default null, p_before timestamptz default null, p_limit int default 30)
returns setof json language sql stable security definer set search_path = public as $$
  select json_build_object('id', n.id, 'url', n.url, 'src', n.src_name, 'image', n.image, 'cat', n.cat, 'title', n.title,
    'summary', n.summary, 'body', n.body, 'why', n.why, 'pinned', n.pinned, 'ai', n.ai, 'at', n.published_at)
  from news_items n
  where n.status = 'published' and auth.uid() is not null
    and (p_cat is null or p_cat = '' or n.cat = p_cat)
    and (p_before is null or n.published_at < p_before)
  order by (p_before is null and n.pinned) desc, n.published_at desc
  limit least(greatest(coalesce(p_limit, 30), 1), 60);
$$;

-- اسم القسم ووقت الموجز (الجزء العام من الإعدادات فقط)
create or replace function public.news_meta()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object('title', coalesce(nullif(data->>'title', ''), 'نبض AI'), 'sub', coalesce(data->>'sub', ''),
    'hour', coalesce((data->>'hour')::int, 8), 'digest', coalesce((data->>'digest')::boolean, true))
  from news_settings where id = 1 and auth.uid() is not null;
$$;

-- قراءة / حفظ (عدّاد)
create or replace function public.news_hit(p_id bigint, p_kind text default 'view')
returns void language sql security definer set search_path = public as $$
  update news_items set views = views + (case when p_kind = 'view' then 1 else 0 end),
                        saves = greatest(0, saves + (case when p_kind = 'save' then 1 when p_kind = 'unsave' then -1 else 0 end))
  where id = p_id and status = 'published' and auth.uid() is not null;
$$;

-- ---------- لوحة التحكم ----------
create or replace function public.admin_news_list(p_status text default 'draft', p_limit int default 100)
returns setof news_items language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return query select * from news_items where p_status is null or status = p_status
    order by case when p_status = 'published' then published_at else created_at end desc nulls last
    limit least(greatest(coalesce(p_limit, 100), 1), 300);
end $$;

-- حفظ خبر (جديد يدوي أو تعديل) — p_item: {id?, title, summary, body, why, cat, image, url, src_name, status?, pinned?}
create or replace function public.admin_news_save(p_item jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; st text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_item->>'title', '')) < 3 then raise exception 'title required'; end if;
  st := coalesce(nullif(p_item->>'status', ''), 'draft');
  if (p_item->>'id') is null then
    insert into news_items (title, summary, body, why, cat, image, url, src_name, status, pinned, created_by, published_at, guid)
    values (left(p_item->>'title', 220), left(coalesce(p_item->>'summary', ''), 600), left(coalesce(p_item->>'body', ''), 6000),
      left(coalesce(p_item->>'why', ''), 600), coalesce(nullif(p_item->>'cat', ''), 'general'), left(coalesce(p_item->>'image', ''), 600),
      left(coalesce(p_item->>'url', ''), 600), left(coalesce(nullif(p_item->>'src_name', ''), 'فريق NOBLE'), 60), st,
      coalesce((p_item->>'pinned')::boolean, false), auth.uid(), case when st = 'published' then now() end, 'manual:' || gen_random_uuid())
    returning id into nid;
  else
    nid := (p_item->>'id')::bigint;
    update news_items set
      title = left(p_item->>'title', 220), summary = left(coalesce(p_item->>'summary', ''), 600), body = left(coalesce(p_item->>'body', ''), 6000),
      why = left(coalesce(p_item->>'why', ''), 600), cat = coalesce(nullif(p_item->>'cat', ''), cat), image = left(coalesce(p_item->>'image', image), 600),
      url = left(coalesce(p_item->>'url', url), 600), src_name = left(coalesce(nullif(p_item->>'src_name', ''), src_name), 60),
      status = st, pinned = coalesce((p_item->>'pinned')::boolean, pinned),
      published_at = case when st = 'published' then coalesce(published_at, now()) else published_at end, updated_at = now()
    where id = nid;
  end if;
  perform public.log_action('news', null, json_build_object('id', nid, 'status', st)::jsonb);
  return nid;
end $$;

-- نشر / رفض / تثبيت
create or replace function public.admin_news_set(p_id bigint, p_status text default null, p_pinned boolean default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_items set
    status = coalesce(p_status, status), pinned = coalesce(p_pinned, pinned),
    published_at = case when coalesce(p_status, status) = 'published' then coalesce(published_at, now()) else published_at end,
    updated_at = now()
  where id = p_id;
end $$;

create or replace function public.admin_news_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  delete from news_items where id = p_id;
end $$;

-- المصادر
create or replace function public.admin_news_sources()
returns setof news_sources language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return query select * from news_sources order by id;
end $$;

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
  if (p_src->>'id') is null then
    insert into news_sources (name, url, cat, active) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'general'), coalesce((p_src->>'active')::boolean, true))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, active = excluded.active
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), active = coalesce((p_src->>'active')::boolean, active) where id = sid;
  end if;
  return sid;
end $$;

create or replace function public.admin_news_source_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  delete from news_sources where id = p_id;
end $$;

-- الإعدادات (المفتاح لا يُرجَع أبداً — فقط هل هو موجود)
create or replace function public.admin_news_settings()
returns json language plpgsql stable security definer set search_path = public as $$
declare d jsonb; k text; job boolean := false;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  select data into d from news_settings where id = 1;
  select gemini_key into k from news_secret where id = 1;
  begin
    execute 'select exists (select 1 from cron.job where jobname = ''noble-news'')' into job;
  exception when others then job := null;  -- pg_cron غير مفعّل
  end;
  return json_build_object('data', coalesce(d, '{}'::jsonb), 'has_key', coalesce(k, '') <> '',
    'key_hint', case when coalesce(k, '') <> '' then '••••' || right(k, 4) else '' end, 'cron', job);
end $$;

create or replace function public.admin_news_set_settings(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update news_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

create or replace function public.admin_news_set_key(p_key text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_secret set gemini_key = trim(coalesce(p_key, '')), updated_at = now() where id = 1;
  perform public.log_action('news_key');
end $$;

-- السحب التلقائي كل X ساعات (يحتاج pg_cron و pg_net — مجانية في Supabase)
create or replace function public.admin_news_schedule(p_url text, p_anon text, p_hours int)
returns text language plpgsql security definer set search_path = public, extensions as $$
declare sec text; cmd text; h int := least(greatest(coalesce(p_hours, 0), 0), 24);
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_url, '') !~ '^https://' then raise exception 'invalid url'; end if;
  select cron_secret into sec from news_secret where id = 1;
  begin
    execute 'select cron.unschedule(''noble-news'')';
  exception when others then null;
  end;
  if h = 0 then return 'off'; end if;
  cmd := format('select net.http_post(url := %L, headers := %L::jsonb, body := %L::jsonb, timeout_milliseconds := 120000)',
    p_url, json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || coalesce(p_anon, ''), 'x-news-secret', sec)::text, '{"action":"fetch"}');
  begin
    execute format('select cron.schedule(%L, %L, %L)', 'noble-news', '7 */' || h || ' * * *', cmd);
  exception when others then
    raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة';
  end;
  return 'on';
end $$;

create or replace function public.admin_news_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'draft', (select count(*) from news_items where status = 'draft'),
    'today', (select count(*) from news_items where status = 'published' and published_at >= date_trunc('day', now())),
    'published', (select count(*) from news_items where status = 'published'),
    'views', (select coalesce(sum(views), 0) from news_items where published_at >= now() - interval '7 days'),
    'saves', (select coalesce(sum(saves), 0) from news_items where published_at >= now() - interval '7 days'));
end $$;

-- محاولة تفعيل الإضافات (تُتجاهل لو ما كانت متاحة)
do $$ begin
  begin create extension if not exists pg_cron; exception when others then null; end;
  begin create extension if not exists pg_net with schema extensions; exception when others then null; end;
end $$;

-- مصادر افتراضية (تقدر تعدّلها أو توقفها من اللوحة)
insert into public.news_sources (name, url, cat) values
  ('The Verge AI', 'https://www.theverge.com/rss/ai-artificial-intelligence/index.xml', 'general'),
  ('TechCrunch AI', 'https://techcrunch.com/category/artificial-intelligence/feed/', 'companies'),
  ('OpenAI', 'https://openai.com/news/rss.xml', 'companies'),
  ('Google AI', 'https://blog.google/technology/ai/rss/', 'companies'),
  ('Hugging Face', 'https://huggingface.co/blog/feed.xml', 'tools')
on conflict (url) do nothing;

do $$
declare f text;
begin
  foreach f in array array['public.news_feed(text, timestamptz, int)', 'public.news_meta()', 'public.news_hit(bigint, text)',
    'public.admin_news_list(text, int)', 'public.admin_news_save(jsonb)', 'public.admin_news_set(bigint, text, boolean)', 'public.admin_news_delete(bigint)',
    'public.admin_news_sources()', 'public.admin_news_source_save(jsonb)', 'public.admin_news_source_delete(bigint)',
    'public.admin_news_settings()', 'public.admin_news_set_settings(jsonb)', 'public.admin_news_set_key(text)',
    'public.admin_news_schedule(text, text, int)', 'public.admin_news_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.12 — «يومي» والإضافة السريعة بالذكاء الاصطناعي وتقاريري
--  • حد يومي لكل مستخدم للإضافة السريعة (يحمي حصة Gemini المجانية)
-- شغّله مرة واحدة في SQL Editor بعد update-1.10.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.ai_usage (
  user_id uuid not null references auth.users(id) on delete cascade,
  day     date not null default current_date,
  n       integer not null default 0,
  primary key (user_id, day)
);
alter table public.ai_usage enable row level security;  -- بدون سياسات: الوصول عبر الدالة فقط

-- يحجز استخداماً واحداً لليوم إن كان ضمن الحد — يرجّع {ok, used}
create or replace function public.ai_use(p_max integer default 40)
returns json language plpgsql security definer set search_path = public as $$
declare c integer; lim integer := least(greatest(coalesce(p_max, 40), 1), 500);
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  insert into ai_usage (user_id, day, n) values (auth.uid(), current_date, 1)
  on conflict (user_id, day) do update set n = ai_usage.n + 1
  returning n into c;
  if c > lim then
    update ai_usage set n = n - 1 where user_id = auth.uid() and day = current_date;
    return json_build_object('ok', false, 'used', c - 1, 'max', lim);
  end if;
  if random() < 0.02 then delete from ai_usage where day < current_date - 60; end if;
  return json_build_object('ok', true, 'used', c, 'max', lim);
end $$;

-- إحصائية للوحة التحكم: استخدام الإضافة السريعة
create or replace function public.admin_ai_usage(p_days integer default 14)
returns table (day date, users bigint, uses bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('news.manage') or public.has_perm('stats.view')) then raise exception 'not allowed'; end if;
  return query select a.day, count(*)::bigint, coalesce(sum(a.n), 0)::bigint from ai_usage a
    where a.day >= current_date - least(greatest(coalesce(p_days, 14), 1), 60) group by a.day order by a.day;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.ai_use(integer)', 'public.admin_ai_usage(integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.13 — الأخبار: مجالات واهتمامات ودول
--  • كل خبر له مجال (cat) واهتمام فرعي (topic) ودولة (country — فارغ = عام)
--  • المصادر لها مجال ودولة افتراضية، وGemini يختار الاهتمام الفرعي
--  • المستخدم يختار دولته ومجالاته المفضلة، والخلاصة تنزل له حسب اختياره
--  • المجالات والدول والحدود والاشتراك تُدار من لوحة التحكم ← الأخبار ← المجالات والدول
-- شغّله مرة واحدة في SQL Editor بعد update-1.12.sql (آمن لو تكرر)
-- ============================================================

alter table public.news_items   add column if not exists topic   text not null default '';
alter table public.news_items   add column if not exists country text not null default '';
alter table public.news_sources add column if not exists topic   text not null default '';
alter table public.news_sources add column if not exists country text not null default '';
create index if not exists news_items_feed2 on public.news_items (status, cat, country, published_at desc);

-- تحويل تصنيفات «نبض AI» القديمة إلى مجال «الذكاء الاصطناعي» واهتماماته
update public.news_items set topic = case when cat = 'general' then '' else cat end, cat = 'ai'
  where cat in ('design', 'tools', 'media', 'companies', 'learn', 'general');
update public.news_sources set topic = case when cat = 'general' then '' else cat end, cat = 'ai'
  where cat in ('design', 'tools', 'media', 'companies', 'learn', 'general');

-- الخلاصة حسب اختيار المستخدم
--  p_cats: مجالاته المفضلة · p_countries: دوله (الخبر العام يوصل للكل) · p_topics: 'مجال/اهتمام' (لو حدّد اهتمامات داخل مجال)
create or replace function public.news_feed2(p_cats text[] default null, p_countries text[] default null, p_topics text[] default null,
  p_before timestamptz default null, p_limit int default 40)
returns setof json language sql stable security definer set search_path = public as $$
  select json_build_object('id', n.id, 'url', n.url, 'src', n.src_name, 'image', n.image, 'cat', n.cat, 'topic', n.topic, 'country', n.country,
    'title', n.title, 'summary', n.summary, 'body', n.body, 'why', n.why, 'pinned', n.pinned, 'ai', n.ai, 'at', n.published_at)
  from news_items n
  where n.status = 'published' and auth.uid() is not null
    and (coalesce(cardinality(p_cats), 0) = 0 or n.cat = any(p_cats))
    and (n.country = '' or n.country = any(coalesce(p_countries, array[]::text[])))
    and (coalesce(cardinality(p_topics), 0) = 0
         or not exists (select 1 from unnest(p_topics) t where split_part(t, '/', 1) = n.cat)
         or (n.cat || '/' || n.topic) = any(p_topics))
    and (p_before is null or n.published_at < p_before)
  order by (p_before is null and n.pinned) desc, n.published_at desc
  limit least(greatest(coalesce(p_limit, 40), 1), 80);
$$;

-- إعدادات القسم العامة للتطبيق: الاسم، الموجز، المجالات، الدول، الحدود، الاشتراك اللي يفتح مزايا التحكم
create or replace function public.news_meta()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object('title', coalesce(nullif(data->>'title', ''), 'الأخبار'), 'sub', coalesce(data->>'sub', ''),
    'hour', coalesce((data->>'hour')::int, 8), 'digest', coalesce((data->>'digest')::boolean, true),
    'domains', data->'domains', 'countries', data->'countries', 'limits', data->'limits', 'premium', data->'premium',
    'ask', coalesce((data->>'ask')::boolean, true))
  from news_settings where id = 1 and auth.uid() is not null;
$$;

-- حفظ خبر: يدعم المجال والاهتمام والدولة
create or replace function public.admin_news_save(p_item jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; st text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if length(coalesce(p_item->>'title', '')) < 3 then raise exception 'title required'; end if;
  st := coalesce(nullif(p_item->>'status', ''), 'draft');
  if (p_item->>'id') is null then
    insert into news_items (title, summary, body, why, cat, topic, country, image, url, src_name, status, pinned, created_by, published_at, guid)
    values (left(p_item->>'title', 220), left(coalesce(p_item->>'summary', ''), 600), left(coalesce(p_item->>'body', ''), 6000),
      left(coalesce(p_item->>'why', ''), 600), coalesce(nullif(p_item->>'cat', ''), 'ai'), left(coalesce(p_item->>'topic', ''), 40),
      left(coalesce(p_item->>'country', ''), 8), left(coalesce(p_item->>'image', ''), 600),
      left(coalesce(p_item->>'url', ''), 600), left(coalesce(nullif(p_item->>'src_name', ''), 'فريق NOBLE'), 60), st,
      coalesce((p_item->>'pinned')::boolean, false), auth.uid(), case when st = 'published' then now() end, 'manual:' || gen_random_uuid())
    returning id into nid;
  else
    nid := (p_item->>'id')::bigint;
    update news_items set
      title = left(p_item->>'title', 220), summary = left(coalesce(p_item->>'summary', ''), 600), body = left(coalesce(p_item->>'body', ''), 6000),
      why = left(coalesce(p_item->>'why', ''), 600), cat = coalesce(nullif(p_item->>'cat', ''), cat),
      topic = left(coalesce(p_item->>'topic', topic), 40), country = left(coalesce(p_item->>'country', country), 8),
      image = left(coalesce(p_item->>'image', image), 600),
      url = left(coalesce(p_item->>'url', url), 600), src_name = left(coalesce(nullif(p_item->>'src_name', ''), src_name), 60),
      status = st, pinned = coalesce((p_item->>'pinned')::boolean, pinned),
      published_at = case when st = 'published' then coalesce(published_at, now()) else published_at end, updated_at = now()
    where id = nid;
  end if;
  perform public.log_action('news', null, json_build_object('id', nid, 'status', st)::jsonb);
  return nid;
end $$;

-- المصادر: مجال + اهتمام + دولة
create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, topic, country, active) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, topic = excluded.topic, country = excluded.country, active = excluded.active
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active) where id = sid;
  end if;
  return sid;
end $$;

-- إحصائية: كم مستخدم اختار كل مجال/دولة (تُرسل من التطبيق كأحداث مجمّعة — بدون بيانات شخصية)
create or replace function public.admin_news_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'draft', (select count(*) from news_items where status = 'draft'),
    'today', (select count(*) from news_items where status = 'published' and published_at >= date_trunc('day', now())),
    'published', (select count(*) from news_items where status = 'published'),
    'views', (select coalesce(sum(views), 0) from news_items where published_at >= now() - interval '7 days'),
    'saves', (select coalesce(sum(saves), 0) from news_items where published_at >= now() - interval '7 days'),
    'by_cat', (select coalesce(json_object_agg(cat, n), '{}'::json) from (select cat, count(*) n from news_items where status = 'published' group by cat) x));
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.news_feed2(text[], text[], text[], timestamptz, int)', 'public.news_meta()',
    'public.admin_news_save(jsonb)', 'public.admin_news_source_save(jsonb)', 'public.admin_news_stats()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ---------- كود خصم 100٪: تفعيل مباشر بدون طلب دفع ----------
-- يتحقق من الكود (فعّال، ما انتهى، باقي له استخدامات، مسموح لهذا القسم والمدة) ومن إنه 100٪،
-- وما يسمح لنفس الشخص يستخدم نفس الكود مرتين، ويزيد عدّاد الاستخدام.
create or replace function public.claim_free_discount(p_code text, p_app text, p_plan text)
returns json language plpgsql security definer set search_path = public as $$
declare d discount_codes; eid bigint; u timestamptz;
begin
  if auth.uid() is null or not public.is_active() then raise exception 'not allowed'; end if;
  if p_app not in ('vault', 'tasks', 'today', 'news', 'finance', 'games', 'all') or p_plan not in ('m', 'y', 'l') then raise exception 'discount not for this'; end if;
  select * into d from discount_codes where code = upper(trim(p_code)) for update;
  if not found or not d.active then raise exception 'invalid discount'; end if;
  if d.until is not null and d.until < now() then raise exception 'discount expired'; end if;
  if d.max_uses is not null and d.used >= d.max_uses then raise exception 'discount used up'; end if;
  if d.apps is not null and not (p_app = any(d.apps)) then raise exception 'discount not for this'; end if;
  if d.plans is not null and not (p_plan = any(d.plans)) then raise exception 'discount not for this'; end if;
  if d.pct < 100 then raise exception 'discount not free'; end if;
  if exists (select 1 from entitlements where user_id = auth.uid() and source = 'discount' and ref = d.code) then raise exception 'discount already claimed'; end if;
  eid := public.grant_entitlement(auth.uid(), p_app, p_plan, 'discount', d.code, 0);
  update discount_codes set used = used + 1 where code = d.code;
  select until into u from entitlements where id = eid;
  perform public.log_action('discount_free', auth.uid(), json_build_object('code', d.code, 'app', p_app, 'plan', p_plan)::jsonb);
  return json_build_object('app', p_app, 'plan', p_plan, 'until', u);
end $$;
revoke all on function public.claim_free_discount(text, text, text) from anon, public;
grant execute on function public.claim_free_discount(text, text, text) to authenticated;

-- ============================================================
-- NOBLE 1.14 — التصاميم (قوالب، خلفيات صور/فيديو، خطوط، أصوات، مخطوطات) + كلمة اليوم + الأذكار
--  • قوالب ترفعها الإدارة (صورة + أماكن النصوص) — والمستخدم يكتب عليها ويحفظها أو يشاركها
--  • المناسبات والنصوص المقترحة والمواسم من لوحة التحكم ← التصاميم
--  • صور القوالب في Storage (مجلد designs عام للقراءة، والرفع للإدارة فقط)
-- شغّله مرة واحدة في SQL Editor بعد update-1.13.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.designs (
  id         bigserial primary key,
  data       jsonb not null default '{}'::jsonb,   -- {title, cat, size, image, slots[], premium, season{from,to}, tags}
  sort       integer not null default 0,
  active     boolean not null default true,
  uses       integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists designs_sort on public.designs (active, sort, id);

create table if not exists public.design_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {occasions[], texts{cat:[...]}, title, featured}
  updated_at timestamptz not null default now()
);
insert into public.design_settings (id) values (1) on conflict (id) do nothing;

alter table public.designs enable row level security;
alter table public.design_settings enable row level security;

-- للمستخدمين: القوالب المفعّلة + الإعدادات العامة
create or replace function public.designs_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from design_settings where id = 1),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', d.id, 'sort', d.sort) || d.data order by d.sort, d.id)
                       from designs d where d.active), '[]'::jsonb))
  where auth.uid() is not null;
$$;

-- عدّاد الاستخدام (كم مرة انحفظ/انشارك القالب)
create or replace function public.design_used(p_id bigint)
returns void language sql security definer set search_path = public as $$
  update designs set uses = uses + 1 where id = p_id and active and auth.uid() is not null;
$$;

-- لوحة التحكم
create or replace function public.admin_designs()
returns setof designs language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  return query select * from designs order by sort, id;
end $$;

create or replace function public.admin_design_save(p_id bigint, p_data jsonb, p_sort integer default null, p_active boolean default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 30000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into designs (data, sort, active) values (coalesce(p_data, '{}'::jsonb), coalesce(p_sort, (select coalesce(max(sort), 0) + 1 from designs)), coalesce(p_active, true))
    returning id into nid;
  else
    update designs set data = coalesce(p_data, data), sort = coalesce(p_sort, sort), active = coalesce(p_active, active), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  perform public.log_action('design', null, json_build_object('id', nid)::jsonb);
  return nid;
end $$;

create or replace function public.admin_design_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  delete from designs where id = p_id;
end $$;

create or replace function public.admin_design_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 40000 then raise exception 'too large'; end if;
  update design_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

-- إحصائية بسيطة للوحة
create or replace function public.admin_design_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not (public.has_perm('content.edit') or public.has_perm('apps.manage')) then raise exception 'not allowed'; end if;
  return json_build_object('count', (select count(*) from designs), 'active', (select count(*) from designs where active),
    'uses', (select coalesce(sum(uses), 0) from designs));
end $$;

-- مجلد الصور (Storage): قراءة للجميع، والرفع والحذف للإدارة فقط
do $$ begin
  begin
    insert into storage.buckets (id, name, public) values ('designs', 'designs', true) on conflict (id) do update set public = true;
    execute 'drop policy if exists "designs: read" on storage.objects';
    execute 'create policy "designs: read" on storage.objects for select using (bucket_id = ''designs'')';
    execute 'drop policy if exists "designs: staff write" on storage.objects';
    execute 'create policy "designs: staff write" on storage.objects for insert with check (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
    execute 'drop policy if exists "designs: staff update" on storage.objects';
    execute 'create policy "designs: staff update" on storage.objects for update using (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
    execute 'drop policy if exists "designs: staff delete" on storage.objects';
    execute 'create policy "designs: staff delete" on storage.objects for delete using (bucket_id = ''designs'' and (public.has_perm(''content.edit'') or public.has_perm(''apps.manage'')))';
  exception when others then
    raise notice 'Storage غير متاح هنا — أنشئ مجلد designs من Supabase ← Storage يدوياً (Public)';
  end;
end $$;

-- ---------- لعبة «كلمة اليوم»: نقاطها في الصدارة (حد أعلى ٦٠ للمحاولة) ----------
create or replace function public.submit_score(p_game text, p_score integer, p_meta jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
declare cap integer; cfg jsonb;
begin
  if not public.is_active() then raise exception 'not allowed'; end if;
  if exists (select 1 from profiles where id = auth.uid() and game_banned) then raise exception 'banned'; end if;
  select games into cfg from app_config where id = 1;
  if p_game in ('xo', 'flame', 'chase', 'word') and (cfg->p_game->>'on')::boolean is false then raise exception 'game disabled'; end if;
  cap := case p_game when 'xo' then 100 when 'flame' then 5000 when 'chase' then 3000 when 'tasks' then 50 when 'word' then 120 when 'daily' then 100 else 1000 end;
  cap := ceil(cap * public.game_multiplier(p_game));
  if p_score < 0 or p_score > cap then raise exception 'invalid score'; end if;
  if exists (select 1 from game_scores where user_id = auth.uid() and created_at > now() - interval '3 seconds') then
    raise exception 'too fast';
  end if;
  insert into game_scores (user_id, game, score, meta) values (auth.uid(), p_game, p_score, coalesce(p_meta, '{}'::jsonb));
end $$;

-- ============================================================
-- الأذكار والأدعية (مجانية للجميع) — الإدارة تضيف وتعدّل، والتطبيق يعرضها عند الفتح وفي قسم «أذكاري»
-- ============================================================
create table if not exists public.azkar (
  id         bigserial primary key,
  data       jsonb not null default '{}'::jsonb,   -- {text, virtue, source, cat, count, pin{from,to}}
  sort       integer not null default 0,
  active     boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists azkar_sort on public.azkar (active, sort, id);
create table if not exists public.azkar_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {toast{on,style,pos,auto,freq,mode}, remind{on,morning,evening}, title, builtin}
  updated_at timestamptz not null default now()
);
insert into public.azkar_settings (id) values (1) on conflict (id) do nothing;
alter table public.azkar enable row level security;
alter table public.azkar_settings enable row level security;

create or replace function public.azkar_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from azkar_settings where id = 1),
    'items', coalesce((select jsonb_agg(jsonb_build_object('id', z.id, 'sort', z.sort) || z.data order by z.sort, z.id) from azkar z where z.active), '[]'::jsonb))
  where auth.uid() is not null;
$$;
create or replace function public.admin_azkar()
returns setof azkar language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return query select * from azkar order by sort, id;
end $$;
create or replace function public.admin_azkar_save(p_id bigint, p_data jsonb, p_sort integer default null, p_active boolean default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 8000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into azkar (data, sort, active) values (coalesce(p_data, '{}'::jsonb), coalesce(p_sort, (select coalesce(max(sort), 0) + 1 from azkar)), coalesce(p_active, true)) returning id into nid;
  else
    update azkar set data = coalesce(p_data, data), sort = coalesce(p_sort, sort), active = coalesce(p_active, active), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  return nid;
end $$;
create or replace function public.admin_azkar_delete(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  delete from azkar where id = p_id;
end $$;
create or replace function public.admin_azkar_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update azkar_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.designs_list()', 'public.design_used(bigint)', 'public.admin_designs()', 'public.admin_design_save(bigint, jsonb, integer, boolean)',
    'public.admin_design_delete(bigint)', 'public.admin_design_meta(jsonb)', 'public.admin_design_stats()',
    'public.azkar_list()', 'public.admin_azkar()', 'public.admin_azkar_save(bigint, jsonb, integer, boolean)', 'public.admin_azkar_delete(bigint)', 'public.admin_azkar_meta(jsonb)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ---------- الأخبار: مصادر عربية موثوقة بدون ترجمة (1.14) ----------
-- المصدر العربي يُنشر من عنوانه ونبذته مباشرة (بدون Gemini ولا يستهلك الحد المجاني)،
-- إلا لو فعّلت له «صياغة AI» من لوحة التحكم ← الأخبار ← المصادر.
alter table public.news_sources add column if not exists lang text not null default 'en';
alter table public.news_sources add column if not exists rewrite boolean not null default false;

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, topic, country, active, lang, rewrite) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true),
      case when p_src->>'lang' = 'ar' then 'ar' else 'en' end, coalesce((p_src->>'rewrite')::boolean, false))
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, topic = excluded.topic, country = excluded.country, active = excluded.active,
      lang = excluded.lang, rewrite = excluded.rewrite
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active),
      lang = case when p_src ? 'lang' then (case when p_src->>'lang' = 'ar' then 'ar' else 'en' end) else lang end,
      rewrite = coalesce((p_src->>'rewrite')::boolean, rewrite) where id = sid;
  end if;
  return sid;
end $$;
revoke all on function public.admin_news_source_save(jsonb) from anon, public;
grant execute on function public.admin_news_source_save(jsonb) to authenticated;

-- مجال «أخبار عامة» — يُضاف لقائمة المجالات لو كانت معدّلة من اللوحة (الافتراضي فيه أصلاً)
update public.news_settings
   set data = jsonb_set(data, '{domains}', jsonb_build_array(jsonb_build_object('id', 'news', 'ic', '📰', 'name', 'أخبار عامة', 'on', true,
     'subs', jsonb_build_array(jsonb_build_array('saudi', 'السعودية'), jsonb_build_array('gulf', 'الخليج'), jsonb_build_array('arab', 'العالم العربي'), jsonb_build_array('world', 'العالم'))))
     || (data->'domains'))
 where id = 1 and jsonb_typeof(data->'domains') = 'array' and jsonb_array_length(data->'domains') > 0
   and not exists (select 1 from jsonb_array_elements(data->'domains') d where d->>'id' = 'news');

-- مصادر عربية موثوقة (لو الرابط تغيّر عند المصدر يظهر «خطأ» جنبه في اللوحة وتقدر توقفه أو تعدّله)
insert into public.news_sources (name, url, cat, topic, country, lang, rewrite) values
  ('الجزيرة نت', 'https://www.aljazeera.net/aljazeerarss/a7c186be-1baa-4bd4-9d80-a84db769f779/73d0e1b4-532f-45ef-b135-bfdff8b8cab9', 'news', '', '', 'ar', false),
  ('BBC عربي', 'https://feeds.bbci.co.uk/arabic/rss.xml', 'news', '', '', 'ar', false),
  ('سكاي نيوز عربية', 'https://www.skynewsarabia.com/rss.xml', 'news', '', '', 'ar', false),
  ('فرانس 24 عربي', 'https://www.france24.com/ar/rss', 'news', 'world', '', 'ar', false),
  ('DW عربية', 'https://rss.dw.com/rdf/rss-ar-all', 'news', 'world', '', 'ar', false),
  ('عكاظ', 'https://www.okaz.com.sa/rssFeed/0', 'news', 'saudi', 'sa', 'ar', false),
  ('البوابة العربية للأخبار التقنية', 'https://aitnews.com/feed/', 'tech', '', '', 'ar', false),
  ('عالم التقنية', 'https://www.tech-wd.com/wd/feed/', 'tech', '', '', 'ar', false)
on conflict (url) do nothing;

-- ============================================================
-- NOBLE 1.15 — «اشتراكي» + الستوري وقسم «اكتشف»
--  • my_subscription(): تاريخ اشتراكات المستخدم كامل (حتى المنتهية) لصفحة «اشتراكي»
--  • feed_items: الستوري والمنشورات (فيديو، صور كاروسيل، استفتاء) — لكل ستوري مدة تنتهي بعدها وتنحذف
--  • إعجاب + استفتاء + مشاهدات + تعليقات (التعليق ما يظهر إلا بعد موافقة الإدارة)
-- شغّله مرة واحدة في SQL Editor بعد update-1.14.sql (آمن لو تكرر)
-- ============================================================

-- ---------- «اشتراكي»: كل الاشتراكات (الفعّالة والمنتهية) ----------
create or replace function public.my_subscription()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'ents', coalesce((select json_agg(json_build_object('id', e.id, 'app', e.app, 'plan', e.plan, 'until', e.until, 'source', e.source,
                        'amount', e.amount, 'revoked', e.revoked, 'created_at', e.created_at) order by e.created_at desc)
                      from entitlements e where e.user_id = auth.uid()), '[]'::json),
    'pays', coalesce((select json_agg(json_build_object('id', p.id, 'app', p.app, 'plan', p.plan, 'amount', p.amount, 'discount', p.discount,
                        'method', p.method, 'status', p.status, 'created_at', p.created_at, 'decided_at', p.decided_at) order by p.created_at desc)
                      from payment_requests p where p.user_id = auth.uid()), '[]'::json))
  where auth.uid() is not null;
$$;

-- ---------- الستوري والمنشورات ----------
create table if not exists public.feed_items (
  id         bigserial primary key,
  kind       text not null default 'post' check (kind in ('story', 'post')),
  data       jsonb not null default '{}'::jsonb,   -- {type: image|video|carousel|poll|text, media:[{url,kind,path}], caption, link:{url,label}, poll:{q, options[]}, ring}
  highlight  boolean not null default false,       -- ستوري «مميزة» دائمة
  expires_at timestamptz,                          -- null = دائم
  active     boolean not null default true,
  sort       integer not null default 0,
  views      integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists feed_items_live on public.feed_items (kind, active, expires_at);

create table if not exists public.feed_likes (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (item_id, user_id)
);
create table if not exists public.feed_votes (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  opt     integer not null,
  created_at timestamptz not null default now(),
  primary key (item_id, user_id)
);
create table if not exists public.feed_seen (
  item_id bigint not null references public.feed_items(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  primary key (item_id, user_id)
);
create table if not exists public.feed_comments (
  id         bigserial primary key,
  item_id    bigint not null references public.feed_items(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  body       text not null,
  status     text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now(),
  decided_at timestamptz
);
create index if not exists feed_comments_item on public.feed_comments (item_id, status);
create index if not exists feed_comments_status on public.feed_comments (status, created_at);

create table if not exists public.feed_settings (
  id   int primary key default 1 check (id = 1),
  data jsonb not null default '{}'::jsonb,           -- {title, sub, comments, storiesOn, discoverOn}
  updated_at timestamptz not null default now()
);
insert into public.feed_settings (id) values (1) on conflict (id) do nothing;

alter table public.feed_items enable row level security;
alter table public.feed_likes enable row level security;
alter table public.feed_votes enable row level security;
alter table public.feed_seen enable row level security;
alter table public.feed_comments enable row level security;
alter table public.feed_settings enable row level security;

-- للمستخدم: الستوري والمنشورات الحية (المنتهية ما تطلع) + تفاعله
create or replace function public.feed_list()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'meta', (select data from feed_settings where id = 1),
    'items', coalesce((select json_agg(x order by x.highlight desc, x.sort, x.created_at desc) from (
      select f.id, f.kind, f.data, f.highlight, f.expires_at, f.sort, f.created_at, f.views,
        (select count(*) from feed_likes l where l.item_id = f.id) as likes,
        exists(select 1 from feed_likes l where l.item_id = f.id and l.user_id = auth.uid()) as liked,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'approved') as comments,
        (select v.opt from feed_votes v where v.item_id = f.id and v.user_id = auth.uid()) as voted,
        (select coalesce(json_object_agg(opt, n), '{}'::json) from (select v.opt, count(*) n from feed_votes v where v.item_id = f.id group by v.opt) t) as tally
      from feed_items f
      where f.active and (f.expires_at is null or f.expires_at > now())) x), '[]'::json))
  where auth.uid() is not null;
$$;

create or replace function public.feed_like(p_id bigint)
returns json language plpgsql security definer set search_path = public as $$
declare on_ boolean;
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if exists(select 1 from feed_likes where item_id = p_id and user_id = auth.uid()) then
    delete from feed_likes where item_id = p_id and user_id = auth.uid(); on_ := false;
  else
    insert into feed_likes (item_id, user_id) select p_id, auth.uid() where exists(select 1 from feed_items where id = p_id and active); on_ := true;
  end if;
  return json_build_object('liked', on_, 'likes', (select count(*) from feed_likes where item_id = p_id));
end $$;

create or replace function public.feed_vote(p_id bigint, p_opt integer)
returns json language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if p_opt < 0 or p_opt > 9 then raise exception 'bad option'; end if;
  insert into feed_votes (item_id, user_id, opt) select p_id, auth.uid(), p_opt where exists(select 1 from feed_items where id = p_id and active)
  on conflict (item_id, user_id) do update set opt = excluded.opt, created_at = now();
  return (select coalesce(json_object_agg(opt, n), '{}'::json) from (select opt, count(*) n from feed_votes where item_id = p_id group by opt) t);
end $$;

create or replace function public.feed_seen_mark(p_id bigint)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then return; end if;
  insert into feed_seen (item_id, user_id) values (p_id, auth.uid()) on conflict do nothing;
  if found then update feed_items set views = views + 1 where id = p_id; end if;
end $$;

-- التعليقات: الموافق عليها + تعليقاتي اللي تنتظر
create or replace function public.feed_comments_list(p_id bigint)
returns json language sql stable security definer set search_path = public as $$
  select coalesce(json_agg(json_build_object('id', c.id, 'body', c.body, 'status', c.status, 'mine', c.user_id = auth.uid(), 'created_at', c.created_at,
           'name', coalesce(nullif(split_part(p.display_name, ' ', 1), ''), 'مستخدم')) order by c.created_at), '[]'::json)
  from feed_comments c left join profiles p on p.id = c.user_id
  where auth.uid() is not null and c.item_id = p_id and (c.status = 'approved' or c.user_id = auth.uid());
$$;

create or replace function public.feed_comment(p_id bigint, p_body text)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint; b text := btrim(coalesce(p_body, ''));
begin
  if auth.uid() is null then raise exception 'not allowed'; end if;
  if length(b) < 1 then raise exception 'empty'; end if;
  if length(b) > 500 then b := left(b, 500); end if;
  if coalesce((select (data->>'comments')::boolean from feed_settings where id = 1), true) = false then raise exception 'comments off'; end if;
  if (select count(*) from feed_comments where user_id = auth.uid() and created_at > now() - interval '1 day') >= 30 then raise exception 'limit'; end if;
  insert into feed_comments (item_id, user_id, body) select p_id, auth.uid(), b where exists(select 1 from feed_items where id = p_id and active)
  returning id into nid;
  return nid;
end $$;

-- ---------- لوحة التحكم ----------
create or replace function public.admin_feed()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return json_build_object(
    'meta', (select data from feed_settings where id = 1),
    'items', coalesce((select json_agg(x order by x.kind, x.highlight desc, x.sort, x.created_at desc) from (
      select f.*, (select count(*) from feed_likes l where l.item_id = f.id) as likes,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'approved') as comments,
        (select count(*) from feed_comments c where c.item_id = f.id and c.status = 'pending') as pending,
        (select coalesce(json_object_agg(opt, n), '{}'::json) from (select v.opt, count(*) n from feed_votes v where v.item_id = f.id group by v.opt) t) as tally
      from feed_items f) x), '[]'::json),
    'pending', (select count(*) from feed_comments where status = 'pending'));
end $$;

create or replace function public.admin_feed_save(p_id bigint, p_kind text, p_data jsonb, p_expires timestamptz, p_highlight boolean, p_active boolean, p_sort integer)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 30000 then raise exception 'too large'; end if;
  if p_id is null then
    insert into feed_items (kind, data, expires_at, highlight, active, sort)
    values (case when p_kind = 'story' then 'story' else 'post' end, coalesce(p_data, '{}'::jsonb), p_expires, coalesce(p_highlight, false), coalesce(p_active, true), coalesce(p_sort, 0))
    returning id into nid;
  else
    update feed_items set data = coalesce(p_data, data), expires_at = p_expires, highlight = coalesce(p_highlight, highlight),
      active = coalesce(p_active, active), sort = coalesce(p_sort, sort), updated_at = now() where id = p_id;
    nid := p_id;
  end if;
  return nid;
end $$;

create or replace function public.admin_feed_delete(p_id bigint)
returns jsonb language plpgsql security definer set search_path = public as $$
declare d jsonb;
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  delete from feed_items where id = p_id returning data into d;
  return d; -- اللوحة تحذف ملفاته من Storage
end $$;

-- المنتهية (غير المميزة): اللوحة تحذف ملفاتها من Storage ثم تحذفها من الجدول
create or replace function public.admin_feed_expired()
returns setof feed_items language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return query select * from feed_items where not highlight and expires_at is not null and expires_at <= now();
end $$;

create or replace function public.admin_feed_meta(p_data jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if length(coalesce(p_data, '{}'::jsonb)::text) > 20000 then raise exception 'too large'; end if;
  update feed_settings set data = coalesce(p_data, '{}'::jsonb), updated_at = now() where id = 1;
end $$;

create or replace function public.admin_feed_comments(p_status text default 'pending')
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  return coalesce((select json_agg(json_build_object('id', c.id, 'item_id', c.item_id, 'body', c.body, 'status', c.status, 'created_at', c.created_at,
      'name', coalesce(p.display_name, p.email, 'مستخدم'), 'email', p.email, 'caption', left(coalesce(f.data->>'caption', ''), 80)) order by c.created_at desc)
    from (select * from feed_comments where status = coalesce(p_status, 'pending') order by created_at desc limit 300) c
    left join profiles p on p.id = c.user_id left join feed_items f on f.id = c.item_id), '[]'::json);
end $$;

create or replace function public.admin_feed_comment_set(p_id bigint, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('content.edit') then raise exception 'not allowed'; end if;
  if p_status = 'delete' then delete from feed_comments where id = p_id; return; end if;
  if p_status not in ('approved', 'rejected', 'pending') then raise exception 'bad status'; end if;
  update feed_comments set status = p_status, decided_at = now() where id = p_id;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.my_subscription()', 'public.feed_list()', 'public.feed_like(bigint)', 'public.feed_vote(bigint, integer)',
    'public.feed_seen_mark(bigint)', 'public.feed_comments_list(bigint)', 'public.feed_comment(bigint, text)',
    'public.admin_feed()', 'public.admin_feed_save(bigint, text, jsonb, timestamptz, boolean, boolean, integer)', 'public.admin_feed_delete(bigint)',
    'public.admin_feed_expired()', 'public.admin_feed_meta(jsonb)', 'public.admin_feed_comments(text)', 'public.admin_feed_comment_set(bigint, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- NOBLE 1.16 — «راسل الإدارة» (الدعم)
--  • المستخدم يرسل مشكلته أو اقتراحه مع صور أو فيديو (حتى ٤ مرفقات)
--  • المرفقات في مخزن خاص «support» — ما يشوفها إلا المالك وفريقه، وما تنحذف إلا بقرارك
--  • تقدر توقف الزر عن الكل أو تخفيه عن مستخدمين محددين
-- شغّله مرة واحدة في SQL Editor بعد update-1.15.sql (آمن لو تكرر)
-- ============================================================

create table if not exists public.support_tickets (
  id            bigserial primary key,
  user_id       uuid not null references auth.users(id) on delete cascade,
  cat           text not null default 'issue' check (cat in ('issue', 'idea', 'billing', 'question', 'other')),
  body          text not null,
  files         jsonb not null default '[]'::jsonb,   -- [{path, kind: image|video, size, name}]
  meta          jsonb not null default '{}'::jsonb,   -- {app, version, platform, device, screen, tab, lang}
  status        text not null default 'new' check (status in ('new', 'open', 'done')),
  reply         text,
  replied_at    timestamptz,
  files_deleted boolean not null default false,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create index if not exists support_tickets_user_idx on public.support_tickets (user_id, created_at desc);
create index if not exists support_tickets_status_idx on public.support_tickets (status, created_at desc);
alter table public.support_tickets enable row level security;   -- الوصول عبر الدوال فقط

create table if not exists public.support_settings (
  id         integer primary key default 1 check (id = 1),
  enabled    boolean not null default true,
  blocked    uuid[] not null default '{}',
  max_day    integer not null default 5,
  updated_at timestamptz not null default now()
);
insert into public.support_settings (id) values (1) on conflict (id) do nothing;
alter table public.support_settings enable row level security;

-- ---------- مخزن المرفقات (خاص) ----------
insert into storage.buckets (id, name, public, file_size_limit)
values ('support', 'support', false, 31457280)
on conflict (id) do update set public = false, file_size_limit = 31457280;

drop policy if exists "support: user uploads own folder" on storage.objects;
create policy "support: user uploads own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'support' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "support: staff read" on storage.objects;
create policy "support: staff read" on storage.objects for select to authenticated
  using (bucket_id = 'support' and public.has_perm('messages.send'));
drop policy if exists "support: staff delete" on storage.objects;
create policy "support: staff delete" on storage.objects for delete to authenticated
  using (bucket_id = 'support' and public.has_perm('messages.send'));

-- ---------- المستخدم ----------
create or replace function public.support_status()
returns json language sql stable security definer set search_path = public as $$
  select json_build_object(
    'on', s.enabled and not (auth.uid() = any(s.blocked)),
    'max_day', s.max_day,
    'used', (select count(*) from support_tickets t where t.user_id = auth.uid() and t.created_at > now() - interval '1 day'),
    'unread', (select count(*) from support_tickets t where t.user_id = auth.uid() and t.reply is not null and t.replied_at > coalesce((t.meta->>'seen_at')::timestamptz, 'epoch')))
  from support_settings s where s.id = 1 and auth.uid() is not null;
$$;

create or replace function public.support_send(p_cat text, p_body text, p_files jsonb default '[]'::jsonb, p_meta jsonb default '{}'::jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare s support_settings; v_id bigint; f jsonb;
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and status = 'active') then raise exception 'account suspended'; end if;
  select * into s from support_settings where id = 1;
  if not s.enabled or auth.uid() = any(s.blocked) then raise exception 'support closed'; end if;
  if length(trim(coalesce(p_body, ''))) < 3 then raise exception 'message too short'; end if;
  if (select count(*) from support_tickets where user_id = auth.uid() and created_at > now() - interval '1 day') >= s.max_day then raise exception 'daily limit'; end if;
  if jsonb_typeof(coalesce(p_files, '[]'::jsonb)) <> 'array' or jsonb_array_length(coalesce(p_files, '[]'::jsonb)) > 4 then raise exception 'too many files'; end if;
  for f in select * from jsonb_array_elements(coalesce(p_files, '[]'::jsonb)) loop
    if split_part(f->>'path', '/', 1) <> auth.uid()::text then raise exception 'bad file path'; end if;
  end loop;
  insert into support_tickets (user_id, cat, body, files, meta)
  values (auth.uid(), case when p_cat in ('issue', 'idea', 'billing', 'question', 'other') then p_cat else 'other' end,
          left(trim(p_body), 2000), coalesce(p_files, '[]'::jsonb), coalesce(p_meta, '{}'::jsonb) - 'seen_at')
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.support_mine()
returns json language sql stable security definer set search_path = public as $$
  select coalesce(json_agg(json_build_object('id', t.id, 'cat', t.cat, 'body', t.body, 'status', t.status, 'reply', t.reply,
    'replied_at', t.replied_at, 'created_at', t.created_at, 'nfiles', jsonb_array_length(t.files)) order by t.created_at desc), '[]'::json)
  from (select * from support_tickets where user_id = auth.uid() order by created_at desc limit 30) t;
$$;

create or replace function public.support_seen()
returns void language sql security definer set search_path = public as $$
  update support_tickets set meta = meta || jsonb_build_object('seen_at', now()) where user_id = auth.uid() and reply is not null;
$$;

-- ---------- لوحة المالك ----------
create or replace function public.admin_support_list(p_status text default null)
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  return coalesce((select json_agg(json_build_object('id', t.id, 'user_id', t.user_id, 'cat', t.cat, 'body', t.body, 'files', t.files, 'meta', t.meta - 'seen_at',
      'status', t.status, 'reply', t.reply, 'replied_at', t.replied_at, 'files_deleted', t.files_deleted, 'created_at', t.created_at,
      'name', coalesce(nullif(p.display_name, ''), p.email, 'مستخدم'), 'email', p.email,
      'count', (select count(*) from support_tickets x where x.user_id = t.user_id)) order by t.created_at desc)
    from (select * from support_tickets where p_status is null or p_status = 'all' or status = p_status order by created_at desc limit 300) t
    left join profiles p on p.id = t.user_id), '[]'::json);
end $$;

create or replace function public.admin_support_counts()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then return json_build_object('new', 0, 'open', 0); end if;
  return (select json_build_object('new', count(*) filter (where status = 'new'), 'open', count(*) filter (where status = 'open'),
    'done', count(*) filter (where status = 'done'), 'all', count(*)) from support_tickets);
end $$;

create or replace function public.admin_support_set(p_id bigint, p_status text default null, p_reply text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  if p_status is not null and p_status not in ('new', 'open', 'done') then raise exception 'bad status'; end if;
  update support_tickets set
    status = coalesce(p_status, status),
    reply = case when p_reply is not null and length(trim(p_reply)) > 0 then left(trim(p_reply), 2000) else reply end,
    replied_at = case when p_reply is not null and length(trim(p_reply)) > 0 then now() else replied_at end,
    updated_at = now()
  where id = p_id;
end $$;

-- يرجّع مسارات المرفقات عشان اللوحة تحذفها من المخزن
create or replace function public.admin_support_delete(p_id bigint, p_files_only boolean default false)
returns json language plpgsql security definer set search_path = public as $$
declare v jsonb;
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  select files into v from support_tickets where id = p_id;
  if p_files_only then update support_tickets set files = '[]'::jsonb, files_deleted = true, updated_at = now() where id = p_id;
  else delete from support_tickets where id = p_id; end if;
  return coalesce((select json_agg(x->>'path') from jsonb_array_elements(coalesce(v, '[]'::jsonb)) x), '[]'::json);
end $$;

create or replace function public.admin_support_settings()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  return (select json_build_object('enabled', s.enabled, 'max_day', s.max_day,
    'blocked', coalesce((select json_agg(json_build_object('id', p.id, 'name', coalesce(nullif(p.display_name, ''), p.email, 'مستخدم'), 'email', p.email))
                         from profiles p where p.id = any(s.blocked)), '[]'::json))
    from support_settings s where s.id = 1);
end $$;

create or replace function public.admin_support_settings_save(p_enabled boolean, p_blocked uuid[], p_max_day integer)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  update support_settings set enabled = coalesce(p_enabled, enabled), blocked = coalesce(p_blocked, blocked),
    max_day = greatest(1, least(50, coalesce(p_max_day, max_day))), updated_at = now() where id = 1;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.support_status()', 'public.support_send(text, text, jsonb, jsonb)', 'public.support_mine()', 'public.support_seen()',
    'public.admin_support_list(text)', 'public.admin_support_counts()', 'public.admin_support_set(bigint, text, text)',
    'public.admin_support_delete(bigint, boolean)', 'public.admin_support_settings()', 'public.admin_support_settings_save(boolean, uuid[], integer)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- ============================================================
-- 1.16 — إيصال التحويل: المشترك يرفق صورة الإيصال قبل ما يأكد طلب الدفع
-- ============================================================
alter table public.payment_requests add column if not exists receipt text not null default '';

insert into storage.buckets (id, name, public, file_size_limit)
values ('receipts', 'receipts', false, 10485760)
on conflict (id) do update set public = false, file_size_limit = 10485760;

drop policy if exists "receipts: user uploads own folder" on storage.objects;
create policy "receipts: user uploads own folder" on storage.objects for insert to authenticated
  with check (bucket_id = 'receipts' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "receipts: billing read" on storage.objects;
create policy "receipts: billing read" on storage.objects for select to authenticated
  using (bucket_id = 'receipts' and public.has_perm('billing.manage'));
drop policy if exists "receipts: billing delete" on storage.objects;
create policy "receipts: billing delete" on storage.objects for delete to authenticated
  using (bucket_id = 'receipts' and public.has_perm('billing.manage'));

-- يربط الإيصال بطلب الدفع (صاحب الطلب فقط، والطلب لسا بانتظار المراجعة)
create or replace function public.payment_receipt_set(p_id bigint, p_path text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'not signed in'; end if;
  if split_part(coalesce(p_path, ''), '/', 1) <> auth.uid()::text then raise exception 'bad path'; end if;
  update payment_requests set receipt = left(p_path, 200)
   where id = p_id and user_id = auth.uid() and status = 'pending';
end $$;

-- الإيصالات لطلبات الدفع (للوحة التحكم)
create or replace function public.admin_payment_receipts()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('billing.manage') then raise exception 'not allowed'; end if;
  return coalesce((select json_object_agg(id, receipt) from (select id, receipt from payment_requests where receipt <> '' order by id desc limit 300) r), '{}'::json);
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.payment_receipt_set(bigint, text)', 'public.admin_payment_receipts()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;

-- =====================================================================
--  NOBLE — تحديث قاعدة البيانات للإصدار 1.17
--  صلاحيات الأقسام: ناس محددين بالاسم أو الإيميل أو نطاق الإيميل أو المجموعات، مع مدة، واستثناءات لكل مستخدم.
--  الصق الملف كاملاً في: Supabase → SQL Editor → New query → Run   (آمن للتشغيل أكثر من مرة)
-- =====================================================================

-- المجموعات (العائلة، عملاء، فريق…)
create table if not exists public.section_groups (
  id         text primary key,
  name       text not null default '',
  color      text not null default '#56C8FF',
  users      uuid[] not null default '{}',
  created_at timestamptz not null default now()
);
-- صلاحيات كل قسم «👥 محددين»: allow = فقط هؤلاء · deny = الكل إلا هؤلاء
create table if not exists public.section_perms (
  sec        text primary key,
  mode       text not null default 'allow' check (mode in ('allow', 'deny')),
  users      uuid[] not null default '{}',
  groups     text[] not null default '{}',
  domains    text[] not null default '{}',
  until      jsonb  not null default '{}'::jsonb,   -- { "<user uuid>": "YYYY-MM-DD" } صلاحية لمدة
  updated_at timestamptz not null default now()
);
-- استثناء خاص لمستخدم: show = أظهره له · hide = أخفِه عنه
create table if not exists public.section_overrides (
  user_id uuid not null references auth.users(id) on delete cascade,
  sec     text not null,
  mode    text not null check (mode in ('show', 'hide')),
  primary key (user_id, sec)
);
alter table public.section_groups    enable row level security;
alter table public.section_perms     enable row level security;
alter table public.section_overrides enable row level security;
-- ما فيه سياسات = ما أحد يقرأها مباشرة؛ كل شي عبر الدوال تحت (ما تنكشف الإيميلات للمستخدمين)

-- ---------- للمستخدم: وش الأقسام المسموحة/الممنوعة له؟ ----------
create or replace function public.my_section_access()
returns json language plpgsql stable security definer set search_path = public as $$
declare
  uid uuid := auth.uid();
  em  text;
  dom text;
  ok  text[] := '{}';
  no  text[] := '{}';
  r   record;
  hit boolean;
  exp text;
begin
  if uid is null then return json_build_object('ok', '[]'::json, 'no', '[]'::json, 'show', '[]'::json, 'hide', '[]'::json); end if;
  select lower(coalesce(email, '')) into em from profiles where id = uid;
  dom := split_part(coalesce(em, ''), '@', 2);
  for r in select * from section_perms loop
    hit := uid = any(r.users)
        or exists (select 1 from section_groups g where g.id = any(r.groups) and uid = any(g.users))
        or (dom <> '' and dom = any(r.domains));
    exp := r.until ->> uid::text;
    if hit and exp is not null and exp <> '' and exp::date < current_date then hit := false; end if;
    if (r.mode = 'allow' and hit) or (r.mode = 'deny' and not hit) then ok := ok || r.sec; else no := no || r.sec; end if;
  end loop;
  return json_build_object('ok', to_json(ok), 'no', to_json(no),
    'show', coalesce((select json_agg(sec) from section_overrides where user_id = uid and mode = 'show'), '[]'::json),
    'hide', coalesce((select json_agg(sec) from section_overrides where user_id = uid and mode = 'hide'), '[]'::json));
end $$;

-- ---------- للإدارة ----------
create or replace function public.admin_sections_get()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'perms', coalesce((select json_agg(row_to_json(p)) from section_perms p), '[]'::json),
    'groups', coalesce((select json_agg(row_to_json(g) order by g.created_at) from section_groups g), '[]'::json),
    'overrides', coalesce((select json_agg(row_to_json(o)) from section_overrides o), '[]'::json));
end $$;

create or replace function public.admin_section_perm_save(p_sec text, p_mode text, p_users uuid[], p_groups text[], p_domains text[], p_until jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  if p_sec is null or length(p_sec) > 30 then raise exception 'bad section'; end if;
  insert into section_perms (sec, mode, users, groups, domains, until, updated_at)
  values (p_sec, coalesce(nullif(p_mode, ''), 'allow'), coalesce(p_users, '{}'), coalesce(p_groups, '{}'),
          (select coalesce(array_agg(distinct lower(trim(d))), '{}') from unnest(coalesce(p_domains, '{}')) d where trim(d) <> ''), coalesce(p_until, '{}'::jsonb), now())
  on conflict (sec) do update set mode = excluded.mode, users = excluded.users, groups = excluded.groups, domains = excluded.domains, until = excluded.until, updated_at = now();
end $$;

create or replace function public.admin_section_perm_delete(p_sec text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  delete from section_perms where sec = p_sec;
end $$;

create or replace function public.admin_section_group_save(p_id text, p_name text, p_color text, p_users uuid[])
returns text language plpgsql security definer set search_path = public as $$
declare gid text := coalesce(nullif(p_id, ''), 'g' || substr(md5(random()::text || clock_timestamp()::text), 1, 10));
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  insert into section_groups (id, name, color, users) values (gid, left(coalesce(p_name, ''), 40), left(coalesce(p_color, '#56C8FF'), 20), coalesce(p_users, '{}'))
  on conflict (id) do update set name = excluded.name, color = excluded.color, users = excluded.users;
  return gid;
end $$;

create or replace function public.admin_section_group_delete(p_id text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  delete from section_groups where id = p_id;
  update section_perms set groups = array_remove(groups, p_id) where p_id = any(groups);
end $$;

create or replace function public.admin_section_override_set(p_user uuid, p_sec text, p_mode text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('sections.manage') then raise exception 'not allowed'; end if;
  if coalesce(p_mode, '') = '' then delete from section_overrides where user_id = p_user and sec = p_sec;
  else insert into section_overrides (user_id, sec, mode) values (p_user, p_sec, p_mode)
       on conflict (user_id, sec) do update set mode = excluded.mode; end if;
end $$;

do $$
declare f text;
begin
  foreach f in array array['public.my_section_access()', 'public.admin_sections_get()', 'public.admin_section_perm_save(text, text, uuid[], text[], text[], jsonb)', 'public.admin_section_perm_delete(text)',
    'public.admin_section_group_save(text, text, text, uuid[])', 'public.admin_section_group_delete(text)', 'public.admin_section_override_set(uuid, text, text)']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;


-- ---------- ملفات للحسابات الموجودة مسبقاً (إن سُجّلت قبل تشغيل الإعداد) ----------
insert into public.profiles (id, email, display_name, role)
select u.id, u.email, coalesce(u.raw_user_meta_data->>'display_name', ''),
       case when lower(u.email) = lower(public.admin_email()) then 'owner' else 'user' end
  from auth.users u
 where not exists (select 1 from public.profiles p where p.id = u.id);
update public.profiles set role = 'owner' where lower(email) = lower(public.admin_email());
create or replace function public.admin_news_publish_back(p_id bigint, p_hours int default 24)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  update news_items set
    status = 'published',
    published_at = now() - make_interval(hours => least(greatest(coalesce(p_hours, 24), 1), 168)),
    updated_at = now()
  where id = p_id;
end $$;
revoke all on function public.admin_news_publish_back(bigint, int) from public, anon;
grant execute on function public.admin_news_publish_back(bigint, int) to authenticated;
create table if not exists public.user_notes (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  tags       text[] not null default '{}',
  note       text not null default '',
  updated_by uuid,
  updated_at timestamptz not null default now()
);
alter table public.user_notes enable row level security; -- بدون سياسات: ما أحد يقراها إلا من الدوال تحت

create or replace function public.admin_user_notes()
returns table (user_id uuid, tags text[], note text, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query select n.user_id, n.tags, n.note, n.updated_at from user_notes n;
end $$;

create or replace function public.admin_user_note_set(p_uid uuid, p_tags text[], p_note text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') then raise exception 'not allowed'; end if;
  insert into user_notes (user_id, tags, note, updated_by, updated_at)
  values (p_uid, coalesce(p_tags[1:12], '{}'), left(coalesce(p_note, ''), 2000), auth.uid(), now())
  on conflict (user_id) do update set tags = excluded.tags, note = excluded.note, updated_by = excluded.updated_by, updated_at = now();
end $$;

revoke all on function public.admin_user_notes() from public, anon;
revoke all on function public.admin_user_note_set(uuid, text[], text) from public, anon;
grant execute on function public.admin_user_notes() to authenticated;
grant execute on function public.admin_user_note_set(uuid, text[], text) to authenticated;
-- رموز الأجهزة (token) اللي يعطيها Firebase لكل جوال — بدون أي معلومة شخصية، وتنحذف مع الحساب
create table if not exists public.push_tokens (
  token      text primary key,
  user_id    uuid references auth.users(id) on delete cascade,
  app        text not null default 'nobleweb',
  platform   text not null default 'android',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists push_tokens_user on public.push_tokens (user_id);
alter table public.push_tokens enable row level security; -- الوصول عبر الدوال فقط

-- سجل الإشعارات اللي انرسلت (للحد اليومي ودمج الدفعات)
create table if not exists public.push_log (
  id      bigserial primary key,
  kind    text not null,             -- news_batch | news_one | test
  title   text not null default '',
  body    text not null default '',
  n       int not null default 1,     -- كم خبر في الدفعة
  sent    int not null default 0,     -- كم جهاز وصله
  failed  int not null default 0,
  at      timestamptz not null default now()
);
alter table public.push_log enable row level security;

create or replace function public.push_token_save(p_token text, p_app text default 'nobleweb', p_platform text default 'android')
returns void language plpgsql security definer set search_path = public as $$
begin
  if auth.uid() is null or length(coalesce(p_token, '')) < 20 then return; end if;
  insert into push_tokens (token, user_id, app, platform, updated_at)
  values (left(p_token, 400), auth.uid(), left(coalesce(p_app, 'nobleweb'), 20), left(coalesce(p_platform, 'android'), 20), now())
  on conflict (token) do update set user_id = auth.uid(), app = excluded.app, platform = excluded.platform, updated_at = now();
end $$;

create or replace function public.push_token_drop(p_token text)
returns void language plpgsql security definer set search_path = public as $$
begin
  delete from push_tokens where token = p_token and (user_id = auth.uid() or auth.uid() is null);
end $$;

-- للوحة: كم جهاز مسجّل + آخر الإشعارات
create or replace function public.admin_push_stats()
returns json language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  return json_build_object(
    'devices', (select count(*) from push_tokens),
    'users', (select count(distinct user_id) from push_tokens),
    'today', (select count(*) from push_log where kind = 'news_batch' and at > date_trunc('day', now() at time zone 'Asia/Riyadh') at time zone 'Asia/Riyadh'),
    'log', coalesce((select json_agg(row_to_json(l) order by l.id desc) from (select * from push_log order by id desc limit 15) l), '[]'::json));
end $$;

revoke all on function public.push_token_save(text, text, text) from public, anon;
revoke all on function public.push_token_drop(text) from public, anon;
revoke all on function public.admin_push_stats() from public, anon;
grant execute on function public.push_token_save(text, text, text) to authenticated;
grant execute on function public.push_token_drop(text) to authenticated;
grant execute on function public.admin_push_stats() to authenticated;
-- NOBLE 1.21.10 — المصدر الواحد يقدر يغذّي أكثر من مجال (تختار كذا مجال، وGemini يحط كل خبر في الأنسب منها)
-- الصق هذا مرة وحدة في Supabase ← SQL Editor ← Run
alter table public.news_sources add column if not exists cats text[] not null default '{}';

create or replace function public.admin_news_source_save(p_src jsonb)
returns bigint language plpgsql security definer set search_path = public as $$
declare sid bigint; t text := case when p_src->>'tier' in ('official', 'secondary', 'video') then p_src->>'tier' else '' end;
  cs text[] := case when jsonb_typeof(p_src->'cats') = 'array' then (select coalesce(array_agg(left(x, 20)), '{}') from (select jsonb_array_elements_text(p_src->'cats') x limit 20) q) else null end;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if (p_src->>'id') is null then
    if coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    insert into news_sources (name, url, cat, cats, topic, country, active, lang, rewrite, tier) values (left(coalesce(nullif(p_src->>'name', ''), 'مصدر'), 60), left(p_src->>'url', 400),
      coalesce(nullif(p_src->>'cat', ''), 'ai'), coalesce(cs, '{}'), left(coalesce(p_src->>'topic', ''), 40), left(coalesce(p_src->>'country', ''), 8), coalesce((p_src->>'active')::boolean, true),
      case when p_src->>'lang' = 'ar' then 'ar' else 'en' end, coalesce((p_src->>'rewrite')::boolean, false), t)
    on conflict (url) do update set name = excluded.name, cat = excluded.cat, cats = excluded.cats, topic = excluded.topic, country = excluded.country, active = excluded.active,
      lang = excluded.lang, rewrite = excluded.rewrite, tier = excluded.tier
    returning id into sid;
  else
    sid := (p_src->>'id')::bigint;
    if p_src ? 'url' and coalesce(p_src->>'url', '') !~ '^https?://' then raise exception 'invalid url'; end if;
    update news_sources set name = left(coalesce(nullif(p_src->>'name', ''), name), 60), url = left(coalesce(p_src->>'url', url), 400),
      cat = coalesce(nullif(p_src->>'cat', ''), cat), cats = coalesce(cs, cats), topic = left(coalesce(p_src->>'topic', topic), 40),
      country = left(coalesce(p_src->>'country', country), 8), active = coalesce((p_src->>'active')::boolean, active),
      lang = case when p_src ? 'lang' then (case when p_src->>'lang' = 'ar' then 'ar' else 'en' end) else lang end,
      rewrite = coalesce((p_src->>'rewrite')::boolean, rewrite),
      tier = case when p_src ? 'tier' then t else tier end where id = sid;
  end if;
  return sid;
end $$;
revoke all on function public.admin_news_source_save(jsonb) from anon, public;
grant execute on function public.admin_news_source_save(jsonb) to authenticated;
-- NOBLE 1.21.13 — ⏰ جدولة نشر أعداد «عاجل»: تجهّز العدد وتختار الوقت، وينتشر لحاله (كل ٥ دقايق نشيّك) + إشعار اختياري
-- الصق هذا مرة وحدة في Supabase ← SQL Editor ← Run  (يحتاج pg_cron و pg_net مفعّلين — نفس اللي يستخدمها سحب الأخبار)
alter table public.ai_issues add column if not exists publish_at timestamptz;
alter table public.ai_issues add column if not exists sched jsonb not null default '{}'::jsonb;  -- {pin, discover, notify}
create index if not exists ai_issues_due on public.ai_issues (publish_at) where status = 'draft' and publish_at is not null;

create table if not exists public.ai_sched_cfg (id int primary key default 1 check (id = 1), push_url text not null default '', anon text not null default '', updated_at timestamptz not null default now());
alter table public.ai_sched_cfg enable row level security;  -- ما أحد يقراه إلا الدوال

-- النشر نفسه (بدون فحص الصلاحية — تناديه الدوال اللي تفحص)
create or replace function public._ai_publish(p_id bigint, p_pin_days int, p_discover boolean)
returns void language plpgsql security definer set search_path = public as $$
declare i ai_issues; fid bigint;
begin
  select * into i from ai_issues where id = p_id; if i.id is null then return; end if;
  update ai_issues set status = 'published', published_at = now(), updated_at = now(), publish_at = null,
    pinned_until = case when p_pin_days is null then pinned_until when p_pin_days <= 0 then null else now() + make_interval(days => p_pin_days) end
  where id = p_id;
  if coalesce(p_discover, true) then
    if i.feed_id is not null and exists(select 1 from feed_items where id = i.feed_id) then
      update feed_items set active = true, data = data || jsonb_build_object('caption', i.title, 'media', jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image'))), updated_at = now() where id = i.feed_id;
    else
      insert into feed_items (kind, data) values ('post', jsonb_build_object('type', 'ai_issue', 'issue', i.id, 'caption', i.title,
        'media', case when i.cover_url <> '' then jsonb_build_array(jsonb_build_object('url', i.cover_url, 'kind', 'image')) else '[]'::jsonb end))
      returning id into fid;
      update ai_issues set feed_id = fid where id = p_id;
    end if;
  end if;
end $$;
revoke all on function public._ai_publish(bigint, int, boolean) from public, anon, authenticated;

-- جدولة / إلغاء (p_at = null يلغي)
create or replace function public.admin_ai_schedule_pub(p_id bigint, p_at timestamptz, p_pin int, p_discover boolean, p_notify boolean, p_push_url text, p_anon text)
returns json language plpgsql security definer set search_path = public, extensions as $$
declare sec text; cmd text;
begin
  if not public.has_perm('news.manage') then raise exception 'not allowed'; end if;
  if p_at is not null and p_at < now() - interval '2 minutes' then raise exception 'الوقت اللي اخترته راح — اختر وقت جاي'; end if;
  update ai_issues set publish_at = p_at, sched = jsonb_build_object('pin', p_pin, 'discover', coalesce(p_discover, true), 'notify', coalesce(p_notify, true)), updated_at = now()
    where id = p_id and status = 'draft';
  if not found then raise exception 'العدد منشور أو مو موجود'; end if;
  if p_at is not null then
    if coalesce(p_push_url, '') ~ '^https://' then
      insert into ai_sched_cfg (id, push_url, anon) values (1, p_push_url, coalesce(p_anon, '')) on conflict (id) do update set push_url = excluded.push_url, anon = excluded.anon, updated_at = now();
    end if;
    -- المهمة المتكررة (مرة وحدة تكفي): كل ٥ دقايق
    begin
      perform 1 from cron.job where jobname = 'noble-ai-pub';
      if not found then perform cron.schedule('noble-ai-pub', '*/5 * * * *', 'select public.ai_publish_due()'); end if;
    exception when others then raise exception 'pg_cron: فعّل الإضافتين pg_cron و pg_net من Database ← Extensions ثم أعد المحاولة'; end;
  end if;
  return (select row_to_json(x) from (select id, status, publish_at, sched from ai_issues where id = p_id) x);
end $$;
revoke all on function public.admin_ai_schedule_pub(bigint, timestamptz, int, boolean, boolean, text, text) from public, anon;
grant execute on function public.admin_ai_schedule_pub(bigint, timestamptz, int, boolean, boolean, text, text) to authenticated;

-- اللي يشغّله الـcron: ينشر اللي جا وقته، ويطلب إشعار لو مفعّل
create or replace function public.ai_publish_due()
returns int language plpgsql security definer set search_path = public, extensions as $$
declare r record; n int := 0; c ai_sched_cfg; sec text;
begin
  select * into c from ai_sched_cfg where id = 1; select cron_secret into sec from news_secret where id = 1;
  for r in select id, sched from ai_issues where status = 'draft' and publish_at is not null and publish_at <= now() order by publish_at limit 10 loop
    perform public._ai_publish(r.id, nullif(r.sched->>'pin', '')::int, coalesce((r.sched->>'discover')::boolean, true));
    n := n + 1;
    if coalesce((r.sched->>'notify')::boolean, true) and c.push_url <> '' then
      begin
        perform net.http_post(url := c.push_url, headers := json_build_object('Content-Type', 'application/json', 'Authorization', 'Bearer ' || c.anon, 'x-news-secret', coalesce(sec, ''))::jsonb,
          body := json_build_object('kind', 'issue', 'id', r.id)::jsonb, timeout_milliseconds := 30000);
      exception when others then null; end;
    end if;
  end loop;
  return n;
end $$;
revoke all on function public.ai_publish_due() from public, anon, authenticated;

-- لو نشرته بيدك قبل الموعد: نلغي الجدولة تلقائياً
create or replace function public._ai_unsched() returns trigger language plpgsql as $$
begin if new.status = 'published' then new.publish_at := null; end if; return new; end $$;
drop trigger if exists ai_issues_unsched on public.ai_issues;
create trigger ai_issues_unsched before update on public.ai_issues for each row execute function public._ai_unsched();
