// NOBLE — سحب الأخبار حسب المجالات والدول (Supabase Edge Function: news-fetch)
// يسحب من مصادر RSS، يترجم ويلخّص بالعربي عبر Gemini، ويحفظها مسودات تنتظر موافقتك (أو ينشرها لو فعّلت النشر التلقائي).
// يُشغَّل: من لوحة التحكم (زر «اسحب الآن») أو تلقائياً كل X ساعات عبر pg_cron.
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-news-secret',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
};
// المجالات الافتراضية (تُستبدل بما تحدده الإدارة في news_settings.data.domains)
type Domain = { id: string; name: string; on?: boolean; subs: [string, string][] };
const DOMAINS: Domain[] = [
  { id: 'news', name: 'أخبار عامة', subs: [['saudi', 'السعودية'], ['gulf', 'الخليج'], ['arab', 'العالم العربي'], ['world', 'العالم']] },
  { id: 'ai', name: 'الذكاء الاصطناعي', subs: [['tools', 'أدوات AI'], ['companies', 'شركات AI'], ['media', 'صور وفيديو'], ['design', 'تصميم بالذكاء'], ['learn', 'تعلّم']] },
  { id: 'tech', name: 'تقنية', subs: [['phones', 'جوالات وأجهزة'], ['apps', 'تطبيقات'], ['games', 'ألعاب فيديو'], ['security', 'أمن سيبراني'], ['dev', 'برمجة']] },
  { id: 'design', name: 'تصميم وإبداع', subs: [['type', 'خطوط وطباعة'], ['brand', 'هويات بصرية'], ['photo', 'تصوير'], ['motion', 'موشن'], ['ux', 'UI/UX']] },
  { id: 'biz', name: 'أعمال واقتصاد', subs: [['local', 'السوق المحلي'], ['startups', 'شركات ناشئة'], ['marketing', 'تسويق'], ['stocks', 'أسهم'], ['crypto', 'عملات رقمية']] },
  { id: 'sports', name: 'رياضة', subs: [['league', 'الدوري المحلي'], ['world', 'كرة عالمية'], ['f1', 'فورمولا 1'], ['combat', 'رياضات قتالية'], ['esports', 'رياضات إلكترونية']] },
  { id: 'science', name: 'علوم وفضاء', subs: [['space', 'فضاء'], ['invent', 'اختراعات'], ['climate', 'بيئة ومناخ']] },
  { id: 'health', name: 'صحة ولياقة', subs: [['fitness', 'لياقة'], ['food', 'تغذية'], ['wellness', 'نوم وعافية']] },
  { id: 'ent', name: 'ترفيه', subs: [['film', 'أفلام ومسلسلات'], ['events', 'فعاليات ومواسم'], ['celebs', 'مشاهير'], ['anime', 'أنمي']] },
  { id: 'cars', name: 'سيارات', subs: [['ev', 'كهربائية'], ['launches', 'إطلاقات جديدة'], ['racing', 'سباقات']] },
  { id: 'edu', name: 'تعليم ومهارات', subs: [['grants', 'منح وفرص'], ['courses', 'كورسات'], ['langs', 'لغات']] },
];
const domainsOf = (data: Record<string, unknown>) => {
  const l = Array.isArray(data?.domains) && (data.domains as Domain[]).length ? (data.domains as Domain[]) : DOMAINS;
  return l.filter((d) => d && d.id).map((d) => ({ id: String(d.id), name: String(d.name || d.id), on: d.on !== false, subs: (Array.isArray(d.subs) ? d.subs : []).filter((x) => Array.isArray(x) && x[0]) }));
};
/* تصنيف Gemini ← مجال واهتمام صالحين */
function classify(r: Record<string, unknown> | null, doms: Domain[], srcCat: string, srcTopic: string, srcCats: string[] = []) {
  // 1.21.10: المصدر له أكثر من مجال → Gemini يختار منها (و«*» = أي مجال)
  const multi = srcCats.length > 1 && !srcCats.includes('*');
  if (multi && r && !srcCats.includes(String(r.cat))) r = { ...r, cat: srcCat };
  const cat = doms.some((d) => d.id === r?.cat) ? String(r?.cat) : (doms.some((d) => d.id === srcCat) ? srcCat : doms[0]?.id || 'ai');
  const d = doms.find((x) => x.id === cat);
  const topic = (d?.subs || []).some((x) => x[0] === r?.topic) ? String(r?.topic) : (cat === srcCat ? srcTopic || '' : '');
  return { cat, topic };
}
/* ---------- 1.19: 🎯 فلتر المواضيع وأولويات المجالات (من لوحة التحكم ← الأخبار ← الفلتر) ---------- */
const BLOCK: Record<string, string[]> = {
  politics: ['سياس', 'رئيس الوزراء', 'رئيس الجمهورية', 'وزير الخارجية', 'وزير الدفاع', 'البرلمان', 'انتخاب', 'الكونغرس', 'مجلس الأمن', 'الأمم المتحدة', 'دبلوماس', 'عقوبات', 'الحزب', 'ترامب', 'بايدن', 'نتنياهو', 'بوتين', 'زيلينسكي', 'البيت الأبيض', 'الكرملين',
    'politic', 'election', 'parliament', 'senate', 'congress', 'white house', 'kremlin', 'prime minister', 'diplomat', 'sanction', 'trump', 'biden', 'putin', 'netanyahu', 'zelensky', 'republican', 'democrat'],
  war: ['حرب', 'الحرب', 'غارة', 'غارات', 'قصف', 'اشتباك', 'قتلى', 'جرحى', 'الجيش', 'عسكري', 'هجوم مسلح', 'الاحتلال', 'مسلح', 'هدنة', 'نزاع', 'غزة', 'أوكرانيا', 'صواريخ باليستية',
    'war ', 'wartime', 'airstrike', 'missile strike', 'troops', 'military', 'ceasefire', 'invasion', 'gaza', 'ukraine war', 'hamas', 'hezbollah'],
  crime: ['جريمة', 'جرائم', 'قتل', 'مقتل', 'اعتقال', 'القبض على', 'سرقة', 'سجن', 'إعدام', 'تحقيق جنائي', 'murder', 'arrested', 'shooting', 'stabbing', 'robbery', 'homicide', 'prison'],
  celeb: ['فضيحة', 'طلاق', 'مشاهير', 'النجمة', 'الفنانة', 'scandal', 'divorce', 'celebrity', 'gossip'],
  disaster: ['زلزال', 'فيضان', 'كارثة', 'حادث مروري', 'earthquake', 'flood', 'disaster', 'crash kills'],
};
const BLOCK_AR: Record<string, string> = { politics: 'السياسة', war: 'الحروب والنزاعات العسكرية', crime: 'الجرائم والحوادث الأمنية', celeb: 'أخبار المشاهير والفضائح', disaster: 'الكوارث والحوادث' };
type Filter = { block: string[]; words: string[]; weights: Record<string, number>; featured: boolean };
function filterOf(S: Record<string, any>, doms: Domain[]): Filter {
  const f = S.filter || {};
  const block = Array.isArray(f.block) ? f.block.filter((x: string) => BLOCK[x]) : ['politics', 'war', 'crime', 'celeb'];
  const words = String(f.words || '').split(/[\n،,]+/).map((x) => x.trim().toLowerCase()).filter((x) => x.length > 1).slice(0, 200);
  const def: Record<string, number> = { ai: 3, tech: 3, news: 0 };
  const weights: Record<string, number> = {};
  for (const d of doms) { const v = f.weights?.[d.id]; weights[d.id] = Math.max(0, Math.min(3, Number.isFinite(+v) ? +v : (def[d.id] ?? 1))); }
  return { block, words, weights, featured: f.featured !== false };
}
const norm = (t: string) => (' ' + String(t || '') + ' ').toLowerCase().replace(/[إأآ]/g, 'ا').replace(/الرئيس التنفيذي|chief executive|vice president|president of product/g, ' ');
function blockedBy(F: Filter, title: string, text = ''): string {
  const t = norm(title + ' ' + String(text).slice(0, 400));
  for (const k of F.block) for (const w of BLOCK[k]) if (t.includes(norm(w).trim())) return k;
  for (const w of F.words) if (t.includes(w.replace(/[إأآ]/g, 'ا'))) return 'words';
  return '';
}
/* اختيار بحسب الأولوية: كل مجال ياخذ حصة على قد وزنه (٣ = كثير · ٠ = لا) */
function pickWeighted<T extends { src: { cat: string }; date?: Date | null }>(pool: T[], n: number, F: Filter): T[] {
  const by: Record<string, T[]> = {};
  for (const x of pool) { const w = F.weights[x.src.cat] ?? 1; if (w <= 0) continue; (by[x.src.cat] = by[x.src.cat] || []).push(x); }
  const cats = Object.keys(by).sort((a, b) => (F.weights[b] ?? 1) - (F.weights[a] ?? 1));
  const out: T[] = [], credit: Record<string, number> = {};
  while (out.length < n && cats.some((c) => by[c].length)) {
    const live = cats.filter((k) => by[k].length); let tot = 0;
    for (const c of live) { credit[c] = (credit[c] || 0) + (F.weights[c] ?? 1); tot += F.weights[c] ?? 1; }
    const c = live.sort((a, b) => credit[b] - credit[a])[0];
    out.push(by[c].shift()!); credit[c] -= tot; // توزيع عادل بحسب الوزن
  }
  return out;
}
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { ...CORS, 'Content-Type': 'application/json' } });

/* ---------- قراءة RSS / Atom ---------- */
const ENT: Record<string, string> = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ' };
function decode(s = '') {
  return s.replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
    .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
    .replace(/&([a-z]+);/gi, (m, n) => ENT[n.toLowerCase()] ?? m);
}
const stripHtml = (s = '') => decode(decode(s)).replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
function tag(block: string, names: string[]) {
  for (const n of names) {
    const m = block.match(new RegExp(`<${n}(?:\\s[^>]*)?>([\\s\\S]*?)</${n}>`, 'i'));
    if (m && m[1].trim()) return m[1].trim();
  }
  return '';
}
function attr(block: string, tagName: string, a: string, filter?: RegExp) {
  const re = new RegExp(`<${tagName}\\b[^>]*>`, 'gi');
  for (const m of block.match(re) || []) {
    if (filter && !filter.test(m)) continue;
    const v = m.match(new RegExp(`${a}\\s*=\\s*["']([^"']+)["']`, 'i'));
    if (v) return decode(v[1]);
  }
  return '';
}
type Item = { guid: string; url: string; title: string; text: string; image: string; date: Date | null };
function parseFeed(xml: string): Item[] {
  const blocks = xml.match(/<item\b[\s\S]*?<\/item>/gi) || xml.match(/<entry\b[\s\S]*?<\/entry>/gi) || [];
  return blocks.map((b) => {
    const title = stripHtml(tag(b, ['title']));
    let url = stripHtml(tag(b, ['link']));
    if (!/^https?:/.test(url)) url = attr(b, 'link', 'href', /rel=["']alternate["']/) || attr(b, 'link', 'href');
    const guid = stripHtml(tag(b, ['guid', 'id'])) || url;
    const raw = tag(b, ['content:encoded', 'description', 'summary', 'content', 'media:description']);
    const image = attr(b, 'media:content', 'url', /image|\.(jpe?g|png|webp)/i) || attr(b, 'media:thumbnail', 'url')
      || attr(b, 'enclosure', 'url', /image/i) || (decode(raw).match(/<img[^>]+src=["']([^"']+)["']/i)?.[1] ?? '');
    const d = tag(b, ['pubDate', 'published', 'updated', 'dc:date']);
    const date = d ? new Date(stripHtml(d)) : null;
    return { guid: guid.slice(0, 500), url, title, text: stripHtml(raw).slice(0, 2500), image, date: date && !isNaN(+date) ? date : null };
  }).filter((x) => x.title && /^https?:/.test(x.url));
}
// 1.21.29: هيدرز متصفح عادي (مواقع كثير تحجب «البوت») + محاولة ثانية لو الموقع مشغول (429/5xx) أو بطيء
const UA = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Mobile Safari/537.36 NOBLE-News/1.0';
async function get1(url: string, ms: number, max: number) {
  const ac = new AbortController();
  const t = setTimeout(() => ac.abort(), ms);
  try {
    const r = await fetch(url, { signal: ac.signal, redirect: 'follow', headers: { 'User-Agent': UA, 'Accept-Language': 'ar,en;q=0.8', Accept: 'application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.9, text/html;q=0.8, */*;q=0.5' } });
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const txt = await r.text();
    return txt.slice(0, max);
  } catch (e) {
    if ((e as Error).name === 'AbortError') throw new Error('TIMEOUT');
    throw e;
  } finally { clearTimeout(t); }
}
async function get(url: string, ms = 10000, max = 2_000_000) {
  try { return await get1(url, ms, max); }
  catch (e) {
    const m = String((e as Error).message || e);
    if (!/HTTP (429|5\d\d)|TIMEOUT/.test(m) || (DEADLINE && Date.now() > DEADLINE - 15000)) throw e;
    await sleep(1500);
    return await get1(url, ms, max);
  }
}
/* 1.21.29 — 🧪 اختبار مصدر + البحث عن رابط RSS بنفسه (من رابط الموقع العادي أو قناة يوتيوب) */
async function probe(url0: string) {
  let url = url0.trim();
  if (/youtube\.com\/(@|channel\/|c\/|user\/)/i.test(url) && !/feeds\/videos\.xml/.test(url)) {
    const f = await ytFeed(url); if (!f) throw new Error('YT_ID'); url = f;
  }
  const tryFeed = async (u: string) => { const txt = await get(u, 9000); const items = parseFeed(txt); return { txt, items }; };
  let first: { txt: string; items: Item[] } | null = null, err: unknown = null;
  try { first = await tryFeed(url); if (first.items.length) return { url, items: first.items }; } catch (e) { err = e; }
  const cands: string[] = [];
  if (first?.txt) {
    for (const m of first.txt.matchAll(/<link[^>]+type=["']application\/(?:rss|atom)\+xml["'][^>]*>/gi)) {
      const href = m[0].match(/href=["']([^"']+)["']/i)?.[1]; if (href) { try { cands.push(new URL(decode(href), url).href); } catch { /* لا شيء */ } }
    }
  }
  try { const o = new URL(url).origin; ['/feed', '/rss', '/feed/', '/rss.xml', '/feed.xml', '/atom.xml', '/index.xml', '/feeds/posts/default'].forEach((p) => cands.push(o + p)); } catch { /* لا شيء */ }
  for (const u of [...new Set(cands)].slice(0, 9)) {
    if (DEADLINE && Date.now() > DEADLINE) break;
    try { const r = await tryFeed(u); if (r.items.length) return { url: u, items: r.items, found: true }; } catch { /* نكمل */ }
  }
  if (err) throw err;
  throw new Error('NO_FEED');
}
async function ogImage(url: string) {
  try {
    const html = await get(url, 6000, 300_000);
    return decode(html.match(/<meta[^>]+property=["']og:image["'][^>]+content=["']([^"']+)["']/i)?.[1]
      || html.match(/<meta[^>]+content=["']([^"']+)["'][^>]+property=["']og:image["']/i)?.[1] || '');
  } catch { return ''; }
}

/* ---------- Gemini ---------- */
// موديلات احتياطية: إذا كان الموديل مزدحماً أو غير متاح نجرب اللي بعده تلقائياً
const FALLBACK = ['gemini-flash-latest', 'gemini-flash-lite-latest', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'];
const BUSY = /high demand|overloaded|unavailable|503|500|internal|try again|not found|404|not supported|deprecated/i;
/* المصادر العربية اللي تنزل مباشرة بدون Gemini */
// deno-lint-ignore no-explicit-any
async function directIds(db: any): Promise<number[]> {
  const { data } = await db.from('news_sources').select('id').eq('lang', 'ar').eq('rewrite', false);
  return (data || []).map((r: { id: number }) => r.id);
}
const isDirect = (s: { lang?: string; rewrite?: boolean }) => s?.lang === 'ar' && !s?.rewrite;
let DEADLINE = 0; // وقت التوقف للطلب الحالي (حد Supabase ١٥٠ ثانية)
async function gemini(key: string, model: string, prompt: string) {
  const list = [...new Set([model, ...FALLBACK].filter(Boolean))];
  let last: unknown = null, quotaHit = false;
  for (const m of list) {
    for (let t = 0; t < 2; t++) {
      if (DEADLINE && Date.now() > DEADLINE) throw last || new Error('timeout');
      try { return await geminiOnce(key, m, prompt); }
      catch (e) {
        last = e;
        const msg = String((e as Error).message || e);
        if (/api key|permission|401|403/i.test(msg) && !/quota/i.test(msg)) throw e; // مشكلة في المفتاح — لا فائدة من التكرار
        if (/quota|rate|429|exhausted/i.test(msg)) { quotaHit = true; break; } // 1.21.1: حد هالموديل خلص — كل موديل له حد مجاني لحاله، نجرب اللي بعده
        if (!BUSY.test(msg)) break;
        await sleep(1200 * (t + 1));
      }
    }
  }
  if (quotaHit) throw new Error(QUOTA_MSG);
  throw last;
}
const QUOTA_MSG = 'QUOTA: وصلت حد Gemini المجاني — جرّب بعد دقيقة، ولو تكرر جرّب بكرة (الحد اليومي يتصفّر). سحب الأخبار التلقائي يستهلك من نفس الحد.';
const arErr = (e: unknown) => { const m = String((e as Error)?.message || e); return /quota|rate|429|exhausted/i.test(m) ? QUOTA_MSG : m; };
async function geminiOnce(key: string, model: string, prompt: string) {
  const ac = new AbortController();
  const tm = setTimeout(() => ac.abort(), 25_000); // لا ننتظر Gemini أكثر من ٢٥ ثانية
  const r = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
    method: 'POST', signal: ac.signal,
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }], generationConfig: { responseMimeType: 'application/json', temperature: 0.4 } }),
  });
  const d = await r.json().catch(() => ({})).finally(() => clearTimeout(tm));
  if (!r.ok) throw new Error(d?.error?.message || 'Gemini HTTP ' + r.status);
  const txt = d?.candidates?.[0]?.content?.parts?.map((p: { text?: string }) => p.text || '').join('') || '';
  return JSON.parse(txt.replace(/^```json\s*|```$/g, ''));
}
function promptFor(it: { title: string; text: string; src: string }, tone: string, doms: Domain[] = DOMAINS, srcCat = 'ai', F: Filter | null = null, srcCats: string[] = []) {
  const main = doms.find((d) => d.id === srcCat) || doms[0];
  const anyD = srcCats.includes('*'), many = srcCats.filter((c) => c !== '*' && doms.some((d) => d.id === c));
  const scope = anyD ? 'أي مجال (اختر الأنسب للخبر)' : many.length > 1 ? many.map((c) => doms.find((d) => d.id === c)?.name).join('، ') : (main?.name || '');
  const list = doms.filter((d) => d.on !== false).map((d) => `${d.id} (${d.name}): ${d.subs.map((x) => `${x[0]}=${x[1]}`).join('، ') || '—'}`).join('\n');
  return `أنت محرر أخبار عربي. هذا خبر من مصدر «${it.src}» وهو مصدر مخصص لمجال «${scope}».
العنوان الأصلي: ${it.title}
النص المتاح من المصدر: ${it.text || '(لا يوجد — اعتمد على العنوان فقط)'}

المطلوب: أعد JSON فقط بهذه الحقول:
{"relevant": true/false, "featured": true/false, "title": "", "summary": "", "body": "", "why": "", "cat": "", "topic": ""}
- relevant: false إذا كان إعلاناً تجارياً أو محتوى غير إخباري أو لا يناسب أي مجال من القائمة${srcCat === 'ai' && !anyD && many.length <= 1 ? '، أو لم يكن عن الذكاء الاصطناعي أو أدواته أو شركاته أو تطبيقاته' : ''}.
${F && F.block.length ? `- relevant: false كذلك إذا كان الخبر عن: ${F.block.map((k) => BLOCK_AR[k]).join('، ')} — حتى لو جاء من مصدر تقني.\n` : ''}${F ? `- featured: true فقط إذا كان الخبر مهم أو مفيد بشكل استثنائي للقارئ (إطلاق كبير، أداة جديدة مفيدة، اكتشاف علمي، تغيير يمس المستخدمين) — غير ذلك false.\n` : ''}- title: عنوان عربي واضح وجذاب بدون مبالغة (أقل من ١٢ كلمة).
- summary: ملخص من جملة أو جملتين (أقل من ٤٠ كلمة).
- body: شرح من فقرتين قصيرتين (٨٠ إلى ١٦٠ كلمة) — افصل الفقرتين بسطر فارغ.
- why: جملة واحدة تبدأ بـ «لو» أو «إذا» توضّح ليش يهم الخبر للقارئ.
- cat: ${anyD ? 'رمز المجال الأنسب للخبر من القائمة' : many.length > 1 ? `رمز المجال الأنسب من هذي فقط: ${many.join('، ')} (الافتراضي «${main?.id || ''}»)` : `رمز المجال الأنسب (الافتراضي «${main?.id || ''}» إلا لو الخبر واضح إنه من مجال ثاني)`}.
- topic: رمز الاهتمام الأنسب داخل المجال، أو فارغ إذا ما فيه واحد مناسب.
المجالات المتاحة (الرمز (الاسم): رمز=اهتمام):
${list}
قواعد مهمة:
- اكتب بالعربية الفصحى المبسطة (إذا كان المصدر عربياً أعد الصياغة والتلخيص بدون نسخ حرفي)، والمصطلحات التقنية وأسماء الشركات والمنتجات الأجنبية تبقى كما هي بالإنجليزي.
- لا تضف أي معلومة أو رقم غير موجود في النص المتاح. إذا كان النص قليلاً فاكتب أقل.
${tone ? '- أسلوب إضافي من الإدارة: ' + tone : ''}`;
}


/* ---------- يوتيوب ---------- */
async function ytFeed(url: string) {
  const direct = url.match(/channel\/(UC[\w-]{22})/)?.[1];
  if (direct) return `https://www.youtube.com/feeds/videos.xml?channel_id=${direct}`;
  try {
    const html = await get(url, 9000, 1_500_000);
    const id = html.match(/"channelId":"(UC[\w-]{22})"/)?.[1] || html.match(/<link rel="canonical" href="https:\/\/www\.youtube\.com\/channel\/(UC[\w-]{22})"/)?.[1]
      || html.match(/"externalId":"(UC[\w-]{22})"/)?.[1] || html.match(/channel_id=(UC[\w-]{22})/)?.[1];
    return id ? `https://www.youtube.com/feeds/videos.xml?channel_id=${id}` : '';
  } catch { return ''; }
}

/* ---------- «⚡ NOBLE عاجل»: تجهيز العدد ---------- */
function isoWeek(d = new Date()) {
  const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate()));
  const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day);
  const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1));
  return Math.ceil(((+t - +y0) / 864e5 + 1) / 7);
}
const PERIOD: Record<string, { days: number; count: number; title: string; kicker: string; in: string; word: string }> = {
  daily: { days: 1.2, count: 4, title: 'ملخص اليوم في الذكاء الاصطناعي', kicker: 'ملخص اليوم', in: 'اليوم', word: 'اليوم' },
  weekly: { days: 7, count: 6, title: 'ملخص أسبوع الذكاء الاصطناعي', kicker: 'ملخص الأسبوع', in: 'هالأسبوع', word: 'الأسبوع' },
  monthly: { days: 31, count: 8, title: 'ملخص شهر الذكاء الاصطناعي', kicker: 'ملخص الشهر', in: 'هالشهر', word: 'الشهر' },
  urgent: { days: 3, count: 3, title: 'خبر عاجل في الذكاء الاصطناعي', kicker: '⚡ عاجل', in: 'مؤخراً', word: 'الأيام الأخيرة' },
};
const arMonth = (d = new Date()) => new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { month: 'long', year: 'numeric', timeZone: 'Asia/Riyadh' }).format(d);
const arDate = (d = new Date()) => new Intl.DateTimeFormat('ar-SA-u-ca-gregory', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'Asia/Riyadh' }).format(d);
type Cand = { id: number; title: string; summary: string; src_name: string; url: string; image: string; tier: string; src_title: string; published_at: string | null; created_at: string };
function issuePrompt(list: Cand[], vids: Cand[], n: number, pick: boolean, tone: string, period = 'الأسبوع') {
  const fmt = (x: Cand) => `#${x.id} [${x.tier === 'official' ? 'رسمي' : x.tier === 'video' ? 'فيديو' : x.tier === 'secondary' ? 'ثانوي' : 'عادي'}] (${x.src_name}) ${x.title || x.src_title} — ${(x.summary || '').slice(0, 160)}`;
  return `أنت محرر «NOBLE عاجل»: ملخص سريع لأهم أخبار الذكاء الاصطناعي بأسلوب هادئ وواضح، يُنشر كسلايدات (كاروسيل إنستقرام).
هذا عدد «ملخص ${period}».
${pick ? `اختر أهم ${n} أخبار مختلفة (لا تكرر نفس الخبر من مصدرين) من القائمة. فضّل الأخبار الرسمية [رسمي] والإطلاقات الجديدة للمنتجات والنماذج والأدوات، وتجاهل المقالات الرأيية والتحليلات العامة.` : 'اكتب سلايد لكل خبر من القائمة بنفس الترتيب.'}
الأخبار:
${list.map(fmt).join('\n')}
${vids.length ? `\nفيديوهات رسمية حديثة (اربط الفيديو بالخبر إذا كان عن نفس الإطلاق فقط):\n${vids.map(fmt).join('\n')}` : ''}

أعد JSON فقط: {"slides": [{"id": رقم الخبر, "video": رقم الفيديو أو 0, "company": "", "head": "", "body": ""}]}
- company: اسم الشركة أو المنتج الأساسي بالإنجليزي كما يُكتب رسمياً (مثل OpenAI أو Google أو NVIDIA).
- head: عنوان عربي قصير وواضح (٤ إلى ٩ كلمات) بدون مبالغة.
- body: ٢٥ إلى ٤٠ كلمة بالعربية الفصحى المبسطة: وش الجديد، ولمين، ومتى يتوفر إذا كان مذكوراً. أسماء المنتجات والنماذج تبقى بالإنجليزي.
- لا تضف أي رقم أو معلومة غير موجودة في النص المتاح.
${tone ? '- أسلوب إضافي من الإدارة: ' + tone : ''}`;
}
// deno-lint-ignore no-explicit-any
async function keepImage(db: any, url: string) {
  // صورة الخبر ← تخزيننا (عشان المعاينة والتصدير يشتغلون بدون مشاكل CORS)
  if (!/^https?:/.test(url || '')) return '';
  try {
    const ac = new AbortController(); const t = setTimeout(() => ac.abort(), 8000);
    const r = await fetch(url, { signal: ac.signal, headers: { 'User-Agent': 'Mozilla/5.0 (NOBLE)' } }).finally(() => clearTimeout(t));
    const type = r.headers.get('content-type') || '';
    if (!r.ok || !/^image\/(jpe?g|png|webp)/.test(type)) return '';
    const buf = new Uint8Array(await r.arrayBuffer());
    if (buf.byteLength > 4_000_000) return '';
    const ext = type.includes('png') ? 'png' : type.includes('webp') ? 'webp' : 'jpg';
    const path = `ai/n/${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}.${ext}`;
    const up = await db.storage.from('designs').upload(path, buf, { contentType: type, cacheControl: '31536000', upsert: false });
    if (up.error) return '';
    return db.storage.from('designs').getPublicUrl(path).data.publicUrl as string;
  } catch { return ''; }
}

/* ---------- الإضافة السريعة: فهم الجملة ---------- */
function parsePrompt(text: string, today: string, cats: string[], accounts: string[]) {
  return `أنت مساعد تنظيم شخصي في تطبيق سعودي. حوّل جملة المستخدم إلى عناصر.
تاريخ اليوم: ${today || new Date().toISOString().slice(0, 10)} (توقيت السعودية).
تصنيفات المالية المتاحة: ${cats.join('، ') || '—'}
الحسابات المتاحة: ${accounts.join('، ') || '—'}
جملة المستخدم: «${text}»

أعد JSON فقط بالشكل: {"items": [ ... ]} وكل عنصر واحد من:
{"type":"task","title":"","due":"YYYY-MM-DD أو فارغ","time":"HH:MM أو فارغ","remind":"0 أو 15 أو 60 أو 1440 أو فارغ","priority":"high|medium|low|none"}
{"type":"expense","amount":رقم,"category":"اسم من التصنيفات أو فارغ","account":"اسم من الحسابات أو فارغ","date":"YYYY-MM-DD","note":""}
{"type":"income","amount":رقم,"category":"","account":"","date":"YYYY-MM-DD","note":""}
{"type":"site","url":"https://...","name":""}
قواعد:
- «بكرة» = اليوم+1، «بعد بكرة» = اليوم+2، أسماء الأيام = أقرب يوم قادم. الأرقام العربية تُحوَّل لأرقام عادية.
- دفع فاتورة أو مبلغ في المستقبل = مهمة (بتنبيه قبل ساعة إذا فيه وقت، وإلا عند ٩ الصبح) + مصروف بتاريخ نفس اليوم.
- «صرفت/دفعت/اشتريت» بمبلغ في الماضي = مصروف فقط بتاريخ اليوم. «استلمت/جاني/دخل» = دخل.
- «ذكرني» = مهمة بتنبيه. رابط موقع = site.
- العنوان قصير وواضح بالعربي. لا تخترع مبالغ أو تواريخ غير مذكورة.
- إذا ما فهمت شي أعد {"items": []}.`;
}
function cleanItems(a: unknown) {
  const ymd = (v: unknown) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v || '')) ? String(v) : '');
  return (Array.isArray(a) ? a : []).slice(0, 6).map((x: Record<string, unknown>) => {
    const t = String(x?.type || '');
    if (t === 'task') return { type: 'task', title: String(x.title || '').slice(0, 200), due: ymd(x.due), time: /^\d{2}:\d{2}$/.test(String(x.time || '')) ? String(x.time) : '',
      remind: ['0', '5', '15', '30', '60', '1440'].includes(String(x.remind)) ? String(x.remind) : '', priority: ['high', 'medium', 'low'].includes(String(x.priority)) ? String(x.priority) : 'none' };
    if (t === 'expense' || t === 'income') { const amount = Math.abs(Number(x.amount) || 0); return amount > 0 ? { type: t, amount: Math.round(amount * 100) / 100, category: String(x.category || '').slice(0, 40), account: String(x.account || '').slice(0, 40), date: ymd(x.date), note: String(x.note || '').slice(0, 120) } : null; }
    if (t === 'site' && /^https?:\/\//.test(String(x.url || ''))) return { type: 'site', url: String(x.url).slice(0, 500), name: String(x.name || '').slice(0, 80) };
    return null;
  }).filter((x) => x && (x.type !== 'task' || x.title));
}

/* ---------- التشغيل ---------- */
Deno.serve(async (req) => {
  DEADLINE = Date.now() + 105_000;
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  const URL_ = Deno.env.get('SUPABASE_URL')!, SRK = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, ANON = Deno.env.get('SUPABASE_ANON_KEY')!;
  const db = createClient(URL_, SRK, { auth: { persistSession: false } });
  const body = await req.json().catch(() => ({}));
  const action = body?.action || 'fetch';

  const { data: sec } = await db.from('news_secret').select('gemini_key, cron_secret').eq('id', 1).maybeSingle();

  // ---- الإضافة السريعة (لأي مستخدم مسجّل) ----
  if (action === 'parse') {
    const user = createClient(URL_, ANON, { global: { headers: { Authorization: req.headers.get('Authorization') || '' } }, auth: { persistSession: false } });
    const { data: u } = await user.auth.getUser();
    if (!u?.user) return json({ error: 'not allowed' }, 401);
    const { data: st0 } = await db.from('news_settings').select('data').eq('id', 1).maybeSingle();
    const Q = { quickOn: true, quickMax: 40, model: 'gemini-flash-latest', ...(st0?.data || {}) };
    const k = sec?.gemini_key || '';
    if (!k || Q.quickOn === false) return json({ error: 'unavailable' }, 503);
    const text = String(body.text || '').replace(/\s+/g, ' ').trim().slice(0, 400);
    if (text.length < 2) return json({ error: 'empty' }, 400);
    const { data: q, error: qe } = await user.rpc('ai_use', { p_max: Number(Q.quickMax) || 40 });
    if (qe) return json({ error: qe.message }, 500);
    if (!q?.ok) return json({ error: 'limit', used: q?.used, max: q?.max }, 429);
    const list = (a: unknown) => (Array.isArray(a) ? a : []).map((x) => String(x).slice(0, 40)).slice(0, 40);
    try {
      const r = await gemini(k, Q.model, parsePrompt(text, String(body.today || ''), list(body.cats), list(body.accounts)));
      return json({ ok: true, items: cleanItems(r?.items), used: q.used, max: q.max });
    } catch (e) { return json({ error: String((e as Error).message || e).slice(0, 200) }, 502); }
  }

  // الصلاحية: سر المؤقت أو أدمن عنده صلاحية الأخبار
  const viaCron = !!sec?.cron_secret && req.headers.get('x-news-secret') === sec.cron_secret;
  if (!viaCron) {
    const auth = req.headers.get('Authorization') || '';
    const user = createClient(URL_, ANON, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
    const { data: ok } = await user.rpc('has_perm', { p: 'news.manage' });
    if (ok !== true) return json({ error: 'not allowed' }, 403);
  }
  const { data: st } = await db.from('news_settings').select('data').eq('id', 1).maybeSingle();
  const S = { auto: false, perRun: 8, model: 'gemini-flash-latest', maxAgeDays: 3, keepDays: 60, tone: '', ...(st?.data || {}) };
  const key = sec?.gemini_key || '';
  const doms = domainsOf(st?.data || {});
  const F = filterOf(S, doms);

  // 🎯 1.19: تنظيف الأخبار الموجودة بالفلتر الحالي (المثبّت ما ينلمس)
  if (action === 'clean') {
    const since = new Date(Date.now() - 45 * 864e5).toISOString();
    const { data: rows } = await db.from('news_items').select('id, title, src_title, summary, cat').in('status', ['draft', 'published']).eq('pinned', false).gte('created_at', since).limit(1500);
    const ids = (rows || []).filter((r: Record<string, string>) => blockedBy(F, `${r.title} ${r.src_title || ''}`, r.summary || '') || (F.weights[r.cat] ?? 1) <= 0).map((r: { id: number }) => r.id);
    for (let i = 0; i < ids.length; i += 200) await db.from('news_items').update({ status: 'rejected', updated_at: new Date().toISOString() }).in('id', ids.slice(i, i + 200));
    return json({ ok: true, cleaned: ids.length, checked: (rows || []).length });
  }

  if (action === 'probe') {
    DEADLINE = Date.now() + 60_000;
    try {
      const r = await probe(String(body?.url || ''));
      return json({ ok: true, url: r.url, found: !!r.found, count: r.items.length, items: r.items.slice(0, 4).map((x) => ({ title: x.title, date: x.date, image: !!x.image })) });
    } catch (e) { return json({ ok: false, error: String((e as Error).message || e).slice(0, 200) }); }
  }
  if (action === 'test') {
    if (!key) return json({ ok: false, error: 'أضف مفتاح Gemini أولاً' });
    try {
      const r = await gemini(key, S.model, 'أعد JSON فقط: {"ok": true, "msg": "جملة ترحيب قصيرة بالعربي"}');
      return json({ ok: true, msg: r?.msg || 'تم', model: S.model });
    } catch (e) { return json({ ok: false, error: String((e as Error).message || e) }); }
  }

  if (action === 'rewrite') {
    const { data: it } = await db.from('news_items').select('*').eq('id', body.id).maybeSingle();
    if (!it) return json({ error: 'not found' }, 404);
    if (!key) return json({ error: 'أضف مفتاح Gemini أولاً' }, 400);
    try {
      const r = await gemini(key, S.model, promptFor({ title: it.src_title || it.title, text: it.src_text || it.body, src: it.src_name }, S.tone, doms, it.cat, F));
      const patch = { title: String(r.title || it.title).slice(0, 220), summary: String(r.summary || '').slice(0, 600), body: String(r.body || '').slice(0, 6000),
        why: String(r.why || '').slice(0, 600), ...classify(r, doms, it.cat, it.topic), featured: F.featured && r.featured === true, ai: true, updated_at: new Date().toISOString() };
      await db.from('news_items').update(patch).eq('id', it.id);
      return json({ ok: true, item: { ...it, ...patch } });
    } catch (e) { return json({ error: String((e as Error).message || e) }, 500); }
  }


  // ---- «⚡ NOBLE عاجل»: يجهّز عدد (مسودة) من أخبار الذكاء الاصطناعي — أسبوعي، أو عاجل من أخبار تختارها ----
  if (action === 'ai_issue') {
    if (!key) return json({ error: 'أضف مفتاح Gemini أولاً' }, 400);
    const A = { period: 'weekly', min: 3, ...(S.ai || {}) };
    const ids: number[] = Array.isArray(body.ids) ? body.ids.map(Number).filter(Boolean).slice(0, 8) : [];
    const urgent = body.kind === 'urgent';
    // الدورية: يومي · أسبوعي · شهري (تختارها الإدارة) — الأيام وعدد الأخبار الافتراضي حسبها
    const kind = urgent ? 'urgent' : (['daily', 'weekly', 'monthly'].includes(body.period) ? body.period : ['daily', 'weekly', 'monthly'].includes(A.period) ? A.period : 'weekly');
    const P = PERIOD[kind] || PERIOD.weekly;
    const days = Number(A.days) > 0 ? Number(A.days) : P.days;
    const since = new Date(Date.now() - days * 864e5).toISOString();
    const cols = 'id,title,summary,src_name,url,image,tier,src_title,published_at,created_at';
    let list: Cand[] = [];
    if (ids.length) {
      const { data } = await db.from('news_items').select(cols).in('id', ids);
      list = ids.map((i) => (data || []).find((x: Cand) => x.id === i)).filter(Boolean) as Cand[];
    } else {
      const { data } = await db.from('news_items').select(cols).eq('cat', 'ai').neq('status', 'rejected').neq('tier', 'video').gte('created_at', since)
        .order('created_at', { ascending: false }).limit(kind === 'monthly' ? 120 : 60);
      // 1.21.1: نرسل لـ Gemini أهم الأخبار بس (الرسمية ثم الأحدث) — طلب أصغر بكثير ويقل الوصول للحد
      const rank = (x: Cand) => (x.tier === 'official' ? 0 : x.tier === 'secondary' ? 2 : 1);
      list = ((data || []) as Cand[]).sort((a, b) => rank(a) - rank(b)).slice(0, kind === 'monthly' ? 30 : kind === 'weekly' ? 24 : 18);
    }
    if (!list.length) return json({ error: ids.length ? 'ما لقيت الأخبار المختارة' : `ما فيه أخبار ذكاء اصطناعي ${P.in} — اسحب الأخبار أول` }, 400);
    const min = Math.max(1, Number(A.min) || 3);
    if (!ids.length && list.length < min) return json({ ok: false, skipped: true, error: `الأخبار المسترجعة ${P.in} ${list.length} بس — أقل من الحد (${min})، ما جهّزت عدد` });
    const { data: vdata } = await db.from('news_items').select(cols).eq('tier', 'video').neq('status', 'rejected').gte('created_at', since).order('created_at', { ascending: false }).limit(15);
    const vids = (vdata || []) as Cand[];
    const n = ids.length ? ids.length : Math.min(8, Math.max(2, Number(A.count) || P.count, 1), list.length);
    let r: Record<string, unknown>;
    try { r = await gemini(key, S.model, issuePrompt(list, vids, n, !ids.length, S.tone, P.word)); }
    catch (e) { return json({ error: arErr(e).slice(0, 220), quota: /^QUOTA/.test(arErr(e)) }, /^QUOTA/.test(arErr(e)) ? 429 : 502); }
    const byId = new Map(list.map((x) => [x.id, x])), vById = new Map(vids.map((x) => [x.id, x]));
    const raw = (Array.isArray(r?.slides) ? r.slides : []) as Record<string, unknown>[];
    const picked = raw.map((x) => ({ x, it: byId.get(Number(x.id)) })).filter((p) => p.it).slice(0, n);
    if (!picked.length) return json({ error: 'Gemini ما رجّع سلايدات — جرّب مرة ثانية' }, 502);
    const slides = [];
    for (const { x, it } of picked) {
      if (Date.now() > DEADLINE - 10_000) break;
      const v = vById.get(Number(x.video));
      const img = await keepImage(db, it!.image);
      const company = String(x.company || it!.src_name || '').slice(0, 40);
      slides.push({
        company, initial: company.replace(/[^A-Za-z0-9؀-ۿ]/g, '').slice(0, 2).toUpperCase() || 'AI',
        head: String(x.head || it!.title || '').slice(0, 120), body: String(x.body || it!.summary || '').slice(0, 420),
        source: it!.src_name, url: it!.url, tier: it!.tier || '', news_id: it!.id,
        media: img ? { url: img, kind: 'image' } : null, trim: [0, 0], rights: false,
        video: v ? { url: v.url, title: v.title || v.src_title, src: v.src_name } : null, // اقتراح مقطع رسمي — تنزّله وترفعه أنت
      });
    }
    const now = new Date(), ksa = new Date(now.getTime() + 3 * 36e5);
    const num = kind === 'daily' ? ksa.getUTCDate() : kind === 'monthly' ? ksa.getUTCMonth() + 1 : isoWeek(now);
    const look = { style: 'aura', theme: 'noble', ...(A.look || {}) };
    const titles = (A.titles || {}) as Record<string, string>, kickers = (A.kickers || {}) as Record<string, string>;
    const { data: ins, error } = await db.from('ai_issues').insert({
      kind, week: num, ai: true, look, slides, date_label: kind === 'monthly' ? arMonth(now) : arDate(now),
      title: urgent ? (String(slides[0]?.head || 'خبر عاجل في الذكاء الاصطناعي')) : String(titles[kind] || P.title),
      kicker: urgent ? '⚡ عاجل' : String(kickers[kind] || P.kicker),
    }).select('id').single();
    if (error) return json({ error: error.message }, 500);
    return json({ ok: true, id: ins.id, kind, slides: slides.length, from: list.length, videos: vids.length });
  }

  // ترجمة الأخبار اللي انسحبت بدون ترجمة (مثلاً لما كان Gemini مزدحماً)
  if (action === 'translate') {
    if (!key) return json({ error: 'أضف مفتاح Gemini أولاً' }, 400);
    const direct = await directIds(db);
    let tq = db.from('news_items').select('*').eq('ai', false).neq('status', 'rejected').not('source_id', 'is', null);
    if (direct.length) tq = tq.not('source_id', 'in', `(${direct.join(',')})`);
    const { data: list } = await tq.order('created_at', { ascending: false }).limit(Math.min(10, Number(body.limit) || 6));
    let done = 0;
    const errors: string[] = [];
    const t0 = Date.now();
    for (const it of list || []) {
      if (Date.now() > DEADLINE - 15_000) break;
      if (Date.now() - t0 > 110_000) break;
      try {
        const r = await gemini(key, S.model, promptFor({ title: it.src_title || it.title, text: it.src_text || it.body, src: it.src_name }, S.tone, doms, it.cat, F));
        if (r.relevant === false) { await db.from('news_items').update({ status: 'rejected', updated_at: new Date().toISOString() }).eq('id', it.id); done++; continue; }
        await db.from('news_items').update({ title: String(r.title || it.title).slice(0, 220), summary: String(r.summary || '').slice(0, 600), body: String(r.body || '').slice(0, 6000),
          why: String(r.why || '').slice(0, 600), ...classify(r, doms, it.cat, it.topic), featured: F.featured && r.featured === true, ai: true, updated_at: new Date().toISOString() }).eq('id', it.id);
        done++;
        await sleep(4000);
      } catch (e) { errors.push(String((e as Error).message || e).slice(0, 160)); if (/quota|rate|429/i.test(String(e))) break; }
    }
    let cq = db.from('news_items').select('id', { count: 'exact', head: true }).eq('ai', false).neq('status', 'rejected').not('source_id', 'is', null);
    if (direct.length) cq = cq.not('source_id', 'in', `(${direct.join(',')})`);
    const { count } = await cq;
    return json({ ok: true, translated: done, left: count ?? 0, errors });
  }

  // ---- السحب ----
  const started = Date.now();
  const { data: sources } = await db.from('news_sources').select('*').eq('active', true).order('id');
  const minDate = Date.now() - Math.max(1, Number(S.maxAgeDays) || 3) * 864e5;
  const fresh: (Item & { src: { id: number; name: string; cat: string; cats: string[]; topic: string; country: string; direct: boolean; tier: string } })[] = [];
  const report: Record<string, string | number> = {};
  DEADLINE = started + 105_000;
  const fetchOne = async (s: Record<string, any>) => {
    try {
      // قناة يوتيوب (@الاسم أو /channel/) ← رابط RSS الخاص فيها، ونحفظه للمرات الجاية
      if (/youtube\.com\/(@|channel\/|c\/|user\/)/i.test(s.url) && !/feeds\/videos\.xml/.test(s.url)) {
        const feed = await ytFeed(s.url);
        if (!feed) throw new Error('ما لقيت معرّف القناة — الصق رابط القناة الصحيح');
        await db.from('news_sources').update({ url: feed }).eq('id', s.id);
        s.url = feed;
      }
      const items = parseFeed(await get(s.url, 8000)).filter((x) => !x.date || +x.date >= minDate).slice(0, 15);
      items.forEach((x) => fresh.push({ ...x, src: { id: s.id, name: s.name, cat: s.cat || 'ai', cats: [...new Set([s.cat || 'ai', ...((s.cats as string[]) || [])])], topic: s.topic || '', country: s.country || '', direct: isDirect(s), tier: s.tier || '' } }));
      report[s.name] = items.length;
      const ok = await db.from('news_sources').update({ last_fetch: new Date().toISOString(), last_error: null, fails: 0 }).eq('id', s.id);
      if (ok.error) await db.from('news_sources').update({ last_fetch: new Date().toISOString(), last_error: null }).eq('id', s.id);
    } catch (e) {
      const msg = String((e as Error).message || e).slice(0, 180);
      report[s.name] = 'خطأ: ' + msg.slice(0, 120);
      // 1.21.29: ⏸️ بعد ٥ مرات فاشلة ورا بعض يوقف المصدر لحاله (يرجع يشتغل لما تفعّله من اللوحة)
      const n = (Number(s.fails) || 0) + 1, pause = n >= 5;
      const up = await db.from('news_sources').update({ last_fetch: new Date().toISOString(), last_error: pause ? 'AUTO_PAUSED ' + msg : msg, fails: n, ...(pause ? { active: false } : {}) }).eq('id', s.id);
      if (up.error) await db.from('news_sources').update({ last_fetch: new Date().toISOString(), last_error: msg }).eq('id', s.id);
    }
  };
  // نسحب المصادر ٦ مع بعض بدل وحدة وحدة (أسرع بكثير)
  const srcs = sources || [];
  for (let i = 0; i < srcs.length; i += 6) await Promise.all(srcs.slice(i, i + 6).map(fetchOne));
  // استبعاد الموجود مسبقاً
  const guids = [...new Set(fresh.map((x) => x.guid))];
  const known = new Set<string>();
  for (let i = 0; i < guids.length; i += 100) {
    const { data } = await db.from('news_items').select('guid').in('guid', guids.slice(i, i + 100));
    (data || []).forEach((r: { guid: string }) => known.add(r.guid));
  }
  const seen = new Set<string>();
  const pool = fresh.filter((x) => !known.has(x.guid) && !seen.has(x.guid) && seen.add(x.guid))
    .sort((a, b) => (+(b.date || 0)) - (+(a.date || 0)));
  // المصادر المباشرة ما تستهلك Gemini، فلها حصة مستقلة (٢٠) غير حصة الترجمة
  const perAi = Math.min(20, Math.max(1, Number(S.perRun) || 8));
  // 🎯 1.19: نستبعد المواضيع الممنوعة (سياسة…) قبل أي شي — مجاناً بدون Gemini — ونحفظها «مرفوضة» عشان ما تنسحب مرة ثانية
  // 1.21.3: لو سحبين اشتغلوا مع بعض (التلقائي + «اسحب الآن») نفس الخبر يتسجل مرة وحدة بدون خطأ duplicate key
  const put = (row: Record<string, unknown>) => db.from('news_items').upsert(row, { onConflict: 'guid', ignoreDuplicates: true }).select('id');
  const exists = async (guid: string) => { const { data } = await db.from('news_items').select('id').eq('guid', guid).limit(1); return !!data?.length; };
  let filtered = 0;
  const okPool = [] as typeof pool;
  for (const x of pool) {
    const why = blockedBy(F, x.title, x.text);
    if (why || (F.weights[x.src.cat] ?? 1) <= 0) {
      filtered++;
      if (filtered <= 150) await put({ guid: x.guid, url: x.url, src_name: x.src.name, src_title: x.title, status: 'rejected', source_id: x.src.id, cat: x.src.cat, country: x.src.country, tier: x.src.tier, why: why ? 'فلتر: ' + why : 'مجال موقوف' });
      continue;
    }
    okPool.push(x);
  }
  // الأولوية: كل مجال ياخذ حصة على قد وزنه (التقنية والذكاء الاصطناعي أكثر)
  const todo = [...pickWeighted(okPool.filter((x) => x.src.direct), 20, F), ...pickWeighted(okPool.filter((x) => !x.src.direct), perAi, F)];

  // صور المصادر المباشرة (مثل الجزيرة ما ترسل صورة) نجيبها ٦ مع بعض قبل الحفظ
  const needImg = todo.filter((x) => x.src.direct && !x.image);
  for (let i = 0; i < needImg.length && Date.now() - started < 60_000; i += 6) {
    await Promise.all(needImg.slice(i, i + 6).map(async (x) => { x.image = await ogImage(x.url); }));
  }
  let added = 0, skipped = 0, dup = 0, pubAdded = 0;
  const errors: string[] = [];
  for (const it of todo) {
    if (Date.now() - started > 95_000) { errors.push('توقف لتجاوز الوقت — الباقي في السحب القادم'); break; }
    if (await exists(it.guid)) { dup++; continue; } // انسحب من سحب ثاني شغّال بنفس الوقت — ما نصرف عليه Gemini
    let ai: Record<string, string | boolean> | null = null;
    const direct = it.src.direct;
    if (key && !direct) {
      try {
        ai = await gemini(key, S.model, promptFor({ title: it.title, text: it.text, src: it.src.name }, S.tone, doms, it.src.cat, F, it.src.cats));
        await sleep(4500); // حدود الخطة المجانية
      } catch (e) { errors.push(String((e as Error).message || e).slice(0, 160)); if (/quota|rate|429/i.test(String(e))) break; }
    }
    const cls = classify(ai as Record<string, unknown> | null, doms, it.src.cat, it.src.topic, it.src.cats);
    if (ai && ai.relevant !== false && (F.weights[cls.cat] ?? 1) <= 0) ai.relevant = false; // Gemini صنّفه لمجال موقوف
    if (ai && ai.relevant === false) {
      skipped++;
      await put({ guid: it.guid, url: it.url, src_name: it.src.name, src_title: it.title, status: 'rejected', source_id: it.src.id, cat: it.src.cat, country: it.src.country, tier: it.src.tier });
      continue;
    }
    const image = it.image || (it.src.direct ? '' : await ogImage(it.url));
    const status = S.auto && (ai || direct) ? 'published' : 'draft';
    // المصدر العربي المباشر: العنوان + نبذة قصيرة + رابط المصدر (ما ننسخ المقال كامل)
    const brief = direct ? (it.text.length > 400 ? it.text.slice(0, 400).replace(/\s+\S*$/, '') + '…' : it.text) : '';
    const { data: insd, error } = await put({
      source_id: it.src.id, guid: it.guid, url: it.url, src_name: it.src.name, src_title: it.title, src_text: it.text, image: image.slice(0, 600),
      ...cls, country: it.src.country, featured: F.featured && ai?.featured === true,
      title: String(ai?.title || it.title).slice(0, 220), summary: String(ai?.summary || (direct ? (brief.length > 280 ? brief.slice(0, 280).replace(/\s+\S*$/, '') + '…' : brief) : it.text.slice(0, 280))).slice(0, 600),
      body: String(ai?.body || (direct ? brief : it.text)).slice(0, 6000), why: String(ai?.why || '').slice(0, 600),
      ai: !!ai, status, tier: it.src.tier, pub_at: it.date?.toISOString() ?? null, published_at: status === 'published' ? new Date().toISOString() : null,
    });
    if (error) { if (/duplicate key|23505/i.test(error.message)) dup++; else errors.push(error.message); }
    else if (insd && insd.length) { added++; if (status === 'published') pubAdded++; } else dup++;
  }
  // تنظيف
  const ago = (d: number) => new Date(Date.now() - d * 864e5).toISOString();
  await db.from('news_items').delete().eq('status', 'draft').lt('created_at', ago(14));
  await db.from('news_items').delete().eq('status', 'published').eq('pinned', false).lt('published_at', ago(Math.max(7, Number(S.keepDays) || 60)));
  await db.from('news_items').update({ src_text: '', body: '' }).eq('status', 'rejected').lt('created_at', ago(3));

  // 1.21.8: النشر التلقائي → إشعار مجمّع فوري (Firebase) — لو push-send منشورة
  if (pubAdded > 0) { try { await fetch(`${URL_}/functions/v1/push-send`, { method: 'POST', headers: { Authorization: `Bearer ${SRK}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ kind: 'batch', n: pubAdded }) }); } catch { /* الإشعار اختياري */ } }
  return json({ ok: true, added, skipped, dup, filtered, checked: todo.length, sources: report, errors, auto: !!S.auto, ai: !!key, ms: Date.now() - started });
});
