// NOBLE — «🔔 push-send» (1.21.8): إشعارات فورية عبر Firebase (FCM v1) — توصل حتى والتطبيق مسكّر
// المفتاح: سر FCM_SERVICE_ACCOUNT في Supabase ← Edge Functions ← Secrets (ملف حساب الخدمة من Firebase كامل)
// الأنواع:
//   { kind: 'batch', n }          إشعار مجمّع «نزل n أخبار» — يندمج مع اللي قبله خلال ٣٠ دقيقة (نفس الإشعار يتحدّث)، وله حد يومي وساعات هدوء
//   { kind: 'one', id }           «🔔 انشر ونبّه» لخبر مهم — فوري
//   { kind: 'test' }              تجربة لجوالك أنت بس
//   { kind: 'issue', id }         عدد عاجل جديد
//   { kind: 'remind', id, what } 🔔 تنبيه المشرف: مسودة جاهزة (ready) · لسا ما انتشرت (late) · قرّب موعد نشرها (soon) — 1.21.26 (من الـcron بس)
//   { kind: 'custom', id }        إشعار من «🔔 الإشعارات» في اللوحة (push_notes) — للجميع أو أشخاص محددين (1.21.22)
// 🖼️ 1.21.22: صورة كبيرة (مثل الجزيرة) — news_settings.data.push.img = { issue:{mode,url}, news:{mode,url}, custom:{mode,url} }
// الصلاحية: أدمن عنده news.manage، أو السيرفر نفسه (news-fetch بعد النشر التلقائي) بمفتاح الخدمة
import { createClient } from 'npm:@supabase/supabase-js@2';

const CORS = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-news-secret', 'Access-Control-Allow-Methods': 'POST, OPTIONS' };
const json = (b: unknown, s = 200) => new Response(JSON.stringify(b), { status: s, headers: { ...CORS, 'Content-Type': 'application/json' } });
const DEF = { mode: 'batch', cap: 3, merge: 30, quietFrom: 23, quietTo: 7 };

// ---------- مفتاح الوصول من حساب الخدمة (JWT RS256) ----------
const b64u = (b: ArrayBuffer | Uint8Array | string) => {
  const s = typeof b === 'string' ? btoa(unescape(encodeURIComponent(b))) : btoa(String.fromCharCode(...new Uint8Array(b instanceof Uint8Array ? b : new Uint8Array(b))));
  return s.replace(/=+$/, '').replace(/\+/g, '-').replace(/\//g, '_');
};
let TOK: { t: string; exp: number } | null = null;
async function accessToken(sa: { client_email: string; private_key: string; token_uri?: string }) {
  if (TOK && TOK.exp > Date.now() + 60_000) return TOK.t;
  const now = Math.floor(Date.now() / 1000);
  const head = b64u(JSON.stringify({ alg: 'RS256', typ: 'JWT' }));
  const claim = b64u(JSON.stringify({ iss: sa.client_email, scope: 'https://www.googleapis.com/auth/firebase.messaging', aud: sa.token_uri || 'https://oauth2.googleapis.com/token', iat: now, exp: now + 3600 }));
  const pem = sa.private_key.replace(/-----[^-]+-----/g, '').replace(/\s+/g, '');
  const der = Uint8Array.from(atob(pem), (c) => c.charCodeAt(0));
  const key = await crypto.subtle.importKey('pkcs8', der, { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' }, false, ['sign']);
  const sig = await crypto.subtle.sign('RSASSA-PKCS1-v1_5', key, new TextEncoder().encode(`${head}.${claim}`));
  const r = await fetch(sa.token_uri || 'https://oauth2.googleapis.com/token', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${head}.${claim}.${b64u(sig)}` });
  const j = await r.json();
  if (!j.access_token) throw new Error('Firebase رفض المفتاح — تأكد إن FCM_SERVICE_ACCOUNT هو ملف حساب الخدمة كامل');
  TOK = { t: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return TOK.t;
}

// ساعة الرياض الحين
const riyadhHour = () => (new Date().getUTCHours() + 3) % 24;
const inQuiet = (f: number, t: number) => { const h = riyadhHour(); if (f === t) return false; return f < t ? h >= f && h < t : h >= f || h < t; };

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: CORS });
  const URL_ = Deno.env.get('SUPABASE_URL')!, SRK = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!, ANON = Deno.env.get('SUPABASE_ANON_KEY')!;
  const db = createClient(URL_, SRK, { auth: { persistSession: false } });
  const body = await req.json().catch(() => ({}));
  const kind = String(body?.kind || 'batch');

  // الصلاحية
  const auth = req.headers.get('Authorization') || '';
  let me: string | null = null;
  // 1.21.13: الـcron (نشر عدد مجدول) يجي بسر news_secret
  const xs = req.headers.get('x-news-secret') || '';
  let viaCron = false;
  if (xs) { const { data: sec } = await db.from('news_secret').select('cron_secret').eq('id', 1).maybeSingle(); viaCron = !!sec?.cron_secret && xs === sec.cron_secret; }
  if (auth !== `Bearer ${SRK}` && !viaCron) {
    const user = createClient(URL_, ANON, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
    // إشعارات اللوحة: صلاحية الرسائل — والباقي: صلاحية الأخبار
    let ok = false;
    if (kind === 'custom') { for (const p of ['messages.broadcast', 'messages.send']) { const { data } = await user.rpc('has_perm', { p }); if (data === true) { ok = true; break; } } }
    else { const { data } = await user.rpc('has_perm', { p: 'news.manage' }); ok = data === true; }
    if (!ok) return json({ error: 'not allowed' }, 403);
    me = (await user.auth.getUser()).data.user?.id || null;
  }

  const raw = Deno.env.get('FCM_SERVICE_ACCOUNT') || '';
  let sa: { project_id: string; client_email: string; private_key: string; token_uri?: string };
  try { sa = JSON.parse(raw); if (!sa.private_key || !sa.project_id) throw 0; } catch { return json({ error: 'FCM_SERVICE_ACCOUNT مو موجود أو ناقص — حطّه في Supabase ← Edge Functions ← Secrets' }, 500); }

  const { data: st } = await db.from('news_settings').select('data').eq('id', 1).maybeSingle();
  const P = { ...DEF, ...((st?.data as Record<string, unknown>)?.push as Record<string, unknown> || {}) } as typeof DEF;
  const label = String((st?.data as Record<string, unknown>)?.title || 'الأخبار');
  // 🖼️ صور الإشعارات
  type Slot = { mode?: string; url?: string };
  const IMG = (((st?.data as Record<string, unknown>)?.push as Record<string, unknown>)?.img || {}) as Record<string, Slot>;
  const okUrl = (u: unknown) => typeof u === 'string' && /^https:\/\/\S{8,600}$/.test(u) ? u : '';
  const fixed = (k: string) => (IMG[k]?.mode === 'off' ? '' : okUrl(IMG[k]?.url));
  let image = '', targets: string[] = [];

  // ---------- وش نرسل ----------
  let title = '', text = '', data: Record<string, string> = { tab: 'news' }, tag = '', logId: number | null = null, n = 1;
  if (kind === 'test') {
    title = '🔔 تجربة إشعارات NOBLE'; text = 'لو وصلك هذا والتطبيق مسكّر — الإشعارات الفورية شغّالة ✓ (اسحبه لتحت تشوف الصورة)'; tag = 'test';
    image = okUrl(body.image) || fixed('custom') || fixed('issue') || fixed('news');
  } else if (kind === 'custom') {
    // 🔔 إشعار من اللوحة (انحفظ في push_notes قبلها)
    const { data: pn } = await db.from('push_notes').select('id, title, body, tab, link, targets, image, active').eq('id', Number(body.id)).maybeSingle();
    if (!pn || !pn.active) return json({ error: 'الإشعار مو موجود' }, 400);
    title = String(pn.title || '').slice(0, 110); text = String(pn.body || '').slice(0, 220);
    data = { push: String(pn.id) }; if (pn.tab) data.tab = String(pn.tab); if (pn.link) data.link = String(pn.link);
    tag = `push-${pn.id}`; targets = (pn.targets || []).map(String);
    image = pn.image === 'def' ? fixed('custom') : okUrl(pn.image);
  } else if (kind === 'issue') {
    // ⚡ عدد عاجل جديد (منشور بيدك أو بالجدولة)
    const { data: is } = await db.from('ai_issues').select('id, title, kind, status, slides, look').eq('id', Number(body.id)).maybeSingle();
    if (!is || is.status !== 'published') return json({ error: 'العدد مو منشور' }, 400);
    const K: Record<string, string> = { daily: 'عدد اليوم', weekly: 'عدد الأسبوع', monthly: 'عدد الشهر', urgent: 'عاجل' };
    title = `⚡ ${K[is.kind] || 'عدد جديد'} نزل في NOBLE عاجل`.slice(0, 110); text = `${is.title || ''} — ${(is.slides || []).length} أخبار`.slice(0, 220); data = { tab: 'news', issue: String(is.id) }; tag = `issue-${is.id}`;
    const ni = (is.look as Record<string, unknown> | null)?.notifImg, mode = IMG.issue?.mode || 'auto';
    image = mode === 'off' || ni === 'none' ? '' : mode === 'fixed' ? (fixed('issue') || okUrl(ni)) : (okUrl(body.image) || okUrl(ni) || fixed('issue'));
  } else if (kind === 'remind') {
    // 🔔 1.21.26: للمشرفين بس (صلاحية الأخبار) — من الـcron
    if (!viaCron && auth !== `Bearer ${SRK}`) return json({ error: 'not allowed' }, 403);
    const { data: is } = await db.from('ai_issues').select('id, title, kind, status, slides, publish_at').eq('id', Number(body.id)).maybeSingle();
    if (!is || is.status !== 'draft') return json({ ok: true, skipped: 'not draft' });
    const K: Record<string, string> = { daily: 'عدد اليوم', weekly: 'عدد الأسبوع', monthly: 'عدد الشهر', urgent: 'العاجل' };
    const k = K[is.kind] || 'العدد', nS = (is.slides || []).length, what = String(body.what || 'ready');
    const hm = is.publish_at ? new Date(new Date(is.publish_at).getTime() + 3 * 36e5).toISOString().slice(11, 16) : '';
    const left = is.publish_at ? Math.max(1, Math.round((new Date(is.publish_at).getTime() - Date.now()) / 60000)) : 0;
    if (what === 'soon') { title = `⏰ ${k} ينشر الساعة ${hm}`; text = `باقي ${left} دقيقة — شيّك عليه قبل ما ينشر: ${is.title || ''}`; }
    else if (what === 'late') { title = `⏰ ${k} لسا ينتظرك`; text = `المسودة جاهزة من فترة وما انتشرت — ${is.title || ''} · ${nS} أخبار`; }
    else { title = `📝 ${k} جاهز للمراجعة`; text = `${is.title || ''} · ${nS} أخبار — راجعه وانشره`; }
    title = title.slice(0, 110); text = text.slice(0, 220);
    data = { admin: 'ainews', draft: String(is.id) }; tag = `remind-${is.id}`;
    const m = (is.slides || []).map((x: { media?: { url?: string; kind?: string } }) => x.media).find((x: { url?: string; kind?: string } | undefined) => x?.kind === 'image' && okUrl(x.url));
    image = okUrl(m?.url) || fixed('issue');
    const { data: ids } = await db.rpc('news_admin_ids');
    targets = ((ids || []) as (string | { news_admin_ids: string })[]).map((x) => typeof x === 'string' ? x : x.news_admin_ids).filter(Boolean);
    if (!targets.length) return json({ ok: true, sent: 0, note: 'ما فيه مشرفين' });
  } else if (kind === 'one') {
    const { data: it } = await db.from('news_items').select('id, title, summary, status, image').eq('id', Number(body.id)).maybeSingle();
    if (!it || it.status !== 'published') return json({ error: 'الخبر مو منشور' }, 400);
    title = `⚡ ${it.title}`.slice(0, 110); text = String(it.summary || '').slice(0, 220); data = { tab: 'news', news: String(it.id) }; tag = `news-${it.id}`;
    const mode = IMG.news?.mode || 'item';
    image = mode === 'off' ? '' : mode === 'fixed' ? fixed('news') : (okUrl(it.image) || fixed('news'));
  } else {
    if (P.mode === 'off') return json({ ok: true, skipped: 'off' });
    n = Math.max(1, Math.min(200, Number(body.n) || 1));
    if (inQuiet(Number(P.quietFrom), Number(P.quietTo))) return json({ ok: true, skipped: 'quiet' });
    // دمج مع آخر دفعة خلال «merge» دقيقة
    const since = new Date(Date.now() - (Number(P.merge) || 30) * 60_000).toISOString();
    const { data: last } = await db.from('push_log').select('id, n').eq('kind', 'news_batch').gte('at', since).order('id', { ascending: false }).limit(1).maybeSingle();
    if (last) { n += last.n; logId = last.id; }
    else {
      const day = new Date(Date.now() + 3 * 3600_000); day.setUTCHours(0, 0, 0, 0);
      const { count } = await db.from('push_log').select('id', { count: 'exact', head: true }).eq('kind', 'news_batch').gte('at', new Date(day.getTime() - 3 * 3600_000).toISOString());
      if ((count || 0) >= (Number(P.cap) || 3)) return json({ ok: true, skipped: 'cap' });
    }
    const { data: top } = await db.from('news_items').select('title, image').eq('status', 'published').order('published_at', { ascending: false }).limit(1).maybeSingle();
    const mode = IMG.news?.mode || 'item';
    image = mode === 'off' ? '' : mode === 'fixed' ? fixed('news') : (okUrl(top?.image) || fixed('news'));
    title = `📰 ${n === 1 ? 'نزل خبر جديد' : `نزل ${n} أخبار جديدة`} في ${label}`.slice(0, 110);
    text = top?.title ? `أبرزها: ${top.title}`.slice(0, 220) : 'افتح التطبيق وشوفها';
    tag = 'news-batch';
  }

  // ---------- الأجهزة ----------
  let q = db.from('push_tokens').select('token');
  if (kind === 'test') { if (!me) return json({ error: 'سجّل دخول' }, 401); q = q.eq('user_id', me); }
  else if (targets.length) q = q.in('user_id', targets.slice(0, 500));
  const { data: toks } = await q.limit(20000);
  const list = (toks || []).map((x: { token: string }) => x.token);
  if (!list.length) return json({ ok: true, sent: 0, note: kind === 'test' ? 'جوالك مو مسجّل بعد — افتح التطبيق بنسخة 1.21.8 واسمح بالإشعارات' : 'ما فيه أجهزة مسجّلة بعد' });

  const at = await accessToken(sa);
  const url = `https://fcm.googleapis.com/v1/projects/${sa.project_id}/messages:send`;
  let sent = 0, failed = 0; const dead: string[] = [];
  const one = async (token: string) => {
    const r = await fetch(url, { method: 'POST', headers: { Authorization: `Bearer ${at}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ message: {
      token, notification: { title, body: text, ...(image ? { image } : {}) }, data,
      android: { priority: 'high', notification: { tag, channel_id: 'news', icon: 'ic_stat_nobleweb', color: '#F0922F', sound: 'default', ...(image ? { image } : {}) } },
    } }) });
    if (r.ok) { sent++; return; }
    failed++;
    const e = await r.text().catch(() => '');
    if (r.status === 404 || /UNREGISTERED|INVALID_ARGUMENT.*token|registration-token-not-registered/i.test(e)) dead.push(token);
  };
  for (let i = 0; i < list.length; i += 25) await Promise.all(list.slice(i, i + 25).map(one));
  for (let i = 0; i < dead.length; i += 200) await db.from('push_tokens').delete().in('token', dead.slice(i, i + 200));

  const row = { kind: kind === 'remind' ? 'remind' : kind === 'one' ? 'news_one' : kind === 'issue' ? 'ai_issue' : kind === 'test' ? 'test' : kind === 'custom' ? 'custom' : 'news_batch', title, body: text, n, sent, failed };
  if (logId) await db.from('push_log').update({ ...row, at: new Date().toISOString() }).eq('id', logId); else await db.from('push_log').insert(row);
  return json({ ok: true, sent, failed, removed: dead.length, n, image: image || null });
});
