-- NOBLE — «🏷️ ملاحظاتك عن المستخدم»: وسوم وملاحظة يكتبها المالك/الفريق (ما تجي من جوال المستخدم ولا يشوفها)
-- الصقه مرة وحدة: Supabase ← SQL Editor ← New query ← الصق ← Run
create table if not exists public.user_notes (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  tags       text[] not null default '{}',
  note       text not null default '',
  updated_by uuid,
  updated_at timestamptz not null default now()
);
alter table public.user_notes enable row level security; -- بدون سياسات: ما أحد يقراها إلا من الدوال تحت

create or replace function public.admin_user_notes()
returns table (user_id uuid, tags text[], note text, updated_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('users.view') then raise exception 'not allowed'; end if;
  return query select n.user_id, n.tags, n.note, n.updated_at from user_notes n;
end $$;

create or replace function public.admin_user_note_set(p_uid uuid, p_tags text[], p_note text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('users.manage') then raise exception 'not allowed'; end if;
  insert into user_notes (user_id, tags, note, updated_by, updated_at)
  values (p_uid, coalesce(p_tags[1:12], '{}'), left(coalesce(p_note, ''), 2000), auth.uid(), now())
  on conflict (user_id) do update set tags = excluded.tags, note = excluded.note, updated_by = excluded.updated_by, updated_at = now();
end $$;

revoke all on function public.admin_user_notes() from public, anon;
revoke all on function public.admin_user_note_set(uuid, text[], text) from public, anon;
grant execute on function public.admin_user_notes() to authenticated;
grant execute on function public.admin_user_note_set(uuid, text[], text) to authenticated;
