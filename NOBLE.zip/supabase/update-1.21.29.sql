-- NOBLE 1.21.29 — مصادر الأخبار: عدّاد الفشل + إيقاف تلقائي بعد ٥ مرات
alter table public.news_sources add column if not exists fails int not null default 0;
-- لما تشغّل المصدر من اللوحة من جديد يتصفّر العدّاد والخطأ
create or replace function public.news_src_reset() returns trigger language plpgsql as $$
begin
  if new.active and not coalesce(old.active, false) then new.fails := 0; new.last_error := null; end if;
  if new.url is distinct from old.url then new.fails := 0; new.last_error := null; end if;
  return new;
end $$;
drop trigger if exists news_src_reset on public.news_sources;
create trigger news_src_reset before update on public.news_sources for each row execute function public.news_src_reset();
select 'NOBLE 1.21.29 ✓' as done;
