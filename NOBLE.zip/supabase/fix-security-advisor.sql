-- NOBLE — إصلاح تنبيهات Security Advisor (1.19.1) — يتشغّل أكثر من مرة بأمان
-- ١) Function Search Path Mutable: نثبّت search_path لكل دوال public اللي ما لها (غير دوال الإضافات)
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f'
       and not exists (select 1 from unnest(coalesce(p.proconfig, '{}')) c where c like 'search_path=%')
       and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')
  loop
    execute format('alter function %s set search_path = public', f.sig);
  end loop;
end $$;

-- ٢) Public Can Execute SECURITY DEFINER: الدوال تحتاج تسجيل دخول (حتى الضيف مسجّل) — نشيلها عن «بدون تسجيل»
--    ما نلمس الدوال اللي تستخدمها سياسات الجداول (has_perm وأمثالها) عشان ما ينكسر شي قبل الدخول.
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig, p.proname from pg_proc p join pg_namespace n on n.oid = p.pronamespace
     where n.nspname = 'public' and p.prokind = 'f' and p.prosecdef
       and not exists (select 1 from pg_depend d where d.objid = p.oid and d.deptype = 'e')
       and not exists (select 1 from pg_policies pl where coalesce(pl.qual, '') || ' ' || coalesce(pl.with_check, '') ~ ('\m' || p.proname || '\('))
  loop
    execute format('revoke execute on function %s from public, anon', f.sig);
    execute format('grant execute on function %s to authenticated, service_role', f.sig);
  end loop;
end $$;
