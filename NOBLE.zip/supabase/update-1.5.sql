-- ============================================================
-- NOBLE 1.5 — تطوير الرسائل
--  • روابط الرسائل كأزرار (مثل «اضغط هنا للتحديث»)
--  • رسائل إجبارية خاصة لمستخدمين محددين أو عامة للجميع
--  • شكل الشريط والشاشة (لون، شكل، حركة، مكان، أيقونة متحركة / GIF) + مدة انتهاء + تعديل مباشر
-- شغّله مرة واحدة في SQL Editor (آمن لو تكرر)
-- ============================================================

-- ---------- صندوق الرسائل ----------
alter table public.messages add column if not exists link       text  not null default '';
alter table public.messages add column if not exists link_label text  not null default '';
alter table public.messages add column if not exists style      jsonb not null default '{}'::jsonb;

drop function if exists public.admin_send_message(uuid, text, text);
drop function if exists public.admin_send_message(uuid, text, text, text, text);
create or replace function public.admin_send_message(p_target uuid, p_title text, p_body text, p_link text default '', p_label text default '', p_style jsonb default '{}'::jsonb)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_target is null and not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  if p_target is not null and not public.has_perm('messages.send') then raise exception 'not allowed'; end if;
  insert into messages (sender, target, title, body, link, link_label, style)
  values (auth.uid(), p_target, left(p_title, 120), left(coalesce(p_body, ''), 2000), left(coalesce(p_link, ''), 600),
          left(coalesce(p_label, ''), 40), coalesce(p_style, '{}'::jsonb));
  perform public.log_action('message', p_target, json_build_object('title', p_title)::jsonb);
end $$;

-- ---------- الرسائل الإجبارية ----------
alter table public.notices add column if not exists link_label text        not null default '';
alter table public.notices add column if not exists style      jsonb       not null default '{}'::jsonb;
alter table public.notices add column if not exists targets    uuid[];                 -- null = للجميع
alter table public.notices add column if not exists expires_at timestamptz;            -- null = بلا انتهاء
alter table public.notices add column if not exists updated_at timestamptz not null default now();

-- الخاصة لا يراها إلا أصحابها
drop policy if exists "notices: read active" on public.notices;
create policy "notices: read active" on public.notices for select
  using ((active and (targets is null or auth.uid() = any(targets))) or public.has_perm('messages.broadcast'));

drop function if exists public.admin_create_notice(text, text, text, text, text);
drop function if exists public.admin_create_notice(text, text, text, text, text, text);
create or replace function public.admin_create_notice(p_title text, p_body text, p_image text, p_link text, p_level text,
  p_label text default '', p_style jsonb default '{}'::jsonb, p_targets uuid[] default null, p_expires timestamptz default null)
returns bigint language plpgsql security definer set search_path = public as $$
declare nid bigint;
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  insert into notices (title, body, image_url, link, link_label, level, style, targets, expires_at, created_by)
  values (left(p_title, 120), left(coalesce(p_body, ''), 3000), left(coalesce(p_image, ''), 600), left(coalesce(p_link, ''), 600),
          left(coalesce(p_label, ''), 40), case when p_level = 'bar' then 'bar' else 'screen' end, coalesce(p_style, '{}'::jsonb),
          case when coalesce(array_length(p_targets, 1), 0) = 0 then null else p_targets end, p_expires, auth.uid())
  returning id into nid;
  perform public.log_action('notice', null, json_build_object('title', p_title, 'level', p_level, 'private', p_targets is not null)::jsonb);
  return nid;
end $$;

-- تعديل رسالة منشورة (يصل التعديل فوراً لمن لم يقرأها)
create or replace function public.admin_update_notice(p_id bigint, p_title text, p_body text, p_image text, p_link text, p_level text,
  p_label text default '', p_style jsonb default '{}'::jsonb, p_targets uuid[] default null, p_expires timestamptz default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  update notices set title = left(p_title, 120), body = left(coalesce(p_body, ''), 3000), image_url = left(coalesce(p_image, ''), 600),
         link = left(coalesce(p_link, ''), 600), link_label = left(coalesce(p_label, ''), 40),
         level = case when p_level = 'bar' then 'bar' else 'screen' end, style = coalesce(p_style, '{}'::jsonb),
         targets = case when coalesce(array_length(p_targets, 1), 0) = 0 then null else p_targets end,
         expires_at = p_expires, updated_at = now()
   where id = p_id;
end $$;

drop function if exists public.admin_notices();
create or replace function public.admin_notices()
returns table (id bigint, title text, body text, image_url text, link text, link_label text, level text, style jsonb,
               targets uuid[], expires_at timestamptz, active boolean, created_at timestamptz, reads bigint, total bigint)
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  return query
  select n.id, n.title, n.body, n.image_url, n.link, n.link_label, n.level, n.style, n.targets, n.expires_at, n.active, n.created_at,
         (select count(*) from notice_reads r where r.notice_id = n.id),
         case when n.targets is null then (select count(*) from profiles where status = 'active')
              else (select count(*) from profiles where status = 'active' and profiles.id = any(n.targets)) end
    from notices n order by n.id desc;
end $$;

-- من قرأ ومن لم يقرأ (للخاصة: أصحابها فقط)
create or replace function public.admin_notice_readers(p_id bigint)
returns table (user_id uuid, email text, name text, read_at timestamptz)
language plpgsql stable security definer set search_path = public as $$
declare t uuid[];
begin
  if not public.has_perm('messages.broadcast') then raise exception 'not allowed'; end if;
  select targets into t from notices where id = p_id;
  return query
  select p.id, p.email, p.display_name, r.read_at
    from profiles p left join notice_reads r on r.user_id = p.id and r.notice_id = p_id
   where p.status = 'active' and (t is null or p.id = any(t))
   order by r.read_at desc nulls last;
end $$;

-- رسائلي غير المقروءة: العامة + الخاصة بي، غير المنتهية
create or replace function public.my_notices()
returns setof public.notices language sql stable security definer set search_path = public as $$
  select n.* from notices n
   where n.active
     and (n.targets is null or auth.uid() = any(n.targets))
     and (n.expires_at is null or n.expires_at > now())
     and not exists (select 1 from notice_reads r where r.notice_id = n.id and r.user_id = auth.uid())
   order by n.id;
$$;

do $$
declare f text;
begin
  foreach f in array array[
    'public.admin_send_message(uuid, text, text, text, text, jsonb)',
    'public.admin_create_notice(text, text, text, text, text, text, jsonb, uuid[], timestamptz)',
    'public.admin_update_notice(bigint, text, text, text, text, text, text, jsonb, uuid[], timestamptz)',
    'public.admin_notices()', 'public.admin_notice_readers(bigint)', 'public.my_notices()']
  loop
    execute format('revoke all on function %s from anon, public', f);
    execute format('grant execute on function %s to authenticated', f);
  end loop;
end $$;
