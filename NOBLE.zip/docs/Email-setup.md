# إعداد رسائل الإيميل (نسيت كلمة المرور) — Gmail مجاناً

عشان يوصل كود «نسيت كلمة المرور» لكل المستخدمين، نربط Supabase بإيميلك في Gmail.
خدمة الإيميل المدمجة في Supabase ما ترسل إلا لإيميلات فريق المشروع وبعدد قليل جداً، فلازم هذا الربط.
Gmail يسمح بحوالي **500 رسالة في اليوم** مجاناً.

> أسماء القوائم في Supabase وقوقل قد تختلف قليلاً مع التحديثات.

---

## ١) كلمة مرور تطبيقات من قوقل (مرة واحدة)
1. افتح https://myaccount.google.com ← **الأمان (Security)**.
2. فعّل **التحقق بخطوتين (2-Step Verification)** إذا ما كان مفعّلاً.
3. افتح https://myaccount.google.com/apppasswords
4. اكتب اسماً مثل `NOBLE` ← **إنشاء (Create)**.
5. يطلع لك رمز من 16 حرفاً (مثل `abcd efgh ijkl mnop`). انسخه بدون مسافات واحفظه، لأنه ما يطلع مرة ثانية.

## ٢) ربط Gmail في Supabase
**Project Settings ← Authentication ← SMTP Settings ← Enable Custom SMTP**

| الحقل | القيمة |
|---|---|
| Sender email | إيميلك في Gmail (نفس الحساب) |
| Sender name | `NOBLE` |
| Host | `smtp.gmail.com` |
| Port | `465` |
| Username | إيميلك في Gmail كاملاً |
| Password | رمز التطبيقات (16 حرفاً بدون مسافات) |

اضغط **Save**.

## ٣) رسالة الكود بالعربي
**Authentication ← Email Templates ← Reset Password (Recovery)**

**Subject:**
```
رمز استرجاع حسابك في NOBLE: {{ .Token }}
```

**Message body** (انسخه كما هو):
```html
<div dir="rtl" style="font-family:Tahoma,Arial,sans-serif;max-width:480px;margin:auto;padding:24px;background:#ffffff;color:#111">
  <h2 style="margin:0 0 8px;color:#0B1638">NOBLE</h2>
  <p style="margin:0 0 16px">أهلاً، استخدم هذا الرمز لتعيين كلمة مرور جديدة لحسابك:</p>
  <div style="font-size:32px;font-weight:bold;letter-spacing:8px;text-align:center;padding:14px;border-radius:12px;background:#F1F4FF;color:#1537D1;direction:ltr">{{ .Token }}</div>
  <p style="margin:16px 0 0;color:#555;font-size:13px">الرمز صالح لمدة ساعة. اكتبه في التطبيق في شاشة «نسيت كلمة المرور».</p>
  <p style="margin:8px 0 0;color:#888;font-size:12px">إذا ما طلبت هذا، تجاهل الرسالة — حسابك بأمان.</p>
</div>
```
> المهم وجود `{{ .Token }}`، لأنه هو الكود اللي يكتبه المستخدم في التطبيق.

## ٤) إعدادات الكود
**Authentication ← Providers ← Email**
- **Email OTP Expiration:** `3600` (ساعة)
- **Email OTP Length:** `6`

**Authentication ← Rate Limits**
- **Rate limit for sending emails:** ارفعه إلى `30` أو أكثر في الساعة.

## ٥) جرّبه
1. في التطبيق ← تسجيل الدخول ← **نسيت كلمة المرور؟**
2. اكتب إيميلك ← **أرسل الكود**.
3. يوصلك الكود خلال ثوانٍ. إذا ما وصل، شيّك على مجلد «الرسائل غير المرغوبة».

---

## الاسترجاع وأمان البيانات
- **استرجاع تلقائي (الافتراضي):** مفتاح البيانات محفوظ في حساب المستخدم على السيرفر، فترجع بياناته كاملة بكود الإيميل فقط.
- **كود استرجاع خاص:** المستخدم يحفظ كوداً من 16 حرفاً، والمفتاح مشفّر به. لا أحد يقدر يفك البيانات بدونه، ولا حتى الإدارة. ولو ضاع الكود تضيع البيانات.
- يغيّر المستخدم الوضع من: **الإعدادات ← الأمان ← إذا نسيت كلمة المرور**.
